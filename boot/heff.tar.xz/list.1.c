// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_EInvalid 31081
#define TAG_EProject 35489
#define TAG_ESpec 56652
#define TAG_EVar 52881
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_IVal 40987
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_RLocal 34280
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define LBL_arg 306384
#define LBL_end 310101
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_ok 10307
#define LBL_refs 9991943
#define LBL_shown 310772011
#define LBL_size 10026184
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_use 325633
#define LBL_value 313331083
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2earity_2earityOne(V, V);
V g_heff_2ecompile_2earity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earity_2earityOne_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeRes(V);
V g_heff_2ecompile_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeRes_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2erepr_2edecidedIn(V, V, V);
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecidedIn_clo;
V g_heff_2ecompile_2esimplify_2ecanonVisit(V, V);
V g_heff_2ecompile_2esimplify_2ecanonVisit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecanonVisit_clo;
V g_heff_2ecompile_2espec_2ebindOne(V, V);
V g_heff_2ecompile_2espec_2ebindOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ebindOne_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2erenameAlt(V, V);
V g_heff_2eelab_2eclauses_2erenameAlt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameAlt_clo;
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2efmt_2etokens_2elineElem(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2elineElem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2elineElem_clo;
V g_heff_2esyntax_2eimport_2eimplicitImports_get(void);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf(V, V);
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902(V);
V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(V);
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_clo;
V g_heff_2esyntax_2esurface_2eidentOf(V);
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eidentOf_clo;
V g_heff_2eutil_2ejson_2eescapeGo(V, V, V);
V g_heff_2eutil_2ejson_2eescapeGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2eescapeGo_clo;
V g_heff_2eutil_2ejson_2estringify(V);
V g_heff_2eutil_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2estringify_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1375915522x445000623(V);
V g_list_2eany_24s1375915522x445000623_entry(V self, V *a);
extern Clo g_list_2eany_24s1375915522x445000623_clo;
V g_list_2eany_24s1523549873x2075662238(V, V);
V g_list_2eany_24s1523549873x2075662238_entry(V self, V *a);
extern Clo g_list_2eany_24s1523549873x2075662238_clo;
V g_list_2eany_24s577543654x765608923(V);
V g_list_2eany_24s577543654x765608923_entry(V self, V *a);
extern Clo g_list_2eany_24s577543654x765608923_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1490692278x809324339(V);
V g_list_2efilter_24s1490692278x809324339_entry(V self, V *a);
extern Clo g_list_2efilter_24s1490692278x809324339_clo;
V g_list_2efilter_24s1490692278x809324339_24dps(V, V);
V g_list_2efilter_24s1490692278x809324339_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1490692278x809324339_24dps_clo;
V g_list_2efilter_24s716173495x680820632_24dps(V, V, V);
V g_list_2efilter_24s716173495x680820632_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s716173495x680820632_24dps_clo;
V g_list_2efilter_24s951260806x709953240_24dps(V, V, V);
V g_list_2efilter_24s951260806x709953240_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s951260806x709953240_24dps_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efind_24s1085725546x1737150855(V, V);
V g_list_2efind_24s1085725546x1737150855_entry(V self, V *a);
extern Clo g_list_2efind_24s1085725546x1737150855_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24f421425463x1941958307(V, V, V);
V g_list_2efoldl_24f421425463x1941958307_entry(V self, V *a);
extern Clo g_list_2efoldl_24f421425463x1941958307_clo;
V g_list_2efoldl_24s1048046132x95752937(V, V);
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1048046132x95752937_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1368043225x413679696(V, V, V);
V g_list_2efoldl_24s1368043225x413679696_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1368043225x413679696_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1577366920x1019062938(V, V);
V g_list_2efoldl_24s1577366920x1019062938_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1577366920x1019062938_clo;
V g_list_2efoldl_24s1872971975x1696014049(V, V, V);
V g_list_2efoldl_24s1872971975x1696014049_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1872971975x1696014049_clo;
V g_list_2efoldl_24s1915639815x253536901(V, V);
V g_list_2efoldl_24s1915639815x253536901_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1915639815x253536901_clo;
V g_list_2efoldl_24s1991317015x801331450(V, V);
V g_list_2efoldl_24s1991317015x801331450_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1991317015x801331450_clo;
V g_list_2efoldl_24s419339443x1702462498(V, V);
V g_list_2efoldl_24s419339443x1702462498_entry(V self, V *a);
extern Clo g_list_2efoldl_24s419339443x1702462498_clo;
V g_list_2efoldl_24s455728131x407835966(V, V);
V g_list_2efoldl_24s455728131x407835966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s455728131x407835966_clo;
V g_list_2efoldl_24s496727651x1448898893(V, V);
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a);
extern Clo g_list_2efoldl_24s496727651x1448898893_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s776002836x391891384(V, V);
V g_list_2efoldl_24s776002836x391891384_entry(V self, V *a);
extern Clo g_list_2efoldl_24s776002836x391891384_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24dps(V, V, V);
V g_list_2emap_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24dps_clo;
V g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps(V, V, V, V, V);
V g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps_clo;
V g_list_2emap_24f768999161x1997188166_24dps(V, V, V, V);
V g_list_2emap_24f768999161x1997188166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f768999161x1997188166_24dps_clo;
V g_list_2emap_24s1036840854x702708481_24dps(V, V, V);
V g_list_2emap_24s1036840854x702708481_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_24dps_clo;
V g_list_2emap_24s1150457979x1978067071(V);
V g_list_2emap_24s1150457979x1978067071_entry(V self, V *a);
extern Clo g_list_2emap_24s1150457979x1978067071_clo;
V g_list_2emap_24s1150457979x1978067071_24dps(V, V);
V g_list_2emap_24s1150457979x1978067071_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1150457979x1978067071_24dps_clo;
V g_list_2emap_24s1258450377x973220636(V);
V g_list_2emap_24s1258450377x973220636_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_clo;
V g_list_2emap_24s1258450377x973220636_24dps(V, V);
V g_list_2emap_24s1258450377x973220636_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_24dps_clo;
V g_list_2emap_24s1276400643x126214923_24dps(V, V);
V g_list_2emap_24s1276400643x126214923_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1276400643x126214923_24dps_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s1281445768x1036802655_24dps(V, V);
V g_list_2emap_24s1281445768x1036802655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_24dps_clo;
V g_list_2emap_24s1310249268x749995235(V, V, V);
V g_list_2emap_24s1310249268x749995235_entry(V self, V *a);
extern Clo g_list_2emap_24s1310249268x749995235_clo;
V g_list_2emap_24s1310249268x749995235_24dps(V, V, V, V);
V g_list_2emap_24s1310249268x749995235_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1310249268x749995235_24dps_clo;
V g_list_2emap_24s1386495485x1391533176(V, V);
V g_list_2emap_24s1386495485x1391533176_entry(V self, V *a);
extern Clo g_list_2emap_24s1386495485x1391533176_clo;
V g_list_2emap_24s1386495485x1391533176_24dps(V, V, V);
V g_list_2emap_24s1386495485x1391533176_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1386495485x1391533176_24dps_clo;
V g_list_2emap_24s152505078x225062837_24dps(V, V);
V g_list_2emap_24s152505078x225062837_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_24dps_clo;
V g_list_2emap_24s1531069132x955165792_24dps(V, V);
V g_list_2emap_24s1531069132x955165792_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1531069132x955165792_24dps_clo;
V g_list_2emap_24s159747708x343809768(V, V, V, V, V, V, V);
V g_list_2emap_24s159747708x343809768_entry(V self, V *a);
extern Clo g_list_2emap_24s159747708x343809768_clo;
V g_list_2emap_24s159747708x343809768_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s159747708x343809768_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s159747708x343809768_24dps_clo;
V g_list_2emap_24s1675313341x192238134_24dps(V, V);
V g_list_2emap_24s1675313341x192238134_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_24dps_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24dps(V, V);
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24dps_clo;
V g_list_2emap_24s1835183789x486277886(V);
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_clo;
V g_list_2emap_24s1835183789x486277886_24dps(V, V);
V g_list_2emap_24s1835183789x486277886_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_24dps_clo;
V g_list_2emap_24s1937570095x2110149801_24dps(V, V);
V g_list_2emap_24s1937570095x2110149801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24dps_clo;
V g_list_2emap_24s2005951263x462916503(V, V, V, V, V, V);
V g_list_2emap_24s2005951263x462916503_entry(V self, V *a);
extern Clo g_list_2emap_24s2005951263x462916503_clo;
V g_list_2emap_24s2005951263x462916503_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s2005951263x462916503_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2005951263x462916503_24dps_clo;
V g_list_2emap_24s2016093283x1174801437(V, V);
V g_list_2emap_24s2016093283x1174801437_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_clo;
V g_list_2emap_24s2016093283x1174801437_24dps(V, V, V);
V g_list_2emap_24s2016093283x1174801437_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_24dps_clo;
V g_list_2emap_24s2051429168x672290949(V);
V g_list_2emap_24s2051429168x672290949_entry(V self, V *a);
extern Clo g_list_2emap_24s2051429168x672290949_clo;
V g_list_2emap_24s2051429168x672290949_24dps(V, V);
V g_list_2emap_24s2051429168x672290949_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2051429168x672290949_24dps_clo;
V g_list_2emap_24s249042484x1701682908_24dps(V, V);
V g_list_2emap_24s249042484x1701682908_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_24dps_clo;
V g_list_2emap_24s471405029x78128406(V);
V g_list_2emap_24s471405029x78128406_entry(V self, V *a);
extern Clo g_list_2emap_24s471405029x78128406_clo;
V g_list_2emap_24s471405029x78128406_24dps(V, V);
V g_list_2emap_24s471405029x78128406_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s471405029x78128406_24dps_clo;
V g_list_2emap_24s502656580x1955732096_24dps(V, V);
V g_list_2emap_24s502656580x1955732096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_24dps_clo;
V g_list_2emap_24s503834852x510769098(V, V);
V g_list_2emap_24s503834852x510769098_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_clo;
V g_list_2emap_24s503834852x510769098_24dps(V, V, V);
V g_list_2emap_24s503834852x510769098_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_24dps_clo;
V g_list_2emap_24s513201124x806973253_24dps(V, V);
V g_list_2emap_24s513201124x806973253_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_24dps_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s60612435x257154841_24dps(V, V);
V g_list_2emap_24s60612435x257154841_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_24dps_clo;
V g_list_2emap_24s640776339x1223679834_24dps(V, V);
V g_list_2emap_24s640776339x1223679834_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_24dps_clo;
V g_list_2emap_24s679881967x35917574(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s679881967x35917574_entry(V self, V *a);
extern Clo g_list_2emap_24s679881967x35917574_clo;
V g_list_2emap_24s679881967x35917574_24dps(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s679881967x35917574_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s679881967x35917574_24dps_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s725725455x1186198702_24dps(V, V);
V g_list_2emap_24s725725455x1186198702_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_24dps_clo;
V g_list_2emap_24s878634257x1677201747(V);
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_clo;
V g_list_2emap_24s878634257x1677201747_24dps(V, V);
V g_list_2emap_24s878634257x1677201747_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_24dps_clo;
V g_list_2emap_24s939813003x1383013550_24dps(V, V);
V g_list_2emap_24s939813003x1383013550_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_24dps_clo;
V g_list_2emap_24s976303750x321235480_24dps(V, V);
V g_list_2emap_24s976303750x321235480_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_24dps_clo;
V g_list_2emerge_24s509014022x1733915733(V, V);
V g_list_2emerge_24s509014022x1733915733_entry(V self, V *a);
extern Clo g_list_2emerge_24s509014022x1733915733_clo;
V g_list_2esortBy_24s1768199906x1695529242(V);
V g_list_2esortBy_24s1768199906x1695529242_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1768199906x1695529242_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24s1877091673x1588480570_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s1877091673x1588480570_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1877091673x1588480570_24dps_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1521533208x253309881(V, V, V);
V g_prelude_2e_2b_2b_24f1521533208x253309881_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1521533208x253309881_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2ecli_2eflagWord(V);
V g_std_2ecli_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagWord_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ehardline_get(void);
Clo g_list_2emap_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_entry, 2, 0};

V g_list_2emap(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24dps(v_f_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_entry(V self, V *a) {
  (void)self;
  return g_list_2emap(a[0], a[1]);
}
Clo g_list_2eany_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_entry, 2, 0};

V g_list_2eany(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efind_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_entry, 2, 0};

V g_list_2efind(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1937570095x2110149801_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1937570095x2110149801_24dps_entry, 2, 0};

V g_list_2emap_24s1937570095x2110149801_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1937570095x2110149801_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1937570095x2110149801_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s716173495x680820632_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s716173495x680820632_24dps_entry, 3, 0};

V g_list_2efilter_24s716173495x680820632_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s716173495x680820632_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s716173495x680820632_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1872971975x1696014049_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1872971975x1696014049_entry, 3, 0};

V g_list_2efoldl_24s1872971975x1696014049(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2etokens_2elineElem(heff_dup(v_lit_240), v_z_241, heff_dup(v_x_243)));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1872971975x1696014049_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1872971975x1696014049(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2eany_24s689038521x519269801_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s689038521x519269801_entry, 1, 0};

V g_list_2eany_24s689038521x519269801(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkSegment: {
        V v_ty_246 = heff_field(v_x11_243, 1);
        switch (heff_tag_of(v_ty_246)) {
        case TAG_SegmentInteger: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        case TAG_SegmentBinary: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        case TAG_SegmentBits: {
          v_t_2411 = NTAG(TAG_True);
          break;
        }
        case TAG_SegmentFloat: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        case TAG_SegmentUtf: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_ty_246);
        }
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2411);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s689038521x519269801_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s689038521x519269801(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s2016093283x1174801437_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2016093283x1174801437_entry, 2, 0};

V g_list_2emap_24s2016093283x1174801437(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2efieldDeclOf(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s2016093283x1174801437_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2016093283x1174801437_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2016093283x1174801437(a[0], a[1]);
}
Clo g_list_2emap_24s1036840854x702708481_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1036840854x702708481_24dps_entry, 3, 0};

V g_list_2emap_24s1036840854x702708481_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2eequationOf(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1036840854x702708481_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1036840854x702708481_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1258450377x973220636_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1258450377x973220636_entry, 1, 0};

V g_list_2emap_24s1258450377x973220636(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1258450377x973220636_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1258450377x973220636_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1258450377x973220636(a[0]);
}
Clo g_list_2emap_24s1276400643x126214923_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1276400643x126214923_24dps_entry, 2, 0};

V g_list_2emap_24s1276400643x126214923_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1276400643x126214923_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1276400643x126214923_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2051429168x672290949_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2051429168x672290949_entry, 1, 0};

V g_list_2emap_24s2051429168x672290949(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2051429168x672290949_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2051429168x672290949_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2051429168x672290949(a[0]);
}
Clo g_list_2emap_24s1150457979x1978067071_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1150457979x1978067071_entry, 1, 0};

V g_list_2emap_24s1150457979x1978067071(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_ArgExplicit: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24ArgExplicit = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_a_245)) {
        case TAG_At: {
          V v_a_246 = heff_field(v_a_245, 0);
          V v_a_247 = heff_field(v_a_245, 1);
          heff_take_n(v_a_245, 3ULL, 2);
          V v_t_248 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_246));
          v_t_249 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_248, v_a_247});
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_249});
        break;
      }
      case TAG_ArgProject: {
        V v_a_2410 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24ArgProject = heff_take_reuse_n(v_a_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ArgProject, TAG_ArgProject, 1, (V[]){v_a_2410});
        break;
      }
      case TAG_ArgNamed: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_a_2412 = heff_field(v_a_243, 1);
        V v_ru_24a_243_24ArgNamed = heff_take_reuse_n(v_a_243, 3ULL, 2);
        V v_t_2416;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2413));
          v_t_2416 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2415, v_a_2414});
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ArgNamed, TAG_ArgNamed, 2, (V[]){v_a_2411, v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = (g_list_2emap_24s1150457979x1978067071_24dps(v_xs_242, heff_dup(v_cell_2419)));
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1150457979x1978067071_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1150457979x1978067071(a[0]);
}
Clo g_list_2emap_24s249042484x1701682908_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s249042484x1701682908_24dps_entry, 2, 0};

V g_list_2emap_24s249042484x1701682908_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2416;
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24SetField = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_2410, v_a_249));
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24a_244_24SetField, TAG_SetField, 3, (V[]){v_a_246, v_a_247, v_t_2411});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2412 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24BadFieldSet = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_2414, v_a_2413));
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24a_244_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2415});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2416, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2418));
    heff_drop(v_u_2419);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2418;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s249042484x1701682908_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s249042484x1701682908_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s878634257x1677201747_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s878634257x1677201747_entry, 1, 0};

V g_list_2emap_24s878634257x1677201747(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2esyntax_2esurface_2eidentOf(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s878634257x1677201747_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s878634257x1677201747(a[0]);
}
Clo g_list_2emap_24s513201124x806973253_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513201124x806973253_24dps_entry, 2, 0};

V g_list_2emap_24s513201124x806973253_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_EProject, 1, (V[]){heff_take_field(v_x_242, 1)});
    V v_t_245 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_242, 3), heff_get_n(v_x_242, 4, 9)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_t_245}), heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513201124x806973253_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513201124x806973253_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1368043225x413679696_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1368043225x413679696_entry, 3, 0};

V g_list_2efoldl_24s1368043225x413679696(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_SetField: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_249 = heff_field(v_a_245, 2);
        heff_take_n(v_a_245, 5ULL, 3);
        V v_t_2412;
        switch (heff_tag_of(v_z_241)) {
        case TAG_At: {
          V v_a_2411 = heff_dup(heff_field(v_z_241, 1));
          v_t_2412 = v_a_2411;
          break;
        }
        default: heff_nomatch(v_z_241);
        }
        V v_t_2413 = ({ V rv_1 = heff_dup(heff_rfield(v_a_246, 1)); V rr_ = heff_rec_reuse_nf(v_t_2412, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_ESpec, 4, (V[]){v_z_241, v_a_247, v_a_246, v_a_249}), v_t_2413});
        break;
      }
      case TAG_BadFieldSet: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_z_241);
        v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(v_lit_240)}), v_a_246});
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2415;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1368043225x413679696_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1368043225x413679696(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s60612435x257154841_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s60612435x257154841_entry, 1, 0};

V g_list_2emap_24s60612435x257154841(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_b_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 4ULL, 3);
      v_t_246 = v_b_245;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s60612435x257154841_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s60612435x257154841_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s60612435x257154841(a[0]);
}
Clo g_list_2efoldl_24s1048046132x95752937_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1048046132x95752937_entry, 2, 0};

V g_list_2efoldl_24s1048046132x95752937(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2espec_2ebindOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1048046132x95752937(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1809017761x1063871171_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1809017761x1063871171_entry, 1, 0};

V g_list_2emap_24s1809017761x1063871171(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1809017761x1063871171_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1809017761x1063871171(a[0]);
}
Clo g_list_2emap_24s1531069132x955165792_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1531069132x955165792_24dps_entry, 2, 0};

V g_list_2emap_24s1531069132x955165792_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1531069132x955165792_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1531069132x955165792_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s419339443x1702462498_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s419339443x1702462498_entry, 2, 0};

V g_list_2efoldl_24s419339443x1702462498(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2ecanonVisit(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s419339443x1702462498_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s419339443x1702462498(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1310249268x749995235_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1310249268x749995235_entry, 3, 0};

V g_list_2emap_24s1310249268x749995235(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2erepr_2edecidedIn(v_lit_240, v_lit_241, v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1310249268x749995235_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1310249268x749995235_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2emap_24s1310249268x749995235(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1915639815x253536901_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1915639815x253536901_entry, 2, 0};

V g_list_2efoldl_24s1915639815x253536901(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2earity_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1915639815x253536901_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1915639815x253536901(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1523549873x2075662238_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1523549873x2075662238_entry, 2, 0};

V g_list_2eany_24s1523549873x2075662238(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_247 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1523549873x2075662238_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1523549873x2075662238(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s455728131x407835966_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s455728131x407835966_entry, 2, 0};

V g_list_2efoldl_24s455728131x407835966(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_z_240)) {
    case TAG_Nothing: {
      v_t_246 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_a_244 = heff_field(v_z_240, 0);
      V v_ru_24z_240_24Just = heff_take_reuse_n(v_z_240, 1ULL, 1);
      switch (heff_tag_of(v_x_242)) {
      case TAG_Nothing: {
        heff_drop(v_a_244);
        heff_drop_cell(v_ru_24z_240_24Just, 1);
        v_t_246 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_b_245 = heff_field(v_x_242, 0);
        v_t_246 = heff_tag_at_n(v_ru_24z_240_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_244, heff_dup(v_b_245))});
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s455728131x407835966_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s455728131x407835966(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1375915522x445000623_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1375915522x445000623_entry, 1, 0};

V g_list_2eany_24s1375915522x445000623(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Nothing: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_a_243 = heff_field(v_x_241, 0);
      if ((heff_dup(v_a_243) == NTAG(TAG_True))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1375915522x445000623_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1375915522x445000623(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1203202837x1639358108_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1203202837x1639358108_entry, 2, 0};

V g_list_2efoldl_24s1203202837x1639358108(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_x_242}), v_z_240});
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1203202837x1639358108(a[0], a[1]);
}
Clo g_list_2emap_24s471405029x78128406_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s471405029x78128406_entry, 1, 0};

V g_list_2emap_24s471405029x78128406(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 7ULL, 3);
      v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_a_244}), heff_tag_n(TAG_ASts, 1, (V[]){v_a_245})});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s471405029x78128406_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s471405029x78128406_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s471405029x78128406(a[0]);
}
Clo g_list_2emap_24s471405029x78128406_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s471405029x78128406_24dps_entry, 2, 0};

V g_list_2emap_24s471405029x78128406_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_245}), heff_tag_n(TAG_ASts, 1, (V[]){v_a_246})});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s471405029x78128406_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s471405029x78128406_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s976303750x321235480_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s976303750x321235480_24dps_entry, 2, 0};

V g_list_2emap_24s976303750x321235480_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Given: {
      V v_e_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = v_e_244;
      break;
    }
    case TAG_GivenU: {
      V v_e_246 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_2410 = v_e_246;
      break;
    }
    case TAG_LentVar: {
      V v_x_247 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2410 = heff_tag_n(TAG_RLocal, 1, (V[]){v_x_247});
      break;
    }
    case TAG_LentValue: {
      V v_e_249 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = v_e_249;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s976303750x321235480_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s976303750x321235480_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1835183789x486277886_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1835183789x486277886_entry, 1, 0};

V g_list_2emap_24s1835183789x486277886(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1835183789x486277886_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1835183789x486277886(a[0]);
}
Clo g_list_2efoldl_24s1577366920x1019062938_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1577366920x1019062938_entry, 2, 0};

V g_list_2efoldl_24s1577366920x1019062938(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_x_242, 4)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1577366920x1019062938_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1577366920x1019062938(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s679881967x35917574_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s679881967x35917574_entry, 10, 0};

V g_list_2emap_24s679881967x35917574(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_x2_249) {
top: ;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24Cons = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_a_2412 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_x_2410), heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_x_2410, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_a_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_2412));
    V v_a_2416;
    switch (heff_tag_of(v_a_2413)) {
    case TAG_Nil: {
      v_a_2416 = v_x_2410;
      break;
    }
    case TAG_Cons: {
      V v_a_2414 = heff_field(v_a_2413, 0);
      heff_take_n(v_a_2413, 1ULL, 2);
      heff_drop(v_x_2410);
      v_a_2416 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_a_2413);
    }
    V v_t_2417 = heff_intSub(heff_strLength_lent(v_a_2416, 0), heff_dup(v_lit_244));
    V v_t_2418 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_a_2416), v_t_2417));
    V v_t_2419 = ({ V a_0 = v_a_2416; V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_a_2420 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_2419, heff_dup(v_lit_245), heff_dup(v_lit_246)));
    V v_t_2422;
    if (heff_strEq_c_lent(v_a_2420, v_lit_247, 0)) {
      heff_drop(v_a_2420);
      v_t_2422 = heff_dup(v_lit_248);
    } else {
      v_t_2422 = v_a_2420;
    }
    V v_t_2423 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_2422));
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_249_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = (g_list_2emap_24s679881967x35917574_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_xs_2411, heff_dup(v_cell_2424)));
    heff_drop(v_u_2425);
    return v_cell_2424;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_list_2emap_24s679881967x35917574_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s679881967x35917574(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2emap_24s152505078x225062837_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s152505078x225062837_24dps_entry, 2, 0};

V g_list_2emap_24s152505078x225062837_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s152505078x225062837_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s152505078x225062837_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s640776339x1223679834_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s640776339x1223679834_24dps_entry, 2, 0};

V g_list_2emap_24s640776339x1223679834_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s640776339x1223679834_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s640776339x1223679834_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1877091673x1588480570_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1877091673x1588480570_24dps_entry, 6, 0};

V g_list_2ezipWith_24s1877091673x1588480570_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_xs_243, V v_ys_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_xs_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_ys_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_xs_243, 0);
    V v_xs2_247 = heff_field(v_xs_243, 1);
    V v_ru_24xs_243_24Cons = heff_take_reuse_n(v_xs_243, 3ULL, 2);
    switch (heff_tag_of(v_ys_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_246);
      heff_drop(v_xs2_247);
      heff_drop_cell(v_ru_24xs_243_24Cons, 2);
      return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_248 = heff_field(v_ys_244, 0);
      V v_ys2_249 = heff_field(v_ys_244, 1);
      heff_take_n(v_ys_244, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_x_246)) {
      case TAG_MkPair: {
        V v_a_2410 = heff_dup(heff_field(v_x_246, 0));
        v_t_2412 = v_a_2410;
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      V v_t_2415;
      switch (heff_tag_of(v_x_246)) {
      case TAG_MkPair: {
        V v_a_2414 = heff_field(v_x_246, 1);
        heff_take_n(v_x_246, 2ULL, 2);
        v_t_2415 = v_a_2414;
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      V v_t_2416 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2415, heff_dup(v_lit_242)));
      V v_t_2417 = heff_strAppend(heff_intShow(v_y_248), v_t_2416);
      V v_t_2418 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_240), v_t_2417));
      V v_cell_2419 = heff_tag_at_n(v_ru_24xs_243_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
      V v_u_2420 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2419));
      heff_drop(v_u_2420);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs2_247;
      V t_4 = v_ys2_249;
      V t_5 = v_cell_2419;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_xs_243 = t_3;
      v_ys_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_ys_244);
    }
  }
  default: return heff_nomatch(v_xs_243);
  }
}
V g_list_2ezipWith_24s1877091673x1588480570_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1877091673x1588480570_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2efoldl_24s776002836x391891384_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s776002836x391891384_entry, 2, 0};

V g_list_2efoldl_24s776002836x391891384(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b_24f1521533208x253309881(v_z_240, heff_dup(v_x_242), heff_dup(g_heff_2esyntax_2eimport_2eimplicitImports_get())));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s776002836x391891384_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s776002836x391891384(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s503834852x510769098_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s503834852x510769098_entry, 2, 0};

V g_list_2emap_24s503834852x510769098(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_x_242; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_244), heff_hole()});
    V v_u_246 = (g_list_2emap_24s503834852x510769098_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s503834852x510769098_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s503834852x510769098(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s502656580x1955732096_24dps_str0, 1, "_");
Clo g_list_2emap_24s502656580x1955732096_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s502656580x1955732096_24dps_entry, 2, 0};

V g_list_2emap_24s502656580x1955732096_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(v_x_242, 0, 5);
    V v_t_2425;
    switch (heff_tag_of(v_t_244)) {
    case TAG_At: {
      V v_x11_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 2);
      switch (heff_tag_of(v_x11_245)) {
      case TAG_PatVar: {
        V v_x_247 = heff_field(v_x11_245, 0);
        V v_ru_24x11_245_24PatVar = heff_take_reuse_n(v_x11_245, 1ULL, 1);
        if (heff_strEq_c_lent(v_x_247, ((V)&g_list_2emap_24s502656580x1955732096_24dps_str0), 2)) {
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x11_245_24PatVar, 1);
          v_t_2425 = NTAG(TAG_Nothing);
        } else {
          v_t_2425 = heff_tag_at_n(v_ru_24x11_245_24PatVar, TAG_Just, 1, (V[]){v_x_247});
        }
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_245, 0ULL, 3);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_245, 0ULL, 3);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_na(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_245, 0ULL, 3);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_245);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_cell_2426 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
    V v_u_2427 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2426));
    heff_drop(v_u_2427);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2426;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s502656580x1955732096_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s502656580x1955732096_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s939813003x1383013550_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s939813003x1383013550_24dps_entry, 2, 0};

V g_list_2emap_24s939813003x1383013550_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(v_x_242, 2, 5);
    V v_t_249;
    switch (heff_tag_of(v_t_244)) {
    case TAG_SizeDefault: {
      v_t_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeNumber: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeName: {
      V v_x_246 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 3);
      v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s939813003x1383013550_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s939813003x1383013550_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1386495485x1391533176_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1386495485x1391533176_entry, 2, 0};

V g_list_2emap_24s1386495485x1391533176(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2eelab_2eclauses_2erenameAlt(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1386495485x1391533176_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1386495485x1391533176_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1386495485x1391533176(a[0], a[1]);
}
Clo g_list_2efoldl_24s1991317015x801331450_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1991317015x801331450_entry, 2, 0};

V g_list_2efoldl_24s1991317015x801331450(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_a_247), NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1991317015x801331450_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1991317015x801331450(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s159747708x343809768_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s159747708x343809768_entry, 7, 0};

V g_list_2emap_24s159747708x343809768(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_a_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_a_2412 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_a_2411), heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_a_2411, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_t_2417;
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2411, heff_dup(v_lit_244)});
      break;
    }
    case TAG_Cons: {
      V v_a_2413 = heff_field(v_a_2412, 0);
      V v_a_2414 = heff_field(v_a_2412, 1);
      V v_ru_24a_2412_24Cons = heff_take_reuse_n(v_a_2412, 3ULL, 2);
      switch (heff_tag_of(v_a_2414)) {
      case TAG_Nil: {
        heff_drop(v_a_2413);
        v_t_2417 = heff_tag_at_n(v_ru_24a_2412_24Cons, TAG_MkPair, 2, (V[]){v_a_2411, heff_dup(v_lit_245)});
        break;
      }
      case TAG_Cons: {
        V v_a_2415 = heff_field(v_a_2414, 0);
        heff_take_n(v_a_2414, 1ULL, 2);
        heff_drop(v_a_2411);
        v_t_2417 = heff_tag_at_n(v_ru_24a_2412_24Cons, TAG_MkPair, 2, (V[]){v_a_2413, v_a_2415});
        break;
      }
      default: heff_nomatch(v_a_2414);
      }
      break;
    }
    default: heff_nomatch(v_a_2412);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = (g_list_2emap_24s159747708x343809768_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s159747708x343809768_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s159747708x343809768(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_list_2eany_24s577543654x765608923_str0, 12, "-- fmt: skip");
Clo g_list_2eany_24s577543654x765608923_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s577543654x765608923_entry, 1, 0};

V g_list_2eany_24s577543654x765608923(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_s_243 = heff_dup(heff_rfield(v_x_241, 0));
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(heff_dup(v_s_243), heff_strLength_lent(v_s_243, 0)));
    if (heff_strEq_c(heff_strSlice(v_s_243, MK_INT(0LL), v_t_244), ((V)&g_list_2eany_24s577543654x765608923_str0))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s577543654x765608923_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s577543654x765608923(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s725725455x1186198702_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s725725455x1186198702_entry, 1, 0};

V g_list_2emap_24s725725455x1186198702(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(heff_dup(v_x_241), heff_strLength_lent(v_x_241, 0)));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_x_241, MK_INT(0LL), v_t_243), heff_hole()});
    V v_u_245 = (g_list_2emap_24s725725455x1186198702_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s725725455x1186198702(a[0]);
}
Clo g_list_2esortBy_24s1768199906x1695529242_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1768199906x1695529242_entry, 1, 0};

V g_list_2esortBy_24s1768199906x1695529242(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s1768199906x1695529242(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s1768199906x1695529242(v_t_249));
      return (g_list_2emerge_24s509014022x1733915733(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1768199906x1695529242_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1768199906x1695529242(a[0]);
}
Clo g_list_2emap_24s1675313341x192238134_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1675313341x192238134_24dps_entry, 2, 0};

V g_list_2emap_24s1675313341x192238134_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_MkEquation: {
        V v_fsp_247 = heff_field(v_x11_244, 1);
        heff_take_n(v_x11_244, 2ULL, 4);
        v_t_2410 = v_fsp_247;
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1675313341x192238134_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1675313341x192238134_24dps(a[0], a[1]);
}
Clo g_list_2efind_24s1085725546x1737150855_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1085725546x1737150855_entry, 2, 0};

V g_list_2efind_24s1085725546x1737150855(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 2));
    if (heff_intLe_c(heff_dup(heff_rfield(v_a_244, 0)), heff_dup(v_lit_240))) {
      if (heff_intLe_c(heff_dup(v_lit_240), heff_get_n(v_a_244, 1, 2))) {
        heff_drop(v_lit_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_a_244, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1085725546x1737150855_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s1085725546x1737150855(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s496727651x1448898893_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s496727651x1448898893_entry, 2, 0};

V g_list_2efoldl_24s496727651x1448898893(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkEquation: {
        V v_a_249 = heff_field(v_a_244, 3);
        v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_249));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s496727651x1448898893(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1490692278x809324339_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1490692278x809324339_entry, 1, 0};

V g_list_2efilter_24s1490692278x809324339(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_241, 10);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2efilter_24s1490692278x809324339_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1490692278x809324339_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1490692278x809324339(a[0]);
}
Clo g_list_2emap_24s2005951263x462916503_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2005951263x462916503_entry, 6, 0};

V g_list_2emap_24s2005951263x462916503(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_246, 0));
      v_t_2410 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_t_2411 = (g_heff_2eutil_2ejson_2eescapeGo(v_t_2410, heff_dup(v_lit_241), heff_dup(v_lit_242)));
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
    V v_t_2415;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_246, 1);
      heff_take_n(v_x_246, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), v_t_2416));
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = (g_list_2emap_24s2005951263x462916503_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s2005951263x462916503_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2005951263x462916503(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2efilter_24s951260806x709953240_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s951260806x709953240_24dps_entry, 3, 0};

V g_list_2efilter_24s951260806x709953240_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2410;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_lit_240, 0);
      v_t_2410 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    if (heff_strEq_c(v_t_247, v_t_2410)) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_2412;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s951260806x709953240_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efilter_24s951260806x709953240_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1281445768x1036802655_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1281445768x1036802655_entry, 1, 0};

V g_list_2emap_24s1281445768x1036802655(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagWord(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1281445768x1036802655_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1281445768x1036802655(a[0]);
}
Clo g_list_2efoldl_24f421425463x1941958307_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f421425463x1941958307_entry, 3, 0};

V g_list_2efoldl_24f421425463x1941958307(V v_z_240, V v_p_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_z_240});
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_z_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f421425463x1941958307_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f421425463x1941958307(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f1134152647x940271785_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1134152647x940271785_entry, 2, 0};

V g_list_2efoldl_24f1134152647x940271785(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(heff_dup(heff_rfield(v_x_242, 0))));
    V v_x_245 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_244));
    V v_t_246 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_245));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f1134152647x940271785(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f1559904364x1248618624_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1559904364x1248618624_entry, 3, 0};

V g_list_2efoldl_24f1559904364x1248618624(V v_z_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_x_243)}));
    V v_t_246 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_245));
    V t_0 = v_t_246;
    V t_1 = v_f_241;
    V t_2 = v_xs_244;
    v_z_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1559904364x1248618624(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f768999161x1997188166_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f768999161x1997188166_24dps_entry, 4, 0};

V g_list_2emap_24f768999161x1997188166_24dps(V v_lit_240, V v_i_241, V v_n_242, V v_d_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_242), heff_dup(v_i_241))) {
    heff_drop(v_lit_240);
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strByteAt_lent(v_lit_240, v_i_241, 0), heff_hole()});
    V v_u_246 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_n_242;
    V t_3 = v_cell_245;
    v_lit_240 = t_0;
    v_i_241 = t_1;
    v_n_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f768999161x1997188166_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f768999161x1997188166_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps_entry, 5, 0};

V g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_take_field(v_x_245, 2);
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_x_248 = heff_get_n(v_x_245, 0, 4);
      V v_t_249 = heff_strSlice(heff_dup(v_x_248), heff_dup(v_lit_241), heff_strLength_lent(v_lit_242, 0));
      if (heff_strEq_c_lent(v_t_249, v_lit_242, 1)) {
        V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_248, heff_dup(v_lit_240)), heff_hole()});
        V v_u_2412 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2411));
        heff_drop(v_u_2412);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_cell_2411;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        v_d_244 = t_4;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        heff_drop(v_x_248);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_d_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_245, 4);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps(a[0], a[1], a[2], a[3], a[4]);
}