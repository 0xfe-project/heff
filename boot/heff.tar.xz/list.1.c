// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ArgEvidence 24309
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CDecl 45531
#define TAG_EInvalid 31081
#define TAG_EProject 35489
#define TAG_ESpec 56652
#define TAG_EVar 52881
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_IVal 40987
#define TAG_Left 13886
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_Mixed 48213
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_MkEquation 38417
#define TAG_MkRegex 19093
#define TAG_MkSegment 38079
#define TAG_NoRecord 51797
#define TAG_OutCall 43778
#define TAG_OutOther 27005
#define TAG_OutRecord 63915
#define TAG_OutTag 45229
#define TAG_PassedOther 52780
#define TAG_PassedRecord 11102
#define TAG_PassedSame 49925
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Positional 16703
#define TAG_RLocal 34280
#define TAG_Records 39950
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SWarning 44190
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_Typed 36072
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_arg 306384
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_doc 309170
#define LBL_end 310101
#define LBL_filter 672649891
#define LBL_input 301716452
#define LBL_key 315609
#define LBL_library 398066429
#define LBL_local 304503685
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_part 9928890
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_refs 9991943
#define LBL_severity 75955546
#define LBL_shape 310758331
#define LBL_shown 310772011
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_value 313331083
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
static uint32_t shape_name__doc__shape[] = {LBL_name, LBL_doc, LBL_shape};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_part__input[] = {LBL_part, LBL_input};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
V g_heff_2ebuild_2ecommands_2ejsonGolden(V);
V g_heff_2ebuild_2ecommands_2ejsonGolden_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsonGolden_clo;
V g_heff_2ebuild_2ecommands_2eplaceBefore(V, V);
V g_heff_2ebuild_2ecommands_2eplaceBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceBefore_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2earity_2earityOne(V, V);
V g_heff_2ecompile_2earity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earity_2earityOne_clo;
V g_heff_2ecompile_2eemitc_2etupleRead(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etupleRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleRead_clo;
HeffT2 g_heff_2ecompile_2efuse_2econsumerOf_24cpr(V, V);
V g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603(V);
V g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eranges_2erangeEq(V, V);
V g_heff_2ecompile_2eranges_2erangeEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangeEq_clo;
V g_heff_2ecompile_2eranges_2ewordPrims_get(void);
V g_heff_2ecompile_2erepr_2edecidedIn(V, V, V);
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecidedIn_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
V g_heff_2ecompile_2escalars_2esameLabels(V, V);
V g_heff_2ecompile_2escalars_2esameLabels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2esameLabels_clo;
V g_heff_2ecompile_2esimplify_2ecanonVisit(V, V);
V g_heff_2ecompile_2esimplify_2ecanonVisit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecanonVisit_clo;
V g_heff_2ecompile_2espec_2ebindOne(V, V);
V g_heff_2ecompile_2espec_2ebindOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ebindOne_clo;
V g_heff_2ecompile_2eunbox_2eslotFor(V, V, V);
V g_heff_2ecompile_2eunbox_2eslotFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eslotFor_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2erenameAlt(V, V);
V g_heff_2eelab_2eclauses_2erenameAlt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameAlt_clo;
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2efmt_2etokens_2elineElem(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2elineElem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2elineElem_clo;
V g_heff_2esyntax_2epresyntax_2earmOn(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2earmOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmOn_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf(V, V);
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902(V);
V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(V);
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_clo;
V g_heff_2esyntax_2esurface_2eidentOf(V);
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eidentOf_clo;
V g_json_2eescapeGo(V, V, V);
V g_json_2eescapeGo_entry(V self, V *a);
extern Clo g_json_2eescapeGo_clo;
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s130813166x1111413304(V, V);
V g_list_2eany_24s130813166x1111413304_entry(V self, V *a);
extern Clo g_list_2eany_24s130813166x1111413304_clo;
V g_list_2eany_24s1375915522x445000623(V);
V g_list_2eany_24s1375915522x445000623_entry(V self, V *a);
extern Clo g_list_2eany_24s1375915522x445000623_clo;
V g_list_2eany_24s1598387467x1906338007(V);
V g_list_2eany_24s1598387467x1906338007_entry(V self, V *a);
extern Clo g_list_2eany_24s1598387467x1906338007_clo;
V g_list_2eany_24s1631644720x1952242925(V, V);
V g_list_2eany_24s1631644720x1952242925_entry(V self, V *a);
extern Clo g_list_2eany_24s1631644720x1952242925_clo;
V g_list_2eany_24s332132496x946063656(V, V);
V g_list_2eany_24s332132496x946063656_entry(V self, V *a);
extern Clo g_list_2eany_24s332132496x946063656_clo;
V g_list_2eany_24s469347062x492258493(V);
V g_list_2eany_24s469347062x492258493_entry(V self, V *a);
extern Clo g_list_2eany_24s469347062x492258493_clo;
V g_list_2eany_24s577543654x765608923(V);
V g_list_2eany_24s577543654x765608923_entry(V self, V *a);
extern Clo g_list_2eany_24s577543654x765608923_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1428393365x1980555854(V, V, V);
V g_list_2efoldl_24f1428393365x1980555854_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1428393365x1980555854_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24f2094160282x1876485468(V, V, V);
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2094160282x1876485468_clo;
V g_list_2efoldl_24f354261656x2102112793(V, V, V, V, V);
V g_list_2efoldl_24f354261656x2102112793_entry(V self, V *a);
extern Clo g_list_2efoldl_24f354261656x2102112793_clo;
V g_list_2efoldl_24f96115456x1460340526(V, V, V);
V g_list_2efoldl_24f96115456x1460340526_entry(V self, V *a);
extern Clo g_list_2efoldl_24f96115456x1460340526_clo;
V g_list_2efoldl_24s1048046132x95752937(V, V);
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1048046132x95752937_clo;
V g_list_2efoldl_24s114050048x1903860601(V, V);
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a);
extern Clo g_list_2efoldl_24s114050048x1903860601_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1368043225x413679696(V, V, V);
V g_list_2efoldl_24s1368043225x413679696_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1368043225x413679696_clo;
V g_list_2efoldl_24s1872971975x1696014049(V, V, V);
V g_list_2efoldl_24s1872971975x1696014049_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1872971975x1696014049_clo;
V g_list_2efoldl_24s1879887278x1868824044(V, V);
V g_list_2efoldl_24s1879887278x1868824044_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1879887278x1868824044_clo;
V g_list_2efoldl_24s1915639815x253536901(V, V);
V g_list_2efoldl_24s1915639815x253536901_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1915639815x253536901_clo;
V g_list_2efoldl_24s1980014771x775787011(V, V);
V g_list_2efoldl_24s1980014771x775787011_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1980014771x775787011_clo;
V g_list_2efoldl_24s1991317015x801331450(V, V);
V g_list_2efoldl_24s1991317015x801331450_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1991317015x801331450_clo;
V g_list_2efoldl_24s213448614x618797387(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s213448614x618797387_entry(V self, V *a);
extern Clo g_list_2efoldl_24s213448614x618797387_clo;
V g_list_2efoldl_24s419339443x1702462498(V, V);
V g_list_2efoldl_24s419339443x1702462498_entry(V self, V *a);
extern Clo g_list_2efoldl_24s419339443x1702462498_clo;
V g_list_2efoldl_24s455728131x407835966(V, V);
V g_list_2efoldl_24s455728131x407835966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s455728131x407835966_clo;
V g_list_2efoldl_24s496727651x1448898893(V, V);
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a);
extern Clo g_list_2efoldl_24s496727651x1448898893_clo;
V g_list_2efoldl_24s578974906x2018699728(V, V);
V g_list_2efoldl_24s578974906x2018699728_entry(V self, V *a);
extern Clo g_list_2efoldl_24s578974906x2018699728_clo;
V g_list_2efoldl_24s62513826x839087377(V, V);
V g_list_2efoldl_24s62513826x839087377_entry(V self, V *a);
extern Clo g_list_2efoldl_24s62513826x839087377_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s723147058x1136115564(V, V);
V g_list_2efoldl_24s723147058x1136115564_entry(V self, V *a);
extern Clo g_list_2efoldl_24s723147058x1136115564_clo;
V g_list_2efoldl_24s782566794x1684170422(V, V);
V g_list_2efoldl_24s782566794x1684170422_entry(V self, V *a);
extern Clo g_list_2efoldl_24s782566794x1684170422_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_list_2ekeepIf_24s1161549307x1906011635_24dps(V, V);
V g_list_2ekeepIf_24s1161549307x1906011635_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_24dps_clo;
V g_list_2ekeepIf_24s1245654234x191876439_24dps(V, V);
V g_list_2ekeepIf_24s1245654234x191876439_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1245654234x191876439_24dps_clo;
V g_list_2ekeepIf_24s1252894891x837498180_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s1252894891x837498180_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1252894891x837498180_24dps_clo;
V g_list_2ekeepIf_24s1823913665x1128491553_24dps(V, V, V);
V g_list_2ekeepIf_24s1823913665x1128491553_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1823913665x1128491553_24dps_clo;
V g_list_2ekeepIf_24s425280038x249084439(V, V, V);
V g_list_2ekeepIf_24s425280038x249084439_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s425280038x249084439_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24dps(V, V, V);
V g_list_2emap_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24dps_clo;
V g_list_2emap_24f1893878025x389241368_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24f1893878025x389241368_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1893878025x389241368_24dps_clo;
V g_list_2emap_24f201346761x152404242_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24f201346761x152404242_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f201346761x152404242_24dps_clo;
V g_list_2emap_24f2124896334x71745266(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f2124896334x71745266_entry(V self, V *a);
extern Clo g_list_2emap_24f2124896334x71745266_clo;
V g_list_2emap_24f2124896334x71745266_24dps(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f2124896334x71745266_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2124896334x71745266_24dps_clo;
V g_list_2emap_24f310588246x1624488069(V, V, V, V);
V g_list_2emap_24f310588246x1624488069_entry(V self, V *a);
extern Clo g_list_2emap_24f310588246x1624488069_clo;
V g_list_2emap_24f310588246x1624488069_24dps(V, V, V, V, V);
V g_list_2emap_24f310588246x1624488069_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f310588246x1624488069_24dps_clo;
V g_list_2emap_24f768999161x1997188166_24dps(V, V, V, V);
V g_list_2emap_24f768999161x1997188166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f768999161x1997188166_24dps_clo;
V g_list_2emap_24s1007499915x73800978_24dps(V, V);
V g_list_2emap_24s1007499915x73800978_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_24dps_clo;
V g_list_2emap_24s1036840854x702708481_24dps(V, V, V);
V g_list_2emap_24s1036840854x702708481_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_24dps_clo;
V g_list_2emap_24s1258450377x973220636(V);
V g_list_2emap_24s1258450377x973220636_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_clo;
V g_list_2emap_24s1258450377x973220636_24dps(V, V);
V g_list_2emap_24s1258450377x973220636_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_24dps_clo;
V g_list_2emap_24s126994153x1029399760_24dps(V, V);
V g_list_2emap_24s126994153x1029399760_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s126994153x1029399760_24dps_clo;
V g_list_2emap_24s1276400643x126214923_24dps(V, V);
V g_list_2emap_24s1276400643x126214923_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1276400643x126214923_24dps_clo;
V g_list_2emap_24s1276696116x507290452_24dps(V, V, V);
V g_list_2emap_24s1276696116x507290452_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1276696116x507290452_24dps_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s1281445768x1036802655_24dps(V, V);
V g_list_2emap_24s1281445768x1036802655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_24dps_clo;
V g_list_2emap_24s1310249268x749995235(V, V, V);
V g_list_2emap_24s1310249268x749995235_entry(V self, V *a);
extern Clo g_list_2emap_24s1310249268x749995235_clo;
V g_list_2emap_24s1310249268x749995235_24dps(V, V, V, V);
V g_list_2emap_24s1310249268x749995235_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1310249268x749995235_24dps_clo;
V g_list_2emap_24s1386495485x1391533176(V, V);
V g_list_2emap_24s1386495485x1391533176_entry(V self, V *a);
extern Clo g_list_2emap_24s1386495485x1391533176_clo;
V g_list_2emap_24s1386495485x1391533176_24dps(V, V, V);
V g_list_2emap_24s1386495485x1391533176_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1386495485x1391533176_24dps_clo;
V g_list_2emap_24s1418269708x2034621695_24dps(V, V, V);
V g_list_2emap_24s1418269708x2034621695_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1418269708x2034621695_24dps_clo;
V g_list_2emap_24s146946949x1862800301_24dps(V, V);
V g_list_2emap_24s146946949x1862800301_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s146946949x1862800301_24dps_clo;
V g_list_2emap_24s1478286876x830244177(V);
V g_list_2emap_24s1478286876x830244177_entry(V self, V *a);
extern Clo g_list_2emap_24s1478286876x830244177_clo;
V g_list_2emap_24s1478286876x830244177_24dps(V, V);
V g_list_2emap_24s1478286876x830244177_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1478286876x830244177_24dps_clo;
V g_list_2emap_24s1520235531x215612111(V, V, V, V, V);
V g_list_2emap_24s1520235531x215612111_entry(V self, V *a);
extern Clo g_list_2emap_24s1520235531x215612111_clo;
V g_list_2emap_24s1520235531x215612111_24dps(V, V, V, V, V, V);
V g_list_2emap_24s1520235531x215612111_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1520235531x215612111_24dps_clo;
V g_list_2emap_24s152505078x225062837_24dps(V, V);
V g_list_2emap_24s152505078x225062837_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_24dps_clo;
V g_list_2emap_24s1531069132x955165792_24dps(V, V);
V g_list_2emap_24s1531069132x955165792_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1531069132x955165792_24dps_clo;
V g_list_2emap_24s1531382666x123921537_24dps(V, V);
V g_list_2emap_24s1531382666x123921537_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1531382666x123921537_24dps_clo;
V g_list_2emap_24s1539380703x380520933_24dps(V, V);
V g_list_2emap_24s1539380703x380520933_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1539380703x380520933_24dps_clo;
V g_list_2emap_24s159747708x343809768(V, V, V, V, V, V, V);
V g_list_2emap_24s159747708x343809768_entry(V self, V *a);
extern Clo g_list_2emap_24s159747708x343809768_clo;
V g_list_2emap_24s159747708x343809768_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s159747708x343809768_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s159747708x343809768_24dps_clo;
V g_list_2emap_24s1675313341x192238134_24dps(V, V);
V g_list_2emap_24s1675313341x192238134_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_24dps_clo;
V g_list_2emap_24s1727184187x1048417382(V);
V g_list_2emap_24s1727184187x1048417382_entry(V self, V *a);
extern Clo g_list_2emap_24s1727184187x1048417382_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24dps(V, V);
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24dps_clo;
V g_list_2emap_24s1835183789x486277886(V);
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_clo;
V g_list_2emap_24s1835183789x486277886_24dps(V, V);
V g_list_2emap_24s1835183789x486277886_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_24dps_clo;
V g_list_2emap_24s1902028738x441242582(V);
V g_list_2emap_24s1902028738x441242582_entry(V self, V *a);
extern Clo g_list_2emap_24s1902028738x441242582_clo;
V g_list_2emap_24s1902028738x441242582_24dps(V, V);
V g_list_2emap_24s1902028738x441242582_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1902028738x441242582_24dps_clo;
V g_list_2emap_24s1919168173x1618249050(V, V, V, V);
V g_list_2emap_24s1919168173x1618249050_entry(V self, V *a);
extern Clo g_list_2emap_24s1919168173x1618249050_clo;
V g_list_2emap_24s1919168173x1618249050_24dps(V, V, V, V, V);
V g_list_2emap_24s1919168173x1618249050_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1919168173x1618249050_24dps_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24dps(V, V);
V g_list_2emap_24s1937570095x2110149801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24dps_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s2016093283x1174801437(V, V);
V g_list_2emap_24s2016093283x1174801437_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_clo;
V g_list_2emap_24s2016093283x1174801437_24dps(V, V, V);
V g_list_2emap_24s2016093283x1174801437_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_24dps_clo;
V g_list_2emap_24s2051429168x672290949(V);
V g_list_2emap_24s2051429168x672290949_entry(V self, V *a);
extern Clo g_list_2emap_24s2051429168x672290949_clo;
V g_list_2emap_24s2051429168x672290949_24dps(V, V);
V g_list_2emap_24s2051429168x672290949_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2051429168x672290949_24dps_clo;
V g_list_2emap_24s2087317732x355496638(V);
V g_list_2emap_24s2087317732x355496638_entry(V self, V *a);
extern Clo g_list_2emap_24s2087317732x355496638_clo;
V g_list_2emap_24s2087317732x355496638_24dps(V, V);
V g_list_2emap_24s2087317732x355496638_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2087317732x355496638_24dps_clo;
V g_list_2emap_24s215892288x1392224072(V, V);
V g_list_2emap_24s215892288x1392224072_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_clo;
V g_list_2emap_24s215892288x1392224072_24dps(V, V, V);
V g_list_2emap_24s215892288x1392224072_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24dps_clo;
V g_list_2emap_24s249042484x1701682908_24dps(V, V);
V g_list_2emap_24s249042484x1701682908_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_24dps_clo;
V g_list_2emap_24s3575633x347355318(V);
V g_list_2emap_24s3575633x347355318_entry(V self, V *a);
extern Clo g_list_2emap_24s3575633x347355318_clo;
V g_list_2emap_24s430074199x1834682414_24dps(V, V, V, V, V);
V g_list_2emap_24s430074199x1834682414_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s430074199x1834682414_24dps_clo;
V g_list_2emap_24s471405029x78128406(V);
V g_list_2emap_24s471405029x78128406_entry(V self, V *a);
extern Clo g_list_2emap_24s471405029x78128406_clo;
V g_list_2emap_24s471405029x78128406_24dps(V, V);
V g_list_2emap_24s471405029x78128406_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s471405029x78128406_24dps_clo;
V g_list_2emap_24s502656580x1955732096_24dps(V, V);
V g_list_2emap_24s502656580x1955732096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_24dps_clo;
V g_list_2emap_24s503834852x510769098(V, V);
V g_list_2emap_24s503834852x510769098_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_clo;
V g_list_2emap_24s503834852x510769098_24dps(V, V, V);
V g_list_2emap_24s503834852x510769098_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_24dps_clo;
V g_list_2emap_24s513201124x806973253_24dps(V, V);
V g_list_2emap_24s513201124x806973253_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_24dps_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s60612435x257154841_24dps(V, V);
V g_list_2emap_24s60612435x257154841_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_24dps_clo;
V g_list_2emap_24s640776339x1223679834_24dps(V, V);
V g_list_2emap_24s640776339x1223679834_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_24dps_clo;
V g_list_2emap_24s698037429x265256386_24dps(V, V);
V g_list_2emap_24s698037429x265256386_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s698037429x265256386_24dps_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s725725455x1186198702_24dps(V, V);
V g_list_2emap_24s725725455x1186198702_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_24dps_clo;
V g_list_2emap_24s809490196x1189312632(V);
V g_list_2emap_24s809490196x1189312632_entry(V self, V *a);
extern Clo g_list_2emap_24s809490196x1189312632_clo;
V g_list_2emap_24s809490196x1189312632_24dps(V, V);
V g_list_2emap_24s809490196x1189312632_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s809490196x1189312632_24dps_clo;
V g_list_2emap_24s878634257x1677201747(V);
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_clo;
V g_list_2emap_24s878634257x1677201747_24dps(V, V);
V g_list_2emap_24s878634257x1677201747_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_24dps_clo;
V g_list_2emap_24s925333445x1396764769_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s925333445x1396764769_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s925333445x1396764769_24dps_clo;
V g_list_2emap_24s939813003x1383013550_24dps(V, V);
V g_list_2emap_24s939813003x1383013550_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_24dps_clo;
V g_list_2emap_24s976303750x321235480_24dps(V, V);
V g_list_2emap_24s976303750x321235480_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_24dps_clo;
V g_list_2emerge_24s2063716145x1843377885_24dps(V, V, V);
V g_list_2emerge_24s2063716145x1843377885_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s2063716145x1843377885_24dps_clo;
V g_list_2emerge_24s2063716145x1843377885_24tok2(V, V, V);
V g_list_2emerge_24s2063716145x1843377885_24tok2_entry(V self, V *a);
extern Clo g_list_2emerge_24s2063716145x1843377885_24tok2_clo;
V g_list_2emerge_24s991540778x2011810329(V, V);
V g_list_2emerge_24s991540778x2011810329_entry(V self, V *a);
extern Clo g_list_2emerge_24s991540778x2011810329_clo;
V g_list_2emerge_24s991540778x2011810329_24dps(V, V, V);
V g_list_2emerge_24s991540778x2011810329_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s991540778x2011810329_24dps_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1023948938x380005785(V, V, V);
V g_list_2ezipWith_24s1023948938x380005785_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1023948938x380005785_clo;
V g_list_2ezipWith_24s1023948938x380005785_24dps(V, V, V, V);
V g_list_2ezipWith_24s1023948938x380005785_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1023948938x380005785_24dps_clo;
V g_list_2ezipWith_24s1604775524x1614188687_24dps(V, V, V, V);
V g_list_2ezipWith_24s1604775524x1614188687_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1604775524x1614188687_24dps_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s1877091673x1588480570_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s1877091673x1588480570_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1877091673x1588480570_24dps_clo;
V g_list_2ezipWith_24s1893966264x617194987(V, V);
V g_list_2ezipWith_24s1893966264x617194987_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1893966264x617194987_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2ecli_2eflagWord(V);
V g_std_2ecli_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagWord_clo;
V g_std_2ecli_2ereading_get(void);
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
Clo g_list_2emap_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_entry, 2, 0};

V g_list_2emap(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24dps(v_f_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_entry(V self, V *a) {
  (void)self;
  return g_list_2emap(a[0], a[1]);
}
Clo g_list_2eany_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_entry, 2, 0};

V g_list_2eany(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1937570095x2110149801_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1937570095x2110149801_24dps_entry, 2, 0};

V g_list_2emap_24s1937570095x2110149801_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1937570095x2110149801_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1937570095x2110149801_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1604775524x1614188687_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1604775524x1614188687_24dps_entry, 4, 0};

V g_list_2ezipWith_24s1604775524x1614188687_24dps(V v_lit_240, V v_x2_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_x3_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_242, 0);
      V v_ys_247 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_a_2410;
      switch (heff_tag_of(v_x_244)) {
      case TAG_MkPair: {
        V v_a_248 = heff_dup(heff_field(v_x_244, 0));
        v_a_2410 = v_a_248;
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      V v_a_2413;
      switch (heff_tag_of(v_x_244)) {
      case TAG_MkPair: {
        V v_a_2412 = heff_field(v_x_244, 1);
        heff_take_n(v_x_244, 2ULL, 2);
        v_a_2413 = v_a_2412;
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      V v_t_2417;
      switch (heff_tag_of(v_a_2413)) {
      case TAG_Unreached: {
        heff_drop(v_y_246);
        v_t_2417 = v_a_2410;
        break;
      }
      case TAG_Within: {
        V v_t_2416 = ({ V a_0 = v_a_2413; V a_1 = v_y_246; V r_ = (g_heff_2ecompile_2eranges_2erangeEq(a_0, a_1)); heff_drop_tag(v_a_2413, 2); heff_drop(v_y_246); r_; });
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop(v_t_2416);
          v_t_2417 = v_a_2410;
        } else {
          heff_drop(v_t_2416);
          v_t_2417 = heff_intAdd(v_a_2410, heff_dup(v_lit_240));
        }
        break;
      }
      default: heff_nomatch(v_a_2413);
      }
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
      V v_u_2419 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2418));
      heff_drop(v_u_2419);
      V t_0 = v_lit_240;
      V t_1 = v_xs_245;
      V t_2 = v_ys_247;
      V t_3 = v_cell_2418;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24s1604775524x1614188687_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1604775524x1614188687_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s213448614x618797387_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s213448614x618797387_entry, 14, 0};

V g_list_2efoldl_24s213448614x618797387(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_z_2412, V v_x3_2413) {
top: ;
  switch (heff_tag_of(v_x3_2413)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    heff_drop(v_lit_2410);
    heff_drop(v_lit_2411);
    return v_z_2412;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x3_2413, 0);
    V v_xs_2415 = heff_field(v_x3_2413, 1);
    V v_a_2418;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_a_2417 = heff_field(v_x_2414, 1);
      v_a_2418 = heff_dup(v_a_2417);
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_243), heff_dup(v_lit_244), v_a_2418));
    V v_t_2420 = (g_list_2erange(heff_dup(v_lit_242), heff_intSub(v_t_2419, heff_dup(v_lit_245))));
    V v_t_2421 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2420, v_a_2418));
    V v_t_2422 = (g_list_2ekeepIf_24s425280038x249084439(heff_dup(v_lit_240), heff_dup(v_lit_241), v_t_2421));
    V v_a_2423 = (g_list_2emap_24s1937570095x2110149801(v_t_2422));
    V v_t_2437;
    switch (heff_tag_of(v_a_2423)) {
    case TAG_Nil: {
      v_t_2437 = v_z_2412;
      break;
    }
    case TAG_Cons: {
      V v_ru_24a_2423_24Cons = heff_take_reuse_n(v_a_2423, 0ULL, 2);
      V v_t_2428;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_MkPair: {
        V v_a_2426 = heff_field(v_x_2414, 0);
        v_t_2428 = heff_dup(v_a_2426);
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_a_2431;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_MkPair: {
        V v_a_2430 = heff_field(v_x_2414, 1);
        v_a_2431 = heff_dup(v_a_2430);
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_249), heff_dup(v_lit_2410), v_a_2431));
      V v_t_2433 = (g_list_2erange(heff_dup(v_lit_248), heff_intSub(v_t_2432, heff_dup(v_lit_2411))));
      V v_t_2434 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2433, v_a_2431));
      V v_t_2435 = (g_list_2ekeepIf_24s425280038x249084439(heff_dup(v_lit_246), heff_dup(v_lit_247), v_t_2434));
      V v_t_2436 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24a_2423_24Cons, v_t_2435));
      v_t_2437 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_2412, v_t_2428, v_t_2436));
      break;
    }
    default: heff_nomatch(v_a_2423);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_lit_249;
    V t_10 = v_lit_2410;
    V t_11 = v_lit_2411;
    V t_12 = v_t_2437;
    V t_13 = v_xs_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_lit_249 = t_9;
    v_lit_2410 = t_10;
    v_lit_2411 = t_11;
    v_z_2412 = t_12;
    v_x3_2413 = t_13;
    goto top;
  }
  default: return heff_nomatch(v_x3_2413);
  }
}
V g_list_2efoldl_24s213448614x618797387_entry(V self, V *a) {
  (void)self;
  V a13 = a[13]; V r = g_list_2efoldl_24s213448614x618797387(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a13); heff_drop(a13); return r;
}
Clo g_list_2emap_24s1835183789x486277886_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1835183789x486277886_entry, 1, 0};

V g_list_2emap_24s1835183789x486277886(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1835183789x486277886_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1835183789x486277886(a[0]);
}
Clo g_list_2efoldl_24s1872971975x1696014049_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1872971975x1696014049_entry, 3, 0};

V g_list_2efoldl_24s1872971975x1696014049(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2etokens_2elineElem(v_lit_240, v_z_241, heff_dup(v_x_243)));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1872971975x1696014049_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2efoldl_24s1872971975x1696014049(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2eany_24s689038521x519269801_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s689038521x519269801_entry, 1, 0};

V g_list_2eany_24s689038521x519269801(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkSegment: {
        V v_ty_246 = heff_field(v_x11_243, 1);
        switch (heff_tag_of(v_ty_246)) {
        case TAG_SegmentInteger: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_SegmentBinary: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_SegmentBits: {
          return NTAG(TAG_True);
        }
        case TAG_SegmentFloat: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_SegmentUtf: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_ty_246);
        }
      }
      default: return heff_nomatch(v_x11_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s689038521x519269801_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s689038521x519269801(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1520235531x215612111_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1520235531x215612111_entry, 5, 0};

V g_list_2emap_24s1520235531x215612111(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = (g_heff_2esyntax_2epresyntax_2earmOn(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_x_245));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s1520235531x215612111_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s1520235531x215612111_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1520235531x215612111(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s2016093283x1174801437_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2016093283x1174801437_entry, 2, 0};

V g_list_2emap_24s2016093283x1174801437(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2efieldDeclOf(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s2016093283x1174801437_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2016093283x1174801437_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2016093283x1174801437(a[0], a[1]);
}
Clo g_list_2emap_24s1036840854x702708481_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1036840854x702708481_24dps_entry, 3, 0};

V g_list_2emap_24s1036840854x702708481_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2eequationOf(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1036840854x702708481_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1036840854x702708481_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1258450377x973220636_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1258450377x973220636_entry, 1, 0};

V g_list_2emap_24s1258450377x973220636(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1258450377x973220636_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1258450377x973220636_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1258450377x973220636(a[0]);
}
Clo g_list_2emap_24s1276400643x126214923_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1276400643x126214923_24dps_entry, 2, 0};

V g_list_2emap_24s1276400643x126214923_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1276400643x126214923_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1276400643x126214923_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2051429168x672290949_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2051429168x672290949_entry, 1, 0};

V g_list_2emap_24s2051429168x672290949(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2051429168x672290949_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2051429168x672290949_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2051429168x672290949(a[0]);
}
Clo g_list_2emap_24s126994153x1029399760_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s126994153x1029399760_24dps_entry, 2, 0};

V g_list_2emap_24s126994153x1029399760_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2420;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2419;
      switch (heff_tag_of(v_a_244)) {
      case TAG_ArgExplicit: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24ArgExplicit = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_field(v_a_246, 0);
          V v_a_248 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_249 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_247));
          v_t_2410 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_249, v_a_248});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24a_244_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_2410});
        break;
      }
      case TAG_ArgProject: {
        V v_a_2411 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24ArgProject = heff_take_reuse_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2419 = heff_tag_at_n(v_ru_24a_244_24ArgProject, TAG_ArgProject, 1, (V[]){v_a_2411});
        break;
      }
      case TAG_ArgNamed: {
        V v_a_2412 = heff_field(v_a_244, 0);
        V v_a_2413 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24ArgNamed = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_t_2417;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          V v_t_2416 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2414));
          v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2416, v_a_2415});
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24a_244_24ArgNamed, TAG_ArgNamed, 2, (V[]){v_a_2412, v_t_2417});
        break;
      }
      case TAG_ArgEvidence: {
        V v_a_2418 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24ArgEvidence = heff_take_reuse_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2419 = heff_tag_at_n(v_ru_24a_244_24ArgEvidence, TAG_ArgEvidence, 1, (V[]){v_a_2418});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2421 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2420, heff_hole()});
    V v_u_2422 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2421));
    heff_drop(v_u_2422);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2421;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s126994153x1029399760_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s126994153x1029399760_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s249042484x1701682908_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s249042484x1701682908_24dps_entry, 2, 0};

V g_list_2emap_24s249042484x1701682908_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2416;
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24SetField = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_2410, v_a_249));
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24a_244_24SetField, TAG_SetField, 3, (V[]){v_a_246, v_a_247, v_t_2411});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2412 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24BadFieldSet = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_2414, v_a_2413));
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24a_244_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2415});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2416, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2418));
    heff_drop(v_u_2419);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2418;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s249042484x1701682908_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s249042484x1701682908_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s878634257x1677201747_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s878634257x1677201747_entry, 1, 0};

V g_list_2emap_24s878634257x1677201747(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2esyntax_2esurface_2eidentOf(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s878634257x1677201747_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s878634257x1677201747(a[0]);
}
Clo g_list_2emap_24s513201124x806973253_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513201124x806973253_24dps_entry, 2, 0};

V g_list_2emap_24s513201124x806973253_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_text_244 = heff_take_field(v_x_242, 1);
    V v_start_245 = heff_take_field(v_x_242, 3);
    V v_end_246 = heff_get_n(v_x_242, 4, 9);
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EProject, 1, (V[]){v_text_244}), heff_rec_n(2, shape_start__end, (V[]){v_start_245, v_end_246})});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513201124x806973253_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513201124x806973253_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1368043225x413679696_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1368043225x413679696_entry, 3, 0};

V g_list_2efoldl_24s1368043225x413679696(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_SetField: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_249 = heff_field(v_a_245, 2);
        heff_take_n(v_a_245, 5ULL, 3);
        V v_t_2412;
        switch (heff_tag_of(v_z_241)) {
        case TAG_At: {
          V v_a_2411 = heff_dup(heff_field(v_z_241, 1));
          v_t_2412 = v_a_2411;
          break;
        }
        default: heff_nomatch(v_z_241);
        }
        V v_t_2413 = ({ V rv_1 = heff_dup(heff_rfield(v_a_246, 1)); V rr_ = heff_rec_reuse_nf(v_t_2412, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_ESpec, 4, (V[]){v_z_241, v_a_247, v_a_246, v_a_249}), v_t_2413});
        break;
      }
      case TAG_BadFieldSet: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_z_241);
        v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(v_lit_240)}), v_a_246});
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2415;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1368043225x413679696_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1368043225x413679696(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s146946949x1862800301_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s146946949x1862800301_24dps_entry, 2, 0};

V g_list_2emap_24s146946949x1862800301_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_text_244 = heff_take_field(v_x_242, 1);
    V v_start_245 = heff_take_field(v_x_242, 3);
    V v_end_246 = heff_get_n(v_x_242, 4, 9);
    V v_t_247 = heff_rec_n(2, shape_name__span, (V[]){v_text_244, heff_rec_n(2, shape_start__end, (V[]){v_start_245, v_end_246})});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s146946949x1862800301_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s146946949x1862800301_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s60612435x257154841_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s60612435x257154841_entry, 1, 0};

V g_list_2emap_24s60612435x257154841(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_b_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 4ULL, 3);
      v_t_246 = v_b_245;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s60612435x257154841_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s60612435x257154841_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s60612435x257154841(a[0]);
}
Clo g_list_2efoldl_24s1048046132x95752937_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1048046132x95752937_entry, 2, 0};

V g_list_2efoldl_24s1048046132x95752937(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2espec_2ebindOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1048046132x95752937(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1809017761x1063871171_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1809017761x1063871171_entry, 1, 0};

V g_list_2emap_24s1809017761x1063871171(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1809017761x1063871171_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1809017761x1063871171(a[0]);
}
Clo g_list_2emap_24s1531069132x955165792_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1531069132x955165792_24dps_entry, 2, 0};

V g_list_2emap_24s1531069132x955165792_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1531069132x955165792_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1531069132x955165792_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s419339443x1702462498_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s419339443x1702462498_entry, 2, 0};

V g_list_2efoldl_24s419339443x1702462498(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2ecanonVisit(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s419339443x1702462498_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s419339443x1702462498(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s469347062x492258493_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s469347062x492258493_entry, 1, 0};

V g_list_2eany_24s469347062x492258493(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_RepV: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_RepFix: {
      return NTAG(TAG_True);
    }
    case TAG_RepF64: {
      return NTAG(TAG_True);
    }
    case TAG_RepInt: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s469347062x492258493_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s469347062x492258493(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1310249268x749995235_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1310249268x749995235_entry, 3, 0};

V g_list_2emap_24s1310249268x749995235(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2erepr_2edecidedIn(v_lit_240, v_lit_241, v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1310249268x749995235_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1310249268x749995235_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2emap_24s1310249268x749995235(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1915639815x253536901_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1915639815x253536901_entry, 2, 0};

V g_list_2efoldl_24s1915639815x253536901(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2earity_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1915639815x253536901_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1915639815x253536901(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1203202837x1639358108_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1203202837x1639358108_entry, 2, 0};

V g_list_2efoldl_24s1203202837x1639358108(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_x_242}), v_z_240});
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1203202837x1639358108(a[0], a[1]);
}
Clo g_list_2eany_24s332132496x946063656_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s332132496x946063656_entry, 2, 0};

V g_list_2eany_24s332132496x946063656(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_lit_240, 0);
      v_t_249 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    if (heff_strEq_c(v_t_246, v_t_249)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s332132496x946063656_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s332132496x946063656(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s471405029x78128406_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s471405029x78128406_entry, 1, 0};

V g_list_2emap_24s471405029x78128406(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 7ULL, 3);
      v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_a_244}), heff_tag_n(TAG_ASts, 1, (V[]){v_a_245})});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s471405029x78128406_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s471405029x78128406_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s471405029x78128406(a[0]);
}
Clo g_list_2emap_24s471405029x78128406_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s471405029x78128406_24dps_entry, 2, 0};

V g_list_2emap_24s471405029x78128406_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_245}), heff_tag_n(TAG_ASts, 1, (V[]){v_a_246})});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s471405029x78128406_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s471405029x78128406_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s698037429x265256386_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s698037429x265256386_24dps_entry, 2, 0};

V g_list_2emap_24s698037429x265256386_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDecl, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s698037429x265256386_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s698037429x265256386_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s976303750x321235480_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s976303750x321235480_24dps_entry, 2, 0};

V g_list_2emap_24s976303750x321235480_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Given: {
      V v_e_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = v_e_244;
      break;
    }
    case TAG_GivenU: {
      V v_e_246 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_2410 = v_e_246;
      break;
    }
    case TAG_LentVar: {
      V v_x_247 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2410 = heff_tag_n(TAG_RLocal, 1, (V[]){v_x_247});
      break;
    }
    case TAG_LentValue: {
      V v_e_249 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = v_e_249;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s976303750x321235480_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s976303750x321235480_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1879887278x1868824044_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1879887278x1868824044_entry, 2, 0};

V g_list_2efoldl_24s1879887278x1868824044(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_2410 = heff_field(v_x_242, 6);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1879887278x1868824044_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1879887278x1868824044(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s215892288x1392224072_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s215892288x1392224072_entry, 2, 0};

V g_list_2emap_24s215892288x1392224072(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_lit_240), v_x_242}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s215892288x1392224072_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s215892288x1392224072_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s215892288x1392224072(a[0], a[1]);
}
Clo g_list_2efoldl_24s1980014771x775787011_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1980014771x775787011_entry, 2, 0};

V g_list_2efoldl_24s1980014771x775787011(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_OutTag: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_OutRecord: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_OutCall: {
      V v_a_248 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_248, NTAG(TAG_Nil)});
      break;
    }
    case TAG_OutOther: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_prelude_2e_2b_2b(v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1980014771x775787011_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1980014771x775787011(a[0], a[1]);
}
Clo g_list_2emap_24s1902028738x441242582_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1902028738x441242582_entry, 1, 0};

V g_list_2emap_24s1902028738x441242582(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    switch (heff_tag_of(v_x_241)) {
    case TAG_RepV: {
      v_t_244 = NTAG(TAG_FtOther);
      break;
    }
    case TAG_RepFix: {
      V v_w_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24RepFix = heff_take_reuse_n(v_x_241, 1ULL, 1);
      v_t_244 = heff_tag_at_n(v_ru_24x_241_24RepFix, TAG_FtFixed, 1, (V[]){v_w_243});
      break;
    }
    case TAG_RepF64: {
      v_t_244 = NTAG(TAG_FtFloat);
      break;
    }
    case TAG_RepInt: {
      v_t_244 = NTAG(TAG_FtOther);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1902028738x441242582_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1902028738x441242582_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1902028738x441242582(a[0]);
}
Clo g_list_2ekeepIf_24s1245654234x191876439_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1245654234x191876439_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1245654234x191876439_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2439;
    switch (heff_tag_of(v_x_242)) {
    case TAG_SLocal: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SGlobal: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SCode: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SApp: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLam: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SCons: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SProj: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_STag: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SMatch: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SSpecialize: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SIs: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SOpaque: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SAbandon: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SRec: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SFix: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SImplicit: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_SPrim: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SMetaApp: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitInt: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFloat: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitString: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitBytes: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitRune: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFixed: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFloat32: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
      heff_drop(v_t_2439);
      V v_cell_2440 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2441 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2440));
      heff_drop(v_u_2441);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2440;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_2439);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1245654234x191876439_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1245654234x191876439_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s455728131x407835966_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s455728131x407835966_entry, 2, 0};

V g_list_2efoldl_24s455728131x407835966(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_z_240)) {
    case TAG_Nothing: {
      v_t_246 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_a_244 = heff_field(v_z_240, 0);
      V v_ru_24z_240_24Just = heff_take_reuse_n(v_z_240, 1ULL, 1);
      switch (heff_tag_of(v_x_242)) {
      case TAG_Nothing: {
        heff_drop(v_a_244);
        heff_drop_cell(v_ru_24z_240_24Just, 1);
        v_t_246 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_b_245 = heff_field(v_x_242, 0);
        v_t_246 = heff_tag_at_n(v_ru_24z_240_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_244, heff_dup(v_b_245))});
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s455728131x407835966_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s455728131x407835966(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1375915522x445000623_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1375915522x445000623_entry, 1, 0};

V g_list_2eany_24s1375915522x445000623(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Nothing: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_a_243 = heff_field(v_x_241, 0);
      if ((heff_dup(v_a_243) == NTAG(TAG_True))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1375915522x445000623_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1375915522x445000623(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s782566794x1684170422_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s782566794x1684170422_entry, 2, 0};

V g_list_2efoldl_24s782566794x1684170422(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_key_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_body_245 = heff_dup(heff_rfield(v_x_242, 2));
    HeffT2 v_t_246 = (g_heff_2ecompile_2efuse_2econsumerOf_24cpr(heff_dup(v_key_244), v_body_245));
    V v_t_2410;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_a_249 = v_field_248;
        v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, v_key_244, v_a_249));
      } else {
        heff_drop(v_key_244);
        heff_drop(v_field_248);
        v_t_2410 = v_z_240;
      }
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s782566794x1684170422_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s782566794x1684170422(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1478286876x830244177_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1478286876x830244177_entry, 1, 0};

V g_list_2emap_24s1478286876x830244177(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1478286876x830244177_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1478286876x830244177_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1478286876x830244177(a[0]);
}
Clo g_list_2efoldl_24s578974906x2018699728_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s578974906x2018699728_entry, 2, 0};

V g_list_2efoldl_24s578974906x2018699728(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_PassedRecord: {
      V v_q1_244 = heff_field(v_x_242, 0);
      V v_q2_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_z_240)) {
      case TAG_NoRecord: {
        v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Records, 2, (V[]){v_q1_244, v_q2_245});
        break;
      }
      case TAG_Records: {
        V v_ls_246 = heff_field(v_z_240, 0);
        V v_ts_247 = heff_field(v_z_240, 1);
        heff_take_n(v_z_240, 3ULL, 2);
        V v_t_248 = ({ V a_0 = v_ls_246; V a_1 = v_q1_244; V r_ = (g_heff_2ecompile_2escalars_2esameLabels(a_0, a_1)); heff_drop(v_q1_244); r_; });
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          V v_t_249 = (g_list_2ezipWith_24s1893966264x617194987(v_ts_247, v_q2_245));
          v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Records, 2, (V[]){v_ls_246, v_t_249});
        } else {
          heff_drop_cell(v_ru_24x3_241_24Cons, 2);
          heff_drop(v_q2_245);
          heff_drop(v_ls_246);
          heff_drop(v_ts_247);
          heff_drop(v_t_248);
          v_t_2410 = NTAG(TAG_Mixed);
        }
        break;
      }
      case TAG_Mixed: {
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop(v_q1_244);
        heff_drop(v_q2_245);
        v_t_2410 = NTAG(TAG_Mixed);
        break;
      }
      default: heff_nomatch(v_z_240);
      }
      break;
    }
    case TAG_PassedSame: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2410 = v_z_240;
      break;
    }
    case TAG_PassedOther: {
      heff_drop(v_z_240);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2410 = NTAG(TAG_Mixed);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s578974906x2018699728_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s578974906x2018699728(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1023948938x380005785_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1023948938x380005785_entry, 3, 0};

V g_list_2ezipWith_24s1023948938x380005785(V v_lit_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2eunbox_2eslotFor(heff_dup(v_lit_240), v_x_243, v_y_245));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s1023948938x380005785_24dps(v_lit_240, v_xs_244, v_ys_246, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24s1023948938x380005785_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1023948938x380005785(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2eany_24s1598387467x1906338007_str0, 4, "word");
Clo g_list_2eany_24s1598387467x1906338007_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1598387467x1906338007_entry, 1, 0};

V g_list_2eany_24s1598387467x1906338007(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    HeffT2 v_t_243 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_x_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x11_246 = v_field_245;
        heff_drop(v_x11_246);
        if (((((int64_t)4ULL) < heff_unbox_word(heff_strLength_lent(v_x_241, 0))) && heff_strEq_c(heff_strSlice_lent(v_x_241, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_list_2eany_24s1598387467x1906338007_str0)))) {
          V v_x1_247 = ({ V a_0 = v_x_241; V b_1 = heff_dup(g_heff_2ecompile_2eranges_2ewordPrims_get()); V r_ = (g_list_2eany_24s130813166x1111413304(a_0, b_1)); heff_drop(b_1); r_; });
          if (!(heff_dup(v_x1_247) == NTAG(TAG_True))) {
            heff_drop(v_x1_247);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_x1_247);
            V t_0 = v_xs_242;
            v_x2_240 = t_0;
            goto top;
          }
        } else {
          return NTAG(TAG_True);
        }
      } else {
        heff_drop(v_field_245);
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1598387467x1906338007_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1598387467x1906338007(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s62513826x839087377_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s62513826x839087377_entry, 2, 0};

V g_list_2efoldl_24s62513826x839087377(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s62513826x839087377_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s62513826x839087377(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s723147058x1136115564_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s723147058x1136115564_entry, 2, 0};

V g_list_2efoldl_24s723147058x1136115564(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_key_244 = heff_dup(heff_rfield(v_x_242, 1));
    V v_refs_245 = heff_dup(heff_rfield(v_x_242, 4));
    V v_t_246 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, v_key_244, v_refs_245));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s723147058x1136115564_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s723147058x1136115564(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s152505078x225062837_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s152505078x225062837_24dps_entry, 2, 0};

V g_list_2emap_24s152505078x225062837_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s152505078x225062837_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s152505078x225062837_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s503834852x510769098_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s503834852x510769098_entry, 2, 0};

V g_list_2emap_24s503834852x510769098(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_x_242; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_244), heff_hole()});
    V v_u_246 = (g_list_2emap_24s503834852x510769098_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s503834852x510769098_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s503834852x510769098(a[0], a[1]);
}
Clo g_list_2emap_24s640776339x1223679834_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s640776339x1223679834_24dps_entry, 2, 0};

V g_list_2emap_24s640776339x1223679834_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s640776339x1223679834_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s640776339x1223679834_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1877091673x1588480570_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1877091673x1588480570_24dps_entry, 6, 0};

V g_list_2ezipWith_24s1877091673x1588480570_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_243, 0);
    V v_xs_247 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_246);
      heff_drop(v_xs_247);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_248 = heff_field(v_x3_244, 0);
      V v_ys_249 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_x_246)) {
      case TAG_MkPair: {
        V v_a_2410 = heff_dup(heff_field(v_x_246, 0));
        v_t_2412 = v_a_2410;
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      V v_t_2415;
      switch (heff_tag_of(v_x_246)) {
      case TAG_MkPair: {
        V v_a_2414 = heff_field(v_x_246, 1);
        heff_take_n(v_x_246, 2ULL, 2);
        v_t_2415 = v_a_2414;
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      V v_t_2416 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2415, heff_dup(v_lit_242)));
      V v_t_2417 = heff_strAppend(heff_intShow(v_y_248), v_t_2416);
      V v_t_2418 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_240), v_t_2417));
      V v_cell_2419 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
      V v_u_2420 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2419));
      heff_drop(v_u_2420);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_247;
      V t_4 = v_ys_249;
      V t_5 = v_cell_2419;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_x3_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s1877091673x1588480570_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1877091673x1588480570_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s430074199x1834682414_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s430074199x1834682414_24dps_entry, 5, 0};

V g_list_2emap_24s430074199x1834682414_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_lit_242; V a_3 = v_x_245; V r_ = (g_heff_2ecompile_2eemitc_2etupleRead(a_0, a_1, a_2, a_3)); heff_drop(v_x_245); r_; });
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s430074199x1834682414_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s430074199x1834682414_24dps(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1418269708x2034621695_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1418269708x2034621695_24dps_entry, 3, 0};

V g_list_2emap_24s1418269708x2034621695_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_strSlice(heff_dup(v_x_243), heff_dup(v_lit_240), heff_strLength(v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1418269708x2034621695_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1418269708x2034621695_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24s502656580x1955732096_24dps_str0, 1, "_");
Clo g_list_2emap_24s502656580x1955732096_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s502656580x1955732096_24dps_entry, 2, 0};

V g_list_2emap_24s502656580x1955732096_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(v_x_242, 0, 5);
    V v_t_2424;
    switch (heff_tag_of(v_t_244)) {
    case TAG_At: {
      V v_x11_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 2);
      switch (heff_tag_of(v_x11_245)) {
      case TAG_PatVar: {
        V v_x_247 = heff_field(v_x11_245, 0);
        V v_ru_24x11_245_24PatVar = heff_take_reuse_n(v_x11_245, 1ULL, 1);
        if (heff_strEq_c_lent(v_x_247, ((V)&g_list_2emap_24s502656580x1955732096_24dps_str0), 2)) {
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x11_245_24PatVar, 1);
          v_t_2424 = NTAG(TAG_Nothing);
        } else {
          v_t_2424 = heff_tag_at_n(v_ru_24x11_245_24PatVar, TAG_Just, 1, (V[]){v_x_247});
        }
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_245, 0ULL, 3);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_245, 0ULL, 3);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_na(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_245, 0ULL, 3);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_245);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_cell_2425 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2424, heff_hole()});
    V v_u_2426 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2425));
    heff_drop(v_u_2426);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2425;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s502656580x1955732096_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s502656580x1955732096_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s939813003x1383013550_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s939813003x1383013550_24dps_entry, 2, 0};

V g_list_2emap_24s939813003x1383013550_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(v_x_242, 2, 5);
    V v_t_249;
    switch (heff_tag_of(v_t_244)) {
    case TAG_SizeDefault: {
      v_t_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeNumber: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeName: {
      V v_x_246 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 3);
      v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s939813003x1383013550_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s939813003x1383013550_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1386495485x1391533176_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1386495485x1391533176_entry, 2, 0};

V g_list_2emap_24s1386495485x1391533176(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2eelab_2eclauses_2erenameAlt(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1386495485x1391533176_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1386495485x1391533176_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1386495485x1391533176(a[0], a[1]);
}
Clo g_list_2efoldl_24s1991317015x801331450_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1991317015x801331450_entry, 2, 0};

V g_list_2efoldl_24s1991317015x801331450(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_a_247), NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1991317015x801331450_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1991317015x801331450(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1823913665x1128491553_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1823913665x1128491553_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1823913665x1128491553_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(v_x_243), heff_dup(heff_rfield(v_lit_240, 1)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1823913665x1128491553_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1823913665x1128491553_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s1161549307x1906011635_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1161549307x1906011635_entry, 1, 0};

V g_list_2ekeepIf_24s1161549307x1906011635(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_SError: {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s1161549307x1906011635_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    case TAG_SWarning: {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SDebug: {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1161549307x1906011635(a[0]);
}
Clo g_list_2eany_24s1631644720x1952242925_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1631644720x1952242925_entry, 2, 0};

V g_list_2eany_24s1631644720x1952242925(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1631644720x1952242925_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1631644720x1952242925(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s159747708x343809768_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s159747708x343809768_entry, 7, 0};

V g_list_2emap_24s159747708x343809768(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_a_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_a_2412 = (g_prelude_2esplitFrom(v_lit_240, v_a_2411, heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_a_2411, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_t_2417;
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2411, heff_dup(v_lit_244)});
      break;
    }
    case TAG_Cons: {
      V v_a_2413 = heff_field(v_a_2412, 0);
      V v_a_2414 = heff_field(v_a_2412, 1);
      V v_ru_24a_2412_24Cons = heff_take_reuse_n(v_a_2412, 3ULL, 2);
      switch (heff_tag_of(v_a_2414)) {
      case TAG_Nil: {
        heff_drop(v_a_2413);
        v_t_2417 = heff_tag_at_n(v_ru_24a_2412_24Cons, TAG_MkPair, 2, (V[]){v_a_2411, heff_dup(v_lit_245)});
        break;
      }
      case TAG_Cons: {
        V v_a_2415 = heff_field(v_a_2414, 0);
        heff_take_n(v_a_2414, 1ULL, 2);
        heff_drop(v_a_2411);
        v_t_2417 = heff_tag_at_n(v_ru_24a_2412_24Cons, TAG_MkPair, 2, (V[]){v_a_2413, v_a_2415});
        break;
      }
      default: heff_nomatch(v_a_2414);
      }
      break;
    }
    default: heff_nomatch(v_a_2412);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = (g_list_2emap_24s159747708x343809768_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s159747708x343809768_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24s159747708x343809768(a0, a[1], a2, a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2emerge_24s991540778x2011810329_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s991540778x2011810329_entry, 2, 0};

V g_list_2emerge_24s991540778x2011810329(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_x3_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_243 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 5);
      heff_drop(v_xs_243);
      return v_x2_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 1, 2);
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 0, 2);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_y_244, 0)), 1, 2);
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_y_244, 0)), 0, 2);
      if (heff_intLe_c(heff_intSub(v_t_246, v_t_247), heff_intSub(v_t_248, v_t_249))) {
        V v_cell_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2411 = (g_list_2emerge_24s991540778x2011810329_24dps(v_xs_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys_245}), heff_dup(v_cell_2410)));
        heff_drop(v_u_2411);
        return v_cell_2410;
      } else {
        V v_cell_2412 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2413 = (g_list_2emerge_24s991540778x2011810329_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs_243}), v_ys_245, heff_dup(v_cell_2412)));
        heff_drop(v_u_2413);
        return v_cell_2412;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s991540778x2011810329_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s991540778x2011810329(a[0], a[1]);
}
Clo g_list_2emap_24s1276696116x507290452_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1276696116x507290452_24dps_entry, 3, 0};

V g_list_2emap_24s1276696116x507290452_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_name_245 = heff_take_field(v_x_243, 0);
    V v_span_246 = heff_get_n(v_x_243, 1, 2);
    V v_a_247 = heff_dup(v_name_245);
    V v_a_248 = v_span_246;
    V v_start_249 = heff_take_field(v_a_248, 0);
    V v_end_2410 = heff_get_n(v_a_248, 1, 2);
    V v_t_2411 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), heff_tag_n(TAG_Just, 1, (V[]){v_name_245}), NTAG(TAG_Nothing)});
    V v_a_2412 = v_start_249;
    V v_a_2413 = heff_intSub(heff_dup(v_end_2410), heff_strLength_lent(v_a_247, 0));
    V v_t_2414;
    if (heff_intLe_c_lent(v_a_2412, v_a_2413, 0)) {
      heff_drop(v_a_2412);
      v_t_2414 = v_a_2413;
    } else {
      heff_drop(v_a_2413);
      v_t_2414 = v_a_2412;
    }
    V v_t_2415 = heff_rec_n(3, shape_target__name__span, (V[]){v_t_2411, v_a_247, heff_rec_n(2, shape_start__end, (V[]){v_t_2414, v_end_2410})});
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2416));
    heff_drop(v_u_2417);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_2416;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1276696116x507290452_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1276696116x507290452_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1675313341x192238134_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1675313341x192238134_24dps_entry, 2, 0};

V g_list_2emap_24s1675313341x192238134_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_MkEquation: {
        V v_fsp_247 = heff_field(v_x11_244, 1);
        heff_take_n(v_x11_244, 2ULL, 4);
        v_t_2410 = v_fsp_247;
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1675313341x192238134_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1675313341x192238134_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s496727651x1448898893_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s496727651x1448898893_entry, 2, 0};

V g_list_2efoldl_24s496727651x1448898893(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkEquation: {
        V v_a_249 = heff_field(v_a_244, 3);
        v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_249));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s496727651x1448898893(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2eany_24s577543654x765608923_str0, 12, "-- fmt: skip");
Clo g_list_2eany_24s577543654x765608923_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s577543654x765608923_entry, 1, 0};

V g_list_2eany_24s577543654x765608923(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_s_243 = heff_dup(heff_rfield(v_x_241, 0));
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(v_s_243, heff_strLength_lent(v_s_243, 0)));
    if (heff_strEq_c(heff_strSlice(v_s_243, MK_INT(0LL), v_t_244), ((V)&g_list_2eany_24s577543654x765608923_str0))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s577543654x765608923_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s577543654x765608923(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s725725455x1186198702_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s725725455x1186198702_entry, 1, 0};

V g_list_2emap_24s725725455x1186198702(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(v_x_241, heff_strLength_lent(v_x_241, 0)));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_x_241, MK_INT(0LL), v_t_243), heff_hole()});
    V v_u_245 = (g_list_2emap_24s725725455x1186198702_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s725725455x1186198702(a[0]);
}
Clo g_list_2emap_24s2087317732x355496638_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2087317732x355496638_entry, 1, 0};

V g_list_2emap_24s2087317732x355496638(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 5), heff_hole()});
    V v_u_244 = (g_list_2emap_24s2087317732x355496638_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2087317732x355496638_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2087317732x355496638(a[0]);
}
Clo g_list_2emap_24s925333445x1396764769_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s925333445x1396764769_24dps_entry, 7, 0};

V g_list_2emap_24s925333445x1396764769_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_x_247, 0));
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_dup(v_lit_241); V a_2 = heff_dup(v_lit_242); V r_ = (g_json_2eescapeGo(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
    V v_t_2413 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_dup(v_lit_243)));
    V v_t_2416;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_2415 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_t_2416 = v_a_2415;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_json_2estringify(a_0)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = heff_strAppend(v_t_2413, heff_strAppend(heff_dup(v_lit_244), v_t_2417));
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_xs_248;
    V t_6 = v_cell_2419;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_x2_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s925333445x1396764769_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s925333445x1396764769_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s1007499915x73800978_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1007499915x73800978_24dps_entry, 2, 0};

V g_list_2emap_24s1007499915x73800978_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = MK_INT(124LL); V a_1 = v_x_242; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_242); r_; });
    V v_t_245 = (g_list_2emap_24s1727184187x1048417382(v_t_244));
    HeffT2 v_t_246 = (g_regex_2eallRead_24cpr(v_t_245));
    V v_t_2411;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_why_249 = v_field_248;
        v_t_2411 = heff_tag_n(TAG_Left, 1, (V[]){v_why_249});
      } else {
        V v_bs_2410 = v_field_248;
        v_t_2411 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkRegex, 1, (V[]){v_bs_2410})});
      }
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2412;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1007499915x73800978_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1007499915x73800978_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s809490196x1189312632_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s809490196x1189312632_entry, 1, 0};

V g_list_2emap_24s809490196x1189312632(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2ecommands_2ejsonGolden(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s809490196x1189312632_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s809490196x1189312632_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s809490196x1189312632(a[0]);
}
Clo g_list_2emap_24s1281445768x1036802655_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1281445768x1036802655_entry, 1, 0};

V g_list_2emap_24s1281445768x1036802655(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagWord(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1281445768x1036802655_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1281445768x1036802655(a[0]);
}
Clo g_list_2emap_24s1919168173x1618249050_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1919168173x1618249050_entry, 4, 0};

V g_list_2emap_24s1919168173x1618249050(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_a_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_a_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2412;
    if (heff_strEq_c_lent(v_a_2411, v_lit_240, 0)) {
      heff_drop(v_a_2411);
      v_t_2412 = v_a_248;
    } else {
      v_t_2412 = heff_strAppend(v_a_248, heff_strAppend(heff_dup(v_lit_241), v_a_2411));
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2412, heff_dup(v_lit_242)), heff_hole()});
    V v_u_2414 = (g_list_2emap_24s1919168173x1618249050_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1919168173x1618249050_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1919168173x1618249050(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1531382666x123921537_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1531382666x123921537_24dps_entry, 2, 0};

V g_list_2emap_24s1531382666x123921537_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_244 = heff_take_field(v_x_242, 0);
    V v_doc_245 = heff_take_field(v_x_242, 1);
    V v_args_246 = heff_get_n(v_x_242, 3, 4);
    V v_t_247 = heff_tr(heff_call(v_args_246, 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_t_248 = heff_rec_n(3, shape_name__doc__shape, (V[]){v_name_244, v_doc_245, heff_get_n(v_t_247, 0, 2)});
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_xs_243;
    V t_1 = v_cell_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1531382666x123921537_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1531382666x123921537_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1539380703x380520933_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1539380703x380520933_24dps_str1, 0, "");
Clo g_list_2emap_24s1539380703x380520933_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1539380703x380520933_24dps_entry, 2, 0};

V g_list_2emap_24s1539380703x380520933_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_list_2emap_24s1539380703x380520933_24dps_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_245 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_list_2emap_24s1539380703x380520933_24dps_str1)), v_t_244});
    V v_t_246 = heff_rec_n(2, shape_part__input, (V[]){heff_tag_n(TAG_Positional, 1, (V[]){v_x_242}), heff_tag_n(TAG_Typed, 1, (V[]){v_t_245})});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1539380703x380520933_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1539380703x380520933_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1252894891x837498180_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1252894891x837498180_24dps_entry, 5, 0};

V g_list_2ekeepIf_24s1252894891x837498180_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_241, 6);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 2)), 0, 2);
    V v_t_248 = heff_strFind(heff_strOfRunes(v_t_247), heff_dup(heff_rfield(v_x_245, 0)), heff_dup(v_lit_242));
    if (heff_intLe_c_lent(v_lit_240, v_t_248, 2)) {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop_rec(v_x_245, 3);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s1252894891x837498180_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ekeepIf_24s1252894891x837498180_24dps(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f1428393365x1980555854_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1428393365x1980555854_entry, 3, 0};

V g_list_2efoldl_24f1428393365x1980555854(V v_z_240, V v_p_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_z_240});
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_z_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1428393365x1980555854_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1428393365x1980555854(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f96115456x1460340526_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f96115456x1460340526_entry, 3, 0};

V g_list_2efoldl_24f96115456x1460340526(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    switch (heff_tag_of(v_x_243)) {
    case TAG_PassedRecord: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_PassedSame: {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_PassedOther: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f96115456x1460340526_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f96115456x1460340526(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f1134152647x940271785_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1134152647x940271785_entry, 2, 0};

V g_list_2efoldl_24f1134152647x940271785(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(heff_rfield(v_x_242, 0)));
    V v_x_245 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_244));
    V v_t_246 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_245));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f1134152647x940271785(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f1559904364x1248618624_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1559904364x1248618624_entry, 3, 0};

V g_list_2efoldl_24f1559904364x1248618624(V v_z_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_x_243)}));
    V v_t_246 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_245));
    V t_0 = v_t_246;
    V t_1 = v_f_241;
    V t_2 = v_xs_244;
    v_z_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1559904364x1248618624(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f768999161x1997188166_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f768999161x1997188166_24dps_entry, 4, 0};

V g_list_2emap_24f768999161x1997188166_24dps(V v_lit_240, V v_box_24i_241, V v_box_24n_242, V v_d_243) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  int64_t v_n_242 = heff_unbox_word(v_box_24n_242);
top: ;
  if ((v_n_242 <= v_i_241)) {
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strByteAt_lent(v_lit_240, heff_box_word(v_i_241), 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_lit_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    int64_t t_2 = v_n_242;
    V t_3 = v_cell_244;
    v_lit_240 = t_0;
    v_i_241 = t_1;
    v_n_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f768999161x1997188166_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f768999161x1997188166_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_list_2emap_24f201346761x152404242_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f201346761x152404242_24dps_entry, 8, 0};

V g_list_2emap_24f201346761x152404242_24dps(V v_box_24lit_240, V v_lit_241, V v_box_24lit_242, V v_box_24lit_243, V v_lit_244, V v_a_245, V v_b_246, V v_d_247) {
  int64_t v_lit_240 = heff_unbox_word(v_box_24lit_240);
  int64_t v_lit_242 = heff_unbox_word(v_box_24lit_242);
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
top: ;
  if (heff_intLt_c_lent(v_b_246, v_a_245, 0)) {
    heff_drop(v_lit_244);
    heff_drop(v_a_245);
    heff_drop(v_b_246);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_249;
    if (((v_lit_240 <= heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_a_245, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_a_245, 0)) <= v_lit_242))) {
      int64_t v_t_248 = (heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_a_245, 0)) + v_lit_243);
      v_t_249 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_248))));
    } else {
      v_t_249 = heff_strSlice(heff_dup(v_lit_241), heff_dup(v_a_245), heff_intAdd(heff_dup(v_a_245), heff_dup(v_lit_244)));
    }
    V v_cell_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    int64_t t_0 = v_lit_240;
    V t_1 = v_lit_241;
    int64_t t_2 = v_lit_242;
    int64_t t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = heff_intAdd(v_a_245, MK_INT(1LL));
    V t_6 = v_b_246;
    V t_7 = v_cell_2410;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_a_245 = t_5;
    v_b_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
}
V g_list_2emap_24f201346761x152404242_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24f201346761x152404242_24dps(a[0], a1, a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f2094160282x1876485468_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2094160282x1876485468_entry, 3, 0};

V g_list_2efoldl_24f2094160282x1876485468(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_dup(heff_rfield(v_x_243, 1));
    switch (heff_tag_of(v_t_245)) {
    case TAG_SError: {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_SWarning: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_SDebug: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f2094160282x1876485468(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1893878025x389241368_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1893878025x389241368_24dps_entry, 7, 0};

V g_list_2emap_24f1893878025x389241368_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_shown_249 = heff_take_field(v_x_247, 2);
    V v_name_2410 = heff_take_field(v_x_247, 0);
    V v_doc_2411 = heff_get_n(v_x_247, 1, 4);
    if (((heff_dup(v_shown_249) == NTAG(TAG_True)) && heff_strEq_c(heff_strSlice(heff_dup(v_name_2410), heff_dup(v_lit_243), heff_strLength_lent(v_lit_244, 0)), heff_dup(v_lit_244)))) {
      heff_drop(v_shown_249);
      V v_a_2412 = v_name_2410;
      V v_a_2413 = v_doc_2411;
      V v_t_2414;
      if (heff_strEq_c_lent(v_a_2413, v_lit_240, 0)) {
        heff_drop(v_a_2413);
        v_t_2414 = v_a_2412;
      } else {
        v_t_2414 = heff_strAppend(v_a_2412, heff_strAppend(heff_dup(v_lit_241), v_a_2413));
      }
      V v_cell_2415 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2414, heff_dup(v_lit_242)), heff_hole()});
      V v_u_2416 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2415));
      heff_drop(v_u_2416);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_248;
      V t_6 = v_cell_2415;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_shown_249);
      heff_drop(v_name_2410);
      heff_drop(v_doc_2411);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_248;
      V t_6 = v_d_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24f1893878025x389241368_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V a4 = a[4]; V r = g_list_2emap_24f1893878025x389241368_24dps(a0, a[1], a[2], a3, a4, a[5], a[6]); heff_drop(a0); heff_drop(a3); heff_drop(a4); return r;
}
HEFF_LIT(g_list_2efoldl_24f354261656x2102112793_str0, 0, "");
HEFF_LIT(g_list_2efoldl_24f354261656x2102112793_str1, 0, "");
HEFF_LIT(g_list_2efoldl_24f354261656x2102112793_str2, 1, " ");
Clo g_list_2efoldl_24f354261656x2102112793_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f354261656x2102112793_entry, 5, 0};

V g_list_2efoldl_24f354261656x2102112793(V v_lit_240, V v_z_241, V v_w_242, V v_line_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_w_242);
    if (heff_strEq_c(v_line_243, ((V)&g_list_2efoldl_24f354261656x2102112793_str0))) {
      heff_drop(v_lit_240);
      return v_z_241;
    } else {
      return ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_intAdd(v_z_241, v_lit_240); V b_2 = NTAG(TAG_Nil); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    }
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_244, 0);
    V v_xs_246 = heff_field(v_x3_244, 1);
    if (heff_strEq_c_lent(v_line_243, ((V)&g_list_2efoldl_24f354261656x2102112793_str1), 2)) {
      heff_drop(v_line_243);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_w_242;
      V t_3 = heff_dup(v_x_245);
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_w_242 = t_2;
      v_line_243 = t_3;
      v_x3_244 = t_4;
      goto top;
    } else {
      V v_xs_247 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_line_243))));
      V v_t_248 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_247; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_247); r_; });
      V v_xs_249 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_x_245))));
      V v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_249; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_249); r_; });
      V v_t_2411 = heff_intAdd(heff_intAdd(v_t_248, MK_INT(1LL)), v_t_2410);
      if (heff_intLe_c_lent(v_t_2411, v_w_242, 1)) {
        V v_t_2412 = heff_strAppend(v_line_243, heff_strAppend(((V)&g_list_2efoldl_24f354261656x2102112793_str2), heff_dup(v_x_245)));
        V t_0 = v_lit_240;
        V t_1 = v_z_241;
        V t_2 = v_w_242;
        V t_3 = v_t_2412;
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_w_242 = t_2;
        v_line_243 = t_3;
        v_x3_244 = t_4;
        goto top;
      } else {
        heff_drop(v_line_243);
        V t_0 = heff_dup(v_lit_240);
        V t_1 = heff_intAdd(v_z_241, v_lit_240);
        V t_2 = v_w_242;
        V t_3 = heff_dup(v_x_245);
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_w_242 = t_2;
        v_line_243 = t_3;
        v_x3_244 = t_4;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24f354261656x2102112793_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2efoldl_24f354261656x2102112793(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
HEFF_LIT(g_list_2emap_24f310588246x1624488069_str0, 8, "browser.");
Clo g_list_2emap_24f310588246x1624488069_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f310588246x1624488069_entry, 4, 0};

V g_list_2emap_24f310588246x1624488069(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_library_246 = heff_take_field(v_x_244, 7);
    V v_module_247 = heff_get_n(v_x_244, 0, 8);
    if (((heff_dup(v_library_246) == NTAG(TAG_True)) && heff_strEq_c(heff_strSlice_lent(v_module_247, MK_INT(0LL), MK_INT(8LL), 6), ((V)&g_list_2emap_24f310588246x1624488069_str0)))) {
      heff_drop(v_library_246);
      V v_t_248 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_dup(v_module_247), heff_dup(v_lit_242)));
      V v_t_249 = heff_rec_n(4, shape_module__code__msg__note, (V[]){v_module_247, heff_dup(v_lit_240), v_t_248, NTAG(TAG_Nothing)});
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = (g_list_2emap_24f310588246x1624488069_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_library_246);
      heff_drop(v_module_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f310588246x1624488069_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f310588246x1624488069(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f2124896334x71745266_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2124896334x71745266_entry, 12, 0};

V g_list_2emap_24f2124896334x71745266(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_lit_244, V v_lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411) {
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_246 = heff_unbox_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_unbox_word(v_box_24lit_247);
  int64_t v_lit_2410 = heff_unbox_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24Cons = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_name_2414 = heff_take_field(v_x_2412, 0);
    V v_key_2415 = heff_get_n(v_x_2412, 1, 2);
    V v_a_2416 = heff_dup(v_name_2414);
    if ((heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_lit_241, v_a_2416, v_lit_242, 0)) ? (((v_lit_243 <= heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_245, 0)) <= v_lit_246)) ? 0 : ((v_lit_247 <= heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_248, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_249, 0)) <= v_lit_2410) : 1)) : 1)) {
      heff_drop(v_a_2416);
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_2411_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__key, (V[]){v_name_2414, v_key_2415}), heff_hole()});
      V v_u_2418 = (g_list_2emap_24f2124896334x71745266_24dps(v_lit_240, v_lit_241, v_lit_242, heff_box_word(v_lit_243), v_lit_244, v_lit_245, heff_box_word(v_lit_246), heff_box_word(v_lit_247), v_lit_248, v_lit_249, heff_box_word(v_lit_2410), v_xs_2413, heff_dup(v_cell_2417)));
      heff_drop(v_u_2418);
      return v_cell_2417;
    } else {
      heff_drop_cell(v_ru_24x2_2411_24Cons, 2);
      heff_drop(v_name_2414);
      heff_drop(v_key_2415);
      heff_drop(v_a_2416);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2emap_24f2124896334x71745266_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a8 = a[8]; V a9 = a[9]; V r = g_list_2emap_24f2124896334x71745266(a[0], a1, a2, a[3], a4, a5, a[6], a[7], a8, a9, a[10], a[11]); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a8); heff_drop(a9); return r;
}
Clo g_list_2emerge_24s2063716145x1843377885_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s2063716145x1843377885_24tok2_entry, 3, 0};

V g_list_2emerge_24s2063716145x1843377885_24tok2(V v_tok_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_x3_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_241, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop_rec(v_x_243, 4);
      heff_drop(v_xs_244);
      return v_x2_241;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      V v_t_247 = (g_heff_2ebuild_2ecommands_2eplaceBefore(heff_rfield(v_x_243, 1), heff_rfield(v_y_245, 1)));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_cell_248 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_249 = (g_list_2emerge_24s2063716145x1843377885_24dps(v_xs_244, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_245, v_ys_246}), heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      } else {
        heff_drop(v_t_247);
        V v_cell_2410 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2411 = (g_list_2emerge_24s2063716145x1843377885_24dps(heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_xs_244}), v_ys_246, heff_dup(v_cell_2410)));
        heff_drop(v_u_2411);
        return v_cell_2410;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_24s2063716145x1843377885_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s2063716145x1843377885_24tok2(a[0], a[1], a[2]);
}