// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CDecl 45531
#define TAG_EAbandon 62759
#define TAG_EInvalid 31081
#define TAG_ELet 43397
#define TAG_ESpec 56652
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_NoneGiven 36085
#define TAG_OfFixed 17267
#define TAG_OutCall 43778
#define TAG_OutOther 27005
#define TAG_OutRecord 63915
#define TAG_OutTag 45229
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_alias 294261354
#define LBL_arg 306384
#define LBL_args 9498020
#define LBL_bound 295286168
#define LBL_end 310101
#define LBL_fixed 298804110
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_labels 836724522
#define LBL_long 9823043
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_op 10312
#define LBL_path 9928940
#define LBL_required 351999471
#define LBL_start 311115900
#define LBL_syntax 1059664654
#define LBL_t 334
#define LBL_tag 324116
#define LBL_text 10052084
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224(V, V);
V g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224_clo;
V g_heff_2ecompile_2eborrow_2eloopLent(V, V, V, V);
V g_heff_2ecompile_2eborrow_2eloopLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eloopLent_clo;
V g_heff_2ecompile_2eborrow_2eonlyLent(V, V, V);
V g_heff_2ecompile_2eborrow_2eonlyLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eonlyLent_clo;
V g_heff_2ecompile_2eborrow_2ereusesHere(V, V);
V g_heff_2ecompile_2eborrow_2ereusesHere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ereusesHere_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2etupleRead(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etupleRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleRead_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2einterp_2eshowValGo_24tok1(V, V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_24tok1_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eranges_2erangeEq(V, V);
V g_heff_2ecompile_2eranges_2erangeEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangeEq_clo;
V g_heff_2ecompile_2erepr_2edecidedIn(V, V, V);
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecidedIn_clo;
V g_heff_2ecompile_2escalars_2egivenOf(V, V);
V g_heff_2ecompile_2escalars_2egivenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2egivenOf_clo;
V g_heff_2ecompile_2escalars_2eslotWith(V, V, V, V, V, V);
V g_heff_2ecompile_2escalars_2eslotWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotWith_clo;
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo;
V g_heff_2esyntax_2esurface_2eidentOf(V);
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eidentOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1375915522x445000623(V);
V g_list_2eany_24s1375915522x445000623_entry(V self, V *a);
extern Clo g_list_2eany_24s1375915522x445000623_clo;
V g_list_2eany_24s1631644720x1952242925(V, V);
V g_list_2eany_24s1631644720x1952242925_entry(V self, V *a);
extern Clo g_list_2eany_24s1631644720x1952242925_clo;
V g_list_2eany_24s1873156379x541659222(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eany_24s1873156379x541659222_entry(V self, V *a);
extern Clo g_list_2eany_24s1873156379x541659222_clo;
V g_list_2eany_24s1996181941x450667621(V, V);
V g_list_2eany_24s1996181941x450667621_entry(V self, V *a);
extern Clo g_list_2eany_24s1996181941x450667621_clo;
V g_list_2eany_24s332132496x946063656(V, V);
V g_list_2eany_24s332132496x946063656_entry(V self, V *a);
extern Clo g_list_2eany_24s332132496x946063656_clo;
V g_list_2eany_24s469347062x492258493(V);
V g_list_2eany_24s469347062x492258493_entry(V self, V *a);
extern Clo g_list_2eany_24s469347062x492258493_clo;
V g_list_2eany_24s577543654x765608923(V);
V g_list_2eany_24s577543654x765608923_entry(V self, V *a);
extern Clo g_list_2eany_24s577543654x765608923_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2eascending(V, V, V, V);
V g_list_2eascending_entry(V self, V *a);
extern Clo g_list_2eascending_clo;
V g_list_2edescending(V, V, V, V);
V g_list_2edescending_entry(V self, V *a);
extern Clo g_list_2edescending_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s151864352x1148566527_24cpr(V, V);
HeffT2 g_list_2efind_24s2013978071x937269256_24cpr(V, V);
V g_list_2efoldl_24f2071981990x435576741(V, V, V);
V g_list_2efoldl_24f2071981990x435576741_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2071981990x435576741_clo;
V g_list_2efoldl_24s1368043225x413679696(V, V, V);
V g_list_2efoldl_24s1368043225x413679696_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1368043225x413679696_clo;
V g_list_2efoldl_24s1551647072x1644392086(V, V);
V g_list_2efoldl_24s1551647072x1644392086_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1551647072x1644392086_clo;
V g_list_2efoldl_24s1980014771x775787011(V, V);
V g_list_2efoldl_24s1980014771x775787011_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1980014771x775787011_clo;
V g_list_2efoldl_24s2076975989x1982453350(V, V);
V g_list_2efoldl_24s2076975989x1982453350_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2076975989x1982453350_clo;
V g_list_2efoldl_24s2146051398x720013633(V, V);
V g_list_2efoldl_24s2146051398x720013633_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2146051398x720013633_clo;
V g_list_2efoldl_24s278088687x1269971185(V, V);
V g_list_2efoldl_24s278088687x1269971185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s278088687x1269971185_clo;
V g_list_2efoldl_24s455728131x407835966(V, V);
V g_list_2efoldl_24s455728131x407835966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s455728131x407835966_clo;
V g_list_2ekeepIf_24s1245654234x191876439_24dps(V, V);
V g_list_2ekeepIf_24s1245654234x191876439_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1245654234x191876439_24dps_clo;
V g_list_2ekeepIf_24s1823913665x1128491553_24dps(V, V, V);
V g_list_2ekeepIf_24s1823913665x1128491553_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1823913665x1128491553_24dps_clo;
V g_list_2ekeepIf_24s498754754x815116558(V, V, V, V, V, V);
V g_list_2ekeepIf_24s498754754x815116558_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s498754754x815116558_clo;
V g_list_2ekeepIf_24s498754754x815116558_24dps(V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s498754754x815116558_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s498754754x815116558_24dps_clo;
V g_list_2ekeepIf_24s949876182x1887521458_24dps(V, V);
V g_list_2ekeepIf_24s949876182x1887521458_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s949876182x1887521458_24dps_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1192859273x245815303(V, V, V, V, V, V, V);
V g_list_2emap_24s1192859273x245815303_entry(V self, V *a);
extern Clo g_list_2emap_24s1192859273x245815303_clo;
V g_list_2emap_24s1192859273x245815303_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1192859273x245815303_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1192859273x245815303_24dps_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s1281445768x1036802655_24dps(V, V);
V g_list_2emap_24s1281445768x1036802655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_24dps_clo;
V g_list_2emap_24s1310249268x749995235(V, V, V);
V g_list_2emap_24s1310249268x749995235_entry(V self, V *a);
extern Clo g_list_2emap_24s1310249268x749995235_clo;
V g_list_2emap_24s1310249268x749995235_24dps(V, V, V, V);
V g_list_2emap_24s1310249268x749995235_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1310249268x749995235_24dps_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1418269708x2034621695_24dps(V, V, V);
V g_list_2emap_24s1418269708x2034621695_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1418269708x2034621695_24dps_clo;
V g_list_2emap_24s1533895818x411093629(V);
V g_list_2emap_24s1533895818x411093629_entry(V self, V *a);
extern Clo g_list_2emap_24s1533895818x411093629_clo;
V g_list_2emap_24s1533895818x411093629_24dps(V, V);
V g_list_2emap_24s1533895818x411093629_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1533895818x411093629_24dps_clo;
V g_list_2emap_24s1566016224x493905666(V, V, V, V);
V g_list_2emap_24s1566016224x493905666_entry(V self, V *a);
extern Clo g_list_2emap_24s1566016224x493905666_clo;
V g_list_2emap_24s1566016224x493905666_24dps(V, V, V, V, V);
V g_list_2emap_24s1566016224x493905666_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1566016224x493905666_24dps_clo;
V g_list_2emap_24s1675313341x192238134_24dps(V, V);
V g_list_2emap_24s1675313341x192238134_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_24dps_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24dps(V, V);
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24dps_clo;
V g_list_2emap_24s1835183789x486277886(V);
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_clo;
V g_list_2emap_24s1835183789x486277886_24dps(V, V);
V g_list_2emap_24s1835183789x486277886_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_24dps_clo;
V g_list_2emap_24s1902028738x441242582(V);
V g_list_2emap_24s1902028738x441242582_entry(V self, V *a);
extern Clo g_list_2emap_24s1902028738x441242582_clo;
V g_list_2emap_24s1902028738x441242582_24dps(V, V);
V g_list_2emap_24s1902028738x441242582_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1902028738x441242582_24dps_clo;
V g_list_2emap_24s1996604328x2084368959(V);
V g_list_2emap_24s1996604328x2084368959_entry(V self, V *a);
extern Clo g_list_2emap_24s1996604328x2084368959_clo;
V g_list_2emap_24s1996604328x2084368959_24dps(V, V);
V g_list_2emap_24s1996604328x2084368959_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1996604328x2084368959_24dps_clo;
V g_list_2emap_24s2016093283x1174801437(V, V);
V g_list_2emap_24s2016093283x1174801437_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_clo;
V g_list_2emap_24s2016093283x1174801437_24dps(V, V, V);
V g_list_2emap_24s2016093283x1174801437_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_24dps_clo;
V g_list_2emap_24s2087317732x355496638(V);
V g_list_2emap_24s2087317732x355496638_entry(V self, V *a);
extern Clo g_list_2emap_24s2087317732x355496638_clo;
V g_list_2emap_24s2087317732x355496638_24dps(V, V);
V g_list_2emap_24s2087317732x355496638_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2087317732x355496638_24dps_clo;
V g_list_2emap_24s379205986x2089287346(V, V, V, V, V, V, V, V);
V g_list_2emap_24s379205986x2089287346_entry(V self, V *a);
extern Clo g_list_2emap_24s379205986x2089287346_clo;
V g_list_2emap_24s379205986x2089287346_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s379205986x2089287346_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s379205986x2089287346_24dps_clo;
V g_list_2emap_24s430074199x1834682414_24dps(V, V, V, V, V);
V g_list_2emap_24s430074199x1834682414_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s430074199x1834682414_24dps_clo;
V g_list_2emap_24s471405029x78128406(V);
V g_list_2emap_24s471405029x78128406_entry(V self, V *a);
extern Clo g_list_2emap_24s471405029x78128406_clo;
V g_list_2emap_24s471405029x78128406_24dps(V, V);
V g_list_2emap_24s471405029x78128406_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s471405029x78128406_24dps_clo;
V g_list_2emap_24s503834852x510769098(V, V);
V g_list_2emap_24s503834852x510769098_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_clo;
V g_list_2emap_24s503834852x510769098_24dps(V, V, V);
V g_list_2emap_24s503834852x510769098_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_24dps_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s60612435x257154841_24dps(V, V);
V g_list_2emap_24s60612435x257154841_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_24dps_clo;
V g_list_2emap_24s640776339x1223679834_24dps(V, V);
V g_list_2emap_24s640776339x1223679834_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_24dps_clo;
V g_list_2emap_24s698037429x265256386_24dps(V, V);
V g_list_2emap_24s698037429x265256386_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s698037429x265256386_24dps_clo;
V g_list_2emap_24s704486313x1071100879_24dps(V, V, V, V, V);
V g_list_2emap_24s704486313x1071100879_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s704486313x1071100879_24dps_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s725725455x1186198702_24dps(V, V);
V g_list_2emap_24s725725455x1186198702_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_24dps_clo;
V g_list_2emap_24s878634257x1677201747(V);
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_clo;
V g_list_2emap_24s878634257x1677201747_24dps(V, V);
V g_list_2emap_24s878634257x1677201747_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_24dps_clo;
V g_list_2emap_24s94933736x72301022(V);
V g_list_2emap_24s94933736x72301022_entry(V self, V *a);
extern Clo g_list_2emap_24s94933736x72301022_clo;
V g_list_2emap_24s94933736x72301022_24dps(V, V);
V g_list_2emap_24s94933736x72301022_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s94933736x72301022_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erunFrom(V, V, V);
V g_list_2erunFrom_entry(V self, V *a);
extern Clo g_list_2erunFrom_clo;
V g_list_2ezipWith_24s1604775524x1614188687_24dps(V, V, V, V);
V g_list_2ezipWith_24s1604775524x1614188687_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1604775524x1614188687_24dps_clo;
V g_list_2ezipWith_24s919837080x1979082626_24dps(V, V, V, V, V);
V g_list_2ezipWith_24s919837080x1979082626_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s919837080x1979082626_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_list_2eany_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_entry, 2, 0};

V g_list_2eany(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2erunFrom_clo = {{0x80000000u, K_CLO, 0}, g_list_2erunFrom_entry, 3, 0};

V g_list_2erunFrom(V v_le_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_244 = heff_field(v_x3_242, 0);
    V v_ys_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){heff_dup(v_x_241), heff_dup(v_y_244)}));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
      return (g_list_2eascending(v_le_240, heff_dup(v_y_244), heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_t_247}), v_ys_245));
    } else {
      heff_drop(v_t_246);
      V v_t_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
      return (g_list_2edescending(v_le_240, heff_dup(v_y_244), heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_t_248}), v_ys_245));
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2erunFrom_entry(V self, V *a) {
  (void)self;
  return g_list_2erunFrom(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s94933736x72301022_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s94933736x72301022_entry, 1, 0};

V g_list_2emap_24s94933736x72301022(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_fixed_243 = heff_take_field(v_x_241, 0);
    V v_op_244 = heff_get_n(v_x_241, 1, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OfFixed, 2, (V[]){v_fixed_243, v_op_244}), heff_hole()});
    V v_u_246 = (g_list_2emap_24s94933736x72301022_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s94933736x72301022_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s94933736x72301022(a[0]);
}
Clo g_list_2emap_24s1809017761x1063871171_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1809017761x1063871171_entry, 1, 0};

V g_list_2emap_24s1809017761x1063871171(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1809017761x1063871171_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1809017761x1063871171(a[0]);
}
Clo g_list_2ezipWith_24s1604775524x1614188687_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1604775524x1614188687_24dps_entry, 4, 0};

V g_list_2ezipWith_24s1604775524x1614188687_24dps(V v_lit_240, V v_x2_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_x3_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_242, 0);
      V v_ys_247 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_a_2410;
      switch (heff_tag_of(v_x_244)) {
      case TAG_MkPair: {
        V v_a_248 = heff_dup(heff_field(v_x_244, 0));
        v_a_2410 = v_a_248;
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      V v_a_2413;
      switch (heff_tag_of(v_x_244)) {
      case TAG_MkPair: {
        V v_a_2412 = heff_field(v_x_244, 1);
        heff_take_n(v_x_244, 2ULL, 2);
        v_a_2413 = v_a_2412;
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      V v_t_2417;
      switch (heff_tag_of(v_a_2413)) {
      case TAG_Unreached: {
        heff_drop(v_y_246);
        v_t_2417 = v_a_2410;
        break;
      }
      case TAG_Within: {
        V v_t_2416 = ({ V a_0 = v_a_2413; V a_1 = v_y_246; V r_ = (g_heff_2ecompile_2eranges_2erangeEq(a_0, a_1)); heff_drop_tag(v_a_2413, 2); heff_drop(v_y_246); r_; });
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop(v_t_2416);
          v_t_2417 = v_a_2410;
        } else {
          heff_drop(v_t_2416);
          v_t_2417 = heff_intAdd(v_a_2410, heff_dup(v_lit_240));
        }
        break;
      }
      default: heff_nomatch(v_a_2413);
      }
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
      V v_u_2419 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2418));
      heff_drop(v_u_2419);
      V t_0 = v_lit_240;
      V t_1 = v_xs_245;
      V t_2 = v_ys_247;
      V t_3 = v_cell_2418;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24s1604775524x1614188687_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1604775524x1614188687_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1835183789x486277886_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1835183789x486277886_entry, 1, 0};

V g_list_2emap_24s1835183789x486277886(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1835183789x486277886_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1835183789x486277886(a[0]);
}
Clo g_list_2eany_24s1996181941x450667621_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1996181941x450667621_entry, 2, 0};

V g_list_2eany_24s1996181941x450667621(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_x_242))) {
      heff_drop_rec(v_lit_240, 9);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1996181941x450667621_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1996181941x450667621(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s689038521x519269801_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s689038521x519269801_entry, 1, 0};

V g_list_2eany_24s689038521x519269801(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkSegment: {
        V v_ty_246 = heff_field(v_x11_243, 1);
        switch (heff_tag_of(v_ty_246)) {
        case TAG_SegmentInteger: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_SegmentBinary: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_SegmentBits: {
          return NTAG(TAG_True);
        }
        case TAG_SegmentFloat: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_SegmentUtf: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_ty_246);
        }
      }
      default: return heff_nomatch(v_x11_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s689038521x519269801_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s689038521x519269801(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s2016093283x1174801437_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2016093283x1174801437_entry, 2, 0};

V g_list_2emap_24s2016093283x1174801437(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2efieldDeclOf(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s2016093283x1174801437_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2016093283x1174801437_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2016093283x1174801437(a[0], a[1]);
}
Clo g_list_2emap_24s878634257x1677201747_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s878634257x1677201747_entry, 1, 0};

V g_list_2emap_24s878634257x1677201747(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2esyntax_2esurface_2eidentOf(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s878634257x1677201747_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s878634257x1677201747(a[0]);
}
Clo g_list_2efoldl_24s1368043225x413679696_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1368043225x413679696_entry, 3, 0};

V g_list_2efoldl_24s1368043225x413679696(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_SetField: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_249 = heff_field(v_a_245, 2);
        heff_take_n(v_a_245, 5ULL, 3);
        V v_t_2412;
        switch (heff_tag_of(v_z_241)) {
        case TAG_At: {
          V v_a_2411 = heff_dup(heff_field(v_z_241, 1));
          v_t_2412 = v_a_2411;
          break;
        }
        default: heff_nomatch(v_z_241);
        }
        V v_t_2413 = ({ V rv_1 = heff_dup(heff_rfield(v_a_246, 1)); V rr_ = heff_rec_reuse_nf(v_t_2412, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_ESpec, 4, (V[]){v_z_241, v_a_247, v_a_246, v_a_249}), v_t_2413});
        break;
      }
      case TAG_BadFieldSet: {
        V v_ru_24a_245_24BadFieldSet = heff_take_reuse_n(v_a_245, 0ULL, 1);
        heff_drop(v_z_241);
        v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_245_24BadFieldSet, TAG_EInvalid, 1, (V[]){heff_dup(v_lit_240)}), v_a_246});
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2415;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1368043225x413679696_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1368043225x413679696(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s60612435x257154841_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s60612435x257154841_entry, 1, 0};

V g_list_2emap_24s60612435x257154841(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_b_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 4ULL, 3);
      v_t_246 = v_b_245;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s60612435x257154841_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s60612435x257154841_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s60612435x257154841(a[0]);
}
Clo g_list_2eany_24s469347062x492258493_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s469347062x492258493_entry, 1, 0};

V g_list_2eany_24s469347062x492258493(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_RepV: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_RepFix: {
      return NTAG(TAG_True);
    }
    case TAG_RepF64: {
      return NTAG(TAG_True);
    }
    case TAG_RepInt: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s469347062x492258493_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s469347062x492258493(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1310249268x749995235_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1310249268x749995235_entry, 3, 0};

V g_list_2emap_24s1310249268x749995235(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2erepr_2edecidedIn(v_lit_240, v_lit_241, v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1310249268x749995235_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1310249268x749995235_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2emap_24s1310249268x749995235(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s498754754x815116558_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s498754754x815116558_entry, 6, 0};

V g_list_2ekeepIf_24s498754754x815116558(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_bor_248 = heff_dup(v_lit_240);
    V v_key_249 = heff_dup(v_lit_241);
    V v_xs_2410 = heff_dup(v_lit_242);
    V v_b_2411 = heff_dup(v_lit_243);
    V v_ds_2412 = heff_dup(v_lit_244);
    V v_i_2413 = heff_dup(v_x_246);
    HeffT3 v_t_2414 = ({ V a_0 = heff_dup(v_i_2413); V a_1 = v_xs_2410; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_xs_2410); r_; });
    V v_t_2424;
    {
      V v_field_2416 = v_t_2414.f[1];
      V v_field_2417 = v_t_2414.f[2];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        V v_p_2418 = v_field_2416;
        V v_x_2419 = v_field_2417;
        heff_drop(v_x_2419);
        V v_t_2420 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_248, heff_dup(v_p_2418), v_b_2411));
        if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
          heff_drop(v_t_2420);
          V v_t_2421 = (g_heff_2ecompile_2eborrow_2ereusesHere(v_p_2418, v_b_2411));
          if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
            heff_drop(v_key_249);
            heff_drop(v_b_2411);
            heff_drop(v_ds_2412);
            heff_drop(v_i_2413);
            heff_drop(v_p_2418);
            heff_drop(v_t_2421);
            v_t_2424 = NTAG(TAG_False);
          } else {
            heff_drop(v_t_2421);
            V v_t_2422 = (g_heff_2ecompile_2eir_2epartsOnto(heff_dup(v_b_2411), NTAG(TAG_Nil)));
            V v_x1_2423 = ({ V a_0 = v_p_2418; V a_1 = v_t_2422; V r_ = (g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224(a_0, a_1)); heff_drop(v_p_2418); r_; });
            if (!(heff_dup(v_x1_2423) == NTAG(TAG_True))) {
              heff_drop(v_x1_2423);
              v_t_2424 = ({ V a_0 = v_key_249; V a_1 = v_i_2413; V a_2 = v_ds_2412; V a_3 = v_b_2411; V r_ = (g_heff_2ecompile_2eborrow_2eloopLent(a_0, a_1, a_2, a_3)); heff_drop(v_b_2411); r_; });
            } else {
              heff_drop(v_key_249);
              heff_drop(v_b_2411);
              heff_drop(v_ds_2412);
              heff_drop(v_i_2413);
              heff_drop(v_x1_2423);
              v_t_2424 = NTAG(TAG_False);
            }
          }
        } else {
          heff_drop(v_key_249);
          heff_drop(v_b_2411);
          heff_drop(v_ds_2412);
          heff_drop(v_i_2413);
          heff_drop(v_p_2418);
          heff_drop(v_t_2420);
          v_t_2424 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_bor_248);
        heff_drop(v_key_249);
        heff_drop(v_b_2411);
        heff_drop(v_ds_2412);
        heff_drop(v_i_2413);
        heff_drop(v_field_2416);
        heff_drop(v_field_2417);
        v_t_2424 = NTAG(TAG_False);
      }
    }
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop(v_t_2424);
      V v_cell_2425 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
      V v_u_2426 = (g_list_2ekeepIf_24s498754754x815116558_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2425)));
      heff_drop(v_u_2426);
      return v_cell_2425;
    } else {
      heff_drop(v_x_246);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_t_2424);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2ekeepIf_24s498754754x815116558_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s498754754x815116558(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2eany_24s332132496x946063656_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s332132496x946063656_entry, 2, 0};

V g_list_2eany_24s332132496x946063656(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_lit_240, 0);
      v_t_249 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    if (heff_strEq_c(v_t_246, v_t_249)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s332132496x946063656_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s332132496x946063656(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s471405029x78128406_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s471405029x78128406_entry, 1, 0};

V g_list_2emap_24s471405029x78128406(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 7ULL, 3);
      v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_a_244}), heff_tag_n(TAG_ASts, 1, (V[]){v_a_245})});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s471405029x78128406_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s471405029x78128406_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s471405029x78128406(a[0]);
}
Clo g_list_2emap_24s698037429x265256386_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s698037429x265256386_24dps_entry, 2, 0};

V g_list_2emap_24s698037429x265256386_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDecl, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s698037429x265256386_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s698037429x265256386_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1980014771x775787011_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1980014771x775787011_entry, 2, 0};

V g_list_2efoldl_24s1980014771x775787011(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_OutTag: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_OutRecord: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_OutCall: {
      V v_a_248 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_248, NTAG(TAG_Nil)});
      break;
    }
    case TAG_OutOther: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_prelude_2e_2b_2b(v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1980014771x775787011_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1980014771x775787011(a[0], a[1]);
}
Clo g_list_2emap_24s1902028738x441242582_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1902028738x441242582_entry, 1, 0};

V g_list_2emap_24s1902028738x441242582(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    switch (heff_tag_of(v_x_241)) {
    case TAG_RepV: {
      v_t_244 = NTAG(TAG_FtOther);
      break;
    }
    case TAG_RepFix: {
      V v_w_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24RepFix = heff_take_reuse_n(v_x_241, 1ULL, 1);
      v_t_244 = heff_tag_at_n(v_ru_24x_241_24RepFix, TAG_FtFixed, 1, (V[]){v_w_243});
      break;
    }
    case TAG_RepF64: {
      v_t_244 = NTAG(TAG_FtFloat);
      break;
    }
    case TAG_RepInt: {
      v_t_244 = NTAG(TAG_FtOther);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1902028738x441242582_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1902028738x441242582_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1902028738x441242582(a[0]);
}

HeffT2 g_list_2efind_24s151864352x1148566527_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s2076975989x1982453350_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2076975989x1982453350_entry, 2, 0};

V g_list_2efoldl_24s2076975989x1982453350(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_x_242, 0), NTAG(TAG_Nil)));
    V v_t_245 = (g_list_2emap_24s1415906091x1371825187(v_t_244));
    V v_t_246 = ({ V a_0 = v_z_240; V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s278088687x1269971185(a_0, a_1)); heff_drop(v_t_245); r_; });
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2076975989x1982453350_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2076975989x1982453350(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1245654234x191876439_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1245654234x191876439_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1245654234x191876439_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2439;
    switch (heff_tag_of(v_x_242)) {
    case TAG_SLocal: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SGlobal: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SCode: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SApp: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLam: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SCons: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SProj: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_STag: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SMatch: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SSpecialize: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SIs: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SOpaque: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SAbandon: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SRec: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SFix: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SImplicit: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_SPrim: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SMetaApp: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitInt: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFloat: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitString: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitBytes: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitRune: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFixed: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFloat32: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
      heff_drop(v_t_2439);
      V v_cell_2440 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2441 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2440));
      heff_drop(v_u_2441);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2440;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_2439);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1245654234x191876439_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1245654234x191876439_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s1873156379x541659222_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1873156379x541659222_entry, 11, 0};

V g_list_2eany_24s1873156379x541659222(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_box_24lit_249, V v_x2_2410) {
  int64_t v_lit_249 = heff_unbox_word(v_box_24lit_249);
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    V v_t_2413 = heff_dup(heff_rfield(v_x_2411, 2));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_FtFloat: {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      int64_t t_9 = v_lit_249;
      V t_10 = v_xs_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_x2_2410 = t_10;
      goto top;
    }
    case TAG_FtFixed: {
      V v_a_2414 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 1);
      V v_t_2415;
      switch (heff_tag_of(v_a_2414)) {
      case TAG_I8: {
        v_t_2415 = heff_dup(v_lit_240);
        break;
      }
      case TAG_I16: {
        v_t_2415 = heff_dup(v_lit_241);
        break;
      }
      case TAG_I32: {
        v_t_2415 = heff_dup(v_lit_242);
        break;
      }
      case TAG_I64: {
        v_t_2415 = heff_dup(v_lit_243);
        break;
      }
      case TAG_U8: {
        v_t_2415 = heff_dup(v_lit_244);
        break;
      }
      case TAG_U16: {
        v_t_2415 = heff_dup(v_lit_245);
        break;
      }
      case TAG_U32: {
        v_t_2415 = heff_dup(v_lit_246);
        break;
      }
      case TAG_U64: {
        v_t_2415 = heff_dup(v_lit_247);
        break;
      }
      case TAG_F32: {
        v_t_2415 = heff_dup(v_lit_248);
        break;
      }
      default: heff_nomatch(v_a_2414);
      }
      if (!(heff_peek_word(v_t_2415) == v_lit_249)) {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        heff_drop(v_lit_243);
        heff_drop(v_lit_244);
        heff_drop(v_lit_245);
        heff_drop(v_lit_246);
        heff_drop(v_lit_247);
        heff_drop(v_lit_248);
        heff_drop(v_t_2415);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2415);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_lit_245;
        V t_6 = v_lit_246;
        V t_7 = v_lit_247;
        V t_8 = v_lit_248;
        int64_t t_9 = v_lit_249;
        V t_10 = v_xs_2412;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_lit_245 = t_5;
        v_lit_246 = t_6;
        v_lit_247 = t_7;
        v_lit_248 = t_8;
        v_lit_249 = t_9;
        v_x2_2410 = t_10;
        goto top;
      }
    }
    case TAG_FtOther: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_lit_247);
      heff_drop(v_lit_248);
      return NTAG(TAG_True);
    }
    case TAG_FtAny: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_lit_247);
      heff_drop(v_lit_248);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2eany_24s1873156379x541659222_entry(V self, V *a) {
  (void)self;
  V a10 = a[10]; V r = g_list_2eany_24s1873156379x541659222(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a10); heff_drop(a10); return r;
}
Clo g_list_2efoldl_24s455728131x407835966_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s455728131x407835966_entry, 2, 0};

V g_list_2efoldl_24s455728131x407835966(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_z_240)) {
    case TAG_Nothing: {
      v_t_246 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_a_244 = heff_field(v_z_240, 0);
      V v_ru_24z_240_24Just = heff_take_reuse_n(v_z_240, 1ULL, 1);
      switch (heff_tag_of(v_x_242)) {
      case TAG_Nothing: {
        heff_drop(v_a_244);
        heff_drop_cell(v_ru_24z_240_24Just, 1);
        v_t_246 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_b_245 = heff_field(v_x_242, 0);
        v_t_246 = heff_tag_at_n(v_ru_24z_240_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_244, heff_dup(v_b_245))});
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s455728131x407835966_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s455728131x407835966(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1375915522x445000623_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1375915522x445000623_entry, 1, 0};

V g_list_2eany_24s1375915522x445000623(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Nothing: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_a_243 = heff_field(v_x_241, 0);
      if ((heff_dup(v_a_243) == NTAG(TAG_True))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1375915522x445000623_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1375915522x445000623(a0); heff_drop(a0); return r;
}

HeffT2 g_list_2efind_24s2013978071x937269256_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_247 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_list_2ezipWith_24s919837080x1979082626_24dps_lam0(V self, V *args);
Clo g_list_2ezipWith_24s919837080x1979082626_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s919837080x1979082626_24dps_entry, 5, 0};

V g_list_2ezipWith_24s919837080x1979082626_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_x3_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_x3_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_242, 0);
    V v_xs_246 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_x_245);
      heff_drop(v_xs_246);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_x3_243, 0);
      V v_ys_248 = heff_field(v_x3_243, 1);
      V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
      V v_kind_249 = heff_dup(v_lit_240);
      V v_c_2410 = heff_dup(v_lit_241);
      V v_p_2411 = v_x_245;
      V v_i_2412 = v_y_247;
      V v_gs_2421 = (g_list_2emap_24tok2(v_ru_24x3_243_24Cons, heff_clo_n(g_list_2ezipWith_24s919837080x1979082626_24dps_lam0, 1, 2, (V[]){heff_dup(v_i_2412), heff_dup(v_p_2411)}), heff_dup(heff_rfield(v_c_2410, 3))));
      V v_t_2422 = (g_list_2efoldl_24f2071981990x435576741(MK_INT(1LL), MK_INT(0LL), v_gs_2421));
      V v_t_2423 = (g_list_2efoldl_24s1551647072x1644392086(NTAG(TAG_NoneGiven), v_gs_2421));
      V v_t_2424 = ({ V a_0 = v_kind_249; V a_1 = v_c_2410; V a_2 = v_i_2412; V a_3 = v_p_2411; V a_4 = v_t_2422; V a_5 = v_t_2423; V r_ = (g_heff_2ecompile_2escalars_2eslotWith(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_kind_249); r_; });
      V v_cell_2425 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2424, heff_hole()});
      V v_u_2426 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2425));
      heff_drop(v_u_2426);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_246;
      V t_3 = v_ys_248;
      V t_4 = v_cell_2425;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_x3_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ezipWith_24s919837080x1979082626_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s919837080x1979082626_24dps(a[0], a[1], a[2], a[3], a[4]);
}
V g_list_2ezipWith_24s919837080x1979082626_24dps_lam0(V self, V *args) {
  V v_args_2413 = args[0];
  V v_i_2412 = heff_env(self)[0];
  V v_p_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT3 v_t_2414 = ({ V a_0 = v_i_2412; V a_1 = v_args_2413; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_args_2413); r_; });
  V v_t_2420;
  {
    V v_field_2416 = v_t_2414.f[1];
    V v_field_2417 = v_t_2414.f[2];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2416;
      V v_x12_2419 = v_field_2417;
      heff_drop(v_x12_2419);
      v_t_2420 = v_x_2418;
    } else {
      heff_drop(v_field_2416);
      heff_drop(v_field_2417);
      v_t_2420 = NTAG(TAG_EAbandon);
    }
  }
  return ({ V a_0 = v_p_2411; V a_1 = v_t_2420; V r_ = (g_heff_2ecompile_2escalars_2egivenOf(a_0, a_1)); heff_drop(v_p_2411); r_; });
}
Clo g_list_2efoldl_24s2146051398x720013633_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2146051398x720013633_entry, 2, 0};

V g_list_2efoldl_24s2146051398x720013633(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_t_248;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      v_t_248 = v_z_240;
      break;
    }
    case TAG_Just: {
      V v_a_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      switch (heff_tag_of(v_a_245)) {
      case TAG_MkPair: {
        V v_a_246 = heff_field(v_a_245, 0);
        V v_a_247 = heff_field(v_a_245, 1);
        heff_take_n(v_a_245, 3ULL, 2);
        v_t_248 = heff_tag_n(TAG_ELet, 3, (V[]){v_a_246, v_a_247, v_z_240});
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2146051398x720013633_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2146051398x720013633(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s503834852x510769098_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s503834852x510769098_entry, 2, 0};

V g_list_2emap_24s503834852x510769098(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_x_242; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_244), heff_hole()});
    V v_u_246 = (g_list_2emap_24s503834852x510769098_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s503834852x510769098_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s503834852x510769098(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s949876182x1887521458_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s949876182x1887521458_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s949876182x1887521458_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_247 = heff_bool(heff_strEq_c(heff_dup(v_a_244), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get())));
      heff_drop(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (!(heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_243;
      V t_1 = v_cell_248;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s949876182x1887521458_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s949876182x1887521458_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s640776339x1223679834_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s640776339x1223679834_24dps_entry, 2, 0};

V g_list_2emap_24s640776339x1223679834_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s640776339x1223679834_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s640776339x1223679834_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s379205986x2089287346_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s379205986x2089287346_entry, 8, 0};

V g_list_2emap_24s379205986x2089287346(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkDrop: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      switch (heff_tag_of(v_a_2411)) {
      case TAG_Nothing: {
        V v_t_2412 = ({ V a_0 = v_a_2410; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_a_2410); r_; });
        V v_t_2413 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), v_t_2412));
        v_t_2415 = heff_strAppend(v_t_2413, heff_dup(v_lit_245));
        break;
      }
      case TAG_Just: {
        V v_a_2414 = heff_field(v_a_2411, 0);
        heff_take_n(v_a_2411, 1ULL, 1);
        v_t_2415 = ({ V a_0 = v_a_2410; V a_1 = v_a_2414; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_a_2410); heff_drop(v_a_2414); r_; });
        break;
      }
      default: heff_nomatch(v_a_2411);
      }
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2415, heff_dup(v_lit_246)), heff_hole()});
    V v_u_2417 = (g_list_2emap_24s379205986x2089287346_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s379205986x2089287346_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s379205986x2089287346(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2emap_24s430074199x1834682414_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s430074199x1834682414_24dps_entry, 5, 0};

V g_list_2emap_24s430074199x1834682414_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_lit_242; V a_3 = v_x_245; V r_ = (g_heff_2ecompile_2eemitc_2etupleRead(a_0, a_1, a_2, a_3)); heff_drop(v_x_245); r_; });
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s430074199x1834682414_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s430074199x1834682414_24dps(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1418269708x2034621695_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1418269708x2034621695_24dps_entry, 3, 0};

V g_list_2emap_24s1418269708x2034621695_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_strSlice(heff_dup(v_x_243), heff_dup(v_lit_240), heff_strLength(v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1418269708x2034621695_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1418269708x2034621695_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1566016224x493905666_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1566016224x493905666_entry, 4, 0};

V g_list_2emap_24s1566016224x493905666(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_244, 1));
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_249 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(v_t_248));
    V v_t_2412;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_244, 0);
      heff_take_n(v_x_244, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_249, heff_dup(v_lit_241)), v_t_2412);
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, heff_dup(v_lit_242)), heff_hole()});
    V v_u_2415 = (g_list_2emap_24s1566016224x493905666_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1566016224x493905666_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1566016224x493905666(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1566016224x493905666_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1566016224x493905666_24dps_entry, 5, 0};

V g_list_2emap_24s1566016224x493905666_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_245, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2410 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(v_t_249));
    V v_t_2413;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_245, 0);
      heff_take_n(v_x_245, 1ULL, 2);
      v_t_2413 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2410, heff_dup(v_lit_241)), v_t_2413);
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2414, heff_dup(v_lit_242)), heff_hole()});
    V v_u_2416 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1566016224x493905666_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1566016224x493905666_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2ekeepIf_24s1823913665x1128491553_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1823913665x1128491553_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1823913665x1128491553_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(v_x_243), heff_dup(heff_rfield(v_lit_240, 1)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1823913665x1128491553_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1823913665x1128491553_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s704486313x1071100879_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s704486313x1071100879_24dps_entry, 5, 0};

V g_list_2emap_24s704486313x1071100879_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_module_247 = heff_take_field(v_x_245, 0);
    V v_alias_248 = heff_get_n(v_x_245, 1, 2);
    V v_t_249 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_module_247), heff_dup(v_lit_241));
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, v_alias_248), heff_dup(v_lit_242));
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2411;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s704486313x1071100879_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s704486313x1071100879_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2eany_24s1631644720x1952242925_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1631644720x1952242925_entry, 2, 0};

V g_list_2eany_24s1631644720x1952242925(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1631644720x1952242925_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1631644720x1952242925(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1192859273x245815303_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1192859273x245815303_entry, 7, 0};

V g_list_2emap_24s1192859273x245815303(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_a_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_a_2412 = (g_prelude_2esplit_2esplitFrom_240(v_a_2411, v_lit_240, heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_a_2411, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_t_2417;
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2411, heff_dup(v_lit_244)});
      break;
    }
    case TAG_Cons: {
      V v_a_2413 = heff_field(v_a_2412, 0);
      V v_a_2414 = heff_field(v_a_2412, 1);
      V v_ru_24a_2412_24Cons = heff_take_reuse_n(v_a_2412, 3ULL, 2);
      switch (heff_tag_of(v_a_2414)) {
      case TAG_Nil: {
        heff_drop(v_a_2413);
        v_t_2417 = heff_tag_at_n(v_ru_24a_2412_24Cons, TAG_MkPair, 2, (V[]){v_a_2411, heff_dup(v_lit_245)});
        break;
      }
      case TAG_Cons: {
        V v_a_2415 = heff_field(v_a_2414, 0);
        heff_take_n(v_a_2414, 1ULL, 2);
        heff_drop(v_a_2411);
        v_t_2417 = heff_tag_at_n(v_ru_24a_2412_24Cons, TAG_MkPair, 2, (V[]){v_a_2413, v_a_2415});
        break;
      }
      default: heff_nomatch(v_a_2414);
      }
      break;
    }
    default: heff_nomatch(v_a_2412);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = (g_list_2emap_24s1192859273x245815303_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s1192859273x245815303_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24s1192859273x245815303(a0, a[1], a2, a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2emap_24s2087317732x355496638_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2087317732x355496638_entry, 1, 0};

V g_list_2emap_24s2087317732x355496638(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 5), heff_hole()});
    V v_u_244 = (g_list_2emap_24s2087317732x355496638_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2087317732x355496638_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2087317732x355496638(a[0]);
}
Clo g_list_2emap_24s1996604328x2084368959_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1996604328x2084368959_entry, 1, 0};

V g_list_2emap_24s1996604328x2084368959(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_k_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_k_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_x2_249 = heff_get_n(v_t_248, 0, 4);
    V v_t_2445;
    switch (heff_tag_of(v_x2_249)) {
    case TAG_SLocal: {
      heff_take_n(v_x2_249, 0ULL, 1);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SGlobal: {
      heff_take_n(v_x2_249, 0ULL, 1);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SCode: {
      heff_take_n(v_x2_249, 0ULL, 1);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SApp: {
      heff_take_n(v_x2_249, 0ULL, 2);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      heff_take_n(v_x2_249, 0ULL, 2);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SCons: {
      heff_take_n(v_x2_249, 0ULL, 1);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      heff_take_n(v_x2_249, 0ULL, 2);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      heff_take_n(v_x2_249, 0ULL, 2);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SMatch: {
      heff_take_n(v_x2_249, 0ULL, 2);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SSpecialize: {
      heff_take_n(v_x2_249, 0ULL, 3);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SIs: {
      heff_take_n(v_x2_249, 0ULL, 1);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SOpaque: {
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SAbandon: {
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      heff_take_n(v_x2_249, 0ULL, 1);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFix: {
      heff_take_n(v_x2_249, 0ULL, 2);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SImplicit: {
      heff_take_n(v_x2_249, 0ULL, 2);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrim: {
      V v_ru_24x2_249_24SPrim = heff_take_reuse_n(v_x2_249, 0ULL, 1);
      v_t_2445 = heff_tag_at_n(v_ru_24x2_249_24SPrim, TAG_Just, 1, (V[]){v_k_245});
      break;
    }
    case TAG_SMetaApp: {
      heff_take_n(v_x2_249, 0ULL, 3);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitInt: {
      heff_take_n(v_x2_249, 0ULL, 1);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFloat: {
      heff_take_na(v_x2_249, 0ULL, 1);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitString: {
      heff_take_n(v_x2_249, 0ULL, 1);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitBytes: {
      heff_take_n(v_x2_249, 0ULL, 1);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitRune: {
      heff_take_n(v_x2_249, 0ULL, 1);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFixed: {
      heff_take_n(v_x2_249, 0ULL, 2);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_x2_249, 0ULL, 1);
      heff_drop(v_k_245);
      v_t_2445 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x2_249);
    }
    V v_cell_2446 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2445, heff_hole()});
    V v_u_2447 = (g_list_2emap_24s1996604328x2084368959_24dps(v_xs_242, heff_dup(v_cell_2446)));
    heff_drop(v_u_2447);
    return v_cell_2446;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1996604328x2084368959_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1996604328x2084368959(a[0]);
}
Clo g_list_2emap_24s1675313341x192238134_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1675313341x192238134_24dps_entry, 2, 0};

V g_list_2emap_24s1675313341x192238134_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_MkEquation: {
        V v_fsp_247 = heff_field(v_x11_244, 1);
        heff_take_n(v_x11_244, 2ULL, 4);
        v_t_2410 = v_fsp_247;
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1675313341x192238134_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1675313341x192238134_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2eany_24s577543654x765608923_str0, 12, "-- fmt: skip");
Clo g_list_2eany_24s577543654x765608923_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s577543654x765608923_entry, 1, 0};

V g_list_2eany_24s577543654x765608923(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_s_243 = heff_dup(heff_rfield(v_x_241, 0));
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(v_s_243, heff_strLength_lent(v_s_243, 0)));
    if (heff_strEq_c(heff_strSlice(v_s_243, MK_INT(0LL), v_t_244), ((V)&g_list_2eany_24s577543654x765608923_str0))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s577543654x765608923_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s577543654x765608923(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s725725455x1186198702_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s725725455x1186198702_entry, 1, 0};

V g_list_2emap_24s725725455x1186198702(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(v_x_241, heff_strLength_lent(v_x_241, 0)));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_x_241, MK_INT(0LL), v_t_243), heff_hole()});
    V v_u_245 = (g_list_2emap_24s725725455x1186198702_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s725725455x1186198702(a[0]);
}
Clo g_list_2emap_24s1533895818x411093629_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1533895818x411093629_entry, 1, 0};

V g_list_2emap_24s1533895818x411093629(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2edriver_2elean(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1533895818x411093629_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1533895818x411093629_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1533895818x411093629(a[0]);
}
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_str1, 3, "[--");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_str2, 1, "]");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_str3, 2, "--");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_str4, 1, "=");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_str5, 3, "[--");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_str6, 1, " ");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_str7, 1, "]");
Clo g_list_2emap_24s1281445768x1036802655_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1281445768x1036802655_entry, 1, 0};

V g_list_2emap_24s1281445768x1036802655(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_f_243 = v_x_241;
    V v_meta_244 = heff_take_field(v_f_243, 2);
    V v_long_245 = heff_take_field(v_f_243, 0);
    V v_required_246 = heff_get_n(v_f_243, 6, 8);
    V v_t_249;
    if (heff_strEq_c_lent(v_meta_244, ((V)&g_list_2emap_24s1281445768x1036802655_str0), 2)) {
      heff_drop(v_meta_244);
      heff_drop(v_required_246);
      v_t_249 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1281445768x1036802655_str1), v_long_245), ((V)&g_list_2emap_24s1281445768x1036802655_str2));
    } else {
      if ((heff_dup(v_required_246) == NTAG(TAG_True))) {
        heff_drop(v_required_246);
        V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1281445768x1036802655_str3), v_long_245), ((V)&g_list_2emap_24s1281445768x1036802655_str4));
        v_t_249 = heff_strAppend(v_t_247, v_meta_244);
      } else {
        heff_drop(v_required_246);
        V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1281445768x1036802655_str5), v_long_245), ((V)&g_list_2emap_24s1281445768x1036802655_str6));
        v_t_249 = heff_strAppend(heff_strAppend(v_t_248, v_meta_244), ((V)&g_list_2emap_24s1281445768x1036802655_str7));
      }
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s1281445768x1036802655_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1281445768x1036802655(a[0]);
}