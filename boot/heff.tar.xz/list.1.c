// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_EInvalid 31081
#define TAG_EProject 35489
#define TAG_ESpec 56652
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_ImplicitParam 51130
#define TAG_Kept 49931
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Pinned 8573
#define TAG_RLocal 34280
#define TAG_RepV 61860
#define TAG_SError 24172
#define TAG_SGlobal 8650
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_TagVariant 25174
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unboxed 46787
#define TAG_Wants 58903
#define LBL_arg 306384
#define LBL_args 9498020
#define LBL_assoc 294479919
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_el 9998
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_from 9647217
#define LBL_id 10114
#define LBL_key 315609
#define LBL_label 304085774
#define LBL_local 304503685
#define LBL_loosest 581880769
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ok 10307
#define LBL_ops 319788
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_refs 9991943
#define LBL_severity 75955546
#define LBL_shown 310772011
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_use 325633
#define LBL_uses 10094739
#define LBL_value 313331083
#define LBL_version 583465758
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_name__args[] = {LBL_name, LBL_args};
static uint32_t shape_name__field__use[] = {LBL_name, LBL_field, LBL_use};
static uint32_t shape_name__key__module[] = {LBL_name, LBL_key, LBL_module};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
V g_heff_2ebuild_2edriver_2ehint(V);
V g_heff_2ebuild_2edriver_2ehint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ehint_clo;
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2earity_2earityOne(V, V);
V g_heff_2ecompile_2earity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earity_2earityOne_clo;
V g_heff_2ecompile_2eemit_2ehostLineOf(V);
V g_heff_2ecompile_2eemit_2ehostLineOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehostLineOf_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeRes(V);
V g_heff_2ecompile_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeRes_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemitc_2elastDotGo(V, V, V);
V g_heff_2ecompile_2eemitc_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elastDotGo_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2efacts_2elazyOf(V, V, V);
V g_heff_2ecompile_2efacts_2elazyOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2elazyOf_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2espec_2ebindOne(V, V);
V g_heff_2ecompile_2espec_2ebindOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ebindOne_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2elocals_2edeclaration(V);
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclaration_clo;
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(V);
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2einlineDoc(V);
V g_heff_2esyntax_2efmt_2elayout_2einlineDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2einlineDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2eimport_2eimplicitImports_get(void);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo;
V g_heff_2esyntax_2esurface_2eidentOf(V);
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eidentOf_clo;
V g_heff_2eutil_2ejson_2eescapeGo(V, V, V);
V g_heff_2eutil_2ejson_2eescapeGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2eescapeGo_clo;
V g_heff_2eutil_2ejson_2estringify(V);
V g_heff_2eutil_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2estringify_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s120814613x1439363162(V, V);
V g_list_2eany_24s120814613x1439363162_entry(V self, V *a);
extern Clo g_list_2eany_24s120814613x1439363162_clo;
V g_list_2eany_24s1375915522x445000623(V);
V g_list_2eany_24s1375915522x445000623_entry(V self, V *a);
extern Clo g_list_2eany_24s1375915522x445000623_clo;
V g_list_2eany_24s1523549873x2075662238(V, V);
V g_list_2eany_24s1523549873x2075662238_entry(V self, V *a);
extern Clo g_list_2eany_24s1523549873x2075662238_clo;
V g_list_2eany_24s195269671x277329476(V, V);
V g_list_2eany_24s195269671x277329476_entry(V self, V *a);
extern Clo g_list_2eany_24s195269671x277329476_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
V g_list_2eany_24s577543654x765608923(V);
V g_list_2eany_24s577543654x765608923_entry(V self, V *a);
extern Clo g_list_2eany_24s577543654x765608923_clo;
V g_list_2eany_24s698149710x1824282627(V, V, V, V);
V g_list_2eany_24s698149710x1824282627_entry(V self, V *a);
extern Clo g_list_2eany_24s698149710x1824282627_clo;
V g_list_2eany_24s762674996x1009180162(V);
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a);
extern Clo g_list_2eany_24s762674996x1009180162_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1490692278x809324339(V);
V g_list_2efilter_24s1490692278x809324339_entry(V self, V *a);
extern Clo g_list_2efilter_24s1490692278x809324339_clo;
V g_list_2efilter_24s1490692278x809324339_24dps(V, V);
V g_list_2efilter_24s1490692278x809324339_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1490692278x809324339_24dps_clo;
V g_list_2efilter_24s1623010005x1805617852(V);
V g_list_2efilter_24s1623010005x1805617852_entry(V self, V *a);
extern Clo g_list_2efilter_24s1623010005x1805617852_clo;
V g_list_2efilter_24s1623010005x1805617852_24dps(V, V);
V g_list_2efilter_24s1623010005x1805617852_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1623010005x1805617852_24dps_clo;
V g_list_2efilter_24s2128134357x1680551385(V, V);
V g_list_2efilter_24s2128134357x1680551385_entry(V self, V *a);
extern Clo g_list_2efilter_24s2128134357x1680551385_clo;
V g_list_2efilter_24s2128134357x1680551385_24dps(V, V, V);
V g_list_2efilter_24s2128134357x1680551385_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2128134357x1680551385_24dps_clo;
V g_list_2efilter_24s50027113x1989932102(V, V);
V g_list_2efilter_24s50027113x1989932102_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_clo;
V g_list_2efilter_24s50027113x1989932102_24dps(V, V, V);
V g_list_2efilter_24s50027113x1989932102_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_24dps_clo;
V g_list_2efilter_24s716173495x680820632_24dps(V, V, V);
V g_list_2efilter_24s716173495x680820632_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s716173495x680820632_24dps_clo;
V g_list_2efilter_24s951260806x709953240_24dps(V, V, V);
V g_list_2efilter_24s951260806x709953240_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s951260806x709953240_24dps_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efind_24s1085725546x1737150855(V, V);
V g_list_2efind_24s1085725546x1737150855_entry(V self, V *a);
extern Clo g_list_2efind_24s1085725546x1737150855_clo;
V g_list_2efind_24s1637307977x1351693783(V, V, V, V, V, V);
V g_list_2efind_24s1637307977x1351693783_entry(V self, V *a);
extern Clo g_list_2efind_24s1637307977x1351693783_clo;
V g_list_2efind_24s2097169879x1343877600(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efind_24s2097169879x1343877600_entry(V self, V *a);
extern Clo g_list_2efind_24s2097169879x1343877600_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24f421425463x1941958307(V, V, V);
V g_list_2efoldl_24f421425463x1941958307_entry(V self, V *a);
extern Clo g_list_2efoldl_24f421425463x1941958307_clo;
V g_list_2efoldl_24f556306710x2087456230(V, V, V, V);
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a);
extern Clo g_list_2efoldl_24f556306710x2087456230_clo;
V g_list_2efoldl_24f675617784x1820039874(V, V);
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a);
extern Clo g_list_2efoldl_24f675617784x1820039874_clo;
V g_list_2efoldl_24s1002907040x997927369(V, V);
V g_list_2efoldl_24s1002907040x997927369_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1002907040x997927369_clo;
V g_list_2efoldl_24s1048046132x95752937(V, V);
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1048046132x95752937_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1368043225x413679696(V, V, V);
V g_list_2efoldl_24s1368043225x413679696_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1368043225x413679696_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1577366920x1019062938(V, V);
V g_list_2efoldl_24s1577366920x1019062938_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1577366920x1019062938_clo;
V g_list_2efoldl_24s1748401606x190338434(V, V);
V g_list_2efoldl_24s1748401606x190338434_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1748401606x190338434_clo;
V g_list_2efoldl_24s1915639815x253536901(V, V);
V g_list_2efoldl_24s1915639815x253536901_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1915639815x253536901_clo;
V g_list_2efoldl_24s1991317015x801331450(V, V);
V g_list_2efoldl_24s1991317015x801331450_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1991317015x801331450_clo;
V g_list_2efoldl_24s2145639387x28888241(V, V, V, V);
V g_list_2efoldl_24s2145639387x28888241_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2145639387x28888241_clo;
V g_list_2efoldl_24s306513717x1560435942(V, V);
V g_list_2efoldl_24s306513717x1560435942_entry(V self, V *a);
extern Clo g_list_2efoldl_24s306513717x1560435942_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s455728131x407835966(V, V);
V g_list_2efoldl_24s455728131x407835966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s455728131x407835966_clo;
V g_list_2efoldl_24s496727651x1448898893(V, V);
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a);
extern Clo g_list_2efoldl_24s496727651x1448898893_clo;
V g_list_2efoldl_24s525916660x1238865713(V, V);
V g_list_2efoldl_24s525916660x1238865713_entry(V self, V *a);
extern Clo g_list_2efoldl_24s525916660x1238865713_clo;
V g_list_2efoldl_24s560581624x1100110660(V, V, V);
V g_list_2efoldl_24s560581624x1100110660_entry(V self, V *a);
extern Clo g_list_2efoldl_24s560581624x1100110660_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s776002836x391891384(V, V);
V g_list_2efoldl_24s776002836x391891384_entry(V self, V *a);
extern Clo g_list_2efoldl_24s776002836x391891384_clo;
V g_list_2efoldl_24s865198748x12535471(V, V);
V g_list_2efoldl_24s865198748x12535471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s865198748x12535471_clo;
V g_list_2efoldl_24s883603918x1469273954(V, V);
V g_list_2efoldl_24s883603918x1469273954_entry(V self, V *a);
extern Clo g_list_2efoldl_24s883603918x1469273954_clo;
V g_list_2efoldl_24s96111113x2107485159(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s96111113x2107485159_entry(V self, V *a);
extern Clo g_list_2efoldl_24s96111113x2107485159_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24dps(V, V, V);
V g_list_2emap_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24dps_clo;
V g_list_2emap_24f1133029339x682401273_24dps(V, V);
V g_list_2emap_24f1133029339x682401273_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1133029339x682401273_24dps_clo;
V g_list_2emap_24f1229912102x1467950109_24dps(V, V, V);
V g_list_2emap_24f1229912102x1467950109_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_24dps_clo;
V g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps(V, V, V, V, V);
V g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps_clo;
V g_list_2emap_24f1352858702x862623587(V, V, V, V, V);
V g_list_2emap_24f1352858702x862623587_entry(V self, V *a);
extern Clo g_list_2emap_24f1352858702x862623587_clo;
V g_list_2emap_24f1352858702x862623587_24dps(V, V, V, V, V, V);
V g_list_2emap_24f1352858702x862623587_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1352858702x862623587_24dps_clo;
V g_list_2emap_24f1502491305x440718220(V, V);
V g_list_2emap_24f1502491305x440718220_entry(V self, V *a);
extern Clo g_list_2emap_24f1502491305x440718220_clo;
V g_list_2emap_24f1502491305x440718220_24dps(V, V, V);
V g_list_2emap_24f1502491305x440718220_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1502491305x440718220_24dps_clo;
V g_list_2emap_24f489129082x766375942_24dps(V, V, V, V, V, V);
V g_list_2emap_24f489129082x766375942_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f489129082x766375942_24dps_clo;
V g_list_2emap_24f768999161x1997188166_24dps(V, V, V, V);
V g_list_2emap_24f768999161x1997188166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f768999161x1997188166_24dps_clo;
V g_list_2emap_24f783067987x1926181389_24dps(V, V, V, V, V, V);
V g_list_2emap_24f783067987x1926181389_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f783067987x1926181389_24dps_clo;
V g_list_2emap_24s1059370217x1267747283_24dps(V, V);
V g_list_2emap_24s1059370217x1267747283_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_24dps_clo;
V g_list_2emap_24s1123370502x1982532655(V);
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_clo;
V g_list_2emap_24s1123370502x1982532655_24dps(V, V);
V g_list_2emap_24s1123370502x1982532655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_24dps_clo;
V g_list_2emap_24s1150457979x1978067071(V);
V g_list_2emap_24s1150457979x1978067071_entry(V self, V *a);
extern Clo g_list_2emap_24s1150457979x1978067071_clo;
V g_list_2emap_24s1150457979x1978067071_24dps(V, V);
V g_list_2emap_24s1150457979x1978067071_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1150457979x1978067071_24dps_clo;
V g_list_2emap_24s1266088736x105832553_24dps(V, V, V);
V g_list_2emap_24s1266088736x105832553_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1266088736x105832553_24dps_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s1281445768x1036802655_24dps(V, V);
V g_list_2emap_24s1281445768x1036802655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_24dps_clo;
V g_list_2emap_24s1418045490x2076674085(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1418045490x2076674085_entry(V self, V *a);
extern Clo g_list_2emap_24s1418045490x2076674085_clo;
V g_list_2emap_24s1418045490x2076674085_24dps(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1418045490x2076674085_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1418045490x2076674085_24dps_clo;
V g_list_2emap_24s1427000880x1925304966(V, V);
V g_list_2emap_24s1427000880x1925304966_entry(V self, V *a);
extern Clo g_list_2emap_24s1427000880x1925304966_clo;
V g_list_2emap_24s1427000880x1925304966_24dps(V, V, V);
V g_list_2emap_24s1427000880x1925304966_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1427000880x1925304966_24dps_clo;
V g_list_2emap_24s152505078x225062837_24dps(V, V);
V g_list_2emap_24s152505078x225062837_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_24dps_clo;
V g_list_2emap_24s159747708x343809768(V, V, V, V, V, V, V);
V g_list_2emap_24s159747708x343809768_entry(V self, V *a);
extern Clo g_list_2emap_24s159747708x343809768_clo;
V g_list_2emap_24s159747708x343809768_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s159747708x343809768_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s159747708x343809768_24dps_clo;
V g_list_2emap_24s1675313341x192238134_24dps(V, V);
V g_list_2emap_24s1675313341x192238134_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_24dps_clo;
V g_list_2emap_24s1729297000x968708966(V);
V g_list_2emap_24s1729297000x968708966_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_clo;
V g_list_2emap_24s1729297000x968708966_24dps(V, V);
V g_list_2emap_24s1729297000x968708966_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_24dps_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24dps(V, V);
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24dps_clo;
V g_list_2emap_24s1835183789x486277886(V);
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_clo;
V g_list_2emap_24s1835183789x486277886_24dps(V, V);
V g_list_2emap_24s1835183789x486277886_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_24dps_clo;
V g_list_2emap_24s1937570095x2110149801_24dps(V, V);
V g_list_2emap_24s1937570095x2110149801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24dps_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s1992667171x110340492_24dps(V, V);
V g_list_2emap_24s1992667171x110340492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_24dps_clo;
V g_list_2emap_24s2005951263x462916503(V, V, V, V, V, V);
V g_list_2emap_24s2005951263x462916503_entry(V self, V *a);
extern Clo g_list_2emap_24s2005951263x462916503_clo;
V g_list_2emap_24s2005951263x462916503_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s2005951263x462916503_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2005951263x462916503_24dps_clo;
V g_list_2emap_24s2029035892x1571084362(V);
V g_list_2emap_24s2029035892x1571084362_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_clo;
V g_list_2emap_24s241620538x329208622_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s241620538x329208622_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s241620538x329208622_24dps_clo;
V g_list_2emap_24s249042484x1701682908_24dps(V, V);
V g_list_2emap_24s249042484x1701682908_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_24dps_clo;
V g_list_2emap_24s265594371x763318798_24dps(V, V);
V g_list_2emap_24s265594371x763318798_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s265594371x763318798_24dps_clo;
V g_list_2emap_24s275211812x1381242052_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s275211812x1381242052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s275211812x1381242052_24dps_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2emap_24s467798769x1763085075_24dps(V, V);
V g_list_2emap_24s467798769x1763085075_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_24dps_clo;
V g_list_2emap_24s471405029x78128406(V);
V g_list_2emap_24s471405029x78128406_entry(V self, V *a);
extern Clo g_list_2emap_24s471405029x78128406_clo;
V g_list_2emap_24s471405029x78128406_24dps(V, V);
V g_list_2emap_24s471405029x78128406_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s471405029x78128406_24dps_clo;
V g_list_2emap_24s502656580x1955732096_24dps(V, V);
V g_list_2emap_24s502656580x1955732096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_24dps_clo;
V g_list_2emap_24s503834852x510769098(V, V);
V g_list_2emap_24s503834852x510769098_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_clo;
V g_list_2emap_24s503834852x510769098_24dps(V, V, V);
V g_list_2emap_24s503834852x510769098_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_24dps_clo;
V g_list_2emap_24s513201124x806973253_24dps(V, V);
V g_list_2emap_24s513201124x806973253_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_24dps_clo;
V g_list_2emap_24s580776739x648604941(V);
V g_list_2emap_24s580776739x648604941_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_clo;
V g_list_2emap_24s580776739x648604941_24dps(V, V);
V g_list_2emap_24s580776739x648604941_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_24dps_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s60612435x257154841_24dps(V, V);
V g_list_2emap_24s60612435x257154841_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_24dps_clo;
V g_list_2emap_24s640776339x1223679834(V);
V g_list_2emap_24s640776339x1223679834_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_clo;
V g_list_2emap_24s640776339x1223679834_24dps(V, V);
V g_list_2emap_24s640776339x1223679834_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_24dps_clo;
V g_list_2emap_24s649333309x1802289391_24dps(V, V);
V g_list_2emap_24s649333309x1802289391_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_24dps_clo;
V g_list_2emap_24s679881967x35917574(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s679881967x35917574_entry(V self, V *a);
extern Clo g_list_2emap_24s679881967x35917574_clo;
V g_list_2emap_24s679881967x35917574_24dps(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s679881967x35917574_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s679881967x35917574_24dps_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s725725455x1186198702_24dps(V, V);
V g_list_2emap_24s725725455x1186198702_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_24dps_clo;
V g_list_2emap_24s73473062x206541869_24dps(V, V);
V g_list_2emap_24s73473062x206541869_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_24dps_clo;
V g_list_2emap_24s864521685x1610969087(V);
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_clo;
V g_list_2emap_24s878634257x1677201747(V);
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_clo;
V g_list_2emap_24s878634257x1677201747_24dps(V, V);
V g_list_2emap_24s878634257x1677201747_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_24dps_clo;
V g_list_2emap_24s939813003x1383013550_24dps(V, V);
V g_list_2emap_24s939813003x1383013550_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_24dps_clo;
V g_list_2emap_24s976303750x321235480_24dps(V, V);
V g_list_2emap_24s976303750x321235480_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_24dps_clo;
V g_list_2emerge_24s1716485482x1012130009(V, V);
V g_list_2emerge_24s1716485482x1012130009_entry(V self, V *a);
extern Clo g_list_2emerge_24s1716485482x1012130009_clo;
V g_list_2emerge_24s1716485482x1012130009_24dps(V, V, V);
V g_list_2emerge_24s1716485482x1012130009_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1716485482x1012130009_24dps_clo;
V g_list_2emerge_24s1840066165x1513718921(V, V);
V g_list_2emerge_24s1840066165x1513718921_entry(V self, V *a);
extern Clo g_list_2emerge_24s1840066165x1513718921_clo;
V g_list_2emerge_24s1840066165x1513718921_24dps(V, V, V);
V g_list_2emerge_24s1840066165x1513718921_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1840066165x1513718921_24dps_clo;
V g_list_2emerge_24s509014022x1733915733(V, V);
V g_list_2emerge_24s509014022x1733915733_entry(V self, V *a);
extern Clo g_list_2emerge_24s509014022x1733915733_clo;
V g_list_2esortBy_24s1768199906x1695529242(V);
V g_list_2esortBy_24s1768199906x1695529242_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1768199906x1695529242_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24dps(V, V, V, V);
V g_list_2ezipWith_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24dps_clo;
V g_list_2ezipWith_24s1149721393x617397893_24dps(V, V, V, V);
V g_list_2ezipWith_24s1149721393x617397893_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1149721393x617397893_24dps_clo;
V g_list_2ezipWith_24s151204990x680105425_24dps(V, V, V);
V g_list_2ezipWith_24s151204990x680105425_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_24dps_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s1876717925x1404326288_24dps(V, V, V);
V g_list_2ezipWith_24s1876717925x1404326288_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_24dps_clo;
V g_list_2ezipWith_24s1877091673x1588480570_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s1877091673x1588480570_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1877091673x1588480570_24dps_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1521533208x253309881(V, V, V);
V g_prelude_2e_2b_2b_24f1521533208x253309881_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1521533208x253309881_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2ecli_2eflagWord(V);
V g_std_2ecli_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagWord_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ehardline_get(void);
Clo g_list_2emap_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_entry, 2, 0};

V g_list_2emap(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24dps(v_f_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_entry(V self, V *a) {
  (void)self;
  return g_list_2emap(a[0], a[1]);
}
Clo g_list_2ezipWith_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_entry, 3, 0};

V g_list_2ezipWith(V v_f_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_f_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_x_243, v_y_245}));
      V v_cell_248 = heff_tag_at_n(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24dps(v_f_240, v_xs2_244, v_ys2_246, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2ezipWith_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith(a[0], a[1], a[2]);
}
Clo g_list_2ezipWith_24s1876717925x1404326288_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1876717925x1404326288_entry, 2, 0};

V g_list_2ezipWith_24s1876717925x1404326288(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_list_2ezipWith_24s1876717925x1404326288_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1876717925x1404326288(a[0], a[1]);
}
Clo g_list_2eany_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_entry, 2, 0};

V g_list_2eany(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efind_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_entry, 2, 0};

V g_list_2efind(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1937570095x2110149801_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1937570095x2110149801_24dps_entry, 2, 0};

V g_list_2emap_24s1937570095x2110149801_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1937570095x2110149801_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1937570095x2110149801_24dps(a[0], a[1]);
}
Clo g_list_2efind_24s2097169879x1343877600_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s2097169879x1343877600_entry, 12, 0};

V g_list_2efind_24s2097169879x1343877600(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_x2_2411) {
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    heff_drop(v_lit_2410);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    V v_a_2414;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_I8: {
      v_a_2414 = heff_dup(v_lit_240);
      break;
    }
    case TAG_I16: {
      v_a_2414 = heff_dup(v_lit_241);
      break;
    }
    case TAG_I32: {
      v_a_2414 = heff_dup(v_lit_242);
      break;
    }
    case TAG_I64: {
      v_a_2414 = heff_dup(v_lit_243);
      break;
    }
    case TAG_U8: {
      v_a_2414 = heff_dup(v_lit_244);
      break;
    }
    case TAG_U16: {
      v_a_2414 = heff_dup(v_lit_245);
      break;
    }
    case TAG_U32: {
      v_a_2414 = heff_dup(v_lit_246);
      break;
    }
    case TAG_U64: {
      v_a_2414 = heff_dup(v_lit_247);
      break;
    }
    case TAG_F32: {
      v_a_2414 = heff_dup(v_lit_248);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_t_2415 = heff_strSlice(heff_dup(v_lit_249), heff_dup(v_lit_2410), heff_strLength_lent(v_a_2414, 0));
    if (heff_strEq_c(v_t_2415, v_a_2414)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_lit_247);
      heff_drop(v_lit_248);
      heff_drop(v_lit_249);
      heff_drop(v_lit_2410);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2412)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_lit_2410;
      V t_11 = v_xs_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2efind_24s2097169879x1343877600_entry(V self, V *a) {
  (void)self;
  V a11 = a[11]; V r = g_list_2efind_24s2097169879x1343877600(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a11); heff_drop(a11); return r;
}
Clo g_list_2efilter_24s716173495x680820632_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s716173495x680820632_24dps_entry, 3, 0};

V g_list_2efilter_24s716173495x680820632_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s716173495x680820632_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s716173495x680820632_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1150457979x1978067071_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1150457979x1978067071_entry, 1, 0};

V g_list_2emap_24s1150457979x1978067071(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_ArgExplicit: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24ArgExplicit = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_a_245)) {
        case TAG_At: {
          V v_a_246 = heff_field(v_a_245, 0);
          V v_a_247 = heff_field(v_a_245, 1);
          heff_take_n(v_a_245, 3ULL, 2);
          V v_t_248 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_246));
          v_t_249 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_248, v_a_247});
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_249});
        break;
      }
      case TAG_ArgProject: {
        V v_a_2410 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24ArgProject = heff_take_reuse_n(v_a_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ArgProject, TAG_ArgProject, 1, (V[]){v_a_2410});
        break;
      }
      case TAG_ArgNamed: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_a_2412 = heff_field(v_a_243, 1);
        V v_ru_24a_243_24ArgNamed = heff_take_reuse_n(v_a_243, 3ULL, 2);
        V v_t_2416;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2413));
          v_t_2416 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2415, v_a_2414});
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ArgNamed, TAG_ArgNamed, 2, (V[]){v_a_2411, v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = (g_list_2emap_24s1150457979x1978067071_24dps(v_xs_242, heff_dup(v_cell_2419)));
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1150457979x1978067071_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1150457979x1978067071(a[0]);
}
Clo g_list_2emap_24s1992667171x110340492_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1992667171x110340492_entry, 1, 0};

V g_list_2emap_24s1992667171x110340492(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(v_a_243));
      v_t_246 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1992667171x110340492_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1992667171x110340492(a[0]);
}
Clo g_list_2emap_24s249042484x1701682908_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s249042484x1701682908_24dps_entry, 2, 0};

V g_list_2emap_24s249042484x1701682908_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2416;
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24SetField = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_2410, v_a_249));
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24a_244_24SetField, TAG_SetField, 3, (V[]){v_a_246, v_a_247, v_t_2411});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2412 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24BadFieldSet = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_2414, v_a_2413));
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24a_244_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2415});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2416, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2418));
    heff_drop(v_u_2419);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2418;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s249042484x1701682908_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s249042484x1701682908_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s878634257x1677201747_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s878634257x1677201747_entry, 1, 0};

V g_list_2emap_24s878634257x1677201747(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2esyntax_2esurface_2eidentOf(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s878634257x1677201747_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s878634257x1677201747(a[0]);
}
Clo g_list_2emap_24s513201124x806973253_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513201124x806973253_24dps_entry, 2, 0};

V g_list_2emap_24s513201124x806973253_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_EProject, 1, (V[]){heff_take_field(v_x_242, 1)});
    V v_t_245 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_242, 3), heff_get_n(v_x_242, 4, 9)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_t_245}), heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513201124x806973253_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513201124x806973253_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1368043225x413679696_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1368043225x413679696_entry, 3, 0};

V g_list_2efoldl_24s1368043225x413679696(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_SetField: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_249 = heff_field(v_a_245, 2);
        heff_take_n(v_a_245, 5ULL, 3);
        V v_t_2412;
        switch (heff_tag_of(v_z_241)) {
        case TAG_At: {
          V v_a_2411 = heff_dup(heff_field(v_z_241, 1));
          v_t_2412 = v_a_2411;
          break;
        }
        default: heff_nomatch(v_z_241);
        }
        V v_t_2413 = ({ V rv_1 = heff_dup(heff_rfield(v_a_246, 1)); V rr_ = heff_rec_reuse_nf(v_t_2412, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_ESpec, 4, (V[]){v_z_241, v_a_247, v_a_246, v_a_249}), v_t_2413});
        break;
      }
      case TAG_BadFieldSet: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_z_241);
        v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(v_lit_240)}), v_a_246});
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2415;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1368043225x413679696_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1368043225x413679696(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1059370217x1267747283_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1059370217x1267747283_24dps_entry, 2, 0};

V g_list_2emap_24s1059370217x1267747283_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_ExplicitParam: {
        V v_x_246 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2412 = v_x_246;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_249 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2412 = v_x_249;
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1059370217x1267747283_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1059370217x1267747283_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s60612435x257154841_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s60612435x257154841_entry, 1, 0};

V g_list_2emap_24s60612435x257154841(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_b_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 4ULL, 3);
      v_t_246 = v_b_245;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s60612435x257154841_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s60612435x257154841_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s60612435x257154841(a[0]);
}
Clo g_list_2efoldl_24s1048046132x95752937_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1048046132x95752937_entry, 2, 0};

V g_list_2efoldl_24s1048046132x95752937(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2espec_2ebindOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1048046132x95752937(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1809017761x1063871171_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1809017761x1063871171_entry, 1, 0};

V g_list_2emap_24s1809017761x1063871171(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1809017761x1063871171_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1809017761x1063871171(a[0]);
}
Clo g_list_2emap_24s73473062x206541869_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s73473062x206541869_24dps_entry, 2, 0};

V g_list_2emap_24s73473062x206541869_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s73473062x206541869_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s73473062x206541869_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1123370502x1982532655_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1123370502x1982532655_entry, 1, 0};

V g_list_2emap_24s1123370502x1982532655(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1123370502x1982532655_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1123370502x1982532655(a[0]);
}
Clo g_list_2efoldl_24s1748401606x190338434_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1748401606x190338434_entry, 2, 0};

V g_list_2efoldl_24s1748401606x190338434(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 2)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1748401606x190338434_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1748401606x190338434(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s120814613x1439363162_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s120814613x1439363162_entry, 2, 0};

V g_list_2eany_24s120814613x1439363162(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_x_242), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s120814613x1439363162_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s120814613x1439363162(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s883603918x1469273954_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s883603918x1469273954_entry, 2, 0};

V g_list_2efoldl_24s883603918x1469273954(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Merge: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_2417 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_245, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Boxed: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Unboxed: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Literal: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Wants: {
      V v_a_2411 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2417 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_2411, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Binds: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Pinned: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Kept: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2418 = (g_prelude_2e_2b_2b(v_t_2417, v_z_240));
    V t_0 = v_t_2418;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s883603918x1469273954_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s883603918x1469273954(a[0], a[1]);
}
Clo g_list_2efoldl_24s2145639387x28888241_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2145639387x28888241_entry, 4, 0};

V g_list_2efoldl_24s2145639387x28888241(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkArm: {
      V v_a_248 = heff_field(v_x_244, 2);
      heff_take_n(v_x_244, 4ULL, 3);
      v_t_249 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_248}), v_z_242});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_249;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s2145639387x28888241_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2145639387x28888241(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s525916660x1238865713_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s525916660x1238865713_entry, 2, 0};

V g_list_2efoldl_24s525916660x1238865713(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2efacts_2elazyOf(v_z_240, heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 2))));
    V v_t_245 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_x_242, 0)), v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s525916660x1238865713_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s525916660x1238865713(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1915639815x253536901_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1915639815x253536901_entry, 2, 0};

V g_list_2efoldl_24s1915639815x253536901(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2earity_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1915639815x253536901_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1915639815x253536901(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s241620538x329208622_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s241620538x329208622_24dps_entry, 8, 0};

V g_list_2emap_24s241620538x329208622_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      V v_t_2412 = (g_heff_2eelab_2eprint_2eescFrom(v_a_2410, heff_dup(v_lit_242)));
      V v_t_2413 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2412, heff_dup(v_lit_243)));
      V v_t_2414 = ({ V a_0 = v_a_2411; V r_ = (g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(a_0)); heff_drop(v_a_2411); r_; });
      V v_t_2415 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2414, heff_dup(v_lit_245)));
      v_t_2416 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2413, v_t_2415));
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s241620538x329208622_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s241620538x329208622_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2efoldl_24s865198748x12535471_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s865198748x12535471_entry, 2, 0};

V g_list_2efoldl_24s865198748x12535471(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s865198748x12535471_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s865198748x12535471(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1729297000x968708966_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729297000x968708966_entry, 1, 0};

V g_list_2emap_24s1729297000x968708966(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_x_241, 0), heff_get_n(v_x_241, 2, 5)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1729297000x968708966_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729297000x968708966_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1729297000x968708966(a[0]);
}
Clo g_list_2eany_24s1523549873x2075662238_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1523549873x2075662238_entry, 2, 0};

V g_list_2eany_24s1523549873x2075662238(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_247 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1523549873x2075662238_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1523549873x2075662238(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s455728131x407835966_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s455728131x407835966_entry, 2, 0};

V g_list_2efoldl_24s455728131x407835966(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_z_240)) {
    case TAG_Nothing: {
      v_t_246 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_a_244 = heff_field(v_z_240, 0);
      V v_ru_24z_240_24Just = heff_take_reuse_n(v_z_240, 1ULL, 1);
      switch (heff_tag_of(v_x_242)) {
      case TAG_Nothing: {
        heff_drop(v_a_244);
        heff_drop_cell(v_ru_24z_240_24Just, 1);
        v_t_246 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_b_245 = heff_field(v_x_242, 0);
        v_t_246 = heff_tag_at_n(v_ru_24z_240_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_244, heff_dup(v_b_245))});
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s455728131x407835966_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s455728131x407835966(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1375915522x445000623_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1375915522x445000623_entry, 1, 0};

V g_list_2eany_24s1375915522x445000623(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Nothing: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_a_243 = heff_field(v_x_241, 0);
      if ((heff_dup(v_a_243) == NTAG(TAG_True))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1375915522x445000623_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1375915522x445000623(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1203202837x1639358108_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1203202837x1639358108_entry, 2, 0};

V g_list_2efoldl_24s1203202837x1639358108(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_x_242}), v_z_240});
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1203202837x1639358108(a[0], a[1]);
}
Clo g_list_2eany_24s195269671x277329476_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s195269671x277329476_entry, 2, 0};

V g_list_2eany_24s195269671x277329476(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_intEq_c(v_t_246, heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s195269671x277329476_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s195269671x277329476(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s471405029x78128406_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s471405029x78128406_entry, 1, 0};

V g_list_2emap_24s471405029x78128406(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 7ULL, 3);
      v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_a_244}), heff_tag_n(TAG_ASts, 1, (V[]){v_a_245})});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s471405029x78128406_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s471405029x78128406_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s471405029x78128406(a[0]);
}
Clo g_list_2emap_24s471405029x78128406_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s471405029x78128406_24dps_entry, 2, 0};

V g_list_2emap_24s471405029x78128406_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_245}), heff_tag_n(TAG_ASts, 1, (V[]){v_a_246})});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s471405029x78128406_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s471405029x78128406_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s976303750x321235480_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s976303750x321235480_24dps_entry, 2, 0};

V g_list_2emap_24s976303750x321235480_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Given: {
      V v_e_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = v_e_244;
      break;
    }
    case TAG_GivenU: {
      V v_e_246 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_2410 = v_e_246;
      break;
    }
    case TAG_LentVar: {
      V v_x_247 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2410 = heff_tag_n(TAG_RLocal, 1, (V[]){v_x_247});
      break;
    }
    case TAG_LentValue: {
      V v_e_249 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = v_e_249;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s976303750x321235480_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s976303750x321235480_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s151204990x680105425_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s151204990x680105425_24dps_entry, 3, 0};

V g_list_2ezipWith_24s151204990x680105425_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_247 = ({ V a_0 = v_x_243; V a_1 = v_y_245; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_y_245); r_; });
      V v_t_248;
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        v_t_248 = v_x_243;
      } else {
        heff_drop(v_x_243);
        heff_drop(v_t_247);
        v_t_248 = NTAG(TAG_RepV);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_249;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s151204990x680105425_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s151204990x680105425_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1835183789x486277886_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1835183789x486277886_entry, 1, 0};

V g_list_2emap_24s1835183789x486277886(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1835183789x486277886_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1835183789x486277886(a[0]);
}
Clo g_list_2emap_24s1835183789x486277886_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1835183789x486277886_24dps_entry, 2, 0};

V g_list_2emap_24s1835183789x486277886_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1835183789x486277886_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1835183789x486277886_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1577366920x1019062938_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1577366920x1019062938_entry, 2, 0};

V g_list_2efoldl_24s1577366920x1019062938(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_x_242, 4)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1577366920x1019062938_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1577366920x1019062938(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s1149721393x617397893_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1149721393x617397893_24dps_entry, 4, 0};

V g_list_2ezipWith_24s1149721393x617397893_24dps(V v_lit_240, V v_xs_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ys_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_xs_241, 0);
    V v_xs2_245 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_244);
      heff_drop(v_xs2_245);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_ys_242, 0);
      V v_ys2_247 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_248 = heff_strAppend(v_x_244, heff_strAppend(heff_dup(v_lit_240), v_y_246));
      V v_cell_249 = heff_tag_at_n(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_xs2_245;
      V t_2 = v_ys2_247;
      V t_3 = v_cell_249;
      v_lit_240 = t_0;
      v_xs_241 = t_1;
      v_ys_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2ezipWith_24s1149721393x617397893_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1149721393x617397893_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s679881967x35917574_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s679881967x35917574_entry, 10, 0};

V g_list_2emap_24s679881967x35917574(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_x2_249) {
top: ;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24Cons = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_a_2412 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_x_2410), heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_x_2410, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_a_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_2412));
    V v_a_2416;
    switch (heff_tag_of(v_a_2413)) {
    case TAG_Nil: {
      v_a_2416 = v_x_2410;
      break;
    }
    case TAG_Cons: {
      V v_a_2414 = heff_field(v_a_2413, 0);
      heff_take_n(v_a_2413, 1ULL, 2);
      heff_drop(v_x_2410);
      v_a_2416 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_a_2413);
    }
    V v_t_2417 = heff_intSub(heff_strLength_lent(v_a_2416, 0), heff_dup(v_lit_244));
    V v_t_2418 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_a_2416), v_t_2417));
    V v_t_2419 = ({ V a_0 = v_a_2416; V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_a_2420 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_2419, heff_dup(v_lit_245), heff_dup(v_lit_246)));
    V v_t_2422;
    if (heff_strEq_c_lent(v_a_2420, v_lit_247, 0)) {
      heff_drop(v_a_2420);
      v_t_2422 = heff_dup(v_lit_248);
    } else {
      v_t_2422 = v_a_2420;
    }
    V v_t_2423 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_2422));
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_249_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = (g_list_2emap_24s679881967x35917574_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_xs_2411, heff_dup(v_cell_2424)));
    heff_drop(v_u_2425);
    return v_cell_2424;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_list_2emap_24s679881967x35917574_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s679881967x35917574(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2emap_24s649333309x1802289391_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s649333309x1802289391_24dps_entry, 2, 0};

V g_list_2emap_24s649333309x1802289391_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemit_2ehostLineOf(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s649333309x1802289391_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s649333309x1802289391_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s2065989517x1307020881_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2065989517x1307020881_entry, 2, 0};

V g_list_2eany_24s2065989517x1307020881(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_242, v_lit_240, 0)) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s2065989517x1307020881(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s152505078x225062837_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s152505078x225062837_24dps_entry, 2, 0};

V g_list_2emap_24s152505078x225062837_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s152505078x225062837_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s152505078x225062837_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s640776339x1223679834_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s640776339x1223679834_entry, 1, 0};

V g_list_2emap_24s640776339x1223679834(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s640776339x1223679834_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s640776339x1223679834_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s640776339x1223679834(a[0]);
}
Clo g_list_2emap_24s640776339x1223679834_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s640776339x1223679834_24dps_entry, 2, 0};

V g_list_2emap_24s640776339x1223679834_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s640776339x1223679834_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s640776339x1223679834_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1877091673x1588480570_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1877091673x1588480570_24dps_entry, 6, 0};

V g_list_2ezipWith_24s1877091673x1588480570_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_xs_243, V v_ys_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_xs_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_ys_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_xs_243, 0);
    V v_xs2_247 = heff_field(v_xs_243, 1);
    V v_ru_24xs_243_24Cons = heff_take_reuse_n(v_xs_243, 3ULL, 2);
    switch (heff_tag_of(v_ys_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_246);
      heff_drop(v_xs2_247);
      heff_drop_cell(v_ru_24xs_243_24Cons, 2);
      return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_248 = heff_field(v_ys_244, 0);
      V v_ys2_249 = heff_field(v_ys_244, 1);
      heff_take_n(v_ys_244, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_x_246)) {
      case TAG_MkPair: {
        V v_a_2410 = heff_dup(heff_field(v_x_246, 0));
        v_t_2412 = v_a_2410;
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      V v_t_2415;
      switch (heff_tag_of(v_x_246)) {
      case TAG_MkPair: {
        V v_a_2414 = heff_field(v_x_246, 1);
        heff_take_n(v_x_246, 2ULL, 2);
        v_t_2415 = v_a_2414;
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      V v_t_2416 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2415, heff_dup(v_lit_242)));
      V v_t_2417 = heff_strAppend(heff_intShow(v_y_248), v_t_2416);
      V v_t_2418 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_240), v_t_2417));
      V v_cell_2419 = heff_tag_at_n(v_ru_24xs_243_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
      V v_u_2420 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2419));
      heff_drop(v_u_2420);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs2_247;
      V t_4 = v_ys2_249;
      V t_5 = v_cell_2419;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_xs_243 = t_3;
      v_ys_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_ys_244);
    }
  }
  default: return heff_nomatch(v_xs_243);
  }
}
V g_list_2ezipWith_24s1877091673x1588480570_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1877091673x1588480570_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s275211812x1381242052_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s275211812x1381242052_24dps_entry, 8, 0};

V g_list_2emap_24s275211812x1381242052_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_dup(heff_field(v_x_248, 0));
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_t_2412, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)));
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2415 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 2ULL, 2);
      v_t_2416 = v_a_2415;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2417 = heff_strAppend(heff_dup(v_lit_245), heff_intShow(v_t_2416));
    V v_t_2418 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2413), v_t_2417);
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2418), heff_hole()});
    V v_u_2420 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2419;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s275211812x1381242052_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s275211812x1381242052_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2efoldl_24s96111113x2107485159_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s96111113x2107485159_entry, 10, 0};

V g_list_2efoldl_24s96111113x2107485159(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_z_248, V v_x3_249) {
top: ;
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    return v_z_248;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x3_249, 0);
    V v_xs_2411 = heff_field(v_x3_249, 1);
    V v_ru_24x3_249_24Cons = heff_take_reuse_n(v_x3_249, 3ULL, 2);
    V v_a_2414;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2412 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2414 = heff_get_n(v_a_2412, 0, 3);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2415 = (g_heff_2ecompile_2eemitc_2elastDotGo(heff_dup(v_a_2414), heff_dup(v_lit_240), heff_dup(v_lit_241)));
    V v_t_2417;
    if (heff_intLt_c(heff_dup(v_a_2415), heff_dup(v_lit_242))) {
      heff_drop(v_a_2415);
      v_t_2417 = v_a_2414;
    } else {
      v_t_2417 = heff_strSlice_lent(v_a_2414, v_lit_243, v_a_2415, 5);
    }
    V v_a_2420;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2418 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2420 = heff_get_n(v_a_2418, 0, 3);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2421 = (g_heff_2ecompile_2eemitc_2elastDotGo(heff_dup(v_a_2420), heff_dup(v_lit_244), heff_dup(v_lit_245)));
    V v_t_2423;
    if (heff_intLt_c(heff_dup(v_a_2421), heff_dup(v_lit_246))) {
      heff_drop(v_a_2421);
      v_t_2423 = v_a_2420;
    } else {
      v_t_2423 = heff_strSlice_lent(v_a_2420, v_lit_247, v_a_2421, 5);
    }
    V v_a_2424 = (g_map_2elookup_24s1546226666x2146984184(v_t_2423, v_z_248));
    V v_t_2426;
    switch (heff_tag_of(v_a_2424)) {
    case TAG_Nothing: {
      v_t_2426 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_a_2425 = heff_field(v_a_2424, 0);
      heff_take_n(v_a_2424, 1ULL, 1);
      v_t_2426 = v_a_2425;
      break;
    }
    default: heff_nomatch(v_a_2424);
    }
    V v_t_2427 = (g_map_2einsert_24s1341440536x470972936(v_t_2417, heff_tag_at_n(v_ru_24x3_249_24Cons, TAG_Cons, 2, (V[]){v_x_2410, v_t_2426}), v_z_248));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_t_2427;
    V t_9 = v_xs_2411;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_z_248 = t_8;
    v_x3_249 = t_9;
    goto top;
  }
  default: return heff_nomatch(v_x3_249);
  }
}
V g_list_2efoldl_24s96111113x2107485159_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s96111113x2107485159(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2eany_24s698149710x1824282627_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s698149710x1824282627_entry, 4, 0};

V g_list_2eany_24s698149710x1824282627(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_242, 1)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s698149710x1824282627_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2eany_24s698149710x1824282627(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str0, 1, "\012");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str1, 1, "\012");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str2, 20, "#define HEFF_THREADS");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str3, 20, "#define HEFF_THREADS");
Clo g_list_2eany_24s762674996x1009180162_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s762674996x1009180162_entry, 1, 0};

V g_list_2eany_24s762674996x1009180162(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_s_243 = heff_dup(heff_rfield(v_x_241, 1));
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_list_2eany_24s762674996x1009180162_str0), heff_dup(v_s_243), MK_INT(0LL), heff_strFind(((V)&g_list_2eany_24s762674996x1009180162_str1), v_s_243, MK_INT(0LL)), NTAG(TAG_Nil)));
    V v_t_245 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_list_2eany_24s762674996x1009180162_str2); V a_2 = ((V)&g_list_2eany_24s762674996x1009180162_str3); V a_3 = v_t_244; V r_ = (g_list_2eany_24s698149710x1824282627(a_0, a_1, a_2, a_3)); heff_drop(v_t_244); r_; });
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s762674996x1009180162(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s306513717x1560435942_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s306513717x1560435942_entry, 2, 0};

V g_list_2efoldl_24s306513717x1560435942(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_t_246, 0, 3), v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s306513717x1560435942_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s306513717x1560435942(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s776002836x391891384_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s776002836x391891384_entry, 2, 0};

V g_list_2efoldl_24s776002836x391891384(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b_24f1521533208x253309881(v_z_240, heff_dup(v_x_242), heff_dup(g_heff_2esyntax_2eimport_2eimplicitImports_get())));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s776002836x391891384_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s776002836x391891384(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1427000880x1925304966_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1427000880x1925304966_entry, 2, 0};

V g_list_2emap_24s1427000880x1925304966(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2411 = heff_strAppend(v_t_246, heff_strAppend(heff_dup(v_lit_240), v_t_2410));
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1427000880x1925304966_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1427000880x1925304966_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1427000880x1925304966(a[0], a[1]);
}
Clo g_list_2emap_24s503834852x510769098_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s503834852x510769098_entry, 2, 0};

V g_list_2emap_24s503834852x510769098(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_x_242; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_244), heff_hole()});
    V v_u_246 = (g_list_2emap_24s503834852x510769098_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s503834852x510769098_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s503834852x510769098(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s502656580x1955732096_24dps_str0, 1, "_");
Clo g_list_2emap_24s502656580x1955732096_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s502656580x1955732096_24dps_entry, 2, 0};

V g_list_2emap_24s502656580x1955732096_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(v_x_242, 0, 5);
    V v_t_2425;
    switch (heff_tag_of(v_t_244)) {
    case TAG_At: {
      V v_x11_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 2);
      switch (heff_tag_of(v_x11_245)) {
      case TAG_PatVar: {
        V v_x_247 = heff_field(v_x11_245, 0);
        V v_ru_24x11_245_24PatVar = heff_take_reuse_n(v_x11_245, 1ULL, 1);
        if (heff_strEq_c_lent(v_x_247, ((V)&g_list_2emap_24s502656580x1955732096_24dps_str0), 2)) {
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x11_245_24PatVar, 1);
          v_t_2425 = NTAG(TAG_Nothing);
        } else {
          v_t_2425 = heff_tag_at_n(v_ru_24x11_245_24PatVar, TAG_Just, 1, (V[]){v_x_247});
        }
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_245, 0ULL, 3);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_245, 0ULL, 3);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_na(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_245, 0ULL, 3);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_245);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_cell_2426 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
    V v_u_2427 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2426));
    heff_drop(v_u_2427);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2426;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s502656580x1955732096_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s502656580x1955732096_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s939813003x1383013550_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s939813003x1383013550_24dps_entry, 2, 0};

V g_list_2emap_24s939813003x1383013550_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(v_x_242, 2, 5);
    V v_t_248;
    switch (heff_tag_of(v_t_244)) {
    case TAG_SizeDefault: {
      v_t_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeNumber: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeName: {
      V v_x_246 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 2);
      v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_xs_243;
    V t_1 = v_cell_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s939813003x1383013550_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s939813003x1383013550_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1991317015x801331450_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1991317015x801331450_entry, 2, 0};

V g_list_2efoldl_24s1991317015x801331450(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_a_247), NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1991317015x801331450_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1991317015x801331450(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s265594371x763318798_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s265594371x763318798_24dps_entry, 2, 0};

V g_list_2emap_24s265594371x763318798_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_SGlobal, 1, (V[]){heff_take_field(v_x_242, 1)});
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_242, 0, 4), v_t_244});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s265594371x763318798_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s265594371x763318798_24dps(a[0], a[1]);
}
Clo g_list_2emerge_24s1840066165x1513718921_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1840066165x1513718921_entry, 2, 0};

V g_list_2emerge_24s1840066165x1513718921(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 10);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_y_244, 0)), heff_dup(heff_rfield(v_x_242, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s1840066165x1513718921_24dps(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s1840066165x1513718921_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1840066165x1513718921_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1840066165x1513718921(a[0], a[1]);
}
Clo g_list_2emap_24s1418045490x2076674085_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1418045490x2076674085_entry, 10, 0};

V g_list_2emap_24s1418045490x2076674085(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_x2_249) {
top: ;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24Cons = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412 = heff_take_field(v_x_2410, 1);
    V v_t_2413;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_AssocLeft: {
      v_t_2413 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2413 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2413 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2414 = heff_take_field(v_x_2410, 3);
    V v_t_2415;
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      v_t_2415 = heff_dup(v_lit_244);
    } else {
      heff_drop(v_t_2414);
      v_t_2415 = heff_dup(v_lit_245);
    }
    V v_t_2416 = heff_take_field(v_x_2410, 2);
    V v_t_2419;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nil: {
      v_t_2419 = heff_dup(v_lit_247);
      break;
    }
    case TAG_Cons: {
      V v_a_2417 = heff_field(v_t_2416, 0);
      V v_a_2418 = heff_field(v_t_2416, 1);
      heff_take_n(v_t_2416, 3ULL, 2);
      v_t_2419 = ({ V a_0 = heff_dup(v_lit_248); V a_1 = v_a_2417; V a_2 = v_a_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2418); r_; });
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_t_2420 = heff_strAppend(v_t_2415, heff_strAppend(heff_dup(v_lit_246), v_t_2419));
    V v_t_2421 = heff_strAppend(heff_intShow(v_t_2413), v_t_2420);
    V v_t_2422 = heff_strAppend(heff_get_n(v_x_2410, 0, 5), heff_strAppend(heff_dup(v_lit_240), v_t_2421));
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_249_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
    V v_u_2424 = (g_list_2emap_24s1418045490x2076674085_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_xs_2411, heff_dup(v_cell_2423)));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_list_2emap_24s1418045490x2076674085_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1418045490x2076674085(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2emap_24s467798769x1763085075_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s467798769x1763085075_entry, 1, 0};

V g_list_2emap_24s467798769x1763085075(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s467798769x1763085075_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s467798769x1763085075(a[0]);
}
Clo g_list_2efoldl_24s560581624x1100110660_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s560581624x1100110660_entry, 3, 0};

V g_list_2efoldl_24s560581624x1100110660(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(heff_dup(v_lit_240), v_x_243));
    V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_248;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s560581624x1100110660_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s560581624x1100110660(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s159747708x343809768_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s159747708x343809768_entry, 7, 0};

V g_list_2emap_24s159747708x343809768(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_a_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_a_2412 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_a_2411), heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_a_2411, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_t_2417;
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2411, heff_dup(v_lit_244)});
      break;
    }
    case TAG_Cons: {
      V v_a_2413 = heff_field(v_a_2412, 0);
      V v_a_2414 = heff_field(v_a_2412, 1);
      V v_ru_24a_2412_24Cons = heff_take_reuse_n(v_a_2412, 3ULL, 2);
      switch (heff_tag_of(v_a_2414)) {
      case TAG_Nil: {
        heff_drop(v_a_2413);
        v_t_2417 = heff_tag_at_n(v_ru_24a_2412_24Cons, TAG_MkPair, 2, (V[]){v_a_2411, heff_dup(v_lit_245)});
        break;
      }
      case TAG_Cons: {
        V v_a_2415 = heff_field(v_a_2414, 0);
        heff_take_n(v_a_2414, 1ULL, 2);
        heff_drop(v_a_2411);
        v_t_2417 = heff_tag_at_n(v_ru_24a_2412_24Cons, TAG_MkPair, 2, (V[]){v_a_2413, v_a_2415});
        break;
      }
      default: heff_nomatch(v_a_2414);
      }
      break;
    }
    default: heff_nomatch(v_a_2412);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = (g_list_2emap_24s159747708x343809768_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s159747708x343809768_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s159747708x343809768(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_list_2eany_24s577543654x765608923_str0, 12, "-- fmt: skip");
Clo g_list_2eany_24s577543654x765608923_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s577543654x765608923_entry, 1, 0};

V g_list_2eany_24s577543654x765608923(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_s_243 = heff_dup(heff_rfield(v_x_241, 0));
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(heff_dup(v_s_243), heff_strLength_lent(v_s_243, 0)));
    if (heff_strEq_c(heff_strSlice(v_s_243, MK_INT(0LL), v_t_244), ((V)&g_list_2eany_24s577543654x765608923_str0))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s577543654x765608923_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s577543654x765608923(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s725725455x1186198702_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s725725455x1186198702_entry, 1, 0};

V g_list_2emap_24s725725455x1186198702(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(heff_dup(v_x_241), heff_strLength_lent(v_x_241, 0)));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_x_241, MK_INT(0LL), v_t_243), heff_hole()});
    V v_u_245 = (g_list_2emap_24s725725455x1186198702_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s725725455x1186198702(a[0]);
}
Clo g_list_2efilter_24s2128134357x1680551385_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2128134357x1680551385_entry, 2, 0};

V g_list_2efilter_24s2128134357x1680551385(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s2128134357x1680551385_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s2128134357x1680551385_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2128134357x1680551385(a[0], a[1]);
}
Clo g_list_2efilter_24s2128134357x1680551385_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2128134357x1680551385_24dps_entry, 3, 0};

V g_list_2efilter_24s2128134357x1680551385_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_240))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s2128134357x1680551385_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2128134357x1680551385_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s50027113x1989932102_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s50027113x1989932102_entry, 2, 0};

V g_list_2efilter_24s50027113x1989932102(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s50027113x1989932102_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s50027113x1989932102_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s50027113x1989932102(a[0], a[1]);
}
Clo g_list_2efoldl_24s1002907040x997927369_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1002907040x997927369_entry, 2, 0};

V g_list_2efoldl_24s1002907040x997927369(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_z_240, 0)))) {
      V v_a_245 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(heff_rfield(v_x_242, 1))));
      V v_t_247;
      switch (heff_tag_of(v_a_245)) {
      case TAG_Nothing: {
        v_t_247 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_a_246 = heff_field(v_a_245, 0);
        heff_take_n(v_a_245, 1ULL, 1);
        v_t_247 = v_a_246;
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      V v_a_248 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(heff_rfield(v_z_240, 1))));
      V v_t_2410;
      switch (heff_tag_of(v_a_248)) {
      case TAG_Nothing: {
        v_t_2410 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_a_249 = heff_field(v_a_248, 0);
        heff_take_n(v_a_248, 1ULL, 1);
        v_t_2410 = v_a_249;
        break;
      }
      default: heff_nomatch(v_a_248);
      }
      V v_t_2411 = ({ V a_0 = v_t_247; V a_1 = v_t_2410; V r_ = (g_heff_2ebuild_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_247); heff_drop(v_t_2410); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop_rec(v_z_240, 3);
        heff_drop(v_t_2411);
        v_t_2412 = heff_dup(v_x_242);
      } else {
        heff_drop(v_t_2411);
        v_t_2412 = v_z_240;
      }
    } else {
      v_t_2412 = v_z_240;
    }
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1002907040x997927369_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1002907040x997927369(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s44351024x1408738471_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s44351024x1408738471_entry, 2, 0};

V g_list_2efoldl_24s44351024x1408738471(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = (g_heff_2eelab_2elocals_2edeclaration(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(heff_take_field(v_z_240, 0), heff_take_field(v_a_244, 0)));
    V v_t_246 = (g_prelude_2e_2b_2b(heff_get_n(v_z_240, 1, 2), heff_get_n(v_a_244, 1, 2)));
    V t_0 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_245, v_t_246});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s44351024x1408738471(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2esortBy_24s1768199906x1695529242_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1768199906x1695529242_entry, 1, 0};

V g_list_2esortBy_24s1768199906x1695529242(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s1768199906x1695529242(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s1768199906x1695529242(v_t_249));
      return (g_list_2emerge_24s509014022x1733915733(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1768199906x1695529242_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1768199906x1695529242(a[0]);
}
Clo g_list_2emerge_24s1716485482x1012130009_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1716485482x1012130009_entry, 2, 0};

V g_list_2emerge_24s1716485482x1012130009(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 2);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_strLt_c(heff_dup(heff_rfield(v_y_244, 0)), heff_dup(heff_rfield(v_x_242, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s1716485482x1012130009_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245, heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s1716485482x1012130009_24dps(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245}), heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1716485482x1012130009_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1716485482x1012130009(a[0], a[1]);
}
Clo g_list_2emap_24s1266088736x105832553_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1266088736x105832553_24dps_entry, 3, 0};

V g_list_2emap_24s1266088736x105832553_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = heff_dup(heff_rfield(v_x_243, 0));
    V v_a_246 = heff_take_field(v_x_243, 1);
    V v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_243, 0, 2)});
    V v_t_248 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), v_t_247, NTAG(TAG_Nothing)});
    V v_a_249 = heff_take_field(v_a_246, 0);
    V v_a_2410 = heff_intSub(heff_dup(heff_rfield(v_a_246, 1)), heff_strLength_lent(v_a_245, 0));
    V v_t_2412;
    if (heff_intLe_c(heff_dup(v_a_249), heff_dup(v_a_2410))) {
      heff_drop(v_a_249);
      v_t_2412 = v_a_2410;
    } else {
      heff_drop(v_a_2410);
      v_t_2412 = v_a_249;
    }
    V v_t_2413 = ({ V rv_0 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_a_246, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_target__name__span, (V[]){v_t_248, v_a_245, v_t_2413}), heff_hole()});
    V v_u_2415 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_2414;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1266088736x105832553_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1266088736x105832553_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1675313341x192238134_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1675313341x192238134_24dps_entry, 2, 0};

V g_list_2emap_24s1675313341x192238134_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_MkEquation: {
        V v_fsp_247 = heff_field(v_x11_244, 1);
        heff_take_n(v_x11_244, 2ULL, 4);
        v_t_2410 = v_fsp_247;
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1675313341x192238134_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1675313341x192238134_24dps(a[0], a[1]);
}
Clo g_list_2efind_24s1085725546x1737150855_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1085725546x1737150855_entry, 2, 0};

V g_list_2efind_24s1085725546x1737150855(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 2));
    if (heff_intLe_c(heff_dup(heff_rfield(v_a_244, 0)), heff_dup(v_lit_240))) {
      if (heff_intLe_c(heff_dup(v_lit_240), heff_get_n(v_a_244, 1, 2))) {
        heff_drop(v_lit_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_a_244, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1085725546x1737150855_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s1085725546x1737150855(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s496727651x1448898893_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s496727651x1448898893_entry, 2, 0};

V g_list_2efoldl_24s496727651x1448898893(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkEquation: {
        V v_a_249 = heff_field(v_a_244, 3);
        v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_249));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s496727651x1448898893(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1490692278x809324339_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1490692278x809324339_entry, 1, 0};

V g_list_2efilter_24s1490692278x809324339(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_241, 10);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2efilter_24s1490692278x809324339_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1490692278x809324339_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1490692278x809324339(a[0]);
}
Clo g_list_2emap_24s2005951263x462916503_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2005951263x462916503_entry, 6, 0};

V g_list_2emap_24s2005951263x462916503(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_246, 0));
      v_t_2410 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_t_2411 = (g_heff_2eutil_2ejson_2eescapeGo(v_t_2410, heff_dup(v_lit_241), heff_dup(v_lit_242)));
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
    V v_t_2415;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_246, 1);
      heff_take_n(v_x_246, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), v_t_2416));
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = (g_list_2emap_24s2005951263x462916503_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s2005951263x462916503_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2005951263x462916503(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s580776739x648604941_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s580776739x648604941_entry, 1, 0};

V g_list_2emap_24s580776739x648604941(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_TagVariant: {
        V v_t_245 = heff_field(v_x11_243, 0);
        V v_args_247 = heff_field(v_x11_243, 2);
        heff_take_n(v_x11_243, 5ULL, 3);
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__args, (V[]){v_t_245, v_args_247})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_249 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s580776739x648604941_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s580776739x648604941_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s580776739x648604941(a[0]);
}
Clo g_list_2efind_24s1637307977x1351693783_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1637307977x1351693783_entry, 6, 0};

V g_list_2efind_24s1637307977x1351693783(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_x_246, 0)), heff_dup(v_lit_242));
    V v_t_249 = heff_strFind(heff_strAppend(heff_dup(v_lit_241), v_t_248), heff_dup(v_lit_243), heff_dup(v_lit_244));
    if (heff_intLe_c(heff_dup(v_lit_240), v_t_249)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_246)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2efind_24s1637307977x1351693783_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_list_2efind_24s1637307977x1351693783(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
Clo g_list_2efilter_24s951260806x709953240_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s951260806x709953240_24dps_entry, 3, 0};

V g_list_2efilter_24s951260806x709953240_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2410;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_lit_240, 0);
      v_t_2410 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    if (heff_strEq_c(v_t_247, v_t_2410)) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_2412;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s951260806x709953240_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efilter_24s951260806x709953240_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1281445768x1036802655_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1281445768x1036802655_entry, 1, 0};

V g_list_2emap_24s1281445768x1036802655(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagWord(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1281445768x1036802655_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1281445768x1036802655(a[0]);
}
Clo g_list_2efilter_24s1623010005x1805617852_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1623010005x1805617852_entry, 1, 0};

V g_list_2efilter_24s1623010005x1805617852(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 2));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2efilter_24s1623010005x1805617852_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_241, 4);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1623010005x1805617852_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1623010005x1805617852(a[0]);
}
Clo g_list_2emap_24f1352858702x862623587_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1352858702x862623587_entry, 5, 0};

V g_list_2emap_24f1352858702x862623587(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_p_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = heff_tr(heff_call(heff_dup(v_p_243), 1, (V[]){heff_dup(v_x_245)}));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = heff_strAppend(heff_take_field(v_x_245, 1), heff_dup(v_lit_242));
      V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 2), heff_get_n(v_x_245, 3, 7)});
      V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), heff_strAppend(heff_dup(v_lit_241), v_t_248), v_t_249, NTAG(TAG_Nothing)});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = (g_list_2emap_24f1352858702x862623587_24dps(v_lit_240, v_lit_241, v_lit_242, v_p_243, v_xs_246, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    } else {
      heff_drop_rec(v_x_245, 7);
      heff_drop_cell(v_ru_24x2_244_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_p_243;
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_p_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f1352858702x862623587_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1352858702x862623587(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24f421425463x1941958307_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f421425463x1941958307_entry, 3, 0};

V g_list_2efoldl_24f421425463x1941958307(V v_z_240, V v_p_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_z_240});
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_z_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f421425463x1941958307_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f421425463x1941958307(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f783067987x1926181389_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f783067987x1926181389_24dps_entry, 6, 0};

V g_list_2emap_24f783067987x1926181389_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_a_243, V v_b_244, V v_d_245) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_244), heff_dup(v_a_243))) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_a_243);
    heff_drop(v_b_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_247 = heff_intSub(heff_intSub(heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_a_243));
    V v_cell_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(v_t_247, heff_dup(v_lit_242)), heff_hole()});
    V v_u_249 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = heff_intAdd(v_a_243, MK_INT(1LL));
    V t_4 = v_b_244;
    V t_5 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_a_243 = t_3;
    v_b_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
}
V g_list_2emap_24f783067987x1926181389_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f783067987x1926181389_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24f1229912102x1467950109_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1229912102x1467950109_24dps_entry, 3, 0};

V g_list_2emap_24f1229912102x1467950109_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_246 = (g_list_2emap_24s2029035892x1571084362(v_xs_244));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_247;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1229912102x1467950109_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1229912102x1467950109_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f675617784x1820039874_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f675617784x1820039874_entry, 2, 0};

V g_list_2efoldl_24f675617784x1820039874(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_x_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f675617784x1820039874(a[0], a[1]);
}
Clo g_list_2emap_24f489129082x766375942_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f489129082x766375942_24dps_entry, 6, 0};

V g_list_2emap_24f489129082x766375942_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_x_2410;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_246, 0);
      heff_take_n(v_x_246, 1ULL, 2);
      v_x_2410 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_a_2411 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_lit_241));
    V v_t_2412 = heff_strSlice(heff_dup(v_x_2410), heff_dup(v_lit_242), heff_strLength_lent(v_a_2411, 0));
    V v_t_2417;
    if (heff_strEq_c(v_t_2412, v_a_2411)) {
      V v_t_2414 = heff_strLength(heff_dup(heff_rfield(v_lit_240, 0)));
      V v_t_2415 = heff_strSlice(heff_dup(v_x_2410), heff_intAdd(v_t_2414, heff_dup(v_lit_243)), heff_strLength_lent(v_x_2410, 0));
      V v_t_2416 = heff_rec_n(3, shape_name__key__module, (V[]){v_t_2415, v_x_2410, heff_dup(heff_rfield(v_lit_240, 0))});
      v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
    } else {
      heff_drop(v_x_2410);
      v_t_2417 = NTAG(TAG_Nothing);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2418));
    heff_drop(v_u_2419);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_xs_247;
    V t_5 = v_cell_2418;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_x2_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f489129082x766375942_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f489129082x766375942_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24f1502491305x440718220_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1502491305x440718220_entry, 2, 0};

V g_list_2emap_24f1502491305x440718220(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return (g_list_2emap_24s864521685x1610969087(v_ys_241));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2edriver_2ehint(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24f1502491305x440718220_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2emap_24f1502491305x440718220_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1502491305x440718220(a[0], a[1]);
}
Clo g_list_2efoldl_24f1134152647x940271785_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1134152647x940271785_entry, 2, 0};

V g_list_2efoldl_24f1134152647x940271785(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(heff_dup(heff_rfield(v_x_242, 0))));
    V v_x_245 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_244));
    V v_t_246 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_245));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f1134152647x940271785(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f1160581125x508466714_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1160581125x508466714_entry, 2, 0};

V g_list_2efoldl_24f1160581125x508466714(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_x_244 = (g_heff_2esyntax_2efmt_2elayout_2einlineDoc(heff_dup(v_x_242)));
    V v_t_245 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f1160581125x508466714(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f1559904364x1248618624_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1559904364x1248618624_entry, 3, 0};

V g_list_2efoldl_24f1559904364x1248618624(V v_z_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_x_243)}));
    V v_t_246 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_245));
    V t_0 = v_t_246;
    V t_1 = v_f_241;
    V t_2 = v_xs_244;
    v_z_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1559904364x1248618624(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f768999161x1997188166_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f768999161x1997188166_24dps_entry, 4, 0};

V g_list_2emap_24f768999161x1997188166_24dps(V v_lit_240, V v_i_241, V v_n_242, V v_d_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_242), heff_dup(v_i_241))) {
    heff_drop(v_lit_240);
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strByteAt_lent(v_lit_240, v_i_241, 0), heff_hole()});
    V v_u_246 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_n_242;
    V t_3 = v_cell_245;
    v_lit_240 = t_0;
    v_i_241 = t_1;
    v_n_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f768999161x1997188166_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f768999161x1997188166_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f1133029339x682401273_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1133029339x682401273_24dps_entry, 2, 0};

V g_list_2emap_24f1133029339x682401273_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 2, 3);
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 0, 3);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 1, 3);
      V v_t_247 = heff_rec_n(3, shape_name__field__use, (V[]){v_t_245, v_t_246, heff_get_n(v_x_242, 1, 2)});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_243;
      V t_1 = v_cell_248;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f1133029339x682401273_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1133029339x682401273_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps_entry, 5, 0};

V g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_take_field(v_x_245, 2);
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_x_248 = heff_get_n(v_x_245, 0, 4);
      V v_t_249 = heff_strSlice(heff_dup(v_x_248), heff_dup(v_lit_241), heff_strLength_lent(v_lit_242, 0));
      if (heff_strEq_c_lent(v_t_249, v_lit_242, 1)) {
        V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_248, heff_dup(v_lit_240)), heff_hole()});
        V v_u_2412 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2411));
        heff_drop(v_u_2412);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_cell_2411;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        v_d_244 = t_4;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        heff_drop(v_x_248);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_d_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_245, 4);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24f556306710x2087456230_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f556306710x2087456230_entry, 4, 0};

V g_list_2efoldl_24f556306710x2087456230(V v_lit_240, V v_z_241, V v_f_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_f_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_x_246 = heff_tr(heff_call(heff_dup(v_f_242), 1, (V[]){heff_dup(v_x_244)}));
    heff_drop(v_x_246);
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_f_242;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_f_242 = t_2;
    v_x2_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f556306710x2087456230(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}