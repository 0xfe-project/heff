// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Processors 11008
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_bind 9519364
#define LBL_diags 296935042
#define LBL_discarded 1490202606
#define LBL_done 9584713
#define LBL_errors 652506774
#define LBL_failure 1292767177
#define LBL_goldens 436112074
#define LBL_jobs 9763101
#define LBL_labels 836724522
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_pattern 1588251091
#define LBL_property 1899481104
#define LBL_root 10001833
#define LBL_run 322821
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_seen 10021698
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_update 1108295668
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_seed__pattern__jobs__update[] = {LBL_seed, LBL_pattern, LBL_jobs, LBL_update};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731(V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_clo;
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288(V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944(V, V);
V g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_clo;
HeffT2 g_heff_2ebuild_2ecommands_2einitProblem_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2ejsonFailure(V);
V g_heff_2ebuild_2ecommands_2ejsonFailure_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsonFailure_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2enameLike(V);
V g_heff_2ebuild_2ecommands_2enameLike_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enameLike_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1(V, V, V);
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprogramText(V);
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprogramText_clo;
V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_clo;
V g_heff_2ebuild_2ecommands_2etestDir(V, V);
V g_heff_2ebuild_2ecommands_2etestDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestDir_clo;
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_clo;
V g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2erenderDiag(V, V, V);
V g_heff_2elsp_2erender_2erenderDiag_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erenderDiag_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1618539892x552009225(V);
V g_list_2emap_24s1618539892x552009225_entry(V self, V *a);
extern Clo g_list_2emap_24s1618539892x552009225_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s809490196x1189312632(V);
V g_list_2emap_24s809490196x1189312632_entry(V self, V *a);
extern Clo g_list_2emap_24s809490196x1189312632_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(V);
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_clo;
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(V);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_clo;
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(V, V);
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_242, v_seen_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2ecommands_2enubStrGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_rest_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_str0, 22, "-- test: expect errors");

static V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eexpectErrorsLine_st;
static V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_init(void) {
  return ((V)&g_heff_2ebuild_2ecommands_2eexpectErrorsLine_str0);
}
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_st)) return g_heff_2ebuild_2ecommands_2eexpectErrorsLine_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eexpectErrorsLine_val, &g_heff_2ebuild_2ecommands_2eexpectErrorsLine_st, g_heff_2ebuild_2ecommands_2eexpectErrorsLine_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str0, 10, ".heff/test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str6, 1, "_");
Clo g_heff_2ebuild_2ecommands_2etestDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestDir_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etestDir(V v_paths_240, V v_file_241) {
top: ;
  V v_style_242 = heff_take_field(v_paths_240, 5);
  V v_root_243 = heff_get_n(v_paths_240, 0, 6);
  V v_st_244 = heff_dup(v_style_242);
  V v_t_245 = (g_std_2epath_2eparse(v_st_244, v_root_243));
  V v_t_246 = (g_std_2epath_2eparse(v_st_244, ((V)&g_heff_2ebuild_2ecommands_2etestDir_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_d_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
  HeffT3 v_t_249 = (g_std_2epath_2eparse_24cpr(v_style_242, v_file_241));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_field_2412 = v_t_249.f[2];
    V v_d_2413 = v_field_2410;
    heff_drop(v_d_2413);
    V v_a_2414 = v_field_2411;
    V v_xs_2415 = v_field_2412;
    V v_xs_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str1); V a_1 = v_a_2414; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str2); V b_3 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str3); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2415; V r_ = (g_list_2efoldl_24s680990791x1764841948(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(v_a_2414); heff_drop(b_3); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
    V v_x2_2418 = v_t_2417;
    V v_p_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_p_2421 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_p_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str6); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_st_2422 = v_style_242;
    V v_t_2423 = (g_std_2epath_2eparse(v_st_2422, v_d_248));
    V v_t_2424 = (g_std_2epath_2eparse(v_st_2422, v_p_2421));
    V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
    return ({ V a_0 = v_st_2422; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2425); r_; });
  }
}
V g_heff_2ebuild_2ecommands_2etestDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str1, 20, "heff: the directory ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str2, 82, " has no name to name a package by: say the project's directory, as `heff init DIR`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str3, 36, "): name it otherwise, as `heff init ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str5, 25, "` cannot name a package (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str6, 21, "heff: the directory `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str7, 62, "heff: `heff` is heff's own package: name the project otherwise");

HeffT2 g_heff_2ebuild_2ecommands_2einitProblem_24cpr(V v_shown_240, V v_name_241) {
top: ;
  if (heff_strEq_c_lent(v_name_241, ((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str0), 2)) {
    heff_drop(v_name_241);
    V v_f_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str1), heff_strAppend(v_shown_240, ((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str2)));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_242}});
  } else {
    heff_drop(v_shown_240);
    HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_name_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_why_246 = v_field_245;
        V v_t_247 = (g_heff_2ebuild_2ecommands_2enameLike(v_name_241));
        V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str3), heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str4)));
        V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str5), heff_strAppend(v_why_246, v_t_248));
        V v_f_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str6), heff_strAppend(v_name_241, v_t_249));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
      } else {
        heff_drop(v_field_245);
        if (heff_strEq_c(v_name_241, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str7)}});
        } else {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str0, 15, "-- The program ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str1, 42, ": `heff build` builds it to .heff/bin/, as");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str2, 29, "-- a build, by `heff run app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str3, 10, "/main.hf`.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str4, 11, "module app.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str5, 5, ".main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str6, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str7, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str9, 20, "main : Co stdio Unit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str10, 24, "main = program (io := _)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str11, 34, "program = print (greeting \"world\")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str14, 60, "program : {e : HFunctor} -> {{io : stdio <: e}} -> Co e Unit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str15, 13, "import std.io");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str17, 9, "import co");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str19, 68, "-- build.hf says, and `heff install` into ~/.heff/bin/; run, without");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str20, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprogramText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprogramText_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eprogramText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str1)));
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str2), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str3)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str4), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str5)));
  V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str6), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str7)));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str8), NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str10), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str12), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str14), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str15), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str16), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str17), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str18), heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str19), heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_2411})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str20); V a_1 = v_t_241; V a_2 = v_t_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2412, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprogramText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_str0, 8, "HEFF_LIB");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_str2, 3, "lib");
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_str0), ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  return v_s_2412;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_st_2422 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2424 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2422, v_x_2423));
  V v_t_2425 = (g_std_2epath_2eparse(v_st_2422, v_a_2424));
  V v_t_2426 = (g_std_2epath_2eparse(v_st_2422, ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_str2)));
  V v_t_2427 = (g_std_2epath_2ejoin(v_t_2425, v_t_2426));
  V v_x_2428 = ({ V a_0 = v_st_2422; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2427); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_st_2422;
  if (heff_strEq_c(v_x_2421, ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_str1))) {
    v_st_2422 = NTAG(TAG_Windows);
  } else {
    v_st_2422 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam4, 1, 2, (V[]){v_st_2422, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam2_clo)})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2419}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2420;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_lam3, 1, 2, (V[]){v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_lib_2429 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_lib_2429;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_str1, 2, "\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_str3, 0, "");
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam4, 2, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(V v_rep_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    return ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_241, 0);
    V v_rest_245 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_diags_246 = heff_take_field(v_c_244, 6);
    V v_source_247 = heff_take_field(v_c_244, 3);
    V v_path_248 = heff_get_n(v_c_244, 1, 14);
    V v_t_2410 = heff_tr(heff_call(heff_dup(v_rep_240), 1, (V[]){heff_tag_n(TAG_ErrColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam1_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam2, 2, 6, (V[]){v_t_2410, v_diags_246, v_source_247, v_path_248, v_rep_240, v_rest_245});
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam1(V self, V *args) {
  V v_b_249 = args[0];
  return v_b_249;
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam4(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam5(V self, V *args) {
  V v_d_2419 = args[0];
  V v_path_248 = heff_env(self)[0];
  V v_src_2418 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = (g_heff_2elsp_2erender_2ediagWhere(v_path_248, v_src_2418, heff_dup(v_d_2419)));
  V v_t_2421 = ({ V a_0 = v_x_2413; V a_1 = v_src_2418; V a_2 = v_d_2419; V r_ = (g_heff_2elsp_2erender_2erenderDiag(a_0, a_1, a_2)); heff_drop(v_x_2413); heff_drop(v_src_2418); r_; });
  V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_str0), heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_str1)));
  return heff_strAppend(v_t_2420, v_t_2422);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2435);
  V v_t_2436 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(v_rep_240, v_rest_245));
  V f_ = v_t_2436;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_diags_246 = heff_env(self)[0];
  V v_source_247 = heff_env(self)[1];
  V v_path_248 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2434;
  switch (heff_tag_of(v_diags_246)) {
  case TAG_Nil: {
    heff_drop(v_x_2413);
    heff_drop(v_source_247);
    heff_drop(v_path_248);
    v_c_2434 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam4_clo);
    break;
  }
  case TAG_Cons: {
    V v_src_2418 = v_source_247;
    V v_x2_2423 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam5, 1, 3, (V[]){v_path_248, v_src_2418, v_x_2413}), v_diags_246));
    V v_str_2426;
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_Nil: {
      v_str_2426 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_xs_2425 = heff_field(v_x2_2423, 1);
      heff_take_n(v_x2_2423, 3ULL, 2);
      v_str_2426 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_str3); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2423);
    }
    V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_str_2426, NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
    v_c_2434 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})}));
    break;
  }
  default: heff_nomatch(v_diags_246);
  }
  V f_ = v_c_2434;
  heff_room[0] = heff_dup(v_hd_2411);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam6, 1, 4, (V[]){v_rep_240, v_rest_245, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_t_2410 = heff_env(self)[0];
  V v_diags_246 = heff_env(self)[1];
  V v_source_247 = heff_env(self)[2];
  V v_path_248 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_co_2eop_24s615738393x1686646143(v_t_2410, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_lam3, 1, 7, (V[]){v_diags_246, v_source_247, v_path_248, v_hd_2411, v_rep_240, v_rest_245, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str3, 17, "heff test: --run ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str5, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str6, 0, "");
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729(V v_seed_240, V v_pattern_241, V v_jobs_242, V v_update_243) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str0);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_pattern_241, 0);
    v_t_245 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_246 = ({ V a_0 = MK_INT(47LL); V a_1 = v_t_245; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_list_2emap_24s1007499915x73800978(v_t_246));
  HeffT2 v_t_248 = (g_regex_2eallRead_24cpr(v_t_247));
  V v_c_2437;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_why_2411 = v_field_2410;
      v_c_2437 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam0, 2, 2, (V[]){heff_dup(v_pattern_241), v_why_2411});
    } else {
      V v_x_2434 = v_field_2410;
      heff_drop(v_x_2434);
      v_c_2437 = ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam2_clo);
    }
  }
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam3, 2, 5, (V[]){v_c_2437, heff_dup(v_seed_240), heff_dup(v_pattern_241), heff_dup(v_jobs_242), v_update_243});
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_hd_2412, v_k_2413));
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_pattern_241 = heff_env(self)[0];
  V v_why_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_2415 = ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_pattern_241, 0);
    heff_take_n(v_pattern_241, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_2416 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str2), v_why_2411));
  V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str3), v_t_2416), ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str4));
  V v_t_2418 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2417, NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})}));
  V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
  args[0] = v_t_2425;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam1, 1, 2, (V[]){v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam2(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam5(V self, V *args) {
  V v_n_2441 = args[0];
  return v_n_2441;
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam7(V self, V *args) {
  V v_v_2451 = args[0];
  return v_v_2451;
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam8(V self, V *args) {
  V v_x_2460 = args[0];
  V v_seed_240 = heff_env(self)[0];
  V v_pattern_241 = heff_env(self)[1];
  V v_x_2450 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_k_2439 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2466;
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    v_t_2466 = MK_INT(2026LL);
    break;
  }
  case TAG_Just: {
    V v_s_2461 = heff_field(v_seed_240, 0);
    heff_take_n(v_seed_240, 1ULL, 1);
    HeffT2 v_t_2462 = ({ V a_0 = v_s_2461; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_s_2461); r_; });
    {
      V v_field_2464 = v_t_2462.f[1];
      int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
      if ((v_tag_2463 == ((int64_t)0ULL))) {
        V v_x_2465 = v_field_2464;
        v_t_2466 = v_x_2465;
      } else {
        heff_drop(v_field_2464);
        v_t_2466 = MK_INT(2026LL);
      }
    }
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_2468;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_2468 = ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str6);
    break;
  }
  case TAG_Just: {
    V v_x_2467 = heff_field(v_pattern_241, 0);
    heff_take_n(v_pattern_241, 1ULL, 1);
    v_t_2468 = v_x_2467;
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_fallback_2469;
  if (heff_intLt_c(heff_intDiv(heff_dup(v_x_2450), MK_INT(2LL)), MK_INT(1LL))) {
    heff_drop(v_x_2450);
    v_fallback_2469 = MK_INT(1LL);
  } else {
    v_fallback_2469 = heff_intDiv(v_x_2450, MK_INT(2LL));
  }
  V v_fallback_2475;
  switch (heff_tag_of(v_x_2460)) {
  case TAG_Nothing: {
    v_fallback_2475 = v_fallback_2469;
    break;
  }
  case TAG_Just: {
    V v_n_2470 = heff_field(v_x_2460, 0);
    heff_take_n(v_x_2460, 1ULL, 1);
    HeffT2 v_t_2471 = ({ V a_0 = v_n_2470; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_n_2470); r_; });
    {
      V v_field_2473 = v_t_2471.f[1];
      int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
      if ((v_tag_2472 == ((int64_t)0ULL))) {
        V v_k_2474 = v_field_2473;
        if (heff_intLt_c_lent(MK_INT(0LL), v_k_2474, 1)) {
          heff_drop(v_fallback_2469);
          v_fallback_2475 = v_k_2474;
        } else {
          heff_drop(v_k_2474);
          v_fallback_2475 = v_fallback_2469;
        }
      } else {
        heff_drop(v_field_2473);
        v_fallback_2475 = v_fallback_2469;
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2460);
  }
  V v_t_2481;
  switch (heff_tag_of(v_jobs_242)) {
  case TAG_Nothing: {
    v_t_2481 = v_fallback_2475;
    break;
  }
  case TAG_Just: {
    V v_n_2476 = heff_field(v_jobs_242, 0);
    heff_take_n(v_jobs_242, 1ULL, 1);
    HeffT2 v_t_2477 = ({ V a_0 = v_n_2476; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_n_2476); r_; });
    {
      V v_field_2479 = v_t_2477.f[1];
      int64_t v_tag_2478 = ((int64_t)v_t_2477.f[0]);
      if ((v_tag_2478 == ((int64_t)0ULL))) {
        V v_k_2480 = v_field_2479;
        if (heff_intLt_c_lent(MK_INT(0LL), v_k_2480, 1)) {
          heff_drop(v_fallback_2475);
          v_t_2481 = v_k_2480;
        } else {
          heff_drop(v_k_2480);
          v_t_2481 = v_fallback_2475;
        }
      } else {
        heff_drop(v_field_2479);
        v_t_2481 = v_fallback_2475;
      }
    }
    break;
  }
  default: heff_nomatch(v_jobs_242);
  }
  V v_x_2482 = heff_rec_n(4, shape_seed__pattern__jobs__update, (V[]){v_t_2466, v_t_2468, v_t_2481, v_update_243});
  V f_ = v_k_2439;
  args[0] = v_x_2482;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam6(V self, V *args) {
  V v_x_2450 = args[0];
  V v_hd_2438 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_k_2439 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_str5), ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam7_clo)})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_call(heff_take_field(v_hd_2438, 2), 1, (V[]){v_t_2458}));
  V f_ = heff_get_n(v_hd_2438, 1, 3);
  heff_room[0] = v_t_2459;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam8, 1, 6, (V[]){v_seed_240, v_pattern_241, v_x_2450, v_jobs_242, v_update_243, v_k_2439});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2438 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_k_2439 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2440);
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Processors, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam5_clo)})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2438, 2)), 1, (V[]){v_t_2448}));
  V f_ = heff_dup(heff_rfield(v_hd_2438, 1));
  heff_room[0] = v_t_2449;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam6, 1, 6, (V[]){v_hd_2438, v_seed_240, v_pattern_241, v_jobs_242, v_update_243, v_k_2439});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam3(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_c_2437 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2437;
  args[0] = heff_dup(v_hd_2438);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_lam4, 1, 6, (V[]){v_hd_2438, v_seed_240, v_pattern_241, v_jobs_242, v_update_243, v_k_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731(V v_rep_240, V v_file_241, V v_outPath_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_file_241)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_lam0, 2, 4, (V[]){v_c_243, v_rep_240, v_file_241, v_outPath_242});
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_outPath_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2410 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_247, 1));
  heff_drop(v_x_247);
  return ({ V a_0 = v_rep_240; V a_1 = v_file_241; V a_2 = v_outPath_242; V a_3 = v_t_2410; V a_4 = heff_get_n(v_x_249, 0, 2); V a_5 = v_hd_244; V a_6 = v_k_245; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s2016481086x1916919563(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_file_241); heff_drop(v_t_2410); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_file_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_248 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(v_x_246));
  V f_ = v_c_248;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_lam3, 1, 6, (V[]){v_x_247, v_rep_240, v_file_241, v_outPath_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_outPath_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_str0), heff_dup(heff_rfield(v_x_246, 1)), MK_INT(0LL), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_lam2, 1, 6, (V[]){v_x_246, v_hd_244, v_rep_240, v_file_241, v_outPath_242, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_outPath_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_lam1, 1, 5, (V[]){v_hd_244, v_rep_240, v_file_241, v_outPath_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_str1, 23, "heff doc: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam2, 3, 0};
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam4, 3, 0};
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288(V v_path_240, V v_text_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam1, 1, 4, (V[]){v_path_240, v_hd_242, v_text_241, v_k_243})});
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2430 = args[1];
  V v_k_2431 = args[2];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_2437 = args[1];
  V v_k_2438 = args[2];
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam6(V self, V *args) {
  V v_x_2451 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2451);
  V v_t_2452 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam5(V self, V *args) {
  V v_x_2440 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Left: {
    V v_ru_24x_2440_24Left = heff_take_reuse_n(v_x_2440, 0ULL, 1);
    V v_t_2442 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_str1), v_path_240), ((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_str2));
    V v_t_2443 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2442, NTAG(TAG_MkUnit)});
    V v_t_2444 = heff_tag_at_n(v_ru_24x_2440_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})}));
    V f_ = heff_dup(heff_rfield(v_hd_242, 1));
    heff_room[0] = v_t_2450;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam6, 1, 2, (V[]){v_hd_242, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2440, 0ULL, 1);
    heff_drop(v_path_240);
    heff_drop_rec(v_hd_242, 3);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2440);
  }
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_text_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2433);
  V v_path_2434 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_path_240); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2435 = ({ V a_0 = v_path_2434; V a_1 = v_text_241; V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_2434); r_; });
  V v_c_2439 = heff_tr(heff_call(v_c_2435, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam4_clo)}));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam5, 1, 3, (V[]){v_path_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_text_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2414;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_str0))) {
    v_st_2414 = NTAG(TAG_Windows);
  } else {
    v_st_2414 = NTAG(TAG_Posix);
  }
  HeffT3 v_t_2415 = (g_std_2epath_2eparse_24cpr(v_st_2414, heff_dup(v_path_240)));
  V v_t_2425;
  {
    V v_field_2416 = v_t_2415.f[0];
    V v_field_2417 = v_t_2415.f[1];
    V v_field_2418 = v_t_2415.f[2];
    V v_d_2419 = v_field_2416;
    V v_a_2420 = v_field_2417;
    V v_xs_2421 = v_field_2418;
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2421));
    V v_xs_2423 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2422; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2422); r_; });
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2423));
    v_t_2425 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2419, v_a_2420, v_t_2424});
  }
  V v_s_2426 = ({ V a_0 = v_st_2414; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2425); r_; });
  V v_path_2427 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2426; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2428 = ({ V a_0 = v_path_2427; V r_ = (g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(a_0)); heff_drop(v_path_2427); r_; });
  V v_c_2432 = heff_tr(heff_call(v_c_2428, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam2_clo)}));
  V f_ = v_c_2432;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_lam3, 1, 4, (V[]){v_path_240, v_text_241, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str1, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str3, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str4, 20, "compiling for a page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str5, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str6, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str7, 12, "passed over ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str8, 32, ": a page's script, not a program");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam15(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam15, 3, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam22(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam20(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648(V v_rep_240, V v_prog_241, V v_st_242, V v_t_243, V v_bp_244, V v_x_245, V v_a_246, V v_next_247) {
top: ;
  V v_backend_248 = heff_take_field(v_a_246, 0);
  V v_run_249 = heff_get_n(v_a_246, 1, 3);
  if (heff_strEq_c(v_backend_248, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str0))) {
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_244, heff_dup(v_x_245), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam0_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam1, 2, 8, (V[]){v_t_2411, v_prog_241, heff_dup(v_st_242), v_t_243, v_x_245, v_next_247, v_rep_240, v_run_249});
  } else {
    V v_t_2434 = heff_dup(heff_rfield(v_t_243, 3));
    if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
      heff_drop(v_t_2434);
      V v_t_2436 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_244, heff_dup(v_x_245), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam10_clo)})}));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam11, 2, 8, (V[]){v_t_2436, v_prog_241, heff_dup(v_st_242), v_t_243, v_x_245, v_rep_240, v_run_249, v_next_247});
    } else {
      heff_drop(v_rep_240);
      heff_drop_rec(v_t_243, 6);
      heff_drop(v_run_249);
      heff_drop(v_t_2434);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam20, 2, 4, (V[]){v_x_245, v_bp_244, v_prog_241, v_next_247});
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam0(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam3(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_next_247 = heff_env(self)[0];
  V v_hd_2423 = heff_env(self)[1];
  V v_k_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2425);
  V f_ = v_next_247;
  heff_room[0] = v_hd_2423;
  heff_room[1] = v_k_2424;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam5(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_t_2422 = heff_env(self)[0];
  V v_next_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s615738393x1686646143(v_t_2422, heff_dup(v_hd_2423), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam6, 1, 3, (V[]){v_next_247, v_hd_2423, v_k_2424})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam9(V self, V *args) {
  V v_x_2433 = args[0];
  V v_next_2426 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2433);
  V f_ = v_next_2426;
  heff_room[0] = v_hd_2431;
  heff_room[1] = v_k_2432;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam8(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_t_2428 = heff_env(self)[0];
  V v_next_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s615738393x1686646143(v_t_2428, heff_dup(v_hd_2431), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam9, 1, 3, (V[]){v_next_2426, v_hd_2431, v_k_2432})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_run_249 = heff_env(self)[1];
  V v_outPath_2419 = heff_env(self)[2];
  V v_file_2420 = heff_env(self)[3];
  V v_t_2428 = heff_env(self)[4];
  V v_next_2426 = heff_env(self)[5];
  V v_hd_2412 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661(MK_INT(1LL), v_rep_240, v_x_2430, heff_tag_n(TAG_Just, 1, (V[]){v_run_249}), v_outPath_2419, v_file_2420, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam8, 2, 2, (V[]){v_t_2428, v_next_2426}), v_hd_2412, v_k_2413));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_next_247 = heff_env(self)[5];
  V v_hd_2412 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  V v_run_249 = heff_env(self)[8];
  V v_k_2413 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2418 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_242, heff_dup(v_t_243), heff_dup(v_x_245)));
  V v_outPath_2419 = heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str2));
  V v_file_2420 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_242, heff_dup(v_t_243), heff_dup(v_x_245), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str3)));
  V v_t_2421 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2414), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2421}));
  V v_next_2426 = ({ V a_0 = heff_dup(v_prog_241); V a_1 = v_st_242; V a_2 = v_t_243; V a_3 = v_x_2414; V a_4 = v_x_245; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam5, 2, 2, (V[]){v_t_2422, v_next_247}); V r_ = (g_heff_2ebuild_2ecommands_2ezigCc_24s414210475x2125188504(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_242); r_; });
  V v_t_2427 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2427}));
  V v_c_2429 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_file_2420)));
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam7, 1, 8, (V[]){v_rep_240, v_run_249, v_outPath_2419, v_file_2420, v_t_2428, v_next_2426, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_next_247 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_run_249 = heff_env(self)[7];
  V v_k_2413 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2416 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2414), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam3_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2416, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam4, 1, 10, (V[]){v_st_242, v_t_243, v_x_245, v_x_2414, v_prog_241, v_next_247, v_hd_2412, v_rep_240, v_run_249, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_t_2411 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_next_247 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_run_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_co_2eop_24s615738393x1686646143(v_t_2411, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam2, 1, 9, (V[]){v_prog_241, v_hd_2412, v_st_242, v_t_243, v_x_245, v_next_247, v_rep_240, v_run_249, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam10(V self, V *args) {
  V v_t_2435 = args[0];
  return v_t_2435;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam13(V self, V *args) {
  V v_t_2440 = args[0];
  return v_t_2440;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam15(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_2447 = args[1];
  V v_k_2448 = args[2];
  heff_drop(v_hd_2447);
  V f_ = v_k_2448;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2446});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam19(V self, V *args) {
  V v_x_2464 = args[0];
  V v_next_247 = heff_env(self)[0];
  V v_hd_2461 = heff_env(self)[1];
  V v_k_2462 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2464);
  V f_ = v_next_247;
  heff_room[0] = v_hd_2461;
  heff_room[1] = v_k_2462;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam18(V self, V *args) {
  V v_x_2463 = args[0];
  V v_t_2458 = heff_env(self)[0];
  V v_hd_2461 = heff_env(self)[1];
  V v_next_247 = heff_env(self)[2];
  V v_k_2462 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2463);
  return (g_co_2eop_24s615738393x1686646143(v_t_2458, heff_dup(v_hd_2461), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam19, 1, 3, (V[]){v_next_247, v_hd_2461, v_k_2462})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam17(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_t_2460 = heff_env(self)[0];
  V v_t_2458 = heff_env(self)[1];
  V v_next_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s615738393x1686646143(v_t_2460, heff_dup(v_hd_2461), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam18, 1, 4, (V[]){v_t_2458, v_hd_2461, v_next_247, v_k_2462})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam16(V self, V *args) {
  V v_x_2450 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_2439 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_x_2442 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_run_249 = heff_env(self)[7];
  V v_next_247 = heff_env(self)[8];
  V v_hd_2437 = heff_env(self)[9];
  V v_k_2438 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2450);
  V v_a_2451 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_242, heff_dup(v_t_243), heff_dup(v_x_245)));
  V v_t_2452 = (g_std_2epath_2eparse(v_st_242, v_a_2451));
  V v_t_2453 = (g_std_2epath_2eparse(v_st_242, heff_strAppend(heff_dup(v_x_245), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str5))));
  V v_t_2454 = (g_std_2epath_2ejoin(v_t_2452, v_t_2453));
  V v_t_2455 = ({ V a_0 = v_st_242; V a_1 = v_t_2454; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2454); r_; });
  V v_t_2456 = ({ V a_0 = v_st_242; V a_1 = v_t_243; V a_2 = v_x_245; V a_3 = ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str6); V r_ = (g_heff_2ebuild_2ecommands_2eappFile(a_0, a_1, a_2, a_3)); heff_drop(v_st_242); r_; });
  V v_t_2457 = heff_tag_n(TAG_End, 2, (V[]){v_x_2439, NTAG(TAG_MkUnit)});
  V v_t_2458 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2457}));
  V v_t_2459 = heff_tag_n(TAG_End, 2, (V[]){v_x_2442, NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2459}));
  V v_t_2465 = ({ V a_0 = v_rep_240; V b_1 = heff_tag_n(TAG_Just, 1, (V[]){v_run_249}); V a_2 = v_t_2455; V a_3 = v_t_2456; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam17, 2, 3, (V[]){v_t_2460, v_t_2458, v_next_247}); V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  V f_ = v_t_2465;
  heff_room[0] = v_hd_2437;
  heff_room[1] = v_k_2438;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam14(V self, V *args) {
  V v_x_2442 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_hd_2437 = heff_env(self)[3];
  V v_x_2439 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_run_249 = heff_env(self)[7];
  V v_next_247 = heff_env(self)[8];
  V v_k_2438 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_s_2443 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_242, heff_dup(v_t_243), heff_dup(v_x_245)));
  V v_path_2444 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2443; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2445 = ({ V a_0 = v_path_2444; V r_ = (g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(a_0)); heff_drop(v_path_2444); r_; });
  V v_c_2449 = heff_tr(heff_call(v_c_2445, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam15_clo)}));
  V f_ = v_c_2449;
  heff_room[0] = heff_dup(v_hd_2437);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam16, 1, 11, (V[]){v_st_242, v_t_243, v_x_245, v_x_2439, v_prog_241, v_x_2442, v_rep_240, v_run_249, v_next_247, v_hd_2437, v_k_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam12(V self, V *args) {
  V v_x_2439 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_hd_2437 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_run_249 = heff_env(self)[6];
  V v_next_247 = heff_env(self)[7];
  V v_k_2438 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2441 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2439), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str4), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam13_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2441, heff_dup(v_hd_2437), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam14, 1, 10, (V[]){v_st_242, v_t_243, v_x_245, v_hd_2437, v_x_2439, v_prog_241, v_rep_240, v_run_249, v_next_247, v_k_2438})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam11(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_t_2436 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_run_249 = heff_env(self)[6];
  V v_next_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_co_2eop_24s615738393x1686646143(v_t_2436, heff_dup(v_hd_2437), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam12, 1, 9, (V[]){v_prog_241, v_hd_2437, v_st_242, v_t_243, v_x_245, v_rep_240, v_run_249, v_next_247, v_k_2438})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam22(V self, V *args) {
  V v_x_2480 = args[0];
  V v_next_247 = heff_env(self)[0];
  V v_hd_2466 = heff_env(self)[1];
  V v_k_2467 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2480);
  V f_ = v_next_247;
  heff_room[0] = v_hd_2466;
  heff_room[1] = v_k_2467;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam21(V self, V *args) {
  V v_x_2477 = args[0];
  V v_bp_244 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_2466 = heff_env(self)[2];
  V v_next_247 = heff_env(self)[3];
  V v_k_2467 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2477);
  V v_t_2478 = heff_tag_n(TAG_Complete, 2, (V[]){v_bp_244, NTAG(TAG_MkUnit)});
  V v_t_2479 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2478}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2479, heff_dup(v_hd_2466), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam22, 1, 3, (V[]){v_next_247, v_hd_2466, v_k_2467})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam20(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_x_245 = heff_env(self)[0];
  V v_bp_244 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_next_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2468 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str7), heff_strAppend(v_x_245, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str8)));
  V v_t_2469 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2468, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_str9)), NTAG(TAG_MkUnit)});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2466, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})}));
  V f_ = heff_dup(heff_rfield(v_hd_2466, 1));
  args[0] = v_t_2476;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_lam21, 1, 5, (V[]){v_bp_244, v_prog_241, v_hd_2466, v_next_247, v_k_2467});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408(V v_prog_240, V v_st_241, V v_t_242, V v_progs_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_prog_240);
    heff_drop(v_t_242);
    heff_drop(v_progs_243);
    return ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam0_clo);
  }
  case TAG_Just: {
    V v_home_247 = heff_field(v_x5_244, 0);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_243)));
    V v_xs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_total_2410 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_249));
    V v_t_2412 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_str0), heff_dup(v_home_247)), v_total_2410, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam1_clo)});
    V v_t_2413 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2412}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam2, 2, 6, (V[]){v_t_2413, v_prog_240, v_progs_243, heff_dup(v_st_241), v_t_242, heff_dup(v_home_247)});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408(a[0], a1, a[2], a[3], a4); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_a_246 = args[1];
  heff_drop(v_a_245);
  V f_ = v_a_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam1(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2424);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam4(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_t_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_co_2eop_24s615738393x1686646143(v_t_2418, v_hd_2422, heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam5, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_progs_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_home_247 = heff_env(self)[4];
  V v_hd_2414 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2417 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2416), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2417}));
  V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_243));
  V v_xs_2420 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_t_2421 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2420));
  V v_t_2425 = ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_home_247; V a_4 = v_x_2416; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam4, 2, 1, (V[]){v_t_2418}); V a_6 = v_t_2421; V r_ = (g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_241); heff_drop(v_t_2421); r_; });
  V f_ = v_t_2425;
  heff_room[0] = v_hd_2414;
  heff_room[1] = v_k_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_t_2413 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_progs_243 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_home_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_co_2eop_24s615738393x1686646143(v_t_2413, heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_lam3, 1, 7, (V[]){v_prog_240, v_progs_243, v_st_241, v_t_242, v_home_247, v_hd_2414, v_k_2415})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str6, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str7, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str9, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str10, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str12, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str13, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str20, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str21, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str22, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678(V v_rep_240, V v_prog_241, V v_st_242, V v_cmd_243, V v_t_244, V v_none_245, V v_done_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_249 = (g_std_2epath_2eparse(v_st_242, heff_dup(heff_rfield(v_t_244, 0))));
  V v_t_2410 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str0)));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
  V v_t_2412 = ({ V a_0 = v_st_242; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  V v_c_2414 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(v_t_2413, NTAG(TAG_Nil)));
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam0, 1, 9, (V[]){v_prog_241, v_z_247, v_rep_240, v_cmd_243, v_z_248, heff_dup(v_st_242), v_t_244, v_none_245, v_done_246})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam1(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam5(V self, V *args) {
  V v_x_2441 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam8(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  V v_x_2469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2470);
  V f_ = v_k_2471;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2469});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam7(V self, V *args) {
  V v_x_2468 = args[0];
  V v_x_2469 = (g_list_2emap_24s219049803x1458391381(v_x_2468));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam8, 2, 1, (V[]){v_x_2469});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam10(V self, V *args) {
  V v_t_2480 = args[0];
  return v_t_2480;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam14(V self, V *args) {
  V v_x_24106 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24106);
  V v_t_24107 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
  V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_24113}), v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam13(V self, V *args) {
  V v_x_2492 = args[0];
  V v_bad_2488 = heff_env(self)[0];
  V v_cmd_243 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_apps_2489 = heff_env(self)[4];
  V v_none_245 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_prog_241 = heff_env(self)[7];
  V v_st_242 = heff_env(self)[8];
  V v_t_244 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2492);
  if (heff_intLt_c_lent(MK_INT(0LL), v_bad_2488, 1)) {
    heff_drop(v_apps_2489);
    heff_drop(v_none_245);
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_st_242);
    heff_drop_rec(v_t_244, 6);
    heff_drop(v_done_246);
    V v_n_2493 = v_bad_2488;
    V v_t_2494;
    if (heff_intEq_c_lent(v_n_2493, MK_INT(1LL), 2)) {
      heff_drop(v_n_2493);
      v_t_2494 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str17);
    } else {
      v_t_2494 = heff_strAppend(heff_intShow(v_n_2493), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str18));
    }
    V v_what_2495 = heff_strAppend(v_t_2494, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str19));
    V v_t_2496 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str20), heff_strAppend(v_what_2495, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str21)));
    V v_t_2497 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str22), heff_strAppend(v_cmd_243, v_t_2496));
    V v_t_2498 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2497, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str23)), NTAG(TAG_MkUnit)});
    V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
    V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
    V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
    V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
    V v_t_24104 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24103})});
    V v_t_24105 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_247, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24104})}));
    V f_ = heff_dup(heff_rfield(v_z_247, 1));
    heff_room[0] = v_t_24105;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam14, 1, 2, (V[]){v_z_247, v_z_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_bad_2488);
    heff_drop(v_cmd_243);
    switch (heff_tag_of(v_apps_2489)) {
    case TAG_Nil: {
      heff_drop(v_rep_240);
      heff_drop(v_prog_241);
      heff_drop(v_st_242);
      heff_drop_rec(v_t_244, 6);
      heff_drop(v_done_246);
      V f_ = v_none_245;
      heff_room[0] = v_z_247;
      heff_room[1] = v_z_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_drop(v_none_245);
      return ({ V a_0 = v_rep_240; V a_1 = v_prog_241; V a_2 = v_st_242; V a_3 = v_t_244; V a_4 = v_done_246; V a_5 = v_apps_2489; V a_6 = v_z_247; V a_7 = v_z_248; V r_ = (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1236039542x2018009876(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_242); r_; });
    }
    default: return heff_nomatch(v_apps_2489);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam12(V self, V *args) {
  V v_x_2487 = args[0];
  V v_x_2482 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_none_245 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_st_242 = heff_env(self)[7];
  V v_t_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_bad_2488 = heff_take_field(v_x_2487, 1);
  V v_apps_2489 = heff_get_n(v_x_2487, 0, 2);
  V v_t_2490 = heff_tag_n(TAG_End, 2, (V[]){v_x_2482, NTAG(TAG_MkUnit)});
  V v_t_2491 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2490}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2491, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam13, 1, 11, (V[]){v_bad_2488, v_cmd_243, v_z_247, v_z_248, v_apps_2489, v_none_245, v_rep_240, v_prog_241, v_st_242, v_t_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam11(V self, V *args) {
  V v_x_2482 = args[0];
  V v_x_2476 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_244 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_cmd_243 = heff_env(self)[5];
  V v_z_248 = heff_env(self)[6];
  V v_none_245 = heff_env(self)[7];
  V v_rep_240 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2483 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2485;
  switch (heff_tag_of(v_x_2476)) {
  case TAG_Nothing: {
    v_t_2485 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2484 = heff_field(v_x_2476, 0);
    heff_take_n(v_x_2476, 1ULL, 1);
    v_t_2485 = v_x_2484;
    break;
  }
  default: heff_nomatch(v_x_2476);
  }
  V v_c_2486 = (g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(heff_dup(v_prog_241), v_st_242, heff_dup(v_t_244), heff_dup(v_x_2482), v_t_2483, v_t_2485));
  V f_ = v_c_2486;
  heff_room[0] = heff_dup(v_z_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam12, 1, 10, (V[]){v_x_2482, v_prog_241, v_z_247, v_cmd_243, v_z_248, v_none_245, v_rep_240, v_st_242, v_t_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam9(V self, V *args) {
  V v_x_2473 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_244 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_248 = heff_env(self)[5];
  V v_none_245 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x_2476;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_Left: {
    heff_take_n(v_x_2473, 0ULL, 1);
    v_x_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2475 = heff_field(v_x_2473, 0);
    V v_ru_24x_2473_24Right = heff_take_reuse_n(v_x_2473, 1ULL, 1);
    v_x_2476 = heff_tag_at_n(v_ru_24x_2473_24Right, TAG_Just, 1, (V[]){v_y_2475});
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  V v_t_2478;
  switch (heff_tag_of(v_x_2476)) {
  case TAG_Nothing: {
    v_t_2478 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2477 = heff_dup(heff_field(v_x_2476, 0));
    v_t_2478 = v_x_2477;
    break;
  }
  default: heff_nomatch(v_x_2476);
  }
  V v_total_2479 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2478; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2478); r_; });
  V v_t_2481 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str16), v_total_2479, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam10_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2481, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam11, 1, 10, (V[]){v_x_2476, v_prog_241, v_st_242, v_t_244, v_z_247, v_cmd_243, v_z_248, v_none_245, v_rep_240, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam6(V self, V *args) {
  V v_x_2461 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_t_244 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_248 = heff_env(self)[5];
  V v_none_245 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2461);
  V v_t_2462 = (g_std_2epath_2eparse(v_st_242, heff_dup(heff_rfield(v_t_244, 0))));
  V v_t_2463 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str15)));
  V v_t_2464 = (g_std_2epath_2ejoin(v_t_2462, v_t_2463));
  V v_s_2465 = ({ V a_0 = v_st_242; V a_1 = v_t_2464; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2464); r_; });
  V v_path_2466 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2465; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2467 = (g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(v_path_2466));
  V v_c_2472 = heff_tr(heff_call(v_c_2467, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam7_clo)}));
  V f_ = v_c_2472;
  heff_room[0] = heff_dup(v_z_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam9, 1, 9, (V[]){v_prog_241, v_z_247, v_st_242, v_t_244, v_cmd_243, v_z_248, v_none_245, v_rep_240, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_errors_2423 = heff_env(self)[0];
  V v_cmd_243 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_seen_2424 = heff_env(self)[4];
  V v_st_242 = heff_env(self)[5];
  V v_t_244 = heff_env(self)[6];
  V v_prog_241 = heff_env(self)[7];
  V v_none_245 = heff_env(self)[8];
  V v_rep_240 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2427);
  if (heff_intLt_c_lent(MK_INT(0LL), v_errors_2423, 1)) {
    heff_drop(v_seen_2424);
    heff_drop(v_st_242);
    heff_drop_rec(v_t_244, 6);
    heff_drop(v_prog_241);
    heff_drop(v_none_245);
    heff_drop(v_rep_240);
    heff_drop(v_done_246);
    V v_n_2428 = v_errors_2423;
    V v_t_2429;
    if (heff_intEq_c_lent(v_n_2428, MK_INT(1LL), 2)) {
      heff_drop(v_n_2428);
      v_t_2429 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str2);
    } else {
      v_t_2429 = heff_strAppend(heff_intShow(v_n_2428), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str3));
    }
    V v_what_2430 = heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str4));
    V v_t_2431 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str5), heff_strAppend(v_what_2430, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str6)));
    V v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str7), heff_strAppend(v_cmd_243, v_t_2431));
    V v_t_2433 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2432, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str8)), NTAG(TAG_MkUnit)});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_247, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})}));
    V f_ = heff_dup(heff_rfield(v_z_247, 1));
    heff_room[0] = v_t_2440;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam5, 1, 2, (V[]){v_z_247, v_z_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_errors_2423);
    V v_n_2449 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_seen_2424; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_seen_2424); r_; });
    V v_t_2450;
    if (heff_intEq_c_lent(v_n_2449, MK_INT(1LL), 2)) {
      heff_drop(v_n_2449);
      v_t_2450 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str9);
    } else {
      v_t_2450 = heff_strAppend(heff_intShow(v_n_2449), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str10));
    }
    V v_t_2451 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str11), heff_strAppend(v_t_2450, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str12)));
    V v_str_2452 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str13), heff_strAppend(heff_dup(v_cmd_243), v_t_2451));
    V v_t_2453 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2452, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str14)), NTAG(TAG_MkUnit)});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_247, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})}));
    V f_ = heff_dup(heff_rfield(v_z_247, 1));
    heff_room[0] = v_t_2460;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam6, 1, 9, (V[]){v_st_242, v_t_244, v_z_247, v_prog_241, v_cmd_243, v_z_248, v_none_245, v_rep_240, v_done_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_st_242 = heff_env(self)[5];
  V v_t_244 = heff_env(self)[6];
  V v_none_245 = heff_env(self)[7];
  V v_rep_240 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_errors_2423 = heff_take_field(v_x_2422, 1);
  V v_seen_2424 = heff_get_n(v_x_2422, 0, 2);
  V v_t_2425 = heff_tag_n(TAG_End, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2425}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2426, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam4, 1, 11, (V[]){v_errors_2423, v_cmd_243, v_z_247, v_z_248, v_seen_2424, v_st_242, v_t_244, v_prog_241, v_none_245, v_rep_240, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_248 = heff_env(self)[5];
  V v_st_242 = heff_env(self)[6];
  V v_t_244 = heff_env(self)[7];
  V v_none_245 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2420 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2421 = ({ V a_0 = heff_dup(v_rep_240); V a_1 = heff_dup(v_prog_241); V a_2 = heff_dup(v_x_2419); V a_3 = v_t_2420; V a_4 = v_x_2415; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2415); r_; });
  V f_ = v_c_2421;
  heff_room[0] = heff_dup(v_z_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam3, 1, 10, (V[]){v_x_2419, v_prog_241, v_z_247, v_cmd_243, v_z_248, v_st_242, v_t_244, v_none_245, v_rep_240, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_st_242 = heff_env(self)[5];
  V v_t_244 = heff_env(self)[6];
  V v_none_245 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_total_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2415));
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_str1), v_total_2416, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam1_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2418, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_lam2, 1, 10, (V[]){v_rep_240, v_prog_241, v_x_2415, v_z_247, v_cmd_243, v_z_248, v_st_242, v_t_244, v_none_245, v_done_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str2, 2, "-m");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str3, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str4, 2, "-a");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str5, 10, "not tagged");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str7, 4, "push");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str8, 6, "origin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str9, 18, "tagged, not pushed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str10, 7, ", tag v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str11, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str12, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str14, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str16, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str17, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394(V v_v_240, V v_pk_241, V v_z_242, V v_z_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str0), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str1), heff_dup(v_v_240)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str2), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str4), v_t_245})});
  V v_c_247 = (g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str5), v_t_246));
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_lam0, 1, 4, (V[]){v_v_240, v_z_242, v_pk_241, v_z_243})});
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_lam2(V self, V *args) {
  V v_x_2434 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_z_242, v_z_243));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_pk_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    V v_t_2413 = heff_strAppend(heff_dup(v_v_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str10), v_v_240));
    V v_t_2414 = heff_strAppend(heff_get_n(v_pk_241, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str11), v_t_2413));
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str12), v_t_2414), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str13));
    V v_t_2416 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2415, NTAG(TAG_MkUnit)});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_call(heff_take_field(v_z_242, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})}));
    V f_ = heff_get_n(v_z_242, 1, 3);
    heff_room[0] = v_t_2423;
    heff_room[1] = v_z_243;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_why_2424 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Just = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_241, 4);
    V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str14), v_why_2424), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str15));
    V v_t_2426 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2425, NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_242, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
    V f_ = heff_dup(heff_rfield(v_z_242, 1));
    heff_room[0] = v_t_2433;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_lam2, 1, 2, (V[]){v_z_242, v_z_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_lam3(V self, V *args) {
  V v_x_2452 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2452);
  V v_t_2453 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2459}), v_z_242, v_z_243));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str6), heff_dup(v_v_240)), NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str8), v_t_249})});
    V v_c_2411 = (g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str9), v_t_2410));
    V f_ = v_c_2411;
    heff_room[0] = heff_dup(v_z_242);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_lam1, 1, 4, (V[]){v_v_240, v_pk_241, v_z_242, v_z_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_why_2442 = heff_field(v_x_248, 0);
    V v_ru_24x_248_24Just = heff_take_reuse_n(v_x_248, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_241, 4);
    V v_t_2443 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str16), v_why_2442), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_str17));
    V v_t_2444 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2443, NTAG(TAG_MkUnit)});
    V v_t_2445 = heff_tag_at_n(v_ru_24x_248_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_242, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})}));
    V f_ = heff_dup(heff_rfield(v_z_242, 1));
    heff_room[0] = v_t_2451;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_lam3, 1, 2, (V[]){v_z_242, v_z_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_248);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_str0, 2, "ok");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_str1, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_str2, 5, "notes");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_str3, 7, "failure");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_str4, 7, "goldens");
Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1(V v_tok_240, V v_name_241, V v_j_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_244 = (g_json_2eat_24cpr(v_t_243, heff_dup(v_j_242)));
  V v_t_2414;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_it1_247 = v_field_246;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_JNull: {
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JBool: {
        V v_b_248 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 1);
        v_t_2414 = v_b_248;
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_247);
      }
    } else {
      heff_drop(v_field_246);
      v_t_2414 = NTAG(TAG_False);
    }
  }
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_str1), NTAG(TAG_Nil)});
  HeffT2 v_t_2416 = (g_json_2eat_24cpr(v_t_2415, heff_dup(v_j_242)));
  V v_t_2426;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_it1_2419 = v_field_2418;
      switch (heff_tag_of(v_it1_2419)) {
      case TAG_JNull: {
        heff_drop_cell(v_tok_240, 1);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2419, 0ULL, 1);
        heff_drop_cell(v_tok_240, 1);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2419, 0ULL, 1);
        heff_drop_cell(v_tok_240, 1);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2419, 0ULL, 1);
        heff_drop_cell(v_tok_240, 1);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        V v_s_2423 = heff_field(v_it1_2419, 0);
        heff_take_n(v_it1_2419, 1ULL, 1);
        v_t_2426 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_s_2423});
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_2419, 0ULL, 1);
        heff_drop_cell(v_tok_240, 1);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2419, 0ULL, 1);
        heff_drop_cell(v_tok_240, 1);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2419);
      }
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_field_2418);
      v_t_2426 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_str2), NTAG(TAG_Nil)});
  HeffT2 v_t_2428 = (g_json_2eat_24cpr(v_t_2427, heff_dup(v_j_242)));
  V v_t_2438;
  {
    V v_field_2430 = v_t_2428.f[1];
    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
    if ((v_tag_2429 == ((int64_t)0ULL))) {
      V v_it1_2431 = v_field_2430;
      switch (heff_tag_of(v_it1_2431)) {
      case TAG_JNull: {
        v_t_2438 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2431, 0ULL, 1);
        v_t_2438 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2431, 0ULL, 1);
        v_t_2438 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2431, 0ULL, 1);
        v_t_2438 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2431, 0ULL, 1);
        v_t_2438 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2436 = heff_field(v_it1_2431, 0);
        heff_take_n(v_it1_2431, 1ULL, 1);
        v_t_2438 = v_xs_2436;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2431, 0ULL, 1);
        v_t_2438 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2431);
      }
    } else {
      heff_drop(v_field_2430);
      v_t_2438 = NTAG(TAG_Nil);
    }
  }
  V v_t_2439 = (g_list_2emap_24s1618539892x552009225(v_t_2438));
  V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_str3), NTAG(TAG_Nil)});
  HeffT2 v_t_2441 = (g_json_2eat_24cpr(v_t_2440, heff_dup(v_j_242)));
  V v_t_2445;
  {
    V v_field_2443 = v_t_2441.f[1];
    int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
    if ((v_tag_2442 == ((int64_t)0ULL))) {
      V v_f_2444 = v_field_2443;
      v_t_2445 = (g_heff_2ebuild_2ecommands_2ejsonFailure(v_f_2444));
    } else {
      heff_drop(v_field_2443);
      v_t_2445 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_str4), NTAG(TAG_Nil)});
  HeffT2 v_t_2447 = (g_json_2eat_24cpr(v_t_2446, v_j_242));
  V v_t_2457;
  {
    V v_field_2449 = v_t_2447.f[1];
    int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
    if ((v_tag_2448 == ((int64_t)0ULL))) {
      V v_it1_2450 = v_field_2449;
      switch (heff_tag_of(v_it1_2450)) {
      case TAG_JNull: {
        v_t_2457 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2450, 0ULL, 1);
        v_t_2457 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2450, 0ULL, 1);
        v_t_2457 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2450, 0ULL, 1);
        v_t_2457 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2450, 0ULL, 1);
        v_t_2457 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2455 = heff_field(v_it1_2450, 0);
        heff_take_n(v_it1_2450, 1ULL, 1);
        v_t_2457 = v_xs_2455;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2450, 0ULL, 1);
        v_t_2457 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2450);
      }
    } else {
      heff_drop(v_field_2449);
      v_t_2457 = NTAG(TAG_Nil);
    }
  }
  V v_t_2458 = (g_list_2emap_24s809490196x1189312632(v_t_2457));
  return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_241, v_t_2414, v_t_2426, NTAG(TAG_False), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2439, v_t_2445, MK_INT(0LL), v_t_2458});
}
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1(a[0], a[1], a[2]);
}