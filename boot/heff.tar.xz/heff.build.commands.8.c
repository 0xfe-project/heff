// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_NoInput 41055
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Release 43671
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Wait 10206
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_bad 306815
#define LBL_build 295453320
#define LBL_c 317
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_effect 641056956
#define LBL_end 310101
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_files 298792593
#define LBL_globals 352931696
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_key 315609
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_pattern 1588251091
#define LBL_prefix 967031229
#define LBL_program 2069953735
#define LBL_root 10001833
#define LBL_segments 1801007612
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_zig 330130
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_name__build[] = {LBL_name, LBL_build};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ecache_2ehashGo(V, V, V, V);
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ehashGo_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_clo;
V g_heff_2ebuild_2ecommands_2ebrokenJob(V, V);
V g_heff_2ebuild_2ecommands_2ebrokenJob_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebrokenJob_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_clo;
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void);
V g_heff_2ebuild_2ecommands_2efilesSaid(V);
V g_heff_2ebuild_2ecommands_2efilesSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efilesSaid_clo;
HeffT2 g_heff_2ebuild_2ecommands_2einitProblem_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096(V, V, V);
V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_clo;
V g_heff_2ebuild_2ecommands_2enameLike(V);
V g_heff_2ebuild_2ecommands_2enameLike_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enameLike_clo;
V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeVariable_get(void);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_clo;
V g_heff_2ebuild_2ecommands_2eprogramText(V);
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprogramText_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_clo;
V g_heff_2ebuild_2ecommands_2etestArgs(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestArgs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestArgs_clo;
V g_heff_2ebuild_2ecommands_2etestDir(V, V);
V g_heff_2ebuild_2ecommands_2etestDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestDir_clo;
V g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_clo;
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389(V);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_clo;
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075_clo;
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_clo;
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_clo;
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_clo;
V g_heff_2ebuild_2ecommands_2etestsHeld(V, V, V);
V g_heff_2ebuild_2ecommands_2etestsHeld_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsHeld_clo;
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_clo;
V g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320_clo;
V g_heff_2ecompile_2eemitc_2eoutputOf(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eoutputOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eoutputOf_clo;
V g_heff_2ecompile_2eemitc_2erunEnd(V, V);
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erunEnd_clo;
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void);
V g_heff_2ecompile_2elower_2elowerProgramC(V, V);
V g_heff_2ecompile_2elower_2elowerProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgramC_clo;
V g_list_2eany_24s762674996x1009180162(V);
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a);
extern Clo g_list_2eany_24s762674996x1009180162_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1725521117x1379101383(V, V, V, V, V, V, V);
V g_list_2efoldl_24s1725521117x1379101383_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1725521117x1379101383_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1146729723x1441207893(V, V, V);
V g_list_2emap_24s1146729723x1441207893_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_242, v_seen_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2ecommands_2enubStrGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_rest_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_str0, 22, "-- test: expect errors");

static V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eexpectErrorsLine_st;
static V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_init(void) {
  return ((V)&g_heff_2ebuild_2ecommands_2eexpectErrorsLine_str0);
}
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_st)) return g_heff_2ebuild_2ecommands_2eexpectErrorsLine_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eexpectErrorsLine_val, &g_heff_2ebuild_2ecommands_2eexpectErrorsLine_st, g_heff_2ebuild_2ecommands_2eexpectErrorsLine_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str0, 10, ".heff/test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str6, 1, "_");
Clo g_heff_2ebuild_2ecommands_2etestDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestDir_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etestDir(V v_paths_240, V v_file_241) {
top: ;
  V v_d_242 = (g_std_2epath_2ejoin(heff_rfield(v_paths_240, 5), heff_take_field(v_paths_240, 0), ((V)&g_heff_2ebuild_2ecommands_2etestDir_str0)));
  V v_p_243 = (g_std_2epath_2eparse(heff_rfield(v_paths_240, 5), v_file_241));
  V v_xs_244 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str1); V a_1 = heff_dup(v_p_243); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str2); V b_3 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str3); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = heff_get_n(v_p_243, 2, 3); V r_ = (g_list_2efoldl_24s1725521117x1379101383(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_3); r_; });
  V v_x2_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_244));
  V v_p_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_p_248 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_p_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str6); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return ({ V b_0 = heff_get_n(v_paths_240, 5, 6); V a_1 = v_d_242; V a_2 = v_p_248; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2ecommands_2etestDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str1, 20, "heff: the directory ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str2, 82, " has no name to name a package by: say the project's directory, as `heff init DIR`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str3, 36, "): name it otherwise, as `heff init ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str5, 25, "` cannot name a package (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str6, 21, "heff: the directory `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str7, 62, "heff: `heff` is heff's own package: name the project otherwise");

HeffT2 g_heff_2ebuild_2ecommands_2einitProblem_24cpr(V v_shown_240, V v_name_241) {
top: ;
  if (heff_strEq_c_lent(v_name_241, ((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str0), 2)) {
    heff_drop(v_name_241);
    V v_f_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str1), heff_strAppend(v_shown_240, ((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str2)));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
  } else {
    heff_drop(v_shown_240);
    HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_name_241));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_why_248 = v_field_246;
        V v_t_249 = (g_heff_2ebuild_2ecommands_2enameLike(v_name_241));
        V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str3), heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str4)));
        V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str5), heff_strAppend(v_why_248, v_t_2410));
        V v_f_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str6), heff_strAppend(v_name_241, v_t_2411));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
      } else {
        heff_drop(v_field_246);
        if (heff_strEq_c(v_name_241, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str7)}});
        } else {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str0, 15, "-- The program ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str1, 42, ": `heff build` builds it to .heff/bin/, as");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str2, 29, "-- a build, by `heff run app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str3, 10, "/main.hf`.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str4, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str5, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str7, 20, "main : Co stdio Unit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str8, 33, "main = program (io := here stdio)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str9, 34, "program = print (greeting \"world\")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str12, 50, "program : {{io : stdio <: stdio}} -> Co stdio Unit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str13, 13, "import std.io");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str15, 9, "import co");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str16, 68, "-- build.hf says, and `heff install` into ~/.heff/bin/; run, without");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str17, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprogramText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprogramText_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eprogramText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str1)));
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str2), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str3)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str4), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str5)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str6), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str8), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str10), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str12), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str13), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str14), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str15), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_249})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str17); V a_1 = v_t_241; V a_2 = v_t_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2410, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprogramText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781_str0, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781(V v_ps_240, V v_b_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    top_TAG_Nothing: ;
    V v_t_243 = (g_heff_2ebuild_2ecache_2ehashGo(v_b_241, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238(v_ps_240, v_b_241, v_t_243);
  }
  case TAG_Just: {
    V v_kept_244 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781_str0), v_kept_244, MK_INT(0LL), 5);
    if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
      heff_drop(v_kept_244);
      heff_drop(v_j_245);
      V t_0 = v_ps_240;
      V t_1 = v_b_241;
      V t_2 = NTAG(TAG_Nothing);
      v_ps_240 = t_0;
      v_b_241 = t_1;
      v_x3_242 = t_2;
      goto top_TAG_Nothing;
    } else {
      V v_t_247 = heff_intSub(heff_strLength_lent(v_kept_244, 0), heff_dup(v_j_245));
      if (heff_intEq_c(heff_intSub(v_t_247, MK_INT(1LL)), heff_strLength_lent(v_b_241, 0))) {
        V v_t_249 = heff_strSlice(heff_dup(v_kept_244), heff_intAdd(heff_dup(v_j_245), MK_INT(1LL)), heff_strLength_lent(v_kept_244, 0));
        if (heff_strEq_c_lent(v_t_249, v_b_241, 1)) {
          heff_drop(v_ps_240);
          heff_drop(v_b_241);
          return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781_lam0, 2, 2, (V[]){v_kept_244, v_j_245});
        } else {
          heff_drop(v_kept_244);
          heff_drop(v_j_245);
          V t_0 = v_ps_240;
          V t_1 = v_b_241;
          V t_2 = NTAG(TAG_Nothing);
          v_ps_240 = t_0;
          v_b_241 = t_1;
          v_x3_242 = t_2;
          goto top_TAG_Nothing;
        }
      } else {
        heff_drop(v_kept_244);
        heff_drop(v_j_245);
        V t_0 = v_ps_240;
        V t_1 = v_b_241;
        V t_2 = NTAG(TAG_Nothing);
        v_ps_240 = t_0;
        v_b_241 = t_1;
        v_x3_242 = t_2;
        goto top_TAG_Nothing;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfFrom_24s730834372x138821781_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_kept_244 = heff_env(self)[0];
  V v_j_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_strSlice(v_kept_244, MK_INT(0LL), v_j_245);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_str4, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_str5, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855(V v_bi_240, V v_file_241, V v_name_242, V v_outPath_243, V v_rt_244, V v_failed_245, V v_done_246, V v_c_247, V v_available_248, V v_z_249, V v_z_2410) {
top: ;
  V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_lam0, 1, 1, (V[]){heff_dup(v_c_247)}), heff_dup(heff_rfield(v_c_247, 7))));
  V v_t_2419 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2418));
  V v_t_2420 = ({ V a_0 = v_t_2419; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2419); r_; });
  V v_t_2421 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2420));
  V v_t_2423 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_lam1, 1, 1, (V[]){heff_dup(v_available_248)}), v_t_2421));
  HeffT2 v_t_2424 = ({ V a_0 = v_t_2423; V a_1 = heff_dup(v_c_247); V a_2 = v_name_242; HeffT2 r_ = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2423); r_; });
  {
    V v_field_2426 = v_t_2424.f[1];
    int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
    if ((v_tag_2425 == ((int64_t)0ULL))) {
      heff_drop(v_bi_240);
      heff_drop(v_outPath_243);
      heff_drop_rec(v_rt_244, 2);
      heff_drop(v_done_246);
      heff_drop_rec(v_c_247, 14);
      heff_drop(v_available_248);
      V v_why_2428 = v_field_2426;
      V v_t_2429 = heff_strAppend(heff_dup(v_file_241), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_str0), heff_dup(v_why_2428)));
      V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_str1), v_t_2429), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_str2));
      V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2430, NTAG(TAG_MkUnit)});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_lam2, 1, 5, (V[]){v_file_241, v_why_2428, v_failed_245, v_z_249, v_z_2410})));
    } else {
      heff_drop(v_file_241);
      heff_drop(v_failed_245);
      V v_r_2439 = v_field_2426;
      int64_t v_t_2440 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
      V v_t_2441 = heff_strSlice(heff_dup(v_outPath_243), heff_box_word(v_t_2440), heff_strLength_lent(v_outPath_243, 0));
      if (heff_strEq_c(v_t_2441, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_str5))) {
        int64_t v_t_2443 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
        return (g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750(v_bi_240, heff_strSlice(v_outPath_243, MK_INT(0LL), heff_box_word(v_t_2443)), v_rt_244, v_done_246, v_c_247, v_available_248, v_r_2439, v_z_249, v_z_2410));
      } else {
        heff_drop(v_bi_240);
        V v_t_2444 = (g_list_2eany_24s762674996x1009180162(v_available_248));
        V v_t_2445;
        if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
          heff_drop(v_t_2444);
          v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2ethreadsLine_get()), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_t_2444);
          v_t_2445 = NTAG(TAG_Nil);
        }
        V v_t_2446 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2erunEnd_clo), 1, (V[]){heff_take_field(v_r_2439, 1)}));
        V v_t_2447 = heff_get_n(heff_get_n(v_c_247, 5, 14), 0, 9);
        V v_t_2448 = (g_heff_2ecompile_2elower_2elowerProgramC(v_t_2447, heff_get_n(v_r_2439, 0, 2)));
        V v_t_2449 = (g_heff_2ecompile_2eemitc_2eoutputOf(heff_take_field(v_rt_244, 0), v_available_248, heff_rec_n(2, shape_prefix__end, (V[]){v_t_2445, v_t_2446}), v_t_2448));
        return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480(v_outPath_243, heff_get_n(v_rt_244, 1, 2), v_done_246, v_t_2449, v_z_249, v_z_2410));
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_lam0(V self, V *args) {
  V v_o_2411 = args[0];
  V v_c_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2412 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_247, heff_rfield(v_o_2411, 1)));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_eff_2416 = v_field_2414;
      V v_t_2417 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2411, 0), heff_get_n(v_o_2411, 1, 2), v_eff_2416});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2417});
    } else {
      heff_drop_rec(v_o_2411, 2);
      heff_drop(v_field_2414);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_lam1(V self, V *args) {
  V v_k_2422 = args[0];
  V v_available_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_248; V a_1 = v_k_2422; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_248); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_lam2(V self, V *args) {
  V v_x_2437 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_why_2428 = heff_env(self)[1];
  V v_failed_245 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_z_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_strAppend(v_file_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_str3), v_why_2428));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1447282046x1046400855_str4), v_t_2438);
  heff_room[1] = v_z_249;
  heff_room[2] = v_z_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str0, 46, "heff test: --watch is not given with --update\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str2, 4, "test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str3, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str4, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str7, 4, "test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str8, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str9, 3, "lib");
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713(V v_clock_240, V v_seed_241, V v_pattern_242, V v_jobs_243, V v_x4_244, V v_given_245) {
top: ;
  if ((heff_dup(v_x4_244) == NTAG(TAG_True))) {
    heff_drop(v_clock_240);
    heff_drop(v_given_245);
    return ((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam0_clo);
  } else {
    V v_c_2421 = (g_heff_2ebuild_2ecommands_2etestOptions_24s222332525x314105075(v_seed_241, v_pattern_242, v_jobs_243, NTAG(TAG_False)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam2, 2, 6, (V[]){v_c_2421, v_given_245, heff_dup(v_seed_241), heff_dup(v_pattern_242), heff_dup(v_jobs_243), v_clock_240});
  }
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713(a[0], a1, a2, a3, a4, a[5]); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str0), NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam1, 1, 2, (V[]){v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam5(V self, V *args) {
  V v_s_2427 = args[0];
  return v_s_2427;
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam8(V self, V *args) {
  V v_x_2445 = args[0];
  V v_given_245 = heff_env(self)[0];
  V v_seed_241 = heff_env(self)[1];
  V v_pattern_242 = heff_env(self)[2];
  V v_jobs_243 = heff_env(self)[3];
  V v_clock_240 = heff_env(self)[4];
  V v_st_2436 = heff_env(self)[5];
  V v_x_2443 = heff_env(self)[6];
  V v_hd_2422 = heff_env(self)[7];
  V v_k_2423 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2448;
  switch (heff_tag_of(v_given_245)) {
  case TAG_Nil: {
    v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str8), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())})});
    break;
  }
  case TAG_Cons: {
    v_t_2448 = (g_prelude_2e_2b_2b(heff_dup(v_given_245), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str9), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())})));
    break;
  }
  default: heff_nomatch(v_given_245);
  }
  V v_t_2449 = ({ V a_0 = v_seed_241; V a_1 = v_pattern_242; V a_2 = v_jobs_243; V a_3 = v_given_245; V r_ = (g_heff_2ebuild_2ecommands_2etestArgs(a_0, a_1, a_2, a_3)); heff_drop(v_seed_241); heff_drop(v_pattern_242); heff_drop(v_jobs_243); r_; });
  V v_t_2450 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1137634002x673507541_clo), 1, (V[]){v_t_2449}));
  return ({ V a_0 = v_clock_240; V a_1 = v_st_2436; V a_2 = v_t_2448; V a_3 = v_t_2450; V a_4 = v_x_2443; V a_5 = v_x_2445; V a_6 = v_hd_2422; V a_7 = v_k_2423; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s62506857x1141442320(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_2436); heff_drop(v_x_2443); heff_drop(v_k_2423); r_; });
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_seed_241 = heff_env(self)[0];
  V v_pattern_242 = heff_env(self)[1];
  V v_jobs_243 = heff_env(self)[2];
  V v_given_245 = heff_env(self)[3];
  V v_hd_2422 = heff_env(self)[4];
  V v_clock_240 = heff_env(self)[5];
  V v_st_2436 = heff_env(self)[6];
  V v_k_2423 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2443;
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Nil: {
    v_x_2443 = ((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2441 = heff_field(v_x_2440, 0);
    V v_xs_2442 = heff_field(v_x_2440, 1);
    heff_take_n(v_x_2440, 3ULL, 2);
    v_x_2443 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str6); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
    break;
  }
  default: heff_nomatch(v_x_2440);
  }
  V v_t_2444 = (g_heff_2ebuild_2ecommands_2etestArgs(v_seed_241, v_pattern_242, v_jobs_243, heff_dup(v_given_245)));
  return (g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804(v_t_2444, MK_INT(0LL), heff_dup(v_hd_2422), heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam8, 1, 9, (V[]){v_given_245, v_seed_241, v_pattern_242, v_jobs_243, v_clock_240, v_st_2436, v_x_2443, v_hd_2422, v_k_2423})));
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_given_245 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_seed_241 = heff_env(self)[2];
  V v_pattern_242 = heff_env(self)[3];
  V v_jobs_243 = heff_env(self)[4];
  V v_clock_240 = heff_env(self)[5];
  V v_k_2423 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2436;
  if (heff_strEq_c(v_x_2434, ((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str1))) {
    v_st_2436 = NTAG(TAG_Windows);
  } else {
    v_st_2436 = NTAG(TAG_Posix);
  }
  V v_paths_2439;
  switch (heff_tag_of(v_given_245)) {
  case TAG_Nil: {
    v_paths_2439 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str3), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())})});
    break;
  }
  case TAG_Cons: {
    v_paths_2439 = (g_prelude_2e_2b_2b(heff_dup(v_given_245), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_str4), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())})));
    break;
  }
  default: heff_nomatch(v_given_245);
  }
  return ({ V a_0 = v_st_2436; V a_1 = NTAG(TAG_Nil); V a_2 = v_paths_2439; V a_3 = heff_dup(v_hd_2422); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam7, 1, 8, (V[]){v_seed_241, v_pattern_242, v_jobs_243, v_given_245, v_hd_2422, v_clock_240, heff_dup(v_st_2436), v_k_2423}); V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_2436); r_; });
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2422 = heff_env(self)[0];
  V v_given_245 = heff_env(self)[1];
  V v_seed_241 = heff_env(self)[2];
  V v_pattern_242 = heff_env(self)[3];
  V v_jobs_243 = heff_env(self)[4];
  V v_clock_240 = heff_env(self)[5];
  V v_k_2423 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2426);
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam5_clo)})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s94900133x232571340(v_t_2433, heff_dup(v_hd_2422), heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam6, 1, 7, (V[]){v_given_245, v_hd_2422, v_seed_241, v_pattern_242, v_jobs_243, v_clock_240, v_k_2423})));
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_given_245 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_seed_241 = heff_env(self)[2];
  V v_pattern_242 = heff_env(self)[3];
  V v_jobs_243 = heff_env(self)[4];
  V v_clock_240 = heff_env(self)[5];
  V v_k_2423 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2424);
  V v_c_2425 = (g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389(heff_dup(v_given_245)));
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(v_hd_2422);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam4, 1, 7, (V[]){v_hd_2422, v_given_245, v_seed_241, v_pattern_242, v_jobs_243, v_clock_240, v_k_2423});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_given_245 = heff_env(self)[1];
  V v_seed_241 = heff_env(self)[2];
  V v_pattern_242 = heff_env(self)[3];
  V v_jobs_243 = heff_env(self)[4];
  V v_clock_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s1923603821x1751635713_lam3, 1, 7, (V[]){v_given_245, v_hd_2422, v_seed_241, v_pattern_242, v_jobs_243, v_clock_240, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_str0, 30, "its program could not be run: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_str1, 8, ".outcome");
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938(V v_sel_240, V v_j_241, V v_dir_242, V v_p_243, V v_p_244) {
top: ;
  V v_f_2419 = heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam0, 1, 3, (V[]){heff_dup(v_dir_242), heff_dup(v_j_241), v_sel_240});
  V v_t_2420 = heff_get_n(heff_dup(heff_rfield(v_j_241, 1)), 0, 2);
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_j_241, 3), heff_take_field(v_j_241, 4)});
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2eoutcomeVariable_get()), heff_strAppend(heff_dup(v_dir_242), ((V)&g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_str1))});
  V v_t_2423 = heff_get_n(heff_dup(heff_rfield(v_j_241, 1)), 1, 2);
  V v_t_2424 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_t_2420, v_t_2421, v_dir_242, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2423}), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), heff_get_n(v_j_241, 5, 6), MK_INT(0LL), NTAG(TAG_True)});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Start, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam4_clo)})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s94900133x232571340(v_t_2431, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam5, 1, 3, (V[]){v_f_2419, v_p_243, v_p_244})));
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam2(V self, V *args) {
  V v_ok_249 = args[0];
  return v_ok_249;
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_err_246 = heff_env(self)[0];
  V v_j_241 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_str0), heff_get_n(v_err_246, 2, 3));
  V v_x_2417 = (g_heff_2ebuild_2ecommands_2ebrokenJob(v_j_241, v_t_2416));
  V f_ = v_k_248;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_dir_242 = heff_env(self)[0];
  V v_err_246 = heff_env(self)[1];
  V v_j_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_dir_242, ((V)&g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam2_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam3, 1, 3, (V[]){v_err_246, v_j_241, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam0(V self, V *args) {
  V v_ran_245 = args[0];
  V v_dir_242 = heff_env(self)[0];
  V v_j_241 = heff_env(self)[1];
  V v_sel_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_ran_245)) {
  case TAG_Left: {
    V v_err_246 = heff_field(v_ran_245, 0);
    heff_take_n(v_ran_245, 1ULL, 1);
    heff_drop(v_sel_240);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam1, 2, 3, (V[]){v_dir_242, v_err_246, v_j_241});
  }
  case TAG_Right: {
    V v_r_2418 = heff_field(v_ran_245, 0);
    heff_take_n(v_ran_245, 1ULL, 1);
    V f_ = ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_clo);
    heff_room[0] = v_sel_240;
    heff_room[1] = v_j_241;
    heff_room[2] = v_dir_242;
    heff_room[3] = v_r_2418;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_ran_245);
  }
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam4(V self, V *args) {
  V v_s_2425 = args[0];
  return v_s_2425;
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam6(V self, V *args) {
  V v_r_2435 = args[0];
  return v_r_2435;
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam8(V self, V *args) {
  V v_r_2443 = args[0];
  return v_r_2443;
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam9(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_2442 = heff_env(self)[0];
  V v_f_2419 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2453;
  switch (heff_tag_of(v_x_2450)) {
  case TAG_Left: {
    V v_err_2451 = heff_field(v_x_2450, 0);
    V v_ru_24x_2450_24Left = heff_take_reuse_n(v_x_2450, 1ULL, 1);
    heff_drop(v_x_2442);
    v_t_2453 = heff_tag_at_n(v_ru_24x_2450_24Left, TAG_Left, 1, (V[]){v_err_2451});
    break;
  }
  case TAG_Right: {
    V v_ru_24x_2450_24Right = heff_take_reuse_n(v_x_2450, 0ULL, 1);
    v_t_2453 = heff_tag_at_n(v_ru_24x_2450_24Right, TAG_Right, 1, (V[]){v_x_2442});
    break;
  }
  default: heff_nomatch(v_x_2450);
  }
  V f_ = v_f_2419;
  heff_room[0] = v_t_2453;
  heff_room[1] = v_p_243;
  heff_room[2] = v_p_244;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam7(V self, V *args) {
  V v_x_2442 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_f_2419 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Release, 2, (V[]){v_x_2434, ((V)&g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam8_clo)})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  return (g_co_2eop_24s94900133x232571340(v_t_2449, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam9, 1, 4, (V[]){v_x_2442, v_f_2419, v_p_243, v_p_244})));
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_f_2419 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Left: {
    V v_err_2433 = heff_field(v_x_2432, 0);
    heff_take_n(v_x_2432, 1ULL, 1);
    V f_ = v_f_2419;
    heff_room[0] = heff_tag_n(TAG_Left, 1, (V[]){v_err_2433});
    heff_room[1] = v_p_243;
    heff_room[2] = v_p_244;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Right: {
    V v_x_2434 = heff_field(v_x_2432, 0);
    V v_ru_24x_2432_24Right = heff_take_reuse_n(v_x_2432, 1ULL, 1);
    V v_t_2436 = heff_tag_at_n(v_ru_24x_2432_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Wait, 2, (V[]){heff_dup(v_x_2434), ((V)&g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam6_clo)})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    return (g_co_2eop_24s94900133x232571340(v_t_2441, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2102741264x591116938_lam7, 1, 4, (V[]){v_x_2434, v_p_243, v_f_2419, v_p_244})));
  }
  default: return heff_nomatch(v_x_2432);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str0, 40, "files that do not check as they should:\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str1, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str3, 1, "'");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str4, 27, "heff test: no tests match '");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str6, 18, " expectations hold");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str7, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam4, 2, 0};
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160(V v_opts_240, V v_acc_241, V v_p_242, V v_p_243) {
top: ;
  V v_ws_244 = heff_dup(heff_rfield(v_acc_241, 4));
  V v_t_2419;
  switch (heff_tag_of(v_ws_244)) {
  case TAG_Nil: {
    v_t_2419 = ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam0_clo);
    break;
  }
  case TAG_Cons: {
    v_t_2419 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam1, 2, 1, (V[]){v_ws_244});
    break;
  }
  default: heff_nomatch(v_ws_244);
  }
  return heff_tail(v_t_2419, 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam3, 1, 4, (V[]){v_opts_240, v_acc_241, v_p_242, v_p_243})});
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ws_244 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2417);
  V v_t_2418 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str1), v_ws_244));
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624(v_t_2418, v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_ws_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tag_n(TAG_Write, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str0), NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam2, 1, 3, (V[]){v_ws_244, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam4(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_2425 = heff_env(self)[0];
  V v_k_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_2425, v_k_2426));
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam5(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_opts_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_strAppend(heff_get_n(v_opts_240, 1, 4), ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str3));
  V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str4), v_t_2427), ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str5));
  V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_hd_2425), heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam6, 1, 2, (V[]){v_hd_2425, v_k_2426})));
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam7(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  heff_drop(v_hd_2442);
  V f_ = v_k_2443;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam9(V self, V *args) {
  V v_x_2459 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2459);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_241, 3)))) {
    heff_drop_rec(v_acc_241, 8);
    V v_t_2461 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2466}), v_p_242, v_p_243));
  } else {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_241, 6)))) {
      heff_drop_rec(v_acc_241, 8);
      V v_t_2468 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
      V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
      V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
      V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
      V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2473}), v_p_242, v_p_243));
    } else {
      V v_t_2474 = heff_get_n(v_acc_241, 4, 8);
      switch (heff_tag_of(v_t_2474)) {
      case TAG_Nil: {
        heff_drop(v_p_242);
        V f_ = v_p_243;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24t_2474_24Cons = heff_take_reuse_n(v_t_2474, 0ULL, 2);
        V v_t_2477 = heff_tag_at_n(v_ru_24t_2474_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
        V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
        V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
        V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
        V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
        return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), v_p_242, v_p_243));
      }
      default: return heff_nomatch(v_t_2474);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam8(V self, V *args) {
  V v_x_2445 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_intSub(heff_dup(heff_rfield(v_acc_241, 2)), heff_dup(heff_rfield(v_acc_241, 3)));
  V v_t_2447 = heff_intShow(heff_dup(heff_rfield(v_acc_241, 2)));
  V v_t_2448 = (g_heff_2ebuild_2ecommands_2etestsHeld(heff_dup(heff_rfield(v_acc_241, 5)), heff_dup(heff_rfield(v_acc_241, 6)), heff_dup(heff_rfield(v_acc_241, 7))));
  V v_t_2449 = (g_heff_2ebuild_2ecommands_2efilesSaid(heff_dup(v_acc_241)));
  V v_t_2450 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str6), heff_strAppend(v_t_2448, v_t_2449));
  V v_t_2451 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str7), heff_strAppend(v_t_2447, v_t_2450));
  V v_str_2452 = heff_strAppend(heff_intShow(v_t_2446), v_t_2451);
  V v_t_2453 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2452, ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str8)), NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam9, 1, 3, (V[]){v_acc_241, v_p_242, v_p_243})));
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2420);
  V v_t_2444;
  if (heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 1)), ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_str2))) {
    heff_drop_rec(v_opts_240, 4);
    v_t_2444 = ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam4_clo);
  } else {
    if (heff_intEq_c(heff_dup(heff_rfield(v_acc_241, 5)), MK_INT(0LL))) {
      v_t_2444 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam5, 2, 1, (V[]){v_opts_240});
    } else {
      heff_drop_rec(v_opts_240, 4);
      v_t_2444 = ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam7_clo);
    }
  }
  V f_ = v_t_2444;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s1266610285x1309203160_lam8, 1, 3, (V[]){v_acc_241, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str0, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str1, 21, "  errors, as expected");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str4, 28, "  checks, but expects errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str6, 43, ": checks, but its first line expects errors");
V g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119(V v_f_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  if ((heff_dup(v_x2_241) == NTAG(TAG_True))) {
    V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str0), heff_strAppend(v_f_240, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str1)));
    V v_t_245 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str2)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_lam0, 1, 1, (V[]){v_p_243})));
  } else {
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str3), heff_strAppend(heff_dup(v_f_240), ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str4)));
    V v_t_2413 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str5)), NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_lam1, 1, 2, (V[]){v_f_240, v_p_243})));
  }
}
V g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2411);
  V f_ = v_p_243;
  args[0] = heff_dup(g_heff_2ebuild_2ecommands_2eexpectedRes_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2419);
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_f_240, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_str6)), NTAG(TAG_Nil)});
  V f_ = v_p_243;
  args[0] = heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), v_t_2420, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487(V v_st_240, V v_t_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_t_241, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam0_clo);
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 0)), heff_dup(v_n_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam1, 2, 5, (V[]){v_t_247, heff_dup(v_st_240), v_t_241, v_rest_246, v_n_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_n_245 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413;
  if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_2410);
    heff_drop(v_n_245);
    v_t_2413 = v_x_2412;
  } else {
    heff_drop(v_x_2410);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_245, v_x_2412});
  }
  V f_ = v_k_249;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam3, 1, 3, (V[]){v_x_2410, v_n_245, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_t_247 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096(v_t_247, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_lam2, 1, 6, (V[]){v_st_240, v_t_241, v_rest_246, v_hd_248, v_n_245, v_k_249})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str1, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str5, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str6, 11, ": it ships ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str7, 33, ", which the project does not have");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_a_244, V v_missing_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_missing_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_z_246);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__build, (V[]){v_x_243, v_a_244}), heff_take_field(v_acc_242, 0)});
    V v_t_249 = ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_acc_242, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tail(v_z_247, 1, (V[]){v_t_249});
  }
  case TAG_Cons: {
    heff_drop(v_a_244);
    V v_t_2412 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str0), v_x_243));
    V v_p_2413 = (g_std_2epath_2ejoin(v_st_240, v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str1)));
    V v_t_2414 = (g_std_2epath_2ejoin(v_st_240, heff_get_n(v_t_241, 0, 6), v_p_2413));
    V v_x2_2415 = (g_list_2emap_24s1146729723x1441207893(((V)&g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str2), ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str3), v_missing_245));
    V v_t_2418;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      v_t_2418 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      v_t_2418 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str5); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str6), heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str7)));
    V v_str_2420 = heff_strAppend(v_t_2414, v_t_2419);
    V v_t_2421 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2420, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_str8)), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_z_246, heff_clo_n(g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_lam0, 1, 2, (V[]){v_acc_242, v_z_247})));
  }
  default: return heff_nomatch(v_missing_245);
  }
}
V g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_lam0(V self, V *args) {
  V v_x_2427 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_intAdd(heff_take_field(v_acc_242, 1), MK_INT(1LL));
  V v_t_2429 = ({ V rv_1 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_acc_242, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_z_247;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}