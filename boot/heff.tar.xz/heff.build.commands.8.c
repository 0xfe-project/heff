// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Later 62002
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_Pend 2230
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Settled 45257
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_backend 2032133329
#define LBL_errors 652506774
#define LBL_file 9638467
#define LBL_integrations 139286697
#define LBL_module 878357911
#define LBL_outcomes 803130769
#define LBL_pages 307784670
#define LBL_reports 1326460931
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_run 322821
#define LBL_segments 1801007612
#define LBL_style 311138763
#define LBL_update 1108295668
#define LBL_wrong 314763719
V g_co_2eop_24s1825131239x2082086395(V, V, V, V, V);
V g_co_2eop_24s1825131239x2082086395_entry(V self, V *a);
extern Clo g_co_2eop_24s1825131239x2082086395_clo;
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_clo;
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_clo;
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_clo;
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269(V, V, V);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_clo;
HeffT2 g_heff_2ebuild_2ecommands_2einitProblem_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898(V, V, V);
V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_clo;
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo;
V g_heff_2ebuild_2ecommands_2enameLike(V);
V g_heff_2ebuild_2ecommands_2enameLike_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enameLike_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2epassedOver(V, V);
V g_heff_2ebuild_2ecommands_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epassedOver_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_clo;
V g_heff_2ebuild_2ecommands_2eprogramText(V);
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprogramText_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_clo;
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_clo;
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183(V, V, V);
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_clo;
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_clo;
V g_heff_2ebuild_2ecommands_2etestDir(V, V);
V g_heff_2ebuild_2ecommands_2etestDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestDir_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_clo;
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152_clo;
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_clo;
V g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s311057088x2004330267(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s311057088x2004330267_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s311057088x2004330267_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s441122589x590049990(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s441122589x590049990_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s441122589x590049990_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_list_2efoldl_24f556306710x2087456230(V, V, V, V);
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a);
extern Clo g_list_2efoldl_24f556306710x2087456230_clo;
V g_list_2efoldl_24s1002907040x997927369(V, V);
V g_list_2efoldl_24s1002907040x997927369_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1002907040x997927369_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1725521117x1379101383(V, V, V, V, V, V, V);
V g_list_2efoldl_24s1725521117x1379101383_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1725521117x1379101383_clo;
V g_list_2efoldl_24s489050722x1368997552(V, V);
V g_list_2efoldl_24s489050722x1368997552_entry(V self, V *a);
extern Clo g_list_2efoldl_24s489050722x1368997552_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s2029274225x672412636(V, V, V, V);
V g_list_2emap_24s2029274225x672412636_entry(V self, V *a);
extern Clo g_list_2emap_24s2029274225x672412636_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_list_2esortBy_24s492793466x2081132734(V);
V g_list_2esortBy_24s492793466x2081132734_entry(V self, V *a);
extern Clo g_list_2esortBy_24s492793466x2081132734_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_242, v_seen_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2ecommands_2enubStrGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_rest_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_str0, 22, "-- test: expect errors");

static V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eexpectErrorsLine_st;
static V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_init(void) {
  return ((V)&g_heff_2ebuild_2ecommands_2eexpectErrorsLine_str0);
}
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_st)) return g_heff_2ebuild_2ecommands_2eexpectErrorsLine_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eexpectErrorsLine_val, &g_heff_2ebuild_2ecommands_2eexpectErrorsLine_st, g_heff_2ebuild_2ecommands_2eexpectErrorsLine_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str0, 10, ".heff/test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestDir_str6, 1, "_");
Clo g_heff_2ebuild_2ecommands_2etestDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestDir_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etestDir(V v_paths_240, V v_file_241) {
top: ;
  V v_d_242 = (g_std_2epath_2ejoin(heff_rfield(v_paths_240, 5), heff_take_field(v_paths_240, 0), ((V)&g_heff_2ebuild_2ecommands_2etestDir_str0)));
  V v_p_243 = (g_std_2epath_2eparse(heff_rfield(v_paths_240, 5), v_file_241));
  V v_xs_244 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str1); V a_1 = heff_dup(v_p_243); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str2); V b_3 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str3); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = heff_get_n(v_p_243, 2, 3); V r_ = (g_list_2efoldl_24s1725521117x1379101383(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_3); r_; });
  V v_x2_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_244));
  V v_p_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_p_248 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_p_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2etestDir_str6); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return ({ V b_0 = heff_get_n(v_paths_240, 5, 6); V a_1 = v_d_242; V a_2 = v_p_248; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2ecommands_2etestDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str1, 20, "heff: the directory ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str2, 82, " has no name to name a package by: say the project's directory, as `heff init DIR`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str3, 36, "): name it otherwise, as `heff init ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str5, 25, "` cannot name a package (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str6, 21, "heff: the directory `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str7, 62, "heff: `heff` is heff's own package: name the project otherwise");

HeffT2 g_heff_2ebuild_2ecommands_2einitProblem_24cpr(V v_shown_240, V v_name_241) {
top: ;
  if (heff_strEq_c_lent(v_name_241, ((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str0), 2)) {
    heff_drop(v_name_241);
    V v_f_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str1), heff_strAppend(v_shown_240, ((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str2)));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
  } else {
    heff_drop(v_shown_240);
    HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_name_241));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_why_248 = v_field_246;
        V v_t_249 = (g_heff_2ebuild_2ecommands_2enameLike(v_name_241));
        V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str3), heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str4)));
        V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str5), heff_strAppend(v_why_248, v_t_2410));
        V v_f_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str6), heff_strAppend(v_name_241, v_t_2411));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
      } else {
        heff_drop(v_field_246);
        if (heff_strEq_c(v_name_241, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ecommands_2einitProblem_24cpr_str7)}});
        } else {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str0, 15, "-- The program ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str1, 42, ": `heff build` builds it to .heff/bin/, as");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str2, 29, "-- a build, by `heff run app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str3, 10, "/main.hf`.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str4, 11, "module app.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str5, 5, ".main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str6, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str7, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str9, 20, "main : Co stdio Unit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str10, 33, "main = program (io := here stdio)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str11, 34, "program = print (greeting \"world\")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str14, 50, "program : {{io : stdio <: stdio}} -> Co stdio Unit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str15, 13, "import std.io");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str17, 9, "import co");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str19, 68, "-- build.hf says, and `heff install` into ~/.heff/bin/; run, without");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str20, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprogramText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprogramText_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eprogramText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str1)));
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str2), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str3)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str4), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str5)));
  V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str6), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str7)));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str8), NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str10), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str12), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str14), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str15), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str16), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str17), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str18), heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str19), heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_2411})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str20); V a_1 = v_t_241; V a_2 = v_t_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2412, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprogramText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_str1, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_str2, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_str3, 22, "heff: no C runtime at ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_str5, 0, "");
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400(V v_name_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam0, 1, 3, (V[]){v_hd_241, v_name_240, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam1(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam3(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2443);
  V f_ = v_k_242;
  args[0] = ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_str5);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam6, 1, 1, (V[]){v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_st_2414 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    V v_t_2425 = (g_std_2epath_2ejoin(v_st_2414, v_x_243, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_str2)));
    V v_t_2426 = ({ V a_0 = v_st_2414; V a_1 = v_t_2425; V a_2 = v_name_240; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2414); r_; });
    V v_str_2427 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_str3), v_t_2426);
    V v_t_2428 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2427, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_str4)), NTAG(TAG_MkUnit)});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam5, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Just: {
    V v_t_2444 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    heff_drop(v_st_2414);
    heff_drop(v_x_243);
    heff_drop(v_name_240);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = v_t_2444;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2414;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_str0))) {
    v_st_2414 = NTAG(TAG_Windows);
  } else {
    v_st_2414 = NTAG(TAG_Posix);
  }
  V v_t_2415 = (g_std_2epath_2ejoin(v_st_2414, heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_str1)));
  V v_path_2416 = (g_std_2epath_2ejoin(v_st_2414, v_t_2415, heff_dup(v_name_240)));
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2416, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam3_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam4, 1, 5, (V[]){v_st_2414, v_x_243, v_name_240, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s495635622x733177935(v_t_2411, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_lam2, 1, 4, (V[]){v_x_243, v_name_240, v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_str0), v_e_243), ((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_str1));
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_WriteErr, 2, (V[]){v_t_245, NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s1825131239x2082086395(v_rest_244, heff_dup(v_p_241), v_p_242, heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_str1, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_str2, 8, "compiler");
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799(V v_ps_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  HEFF_LAST return g_co_2eop_24s495635622x733177935(v_t_2410, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_ps_240}));
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam2(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam4(V self, V *args) {
  V v_t_2424 = args[0];
  return v_t_2424;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_b_2420 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2432 = (g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665(v_ps_240, v_b_2420, v_x_2431));
  V f_ = v_t_2432;
  heff_room[0] = v_hd_241;
  heff_room[1] = v_k_242;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_str0);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_b_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Just = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    V v_d_2421 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_str1)));
    V v_d_2422 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2421, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
    V v_path_2423 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2422, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_str2)));
    V v_t_2425 = heff_tag_at_n(v_ru_24x_2419_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2423, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam4_clo)})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam5, 1, 4, (V[]){v_ps_240, v_b_2420, v_hd_241, v_k_242})));
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_lam3, 1, 3, (V[]){v_k_242, v_ps_240, v_hd_241})));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957(V v_rep_240, V v_prog_241, V v_rx_242, V v_ex_243, V v_tk_244, V v_opts_245, V v_x3_246, V v_acc_247, V v_ready_248, V v_z_249, V v_z_2410) {
top: ;
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nil: {
    V v_t_2411 = heff_tag_n(TAG_End, 2, (V[]){v_tk_244, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2411}));
    return (g_co_2eop_24s495635622x733177935(v_t_2412, heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam0, 1, 9, (V[]){v_rep_240, v_prog_241, v_rx_242, v_ex_243, v_opts_245, v_ready_248, v_acc_247, v_z_249, v_z_2410})));
  }
  case TAG_Cons: {
    V v_f_2416 = heff_field(v_x3_246, 0);
    V v_rest_2417 = heff_field(v_x3_246, 1);
    heff_take_n(v_x3_246, 3ULL, 2);
    V v_t_2419 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_tk_244), heff_dup(v_f_2416), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam2_clo)})}));
    return (g_co_2eop_24s495635622x733177935(v_t_2419, heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam3, 1, 12, (V[]){v_rep_240, v_opts_245, v_f_2416, v_z_249, v_ready_248, v_prog_241, v_acc_247, v_rx_242, v_ex_243, v_tk_244, v_rest_2417, v_z_2410})));
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_opts_245 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_z_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2etestSummary_24s1446826875x163970152(v_opts_245, v_x_2415, v_z_249, v_z_2410));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_rx_242 = heff_env(self)[2];
  V v_ex_243 = heff_env(self)[3];
  V v_opts_245 = heff_env(self)[4];
  V v_ready_248 = heff_env(self)[5];
  V v_acc_247 = heff_env(self)[6];
  V v_z_249 = heff_env(self)[7];
  V v_z_2410 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2413);
  V v_c_2414 = (g_heff_2ebuild_2ecommands_2erunReady_24s1558977448x1998620302(v_rep_240, v_prog_241, v_rx_242, v_ex_243, heff_dup(v_opts_245), v_ready_248, v_acc_247));
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_z_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam1, 1, 3, (V[]){v_opts_245, v_z_249, v_z_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam2(V self, V *args) {
  V v_t_2418 = args[0];
  return v_t_2418;
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam7(V self, V *args) {
  V v_x_2428 = args[0];
  V v_pr_2423 = heff_env(self)[0];
  V v_acc_247 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_rx_242 = heff_env(self)[4];
  V v_ex_243 = heff_env(self)[5];
  V v_tk_244 = heff_env(self)[6];
  V v_opts_245 = heff_env(self)[7];
  V v_rest_2417 = heff_env(self)[8];
  V v_ready_248 = heff_env(self)[9];
  V v_hd_2426 = heff_env(self)[10];
  V v_k_2427 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2428);
  switch (heff_tag_of(v_pr_2423)) {
  case TAG_Done: {
    V v_r_2429 = heff_field(v_pr_2423, 0);
    heff_take_n(v_pr_2423, 1ULL, 1);
    V v_t_2430 = (g_heff_2ebuild_2ecommands_2eaddRes(v_acc_247, v_r_2429));
    return (g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957(v_rep_240, v_prog_241, v_rx_242, v_ex_243, v_tk_244, v_opts_245, v_rest_2417, v_t_2430, v_ready_248, v_hd_2426, v_k_2427));
  }
  case TAG_Later: {
    V v_r_2431 = heff_field(v_pr_2423, 0);
    heff_take_n(v_pr_2423, 1ULL, 1);
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_2431, NTAG(TAG_Nil)});
    V v_t_2433 = (g_prelude_2e_2b_2b(v_ready_248, v_t_2432));
    return (g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957(v_rep_240, v_prog_241, v_rx_242, v_ex_243, v_tk_244, v_opts_245, v_rest_2417, v_acc_247, v_t_2433, v_hd_2426, v_k_2427));
  }
  default: return heff_nomatch(v_pr_2423);
  }
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_t_2425 = heff_env(self)[0];
  V v_pr_2423 = heff_env(self)[1];
  V v_acc_247 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_rx_242 = heff_env(self)[5];
  V v_ex_243 = heff_env(self)[6];
  V v_tk_244 = heff_env(self)[7];
  V v_opts_245 = heff_env(self)[8];
  V v_rest_2417 = heff_env(self)[9];
  V v_ready_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  return (g_co_2eop_24s495635622x733177935(v_t_2425, heff_dup(v_hd_2426), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam7, 1, 12, (V[]){v_pr_2423, v_acc_247, v_rep_240, v_prog_241, v_rx_242, v_ex_243, v_tk_244, v_opts_245, v_rest_2417, v_ready_248, v_hd_2426, v_k_2427})));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam5(V self, V *args) {
  V v_pr_2423 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_acc_247 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_rx_242 = heff_env(self)[4];
  V v_ex_243 = heff_env(self)[5];
  V v_tk_244 = heff_env(self)[6];
  V v_opts_245 = heff_env(self)[7];
  V v_rest_2417 = heff_env(self)[8];
  V v_ready_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2424 = heff_tag_n(TAG_End, 2, (V[]){v_x_2420, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2424}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam6, 2, 11, (V[]){v_t_2425, v_pr_2423, v_acc_247, v_rep_240, v_prog_241, v_rx_242, v_ex_243, v_tk_244, v_opts_245, v_rest_2417, v_ready_248});
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_k_2434 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_z_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2434;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2442});
  heff_room[1] = v_z_249;
  heff_room[2] = v_z_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_opts_245 = heff_env(self)[0];
  V v_k_2434 = heff_env(self)[1];
  V v_z_249 = heff_env(self)[2];
  V v_z_2410 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_2436 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2441 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_245, heff_dup(v_x_2440)));
  if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
    heff_drop(v_x_2440);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_2436, 7);
    heff_drop(v_t_2441);
    V f_ = v_k_2434;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_249;
    heff_room[2] = v_z_2410;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2441);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(v_rep_240, heff_dup(heff_rfield(v_p_2436, 0)), heff_dup(heff_rfield(v_p_2436, 1)), heff_get_n(v_p_2436, 2, 7), v_x_2440, heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam9, 1, 3, (V[]){v_k_2434, v_z_249, v_z_2410})));
  }
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_ready_248 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_acc_247 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_rx_242 = heff_env(self)[5];
  V v_ex_243 = heff_env(self)[6];
  V v_tk_244 = heff_env(self)[7];
  V v_opts_245 = heff_env(self)[8];
  V v_rest_2417 = heff_env(self)[9];
  V v_z_249 = heff_env(self)[10];
  V v_z_2410 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_at_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ready_248));
  V v_k_2434 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam5, 1, 10, (V[]){v_x_2420, heff_dup(v_prog_241), v_acc_247, heff_dup(v_rep_240), v_rx_242, v_ex_243, v_tk_244, heff_dup(v_opts_245), v_rest_2417, v_ready_248});
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Settled: {
    V v_r_2435 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    heff_drop(v_prog_241);
    heff_drop(v_rep_240);
    heff_drop_rec(v_opts_245, 4);
    heff_drop(v_at_2422);
    V f_ = v_k_2434;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_r_2435});
    heff_room[1] = v_z_249;
    heff_room[2] = v_z_2410;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Pend: {
    V v_p_2436 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    V v_t_2437 = heff_dup(heff_rfield(v_p_2436, 4));
    switch (heff_tag_of(v_t_2437)) {
    case TAG_Nil: {
      heff_drop(v_prog_241);
      heff_drop(v_at_2422);
      V v_t_2438 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_2436, 3)), NTAG(TAG_Nil)));
      V v_c_2439 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(heff_rfield(v_opts_245, 3), heff_dup(heff_rfield(v_p_2436, 0)), v_t_2438));
      V f_ = v_c_2439;
      heff_room[0] = heff_dup(v_z_249);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam8, 1, 6, (V[]){v_opts_245, v_k_2434, v_z_249, v_z_2410, v_rep_240, v_p_2436});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_take_n(v_t_2437, 0ULL, 2);
      return (g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1655874045x626928509(v_rep_240, v_prog_241, v_opts_245, v_at_2422, v_p_2436, v_k_2434, v_z_249, v_z_2410));
    }
    default: return heff_nomatch(v_t_2437);
    }
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_opts_245 = heff_env(self)[1];
  V v_f_2416 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_ready_248 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_acc_247 = heff_env(self)[6];
  V v_rx_242 = heff_env(self)[7];
  V v_ex_243 = heff_env(self)[8];
  V v_tk_244 = heff_env(self)[9];
  V v_rest_2417 = heff_env(self)[10];
  V v_z_2410 = heff_env(self)[11];
  heff_clo_take(self, 12);
  return ({ V a_0 = v_rep_240; V a_1 = heff_dup(v_opts_245); V a_2 = v_f_2416; V a_3 = heff_dup(v_z_249); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_lam4, 1, 12, (V[]){v_ready_248, v_x_2420, v_prog_241, v_acc_247, heff_dup(v_rep_240), v_rx_242, v_ex_243, v_tk_244, v_opts_245, v_rest_2417, v_z_249, v_z_2410}); V r_ = (g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rep_240); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str3, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str4, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str5, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str8, 11, "the project");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str9, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str10, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str15, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str16, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str17, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str20, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str21, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str22, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str23, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str24, 27, " packages, heff.sum written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str25, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str26, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str27, 32, "heff get: cannot write heff.sum\012");
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam11, 2, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269(V v_prog_240, V v_z_241, V v_z_242) {
top: ;
  V v_c_243 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_clo);
  return heff_tail(v_c_243, 2, (V[]){heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam0, 1, 3, (V[]){v_z_241, v_z_242, v_prog_240})});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam2(V self, V *args) {
  V v_t_247 = args[0];
  return v_t_247;
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V v_t_2430 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_z_241, v_z_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  V v_t_2451 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), v_z_241, v_z_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam7(V self, V *args) {
  V v_x_2470 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2470);
  V v_t_2471 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2477}), v_z_241, v_z_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam8(V self, V *args) {
  V v_by_2482 = args[0];
  V v_path_2483 = args[1];
  V v_v_2484 = args[2];
  V v_prog_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_root_2458 = heff_env(self)[2];
  V v_sums_2478 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902(v_prog_240, v_x_246, v_root_2458, v_sums_2478, v_by_2482, v_path_2483, v_v_2484));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam11(V self, V *args) {
  V v_hd_2498 = args[0];
  V v_k_2499 = args[1];
  heff_drop(v_hd_2498);
  V f_ = v_k_2499;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam12(V self, V *args) {
  V v_ok_24105 = args[0];
  return v_ok_24105;
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam17(V self, V *args) {
  V v_x_24141 = args[0];
  V v_seen_24139 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24141; V a_1 = v_seen_24139; V r_ = (g_list_2efoldl_24s1002907040x997927369(a_0, a_1)); heff_drop(v_seen_24139); r_; });
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam16(V self, V *args) {
  V v_x_24128 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_x_2486 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_intLt_c(MK_INT(0LL), v_x_24128)) {
    heff_drop(v_x_2486);
    V v_t_24130 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24130})});
    V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
    V v_t_24133 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
    V v_t_24134 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
    V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
    V v_t_24136 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24135})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24136}), v_z_241, v_z_242));
  } else {
    V v_seen_24139;
    switch (heff_tag_of(v_x_2486)) {
    case TAG_MkPair: {
      V v_x_24137 = heff_field(v_x_2486, 0);
      heff_take_n(v_x_2486, 1ULL, 2);
      v_seen_24139 = v_x_24137;
      break;
    }
    default: heff_nomatch(v_x_2486);
    }
    V v_t_24140 = (g_list_2efoldl_24s489050722x1368997552(NTAG(TAG_Nil), heff_dup(v_seen_24139)));
    V v_t_24142 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam17, 1, 1, (V[]){v_seen_24139}); V a_3 = v_t_24140; V r_ = (g_list_2efoldl_24f556306710x2087456230(a_0, a_1, a_2, a_3)); heff_drop(v_t_24140); r_; });
    V v_t_24143 = heff_strAppend(heff_intShow(v_t_24142), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str24));
    V v_str_24144 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str25), v_t_24143);
    V v_t_24145 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_24144, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str26)), NTAG(TAG_MkUnit)});
    V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
    V v_t_24147 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24146})});
    V v_t_24148 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24147})});
    V v_t_24149 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24148})});
    V v_t_24150 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24149})});
    V v_t_24151 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24150})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24151}), v_z_241, v_z_242));
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam15(V self, V *args) {
  V v_x_24127 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_x_2486 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str23), heff_get_n(v_x_24127, 1, 5), MK_INT(0LL), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam16, 1, 3, (V[]){v_z_241, v_z_242, v_x_2486})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam18(V self, V *args) {
  V v_x_24159 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24159);
  V v_t_24160 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24161 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24160})});
  V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
  V v_t_24163 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24162})});
  V v_t_24164 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24163})});
  V v_t_24165 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24164})});
  V v_t_24166 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24165})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24166}), v_z_241, v_z_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam14(V self, V *args) {
  V v_x_24117 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_x_24113 = heff_env(self)[2];
  V v_x_2486 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_intLt_c(MK_INT(0LL), v_x_24117)) {
    heff_drop(v_x_24113);
    heff_drop(v_x_2486);
    V v_t_24119 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24119})});
    V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
    V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
    V v_t_24125 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24124})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24125}), v_z_241, v_z_242));
  } else {
    if ((heff_dup(v_x_24113) == NTAG(TAG_True))) {
      heff_drop(v_x_24113);
      V v_c_24126 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str22)));
      V f_ = v_c_24126;
      heff_room[0] = heff_dup(v_z_241);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam15, 1, 3, (V[]){v_z_241, v_z_242, v_x_2486});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x_24113);
      heff_drop(v_x_2486);
      V v_t_24152 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str27), NTAG(TAG_MkUnit)});
      V v_t_24153 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24152})});
      V v_t_24154 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24153})});
      V v_t_24155 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24154})});
      V v_t_24156 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24155})});
      V v_t_24157 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24156})});
      V v_t_24158 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24157})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24158}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam18, 1, 2, (V[]){v_z_241, v_z_242})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam13(V self, V *args) {
  V v_x_24113 = args[0];
  V v_x_2486 = heff_env(self)[0];
  V v_z_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24116;
  switch (heff_tag_of(v_x_2486)) {
  case TAG_MkPair: {
    V v_y_24115 = heff_dup(heff_field(v_x_2486, 1));
    v_t_24116 = v_y_24115;
    break;
  }
  default: heff_nomatch(v_x_2486);
  }
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str21), v_t_24116, MK_INT(0LL), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam14, 1, 4, (V[]){v_z_241, v_z_242, v_x_24113, v_x_2486})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam10(V self, V *args) {
  V v_x_2491 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_x_2486 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2492 = (g_list_2esortBy_24s492793466x2081132734(heff_dup(v_x_2491)));
  V v_x2_2493 = (g_list_2emap_24s2029274225x672412636(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str9), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str10), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str11), v_t_2492));
  V v_t_2496;
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_Nil: {
    v_t_2496 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2494 = heff_field(v_x2_2493, 0);
    V v_xs_2495 = heff_field(v_x2_2493, 1);
    heff_take_n(v_x2_2493, 3ULL, 2);
    v_t_2496 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str13); V a_1 = v_x_2494; V a_2 = v_xs_2495; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2495); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2493);
  }
  V v_c_24112;
  if (heff_strEq_c(v_t_2496, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str14))) {
    heff_drop(v_x_2491);
    v_c_24112 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam11_clo);
  } else {
    V v_t_24100 = (g_list_2esortBy_24s492793466x2081132734(v_x_2491));
    V v_x2_24101 = (g_list_2emap_24s2029274225x672412636(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str15), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str16), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str17), v_t_24100));
    V v_str_24104;
    switch (heff_tag_of(v_x2_24101)) {
    case TAG_Nil: {
      v_str_24104 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_24102 = heff_field(v_x2_24101, 0);
      V v_xs_24103 = heff_field(v_x2_24101, 1);
      heff_take_n(v_x2_24101, 3ULL, 2);
      v_str_24104 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str19); V a_1 = v_x_24102; V a_2 = v_xs_24103; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24103); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24101);
    }
    V v_t_24106 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str20), v_str_24104, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam12_clo)})});
    V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
    V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
    V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
    V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24110})});
    v_c_24112 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24111})}));
  }
  V f_ = v_c_24112;
  heff_room[0] = heff_dup(v_z_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam13, 1, 3, (V[]){v_x_2486, v_z_241, v_z_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam9(V self, V *args) {
  V v_x_2486 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_root_2458 = heff_env(self)[1];
  V v_z_241 = heff_env(self)[2];
  V v_z_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2489;
  switch (heff_tag_of(v_x_2486)) {
  case TAG_MkPair: {
    V v_x_2487 = heff_dup(heff_field(v_x_2486, 0));
    v_t_2489 = v_x_2487;
    break;
  }
  default: heff_nomatch(v_x_2486);
  }
  V v_c_2490 = (g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183(v_x_246, v_root_2458, v_t_2489));
  V f_ = v_c_2490;
  heff_room[0] = heff_dup(v_z_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam10, 1, 3, (V[]){v_z_241, v_x_2486, v_z_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam6(V self, V *args) {
  V v_x_2460 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_root_2458 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2460)) {
  case TAG_Left: {
    V v_why_2461 = heff_field(v_x_2460, 0);
    V v_ru_24x_2460_24Left = heff_take_reuse_n(v_x_2460, 1ULL, 1);
    heff_drop_rec(v_root_2458, 4);
    heff_drop(v_prog_240);
    heff_drop(v_x_246);
    V v_t_2462 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str5), v_why_2461), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str6));
    V v_t_2463 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2462, NTAG(TAG_MkUnit)});
    V v_t_2464 = heff_tag_at_n(v_ru_24x_2460_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2469}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam7, 1, 2, (V[]){v_z_241, v_z_242})));
  }
  case TAG_Right: {
    V v_sums_2478 = heff_field(v_x_2460, 0);
    heff_take_n(v_x_2460, 1ULL, 1);
    V v_t_2480;
    if (heff_strEq_c(heff_dup(heff_rfield(v_root_2458, 0)), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str7))) {
      v_t_2480 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str8);
    } else {
      v_t_2480 = heff_dup(heff_rfield(v_root_2458, 0));
    }
    V v_t_2481 = (g_list_2emap_24s675147852x248982264(v_t_2480, heff_dup(heff_rfield(v_root_2458, 2))));
    V v_c_2485 = (g_heff_2ebuild_2eload_2eversionsGo_24s441122589x590049990(heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam8, 3, 4, (V[]){v_prog_240, heff_dup(v_x_246), heff_dup(v_root_2458), v_sums_2478}), heff_rfield(v_root_2458, 0), v_t_2481, NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V f_ = v_c_2485;
    heff_room[0] = heff_dup(v_z_241);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam9, 1, 4, (V[]){v_x_246, v_root_2458, v_z_241, v_z_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2460);
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  HeffT2 v_t_2417 = ({ V a_0 = v_t_2416; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_t_2416); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      heff_drop(v_x_246);
      heff_drop(v_prog_240);
      V v_p_2421 = v_field_2419;
      heff_drop(v_p_2421);
      V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str3), NTAG(TAG_MkUnit)});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam4, 1, 2, (V[]){v_z_241, v_z_242})));
    } else {
      V v_x_2437 = v_field_2419;
      HeffT2 v_t_2438 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2437));
      {
        V v_field_2440 = v_t_2438.f[1];
        int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
        if ((v_tag_2439 == ((int64_t)0ULL))) {
          heff_drop(v_x_246);
          heff_drop(v_prog_240);
          V v_x_2442 = v_field_2440;
          heff_drop(v_x_2442);
          V v_t_2443 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str4), NTAG(TAG_MkUnit)});
          V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
          V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
          V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
          V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
          V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
          V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
          return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam5, 1, 2, (V[]){v_z_241, v_z_242})));
        } else {
          V v_root_2458 = v_field_2440;
          V v_c_2459 = (g_heff_2ebuild_2eload_2ereadSumAt_24s311057088x2004330267(heff_dup(v_x_246)));
          V f_ = v_c_2459;
          heff_room[0] = heff_dup(v_z_241);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam6, 1, 5, (V[]){v_z_241, v_z_242, v_root_2458, v_prog_240, v_x_246});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str1), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam3, 1, 4, (V[]){v_z_241, v_z_242, v_x_246, v_prog_240})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(v_x_244, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_str0)));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_z_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_lam1, 1, 3, (V[]){v_z_241, v_z_242, v_prog_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495(V v_st_240, V v_t_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_t_241, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam0_clo);
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 0)), heff_dup(v_n_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam1, 2, 5, (V[]){v_t_247, heff_dup(v_st_240), v_t_241, v_rest_246, v_n_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_n_245 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413;
  if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_2410);
    heff_drop(v_n_245);
    v_t_2413 = v_x_2412;
  } else {
    heff_drop(v_x_2410);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_245, v_x_2412});
  }
  V f_ = v_k_249;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam3, 1, 3, (V[]){v_x_2410, v_n_245, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_t_247 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898(v_t_247, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_lam2, 1, 6, (V[]){v_st_240, v_t_241, v_rest_246, v_hd_248, v_n_245, v_k_249})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str1, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str3, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str5, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str6, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str7, 20, "compiling for a page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str8, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str9, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str10, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str11, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str12, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str13, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str14, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str15, 12, "passed over ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str16, 32, ": a page's script, not a program");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str17, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam15(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam15, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam22(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam20(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415(V v_rep_240, V v_prog_241, V v_st_242, V v_t_243, V v_bp_244, V v_x_245, V v_a_246, V v_next_247) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_a_246, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str0))) {
    V v_t_2410 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_244, heff_dup(v_x_245), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam0_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam1, 2, 8, (V[]){v_t_2410, v_prog_241, v_st_242, v_x_245, v_t_243, v_next_247, v_a_246, v_rep_240});
  } else {
    V v_t_2438 = heff_dup(heff_rfield(v_t_243, 3));
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop(v_t_2438);
      V v_t_2440 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_244, heff_dup(v_x_245), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam10_clo)})}));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam11, 2, 8, (V[]){v_t_2440, v_prog_241, v_st_242, v_x_245, v_t_243, v_a_246, v_rep_240, v_next_247});
    } else {
      heff_drop(v_rep_240);
      heff_drop(v_st_242);
      heff_drop_rec(v_t_243, 6);
      heff_drop_rec(v_a_246, 3);
      heff_drop(v_t_2438);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam20, 2, 4, (V[]){v_x_245, v_bp_244, v_prog_241, v_next_247});
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam0(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam3(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_next_247 = heff_env(self)[0];
  V v_hd_2426 = heff_env(self)[1];
  V v_k_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2428);
  V f_ = v_next_247;
  heff_room[0] = v_hd_2426;
  heff_room[1] = v_k_2427;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam5(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_t_2425 = heff_env(self)[0];
  V v_next_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s495635622x733177935(v_t_2425, heff_dup(v_hd_2426), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam6, 1, 3, (V[]){v_next_247, v_hd_2426, v_k_2427})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_next_2429 = heff_env(self)[0];
  V v_hd_2435 = heff_env(self)[1];
  V v_k_2436 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2437);
  V f_ = v_next_2429;
  heff_room[0] = v_hd_2435;
  heff_room[1] = v_k_2436;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_t_2431 = heff_env(self)[0];
  V v_next_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s495635622x733177935(v_t_2431, heff_dup(v_hd_2435), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam9, 1, 3, (V[]){v_next_2429, v_hd_2435, v_k_2436})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_outPath_2420 = heff_env(self)[2];
  V v_file_2423 = heff_env(self)[3];
  V v_t_2431 = heff_env(self)[4];
  V v_next_2429 = heff_env(self)[5];
  V v_hd_2411 = heff_env(self)[6];
  V v_k_2412 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_a_246, 1, 3)});
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240(MK_INT(1LL), v_rep_240, v_x_2433, v_t_2434, v_outPath_2420, v_file_2423, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam8, 2, 2, (V[]){v_t_2431, v_next_2429}), v_hd_2411, v_k_2412));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_t_243 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_next_247 = heff_env(self)[5];
  V v_hd_2411 = heff_env(self)[6];
  V v_a_246 = heff_env(self)[7];
  V v_rep_240 = heff_env(self)[8];
  V v_k_2412 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2417 = (g_std_2epath_2ejoin(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str2), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str3)));
  V v_p_2418 = (g_std_2epath_2ejoin(v_st_242, v_t_2417, heff_dup(v_x_245)));
  V v_t_2419 = (g_std_2epath_2ejoin(v_st_242, heff_dup(heff_rfield(v_t_243, 0)), v_p_2418));
  V v_outPath_2420 = heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str4));
  V v_t_2421 = (g_std_2epath_2ejoin(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str5), heff_dup(v_x_245)));
  V v_p_2422 = (g_std_2epath_2ejoin(v_st_242, v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str6)));
  V v_file_2423 = (g_std_2epath_2ejoin(v_st_242, heff_dup(heff_rfield(v_t_243, 0)), v_p_2422));
  V v_t_2424 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2413), NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2424}));
  V v_next_2429 = heff_tr(g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511(heff_dup(v_prog_241), v_st_242, v_t_243, v_x_2413, v_x_245, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam5, 2, 2, (V[]){v_t_2425, v_next_247})));
  V v_t_2430 = heff_tag_n(TAG_End, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2430}));
  V v_c_2432 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(heff_dup(v_file_2423)));
  V f_ = v_c_2432;
  heff_room[0] = heff_dup(v_hd_2411);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam7, 1, 8, (V[]){v_a_246, v_rep_240, v_outPath_2420, v_file_2423, v_t_2431, v_next_2429, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_next_247 = heff_env(self)[5];
  V v_a_246 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  V v_k_2412 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2415 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2413), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam3_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2415, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam4, 1, 10, (V[]){v_st_242, v_x_245, v_t_243, v_x_2413, v_prog_241, v_next_247, v_hd_2411, v_a_246, v_rep_240, v_k_2412})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_t_2410 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_next_247 = heff_env(self)[5];
  V v_a_246 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_co_2eop_24s495635622x733177935(v_t_2410, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam2, 1, 9, (V[]){v_prog_241, v_hd_2411, v_st_242, v_x_245, v_t_243, v_next_247, v_a_246, v_rep_240, v_k_2412})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam10(V self, V *args) {
  V v_t_2439 = args[0];
  return v_t_2439;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam13(V self, V *args) {
  V v_t_2444 = args[0];
  return v_t_2444;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam15(V self, V *args) {
  V v_ok_2450 = args[0];
  return v_ok_2450;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam19(V self, V *args) {
  V v_x_2473 = args[0];
  V v_next_247 = heff_env(self)[0];
  V v_hd_2470 = heff_env(self)[1];
  V v_k_2471 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2473);
  V f_ = v_next_247;
  heff_room[0] = v_hd_2470;
  heff_room[1] = v_k_2471;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam18(V self, V *args) {
  V v_x_2472 = args[0];
  V v_t_2467 = heff_env(self)[0];
  V v_hd_2470 = heff_env(self)[1];
  V v_next_247 = heff_env(self)[2];
  V v_k_2471 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2472);
  return (g_co_2eop_24s495635622x733177935(v_t_2467, heff_dup(v_hd_2470), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam19, 1, 3, (V[]){v_next_247, v_hd_2470, v_k_2471})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam17(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  V v_t_2469 = heff_env(self)[0];
  V v_t_2467 = heff_env(self)[1];
  V v_next_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s495635622x733177935(v_t_2469, heff_dup(v_hd_2470), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam18, 1, 4, (V[]){v_t_2467, v_hd_2470, v_next_247, v_k_2471})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam16(V self, V *args) {
  V v_x_2457 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_x_2443 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_x_2446 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  V v_next_247 = heff_env(self)[8];
  V v_hd_2441 = heff_env(self)[9];
  V v_k_2442 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2457);
  V v_t_2458 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_a_246, 1, 3)});
  V v_t_2459 = (g_std_2epath_2ejoin(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str10), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str11)));
  V v_p_2460 = (g_std_2epath_2ejoin(v_st_242, v_t_2459, heff_dup(v_x_245)));
  V v_t_2461 = (g_std_2epath_2ejoin(v_st_242, heff_dup(heff_rfield(v_t_243, 0)), v_p_2460));
  V v_t_2462 = (g_std_2epath_2ejoin(v_st_242, v_t_2461, heff_strAppend(heff_dup(v_x_245), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str12))));
  V v_t_2463 = (g_std_2epath_2ejoin(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str13), v_x_245));
  V v_p_2464 = (g_std_2epath_2ejoin(v_st_242, v_t_2463, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str14)));
  V v_t_2465 = ({ V a_0 = v_st_242; V a_1 = heff_get_n(v_t_243, 0, 6); V a_2 = v_p_2464; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_242); r_; });
  V v_t_2466 = heff_tag_n(TAG_End, 2, (V[]){v_x_2443, NTAG(TAG_MkUnit)});
  V v_t_2467 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2466}));
  V v_t_2468 = heff_tag_n(TAG_End, 2, (V[]){v_x_2446, NTAG(TAG_MkUnit)});
  V v_t_2469 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2468}));
  V v_t_2474 = ({ V a_0 = v_rep_240; V a_1 = v_t_2458; V a_2 = v_t_2462; V a_3 = v_t_2465; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam17, 2, 3, (V[]){v_t_2469, v_t_2467, v_next_247}); V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_t_2458, 1); r_; });
  V f_ = v_t_2474;
  heff_room[0] = v_hd_2441;
  heff_room[1] = v_k_2442;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam14(V self, V *args) {
  V v_x_2446 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_t_243 = heff_env(self)[2];
  V v_hd_2441 = heff_env(self)[3];
  V v_a_246 = heff_env(self)[4];
  V v_x_2443 = heff_env(self)[5];
  V v_prog_241 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  V v_next_247 = heff_env(self)[8];
  V v_k_2442 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2447 = (g_std_2epath_2ejoin(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str8), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str9)));
  V v_p_2448 = (g_std_2epath_2ejoin(v_st_242, v_t_2447, heff_dup(v_x_245)));
  V v_path_2449 = (g_std_2epath_2ejoin(v_st_242, heff_dup(heff_rfield(v_t_243, 0)), v_p_2448));
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_2449, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam15_clo)})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2456}), heff_dup(v_hd_2441), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam16, 1, 11, (V[]){v_a_246, v_st_242, v_x_245, v_t_243, v_x_2443, v_prog_241, v_x_2446, v_rep_240, v_next_247, v_hd_2441, v_k_2442})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam12(V self, V *args) {
  V v_x_2443 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_hd_2441 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_a_246 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_next_247 = heff_env(self)[7];
  V v_k_2442 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2445 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2443), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str7), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam13_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2445, heff_dup(v_hd_2441), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam14, 1, 10, (V[]){v_st_242, v_x_245, v_t_243, v_hd_2441, v_a_246, v_x_2443, v_prog_241, v_rep_240, v_next_247, v_k_2442})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam11(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_t_2440 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_a_246 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_next_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_co_2eop_24s495635622x733177935(v_t_2440, heff_dup(v_hd_2441), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam12, 1, 9, (V[]){v_prog_241, v_hd_2441, v_st_242, v_x_245, v_t_243, v_a_246, v_rep_240, v_next_247, v_k_2442})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam22(V self, V *args) {
  V v_x_2488 = args[0];
  V v_next_247 = heff_env(self)[0];
  V v_hd_2475 = heff_env(self)[1];
  V v_k_2476 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2488);
  V f_ = v_next_247;
  heff_room[0] = v_hd_2475;
  heff_room[1] = v_k_2476;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam21(V self, V *args) {
  V v_x_2485 = args[0];
  V v_bp_244 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_2475 = heff_env(self)[2];
  V v_next_247 = heff_env(self)[3];
  V v_k_2476 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2485);
  V v_t_2486 = heff_tag_n(TAG_Complete, 2, (V[]){v_bp_244, NTAG(TAG_MkUnit)});
  V v_t_2487 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2486}));
  return (g_co_2eop_24s495635622x733177935(v_t_2487, heff_dup(v_hd_2475), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam22, 1, 3, (V[]){v_next_247, v_hd_2475, v_k_2476})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam20(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k_2476 = args[1];
  V v_x_245 = heff_env(self)[0];
  V v_bp_244 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_next_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2477 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str15), heff_strAppend(v_x_245, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str16)));
  V v_t_2478 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2477, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_str17)), NTAG(TAG_MkUnit)});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2484}), heff_dup(v_hd_2475), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_lam21, 1, 5, (V[]){v_bp_244, v_prog_241, v_hd_2475, v_next_247, v_k_2476})));
}