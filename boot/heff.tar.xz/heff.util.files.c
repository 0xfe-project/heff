// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_ReadFile 6783
#define TAG_ReadOnly 17623
#define TAG_RealPath 18882
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_TemporaryDirectory 61563
#define TAG_Throw 56084
#define TAG_WriteFile 62589
#define LBL_ret 322331
V g_co_2e_3c_2b_3e_24s1585861108x1258949188(V);
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1585861108x1258949188_clo;
V g_co_2e_3c_2b_3e_24s33412700x2062750937_get(void);
V g_co_2eop_24s1203925392x1944187472(V, V);
V g_co_2eop_24s1203925392x1944187472_entry(V self, V *a);
extern Clo g_co_2eop_24s1203925392x1944187472_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_co_2eop_24s574817332x141721203(V);
V g_co_2eop_24s574817332x141721203_entry(V self, V *a);
extern Clo g_co_2eop_24s574817332x141721203_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(V);
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_clo;
V g_heff_2eutil_2efiles_2ereadDirectory(V, V, V);
V g_heff_2eutil_2efiles_2ereadDirectory_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_clo;
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(V);
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_clo;
V g_heff_2eutil_2efiles_2ereadFile(V, V, V);
V g_heff_2eutil_2efiles_2ereadFile_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_clo;
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(V);
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_clo;
V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160(V);
V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_clo;
V g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003(V);
V g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_clo;
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(V);
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_clo;
V g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696(V);
V g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_clo;
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(V, V);
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_std_2efilesystem_2ereadDirectory_24s374445114x460765065(V);
V g_std_2efilesystem_2ereadDirectory_24s374445114x460765065_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s374445114x460765065_clo;
V g_std_2efilesystem_2ereadDirectory_24s828287256x1704973048(V, V, V);
V g_std_2efilesystem_2ereadDirectory_24s828287256x1704973048_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s828287256x1704973048_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_heff_2eutil_2efiles_2ereadFile_lam0(V self, V *args); static Clo g_heff_2eutil_2efiles_2ereadFile_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadFile_lam0, 1, 0};
V g_heff_2eutil_2efiles_2ereadFile_lam1(V self, V *args);
V g_heff_2eutil_2efiles_2ereadFile_lam3(V self, V *args);
V g_heff_2eutil_2efiles_2ereadFile_lam2(V self, V *args);
Clo g_heff_2eutil_2efiles_2ereadFile_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadFile_entry, 3, 0};

V g_heff_2eutil_2efiles_2ereadFile(V v_e_240, V v_disk_241, V v_path_242) {
top: ;
  V v_e_243 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(heff_dup(v_e_240)));
  V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_242; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_p_231002_246 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_244, ((V)&g_heff_2eutil_2efiles_2ereadFile_lam0_clo)});
  V v_t_247 = heff_tr(heff_call(v_disk_241, 1, (V[]){v_p_231002_246}));
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){v_t_247});
  V v_h_249 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(heff_dup(v_e_240)));
  heff_drop(v_h_249);
  V v_hd_2410 = (g_exception_2eattempted(v_e_240));
  V v_k_2411 = heff_dup(heff_rfield(v_hd_2410, 0));
  V v_c_2416 = heff_tr(g_co_2eop_24s310169282x2049378029(heff_dup(v_e_243), v_t_248, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_lam1, 1, 3, (V[]){v_e_243, v_hd_2410, v_k_2411})));
  return heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_lam2, 2, 1, (V[]){v_c_2416});
}
V g_heff_2eutil_2efiles_2ereadFile_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eutil_2efiles_2ereadFile(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eutil_2efiles_2ereadFile_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2eutil_2efiles_2ereadFile_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2413})});
    return (g_co_2eop_24s310169282x2049378029(v_e_243, v_t_2414, v_hd_2410, v_k_2411));
  }
  case TAG_Right: {
    V v_x_2415 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    heff_drop(v_e_243);
    heff_drop_rec(v_hd_2410, 3);
    V f_ = v_k_2411;
    args[0] = v_x_2415;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2eutil_2efiles_2ereadFile_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    heff_take_n(v_x_2419, 0ULL, 1);
    v_t_2422 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    v_t_2422 = heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Just, 1, (V[]){v_y_2421});
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V f_ = v_k_2418;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ereadFile_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_lam3, 1, 1, (V[]){v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eutil_2efiles_2ereadDirectory_lam0(V self, V *args);
V g_heff_2eutil_2efiles_2ereadDirectory_lam1(V self, V *args);
V g_heff_2eutil_2efiles_2ereadDirectory_lam3(V self, V *args);
V g_heff_2eutil_2efiles_2ereadDirectory_lam2(V self, V *args);
Clo g_heff_2eutil_2efiles_2ereadDirectory_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadDirectory_entry, 3, 0};

V g_heff_2eutil_2efiles_2ereadDirectory(V v_e_240, V v_disk_241, V v_path_242) {
top: ;
  V v_h_243 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(heff_dup(v_e_240)));
  heff_drop(v_h_243);
  V v_t_244 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(heff_dup(v_e_240)));
  V v_c_247 = (g_std_2efilesystem_2ereadDirectory_24s828287256x1704973048(v_t_244, heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_lam0, 1, 1, (V[]){v_disk_241}), v_path_242));
  V v_h_248 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(heff_dup(v_e_240)));
  heff_drop(v_h_248);
  V v_hd_249 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2413 = heff_tr(heff_call(v_c_247, 2, (V[]){heff_dup(v_hd_249), heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_lam1, 1, 2, (V[]){v_e_240, v_hd_249})}));
  return heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_lam2, 2, 1, (V[]){v_c_2413});
}
V g_heff_2eutil_2efiles_2ereadDirectory_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2efiles_2ereadDirectory(a[0], a[1], a[2]);
}
V g_heff_2eutil_2efiles_2ereadDirectory_lam0(V self, V *args) {
  V v_p_231002_245 = args[0];
  V v_disk_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tr(heff_call(v_disk_241, 1, (V[]){v_p_231002_245}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_246});
}
V g_heff_2eutil_2efiles_2ereadDirectory_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_h_2411 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(v_e_240));
  heff_drop(v_h_2411);
  V v_x_2412 = (g_list_2emap_24s219049803x1458391381(v_x_2410));
  V f_ = heff_get_n(v_hd_249, 0, 3);
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ereadDirectory_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    heff_take_n(v_x_2416, 0ULL, 1);
    v_t_2419 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2418 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Right = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    v_t_2419 = heff_tag_at_n(v_ru_24x_2416_24Right, TAG_Just, 1, (V[]){v_y_2418});
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V f_ = v_k_2415;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ereadDirectory_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_lam3, 1, 1, (V[]){v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam0(V self, V *args); static Clo g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam0, 1, 0};
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam1(V self, V *args);
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam3(V self, V *args);
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam2(V self, V *args);
Clo g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_entry, 1, 0};

V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(V v_path_240) {
top: ;
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_p_231002_243 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_241, ((V)&g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam0_clo)});
  V v_k_244 = heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 0));
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_231002_243})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_c_2418 = (g_co_2eop_24s1203925392x1944187472(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam1, 3, 1, (V[]){v_k_244})));
  return heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam2, 2, 1, (V[]){v_c_2418});
}
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a0); heff_drop(a0); return r;
}
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_2412 = args[1];
  V v_z_2413 = args[2];
  V v_k_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Left = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2411_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2414})});
    V v_t_2416 = (g_co_2eop_24s1203925392x1944187472(v_t_2415, v_k_244));
    V f_ = v_t_2416;
    args[0] = v_z_2412;
    args[1] = v_z_2413;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    V f_ = v_k_244;
    args[0] = v_x_2417;
    args[1] = v_z_2412;
    args[2] = v_z_2413;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    heff_take_n(v_x_2421, 0ULL, 1);
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2423 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Right = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    v_t_2424 = heff_tag_at_n(v_ru_24x_2421_24Right, TAG_Just, 1, (V[]){v_y_2423});
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V f_ = v_k_2420;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_lam3, 1, 1, (V[]){v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam1(V self, V *args);
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam0(V self, V *args); static Clo g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam0, 1, 0};
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam3(V self, V *args);
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam2(V self, V *args);
Clo g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_entry, 1, 0};

V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(V v_path_240) {
top: ;
  V v_c_241 = (g_std_2efilesystem_2ereadDirectory_24s374445114x460765065(v_path_240));
  V v_c_246 = heff_tr(heff_call(v_c_241, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam0_clo)}));
  return heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam2, 2, 1, (V[]){v_c_246});
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(a[0]);
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_243});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_x_243 = (g_list_2emap_24s219049803x1458391381(v_x_242));
  return heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam1, 2, 1, (V[]){v_x_243});
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    heff_take_n(v_x_249, 0ULL, 1);
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2411 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Right = heff_take_reuse_n(v_x_249, 1ULL, 1);
    v_t_2412 = heff_tag_at_n(v_ru_24x_249_24Right, TAG_Just, 1, (V[]){v_y_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam2(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_lam3, 1, 1, (V[]){v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam0(V self, V *args); static Clo g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam0, 1, 0};
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam1(V self, V *args);
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam3(V self, V *args);
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam2(V self, V *args);
Clo g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_entry, 1, 0};

V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(V v_path_240) {
top: ;
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_p_231002_243 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_241, ((V)&g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam0_clo)});
  V v_k_244 = heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 0));
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_231002_243})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_c_2418 = (g_co_2eop_24s1203925392x1944187472(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_clo_n(g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam1, 3, 1, (V[]){v_k_244})));
  return heff_clo_n(g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam2, 2, 1, (V[]){v_c_2418});
}
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(a0); heff_drop(a0); return r;
}
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_2412 = args[1];
  V v_z_2413 = args[2];
  V v_k_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Left = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2411_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2414})});
    V v_t_2416 = (g_co_2eop_24s1203925392x1944187472(v_t_2415, v_k_244));
    V f_ = v_t_2416;
    args[0] = v_z_2412;
    args[1] = v_z_2413;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    V f_ = v_k_244;
    args[0] = v_x_2417;
    args[1] = v_z_2412;
    args[2] = v_z_2413;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    heff_take_n(v_x_2421, 0ULL, 1);
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2421, 0ULL, 1);
    v_t_2424 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V f_ = v_k_2420;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_lam3, 1, 1, (V[]){v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam0(V self, V *args); static Clo g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam0, 1, 0};
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam1(V self, V *args);
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam3(V self, V *args);
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam2(V self, V *args);
Clo g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_entry, 2, 0};

V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(V v_path_240, V v_text_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_p_231002_244 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_242, v_text_241, ((V)&g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam0_clo)});
  V v_k_245 = heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 0));
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_231002_244})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_c_2419 = (g_co_2eop_24s1203925392x1944187472(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_clo_n(g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam1, 3, 1, (V[]){v_k_245})));
  return heff_clo_n(g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam2, 2, 1, (V[]){v_c_2419});
}
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam0(V self, V *args) {
  V v_r_243 = args[0];
  return v_r_243;
}
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_z_2413 = args[1];
  V v_z_2414 = args[2];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2415 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2416 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2415})});
    V v_t_2417 = (g_co_2eop_24s1203925392x1944187472(v_t_2416, v_k_245));
    V f_ = v_t_2417;
    args[0] = v_z_2413;
    args[1] = v_z_2414;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Right: {
    V v_x_2418 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    V f_ = v_k_245;
    args[0] = v_x_2418;
    args[1] = v_z_2413;
    args[2] = v_z_2414;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    heff_take_n(v_x_2422, 0ULL, 1);
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2422, 0ULL, 1);
    v_t_2425 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V f_ = v_k_2421;
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo_n(g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_lam3, 1, 1, (V[]){v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam0(V self, V *args); static Clo g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam0, 1, 0};
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam1(V self, V *args);
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam3(V self, V *args);
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam2(V self, V *args);
Clo g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_entry, 1, 0};

V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(V v_path_240) {
top: ;
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_p_231002_243 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_241, ((V)&g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam0_clo)});
  V v_k_244 = heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 0));
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_231002_243})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_c_2418 = (g_co_2eop_24s1203925392x1944187472(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_clo_n(g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam1, 3, 1, (V[]){v_k_244})));
  return heff_clo_n(g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam2, 2, 1, (V[]){v_c_2418});
}
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(a0); heff_drop(a0); return r;
}
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_2412 = args[1];
  V v_z_2413 = args[2];
  V v_k_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Left = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2411_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2414})});
    V v_t_2416 = (g_co_2eop_24s1203925392x1944187472(v_t_2415, v_k_244));
    V f_ = v_t_2416;
    args[0] = v_z_2412;
    args[1] = v_z_2413;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    V f_ = v_k_244;
    args[0] = v_x_2417;
    args[1] = v_z_2412;
    args[2] = v_z_2413;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    heff_take_n(v_x_2421, 0ULL, 1);
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2421, 0ULL, 1);
    v_t_2424 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V f_ = v_k_2420;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_lam3, 1, 1, (V[]){v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_lam0(V self, V *args); static Clo g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_lam0, 1, 0};
V g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_lam2(V self, V *args);
V g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_lam1(V self, V *args); static Clo g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_lam1, 1, 0};
Clo g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_entry, 1, 0};

V g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696(V v_prefix_240) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_TemporaryDirectory, 2, (V[]){v_prefix_240, ((V)&g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_lam0_clo)})});
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_242})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(g_co_2e_3c_2b_3e_24s33412700x2062750937_get()), v_t_248, heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_lam1_clo)));
}
V g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696(a[0]);
}
V g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_lam0(V self, V *args) {
  V v_r_241 = args[0];
  return v_r_241;
}
V g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_lam1(V self, V *args) {
  V v_x_249 = args[0];
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    V v_err_2410 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Left = heff_take_reuse_n(v_x_249, 1ULL, 1);
    V v_t_2411 = heff_tag_at_n(v_ru_24x_249_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2410})});
    return (g_co_2eop_24s574817332x141721203(v_t_2411));
  }
  case TAG_Right: {
    V v_x_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_x_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_2412; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    return heff_clo_n(g_heff_2eutil_2efiles_2etemporaryDirectory_24s602598444x1257350696_lam2, 2, 1, (V[]){v_x_2413});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_lam0(V self, V *args); static Clo g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_lam0, 1, 0};
V g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_lam2(V self, V *args);
V g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_lam1(V self, V *args); static Clo g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_lam1, 1, 0};
Clo g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_entry, 1, 0};

V g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003(V v_path_240) {
top: ;
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_p_231002_243 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_241, ((V)&g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_lam0_clo)});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_231002_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(g_co_2e_3c_2b_3e_24s33412700x2062750937_get()), heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_lam1_clo)));
}
V g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003(a0); heff_drop(a0); return r;
}
V g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    V v_err_2411 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Left = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    V v_t_2412 = heff_tag_at_n(v_ru_24x_2410_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2411})});
    return (g_co_2eop_24s574817332x141721203(v_t_2412));
  }
  case TAG_Right: {
    V v_x_2413 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    V v_x_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_2413; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    return heff_clo_n(g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_lam2, 2, 1, (V[]){v_x_2414});
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam0(V self, V *args); static Clo g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam0, 1, 0};
V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam1(V self, V *args);
V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam3(V self, V *args);
V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam2(V self, V *args);
Clo g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_entry, 1, 0};

V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160(V v_path_240) {
top: ;
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_p_231002_243 = heff_tag_n(TAG_ReadOnly, 2, (V[]){v_t_241, ((V)&g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam0_clo)});
  V v_k_244 = heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 0));
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_231002_243})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_c_2418 = (g_co_2eop_24s1203925392x1944187472(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_clo_n(g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam1, 3, 1, (V[]){v_k_244})));
  return heff_clo_n(g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam2, 2, 1, (V[]){v_c_2418});
}
V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160(a0); heff_drop(a0); return r;
}
V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_2412 = args[1];
  V v_z_2413 = args[2];
  V v_k_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Left = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2411_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2414})});
    V v_t_2416 = (g_co_2eop_24s1203925392x1944187472(v_t_2415, v_k_244));
    V f_ = v_t_2416;
    args[0] = v_z_2412;
    args[1] = v_z_2413;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    V f_ = v_k_244;
    args[0] = v_x_2417;
    args[1] = v_z_2412;
    args[2] = v_z_2413;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    heff_take_n(v_x_2421, 0ULL, 1);
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2421, 0ULL, 1);
    v_t_2424 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V f_ = v_k_2420;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_lam3, 1, 1, (V[]){v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}