// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Throw 56084
#define LBL_bind 9519364
#define LBL_malg 9839318
V g_co_2eop_24s1628839587x1321325607(V, V, V, V);
V g_co_2eop_24s1628839587x1321325607_entry(V self, V *a);
extern Clo g_co_2eop_24s1628839587x1321325607_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2eutil_2efiles_2ereadFile(V, V, V);
V g_heff_2eutil_2efiles_2ereadFile_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_heff_2eutil_2efiles_2ereadFile_lam0(V self, V *args);
V g_heff_2eutil_2efiles_2ereadFile_lam1(V self, V *args); static Clo g_heff_2eutil_2efiles_2ereadFile_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadFile_lam1, 1, 0};
V g_heff_2eutil_2efiles_2ereadFile_lam3(V self, V *args);
V g_heff_2eutil_2efiles_2ereadFile_lam2(V self, V *args);
V g_heff_2eutil_2efiles_2ereadFile_lam4(V self, V *args); static Clo g_heff_2eutil_2efiles_2ereadFile_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadFile_lam4, 3, 0};
V g_heff_2eutil_2efiles_2ereadFile_lam6(V self, V *args);
V g_heff_2eutil_2efiles_2ereadFile_lam5(V self, V *args);
Clo g_heff_2eutil_2efiles_2ereadFile_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadFile_entry, 3, 0};

V g_heff_2eutil_2efiles_2ereadFile(V v_e_240, V v_disk_241, V v_path_242) {
top: ;
  V v_lit_243 = heff_dup(v_e_240);
  V v_ev_246 = heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_lam0, 1, 1, (V[]){v_disk_241});
  V v_path_247 = v_path_242;
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
  V v_t_2410 = heff_tr(heff_call(v_ev_246, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_248, ((V)&g_heff_2eutil_2efiles_2ereadFile_lam1_clo)})}));
  V v_c_2418 = heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_lam2, 2, 2, (V[]){v_lit_243, v_t_2410});
  V v_t_2419 = (g_exception_2eattempted(v_e_240));
  V v_c_2423 = heff_tr(heff_call(v_c_2418, 2, (V[]){v_t_2419, ((V)&g_heff_2eutil_2efiles_2ereadFile_lam4_clo)}));
  return heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_lam5, 2, 1, (V[]){v_c_2423});
}
V g_heff_2eutil_2efiles_2ereadFile_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2efiles_2ereadFile(a[0], a[1], a[2]);
}
V g_heff_2eutil_2efiles_2ereadFile_lam0(V self, V *args) {
  V v_p_231002_244 = args[0];
  V v_disk_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(v_disk_241, 1, (V[]){v_p_231002_244}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_245});
}
V g_heff_2eutil_2efiles_2ereadFile_lam1(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2eutil_2efiles_2ereadFile_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2413_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2414})});
    V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_2411, 2), 1, (V[]){v_t_2415}));
    V f_ = heff_get_n(v_hd_2411, 1, 3);
    heff_room[0] = v_t_2416;
    heff_room[1] = v_k_2412;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    heff_drop_rec(v_hd_2411, 3);
    V f_ = v_k_2412;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2eutil_2efiles_2ereadFile_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_lit_243 = heff_env(self)[0];
  V v_t_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1628839587x1321325607(v_lit_243, v_t_2410, heff_dup(v_hd_2411), heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_lam3, 1, 2, (V[]){v_hd_2411, v_k_2412})));
}
V g_heff_2eutil_2efiles_2ereadFile_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_2421 = args[1];
  V v_k_2422 = args[2];
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ereadFile_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429;
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    heff_take_n(v_x_2426, 0ULL, 1);
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2426, 0);
    V v_ru_24x_2426_24Right = heff_take_reuse_n(v_x_2426, 1ULL, 1);
    v_t_2429 = heff_tag_at_n(v_ru_24x_2426_24Right, TAG_Just, 1, (V[]){v_y_2428});
    break;
  }
  default: heff_nomatch(v_x_2426);
  }
  V f_ = v_k_2425;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ereadFile_lam5(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_lam6, 1, 1, (V[]){v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}