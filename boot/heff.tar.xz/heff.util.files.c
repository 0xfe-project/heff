// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Right 62770
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2eutil_2efiles_2ereadDirectory(V, V, V);
V g_heff_2eutil_2efiles_2ereadDirectory_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_clo;
V g_heff_2eutil_2efiles_2ereadFile(V, V, V);
V g_heff_2eutil_2efiles_2ereadFile_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351(V, V, V);
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_clo;
V g_std_2efilesystem_2ereadFile_24s597359330x237736700(V, V, V);
V g_std_2efilesystem_2ereadFile_24s597359330x237736700_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s597359330x237736700_clo;
V g_heff_2eutil_2efiles_2ereadFile_lam0(V self, V *args);
V g_heff_2eutil_2efiles_2ereadFile_lam1(V self, V *args); static Clo g_heff_2eutil_2efiles_2ereadFile_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadFile_lam1, 3, 0};
V g_heff_2eutil_2efiles_2ereadFile_lam3(V self, V *args);
V g_heff_2eutil_2efiles_2ereadFile_lam2(V self, V *args);
Clo g_heff_2eutil_2efiles_2ereadFile_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadFile_entry, 3, 0};

V g_heff_2eutil_2efiles_2ereadFile(V v_e_240, V v_disk_241, V v_path_242) {
top: ;
  V v_c_245 = (g_std_2efilesystem_2ereadFile_24s597359330x237736700(heff_dup(v_e_240), heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_lam0, 1, 1, (V[]){v_disk_241}), v_path_242));
  V v_t_246 = (g_exception_2eattempted(v_e_240));
  V v_c_2410 = heff_tr(heff_call(v_c_245, 2, (V[]){v_t_246, ((V)&g_heff_2eutil_2efiles_2ereadFile_lam1_clo)}));
  return heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_lam2, 2, 1, (V[]){v_c_2410});
}
V g_heff_2eutil_2efiles_2ereadFile_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eutil_2efiles_2ereadFile(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eutil_2efiles_2ereadFile_lam0(V self, V *args) {
  V v_p_231002_243 = args[0];
  V v_disk_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tr(heff_call(v_disk_241, 1, (V[]){v_p_231002_243}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_244});
}
V g_heff_2eutil_2efiles_2ereadFile_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_248 = args[1];
  V v_k_249 = args[2];
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ereadFile_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    heff_take_n(v_x_2413, 0ULL, 1);
    v_t_2416 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2415 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Right = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    v_t_2416 = heff_tag_at_n(v_ru_24x_2413_24Right, TAG_Just, 1, (V[]){v_y_2415});
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V f_ = v_k_2412;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ereadFile_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2410;
  args[0] = v_hd_2411;
  args[1] = heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_lam3, 1, 1, (V[]){v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eutil_2efiles_2ereadDirectory_lam0(V self, V *args);
V g_heff_2eutil_2efiles_2ereadDirectory_lam2(V self, V *args);
V g_heff_2eutil_2efiles_2ereadDirectory_lam1(V self, V *args); static Clo g_heff_2eutil_2efiles_2ereadDirectory_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadDirectory_lam1, 1, 0};
V g_heff_2eutil_2efiles_2ereadDirectory_lam4(V self, V *args);
V g_heff_2eutil_2efiles_2ereadDirectory_lam3(V self, V *args);
Clo g_heff_2eutil_2efiles_2ereadDirectory_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadDirectory_entry, 3, 0};

V g_heff_2eutil_2efiles_2ereadDirectory(V v_e_240, V v_disk_241, V v_path_242) {
top: ;
  V v_c_245 = (g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351(heff_dup(v_e_240), heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_lam0, 1, 1, (V[]){v_disk_241}), v_path_242));
  V v_t_246 = (g_exception_2eattempted(v_e_240));
  V v_c_2411 = heff_tr(heff_call(v_c_245, 2, (V[]){v_t_246, ((V)&g_heff_2eutil_2efiles_2ereadDirectory_lam1_clo)}));
  return heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_lam3, 2, 1, (V[]){v_c_2411});
}
V g_heff_2eutil_2efiles_2ereadDirectory_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2efiles_2ereadDirectory(a[0], a[1], a[2]);
}
V g_heff_2eutil_2efiles_2ereadDirectory_lam0(V self, V *args) {
  V v_p_231002_243 = args[0];
  V v_disk_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tr(heff_call(v_disk_241, 1, (V[]){v_p_231002_243}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_244});
}
V g_heff_2eutil_2efiles_2ereadDirectory_lam2(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ereadDirectory_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_248 = (g_list_2emap_24s219049803x1458391381(v_x_247));
  return heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_lam2, 2, 1, (V[]){v_x_248});
}
V g_heff_2eutil_2efiles_2ereadDirectory_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    heff_take_n(v_x_2414, 0ULL, 1);
    v_t_2417 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2416 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Right = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    v_t_2417 = heff_tag_at_n(v_ru_24x_2414_24Right, TAG_Just, 1, (V[]){v_y_2416});
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_k_2413;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eutil_2efiles_2ereadDirectory_lam3(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_lam4, 1, 1, (V[]){v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}