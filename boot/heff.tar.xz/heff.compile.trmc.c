// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FtAny 18156
#define TAG_Hole 35555
#define TAG_SetField 47531
#define TAG_StrAppend 34515
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_m 327
#define LBL_n 328
#define LBL_name 9869138
#define LBL_xs 10594
static uint32_t shape_key__at[] = {LBL_key, LBL_at};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_m__n__xs[] = {LBL_m, LBL_n, LBL_xs};
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841(V, V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267(V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841(V, V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_clo;
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
V g_heff_2ecompile_2etrmc_2eappendEnds(V, V);
V g_heff_2ecompile_2etrmc_2eappendEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eappendEnds_clo;
V g_heff_2ecompile_2etrmc_2eappendedTo(V, V);
V g_heff_2ecompile_2etrmc_2eappendedTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eappendedTo_clo;
V g_heff_2ecompile_2etrmc_2econsEnds(V, V);
V g_heff_2ecompile_2etrmc_2econsEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2econsEnds_clo;
V g_heff_2ecompile_2etrmc_2edestined(V, V, V, V);
V g_heff_2ecompile_2etrmc_2edestined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2edestined_clo;
V g_heff_2ecompile_2etrmc_2efill(V, V, V, V, V);
V g_heff_2ecompile_2etrmc_2efill_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2efill_clo;
V g_heff_2ecompile_2etrmc_2egather(V, V, V, V);
V g_heff_2ecompile_2etrmc_2egather_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2egather_clo;
V g_heff_2ecompile_2etrmc_2egathered(V, V, V, V);
V g_heff_2ecompile_2etrmc_2egathered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2egathered_clo;
V g_heff_2ecompile_2etrmc_2ehole_get(void);
V g_heff_2ecompile_2etrmc_2eholesAt(V, V);
V g_heff_2ecompile_2etrmc_2eholesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eholesAt_clo;
V g_heff_2ecompile_2etrmc_2eselfCall(V, V);
V g_heff_2ecompile_2etrmc_2eselfCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eselfCall_clo;
V g_heff_2ecompile_2etrmc_2esetFieldPrim_get(void);
V g_heff_2ecompile_2etrmc_2estartAcc(V, V, V);
V g_heff_2ecompile_2etrmc_2estartAcc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2estartAcc_clo;
V g_heff_2ecompile_2etrmc_2estartCell(V, V, V);
V g_heff_2ecompile_2etrmc_2estartCell_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2estartCell_clo;
V g_list_2eall_24s262401054x194288545(V, V);
V g_list_2eall_24s262401054x194288545_entry(V self, V *a);
extern Clo g_list_2eall_24s262401054x194288545_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636(V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);

static V g_heff_2ecompile_2etrmc_2esetFieldPrim_val;
static HEFF_ONCE g_heff_2ecompile_2etrmc_2esetFieldPrim_st;
static V g_heff_2ecompile_2etrmc_2esetFieldPrim_init(void) {
  return NTAG(TAG_SetField);
}
V g_heff_2ecompile_2etrmc_2esetFieldPrim_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2etrmc_2esetFieldPrim_st)) return g_heff_2ecompile_2etrmc_2esetFieldPrim_val;
  return heff_global(&g_heff_2ecompile_2etrmc_2esetFieldPrim_val, &g_heff_2ecompile_2etrmc_2esetFieldPrim_st, g_heff_2ecompile_2etrmc_2esetFieldPrim_init);
}

static V g_heff_2ecompile_2etrmc_2ehole_val;
static HEFF_ONCE g_heff_2ecompile_2etrmc_2ehole_st;
static V g_heff_2ecompile_2etrmc_2ehole_init(void) {
  return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_Hole), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2etrmc_2ehole_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2etrmc_2ehole_st)) return g_heff_2ecompile_2etrmc_2ehole_val;
  return heff_global(&g_heff_2ecompile_2etrmc_2ehole_val, &g_heff_2ecompile_2etrmc_2ehole_st, g_heff_2ecompile_2etrmc_2ehole_init);
}
Clo g_heff_2ecompile_2etrmc_2eselfCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eselfCall_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eselfCall(V v_s_240, V v_x2_241) {
top: ;
  V v_key_242 = heff_take_field(v_s_240, 0);
  V v_arity_243 = heff_get_n(v_s_240, 1, 2);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    V v_g_2427 = heff_field(v_x2_241, 0);
    V v_args_2428 = heff_field(v_x2_241, 1);
    V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_g_2427, v_key_242, 0) && ({ V v_t_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2428)); int c_ = heff_intEq_c_lent(v_t_2443, v_arity_243, 0); heff_drop(v_t_2443); c_; })));
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return v_ret_24bool;
  }
  case TAG_EInt: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2eselfCall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2etrmc_2eselfCall(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2etrmc_2econsEnds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2econsEnds_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2econsEnds(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_args_2418 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2418));
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nil: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x1_2420, 0);
      heff_take_n(v_x1_2420, 1ULL, 2);
      V v_t_2423 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_x_2421));
      if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
        heff_drop(v_s_240);
        heff_drop(v_x_2421);
        heff_drop(v_t_2423);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2423);
        V t_0 = v_s_240;
        V t_1 = v_x_2421;
        v_s_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x1_2420);
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2econsEnds_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2econsEnds(a[0], a[1]);
}
Clo g_heff_2ecompile_2etrmc_2eappendEnds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eappendEnds_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eappendEnds(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_x21_2423 = heff_field(v_x2_241, 0);
    V v_x22_2424 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_2423)) {
    case TAG_StrAppend: {
      switch (heff_tag_of(v_x22_2424)) {
      case TAG_Nil: {
        heff_drop(v_s_240);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x222_2426 = heff_field(v_x22_2424, 1);
        switch (heff_tag_of(v_x222_2426)) {
        case TAG_Nil: {
          heff_drop(v_s_240);
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          V v_r_2427 = heff_field(v_x222_2426, 0);
          V v_x2222_2428 = heff_field(v_x222_2426, 1);
          switch (heff_tag_of(v_x2222_2428)) {
          case TAG_Nil: {
            V v_t_2429 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_r_2427));
            if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
              heff_drop(v_s_240);
              heff_drop(v_t_2429);
              return NTAG(TAG_True);
            } else {
              heff_drop(v_t_2429);
              V t_0 = v_s_240;
              V t_1 = v_r_2427;
              v_s_240 = t_0;
              v_x2_241 = t_1;
              goto top;
            }
          }
          case TAG_Cons: {
            heff_drop(v_s_240);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x2222_2428);
          }
        }
        default: return heff_nomatch(v_x222_2426);
        }
      }
      default: return heff_nomatch(v_x22_2424);
      }
    }
    default: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    }
  }
  case TAG_ECall: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2eappendEnds_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2etrmc_2eappendEnds(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2efill_str0, 5, "cell$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2efill_str1, 2, "u$");
V g_heff_2ecompile_2etrmc_2efill_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam4(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2efill_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2efill_entry, 5, 0};

V g_heff_2ecompile_2etrmc_2efill(V v_s_240, V v_p_241, V v_d_242, V v_i_243, V v_e_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_e_244));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_s_240);
    heff_drop(v_t_245);
    switch (heff_tag_of(v_e_244)) {
    case TAG_ECall: {
      V v_args_247 = heff_field(v_e_244, 1);
      V v_ru_24e_244_24ECall = heff_take_reuse_n(v_e_244, 2ULL, 2);
      V v_t_248 = heff_take_field(v_p_241, 1);
      V v_t_2411;
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_i_243, NTAG(TAG_Nil)});
        v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, v_t_249});
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_248, 0ULL, 1);
        heff_drop(v_i_243);
        v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_t_2412 = (g_prelude_2e_2b_2b(v_args_247, v_t_2411));
      V v_x_2413 = heff_tag_at_n(v_ru_24e_244_24ECall, TAG_ECall, 2, (V[]){heff_get_n(v_p_241, 0, 2), v_t_2412});
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam0, 1, 1, (V[]){v_x_2413});
    }
    default: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam1, 1, 1, (V[]){v_e_244});
    }
    }
  } else {
    heff_drop(v_t_245);
    V v_t_2416 = (g_heff_2ecompile_2etrmc_2econsEnds(heff_dup(v_s_240), heff_dup(v_e_244)));
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_t_2416);
      switch (heff_tag_of(v_e_244)) {
      case TAG_ETag: {
        V v_t_2417 = heff_dup(heff_field(v_e_244, 0));
        V v_args_2418 = heff_dup(heff_field(v_e_244, 1));
        V v_ts_2419 = heff_dup(heff_field(v_e_244, 2));
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam2, 1, 8, (V[]){v_args_2418, v_e_244, v_s_240, v_p_241, v_ts_2419, v_d_242, v_i_243, v_t_2417});
      }
      default: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam3, 1, 1, (V[]){v_e_244});
      }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_t_2416);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam4, 1, 3, (V[]){v_e_244, v_d_242, v_i_243});
    }
  }
}
V g_heff_2ecompile_2etrmc_2efill_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2efill(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2etrmc_2efill_lam0(V self, V *args) {
  V v_n_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_n_2414});
}
V g_heff_2ecompile_2etrmc_2efill_lam1(V self, V *args) {
  V v_n_2415 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2415});
}
V g_heff_2ecompile_2etrmc_2efill_lam2(V self, V *args) {
  V v_n_2420 = args[0];
  V v_args_2418 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_s_240 = heff_env(self)[2];
  V v_p_241 = heff_env(self)[3];
  V v_ts_2419 = heff_env(self)[4];
  V v_d_242 = heff_env(self)[5];
  V v_i_243 = heff_env(self)[6];
  V v_t_2417 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2421 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2efill_str0), heff_intShow(heff_dup(v_n_2420)));
  V v_n_2422 = heff_intAdd(v_n_2420, MK_INT(1LL));
  V v_x_2423 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2efill_str1), heff_intShow(heff_dup(v_n_2422)));
  V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2418));
  V v_t_2425 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_t_2424, MK_INT(1LL))});
  V v_x1_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2418)));
  V v_t_2429;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_Nil: {
    v_t_2429 = v_e_244;
    break;
  }
  case TAG_Cons: {
    V v_x_2427 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 2);
    heff_drop_tag(v_e_244, 3);
    v_t_2429 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  V v_m_2430 = (g_heff_2ecompile_2etrmc_2efill(v_s_240, v_p_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2421)}), v_t_2425, v_t_2429));
  V v_x2_2431 = heff_tr(heff_call(v_m_2430, 1, (V[]){heff_intAdd(v_n_2422, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_n_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2ehole_get()), NTAG(TAG_Nil)});
    V v_t_2435 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2434, v_args_2418));
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), NTAG(TAG_Nil)});
    V v_t_2437 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2436, v_ts_2419));
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2421)}), NTAG(TAG_Nil)});
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, heff_tag_n(TAG_Cons, 2, (V[]){v_i_243, v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_2423, heff_tag_n(TAG_EPrimCall, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2esetFieldPrim_get()), v_t_2439}), v_x_2432});
    V v_x_2441 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_2421, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2417, v_t_2435, v_t_2437}), v_t_2440});
    return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){v_x_2441, v_n_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2etrmc_2efill_lam3(V self, V *args) {
  V v_n_2442 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2442});
}
V g_heff_2ecompile_2etrmc_2efill_lam4(V self, V *args) {
  V v_n_2443 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_i_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, heff_tag_n(TAG_Cons, 2, (V[]){v_i_243, v_t_2444})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2esetFieldPrim_get()), v_t_2445}), v_n_2443});
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartCell_str0, 5, "cell$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartCell_str1, 2, "u$");
V g_heff_2ecompile_2etrmc_2estartCell_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam2(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2estartCell_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2estartCell_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2estartCell(V v_s_240, V v_p_241, V v_e_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2etrmc_2econsEnds(heff_dup(v_s_240), heff_dup(v_e_242)));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    switch (heff_tag_of(v_e_242)) {
    case TAG_ETag: {
      V v_t_244 = heff_dup(heff_field(v_e_242, 0));
      V v_args_245 = heff_dup(heff_field(v_e_242, 1));
      V v_ts_246 = heff_dup(heff_field(v_e_242, 2));
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam0, 1, 6, (V[]){v_args_245, v_e_242, v_s_240, v_p_241, v_ts_246, v_t_244});
    }
    default: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam1, 1, 1, (V[]){v_e_242});
    }
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_p_241);
    heff_drop(v_t_243);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam2, 1, 1, (V[]){v_e_242});
  }
}
V g_heff_2ecompile_2etrmc_2estartCell_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2estartCell(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2etrmc_2estartCell_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_args_245 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_s_240 = heff_env(self)[2];
  V v_p_241 = heff_env(self)[3];
  V v_ts_246 = heff_env(self)[4];
  V v_t_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_248 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartCell_str0), heff_intShow(heff_dup(v_n_247)));
  V v_n_249 = heff_intAdd(v_n_247, MK_INT(1LL));
  V v_x_2410 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartCell_str1), heff_intShow(heff_dup(v_n_249)));
  V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_245));
  V v_t_2412 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_t_2411, MK_INT(1LL))});
  V v_x1_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_245)));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Nil: {
    v_t_2416 = v_e_242;
    break;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 2);
    heff_drop_tag(v_e_242, 3);
    v_t_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2413);
  }
  V v_m_2417 = (g_heff_2ecompile_2etrmc_2efill(v_s_240, v_p_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_248)}), v_t_2412, v_t_2416));
  V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){heff_intAdd(v_n_249, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_n_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2ehole_get()), NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2421, v_args_245));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), NTAG(TAG_Nil)});
    V v_t_2424 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2423, v_ts_246));
    V v_t_2425 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_2410, v_x_2419, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_248)})});
    V v_x_2426 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_248, heff_tag_n(TAG_ETag, 3, (V[]){v_t_244, v_t_2422, v_t_2424}), v_t_2425});
    return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2426, v_n_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2etrmc_2estartCell_lam1(V self, V *args) {
  V v_n_2427 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2427});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam2(V self, V *args) {
  V v_n_2428 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2428});
}
Clo g_heff_2ecompile_2etrmc_2eholesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eholesAt_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eholesAt(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    V v_args_2418 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2418)));
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nil: {
      heff_drop(v_s_240);
      heff_drop(v_args_2418);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x1_2420, 0);
      V v_ru_24x1_2420_24Cons = heff_take_reuse_n(v_x1_2420, 1ULL, 2);
      V v_t_2423 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_x_2421));
      if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
        heff_drop(v_s_240);
        heff_drop(v_x_2421);
        heff_drop(v_t_2423);
        V v_t_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2418; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2418); r_; });
        return heff_tag_at_n(v_ru_24x1_2420_24Cons, TAG_Cons, 2, (V[]){heff_intSub(v_t_2424, MK_INT(1LL)), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_args_2418);
        heff_drop_cell(v_ru_24x1_2420_24Cons, 2);
        heff_drop(v_t_2423);
        V v_t_2425 = (g_heff_2ecompile_2etrmc_2econsEnds(heff_dup(v_s_240), heff_dup(v_x_2421)));
        if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
          heff_drop(v_t_2425);
          V t_0 = v_s_240;
          V t_1 = v_x_2421;
          v_s_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          heff_drop(v_s_240);
          heff_drop(v_x_2421);
          heff_drop(v_t_2425);
          return NTAG(TAG_Nil);
        }
      }
    }
    default: return heff_nomatch(v_x1_2420);
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2eholesAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eholesAt(a[0], a[1]);
}
Clo g_heff_2ecompile_2etrmc_2eappendedTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eappendedTo_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eappendedTo(V v_acc_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EPrimCall: {
    V v_e1_242 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_243 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_StrAppend: {
      switch (heff_tag_of(v_e2_243)) {
      case TAG_Nil: {
        V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrAppend), heff_tag_n(TAG_Cons, 2, (V[]){v_acc_240, v_t_244})});
      }
      case TAG_Cons: {
        V v_a_245 = heff_field(v_e2_243, 0);
        V v_e22_246 = heff_field(v_e2_243, 1);
        V v_ru_24e2_243_24Cons = heff_take_reuse_n(v_e2_243, 3ULL, 2);
        switch (heff_tag_of(v_e22_246)) {
        case TAG_Nil: {
          heff_drop(v_a_245);
          V v_t_247 = heff_tag_at_n(v_ru_24e2_243_24Cons, TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrAppend), heff_tag_n(TAG_Cons, 2, (V[]){v_acc_240, v_t_247})});
        }
        case TAG_Cons: {
          V v_b_248 = heff_field(v_e22_246, 0);
          V v_e222_249 = heff_field(v_e22_246, 1);
          V v_ru_24e22_246_24Cons = heff_take_reuse_n(v_e22_246, 3ULL, 2);
          switch (heff_tag_of(v_e222_249)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_241, 2);
            V v_a_2410 = (g_heff_2ecompile_2etrmc_2eappendedTo(v_acc_240, v_a_245));
            V v_t_2411 = heff_tag_at_n(v_ru_24e2_243_24Cons, TAG_Cons, 2, (V[]){v_b_248, NTAG(TAG_Nil)});
            return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrAppend), heff_tag_at_n(v_ru_24e22_246_24Cons, TAG_Cons, 2, (V[]){v_a_2410, v_t_2411})});
          }
          case TAG_Cons: {
            V v_ru_24e222_249_24Cons = heff_take_reuse_n(v_e222_249, 0ULL, 2);
            heff_drop(v_a_245);
            heff_drop(v_b_248);
            V v_t_2414 = heff_tag_at_n(v_ru_24e2_243_24Cons, TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
            return heff_tag_at_n(v_ru_24e222_249_24Cons, TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrAppend), heff_tag_at_n(v_ru_24e22_246_24Cons, TAG_Cons, 2, (V[]){v_acc_240, v_t_2414})});
          }
          default: return heff_nomatch(v_e222_249);
          }
        }
        default: return heff_nomatch(v_e22_246);
        }
      }
      default: return heff_nomatch(v_e2_243);
      }
    }
    default: {
      heff_drop(v_e1_242);
      heff_drop(v_e2_243);
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrAppend), heff_tag_n(TAG_Cons, 2, (V[]){v_acc_240, v_t_2415})});
    }
    }
  }
  default: {
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrAppend), heff_tag_n(TAG_Cons, 2, (V[]){v_acc_240, v_t_2416})});
  }
  }
}
V g_heff_2ecompile_2etrmc_2eappendedTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eappendedTo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2egather_str0, 2, "s$");
V g_heff_2ecompile_2etrmc_2egather_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam4(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam5(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam6(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam7(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2egather_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2egather_entry, 4, 0};

V g_heff_2ecompile_2etrmc_2egather(V v_s_240, V v_ak_241, V v_acc_242, V v_e_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_e_243));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_s_240);
    heff_drop(v_t_244);
    switch (heff_tag_of(v_e_243)) {
    case TAG_ECall: {
      V v_args_246 = heff_field(v_e_243, 1);
      V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 2ULL, 2);
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_acc_242, NTAG(TAG_Nil)});
      V v_t_248 = (g_prelude_2e_2b_2b(v_args_246, v_t_247));
      V v_x_249 = heff_tag_at_n(v_ru_24e_243_24ECall, TAG_ECall, 2, (V[]){v_ak_241, v_t_248});
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam0, 1, 1, (V[]){v_x_249});
    }
    default: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam1, 1, 1, (V[]){v_e_243});
    }
    }
  } else {
    heff_drop(v_t_244);
    V v_t_2412 = (g_heff_2ecompile_2etrmc_2eappendEnds(heff_dup(v_s_240), v_e_243));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      switch (heff_tag_of(v_e_243)) {
      case TAG_EPrimCall: {
        V v_it2_2414 = heff_dup(heff_field(v_e_243, 1));
        switch (heff_tag_of(v_it2_2414)) {
        case TAG_Nil: {
          heff_drop(v_s_240);
          heff_drop(v_ak_241);
          heff_drop(v_acc_242);
          return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam2, 1, 1, (V[]){v_e_243});
        }
        case TAG_Cons: {
          V v_a_2416 = heff_field(v_it2_2414, 0);
          V v_it22_2417 = heff_field(v_it2_2414, 1);
          heff_take_n(v_it2_2414, 3ULL, 2);
          switch (heff_tag_of(v_it22_2417)) {
          case TAG_Nil: {
            heff_drop(v_s_240);
            heff_drop(v_ak_241);
            heff_drop(v_acc_242);
            heff_drop(v_a_2416);
            return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam3, 1, 1, (V[]){v_e_243});
          }
          case TAG_Cons: {
            V v_r_2419 = heff_field(v_it22_2417, 0);
            V v_it222_2420 = heff_field(v_it22_2417, 1);
            heff_take_n(v_it22_2417, 3ULL, 2);
            switch (heff_tag_of(v_it222_2420)) {
            case TAG_Nil: {
              heff_drop_tag(v_e_243, 2);
              return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam4, 1, 5, (V[]){v_s_240, v_ak_241, v_r_2419, v_acc_242, v_a_2416});
            }
            case TAG_Cons: {
              heff_take_n(v_it222_2420, 0ULL, 2);
              heff_drop(v_s_240);
              heff_drop(v_ak_241);
              heff_drop(v_acc_242);
              heff_drop(v_a_2416);
              heff_drop(v_r_2419);
              return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam5, 1, 1, (V[]){v_e_243});
            }
            default: return heff_nomatch(v_it222_2420);
            }
          }
          default: return heff_nomatch(v_it22_2417);
          }
        }
        default: return heff_nomatch(v_it2_2414);
        }
      }
      default: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam6, 1, 1, (V[]){v_e_243});
      }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      heff_drop(v_t_2412);
      V v_x_2433 = (g_heff_2ecompile_2etrmc_2eappendedTo(v_acc_242, v_e_243));
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam7, 1, 1, (V[]){v_x_2433});
    }
  }
}
V g_heff_2ecompile_2etrmc_2egather_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2egather(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2etrmc_2egather_lam0(V self, V *args) {
  V v_n_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_n_2410});
}
V g_heff_2ecompile_2etrmc_2egather_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2411});
}
V g_heff_2ecompile_2etrmc_2egather_lam2(V self, V *args) {
  V v_n_2415 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2415});
}
V g_heff_2ecompile_2etrmc_2egather_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2418});
}
V g_heff_2ecompile_2etrmc_2egather_lam4(V self, V *args) {
  V v_n_2421 = args[0];
  V v_s_240 = heff_env(self)[0];
  V v_ak_241 = heff_env(self)[1];
  V v_r_2419 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_a_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2422 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2egather_str0), heff_intShow(heff_dup(v_n_2421)));
  V v_m_2423 = (g_heff_2ecompile_2etrmc_2egather(v_s_240, v_ak_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2422)}), v_r_2419));
  V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){heff_intAdd(v_n_2421, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_n_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    V v_t_2427 = (g_heff_2ecompile_2etrmc_2eappendedTo(v_acc_242, v_a_2416));
    V v_x_2428 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_2422, v_t_2427, v_x_2425});
    return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){v_x_2428, v_n_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2etrmc_2egather_lam5(V self, V *args) {
  V v_n_2431 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2431});
}
V g_heff_2ecompile_2etrmc_2egather_lam6(V self, V *args) {
  V v_n_2432 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2432});
}
V g_heff_2ecompile_2etrmc_2egather_lam7(V self, V *args) {
  V v_n_2434 = args[0];
  V v_x_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2433, v_n_2434});
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartAcc_str0, 2, "s$");
V g_heff_2ecompile_2etrmc_2estartAcc_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam4(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam5(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2estartAcc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2estartAcc_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2estartAcc(V v_s_240, V v_ak_241, V v_e_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2etrmc_2eappendEnds(heff_dup(v_s_240), v_e_242));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    switch (heff_tag_of(v_e_242)) {
    case TAG_EPrimCall: {
      V v_it2_245 = heff_dup(heff_field(v_e_242, 1));
      switch (heff_tag_of(v_it2_245)) {
      case TAG_Nil: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam0, 1, 1, (V[]){v_e_242});
      }
      case TAG_Cons: {
        V v_a_247 = heff_field(v_it2_245, 0);
        V v_it22_248 = heff_field(v_it2_245, 1);
        heff_take_n(v_it2_245, 3ULL, 2);
        switch (heff_tag_of(v_it22_248)) {
        case TAG_Nil: {
          heff_drop(v_s_240);
          heff_drop(v_ak_241);
          heff_drop(v_a_247);
          return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam1, 1, 1, (V[]){v_e_242});
        }
        case TAG_Cons: {
          V v_r_2410 = heff_field(v_it22_248, 0);
          V v_it222_2411 = heff_field(v_it22_248, 1);
          heff_take_n(v_it22_248, 3ULL, 2);
          switch (heff_tag_of(v_it222_2411)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_242, 2);
            return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam2, 1, 4, (V[]){v_s_240, v_ak_241, v_r_2410, v_a_247});
          }
          case TAG_Cons: {
            heff_take_n(v_it222_2411, 0ULL, 2);
            heff_drop(v_s_240);
            heff_drop(v_ak_241);
            heff_drop(v_a_247);
            heff_drop(v_r_2410);
            return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam3, 1, 1, (V[]){v_e_242});
          }
          default: return heff_nomatch(v_it222_2411);
          }
        }
        default: return heff_nomatch(v_it22_248);
        }
      }
      default: return heff_nomatch(v_it2_245);
      }
    }
    default: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam4, 1, 1, (V[]){v_e_242});
    }
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_ak_241);
    heff_drop(v_t_243);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam5, 1, 1, (V[]){v_e_242});
  }
}
V g_heff_2ecompile_2etrmc_2estartAcc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2estartAcc(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_246});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_249});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  V v_s_240 = heff_env(self)[0];
  V v_ak_241 = heff_env(self)[1];
  V v_r_2410 = heff_env(self)[2];
  V v_a_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2413 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartAcc_str0), heff_intShow(heff_dup(v_n_2412)));
  V v_m_2414 = (g_heff_2ecompile_2etrmc_2egather(v_s_240, v_ak_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2413)}), v_r_2410));
  V v_x2_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){heff_intAdd(v_n_2412, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2413, v_a_247, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam3(V self, V *args) {
  V v_n_2420 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2420});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam4(V self, V *args) {
  V v_n_2421 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2421});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam5(V self, V *args) {
  V v_n_2422 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2422});
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str0, 4, "$dps");
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str1, 2, "d$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str2, 2, "i$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str3, 4, "$dps");
V g_heff_2ecompile_2etrmc_2edestined_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2edestined_lam1(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2edestined_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2edestined_entry, 4, 0};

V g_heff_2ecompile_2etrmc_2edestined(V v_s_240, V v_d_241, V v_xs_242, V v_b_243) {
top: ;
  V v_t_244 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2ecompile_2etrmc_2edestined_str0));
  V v_xs_245 = (g_heff_2ecompile_2eir_2ewaysOnto(heff_dup(v_b_243), NTAG(TAG_Nil)));
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
  V v_x1_2410 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2etrmc_2edestined_lam0, 2, 1, (V[]){heff_dup(v_s_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_2414;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nil: {
    v_t_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_k_2411 = heff_field(v_x1_2410, 0);
    V v_ks_2412 = heff_field(v_x1_2410, 1);
    heff_take_n(v_x1_2410, 3ULL, 2);
    V v_t_2413 = ({ V a_0 = heff_dup(v_k_2411); V a_1 = v_ks_2412; V r_ = (g_list_2eall_24s262401054x194288545(a_0, a_1)); heff_drop(v_ks_2412); r_; });
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_k_2411});
    } else {
      heff_drop(v_k_2411);
      heff_drop(v_t_2413);
      v_t_2414 = NTAG(TAG_Nothing);
    }
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  V v_p_2415 = heff_rec_n(2, shape_key__at, (V[]){v_t_244, v_t_2414});
  V v_m_2416 = (g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841(heff_dup(v_s_240), heff_dup(v_p_2415), heff_dup(v_b_243)));
  return heff_clo_n(g_heff_2ecompile_2etrmc_2edestined_lam1, 1, 6, (V[]){v_m_2416, v_xs_242, v_b_243, v_p_2415, v_s_240, v_d_241});
}
V g_heff_2ecompile_2etrmc_2edestined_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2edestined(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2etrmc_2edestined_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = (g_heff_2ecompile_2etrmc_2eholesAt(v_s_240, v_x_248));
  return (g_prelude_2e_2b_2b(v_t_249, v_acc_247));
}
V g_heff_2ecompile_2etrmc_2edestined_lam1(V self, V *args) {
  V v_n_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  V v_b_243 = heff_env(self)[2];
  V v_p_2415 = heff_env(self)[3];
  V v_s_240 = heff_env(self)[4];
  V v_d_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_n_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_n_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = heff_rec_n(3, shape_m__n__xs, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), v_n_2420, NTAG(TAG_Nil)});
    V v_v_2422 = (g_list_2efoldl_24s690313412x1307839513(v_t_2421, heff_dup(v_xs_242)));
    V v_m_2423 = heff_take_field(v_v_2422, 0);
    V v_n_2424 = heff_take_field(v_v_2422, 1);
    V v_xs_2425 = heff_get_n(v_v_2422, 2, 3);
    HeffT2 v_t_2426 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2423, v_n_2424, v_b_243));
    {
      V v_field_2427 = v_t_2426.f[0];
      V v_field_2428 = v_t_2426.f[1];
      V v_b_27_2429 = v_field_2427;
      V v_n_27_2430 = v_field_2428;
      V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2425));
      V v_x_2432 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2edestined_str1), heff_intShow(heff_dup(v_n_27_2430)));
      V v_n_2433 = heff_intAdd(v_n_27_2430, MK_INT(1LL));
      V v_x_2434 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2edestined_str2), heff_intShow(heff_dup(v_n_2433)));
      V v_t_2435 = heff_dup(heff_rfield(v_p_2415, 1));
      V v_t_2437;
      switch (heff_tag_of(v_t_2435)) {
      case TAG_Nothing: {
        v_t_2437 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2434)});
        break;
      }
      case TAG_Just: {
        V v_k_2436 = heff_field(v_t_2435, 0);
        V v_ru_24t_2435_24Just = heff_take_reuse_n(v_t_2435, 1ULL, 1);
        v_t_2437 = heff_tag_at_n(v_ru_24t_2435_24Just, TAG_EInt, 1, (V[]){v_k_2436});
        break;
      }
      default: heff_nomatch(v_t_2435);
      }
      V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2ecompile_2etrmc_2efill_clo), 4, (V[]){v_s_240, heff_dup(v_p_2415), heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2432)}), v_t_2437}));
      V v_m_2439 = heff_tr(g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267(v_t_2438, v_b_27_2429));
      V v_x2_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){heff_intAdd(v_n_2433, MK_INT(1LL))}));
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_MkPair: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_n_2442 = heff_field(v_x2_2440, 1);
        V v_ru_24x2_2440_24MkPair = heff_take_reuse_n(v_x2_2440, 3ULL, 2);
        V v_t_2443 = heff_take_field(v_p_2415, 1);
        V v_t_2446;
        switch (heff_tag_of(v_t_2443)) {
        case TAG_Nothing: {
          V v_t_2444 = heff_tag_at_n(v_ru_24x2_2440_24MkPair, TAG_Cons, 2, (V[]){v_x_2434, NTAG(TAG_Nil)});
          v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2432, v_t_2444});
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2443, 0ULL, 1);
          heff_drop(v_x_2434);
          v_t_2446 = heff_tag_at_n(v_ru_24x2_2440_24MkPair, TAG_Cons, 2, (V[]){v_x_2432, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_t_2443);
        }
        V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2431, v_t_2446));
        V v_body_2448 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2447, v_x_2441});
        V v_t_2449 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 1)), ((V)&g_heff_2ecompile_2etrmc_2edestined_str3));
        V v_x_2450 = heff_rec_n(3, shape_key__name__body, (V[]){heff_get_n(v_p_2415, 0, 2), v_t_2449, v_body_2448});
        V v_t_2451 = ({ V rv_2 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_242, v_x_2419}); V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2450, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, v_t_2452}), v_n_2442});
      }
      default: return heff_nomatch(v_x2_2440);
      }
    }
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str0, 4, "$acc");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str1, 4, "acc$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str2, 4, "$acc");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str3, 4, "$acc");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str4, 4, "$acc");
V g_heff_2ecompile_2etrmc_2egathered_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2egathered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2egathered_entry, 4, 0};

V g_heff_2ecompile_2etrmc_2egathered(V v_s_240, V v_d_241, V v_xs_242, V v_b_243) {
top: ;
  V v_t_244 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2ecompile_2etrmc_2egathered_str0));
  V v_m_245 = (g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841(heff_dup(v_s_240), v_t_244, heff_dup(v_b_243)));
  return heff_clo_n(g_heff_2ecompile_2etrmc_2egathered_lam0, 1, 5, (V[]){v_m_245, v_xs_242, v_b_243, v_d_241, v_s_240});
}
V g_heff_2ecompile_2etrmc_2egathered_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2egathered(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2etrmc_2egathered_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  V v_b_243 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_s_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = heff_rec_n(3, shape_m__n__xs, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), v_n_249, NTAG(TAG_Nil)});
    V v_v_2411 = (g_list_2efoldl_24s690313412x1307839513(v_t_2410, heff_dup(v_xs_242)));
    V v_m_2412 = heff_take_field(v_v_2411, 0);
    V v_n_2413 = heff_take_field(v_v_2411, 1);
    V v_xs_2414 = heff_get_n(v_v_2411, 2, 3);
    HeffT2 v_t_2415 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2412, v_n_2413, v_b_243));
    {
      V v_field_2416 = v_t_2415.f[0];
      V v_field_2417 = v_t_2415.f[1];
      V v_b_27_2418 = v_field_2416;
      V v_n_27_2419 = v_field_2417;
      V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2414));
      V v_x_2421 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2egathered_str1), heff_intShow(heff_dup(v_n_27_2419)));
      V v_t_2422 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2ecompile_2etrmc_2egathered_str2));
      V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2ecompile_2etrmc_2egather_clo), 3, (V[]){v_s_240, v_t_2422, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2421)})}));
      V v_m_2424 = heff_tr(g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267(v_t_2423, v_b_27_2418));
      V v_x2_2425 = heff_tr(heff_call(v_m_2424, 1, (V[]){heff_intAdd(v_n_27_2419, MK_INT(1LL))}));
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_MkPair: {
        V v_x_2426 = heff_field(v_x2_2425, 0);
        V v_n_2427 = heff_field(v_x2_2425, 1);
        V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
        V v_t_2428 = heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_Cons, 2, (V[]){v_x_2421, NTAG(TAG_Nil)});
        V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2428));
        V v_body_2430 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2429, v_x_2426});
        V v_t_2431 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2ecompile_2etrmc_2egathered_str3));
        V v_t_2432 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 1)), ((V)&g_heff_2ecompile_2etrmc_2egathered_str4));
        V v_x_2433 = heff_rec_n(3, shape_key__name__body, (V[]){v_t_2431, v_t_2432, v_body_2430});
        V v_t_2434 = ({ V rv_2 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_242, v_x_248}); V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2433, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_t_2435}), v_n_2427});
      }
      default: return heff_nomatch(v_x2_2425);
      }
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}