// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FtAny 18156
#define TAG_MkArm 55352
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_m 327
#define LBL_n 328
#define LBL_name 9869138
#define LBL_xs 10594
static uint32_t shape_key__arity[] = {LBL_key, LBL_arity};
static uint32_t shape_key__at[] = {LBL_key, LBL_at};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_m__n__xs[] = {LBL_m, LBL_n, LBL_xs};
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2etrmc_2eanyTail(V, V);
V g_heff_2ecompile_2etrmc_2eanyTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eanyTail_clo;
V g_heff_2ecompile_2etrmc_2eappendEnds(V, V);
V g_heff_2ecompile_2etrmc_2eappendEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eappendEnds_clo;
V g_heff_2ecompile_2etrmc_2eatTails(V, V);
V g_heff_2ecompile_2etrmc_2eatTails_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eatTails_clo;
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700(V, V, V);
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_clo;
V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306(V, V, V);
V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_clo;
V g_heff_2ecompile_2etrmc_2econsEnds(V, V);
V g_heff_2ecompile_2etrmc_2econsEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2econsEnds_clo;
V g_heff_2ecompile_2etrmc_2edefT(V);
V g_heff_2ecompile_2etrmc_2edefT_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2edefT_clo;
V g_heff_2ecompile_2etrmc_2edestined(V, V, V, V);
V g_heff_2ecompile_2etrmc_2edestined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2edestined_clo;
V g_heff_2ecompile_2etrmc_2efill(V, V, V, V, V);
V g_heff_2ecompile_2etrmc_2efill_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2efill_clo;
V g_heff_2ecompile_2etrmc_2egather(V, V, V, V);
V g_heff_2ecompile_2etrmc_2egather_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2egather_clo;
V g_heff_2ecompile_2etrmc_2egathered(V, V, V, V);
V g_heff_2ecompile_2etrmc_2egathered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2egathered_clo;
V g_heff_2ecompile_2etrmc_2ehole_get(void);
V g_heff_2ecompile_2etrmc_2eholesAt(V, V);
V g_heff_2ecompile_2etrmc_2eholesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eholesAt_clo;
HeffT2 g_heff_2ecompile_2etrmc_2elastOf_24cpr(V);
V g_heff_2ecompile_2etrmc_2eselfCall(V, V);
V g_heff_2ecompile_2etrmc_2eselfCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eselfCall_clo;
V g_heff_2ecompile_2etrmc_2esetFieldPrim_get(void);
V g_heff_2ecompile_2etrmc_2estartAcc(V, V, V);
V g_heff_2ecompile_2etrmc_2estartAcc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2estartAcc_clo;
V g_heff_2ecompile_2etrmc_2estartCell(V, V, V);
V g_heff_2ecompile_2etrmc_2estartCell_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2estartCell_clo;
V g_list_2eall_24s262401054x194288545(V, V);
V g_list_2eall_24s262401054x194288545_entry(V self, V *a);
extern Clo g_list_2eall_24s262401054x194288545_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636(V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s1019364152x1582657694(V, V);
V g_prelude_2etraverse_24s1019364152x1582657694_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1019364152x1582657694_clo;
V g_std_2emap_2eempty_get(void);
HEFF_LIT(g_heff_2ecompile_2etrmc_2esetFieldPrim_str0, 8, "setField");

static V g_heff_2ecompile_2etrmc_2esetFieldPrim_val;
static HEFF_ONCE g_heff_2ecompile_2etrmc_2esetFieldPrim_st;
static V g_heff_2ecompile_2etrmc_2esetFieldPrim_init(void) {
  return ((V)&g_heff_2ecompile_2etrmc_2esetFieldPrim_str0);
}
V g_heff_2ecompile_2etrmc_2esetFieldPrim_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2etrmc_2esetFieldPrim_st)) return g_heff_2ecompile_2etrmc_2esetFieldPrim_val;
  return heff_global(&g_heff_2ecompile_2etrmc_2esetFieldPrim_val, &g_heff_2ecompile_2etrmc_2esetFieldPrim_st, g_heff_2ecompile_2etrmc_2esetFieldPrim_init);
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2ehole_str0, 4, "hole");

static V g_heff_2ecompile_2etrmc_2ehole_val;
static HEFF_ONCE g_heff_2ecompile_2etrmc_2ehole_st;
static V g_heff_2ecompile_2etrmc_2ehole_init(void) {
  return heff_tag_n(TAG_EPrimCall, 2, (V[]){((V)&g_heff_2ecompile_2etrmc_2ehole_str0), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2etrmc_2ehole_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2etrmc_2ehole_st)) return g_heff_2ecompile_2etrmc_2ehole_val;
  return heff_global(&g_heff_2ecompile_2etrmc_2ehole_val, &g_heff_2ecompile_2etrmc_2ehole_st, g_heff_2ecompile_2etrmc_2ehole_init);
}

HeffT2 g_heff_2ecompile_2etrmc_2elastOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_241}});
    }
    case TAG_Cons: {
      heff_drop(v_x_241);
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2etrmc_2eselfCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eselfCall_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eselfCall(V v_s_240, V v_x2_241) {
top: ;
  V v_key_242 = heff_take_field(v_s_240, 0);
  V v_arity_243 = heff_get_n(v_s_240, 1, 2);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    V v_g_2427 = heff_field(v_x2_241, 0);
    V v_args_2428 = heff_field(v_x2_241, 1);
    V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_g_2427, v_key_242, 0) && ({ V v_t_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2428)); int c_ = heff_intEq_c_lent(v_t_2443, v_arity_243, 0); heff_drop(v_t_2443); c_; })));
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return v_ret_24bool;
  }
  case TAG_EInt: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2eselfCall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2etrmc_2eselfCall(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2etrmc_2econsEnds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2econsEnds_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2econsEnds(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_args_2418 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    HeffT2 v_t_2420 = (g_heff_2ecompile_2etrmc_2elastOf_24cpr(v_args_2418));
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_l_2423 = v_field_2422;
        V v_t_2424 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_l_2423));
        if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
          heff_drop(v_s_240);
          heff_drop(v_l_2423);
          heff_drop(v_t_2424);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2424);
          V t_0 = v_s_240;
          V t_1 = v_l_2423;
          v_s_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      } else {
        heff_drop(v_s_240);
        heff_drop(v_field_2422);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2econsEnds_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2econsEnds(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2eappendEnds_str0, 9, "strAppend");
Clo g_heff_2ecompile_2etrmc_2eappendEnds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eappendEnds_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eappendEnds(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2423 = heff_field(v_x2_241, 0);
    V v_x22_2424 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_2424)) {
    case TAG_Nil: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x222_2426 = heff_field(v_x22_2424, 1);
      switch (heff_tag_of(v_x222_2426)) {
      case TAG_Nil: {
        heff_drop(v_s_240);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_r_2427 = heff_field(v_x222_2426, 0);
        V v_x2222_2428 = heff_field(v_x222_2426, 1);
        switch (heff_tag_of(v_x2222_2428)) {
        case TAG_Nil: {
          if (heff_strEq_c_lent(v_p_2423, ((V)&g_heff_2ecompile_2etrmc_2eappendEnds_str0), 2)) {
            V v_t_2429 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_r_2427));
            if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
              heff_drop(v_s_240);
              heff_drop(v_t_2429);
              return NTAG(TAG_True);
            } else {
              heff_drop(v_t_2429);
              V t_0 = v_s_240;
              V t_1 = v_r_2427;
              v_s_240 = t_0;
              v_x2_241 = t_1;
              goto top;
            }
          } else {
            heff_drop(v_s_240);
            return NTAG(TAG_False);
          }
        }
        case TAG_Cons: {
          heff_drop(v_s_240);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x2222_2428);
        }
      }
      default: return heff_nomatch(v_x222_2426);
      }
    }
    default: return heff_nomatch(v_x22_2424);
    }
  }
  case TAG_ECall: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2eappendEnds_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2etrmc_2eappendEnds(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2etrmc_2eanyTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eanyTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eanyTail_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eanyTail(V v_p_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EApp: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 4ULL, 3);
    V t_0 = v_p_240;
    V t_1 = v_b_2410;
    v_p_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EProj: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_ETag: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EMatch: {
    V v_arms_2421 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2etrmc_2eanyTail_lam0, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2421; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2421); r_; });
  }
  case TAG_EPrim: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_ECall: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EBool: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_ESet: {
    V v_b_2442 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 4ULL, 3);
    V t_0 = v_p_240;
    V t_1 = v_b_2442;
    v_p_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_EValues: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2etrmc_2eanyTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eanyTail(a[0], a[1]);
}
V g_heff_2ecompile_2etrmc_2eanyTail_lam0(V self, V *args) {
  V v_a_2422 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426;
  switch (heff_tag_of(v_a_2422)) {
  case TAG_MkArm: {
    V v_b_2425 = heff_field(v_a_2422, 2);
    heff_take_n(v_a_2422, 4ULL, 3);
    v_t_2426 = v_b_2425;
    break;
  }
  default: heff_nomatch(v_a_2422);
  }
  return (g_heff_2ecompile_2etrmc_2eanyTail(v_p_240, v_t_2426));
}
V g_heff_2ecompile_2etrmc_2eatTails_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_lam4(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eatTails_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eatTails_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eatTails(V v_f_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EApp: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2411 = heff_tr(g_heff_2ecompile_2etrmc_2eatTails(v_f_240, v_b_2410));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_lam0, 1, 3, (V[]){v_m_2411, v_x_248, v_a_249});
  }
  case TAG_ERecord: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EProj: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ETag: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EMatch: {
    V v_sc_2425 = heff_field(v_e_241, 0);
    V v_arms_2426 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2436 = (g_prelude_2etraverse_24s1019364152x1582657694(heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_lam1, 1, 1, (V[]){v_f_240}), v_arms_2426));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_lam3, 1, 2, (V[]){v_m_2436, v_sc_2425});
  }
  case TAG_EPrim: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ECall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EBool: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ESet: {
    V v_xs_2454 = heff_field(v_e_241, 0);
    V v_a_2455 = heff_field(v_e_241, 1);
    V v_b_2456 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2457 = heff_tr(g_heff_2ecompile_2etrmc_2eatTails(v_f_240, v_b_2456));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_lam4, 1, 3, (V[]){v_m_2457, v_xs_2454, v_a_2455});
  }
  case TAG_EValues: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eatTails(a[0], a[1]);
}
V g_heff_2ecompile_2etrmc_2eatTails_lam0(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_a_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_248, v_a_249, v_x_2414}), v_n_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_lam2(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_t_2428 = heff_env(self)[1];
  V v_vs_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2428, v_vs_2429, v_x_2434}), v_n_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_lam1(V self, V *args) {
  V v_arm_2427 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_arm_2427)) {
  case TAG_MkArm: {
    V v_t_2428 = heff_field(v_arm_2427, 0);
    V v_vs_2429 = heff_field(v_arm_2427, 1);
    V v_b_2430 = heff_field(v_arm_2427, 2);
    heff_take_n(v_arm_2427, 7ULL, 3);
    V v_m_2431 = heff_tr(g_heff_2ecompile_2etrmc_2eatTails(v_f_240, v_b_2430));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_lam2, 1, 3, (V[]){v_m_2431, v_t_2428, v_vs_2429});
  }
  default: return heff_nomatch(v_arm_2427);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_lam3(V self, V *args) {
  V v_n_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  V v_sc_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2438 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_n_2440 = heff_field(v_x2_2438, 1);
    V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2425, v_x_2439}), v_n_2440});
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_lam4(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_xs_2454 = heff_env(self)[1];
  V v_a_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2454, v_a_2455, v_x_2460}), v_n_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2efill_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2efill_str1, 4, "cell");
HEFF_LIT(g_heff_2ecompile_2etrmc_2efill_str2, 1, "$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2efill_str3, 1, "u");
V g_heff_2ecompile_2etrmc_2efill_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam4(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam5(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam6(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam7(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam8(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam9(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam10(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam11(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam12(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam13(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam14(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam15(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam16(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam17(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam18(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam19(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam20(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam21(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam22(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam23(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam24(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam25(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam26(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam27(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam28(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam29(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam30(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam31(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam32(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam33(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam34(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam35(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam36(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam37(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam38(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam39(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam40(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam41(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam42(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam43(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam44(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam45(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam46(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2efill_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2efill_entry, 5, 0};

V g_heff_2ecompile_2etrmc_2efill(V v_s_240, V v_p_241, V v_d_242, V v_i_243, V v_e_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_e_244));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_s_240);
    heff_drop(v_t_245);
    switch (heff_tag_of(v_e_244)) {
    case TAG_EVar: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam0, 1, 1, (V[]){v_e_244});
    }
    case TAG_EGlobal: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam1, 1, 1, (V[]){v_e_244});
    }
    case TAG_ELam: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam2, 1, 1, (V[]){v_e_244});
    }
    case TAG_EApp: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam3, 1, 1, (V[]){v_e_244});
    }
    case TAG_ELet: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam4, 1, 1, (V[]){v_e_244});
    }
    case TAG_ERecord: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam5, 1, 1, (V[]){v_e_244});
    }
    case TAG_EProj: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam6, 1, 1, (V[]){v_e_244});
    }
    case TAG_ETag: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam7, 1, 1, (V[]){v_e_244});
    }
    case TAG_EMatch: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam8, 1, 1, (V[]){v_e_244});
    }
    case TAG_EPrim: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam9, 1, 1, (V[]){v_e_244});
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam10, 1, 1, (V[]){v_e_244});
    }
    case TAG_ECall: {
      V v_args_2441 = heff_field(v_e_244, 1);
      V v_ru_24e_244_24ECall = heff_take_reuse_n(v_e_244, 2ULL, 2);
      V v_t_2442 = heff_take_field(v_p_241, 1);
      V v_t_2445;
      switch (heff_tag_of(v_t_2442)) {
      case TAG_Nothing: {
        V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_i_243, NTAG(TAG_Nil)});
        v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, v_t_2443});
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_2442, 0ULL, 1);
        heff_drop(v_i_243);
        v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_2442);
      }
      V v_t_2446 = (g_prelude_2e_2b_2b(v_args_2441, v_t_2445));
      V v_x_2447 = heff_tag_at_n(v_ru_24e_244_24ECall, TAG_ECall, 2, (V[]){heff_get_n(v_p_241, 0, 2), v_t_2446});
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam11, 1, 1, (V[]){v_x_2447});
    }
    case TAG_EInt: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam12, 1, 1, (V[]){v_e_244});
    }
    case TAG_EFloat: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam13, 1, 1, (V[]){v_e_244});
    }
    case TAG_EStr: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam14, 1, 1, (V[]){v_e_244});
    }
    case TAG_EBytes: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam15, 1, 1, (V[]){v_e_244});
    }
    case TAG_EFixed: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam16, 1, 1, (V[]){v_e_244});
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam17, 1, 1, (V[]){v_e_244});
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam18, 1, 1, (V[]){v_e_244});
    }
    case TAG_EBool: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam19, 1, 1, (V[]){v_e_244});
    }
    case TAG_ESet: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam20, 1, 1, (V[]){v_e_244});
    }
    case TAG_EValues: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam21, 1, 1, (V[]){v_e_244});
    }
    case TAG_EFix: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam22, 1, 1, (V[]){v_e_244});
    }
    default: return heff_nomatch(v_e_244);
    }
  } else {
    heff_drop(v_t_245);
    V v_t_2474 = (g_heff_2ecompile_2etrmc_2econsEnds(heff_dup(v_s_240), heff_dup(v_e_244)));
    if ((heff_dup(v_t_2474) == NTAG(TAG_True))) {
      heff_drop(v_t_2474);
      switch (heff_tag_of(v_e_244)) {
      case TAG_EVar: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam23, 1, 1, (V[]){v_e_244});
      }
      case TAG_EGlobal: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam24, 1, 1, (V[]){v_e_244});
      }
      case TAG_ELam: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam25, 1, 1, (V[]){v_e_244});
      }
      case TAG_EApp: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam26, 1, 1, (V[]){v_e_244});
      }
      case TAG_ELet: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam27, 1, 1, (V[]){v_e_244});
      }
      case TAG_ERecord: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam28, 1, 1, (V[]){v_e_244});
      }
      case TAG_EProj: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam29, 1, 1, (V[]){v_e_244});
      }
      case TAG_ETag: {
        V v_t_2497 = heff_dup(heff_field(v_e_244, 0));
        V v_args_2498 = heff_dup(heff_field(v_e_244, 1));
        V v_ts_2499 = heff_dup(heff_field(v_e_244, 2));
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam30, 1, 8, (V[]){v_args_2498, v_e_244, v_s_240, v_p_241, v_ts_2499, v_d_242, v_i_243, v_t_2497});
      }
      case TAG_EMatch: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam31, 1, 1, (V[]){v_e_244});
      }
      case TAG_EPrim: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam32, 1, 1, (V[]){v_e_244});
      }
      case TAG_EPrimCall: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam33, 1, 1, (V[]){v_e_244});
      }
      case TAG_ECall: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam34, 1, 1, (V[]){v_e_244});
      }
      case TAG_EInt: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam35, 1, 1, (V[]){v_e_244});
      }
      case TAG_EFloat: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam36, 1, 1, (V[]){v_e_244});
      }
      case TAG_EStr: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam37, 1, 1, (V[]){v_e_244});
      }
      case TAG_EBytes: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam38, 1, 1, (V[]){v_e_244});
      }
      case TAG_EFixed: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam39, 1, 1, (V[]){v_e_244});
      }
      case TAG_EFloat32: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam40, 1, 1, (V[]){v_e_244});
      }
      case TAG_EAbandon: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam41, 1, 1, (V[]){v_e_244});
      }
      case TAG_EBool: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam42, 1, 1, (V[]){v_e_244});
      }
      case TAG_ESet: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam43, 1, 1, (V[]){v_e_244});
      }
      case TAG_EValues: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam44, 1, 1, (V[]){v_e_244});
      }
      case TAG_EFix: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam45, 1, 1, (V[]){v_e_244});
      }
      default: return heff_nomatch(v_e_244);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_t_2474);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam46, 1, 3, (V[]){v_e_244, v_d_242, v_i_243});
    }
  }
}
V g_heff_2ecompile_2etrmc_2efill_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2efill(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2etrmc_2efill_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_247});
}
V g_heff_2ecompile_2etrmc_2efill_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_249});
}
V g_heff_2ecompile_2etrmc_2efill_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2412});
}
V g_heff_2ecompile_2etrmc_2efill_lam3(V self, V *args) {
  V v_n_2415 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2415});
}
V g_heff_2ecompile_2etrmc_2efill_lam4(V self, V *args) {
  V v_n_2419 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2419});
}
V g_heff_2ecompile_2etrmc_2efill_lam5(V self, V *args) {
  V v_n_2422 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2422});
}
V g_heff_2ecompile_2etrmc_2efill_lam6(V self, V *args) {
  V v_n_2427 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2427});
}
V g_heff_2ecompile_2etrmc_2efill_lam7(V self, V *args) {
  V v_n_2431 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2431});
}
V g_heff_2ecompile_2etrmc_2efill_lam8(V self, V *args) {
  V v_n_2434 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2434});
}
V g_heff_2ecompile_2etrmc_2efill_lam9(V self, V *args) {
  V v_n_2436 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2436});
}
V g_heff_2ecompile_2etrmc_2efill_lam10(V self, V *args) {
  V v_n_2439 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2439});
}
V g_heff_2ecompile_2etrmc_2efill_lam11(V self, V *args) {
  V v_n_2448 = args[0];
  V v_x_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2447, v_n_2448});
}
V g_heff_2ecompile_2etrmc_2efill_lam12(V self, V *args) {
  V v_n_2450 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2450});
}
V g_heff_2ecompile_2etrmc_2efill_lam13(V self, V *args) {
  V v_n_2452 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2452});
}
V g_heff_2ecompile_2etrmc_2efill_lam14(V self, V *args) {
  V v_n_2454 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2454});
}
V g_heff_2ecompile_2etrmc_2efill_lam15(V self, V *args) {
  V v_n_2456 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2456});
}
V g_heff_2ecompile_2etrmc_2efill_lam16(V self, V *args) {
  V v_n_2459 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2459});
}
V g_heff_2ecompile_2etrmc_2efill_lam17(V self, V *args) {
  V v_n_2461 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2461});
}
V g_heff_2ecompile_2etrmc_2efill_lam18(V self, V *args) {
  V v_n_2462 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2462});
}
V g_heff_2ecompile_2etrmc_2efill_lam19(V self, V *args) {
  V v_n_2464 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2464});
}
V g_heff_2ecompile_2etrmc_2efill_lam20(V self, V *args) {
  V v_n_2468 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2468});
}
V g_heff_2ecompile_2etrmc_2efill_lam21(V self, V *args) {
  V v_n_2470 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2470});
}
V g_heff_2ecompile_2etrmc_2efill_lam22(V self, V *args) {
  V v_n_2473 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2473});
}
V g_heff_2ecompile_2etrmc_2efill_lam23(V self, V *args) {
  V v_n_2476 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2476});
}
V g_heff_2ecompile_2etrmc_2efill_lam24(V self, V *args) {
  V v_n_2478 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2478});
}
V g_heff_2ecompile_2etrmc_2efill_lam25(V self, V *args) {
  V v_n_2481 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2481});
}
V g_heff_2ecompile_2etrmc_2efill_lam26(V self, V *args) {
  V v_n_2484 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2484});
}
V g_heff_2ecompile_2etrmc_2efill_lam27(V self, V *args) {
  V v_n_2488 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2488});
}
V g_heff_2ecompile_2etrmc_2efill_lam28(V self, V *args) {
  V v_n_2491 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2491});
}
V g_heff_2ecompile_2etrmc_2efill_lam29(V self, V *args) {
  V v_n_2496 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2496});
}
V g_heff_2ecompile_2etrmc_2efill_lam30(V self, V *args) {
  V v_n_24100 = args[0];
  V v_args_2498 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_s_240 = heff_env(self)[2];
  V v_p_241 = heff_env(self)[3];
  V v_ts_2499 = heff_env(self)[4];
  V v_d_242 = heff_env(self)[5];
  V v_i_243 = heff_env(self)[6];
  V v_t_2497 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_24101 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2efill_str0), heff_intShow(heff_dup(v_n_24100)));
  V v_x_24102 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2efill_str1), v_t_24101);
  V v_n_24103 = heff_intAdd(v_n_24100, MK_INT(1LL));
  V v_t_24104 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2498));
  V v_t_24105 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_t_24104, MK_INT(1LL))});
  HeffT2 v_t_24106 = (g_heff_2ecompile_2etrmc_2elastOf_24cpr(heff_dup(v_args_2498)));
  V v_t_24110;
  {
    V v_field_24108 = v_t_24106.f[1];
    int64_t v_tag_24107 = ((int64_t)v_t_24106.f[0]);
    if ((v_tag_24107 == ((int64_t)0ULL))) {
      heff_drop_tag(v_e_244, 3);
      V v_x_24109 = v_field_24108;
      v_t_24110 = v_x_24109;
    } else {
      heff_drop(v_field_24108);
      v_t_24110 = v_e_244;
    }
  }
  V v_m_24111 = (g_heff_2ecompile_2etrmc_2efill(v_s_240, v_p_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24102)}), v_t_24105, v_t_24110));
  V v_x2_24112 = heff_tr(heff_call(v_m_24111, 1, (V[]){heff_intAdd(heff_dup(v_n_24103), MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24112)) {
  case TAG_MkPair: {
    V v_x_24113 = heff_field(v_x2_24112, 0);
    V v_n_24114 = heff_field(v_x2_24112, 1);
    V v_ru_24x2_24112_24MkPair = heff_take_reuse_n(v_x2_24112, 3ULL, 2);
    V v_t_24115 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2ehole_get()), NTAG(TAG_Nil)});
    V v_t_24116 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_24115, v_args_2498));
    V v_t_24117 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), NTAG(TAG_Nil)});
    V v_t_24118 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_24117, v_ts_2499));
    V v_t_24119 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2efill_str2), heff_intShow(v_n_24103));
    V v_t_24120 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24102)}), NTAG(TAG_Nil)});
    V v_t_24121 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, heff_tag_n(TAG_Cons, 2, (V[]){v_i_243, v_t_24120})});
    V v_t_24122 = heff_tag_n(TAG_ELet, 3, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2efill_str3), v_t_24119), heff_tag_n(TAG_EPrimCall, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2esetFieldPrim_get()), v_t_24121}), v_x_24113});
    V v_x_24123 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_24102, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2497, v_t_24116, v_t_24118}), v_t_24122});
    return heff_tag_at_n(v_ru_24x2_24112_24MkPair, TAG_MkPair, 2, (V[]){v_x_24123, v_n_24114});
  }
  default: return heff_nomatch(v_x2_24112);
  }
}
V g_heff_2ecompile_2etrmc_2efill_lam31(V self, V *args) {
  V v_n_24126 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24126});
}
V g_heff_2ecompile_2etrmc_2efill_lam32(V self, V *args) {
  V v_n_24128 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24128});
}
V g_heff_2ecompile_2etrmc_2efill_lam33(V self, V *args) {
  V v_n_24131 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24131});
}
V g_heff_2ecompile_2etrmc_2efill_lam34(V self, V *args) {
  V v_n_24134 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24134});
}
V g_heff_2ecompile_2etrmc_2efill_lam35(V self, V *args) {
  V v_n_24136 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24136});
}
V g_heff_2ecompile_2etrmc_2efill_lam36(V self, V *args) {
  V v_n_24138 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24138});
}
V g_heff_2ecompile_2etrmc_2efill_lam37(V self, V *args) {
  V v_n_24140 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24140});
}
V g_heff_2ecompile_2etrmc_2efill_lam38(V self, V *args) {
  V v_n_24142 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24142});
}
V g_heff_2ecompile_2etrmc_2efill_lam39(V self, V *args) {
  V v_n_24145 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24145});
}
V g_heff_2ecompile_2etrmc_2efill_lam40(V self, V *args) {
  V v_n_24147 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24147});
}
V g_heff_2ecompile_2etrmc_2efill_lam41(V self, V *args) {
  V v_n_24148 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24148});
}
V g_heff_2ecompile_2etrmc_2efill_lam42(V self, V *args) {
  V v_n_24150 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24150});
}
V g_heff_2ecompile_2etrmc_2efill_lam43(V self, V *args) {
  V v_n_24154 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24154});
}
V g_heff_2ecompile_2etrmc_2efill_lam44(V self, V *args) {
  V v_n_24156 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24156});
}
V g_heff_2ecompile_2etrmc_2efill_lam45(V self, V *args) {
  V v_n_24159 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_24159});
}
V g_heff_2ecompile_2etrmc_2efill_lam46(V self, V *args) {
  V v_n_24160 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_i_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24161 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
  V v_t_24162 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, heff_tag_n(TAG_Cons, 2, (V[]){v_i_243, v_t_24161})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2esetFieldPrim_get()), v_t_24162}), v_n_24160});
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartCell_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartCell_str1, 4, "cell");
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartCell_str2, 1, "$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartCell_str3, 1, "u");
V g_heff_2ecompile_2etrmc_2estartCell_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam4(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam5(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam6(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam7(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam8(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam9(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam10(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam11(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam12(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam13(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam14(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam15(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam16(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam17(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam18(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam19(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam20(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam21(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam22(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam23(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2estartCell_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2estartCell_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2estartCell(V v_s_240, V v_p_241, V v_e_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2etrmc_2econsEnds(heff_dup(v_s_240), heff_dup(v_e_242)));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    switch (heff_tag_of(v_e_242)) {
    case TAG_EVar: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam0, 1, 1, (V[]){v_e_242});
    }
    case TAG_EGlobal: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam1, 1, 1, (V[]){v_e_242});
    }
    case TAG_ELam: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam2, 1, 1, (V[]){v_e_242});
    }
    case TAG_EApp: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam3, 1, 1, (V[]){v_e_242});
    }
    case TAG_ELet: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam4, 1, 1, (V[]){v_e_242});
    }
    case TAG_ERecord: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam5, 1, 1, (V[]){v_e_242});
    }
    case TAG_EProj: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam6, 1, 1, (V[]){v_e_242});
    }
    case TAG_ETag: {
      V v_t_2426 = heff_dup(heff_field(v_e_242, 0));
      V v_args_2427 = heff_dup(heff_field(v_e_242, 1));
      V v_ts_2428 = heff_dup(heff_field(v_e_242, 2));
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam7, 1, 6, (V[]){v_args_2427, v_e_242, v_s_240, v_p_241, v_ts_2428, v_t_2426});
    }
    case TAG_EMatch: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam8, 1, 1, (V[]){v_e_242});
    }
    case TAG_EPrim: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam9, 1, 1, (V[]){v_e_242});
    }
    case TAG_EPrimCall: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam10, 1, 1, (V[]){v_e_242});
    }
    case TAG_ECall: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam11, 1, 1, (V[]){v_e_242});
    }
    case TAG_EInt: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam12, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFloat: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam13, 1, 1, (V[]){v_e_242});
    }
    case TAG_EStr: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam14, 1, 1, (V[]){v_e_242});
    }
    case TAG_EBytes: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam15, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFixed: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam16, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFloat32: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam17, 1, 1, (V[]){v_e_242});
    }
    case TAG_EAbandon: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam18, 1, 1, (V[]){v_e_242});
    }
    case TAG_EBool: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam19, 1, 1, (V[]){v_e_242});
    }
    case TAG_ESet: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam20, 1, 1, (V[]){v_e_242});
    }
    case TAG_EValues: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam21, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFix: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam22, 1, 1, (V[]){v_e_242});
    }
    default: return heff_nomatch(v_e_242);
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_p_241);
    heff_drop(v_t_243);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam23, 1, 1, (V[]){v_e_242});
  }
}
V g_heff_2ecompile_2etrmc_2estartCell_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2estartCell(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2etrmc_2estartCell_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_245});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_247});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam2(V self, V *args) {
  V v_n_2410 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2410});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam3(V self, V *args) {
  V v_n_2413 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2413});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam4(V self, V *args) {
  V v_n_2417 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2417});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam5(V self, V *args) {
  V v_n_2420 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2420});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam6(V self, V *args) {
  V v_n_2425 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2425});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam7(V self, V *args) {
  V v_n_2429 = args[0];
  V v_args_2427 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_s_240 = heff_env(self)[2];
  V v_p_241 = heff_env(self)[3];
  V v_ts_2428 = heff_env(self)[4];
  V v_t_2426 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartCell_str0), heff_intShow(heff_dup(v_n_2429)));
  V v_x_2431 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartCell_str1), v_t_2430);
  V v_n_2432 = heff_intAdd(v_n_2429, MK_INT(1LL));
  V v_t_2433 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2427));
  V v_t_2434 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_t_2433, MK_INT(1LL))});
  HeffT2 v_t_2435 = (g_heff_2ecompile_2etrmc_2elastOf_24cpr(heff_dup(v_args_2427)));
  V v_t_2439;
  {
    V v_field_2437 = v_t_2435.f[1];
    int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
    if ((v_tag_2436 == ((int64_t)0ULL))) {
      heff_drop_tag(v_e_242, 3);
      V v_x_2438 = v_field_2437;
      v_t_2439 = v_x_2438;
    } else {
      heff_drop(v_field_2437);
      v_t_2439 = v_e_242;
    }
  }
  V v_m_2440 = (g_heff_2ecompile_2etrmc_2efill(v_s_240, v_p_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2431)}), v_t_2434, v_t_2439));
  V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){heff_intAdd(heff_dup(v_n_2432), MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_n_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2ehole_get()), NTAG(TAG_Nil)});
    V v_t_2445 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2444, v_args_2427));
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), NTAG(TAG_Nil)});
    V v_t_2447 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2446, v_ts_2428));
    V v_t_2448 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartCell_str2), heff_intShow(v_n_2432));
    V v_t_2449 = heff_tag_n(TAG_ELet, 3, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartCell_str3), v_t_2448), v_x_2442, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2431)})});
    V v_x_2450 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_2431, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2426, v_t_2445, v_t_2447}), v_t_2449});
    return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){v_x_2450, v_n_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2etrmc_2estartCell_lam8(V self, V *args) {
  V v_n_2453 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2453});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam9(V self, V *args) {
  V v_n_2455 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2455});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam10(V self, V *args) {
  V v_n_2458 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2458});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam11(V self, V *args) {
  V v_n_2461 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2461});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam12(V self, V *args) {
  V v_n_2463 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2463});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam13(V self, V *args) {
  V v_n_2465 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2465});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam14(V self, V *args) {
  V v_n_2467 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2467});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam15(V self, V *args) {
  V v_n_2469 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2469});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam16(V self, V *args) {
  V v_n_2472 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2472});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam17(V self, V *args) {
  V v_n_2474 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2474});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam18(V self, V *args) {
  V v_n_2475 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2475});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam19(V self, V *args) {
  V v_n_2477 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2477});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam20(V self, V *args) {
  V v_n_2481 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2481});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam21(V self, V *args) {
  V v_n_2483 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2483});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam22(V self, V *args) {
  V v_n_2486 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2486});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam23(V self, V *args) {
  V v_n_2487 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2487});
}
V g_heff_2ecompile_2etrmc_2eholesAt_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eholesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eholesAt_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eholesAt(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_b_2410 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 4ULL, 3);
    V t_0 = v_s_240;
    V t_1 = v_b_2410;
    v_s_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    V v_args_2418 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    HeffT2 v_t_2420 = (g_heff_2ecompile_2etrmc_2elastOf_24cpr(heff_dup(v_args_2418)));
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_l_2423 = v_field_2422;
        V v_t_2424 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_l_2423));
        if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
          heff_drop(v_s_240);
          heff_drop(v_l_2423);
          heff_drop(v_t_2424);
          V v_t_2425 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2418; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2418); r_; });
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_intSub(v_t_2425, MK_INT(1LL)), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_args_2418);
          heff_drop(v_t_2424);
          V v_t_2426 = (g_heff_2ecompile_2etrmc_2econsEnds(heff_dup(v_s_240), heff_dup(v_l_2423)));
          if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
            heff_drop(v_t_2426);
            V t_0 = v_s_240;
            V t_1 = v_l_2423;
            v_s_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          } else {
            heff_drop(v_s_240);
            heff_drop(v_l_2423);
            heff_drop(v_t_2426);
            return NTAG(TAG_Nil);
          }
        }
      } else {
        heff_drop(v_s_240);
        heff_drop(v_args_2418);
        heff_drop(v_field_2422);
        return NTAG(TAG_Nil);
      }
    }
  }
  case TAG_EMatch: {
    V v_arms_2428 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2428));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2etrmc_2eholesAt_lam0, 2, 1, (V[]){v_s_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2429; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2429); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ESet: {
    V v_b_2452 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 4ULL, 3);
    V t_0 = v_s_240;
    V t_1 = v_b_2452;
    v_s_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2eholesAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eholesAt(a[0], a[1]);
}
V g_heff_2ecompile_2etrmc_2eholesAt_lam0(V self, V *args) {
  V v_acc_2430 = args[0];
  V v_x_2431 = args[1];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435;
  switch (heff_tag_of(v_x_2431)) {
  case TAG_MkArm: {
    V v_b_2434 = heff_field(v_x_2431, 2);
    heff_take_n(v_x_2431, 4ULL, 3);
    v_t_2435 = v_b_2434;
    break;
  }
  default: heff_nomatch(v_x_2431);
  }
  V v_t_2436 = (g_heff_2ecompile_2etrmc_2eholesAt(v_s_240, v_t_2435));
  return (g_prelude_2e_2b_2b(v_t_2436, v_acc_2430));
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2egather_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egather_str1, 1, "s");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egather_str2, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egather_str3, 9, "strAppend");
V g_heff_2ecompile_2etrmc_2egather_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam4(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam5(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam6(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam7(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam8(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam9(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam10(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam11(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam12(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam13(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam14(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam15(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam16(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam17(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam18(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam19(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam20(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam21(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam22(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam23(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam24(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam25(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam26(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam27(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam28(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam29(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam30(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam31(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam32(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam33(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam34(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam35(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam36(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam37(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam38(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam39(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam40(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam41(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam42(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam43(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam44(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam45(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam46(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam47(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam48(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam49(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2egather_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2egather_entry, 4, 0};

V g_heff_2ecompile_2etrmc_2egather(V v_s_240, V v_ak_241, V v_acc_242, V v_e_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_e_243));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_s_240);
    heff_drop(v_t_244);
    switch (heff_tag_of(v_e_243)) {
    case TAG_EVar: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam0, 1, 1, (V[]){v_e_243});
    }
    case TAG_EGlobal: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam1, 1, 1, (V[]){v_e_243});
    }
    case TAG_ELam: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam2, 1, 1, (V[]){v_e_243});
    }
    case TAG_EApp: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam3, 1, 1, (V[]){v_e_243});
    }
    case TAG_ELet: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam4, 1, 1, (V[]){v_e_243});
    }
    case TAG_ERecord: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam5, 1, 1, (V[]){v_e_243});
    }
    case TAG_EProj: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam6, 1, 1, (V[]){v_e_243});
    }
    case TAG_ETag: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam7, 1, 1, (V[]){v_e_243});
    }
    case TAG_EMatch: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam8, 1, 1, (V[]){v_e_243});
    }
    case TAG_EPrim: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam9, 1, 1, (V[]){v_e_243});
    }
    case TAG_EPrimCall: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam10, 1, 1, (V[]){v_e_243});
    }
    case TAG_ECall: {
      V v_args_2440 = heff_field(v_e_243, 1);
      V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 2ULL, 2);
      V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_acc_242, NTAG(TAG_Nil)});
      V v_t_2442 = (g_prelude_2e_2b_2b(v_args_2440, v_t_2441));
      V v_x_2443 = heff_tag_at_n(v_ru_24e_243_24ECall, TAG_ECall, 2, (V[]){v_ak_241, v_t_2442});
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam11, 1, 1, (V[]){v_x_2443});
    }
    case TAG_EInt: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam12, 1, 1, (V[]){v_e_243});
    }
    case TAG_EFloat: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam13, 1, 1, (V[]){v_e_243});
    }
    case TAG_EStr: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam14, 1, 1, (V[]){v_e_243});
    }
    case TAG_EBytes: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam15, 1, 1, (V[]){v_e_243});
    }
    case TAG_EFixed: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam16, 1, 1, (V[]){v_e_243});
    }
    case TAG_EFloat32: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam17, 1, 1, (V[]){v_e_243});
    }
    case TAG_EAbandon: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam18, 1, 1, (V[]){v_e_243});
    }
    case TAG_EBool: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam19, 1, 1, (V[]){v_e_243});
    }
    case TAG_ESet: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam20, 1, 1, (V[]){v_e_243});
    }
    case TAG_EValues: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam21, 1, 1, (V[]){v_e_243});
    }
    case TAG_EFix: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam22, 1, 1, (V[]){v_e_243});
    }
    default: return heff_nomatch(v_e_243);
    }
  } else {
    heff_drop(v_t_244);
    V v_t_2470 = (g_heff_2ecompile_2etrmc_2eappendEnds(heff_dup(v_s_240), v_e_243));
    if ((heff_dup(v_t_2470) == NTAG(TAG_True))) {
      heff_drop(v_t_2470);
      switch (heff_tag_of(v_e_243)) {
      case TAG_EVar: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam23, 1, 1, (V[]){v_e_243});
      }
      case TAG_EGlobal: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam24, 1, 1, (V[]){v_e_243});
      }
      case TAG_ELam: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam25, 1, 1, (V[]){v_e_243});
      }
      case TAG_EApp: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam26, 1, 1, (V[]){v_e_243});
      }
      case TAG_ELet: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam27, 1, 1, (V[]){v_e_243});
      }
      case TAG_ERecord: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam28, 1, 1, (V[]){v_e_243});
      }
      case TAG_EProj: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam29, 1, 1, (V[]){v_e_243});
      }
      case TAG_ETag: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam30, 1, 1, (V[]){v_e_243});
      }
      case TAG_EMatch: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam31, 1, 1, (V[]){v_e_243});
      }
      case TAG_EPrim: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam32, 1, 1, (V[]){v_e_243});
      }
      case TAG_EPrimCall: {
        V v_it2_24103 = heff_dup(heff_field(v_e_243, 1));
        switch (heff_tag_of(v_it2_24103)) {
        case TAG_Nil: {
          heff_drop(v_s_240);
          heff_drop(v_ak_241);
          heff_drop(v_acc_242);
          return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam33, 1, 1, (V[]){v_e_243});
        }
        case TAG_Cons: {
          V v_a_24105 = heff_field(v_it2_24103, 0);
          V v_it22_24106 = heff_field(v_it2_24103, 1);
          heff_take_n(v_it2_24103, 3ULL, 2);
          switch (heff_tag_of(v_it22_24106)) {
          case TAG_Nil: {
            heff_drop(v_s_240);
            heff_drop(v_ak_241);
            heff_drop(v_acc_242);
            heff_drop(v_a_24105);
            return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam34, 1, 1, (V[]){v_e_243});
          }
          case TAG_Cons: {
            V v_r_24108 = heff_field(v_it22_24106, 0);
            V v_it222_24109 = heff_field(v_it22_24106, 1);
            heff_take_n(v_it22_24106, 3ULL, 2);
            switch (heff_tag_of(v_it222_24109)) {
            case TAG_Nil: {
              heff_drop_tag(v_e_243, 2);
              return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam35, 1, 5, (V[]){v_s_240, v_ak_241, v_r_24108, v_a_24105, v_acc_242});
            }
            case TAG_Cons: {
              heff_take_n(v_it222_24109, 0ULL, 2);
              heff_drop(v_s_240);
              heff_drop(v_ak_241);
              heff_drop(v_acc_242);
              heff_drop(v_a_24105);
              heff_drop(v_r_24108);
              return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam36, 1, 1, (V[]){v_e_243});
            }
            default: return heff_nomatch(v_it222_24109);
            }
          }
          default: return heff_nomatch(v_it22_24106);
          }
        }
        default: return heff_nomatch(v_it2_24103);
        }
      }
      case TAG_ECall: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam37, 1, 1, (V[]){v_e_243});
      }
      case TAG_EInt: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam38, 1, 1, (V[]){v_e_243});
      }
      case TAG_EFloat: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam39, 1, 1, (V[]){v_e_243});
      }
      case TAG_EStr: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam40, 1, 1, (V[]){v_e_243});
      }
      case TAG_EBytes: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam41, 1, 1, (V[]){v_e_243});
      }
      case TAG_EFixed: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam42, 1, 1, (V[]){v_e_243});
      }
      case TAG_EFloat32: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam43, 1, 1, (V[]){v_e_243});
      }
      case TAG_EAbandon: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam44, 1, 1, (V[]){v_e_243});
      }
      case TAG_EBool: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam45, 1, 1, (V[]){v_e_243});
      }
      case TAG_ESet: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam46, 1, 1, (V[]){v_e_243});
      }
      case TAG_EValues: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam47, 1, 1, (V[]){v_e_243});
      }
      case TAG_EFix: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam48, 1, 1, (V[]){v_e_243});
      }
      default: return heff_nomatch(v_e_243);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      heff_drop(v_t_2470);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam49, 1, 2, (V[]){v_e_243, v_acc_242});
    }
  }
}
V g_heff_2ecompile_2etrmc_2egather_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2egather(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2etrmc_2egather_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_246});
}
V g_heff_2ecompile_2etrmc_2egather_lam1(V self, V *args) {
  V v_n_248 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_248});
}
V g_heff_2ecompile_2etrmc_2egather_lam2(V self, V *args) {
  V v_n_2411 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2411});
}
V g_heff_2ecompile_2etrmc_2egather_lam3(V self, V *args) {
  V v_n_2414 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2414});
}
V g_heff_2ecompile_2etrmc_2egather_lam4(V self, V *args) {
  V v_n_2418 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2418});
}
V g_heff_2ecompile_2etrmc_2egather_lam5(V self, V *args) {
  V v_n_2421 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2421});
}
V g_heff_2ecompile_2etrmc_2egather_lam6(V self, V *args) {
  V v_n_2426 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2426});
}
V g_heff_2ecompile_2etrmc_2egather_lam7(V self, V *args) {
  V v_n_2430 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2430});
}
V g_heff_2ecompile_2etrmc_2egather_lam8(V self, V *args) {
  V v_n_2433 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2433});
}
V g_heff_2ecompile_2etrmc_2egather_lam9(V self, V *args) {
  V v_n_2435 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2435});
}
V g_heff_2ecompile_2etrmc_2egather_lam10(V self, V *args) {
  V v_n_2438 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2438});
}
V g_heff_2ecompile_2etrmc_2egather_lam11(V self, V *args) {
  V v_n_2444 = args[0];
  V v_x_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2443, v_n_2444});
}
V g_heff_2ecompile_2etrmc_2egather_lam12(V self, V *args) {
  V v_n_2446 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2446});
}
V g_heff_2ecompile_2etrmc_2egather_lam13(V self, V *args) {
  V v_n_2448 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2448});
}
V g_heff_2ecompile_2etrmc_2egather_lam14(V self, V *args) {
  V v_n_2450 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2450});
}
V g_heff_2ecompile_2etrmc_2egather_lam15(V self, V *args) {
  V v_n_2452 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2452});
}
V g_heff_2ecompile_2etrmc_2egather_lam16(V self, V *args) {
  V v_n_2455 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2455});
}
V g_heff_2ecompile_2etrmc_2egather_lam17(V self, V *args) {
  V v_n_2457 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2457});
}
V g_heff_2ecompile_2etrmc_2egather_lam18(V self, V *args) {
  V v_n_2458 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2458});
}
V g_heff_2ecompile_2etrmc_2egather_lam19(V self, V *args) {
  V v_n_2460 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2460});
}
V g_heff_2ecompile_2etrmc_2egather_lam20(V self, V *args) {
  V v_n_2464 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2464});
}
V g_heff_2ecompile_2etrmc_2egather_lam21(V self, V *args) {
  V v_n_2466 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2466});
}
V g_heff_2ecompile_2etrmc_2egather_lam22(V self, V *args) {
  V v_n_2469 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2469});
}
V g_heff_2ecompile_2etrmc_2egather_lam23(V self, V *args) {
  V v_n_2472 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2472});
}
V g_heff_2ecompile_2etrmc_2egather_lam24(V self, V *args) {
  V v_n_2474 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2474});
}
V g_heff_2ecompile_2etrmc_2egather_lam25(V self, V *args) {
  V v_n_2477 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2477});
}
V g_heff_2ecompile_2etrmc_2egather_lam26(V self, V *args) {
  V v_n_2480 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2480});
}
V g_heff_2ecompile_2etrmc_2egather_lam27(V self, V *args) {
  V v_n_2484 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2484});
}
V g_heff_2ecompile_2etrmc_2egather_lam28(V self, V *args) {
  V v_n_2487 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2487});
}
V g_heff_2ecompile_2etrmc_2egather_lam29(V self, V *args) {
  V v_n_2492 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2492});
}
V g_heff_2ecompile_2etrmc_2egather_lam30(V self, V *args) {
  V v_n_2496 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2496});
}
V g_heff_2ecompile_2etrmc_2egather_lam31(V self, V *args) {
  V v_n_2499 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2499});
}
V g_heff_2ecompile_2etrmc_2egather_lam32(V self, V *args) {
  V v_n_24101 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24101});
}
V g_heff_2ecompile_2etrmc_2egather_lam33(V self, V *args) {
  V v_n_24104 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24104});
}
V g_heff_2ecompile_2etrmc_2egather_lam34(V self, V *args) {
  V v_n_24107 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24107});
}
V g_heff_2ecompile_2etrmc_2egather_lam35(V self, V *args) {
  V v_n_24110 = args[0];
  V v_s_240 = heff_env(self)[0];
  V v_ak_241 = heff_env(self)[1];
  V v_r_24108 = heff_env(self)[2];
  V v_a_24105 = heff_env(self)[3];
  V v_acc_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24111 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2egather_str0), heff_intShow(heff_dup(v_n_24110)));
  V v_x_24112 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2egather_str1), v_t_24111);
  V v_m_24113 = (g_heff_2ecompile_2etrmc_2egather(v_s_240, v_ak_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24112)}), v_r_24108));
  V v_x2_24114 = heff_tr(heff_call(v_m_24113, 1, (V[]){heff_intAdd(v_n_24110, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24114)) {
  case TAG_MkPair: {
    V v_x_24115 = heff_field(v_x2_24114, 0);
    V v_n_24116 = heff_field(v_x2_24114, 1);
    V v_ru_24x2_24114_24MkPair = heff_take_reuse_n(v_x2_24114, 3ULL, 2);
    V v_t_24117 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_24105, NTAG(TAG_Nil)});
    V v_t_24118 = heff_tag_n(TAG_EPrimCall, 2, (V[]){((V)&g_heff_2ecompile_2etrmc_2egather_str2), heff_tag_n(TAG_Cons, 2, (V[]){v_acc_242, v_t_24117})});
    return heff_tag_at_n(v_ru_24x2_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24112, v_t_24118, v_x_24115}), v_n_24116});
  }
  default: return heff_nomatch(v_x2_24114);
  }
}
V g_heff_2ecompile_2etrmc_2egather_lam36(V self, V *args) {
  V v_n_24121 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24121});
}
V g_heff_2ecompile_2etrmc_2egather_lam37(V self, V *args) {
  V v_n_24124 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24124});
}
V g_heff_2ecompile_2etrmc_2egather_lam38(V self, V *args) {
  V v_n_24126 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24126});
}
V g_heff_2ecompile_2etrmc_2egather_lam39(V self, V *args) {
  V v_n_24128 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24128});
}
V g_heff_2ecompile_2etrmc_2egather_lam40(V self, V *args) {
  V v_n_24130 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24130});
}
V g_heff_2ecompile_2etrmc_2egather_lam41(V self, V *args) {
  V v_n_24132 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24132});
}
V g_heff_2ecompile_2etrmc_2egather_lam42(V self, V *args) {
  V v_n_24135 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24135});
}
V g_heff_2ecompile_2etrmc_2egather_lam43(V self, V *args) {
  V v_n_24137 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24137});
}
V g_heff_2ecompile_2etrmc_2egather_lam44(V self, V *args) {
  V v_n_24138 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24138});
}
V g_heff_2ecompile_2etrmc_2egather_lam45(V self, V *args) {
  V v_n_24140 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24140});
}
V g_heff_2ecompile_2etrmc_2egather_lam46(V self, V *args) {
  V v_n_24144 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24144});
}
V g_heff_2ecompile_2etrmc_2egather_lam47(V self, V *args) {
  V v_n_24146 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24146});
}
V g_heff_2ecompile_2etrmc_2egather_lam48(V self, V *args) {
  V v_n_24149 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_24149});
}
V g_heff_2ecompile_2etrmc_2egather_lam49(V self, V *args) {
  V v_n_24150 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24151 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
  V v_t_24152 = heff_tag_n(TAG_EPrimCall, 2, (V[]){((V)&g_heff_2ecompile_2etrmc_2egather_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_acc_242, v_t_24151})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24152, v_n_24150});
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartAcc_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartAcc_str1, 1, "s");
V g_heff_2ecompile_2etrmc_2estartAcc_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam4(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam5(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam6(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam7(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam8(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam9(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam10(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam11(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam12(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam13(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam14(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam15(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam16(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam17(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam18(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam19(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam20(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam21(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam22(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam23(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam24(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam25(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam26(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2estartAcc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2estartAcc_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2estartAcc(V v_s_240, V v_ak_241, V v_e_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2etrmc_2eappendEnds(heff_dup(v_s_240), v_e_242));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    switch (heff_tag_of(v_e_242)) {
    case TAG_EVar: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam0, 1, 1, (V[]){v_e_242});
    }
    case TAG_EGlobal: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam1, 1, 1, (V[]){v_e_242});
    }
    case TAG_ELam: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam2, 1, 1, (V[]){v_e_242});
    }
    case TAG_EApp: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam3, 1, 1, (V[]){v_e_242});
    }
    case TAG_ELet: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam4, 1, 1, (V[]){v_e_242});
    }
    case TAG_ERecord: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam5, 1, 1, (V[]){v_e_242});
    }
    case TAG_EProj: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam6, 1, 1, (V[]){v_e_242});
    }
    case TAG_ETag: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam7, 1, 1, (V[]){v_e_242});
    }
    case TAG_EMatch: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam8, 1, 1, (V[]){v_e_242});
    }
    case TAG_EPrim: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam9, 1, 1, (V[]){v_e_242});
    }
    case TAG_EPrimCall: {
      V v_it2_2436 = heff_dup(heff_field(v_e_242, 1));
      switch (heff_tag_of(v_it2_2436)) {
      case TAG_Nil: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam10, 1, 1, (V[]){v_e_242});
      }
      case TAG_Cons: {
        V v_a_2438 = heff_field(v_it2_2436, 0);
        V v_it22_2439 = heff_field(v_it2_2436, 1);
        heff_take_n(v_it2_2436, 3ULL, 2);
        switch (heff_tag_of(v_it22_2439)) {
        case TAG_Nil: {
          heff_drop(v_s_240);
          heff_drop(v_ak_241);
          heff_drop(v_a_2438);
          return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam11, 1, 1, (V[]){v_e_242});
        }
        case TAG_Cons: {
          V v_r_2441 = heff_field(v_it22_2439, 0);
          V v_it222_2442 = heff_field(v_it22_2439, 1);
          heff_take_n(v_it22_2439, 3ULL, 2);
          switch (heff_tag_of(v_it222_2442)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_242, 2);
            return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam12, 1, 4, (V[]){v_s_240, v_ak_241, v_r_2441, v_a_2438});
          }
          case TAG_Cons: {
            heff_take_n(v_it222_2442, 0ULL, 2);
            heff_drop(v_s_240);
            heff_drop(v_ak_241);
            heff_drop(v_a_2438);
            heff_drop(v_r_2441);
            return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam13, 1, 1, (V[]){v_e_242});
          }
          default: return heff_nomatch(v_it222_2442);
          }
        }
        default: return heff_nomatch(v_it22_2439);
        }
      }
      default: return heff_nomatch(v_it2_2436);
      }
    }
    case TAG_ECall: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam14, 1, 1, (V[]){v_e_242});
    }
    case TAG_EInt: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam15, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFloat: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam16, 1, 1, (V[]){v_e_242});
    }
    case TAG_EStr: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam17, 1, 1, (V[]){v_e_242});
    }
    case TAG_EBytes: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam18, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFixed: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam19, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFloat32: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam20, 1, 1, (V[]){v_e_242});
    }
    case TAG_EAbandon: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam21, 1, 1, (V[]){v_e_242});
    }
    case TAG_EBool: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam22, 1, 1, (V[]){v_e_242});
    }
    case TAG_ESet: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam23, 1, 1, (V[]){v_e_242});
    }
    case TAG_EValues: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam24, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFix: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam25, 1, 1, (V[]){v_e_242});
    }
    default: return heff_nomatch(v_e_242);
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_ak_241);
    heff_drop(v_t_243);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam26, 1, 1, (V[]){v_e_242});
  }
}
V g_heff_2ecompile_2etrmc_2estartAcc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2estartAcc(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_245});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_247});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam2(V self, V *args) {
  V v_n_2410 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2410});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam3(V self, V *args) {
  V v_n_2413 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2413});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam4(V self, V *args) {
  V v_n_2417 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2417});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam5(V self, V *args) {
  V v_n_2420 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2420});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam6(V self, V *args) {
  V v_n_2425 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2425});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam7(V self, V *args) {
  V v_n_2429 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2429});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam8(V self, V *args) {
  V v_n_2432 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2432});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam9(V self, V *args) {
  V v_n_2434 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2434});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam10(V self, V *args) {
  V v_n_2437 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2437});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam11(V self, V *args) {
  V v_n_2440 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2440});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam12(V self, V *args) {
  V v_n_2443 = args[0];
  V v_s_240 = heff_env(self)[0];
  V v_ak_241 = heff_env(self)[1];
  V v_r_2441 = heff_env(self)[2];
  V v_a_2438 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartAcc_str0), heff_intShow(heff_dup(v_n_2443)));
  V v_x_2445 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartAcc_str1), v_t_2444);
  V v_m_2446 = (g_heff_2ecompile_2etrmc_2egather(v_s_240, v_ak_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2445)}), v_r_2441));
  V v_x2_2447 = heff_tr(heff_call(v_m_2446, 1, (V[]){heff_intAdd(v_n_2443, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_n_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2445, v_a_2438, v_x_2448}), v_n_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam13(V self, V *args) {
  V v_n_2452 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2452});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam14(V self, V *args) {
  V v_n_2455 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2455});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam15(V self, V *args) {
  V v_n_2457 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2457});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam16(V self, V *args) {
  V v_n_2459 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2459});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam17(V self, V *args) {
  V v_n_2461 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2461});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam18(V self, V *args) {
  V v_n_2463 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2463});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam19(V self, V *args) {
  V v_n_2466 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2466});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam20(V self, V *args) {
  V v_n_2468 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2468});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam21(V self, V *args) {
  V v_n_2469 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2469});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam22(V self, V *args) {
  V v_n_2471 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2471});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam23(V self, V *args) {
  V v_n_2475 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2475});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam24(V self, V *args) {
  V v_n_2477 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2477});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam25(V self, V *args) {
  V v_n_2480 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2480});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam26(V self, V *args) {
  V v_n_2481 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2481});
}
V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam4(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306(V v_lit_240, V v_lit_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2412 = (g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306(v_lit_240, v_lit_241, v_b_2411));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam0, 1, 3, (V[]){v_m_2412, v_x_249, v_a_2410});
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EMatch: {
    V v_sc_2426 = heff_field(v_e_242, 0);
    V v_arms_2427 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2437 = (g_prelude_2etraverse_24s1019364152x1582657694(heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam1, 1, 2, (V[]){v_lit_240, v_lit_241}), v_arms_2427));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam3, 1, 2, (V[]){v_m_2437, v_sc_2426});
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EBool: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ESet: {
    V v_xs_2455 = heff_field(v_e_242, 0);
    V v_a_2456 = heff_field(v_e_242, 1);
    V v_b_2457 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2458 = (g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306(v_lit_240, v_lit_241, v_b_2457));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam4, 1, 3, (V[]){v_m_2458, v_xs_2455, v_a_2456});
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam0(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_a_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_249, v_a_2410, v_x_2415}), v_n_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam2(V self, V *args) {
  V v_n_2433 = args[0];
  V v_m_2432 = heff_env(self)[0];
  V v_t_2429 = heff_env(self)[1];
  V v_vs_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2434 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_n_2433}));
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_MkPair: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_n_2436 = heff_field(v_x2_2434, 1);
    V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2429, v_vs_2430, v_x_2435}), v_n_2436});
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam1(V self, V *args) {
  V v_arm_2428 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_2428)) {
  case TAG_MkArm: {
    V v_t_2429 = heff_field(v_arm_2428, 0);
    V v_vs_2430 = heff_field(v_arm_2428, 1);
    V v_b_2431 = heff_field(v_arm_2428, 2);
    heff_take_n(v_arm_2428, 7ULL, 3);
    V v_m_2432 = (g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306(v_lit_240, v_lit_241, v_b_2431));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam2, 1, 3, (V[]){v_m_2432, v_t_2429, v_vs_2430});
  }
  default: return heff_nomatch(v_arm_2428);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam3(V self, V *args) {
  V v_n_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_sc_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_n_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_n_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2426, v_x_2440}), v_n_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306_lam4(V self, V *args) {
  V v_n_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_xs_2455 = heff_env(self)[1];
  V v_a_2456 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_n_2459}));
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_n_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2455, v_a_2456, v_x_2461}), v_n_2462});
  }
  default: return heff_nomatch(v_x2_2460);
  }
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str0, 4, "$dps");
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str1, 1, "$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str2, 1, "d");
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str3, 1, "$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str4, 1, "i");
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str5, 4, "$dps");
V g_heff_2ecompile_2etrmc_2edestined_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2edestined_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2edestined_entry, 4, 0};

V g_heff_2ecompile_2etrmc_2edestined(V v_s_240, V v_d_241, V v_xs_242, V v_b_243) {
top: ;
  V v_key_244 = heff_take_field(v_d_241, 0);
  V v_name_245 = heff_get_n(v_d_241, 1, 3);
  V v_x1_246 = (g_heff_2ecompile_2etrmc_2eholesAt(heff_dup(v_s_240), heff_dup(v_b_243)));
  V v_t_2410;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Nil: {
    v_t_2410 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_k_247 = heff_field(v_x1_246, 0);
    V v_ks_248 = heff_field(v_x1_246, 1);
    heff_take_n(v_x1_246, 3ULL, 2);
    V v_t_249 = ({ V a_0 = heff_dup(v_k_247); V a_1 = v_ks_248; V r_ = (g_list_2eall_24s262401054x194288545(a_0, a_1)); heff_drop(v_ks_248); r_; });
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){v_k_247});
    } else {
      heff_drop(v_k_247);
      heff_drop(v_t_249);
      v_t_2410 = NTAG(TAG_Nothing);
    }
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  V v_p_2411 = heff_rec_n(2, shape_key__at, (V[]){heff_strAppend(heff_dup(v_key_244), ((V)&g_heff_2ecompile_2etrmc_2edestined_str0)), v_t_2410});
  V v_m_2412 = (g_heff_2ecompile_2etrmc_2eatTails_24s242424081x2082772306(heff_dup(v_s_240), heff_dup(v_p_2411), heff_dup(v_b_243)));
  return heff_clo_n(g_heff_2ecompile_2etrmc_2edestined_lam0, 1, 7, (V[]){v_m_2412, v_xs_242, v_b_243, v_p_2411, v_s_240, v_key_244, v_name_245});
}
V g_heff_2ecompile_2etrmc_2edestined_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2edestined(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2etrmc_2edestined_lam0(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  V v_b_243 = heff_env(self)[2];
  V v_p_2411 = heff_env(self)[3];
  V v_s_240 = heff_env(self)[4];
  V v_key_244 = heff_env(self)[5];
  V v_name_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_t_2417 = heff_rec_n(3, shape_m__n__xs, (V[]){heff_dup(g_std_2emap_2eempty_get()), v_n_2416, NTAG(TAG_Nil)});
    V v_v_2418 = (g_list_2efoldl_24s690313412x1307839513(v_t_2417, v_xs_242));
    V v_m_2419 = heff_take_field(v_v_2418, 0);
    V v_n_2420 = heff_take_field(v_v_2418, 1);
    V v_xs_2421 = heff_get_n(v_v_2418, 2, 3);
    HeffT2 v_t_2422 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2419, v_n_2420, v_b_243));
    {
      V v_field_2423 = v_t_2422.f[0];
      V v_field_2424 = v_t_2422.f[1];
      V v_b_27_2425 = v_field_2423;
      V v_n_27_2426 = v_field_2424;
      V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2421));
      V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2edestined_str1), heff_intShow(heff_dup(v_n_27_2426)));
      V v_x_2429 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2edestined_str2), v_t_2428);
      V v_n_2430 = heff_intAdd(v_n_27_2426, MK_INT(1LL));
      V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2edestined_str3), heff_intShow(heff_dup(v_n_2430)));
      V v_x_2432 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2edestined_str4), v_t_2431);
      V v_t_2433 = heff_dup(heff_rfield(v_p_2411, 1));
      V v_t_2435;
      switch (heff_tag_of(v_t_2433)) {
      case TAG_Nothing: {
        v_t_2435 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2432)});
        break;
      }
      case TAG_Just: {
        V v_k_2434 = heff_field(v_t_2433, 0);
        V v_ru_24t_2433_24Just = heff_take_reuse_n(v_t_2433, 1ULL, 1);
        v_t_2435 = heff_tag_at_n(v_ru_24t_2433_24Just, TAG_EInt, 1, (V[]){v_k_2434});
        break;
      }
      default: heff_nomatch(v_t_2433);
      }
      V v_t_2436 = heff_tr(heff_call(((V)&g_heff_2ecompile_2etrmc_2efill_clo), 4, (V[]){v_s_240, heff_dup(v_p_2411), heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2429)}), v_t_2435}));
      V v_m_2437 = heff_tr(g_heff_2ecompile_2etrmc_2eatTails(v_t_2436, v_b_27_2425));
      V v_x2_2438 = heff_tr(heff_call(v_m_2437, 1, (V[]){heff_intAdd(v_n_2430, MK_INT(1LL))}));
      switch (heff_tag_of(v_x2_2438)) {
      case TAG_MkPair: {
        V v_x_2439 = heff_field(v_x2_2438, 0);
        V v_n_2440 = heff_field(v_x2_2438, 1);
        V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
        V v_t_2441 = heff_take_field(v_p_2411, 1);
        V v_t_2444;
        switch (heff_tag_of(v_t_2441)) {
        case TAG_Nothing: {
          V v_t_2442 = heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_Cons, 2, (V[]){v_x_2432, NTAG(TAG_Nil)});
          v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2429, v_t_2442});
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2441, 0ULL, 1);
          heff_drop(v_x_2432);
          v_t_2444 = heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_Cons, 2, (V[]){v_x_2429, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_t_2441);
        }
        V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2427, v_t_2444));
        V v_body_2446 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2445, v_x_2439});
        V v_t_2447 = heff_rec_n(3, shape_key__name__body, (V[]){v_key_244, heff_dup(v_name_245), heff_tag_n(TAG_ELam, 2, (V[]){v_xs_242, v_x_2415})});
        V v_t_2448 = heff_rec_n(3, shape_key__name__body, (V[]){heff_get_n(v_p_2411, 0, 2), heff_strAppend(v_name_245, ((V)&g_heff_2ecompile_2etrmc_2edestined_str5)), v_body_2446});
        V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, v_t_2449}), v_n_2440});
      }
      default: return heff_nomatch(v_x2_2438);
      }
    }
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam4(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700(V v_lit_240, V v_lit_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2412 = (g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700(v_lit_240, v_lit_241, v_b_2411));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam0, 1, 3, (V[]){v_m_2412, v_x_249, v_a_2410});
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EMatch: {
    V v_sc_2426 = heff_field(v_e_242, 0);
    V v_arms_2427 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2437 = (g_prelude_2etraverse_24s1019364152x1582657694(heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam1, 1, 2, (V[]){v_lit_240, v_lit_241}), v_arms_2427));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam3, 1, 2, (V[]){v_m_2437, v_sc_2426});
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EBool: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ESet: {
    V v_xs_2455 = heff_field(v_e_242, 0);
    V v_a_2456 = heff_field(v_e_242, 1);
    V v_b_2457 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2458 = (g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700(v_lit_240, v_lit_241, v_b_2457));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam4, 1, 3, (V[]){v_m_2458, v_xs_2455, v_a_2456});
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam0(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_a_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_249, v_a_2410, v_x_2415}), v_n_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam2(V self, V *args) {
  V v_n_2433 = args[0];
  V v_m_2432 = heff_env(self)[0];
  V v_t_2429 = heff_env(self)[1];
  V v_vs_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2434 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_n_2433}));
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_MkPair: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_n_2436 = heff_field(v_x2_2434, 1);
    V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2429, v_vs_2430, v_x_2435}), v_n_2436});
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam1(V self, V *args) {
  V v_arm_2428 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_2428)) {
  case TAG_MkArm: {
    V v_t_2429 = heff_field(v_arm_2428, 0);
    V v_vs_2430 = heff_field(v_arm_2428, 1);
    V v_b_2431 = heff_field(v_arm_2428, 2);
    heff_take_n(v_arm_2428, 7ULL, 3);
    V v_m_2432 = (g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700(v_lit_240, v_lit_241, v_b_2431));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam2, 1, 3, (V[]){v_m_2432, v_t_2429, v_vs_2430});
  }
  default: return heff_nomatch(v_arm_2428);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam3(V self, V *args) {
  V v_n_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_sc_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_n_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_n_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2426, v_x_2440}), v_n_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam4(V self, V *args) {
  V v_n_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_xs_2455 = heff_env(self)[1];
  V v_a_2456 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_n_2459}));
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_n_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2455, v_a_2456, v_x_2461}), v_n_2462});
  }
  default: return heff_nomatch(v_x2_2460);
  }
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str0, 4, "$acc");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str1, 1, "$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str2, 3, "acc");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str3, 4, "$acc");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str4, 4, "$acc");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str5, 4, "$acc");
V g_heff_2ecompile_2etrmc_2egathered_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2egathered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2egathered_entry, 4, 0};

V g_heff_2ecompile_2etrmc_2egathered(V v_s_240, V v_d_241, V v_xs_242, V v_b_243) {
top: ;
  V v_key_244 = heff_take_field(v_d_241, 0);
  V v_name_245 = heff_get_n(v_d_241, 1, 3);
  V v_m_246 = (g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700(heff_dup(v_s_240), heff_strAppend(heff_dup(v_key_244), ((V)&g_heff_2ecompile_2etrmc_2egathered_str0)), heff_dup(v_b_243)));
  return heff_clo_n(g_heff_2ecompile_2etrmc_2egathered_lam0, 1, 6, (V[]){v_m_246, v_xs_242, v_b_243, v_s_240, v_key_244, v_name_245});
}
V g_heff_2ecompile_2etrmc_2egathered_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2egathered(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2etrmc_2egathered_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  V v_b_243 = heff_env(self)[2];
  V v_s_240 = heff_env(self)[3];
  V v_key_244 = heff_env(self)[4];
  V v_name_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2411 = heff_rec_n(3, shape_m__n__xs, (V[]){heff_dup(g_std_2emap_2eempty_get()), v_n_2410, NTAG(TAG_Nil)});
    V v_v_2412 = (g_list_2efoldl_24s690313412x1307839513(v_t_2411, v_xs_242));
    V v_m_2413 = heff_take_field(v_v_2412, 0);
    V v_n_2414 = heff_take_field(v_v_2412, 1);
    V v_xs_2415 = heff_get_n(v_v_2412, 2, 3);
    HeffT2 v_t_2416 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2413, v_n_2414, v_b_243));
    {
      V v_field_2417 = v_t_2416.f[0];
      V v_field_2418 = v_t_2416.f[1];
      V v_b_27_2419 = v_field_2417;
      V v_n_27_2420 = v_field_2418;
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2415));
      V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2egathered_str1), heff_intShow(heff_dup(v_n_27_2420)));
      V v_x_2423 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2egathered_str2), v_t_2422);
      V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2etrmc_2egather_clo), 3, (V[]){v_s_240, heff_strAppend(heff_dup(v_key_244), ((V)&g_heff_2ecompile_2etrmc_2egathered_str3)), heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2423)})}));
      V v_m_2425 = heff_tr(g_heff_2ecompile_2etrmc_2eatTails(v_t_2424, v_b_27_2419));
      V v_x2_2426 = heff_tr(heff_call(v_m_2425, 1, (V[]){heff_intAdd(v_n_27_2420, MK_INT(1LL))}));
      switch (heff_tag_of(v_x2_2426)) {
      case TAG_MkPair: {
        V v_x_2427 = heff_field(v_x2_2426, 0);
        V v_n_2428 = heff_field(v_x2_2426, 1);
        V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
        V v_t_2429 = heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_Cons, 2, (V[]){v_x_2423, NTAG(TAG_Nil)});
        V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2429));
        V v_body_2431 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2430, v_x_2427});
        V v_t_2432 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_key_244), heff_dup(v_name_245), heff_tag_n(TAG_ELam, 2, (V[]){v_xs_242, v_x_249})});
        V v_t_2433 = heff_rec_n(3, shape_key__name__body, (V[]){heff_strAppend(v_key_244, ((V)&g_heff_2ecompile_2etrmc_2egathered_str4)), heff_strAppend(v_name_245, ((V)&g_heff_2ecompile_2etrmc_2egathered_str5)), v_body_2431});
        V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2434}), v_n_2428});
      }
      default: return heff_nomatch(v_x2_2426);
      }
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2etrmc_2edefT_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam4(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam5(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam6(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam7(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam8(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam9(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam10(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam11(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam12(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam13(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam14(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam15(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam16(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam17(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam18(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam19(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam20(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam21(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam22(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2edefT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2edefT_entry, 1, 0};

V g_heff_2ecompile_2etrmc_2edefT(V v_d_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_d_240, 2));
  switch (heff_tag_of(v_t_241)) {
  case TAG_EVar: {
    heff_take_n(v_t_241, 0ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam0, 1, 1, (V[]){v_d_240});
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_241, 0ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam1, 1, 1, (V[]){v_d_240});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_t_241, 0);
    V v_b_249 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
    V v_s_2411 = heff_rec_n(2, shape_key__arity, (V[]){heff_dup(heff_rfield(v_d_240, 0)), v_t_2410});
    V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2etrmc_2econsEnds_clo), 1, (V[]){heff_dup(v_s_2411)}));
    V v_t_2413 = heff_tr(g_heff_2ecompile_2etrmc_2eanyTail(v_t_2412, heff_dup(v_b_249)));
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      return (g_heff_2ecompile_2etrmc_2edestined(v_s_2411, v_d_240, v_xs_248, v_b_249));
    } else {
      heff_drop(v_t_2413);
      V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2etrmc_2eappendEnds_clo), 1, (V[]){heff_dup(v_s_2411)}));
      V v_t_2415 = heff_tr(g_heff_2ecompile_2etrmc_2eanyTail(v_t_2414, heff_dup(v_b_249)));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        return (g_heff_2ecompile_2etrmc_2egathered(v_s_2411, v_d_240, v_xs_248, v_b_249));
      } else {
        heff_drop(v_xs_248);
        heff_drop(v_b_249);
        heff_drop_rec(v_s_2411, 2);
        heff_drop(v_t_2415);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam2, 1, 1, (V[]){v_d_240});
      }
    }
  }
  case TAG_EApp: {
    heff_take_n(v_t_241, 0ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam3, 1, 1, (V[]){v_d_240});
  }
  case TAG_ELet: {
    heff_take_n(v_t_241, 0ULL, 3);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam4, 1, 1, (V[]){v_d_240});
  }
  case TAG_ERecord: {
    heff_take_n(v_t_241, 0ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam5, 1, 1, (V[]){v_d_240});
  }
  case TAG_EProj: {
    heff_take_n(v_t_241, 0ULL, 4);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam6, 1, 1, (V[]){v_d_240});
  }
  case TAG_ETag: {
    heff_take_n(v_t_241, 0ULL, 3);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam7, 1, 1, (V[]){v_d_240});
  }
  case TAG_EMatch: {
    heff_take_n(v_t_241, 0ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam8, 1, 1, (V[]){v_d_240});
  }
  case TAG_EPrim: {
    heff_take_n(v_t_241, 0ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam9, 1, 1, (V[]){v_d_240});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_241, 0ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam10, 1, 1, (V[]){v_d_240});
  }
  case TAG_ECall: {
    heff_take_n(v_t_241, 0ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam11, 1, 1, (V[]){v_d_240});
  }
  case TAG_EInt: {
    heff_take_n(v_t_241, 0ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam12, 1, 1, (V[]){v_d_240});
  }
  case TAG_EFloat: {
    heff_take_na(v_t_241, 0ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam13, 1, 1, (V[]){v_d_240});
  }
  case TAG_EStr: {
    heff_take_n(v_t_241, 0ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam14, 1, 1, (V[]){v_d_240});
  }
  case TAG_EBytes: {
    heff_take_n(v_t_241, 0ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam15, 1, 1, (V[]){v_d_240});
  }
  case TAG_EFixed: {
    heff_take_n(v_t_241, 0ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam16, 1, 1, (V[]){v_d_240});
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_241, 0ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam17, 1, 1, (V[]){v_d_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam18, 1, 1, (V[]){v_d_240});
  }
  case TAG_EBool: {
    heff_take_n(v_t_241, 0ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam19, 1, 1, (V[]){v_d_240});
  }
  case TAG_ESet: {
    heff_take_n(v_t_241, 0ULL, 3);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam20, 1, 1, (V[]){v_d_240});
  }
  case TAG_EValues: {
    heff_take_n(v_t_241, 0ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam21, 1, 1, (V[]){v_d_240});
  }
  case TAG_EFix: {
    heff_take_n(v_t_241, 0ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam22, 1, 1, (V[]){v_d_240});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2etrmc_2edefT_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2edefT(a[0]);
}
V g_heff_2ecompile_2etrmc_2edefT_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_n_243});
}
V g_heff_2ecompile_2etrmc_2edefT_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_n_246});
}
V g_heff_2ecompile_2etrmc_2edefT_lam2(V self, V *args) {
  V v_n_2416 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_n_2416});
}
V g_heff_2ecompile_2etrmc_2edefT_lam3(V self, V *args) {
  V v_n_2420 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, v_n_2420});
}
V g_heff_2ecompile_2etrmc_2edefT_lam4(V self, V *args) {
  V v_n_2425 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_n_2425});
}
V g_heff_2ecompile_2etrmc_2edefT_lam5(V self, V *args) {
  V v_n_2429 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_n_2429});
}
V g_heff_2ecompile_2etrmc_2edefT_lam6(V self, V *args) {
  V v_n_2435 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2436, v_n_2435});
}
V g_heff_2ecompile_2etrmc_2edefT_lam7(V self, V *args) {
  V v_n_2440 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2441, v_n_2440});
}
V g_heff_2ecompile_2etrmc_2edefT_lam8(V self, V *args) {
  V v_n_2444 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2445, v_n_2444});
}
V g_heff_2ecompile_2etrmc_2edefT_lam9(V self, V *args) {
  V v_n_2447 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2448, v_n_2447});
}
V g_heff_2ecompile_2etrmc_2edefT_lam10(V self, V *args) {
  V v_n_2451 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2452, v_n_2451});
}
V g_heff_2ecompile_2etrmc_2edefT_lam11(V self, V *args) {
  V v_n_2455 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2456, v_n_2455});
}
V g_heff_2ecompile_2etrmc_2edefT_lam12(V self, V *args) {
  V v_n_2458 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2459, v_n_2458});
}
V g_heff_2ecompile_2etrmc_2edefT_lam13(V self, V *args) {
  V v_n_2461 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2462, v_n_2461});
}
V g_heff_2ecompile_2etrmc_2edefT_lam14(V self, V *args) {
  V v_n_2464 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2465, v_n_2464});
}
V g_heff_2ecompile_2etrmc_2edefT_lam15(V self, V *args) {
  V v_n_2467 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2468, v_n_2467});
}
V g_heff_2ecompile_2etrmc_2edefT_lam16(V self, V *args) {
  V v_n_2471 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2472, v_n_2471});
}
V g_heff_2ecompile_2etrmc_2edefT_lam17(V self, V *args) {
  V v_n_2474 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2475, v_n_2474});
}
V g_heff_2ecompile_2etrmc_2edefT_lam18(V self, V *args) {
  V v_n_2476 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2477, v_n_2476});
}
V g_heff_2ecompile_2etrmc_2edefT_lam19(V self, V *args) {
  V v_n_2479 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2480, v_n_2479});
}
V g_heff_2ecompile_2etrmc_2edefT_lam20(V self, V *args) {
  V v_n_2484 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2485, v_n_2484});
}
V g_heff_2ecompile_2etrmc_2edefT_lam21(V self, V *args) {
  V v_n_2487 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2488 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2488, v_n_2487});
}
V g_heff_2ecompile_2etrmc_2edefT_lam22(V self, V *args) {
  V v_n_2491 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2492, v_n_2491});
}