// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Backspace 1027
#define TAG_Char 10597
#define TAG_Control 37853
#define TAG_Enter 13030
#define TAG_Escape 55216
#define TAG_Sequence 46672
#define TAG_Tab 31265
#define LBL_key 315609
#define LBL_next 9873338
static uint32_t shape_key__next[] = {LBL_key, LBL_next};
V g_std_2eterminal_2ewidget_2ecsiEnd(V, V);
V g_std_2eterminal_2ewidget_2ecsiEnd_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecsiEnd_clo;
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244(V, V);
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_clo;
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps(V, V, V);
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps_clo;
V g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243(V, V);
V g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_clo;
V g_std_2eterminal_2ewidget_2efinalKey(V, V, V);
V g_std_2eterminal_2ewidget_2efinalKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2efinalKey_clo;
HEFF_LIT(g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_str0, 0, "");
Clo g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_entry, 2, 0};

V g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)27ULL))) {
    V v_s_242 = v_s_240;
    V v_i_243 = v_i_241;
    V v_t_244 = heff_strByteAt(heff_dup(v_s_242), heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
    if ((heff_unbox_word(v_t_244) == ((int64_t)91ULL))) {
      V v_s_245 = v_s_242;
      V v_i_246 = v_i_243;
      V v_t_247 = (g_std_2eterminal_2ewidget_2ecsiEnd(v_s_245, heff_intAdd(heff_dup(v_i_246), MK_INT(2LL))));
      if (heff_intLt_c(v_t_247, MK_INT(0LL))) {
        V v_t_248 = heff_strSlice(heff_dup(v_s_245), v_i_246, heff_strLength_lent(v_s_245, 0));
        return heff_rec_n(2, shape_key__next, (V[]){heff_tag_n(TAG_Sequence, 1, (V[]){v_t_248}), heff_strLength(v_s_245)});
      } else {
        V v_t_249 = (g_std_2eterminal_2ewidget_2ecsiEnd(v_s_245, heff_intAdd(heff_dup(v_i_246), MK_INT(2LL))));
        V v_t_2410 = heff_strSlice(heff_dup(v_s_245), heff_dup(v_i_246), heff_intAdd(v_t_249, MK_INT(1LL)));
        V v_t_2411 = (g_std_2eterminal_2ewidget_2ecsiEnd(v_s_245, heff_intAdd(heff_dup(v_i_246), MK_INT(2LL))));
        V v_t_2412 = heff_strSlice(heff_dup(v_s_245), heff_intAdd(heff_dup(v_i_246), MK_INT(2LL)), v_t_2411);
        V v_t_2413 = (g_std_2eterminal_2ewidget_2ecsiEnd(v_s_245, heff_intAdd(heff_dup(v_i_246), MK_INT(2LL))));
        V v_t_2414 = ({ V a_0 = v_t_2410; V a_1 = v_t_2412; V a_2 = heff_strByteAt_lent(v_s_245, v_t_2413, 2); V r_ = (g_std_2eterminal_2ewidget_2efinalKey(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
        V v_t_2415 = ({ V a_0 = v_s_245; V a_1 = heff_intAdd(v_i_246, MK_INT(2LL)); V r_ = (g_std_2eterminal_2ewidget_2ecsiEnd(a_0, a_1)); heff_drop(v_s_245); r_; });
        return heff_rec_n(2, shape_key__next, (V[]){v_t_2414, heff_intAdd(v_t_2415, MK_INT(1LL))});
      }
    } else {
      V v_t_2416 = heff_strByteAt(heff_dup(v_s_242), heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
      if ((heff_unbox_word(v_t_2416) == ((int64_t)79ULL))) {
        V v_s_2417 = v_s_242;
        V v_i_2418 = v_i_243;
        if (heff_intLe_c(heff_strLength_lent(v_s_2417, 0), heff_intAdd(heff_dup(v_i_2418), MK_INT(2LL)))) {
          heff_drop(v_s_2417);
          return heff_rec_n(2, shape_key__next, (V[]){NTAG(TAG_Escape), heff_intAdd(v_i_2418, MK_INT(1LL))});
        } else {
          V v_t_2419 = heff_strSlice(heff_dup(v_s_2417), heff_dup(v_i_2418), heff_intAdd(heff_dup(v_i_2418), MK_INT(3LL)));
          V v_t_2420 = heff_strByteAt(v_s_2417, heff_intAdd(heff_dup(v_i_2418), MK_INT(2LL)));
          V v_t_2421 = ({ V a_0 = v_t_2419; V b_1 = ((V)&g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_str0); V a_2 = v_t_2420; V r_ = (g_std_2eterminal_2ewidget_2efinalKey(a_0, b_1, a_2)); heff_drop(b_1); r_; });
          return heff_rec_n(2, shape_key__next, (V[]){v_t_2421, heff_intAdd(v_i_2418, MK_INT(3LL))});
        }
      } else {
        heff_drop(v_s_242);
        return heff_rec_n(2, shape_key__next, (V[]){NTAG(TAG_Escape), heff_intAdd(v_i_243, MK_INT(1LL))});
      }
    }
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) < ((int64_t)32ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)127ULL)))) {
      V v_b_2422 = heff_strByteAt_lent(v_s_240, v_i_241, 1);
      V v_t_2425;
      if ((heff_peek_word(v_b_2422) == ((int64_t)13ULL))) {
        heff_drop(v_b_2422);
        v_t_2425 = NTAG(TAG_Enter);
      } else {
        if ((heff_peek_word(v_b_2422) == ((int64_t)10ULL))) {
          heff_drop(v_b_2422);
          v_t_2425 = NTAG(TAG_Enter);
        } else {
          if ((heff_peek_word(v_b_2422) == ((int64_t)9ULL))) {
            heff_drop(v_b_2422);
            v_t_2425 = NTAG(TAG_Tab);
          } else {
            if ((heff_peek_word(v_b_2422) == ((int64_t)8ULL))) {
              heff_drop(v_b_2422);
              v_t_2425 = NTAG(TAG_Backspace);
            } else {
              if ((heff_peek_word(v_b_2422) == ((int64_t)127ULL))) {
                heff_drop(v_b_2422);
                v_t_2425 = NTAG(TAG_Backspace);
              } else {
                if (((((int64_t)1ULL) <= heff_peek_word(v_b_2422)) && (heff_peek_word(v_b_2422) <= ((int64_t)26ULL)))) {
                  V v_t_2423 = heff_runeFromInt(heff_box_word((heff_unbox_word(v_b_2422) + ((int64_t)96ULL))));
                  v_t_2425 = heff_tag_n(TAG_Control, 1, (V[]){v_t_2423});
                } else {
                  V v_t_2424 = heff_runeFromInt(heff_box_word((heff_unbox_word(v_b_2422) + ((int64_t)64ULL))));
                  v_t_2425 = heff_tag_n(TAG_Control, 1, (V[]){v_t_2424});
                }
              }
            }
          }
        }
      }
      return heff_rec_n(2, shape_key__next, (V[]){v_t_2425, heff_intAdd(v_i_241, MK_INT(1LL))});
    } else {
      HeffT2 v_t_2426 = heff_strRuneDecode_lent(v_s_240, v_i_241, 1);
      {
        V v_rune_2427 = v_t_2426.f[0];
        V v_width_2428 = v_t_2426.f[1];
        V v_t_2429 = heff_tag_n(TAG_Char, 1, (V[]){v_rune_2427});
        V v_t_2430 = heff_intAdd(v_i_241, v_width_2428);
        return heff_rec_n(2, shape_key__next, (V[]){v_t_2429, v_t_2430});
      }
    }
  }
}
V g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243(a[0], a[1]);
}
Clo g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_entry, 2, 0};

V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  } else {
    V v_t_242 = (g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_242, 0, 2), heff_hole()});
    V v_t_244 = (g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243(heff_dup(v_s_240), v_i_241));
    V v_u_245 = (g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps(v_s_240, heff_get_n(v_t_244, 1, 2), heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
}
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244(a[0], a[1]);
}
Clo g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps_entry, 3, 0};

V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps(V v_s_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_243 = (g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_243, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243(heff_dup(v_s_240), v_i_241));
    V t_0 = v_s_240;
    V t_1 = heff_get_n(v_t_246, 1, 2);
    V t_2 = v_cell_244;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps(a[0], a[1], a[2]);
}