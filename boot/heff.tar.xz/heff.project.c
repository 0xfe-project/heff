// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2enextDecl_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
Clo g_heff_2eproject_2enextDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2enextDecl_entry, 2, 0};

V g_heff_2eproject_2enextDecl(V v_ts_240, V v_i_241) {
top: ;
  V v_t_242 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
  V v_t_243 = heff_strEq(heff_get(heff_dup(v_t_242), LBL_kind), ((V)&g_heff_2eproject_2enextDecl_str0));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_ts_240);
    heff_drop(v_t_242);
    heff_drop(v_t_243);
    return v_i_241;
  }
  case TAG_False: {
    heff_drop(v_t_243);
    V v_t_244 = heff_get(heff_dup(v_t_242), LBL_first);
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_t_244);
      V v_t_245 = heff_intEq(heff_get(v_t_242, LBL_col), MK_INT(0LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_ts_240);
        heff_drop(v_t_245);
        return v_i_241;
      }
      case TAG_False: {
        heff_drop(v_t_245);
        V t_0 = v_ts_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        v_ts_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_False: {
      heff_drop(v_t_242);
      heff_drop(v_t_244);
      V t_0 = v_ts_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_ts_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eproject_2enextDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2enextDecl(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eproject_2eitemsGo_24s727_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2eitemsGo_24s727_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eproject_2eitemsGo_24s727_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2eitemsGo_24s727_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[62]; } g_heff_2eproject_2eitemsGo_24s727_str4 = {{0x80000000u, K_STR, 0}, 62, 62, {101, 120, 112, 101, 99, 116, 101, 100, 32, 96, 44, 96, 32, 111, 114, 32, 96, 93, 96, 58, 32, 97, 110, 32, 105, 116, 101, 109, 32, 105, 115, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 110, 111, 116, 104, 105, 110, 103, 32, 105, 115, 32, 99, 111, 109, 112, 117, 116, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[62]; } g_heff_2eproject_2eitemsGo_24s727_str5 = {{0x80000000u, K_STR, 0}, 62, 62, {101, 120, 112, 101, 99, 116, 101, 100, 32, 96, 44, 96, 32, 111, 114, 32, 96, 93, 96, 58, 32, 97, 110, 32, 105, 116, 101, 109, 32, 105, 115, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 110, 111, 116, 104, 105, 110, 103, 32, 105, 115, 32, 99, 111, 109, 112, 117, 116, 101, 100}};
Clo g_heff_2eproject_2eitemsGo_24s727_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2eitemsGo_24s727_entry, 3, 0};

V g_heff_2eproject_2eitemsGo_24s727(V v_ts_240, V v_i_241, V v_acc_242) {
top: ;
  V v_it_243 = (g_heff_2eproject_2elitF_24s726(heff_dup(v_ts_240), v_i_241));
  switch (heff_tag_of(v_it_243)) {
  case TAG_Left: {
    V v_p_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Left = heff_take_reuse(v_it_243, 1ULL);
    heff_drop(v_ts_240);
    heff_drop(v_acc_242);
    return heff_tag_at(v_ru_24it_243_24Left, TAG_Left, 1, (V[]){v_p_244});
  }
  case TAG_Right: {
    V v_it1_245 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Right = heff_take_reuse(v_it_243, 1ULL);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_it1_245, 0);
      V v_j_247 = heff_field(v_it1_245, 1);
      V v_ru_24it1_245_24MkPair = heff_take_reuse(v_it1_245, 3ULL);
      V v_t_248 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_j_247));
      V v_t_249 = heff_strEq(heff_get(heff_dup(v_t_248), LBL_kind), ((V)&g_heff_2eproject_2eitemsGo_24s727_str0));
      V v_t_2410;
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        heff_drop(v_t_249);
        v_t_2410 = heff_strEq(heff_get(v_t_248, LBL_text), ((V)&g_heff_2eproject_2eitemsGo_24s727_str1));
        break;
      }
      case TAG_False: {
        heff_drop(v_t_248);
        heff_drop(v_t_249);
        v_t_2410 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop(v_ru_24it_243_24Right);
        heff_drop(v_t_2410);
        V t_0 = v_ts_240;
        V t_1 = heff_intAdd(v_j_247, MK_INT(1LL));
        V t_2 = heff_tag_at(v_ru_24it1_245_24MkPair, TAG_Cons, 2, (V[]){v_x_246, v_acc_242});
        v_ts_240 = t_0;
        v_i_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_t_2410);
        V v_t_2411 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_j_247));
        V v_t_2412 = heff_strEq(heff_get(heff_dup(v_t_2411), LBL_kind), ((V)&g_heff_2eproject_2eitemsGo_24s727_str2));
        switch (heff_tag_of(v_t_2412)) {
        case TAG_True: {
          heff_drop(v_t_2412);
          V v_t_2413 = heff_strEq(heff_get(v_t_2411, LBL_text), ((V)&g_heff_2eproject_2eitemsGo_24s727_str3));
          switch (heff_tag_of(v_t_2413)) {
          case TAG_True: {
            heff_drop(v_ts_240);
            heff_drop(v_t_2413);
            V v_t_2414 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_tag_at(v_ru_24it1_245_24MkPair, TAG_Cons, 2, (V[]){v_x_246, v_acc_242})));
            V v_t_2415 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2414, heff_intAdd(v_j_247, MK_INT(1LL))});
            return heff_tag_at(v_ru_24it_243_24Right, TAG_Right, 1, (V[]){v_t_2415});
          }
          case TAG_False: {
            heff_drop(v_acc_242);
            heff_drop(v_x_246);
            heff_drop(v_ru_24it1_245_24MkPair);
            heff_drop(v_t_2413);
            V v_t_2416 = heff_arrayIndex(v_ts_240, v_j_247);
            V v_t_2417 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2416, LBL_start), ((V)&g_heff_2eproject_2eitemsGo_24s727_str4)});
            return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_t_2417});
          }
          default: return heff_nomatch(v_t_2413);
          }
        }
        case TAG_False: {
          heff_drop(v_acc_242);
          heff_drop(v_x_246);
          heff_drop(v_ru_24it1_245_24MkPair);
          heff_drop(v_t_2411);
          heff_drop(v_t_2412);
          V v_t_2418 = heff_arrayIndex(v_ts_240, v_j_247);
          V v_t_2419 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2418, LBL_start), ((V)&g_heff_2eproject_2eitemsGo_24s727_str5)});
          return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_t_2419});
        }
        default: return heff_nomatch(v_t_2412);
        }
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_it1_245);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2eproject_2eitemsGo_24s727_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2eitemsGo_24s727(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2efieldsGo_24s728_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2eproject_2efieldsGo_24s728_str1 = {{0x80000000u, K_STR, 0}, 23, 23, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 102, 105, 101, 108, 100, 39, 115, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2efieldsGo_24s728_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2efieldsGo_24s728_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eproject_2efieldsGo_24s728_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {101, 120, 112, 101, 99, 116, 101, 100, 32, 96, 61, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eproject_2efieldsGo_24s728_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2efieldsGo_24s728_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eproject_2efieldsGo_24s728_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2efieldsGo_24s728_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[62]; } g_heff_2eproject_2efieldsGo_24s728_str9 = {{0x80000000u, K_STR, 0}, 62, 62, {101, 120, 112, 101, 99, 116, 101, 100, 32, 96, 44, 96, 32, 111, 114, 32, 96, 125, 96, 58, 32, 97, 32, 102, 105, 101, 108, 100, 32, 105, 115, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 110, 111, 116, 104, 105, 110, 103, 32, 105, 115, 32, 99, 111, 109, 112, 117, 116, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[62]; } g_heff_2eproject_2efieldsGo_24s728_str10 = {{0x80000000u, K_STR, 0}, 62, 62, {101, 120, 112, 101, 99, 116, 101, 100, 32, 96, 44, 96, 32, 111, 114, 32, 96, 125, 96, 58, 32, 97, 32, 102, 105, 101, 108, 100, 32, 105, 115, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 110, 111, 116, 104, 105, 110, 103, 32, 105, 115, 32, 99, 111, 109, 112, 117, 116, 101, 100}};
Clo g_heff_2eproject_2efieldsGo_24s728_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2efieldsGo_24s728_entry, 3, 0};

V g_heff_2eproject_2efieldsGo_24s728(V v_ts_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
  V v_x1_244 = heff_strEq(heff_get(v_t_243, LBL_kind), ((V)&g_heff_2eproject_2efieldsGo_24s728_str0));
  V v_t_245;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_True: {
    heff_drop(v_x1_244);
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    heff_drop(v_x1_244);
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_acc_242);
    heff_drop(v_t_245);
    V v_t_246 = heff_arrayIndex(v_ts_240, v_i_241);
    V v_t_247 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_246, LBL_start), ((V)&g_heff_2eproject_2efieldsGo_24s728_str1)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_247});
  }
  case TAG_False: {
    heff_drop(v_t_245);
    V v_t_248 = heff_arrayIndex(heff_dup(v_ts_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
    V v_t_249 = heff_strEq(heff_get(v_t_248, LBL_kind), ((V)&g_heff_2eproject_2efieldsGo_24s728_str2));
    V v_x1_2411;
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_t_249);
      V v_t_2410 = heff_arrayIndex(heff_dup(v_ts_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
      v_x1_2411 = heff_strEq(heff_get(v_t_2410, LBL_text), ((V)&g_heff_2eproject_2efieldsGo_24s728_str3));
      break;
    }
    case TAG_False: {
      heff_drop(v_t_249);
      v_x1_2411 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_True: {
      heff_drop(v_x1_2411);
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      heff_drop(v_x1_2411);
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_2411);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_acc_242);
      heff_drop(v_t_2412);
      V v_t_2413 = heff_arrayIndex(v_ts_240, heff_intAdd(v_i_241, MK_INT(1LL)));
      V v_t_2414 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2413, LBL_start), ((V)&g_heff_2eproject_2efieldsGo_24s728_str4)});
      return heff_tag(TAG_Left, 1, (V[]){v_t_2414});
    }
    case TAG_False: {
      heff_drop(v_t_2412);
      V v_it_2415 = (g_heff_2eproject_2elitF_24s726(heff_dup(v_ts_240), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))));
      switch (heff_tag_of(v_it_2415)) {
      case TAG_Left: {
        V v_p_2416 = heff_field(v_it_2415, 0);
        V v_ru_24it_2415_24Left = heff_take_reuse(v_it_2415, 1ULL);
        heff_drop(v_ts_240);
        heff_drop(v_i_241);
        heff_drop(v_acc_242);
        return heff_tag_at(v_ru_24it_2415_24Left, TAG_Left, 1, (V[]){v_p_2416});
      }
      case TAG_Right: {
        V v_it1_2417 = heff_field(v_it_2415, 0);
        V v_ru_24it_2415_24Right = heff_take_reuse(v_it_2415, 1ULL);
        switch (heff_tag_of(v_it1_2417)) {
        case TAG_MkPair: {
          V v_x_2418 = heff_field(v_it1_2417, 0);
          V v_j_2419 = heff_field(v_it1_2417, 1);
          V v_ru_24it1_2417_24MkPair = heff_take_reuse(v_it1_2417, 3ULL);
          V v_t_2420 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_j_2419));
          V v_t_2421 = heff_strEq(heff_get(heff_dup(v_t_2420), LBL_kind), ((V)&g_heff_2eproject_2efieldsGo_24s728_str5));
          V v_t_2422;
          switch (heff_tag_of(v_t_2421)) {
          case TAG_True: {
            heff_drop(v_t_2421);
            v_t_2422 = heff_strEq(heff_get(v_t_2420, LBL_text), ((V)&g_heff_2eproject_2efieldsGo_24s728_str6));
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2420);
            heff_drop(v_t_2421);
            v_t_2422 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          switch (heff_tag_of(v_t_2422)) {
          case TAG_True: {
            heff_drop(v_ru_24it_2415_24Right);
            heff_drop(v_t_2422);
            V v_t_2423 = heff_arrayIndex(heff_dup(v_ts_240), v_i_241);
            V v_t_2424 = heff_tag_at(v_ru_24it1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_get(v_t_2423, LBL_text), v_x_2418});
            V t_0 = v_ts_240;
            V t_1 = heff_intAdd(v_j_2419, MK_INT(1LL));
            V t_2 = heff_tag(TAG_Cons, 2, (V[]){v_t_2424, v_acc_242});
            v_ts_240 = t_0;
            v_i_241 = t_1;
            v_acc_242 = t_2;
            goto top;
          }
          case TAG_False: {
            heff_drop(v_t_2422);
            V v_t_2425 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_j_2419));
            V v_t_2426 = heff_strEq(heff_get(heff_dup(v_t_2425), LBL_kind), ((V)&g_heff_2eproject_2efieldsGo_24s728_str7));
            switch (heff_tag_of(v_t_2426)) {
            case TAG_True: {
              heff_drop(v_t_2426);
              V v_t_2427 = heff_strEq(heff_get(v_t_2425, LBL_text), ((V)&g_heff_2eproject_2efieldsGo_24s728_str8));
              switch (heff_tag_of(v_t_2427)) {
              case TAG_True: {
                heff_drop(v_t_2427);
                V v_t_2428 = heff_arrayIndex(v_ts_240, v_i_241);
                V v_t_2429 = heff_tag_at(v_ru_24it1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_get(v_t_2428, LBL_text), v_x_2418});
                V v_xs_2430 = heff_tag(TAG_Cons, 2, (V[]){v_t_2429, v_acc_242});
                V v_t_2431 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2430));
                V v_t_2432 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2431, heff_intAdd(v_j_2419, MK_INT(1LL))});
                return heff_tag_at(v_ru_24it_2415_24Right, TAG_Right, 1, (V[]){v_t_2432});
              }
              case TAG_False: {
                heff_drop(v_i_241);
                heff_drop(v_acc_242);
                heff_drop(v_x_2418);
                heff_drop(v_ru_24it1_2417_24MkPair);
                heff_drop(v_t_2427);
                V v_t_2433 = heff_arrayIndex(v_ts_240, v_j_2419);
                V v_t_2434 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2433, LBL_start), ((V)&g_heff_2eproject_2efieldsGo_24s728_str9)});
                return heff_tag_at(v_ru_24it_2415_24Right, TAG_Left, 1, (V[]){v_t_2434});
              }
              default: return heff_nomatch(v_t_2427);
              }
            }
            case TAG_False: {
              heff_drop(v_i_241);
              heff_drop(v_acc_242);
              heff_drop(v_x_2418);
              heff_drop(v_ru_24it1_2417_24MkPair);
              heff_drop(v_t_2425);
              heff_drop(v_t_2426);
              V v_t_2435 = heff_arrayIndex(v_ts_240, v_j_2419);
              V v_t_2436 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2435, LBL_start), ((V)&g_heff_2eproject_2efieldsGo_24s728_str10)});
              return heff_tag_at(v_ru_24it_2415_24Right, TAG_Left, 1, (V[]){v_t_2436});
            }
            default: return heff_nomatch(v_t_2426);
            }
          }
          default: return heff_nomatch(v_t_2422);
          }
        }
        default: return heff_nomatch(v_it1_2417);
        }
      }
      default: return heff_nomatch(v_it_2415);
      }
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eproject_2efieldsGo_24s728_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2efieldsGo_24s728(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2elitF_24s726_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 116, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2elitF_24s726_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eproject_2elitF_24s726_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2elitF_24s726_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eproject_2elitF_24s726_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2elitF_24s726_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eproject_2elitF_24s726_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2elitF_24s726_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[84]; } g_heff_2eproject_2elitF_24s726_str8 = {{0x80000000u, K_STR, 0}, 84, 84, {97, 32, 109, 97, 110, 105, 102, 101, 115, 116, 32, 104, 111, 108, 100, 115, 32, 115, 116, 114, 105, 110, 103, 115, 44, 32, 116, 97, 103, 115, 32, 96, 39, 120, 96, 44, 32, 108, 105, 115, 116, 115, 32, 96, 91, 46, 46, 46, 93, 96, 32, 97, 110, 100, 32, 114, 101, 99, 111, 114, 100, 115, 32, 96, 123, 46, 46, 46, 125, 96, 44, 32, 110, 111, 116, 104, 105, 110, 103, 32, 101, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[84]; } g_heff_2eproject_2elitF_24s726_str9 = {{0x80000000u, K_STR, 0}, 84, 84, {97, 32, 109, 97, 110, 105, 102, 101, 115, 116, 32, 104, 111, 108, 100, 115, 32, 115, 116, 114, 105, 110, 103, 115, 44, 32, 116, 97, 103, 115, 32, 96, 39, 120, 96, 44, 32, 108, 105, 115, 116, 115, 32, 96, 91, 46, 46, 46, 93, 96, 32, 97, 110, 100, 32, 114, 101, 99, 111, 114, 100, 115, 32, 96, 123, 46, 46, 46, 125, 96, 44, 32, 110, 111, 116, 104, 105, 110, 103, 32, 101, 108, 115, 101}};
Clo g_heff_2eproject_2elitF_24s726_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2elitF_24s726_entry, 2, 0};

V g_heff_2eproject_2elitF_24s726(V v_ts_240, V v_i_241) {
top: ;
  V v_t_242 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
  V v_t_243 = heff_strEq(heff_get(v_t_242, LBL_kind), ((V)&g_heff_2eproject_2elitF_24s726_str0));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_t_243);
    V v_t_244 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
    V v_t_245 = heff_arrayIndex(v_ts_240, heff_dup(v_i_241));
    V v_t_246 = heff_tag(TAG_LStr, 2, (V[]){heff_get(v_t_244, LBL_text), v_t_245});
    V v_t_247 = heff_tag(TAG_MkPair, 2, (V[]){v_t_246, heff_intAdd(v_i_241, MK_INT(1LL))});
    return heff_tag(TAG_Right, 1, (V[]){v_t_247});
  }
  case TAG_False: {
    heff_drop(v_t_243);
    V v_t_248 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
    V v_t_249 = heff_strEq(heff_get(v_t_248, LBL_kind), ((V)&g_heff_2eproject_2elitF_24s726_str1));
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_t_249);
      V v_t_2410 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
      V v_t_2411 = heff_arrayIndex(v_ts_240, heff_dup(v_i_241));
      V v_t_2412 = heff_tag(TAG_LTag, 2, (V[]){heff_get(v_t_2410, LBL_text), v_t_2411});
      V v_t_2413 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2412, heff_intAdd(v_i_241, MK_INT(1LL))});
      return heff_tag(TAG_Right, 1, (V[]){v_t_2413});
    }
    case TAG_False: {
      heff_drop(v_t_249);
      V v_t_2414 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
      V v_t_2415 = heff_strEq(heff_get(heff_dup(v_t_2414), LBL_kind), ((V)&g_heff_2eproject_2elitF_24s726_str2));
      V v_t_2416;
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop(v_t_2415);
        v_t_2416 = heff_strEq(heff_get(v_t_2414, LBL_text), ((V)&g_heff_2eproject_2elitF_24s726_str3));
        break;
      }
      case TAG_False: {
        heff_drop(v_t_2414);
        heff_drop(v_t_2415);
        v_t_2416 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2415);
      }
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        heff_drop(v_t_2416);
        V v_t_2417 = heff_arrayIndex(heff_dup(v_ts_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
        V v_t_2418 = heff_strEq(heff_get(heff_dup(v_t_2417), LBL_kind), ((V)&g_heff_2eproject_2elitF_24s726_str4));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_True: {
          heff_drop(v_t_2418);
          V v_t_2419 = heff_strEq(heff_get(v_t_2417, LBL_text), ((V)&g_heff_2eproject_2elitF_24s726_str5));
          switch (heff_tag_of(v_t_2419)) {
          case TAG_True: {
            heff_drop(v_t_2419);
            V v_t_2420 = heff_arrayIndex(v_ts_240, heff_dup(v_i_241));
            V v_t_2421 = heff_tag(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_2420});
            V v_t_2422 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2421, heff_intAdd(v_i_241, MK_INT(2LL))});
            return heff_tag(TAG_Right, 1, (V[]){v_t_2422});
          }
          case TAG_False: {
            heff_drop(v_t_2419);
            V v_t_2423 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
            V v_x2_2424 = (g_heff_2eproject_2eitemsGo_24s727(v_ts_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_Nil)));
            switch (heff_tag_of(v_x2_2424)) {
            case TAG_Left: {
              V v_p_2425 = heff_field(v_x2_2424, 0);
              V v_ru_24x2_2424_24Left = heff_take_reuse(v_x2_2424, 1ULL);
              heff_drop(v_t_2423);
              return heff_tag_at(v_ru_24x2_2424_24Left, TAG_Left, 1, (V[]){v_p_2425});
            }
            case TAG_Right: {
              V v_x21_2426 = heff_field(v_x2_2424, 0);
              V v_ru_24x2_2424_24Right = heff_take_reuse(v_x2_2424, 1ULL);
              switch (heff_tag_of(v_x21_2426)) {
              case TAG_MkPair: {
                V v_xs_2427 = heff_field(v_x21_2426, 0);
                V v_j_2428 = heff_field(v_x21_2426, 1);
                V v_ru_24x21_2426_24MkPair = heff_take_reuse(v_x21_2426, 3ULL);
                V v_t_2429 = heff_tag_at(v_ru_24x21_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_LList, 2, (V[]){v_xs_2427, v_t_2423}), v_j_2428});
                return heff_tag_at(v_ru_24x2_2424_24Right, TAG_Right, 1, (V[]){v_t_2429});
              }
              default: return heff_nomatch(v_x21_2426);
              }
            }
            default: return heff_nomatch(v_x2_2424);
            }
          }
          default: return heff_nomatch(v_t_2419);
          }
        }
        case TAG_False: {
          heff_drop(v_t_2417);
          heff_drop(v_t_2418);
          V v_t_2430 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
          V v_x2_2431 = (g_heff_2eproject_2eitemsGo_24s727(v_ts_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_Nil)));
          switch (heff_tag_of(v_x2_2431)) {
          case TAG_Left: {
            V v_p_2432 = heff_field(v_x2_2431, 0);
            V v_ru_24x2_2431_24Left = heff_take_reuse(v_x2_2431, 1ULL);
            heff_drop(v_t_2430);
            return heff_tag_at(v_ru_24x2_2431_24Left, TAG_Left, 1, (V[]){v_p_2432});
          }
          case TAG_Right: {
            V v_x21_2433 = heff_field(v_x2_2431, 0);
            V v_ru_24x2_2431_24Right = heff_take_reuse(v_x2_2431, 1ULL);
            switch (heff_tag_of(v_x21_2433)) {
            case TAG_MkPair: {
              V v_xs_2434 = heff_field(v_x21_2433, 0);
              V v_j_2435 = heff_field(v_x21_2433, 1);
              V v_ru_24x21_2433_24MkPair = heff_take_reuse(v_x21_2433, 3ULL);
              V v_t_2436 = heff_tag_at(v_ru_24x21_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_LList, 2, (V[]){v_xs_2434, v_t_2430}), v_j_2435});
              return heff_tag_at(v_ru_24x2_2431_24Right, TAG_Right, 1, (V[]){v_t_2436});
            }
            default: return heff_nomatch(v_x21_2433);
            }
          }
          default: return heff_nomatch(v_x2_2431);
          }
        }
        default: return heff_nomatch(v_t_2418);
        }
      }
      case TAG_False: {
        heff_drop(v_t_2416);
        V v_t_2437 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
        V v_t_2438 = heff_strEq(heff_get(heff_dup(v_t_2437), LBL_kind), ((V)&g_heff_2eproject_2elitF_24s726_str6));
        switch (heff_tag_of(v_t_2438)) {
        case TAG_True: {
          heff_drop(v_t_2438);
          V v_t_2439 = heff_strEq(heff_get(v_t_2437, LBL_text), ((V)&g_heff_2eproject_2elitF_24s726_str7));
          switch (heff_tag_of(v_t_2439)) {
          case TAG_True: {
            heff_drop(v_t_2439);
            V v_t_2440 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
            V v_x2_2441 = (g_heff_2eproject_2efieldsGo_24s728(v_ts_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_Nil)));
            switch (heff_tag_of(v_x2_2441)) {
            case TAG_Left: {
              V v_p_2442 = heff_field(v_x2_2441, 0);
              V v_ru_24x2_2441_24Left = heff_take_reuse(v_x2_2441, 1ULL);
              heff_drop(v_t_2440);
              return heff_tag_at(v_ru_24x2_2441_24Left, TAG_Left, 1, (V[]){v_p_2442});
            }
            case TAG_Right: {
              V v_x21_2443 = heff_field(v_x2_2441, 0);
              V v_ru_24x2_2441_24Right = heff_take_reuse(v_x2_2441, 1ULL);
              switch (heff_tag_of(v_x21_2443)) {
              case TAG_MkPair: {
                V v_fs_2444 = heff_field(v_x21_2443, 0);
                V v_j_2445 = heff_field(v_x21_2443, 1);
                V v_ru_24x21_2443_24MkPair = heff_take_reuse(v_x21_2443, 3ULL);
                V v_t_2446 = heff_tag_at(v_ru_24x21_2443_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_LRec, 2, (V[]){v_fs_2444, v_t_2440}), v_j_2445});
                return heff_tag_at(v_ru_24x2_2441_24Right, TAG_Right, 1, (V[]){v_t_2446});
              }
              default: return heff_nomatch(v_x21_2443);
              }
            }
            default: return heff_nomatch(v_x2_2441);
            }
          }
          case TAG_False: {
            heff_drop(v_t_2439);
            V v_t_2447 = heff_arrayIndex(v_ts_240, v_i_241);
            V v_t_2448 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2447, LBL_start), ((V)&g_heff_2eproject_2elitF_24s726_str8)});
            return heff_tag(TAG_Left, 1, (V[]){v_t_2448});
          }
          default: return heff_nomatch(v_t_2439);
          }
        }
        case TAG_False: {
          heff_drop(v_t_2437);
          heff_drop(v_t_2438);
          V v_t_2449 = heff_arrayIndex(v_ts_240, v_i_241);
          V v_t_2450 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2449, LBL_start), ((V)&g_heff_2eproject_2elitF_24s726_str9)});
          return heff_tag(TAG_Left, 1, (V[]){v_t_2450});
        }
        default: return heff_nomatch(v_t_2438);
        }
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eproject_2elitF_24s726_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2elitF_24s726(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2edeclsGo_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eproject_2edeclsGo_str1 = {{0x80000000u, K_STR, 0}, 13, 13, {32, 100, 101, 102, 105, 110, 101, 115, 32, 110, 111, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2edeclsGo_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eproject_2edeclsGo_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eproject_2edeclsGo_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 109, 112, 111, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2edeclsGo_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2edeclsGo_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2edeclsGo_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2edeclsGo_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2edeclsGo_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2edeclsGo_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2edeclsGo_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2edeclsGo_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[38]; } g_heff_2eproject_2edeclsGo_str13 = {{0x80000000u, K_STR, 0}, 38, 38, {96, 32, 105, 115, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 97, 110, 100, 32, 110, 111, 116, 104, 105, 110, 103, 32, 102, 111, 108, 108, 111, 119, 115, 32, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2edeclsGo_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[38]; } g_heff_2eproject_2edeclsGo_str15 = {{0x80000000u, K_STR, 0}, 38, 38, {96, 32, 105, 115, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 97, 110, 100, 32, 110, 111, 116, 104, 105, 110, 103, 32, 102, 111, 108, 108, 111, 119, 115, 32, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2edeclsGo_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eproject_2edeclsGo_str17 = {{0x80000000u, K_STR, 0}, 27, 27, {96, 32, 105, 115, 32, 100, 101, 102, 105, 110, 101, 100, 32, 109, 111, 114, 101, 32, 116, 104, 97, 110, 32, 111, 110, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2eproject_2edeclsGo_str18 = {{0x80000000u, K_STR, 0}, 21, 21, {32, 104, 111, 108, 100, 115, 32, 105, 109, 112, 111, 114, 116, 115, 44, 32, 97, 110, 100, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[50]; } g_heff_2eproject_2edeclsGo_str19 = {{0x80000000u, K_STR, 0}, 50, 50, {96, 32, 40, 105, 116, 115, 32, 115, 105, 103, 110, 97, 116, 117, 114, 101, 32, 97, 110, 100, 32, 105, 116, 115, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 41, 44, 32, 110, 111, 116, 104, 105, 110, 103, 32, 101, 108, 115, 101}};
Clo g_heff_2eproject_2edeclsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2edeclsGo_entry, 5, 0};

V g_heff_2eproject_2edeclsGo(V v_file_240, V v_name_241, V v_ts_242, V v_i_243, V v_found_244) {
top: ;
  V v_t_245 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
  V v_t_246 = heff_strEq(heff_get(v_t_245, LBL_kind), ((V)&g_heff_2eproject_2edeclsGo_str0));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_t_246);
    switch (heff_tag_of(v_found_244)) {
    case TAG_Nothing: {
      heff_drop(v_found_244);
      V v_t_247 = heff_arrayIndex(v_ts_242, v_i_243);
      V v_t_248 = heff_strAppend(v_file_240, heff_strAppend(((V)&g_heff_2eproject_2edeclsGo_str1), heff_strAppend(v_name_241, ((V)&g_heff_2eproject_2edeclsGo_str2))));
      V v_t_249 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_247, LBL_start), v_t_248});
      return heff_tag(TAG_Left, 1, (V[]){v_t_249});
    }
    case TAG_Just: {
      V v_x_2410 = heff_field(v_found_244, 0);
      V v_ru_24found_244_24Just = heff_take_reuse(v_found_244, 1ULL);
      heff_drop(v_file_240);
      heff_drop(v_name_241);
      heff_drop(v_ts_242);
      heff_drop(v_i_243);
      return heff_tag_at(v_ru_24found_244_24Just, TAG_Right, 1, (V[]){v_x_2410});
    }
    default: return heff_nomatch(v_found_244);
    }
  }
  case TAG_False: {
    heff_drop(v_t_246);
    V v_t_2411 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
    V v_t_2412 = heff_strEq(heff_get(v_t_2411, LBL_kind), ((V)&g_heff_2eproject_2edeclsGo_str3));
    V v_t_2414;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_t_2412);
      V v_t_2413 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
      v_t_2414 = heff_strEq(heff_get(v_t_2413, LBL_text), ((V)&g_heff_2eproject_2edeclsGo_str4));
      break;
    }
    case TAG_False: {
      heff_drop(v_t_2412);
      v_t_2414 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      heff_drop(v_t_2414);
      V v_t_2415 = (g_heff_2eproject_2enextDecl(heff_dup(v_ts_242), heff_intAdd(v_i_243, MK_INT(1LL))));
      V t_0 = v_file_240;
      V t_1 = v_name_241;
      V t_2 = v_ts_242;
      V t_3 = v_t_2415;
      V t_4 = v_found_244;
      v_file_240 = t_0;
      v_name_241 = t_1;
      v_ts_242 = t_2;
      v_i_243 = t_3;
      v_found_244 = t_4;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_t_2414);
      V v_t_2416 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
      V v_t_2417 = heff_strEq(heff_get(v_t_2416, LBL_kind), ((V)&g_heff_2eproject_2edeclsGo_str5));
      V v_t_2422;
      switch (heff_tag_of(v_t_2417)) {
      case TAG_True: {
        heff_drop(v_t_2417);
        V v_t_2418 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
        V v_t_2419 = heff_strEq(heff_get(v_t_2418, LBL_text), heff_dup(v_name_241));
        switch (heff_tag_of(v_t_2419)) {
        case TAG_True: {
          heff_drop(v_t_2419);
          V v_t_2420 = heff_arrayIndex(heff_dup(v_ts_242), heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
          V v_t_2421 = heff_strEq(heff_get(heff_dup(v_t_2420), LBL_kind), ((V)&g_heff_2eproject_2edeclsGo_str6));
          switch (heff_tag_of(v_t_2421)) {
          case TAG_True: {
            heff_drop(v_t_2421);
            v_t_2422 = heff_strEq(heff_get(v_t_2420, LBL_text), ((V)&g_heff_2eproject_2edeclsGo_str7));
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2420);
            heff_drop(v_t_2421);
            v_t_2422 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          break;
        }
        case TAG_False: {
          heff_drop(v_t_2419);
          v_t_2422 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2419);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_t_2417);
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      switch (heff_tag_of(v_t_2422)) {
      case TAG_True: {
        heff_drop(v_t_2422);
        V v_t_2423 = (g_heff_2eproject_2enextDecl(heff_dup(v_ts_242), heff_intAdd(v_i_243, MK_INT(1LL))));
        V t_0 = v_file_240;
        V t_1 = v_name_241;
        V t_2 = v_ts_242;
        V t_3 = v_t_2423;
        V t_4 = v_found_244;
        v_file_240 = t_0;
        v_name_241 = t_1;
        v_ts_242 = t_2;
        v_i_243 = t_3;
        v_found_244 = t_4;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_t_2422);
        V v_t_2424 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
        V v_t_2425 = heff_strEq(heff_get(v_t_2424, LBL_kind), ((V)&g_heff_2eproject_2edeclsGo_str8));
        V v_t_2430;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_True: {
          heff_drop(v_t_2425);
          V v_t_2426 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
          V v_t_2427 = heff_strEq(heff_get(v_t_2426, LBL_text), heff_dup(v_name_241));
          switch (heff_tag_of(v_t_2427)) {
          case TAG_True: {
            heff_drop(v_t_2427);
            V v_t_2428 = heff_arrayIndex(heff_dup(v_ts_242), heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
            V v_t_2429 = heff_strEq(heff_get(heff_dup(v_t_2428), LBL_kind), ((V)&g_heff_2eproject_2edeclsGo_str9));
            switch (heff_tag_of(v_t_2429)) {
            case TAG_True: {
              heff_drop(v_t_2429);
              v_t_2430 = heff_strEq(heff_get(v_t_2428, LBL_text), ((V)&g_heff_2eproject_2edeclsGo_str10));
              break;
            }
            case TAG_False: {
              heff_drop(v_t_2428);
              heff_drop(v_t_2429);
              v_t_2430 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_t_2429);
            }
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2427);
            v_t_2430 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_t_2427);
          }
          break;
        }
        case TAG_False: {
          heff_drop(v_t_2425);
          v_t_2430 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        switch (heff_tag_of(v_t_2430)) {
        case TAG_True: {
          heff_drop(v_t_2430);
          switch (heff_tag_of(v_found_244)) {
          case TAG_Nothing: {
            heff_drop(v_found_244);
            V v_it_2431 = (g_heff_2eproject_2elitF_24s726(heff_dup(v_ts_242), heff_intAdd(v_i_243, MK_INT(2LL))));
            switch (heff_tag_of(v_it_2431)) {
            case TAG_Left: {
              V v_p_2432 = heff_field(v_it_2431, 0);
              V v_ru_24it_2431_24Left = heff_take_reuse(v_it_2431, 1ULL);
              heff_drop(v_file_240);
              heff_drop(v_name_241);
              heff_drop(v_ts_242);
              return heff_tag_at(v_ru_24it_2431_24Left, TAG_Left, 1, (V[]){v_p_2432});
            }
            case TAG_Right: {
              V v_it1_2433 = heff_field(v_it_2431, 0);
              V v_ru_24it_2431_24Right = heff_take_reuse(v_it_2431, 1ULL);
              switch (heff_tag_of(v_it1_2433)) {
              case TAG_MkPair: {
                V v_x_2434 = heff_field(v_it1_2433, 0);
                V v_j_2435 = heff_field(v_it1_2433, 1);
                heff_take(v_it1_2433, 3ULL);
                V v_t_2436 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_j_2435));
                V v_t_2437 = heff_strEq(heff_get(heff_dup(v_t_2436), LBL_kind), ((V)&g_heff_2eproject_2edeclsGo_str11));
                switch (heff_tag_of(v_t_2437)) {
                case TAG_True: {
                  heff_drop(v_t_2436);
                  heff_drop(v_t_2437);
                  V t_0 = v_file_240;
                  V t_1 = v_name_241;
                  V t_2 = v_ts_242;
                  V t_3 = v_j_2435;
                  V t_4 = heff_tag_at(v_ru_24it_2431_24Right, TAG_Just, 1, (V[]){v_x_2434});
                  v_file_240 = t_0;
                  v_name_241 = t_1;
                  v_ts_242 = t_2;
                  v_i_243 = t_3;
                  v_found_244 = t_4;
                  goto top;
                }
                case TAG_False: {
                  heff_drop(v_t_2437);
                  V v_t_2438 = heff_get(heff_dup(v_t_2436), LBL_first);
                  switch (heff_tag_of(v_t_2438)) {
                  case TAG_True: {
                    heff_drop(v_t_2438);
                    V v_t_2439 = heff_intEq(heff_get(v_t_2436, LBL_col), MK_INT(0LL));
                    switch (heff_tag_of(v_t_2439)) {
                    case TAG_True: {
                      heff_drop(v_t_2439);
                      V t_0 = v_file_240;
                      V t_1 = v_name_241;
                      V t_2 = v_ts_242;
                      V t_3 = v_j_2435;
                      V t_4 = heff_tag_at(v_ru_24it_2431_24Right, TAG_Just, 1, (V[]){v_x_2434});
                      v_file_240 = t_0;
                      v_name_241 = t_1;
                      v_ts_242 = t_2;
                      v_i_243 = t_3;
                      v_found_244 = t_4;
                      goto top;
                    }
                    case TAG_False: {
                      heff_drop(v_file_240);
                      heff_drop(v_x_2434);
                      heff_drop(v_t_2439);
                      V v_t_2440 = heff_arrayIndex(v_ts_242, v_j_2435);
                      V v_t_2441 = heff_strAppend(((V)&g_heff_2eproject_2edeclsGo_str12), heff_strAppend(v_name_241, ((V)&g_heff_2eproject_2edeclsGo_str13)));
                      V v_t_2442 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2440, LBL_start), v_t_2441});
                      return heff_tag_at(v_ru_24it_2431_24Right, TAG_Left, 1, (V[]){v_t_2442});
                    }
                    default: return heff_nomatch(v_t_2439);
                    }
                  }
                  case TAG_False: {
                    heff_drop(v_file_240);
                    heff_drop(v_x_2434);
                    heff_drop(v_t_2436);
                    heff_drop(v_t_2438);
                    V v_t_2443 = heff_arrayIndex(v_ts_242, v_j_2435);
                    V v_t_2444 = heff_strAppend(((V)&g_heff_2eproject_2edeclsGo_str14), heff_strAppend(v_name_241, ((V)&g_heff_2eproject_2edeclsGo_str15)));
                    V v_t_2445 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2443, LBL_start), v_t_2444});
                    return heff_tag_at(v_ru_24it_2431_24Right, TAG_Left, 1, (V[]){v_t_2445});
                  }
                  default: return heff_nomatch(v_t_2438);
                  }
                }
                default: return heff_nomatch(v_t_2437);
                }
              }
              default: return heff_nomatch(v_it1_2433);
              }
            }
            default: return heff_nomatch(v_it_2431);
            }
          }
          case TAG_Just: {
            V v_ru_24found_244_24Just = heff_take_reuse(v_found_244, 0ULL);
            heff_drop(v_file_240);
            V v_t_2447 = heff_arrayIndex(v_ts_242, v_i_243);
            V v_t_2448 = heff_strAppend(((V)&g_heff_2eproject_2edeclsGo_str16), heff_strAppend(v_name_241, ((V)&g_heff_2eproject_2edeclsGo_str17)));
            V v_t_2449 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2447, LBL_start), v_t_2448});
            return heff_tag_at(v_ru_24found_244_24Just, TAG_Left, 1, (V[]){v_t_2449});
          }
          default: return heff_nomatch(v_found_244);
          }
        }
        case TAG_False: {
          heff_drop(v_found_244);
          heff_drop(v_t_2430);
          V v_t_2450 = heff_arrayIndex(v_ts_242, v_i_243);
          V v_t_2451 = heff_strAppend(v_file_240, heff_strAppend(((V)&g_heff_2eproject_2edeclsGo_str18), heff_strAppend(v_name_241, ((V)&g_heff_2eproject_2edeclsGo_str19))));
          V v_t_2452 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2450, LBL_start), v_t_2451});
          return heff_tag(TAG_Left, 1, (V[]){v_t_2452});
        }
        default: return heff_nomatch(v_t_2430);
        }
      }
      default: return heff_nomatch(v_t_2422);
      }
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eproject_2edeclsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2edeclsGo(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eproject_2erangeFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2erangeFrom_entry, 2, 0};

V g_heff_2eproject_2erangeFrom(V v_i_240, V v_n_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_n_241), heff_dup(v_i_240));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_i_240);
    heff_drop(v_n_241);
    heff_drop(v_t_242);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    heff_drop(v_t_242);
    return heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_i_240), (g_heff_2eproject_2erangeFrom(heff_intAdd(v_i_240, MK_INT(1LL)), v_n_241))});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eproject_2erangeFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2erangeFrom(a[0], a[1]);
}
V g_heff_2eproject_2eisNumber_lam0(V self, V *args);
Clo g_heff_2eproject_2eisNumber_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2eisNumber_entry, 1, 0};

V g_heff_2eproject_2eisNumber(V v_s_240) {
top: ;
  V v_t_241 = heff_intLt(MK_INT(0LL), heff_strLength(heff_dup(v_s_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_t_241);
    V v_t_242 = (g_heff_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength(heff_dup(v_s_240))));
    V v_t_244 = (g_prelude_2emap(heff_clo(g_heff_2eproject_2eisNumber_lam0, 1, 1, (V[]){heff_dup(v_s_240)}), v_t_242));
    V v_t_245 = ({ V a_0 = v_t_244; V r_ = (g_prelude_2eall_24s729(a_0)); heff_drop(v_t_244); r_; });
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      V v_t_246 = heff_intEq(heff_strLength(heff_dup(v_s_240)), MK_INT(1LL));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_s_240);
        heff_drop(v_t_246);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        heff_drop(v_t_246);
        V v_t_247 = heff_intEq(heff_strCharCode(v_s_240, MK_INT(0LL)), MK_INT(48LL));
        switch (heff_tag_of(v_t_247)) {
        case TAG_True: {
          heff_drop(v_t_247);
          return NTAG(TAG_False);
        }
        case TAG_False: {
          heff_drop(v_t_247);
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t_247);
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_False: {
      heff_drop(v_s_240);
      heff_drop(v_t_245);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_False: {
    heff_drop(v_s_240);
    heff_drop(v_t_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eproject_2eisNumber_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2eisNumber(a[0]);
}
V g_heff_2eproject_2eisNumber_lam0(V self, V *args) {
  V v_i_243 = args[0];
  V v_s_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strCharCode(v_s_240, v_i_243);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2eversion_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
Clo g_heff_2eproject_2eversion_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2eversion_entry, 1, 0};

V g_heff_2eproject_2eversion(V v_v_240) {
top: ;
  V v_it_241 = (g_prelude_2esplitFrom(((V)&g_heff_2eproject_2eversion_str0), v_v_240, MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    heff_drop(v_it_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    V v_ru_24it_241_24Cons = heff_take_reuse(v_it_241, 3ULL);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_a_242);
      heff_drop(v_it2_243);
      heff_drop(v_ru_24it_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      V v_ru_24it2_243_24Cons = heff_take_reuse(v_it2_243, 3ULL);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_a_242);
        heff_drop(v_ru_24it_241_24Cons);
        heff_drop(v_b_244);
        heff_drop(v_it22_245);
        heff_drop(v_ru_24it2_243_24Cons);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_c_246 = heff_field(v_it22_245, 0);
        V v_it222_247 = heff_field(v_it22_245, 1);
        heff_take(v_it22_245, 3ULL);
        switch (heff_tag_of(v_it222_247)) {
        case TAG_Nil: {
          heff_drop(v_it222_247);
          V v_t_248 = (g_heff_2eproject_2eisNumber(heff_dup(v_a_242)));
          switch (heff_tag_of(v_t_248)) {
          case TAG_True: {
            heff_drop(v_t_248);
            V v_t_249 = (g_heff_2eproject_2eisNumber(heff_dup(v_b_244)));
            switch (heff_tag_of(v_t_249)) {
            case TAG_True: {
              heff_drop(v_t_249);
              V v_t_2410 = (g_heff_2eproject_2eisNumber(heff_dup(v_c_246)));
              switch (heff_tag_of(v_t_2410)) {
              case TAG_True: {
                heff_drop(v_t_2410);
                V v_t_2411 = heff_tag_at(v_ru_24it_241_24Cons, TAG_Cons, 2, (V[]){v_c_246, NTAG(TAG_Nil)});
                V v_t_2412 = heff_tag_at(v_ru_24it2_243_24Cons, TAG_Cons, 2, (V[]){v_a_242, heff_tag(TAG_Cons, 2, (V[]){v_b_244, v_t_2411})});
                return heff_tag(TAG_Just, 1, (V[]){(g_prelude_2emap_24s730(v_t_2412))});
              }
              case TAG_False: {
                heff_drop(v_a_242);
                heff_drop(v_ru_24it_241_24Cons);
                heff_drop(v_b_244);
                heff_drop(v_ru_24it2_243_24Cons);
                heff_drop(v_c_246);
                heff_drop(v_t_2410);
                return NTAG(TAG_Nothing);
              }
              default: return heff_nomatch(v_t_2410);
              }
            }
            case TAG_False: {
              heff_drop(v_a_242);
              heff_drop(v_ru_24it_241_24Cons);
              heff_drop(v_b_244);
              heff_drop(v_ru_24it2_243_24Cons);
              heff_drop(v_c_246);
              heff_drop(v_t_249);
              return NTAG(TAG_Nothing);
            }
            default: return heff_nomatch(v_t_249);
            }
          }
          case TAG_False: {
            heff_drop(v_a_242);
            heff_drop(v_ru_24it_241_24Cons);
            heff_drop(v_b_244);
            heff_drop(v_ru_24it2_243_24Cons);
            heff_drop(v_c_246);
            heff_drop(v_t_248);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_248);
          }
        }
        case TAG_Cons: {
          heff_take(v_it222_247, 0ULL);
          heff_drop(v_a_242);
          heff_drop(v_ru_24it_241_24Cons);
          heff_drop(v_b_244);
          heff_drop(v_ru_24it2_243_24Cons);
          heff_drop(v_c_246);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it222_247);
        }
      }
      default: return heff_nomatch(v_it22_245);
      }
    }
    default: return heff_nomatch(v_it2_243);
    }
  }
  default: return heff_nomatch(v_it_241);
  }
}
V g_heff_2eproject_2eversion_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2eversion(a[0]);
}
Clo g_heff_2eproject_2ecompatible_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2ecompatible_entry, 2, 0};

V g_heff_2eproject_2ecompatible(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_wa_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_wb_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_wc_246 = heff_field(v_x122_245, 0);
        V v_x1222_247 = heff_field(v_x122_245, 1);
        switch (heff_tag_of(v_x1222_247)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x2_241)) {
          case TAG_Nil: {
            return NTAG(TAG_False);
          }
          case TAG_Cons: {
            V v_ra_248 = heff_field(v_x2_241, 0);
            V v_x22_249 = heff_field(v_x2_241, 1);
            switch (heff_tag_of(v_x22_249)) {
            case TAG_Nil: {
              return NTAG(TAG_False);
            }
            case TAG_Cons: {
              V v_rb_2410 = heff_field(v_x22_249, 0);
              V v_x222_2411 = heff_field(v_x22_249, 1);
              switch (heff_tag_of(v_x222_2411)) {
              case TAG_Nil: {
                return NTAG(TAG_False);
              }
              case TAG_Cons: {
                V v_rc_2412 = heff_field(v_x222_2411, 0);
                V v_x2222_2413 = heff_field(v_x222_2411, 1);
                switch (heff_tag_of(v_x2222_2413)) {
                case TAG_Nil: {
                  V v_t_2414 = heff_intEq(heff_dup(v_wa_242), MK_INT(0LL));
                  switch (heff_tag_of(v_t_2414)) {
                  case TAG_True: {
                    heff_drop(v_t_2414);
                    V v_t_2415 = heff_intEq(heff_dup(v_ra_248), MK_INT(0LL));
                    switch (heff_tag_of(v_t_2415)) {
                    case TAG_True: {
                      heff_drop(v_t_2415);
                      V v_t_2416 = heff_intEq(heff_dup(v_rb_2410), heff_dup(v_wb_244));
                      switch (heff_tag_of(v_t_2416)) {
                      case TAG_True: {
                        heff_drop(v_t_2416);
                        return heff_intLe(heff_dup(v_wc_246), heff_dup(v_rc_2412));
                      }
                      case TAG_False: {
                        heff_drop(v_t_2416);
                        return NTAG(TAG_False);
                      }
                      default: return heff_nomatch(v_t_2416);
                      }
                    }
                    case TAG_False: {
                      heff_drop(v_t_2415);
                      return NTAG(TAG_False);
                    }
                    default: return heff_nomatch(v_t_2415);
                    }
                  }
                  case TAG_False: {
                    heff_drop(v_t_2414);
                    V v_t_2417 = heff_intEq(heff_dup(v_ra_248), heff_dup(v_wa_242));
                    switch (heff_tag_of(v_t_2417)) {
                    case TAG_True: {
                      heff_drop(v_t_2417);
                      V v_t_2418 = heff_intLt(heff_dup(v_wb_244), heff_dup(v_rb_2410));
                      switch (heff_tag_of(v_t_2418)) {
                      case TAG_True: {
                        heff_drop(v_t_2418);
                        return NTAG(TAG_True);
                      }
                      case TAG_False: {
                        heff_drop(v_t_2418);
                        V v_t_2419 = heff_intEq(heff_dup(v_rb_2410), heff_dup(v_wb_244));
                        switch (heff_tag_of(v_t_2419)) {
                        case TAG_True: {
                          heff_drop(v_t_2419);
                          return heff_intLe(heff_dup(v_wc_246), heff_dup(v_rc_2412));
                        }
                        case TAG_False: {
                          heff_drop(v_t_2419);
                          return NTAG(TAG_False);
                        }
                        default: return heff_nomatch(v_t_2419);
                        }
                      }
                      default: return heff_nomatch(v_t_2418);
                      }
                    }
                    case TAG_False: {
                      heff_drop(v_t_2417);
                      return NTAG(TAG_False);
                    }
                    default: return heff_nomatch(v_t_2417);
                    }
                  }
                  default: return heff_nomatch(v_t_2414);
                  }
                }
                case TAG_Cons: {
                  return NTAG(TAG_False);
                }
                default: return heff_nomatch(v_x2222_2413);
                }
              }
              default: return heff_nomatch(v_x222_2411);
              }
            }
            default: return heff_nomatch(v_x22_249);
            }
          }
          default: return heff_nomatch(v_x2_241);
          }
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x1222_247);
        }
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eproject_2ecompatible_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2ecompatible(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2eproject_2eisName_lam0(V self, V *args);
Clo g_heff_2eproject_2eisName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2eisName_entry, 1, 0};

V g_heff_2eproject_2eisName(V v_x_240) {
top: ;
  V v_t_241 = heff_intLt(MK_INT(0LL), heff_strLength(heff_dup(v_x_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_t_241);
    V v_t_242 = heff_intLe(MK_INT(97LL), heff_strCharCode(heff_dup(v_x_240), MK_INT(0LL)));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_t_242);
      V v_t_243 = heff_intLe(heff_strCharCode(heff_dup(v_x_240), MK_INT(0LL)), MK_INT(122LL));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_t_243);
        V v_t_244 = (g_heff_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength(heff_dup(v_x_240))));
        V v_t_246 = (g_prelude_2emap(heff_clo(g_heff_2eproject_2eisName_lam0, 1, 1, (V[]){v_x_240}), v_t_244));
        return ({ V a_0 = v_t_246; V r_ = (g_prelude_2eall_24s731(a_0)); heff_drop(v_t_246); r_; });
      }
      case TAG_False: {
        heff_drop(v_x_240);
        heff_drop(v_t_243);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    case TAG_False: {
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_False: {
    heff_drop(v_x_240);
    heff_drop(v_t_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eproject_2eisName_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2eisName(a[0]);
}
V g_heff_2eproject_2eisName_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_x_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strCharCode(v_x_240, v_i_245);
}
Clo g_heff_2eproject_2esameNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2esameNames_entry, 2, 0};

V g_heff_2eproject_2esameNames(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      V v_t_248 = heff_strEq(heff_dup(v_x_244), heff_dup(v_y_246));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop(v_t_248);
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_t_248);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eproject_2esameNames_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2esameNames(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2efieldsAre_str0 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2efieldsAre_str1 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2efieldsAre_str2 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2efieldsAre_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eproject_2efieldsAre_str4 = {{0x80000000u, K_STR, 0}, 15, 15, {116, 104, 101, 32, 102, 105, 101, 108, 100, 115, 32, 97, 114, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eproject_2efieldsAre_str5 = {{0x80000000u, K_STR, 0}, 15, 15, {44, 32, 105, 110, 32, 116, 104, 105, 115, 32, 111, 114, 100, 101, 114}};
Clo g_heff_2eproject_2efieldsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2efieldsAre_entry, 2, 0};

V g_heff_2eproject_2efieldsAre(V v_names_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x_241)) {
  case TAG_LStr: {
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_245 = heff_field(v_x_241, 1);
      v_t_2412 = heff_dup(v_t_245);
      break;
    }
    case TAG_LTag: {
      V v_t_247 = heff_field(v_x_241, 1);
      v_t_2412 = heff_dup(v_t_247);
      break;
    }
    case TAG_LList: {
      V v_t_249 = heff_field(v_x_241, 1);
      v_t_2412 = heff_dup(v_t_249);
      break;
    }
    case TAG_LRec: {
      V v_t_2411 = heff_field(v_x_241, 1);
      v_t_2412 = heff_dup(v_t_2411);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2413 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2412, LBL_start), ((V)&g_heff_2eproject_2efieldsAre_str0)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2413});
  }
  case TAG_LTag: {
    V v_t_2424;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_2417 = heff_field(v_x_241, 1);
      v_t_2424 = heff_dup(v_t_2417);
      break;
    }
    case TAG_LTag: {
      V v_t_2419 = heff_field(v_x_241, 1);
      v_t_2424 = heff_dup(v_t_2419);
      break;
    }
    case TAG_LList: {
      V v_t_2421 = heff_field(v_x_241, 1);
      v_t_2424 = heff_dup(v_t_2421);
      break;
    }
    case TAG_LRec: {
      V v_t_2423 = heff_field(v_x_241, 1);
      v_t_2424 = heff_dup(v_t_2423);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2425 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2424, LBL_start), ((V)&g_heff_2eproject_2efieldsAre_str1)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2425});
  }
  case TAG_LList: {
    V v_t_2436;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_2429 = heff_field(v_x_241, 1);
      v_t_2436 = heff_dup(v_t_2429);
      break;
    }
    case TAG_LTag: {
      V v_t_2431 = heff_field(v_x_241, 1);
      v_t_2436 = heff_dup(v_t_2431);
      break;
    }
    case TAG_LList: {
      V v_t_2433 = heff_field(v_x_241, 1);
      v_t_2436 = heff_dup(v_t_2433);
      break;
    }
    case TAG_LRec: {
      V v_t_2435 = heff_field(v_x_241, 1);
      v_t_2436 = heff_dup(v_t_2435);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2437 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2436, LBL_start), ((V)&g_heff_2eproject_2efieldsAre_str2)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2437});
  }
  case TAG_LRec: {
    V v_fs_2438 = heff_field(v_x_241, 0);
    V v_t_2439 = heff_field(v_x_241, 1);
    V v_t_2440 = (g_prelude_2emap_24s644(heff_dup(v_fs_2438)));
    V v_t_2441 = ({ V a_0 = v_t_2440; V a_1 = v_names_240; V r_ = (g_heff_2eproject_2esameNames(a_0, a_1)); heff_drop(v_t_2440); r_; });
    switch (heff_tag_of(v_t_2441)) {
    case TAG_True: {
      heff_drop(v_t_2441);
      return heff_tag(TAG_Right, 1, (V[]){(g_prelude_2emap_24s539(heff_dup(v_fs_2438)))});
    }
    case TAG_False: {
      heff_drop(v_t_2441);
      V v_t_2444;
      switch (heff_tag_of(v_names_240)) {
      case TAG_Nil: {
        v_t_2444 = ((V)&g_heff_2eproject_2efieldsAre_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_2442 = heff_field(v_names_240, 0);
        V v_xs_2443 = heff_field(v_names_240, 1);
        v_t_2444 = (g_prelude_2efoldl_24s45(heff_dup(v_x_2442), v_xs_2443));
        break;
      }
      default: heff_nomatch(v_names_240);
      }
      V v_msg_2445 = heff_strAppend(((V)&g_heff_2eproject_2efieldsAre_str4), heff_strAppend(v_t_2444, ((V)&g_heff_2eproject_2efieldsAre_str5)));
      V v_t_2446 = heff_rec(2, shape_15_185, (V[]){heff_get(heff_dup(v_t_2439), LBL_start), v_msg_2445});
      return heff_tag(TAG_Left, 1, (V[]){v_t_2446});
    }
    default: return heff_nomatch(v_t_2441);
    }
  }
  default: return heff_nomatch(v_x_241);
  }
}
V g_heff_2eproject_2efieldsAre_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2efieldsAre(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eproject_2estr_str0 = {{0x80000000u, K_STR, 0}, 17, 17, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 115, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eproject_2estr_str1 = {{0x80000000u, K_STR, 0}, 17, 17, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 115, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eproject_2estr_str2 = {{0x80000000u, K_STR, 0}, 17, 17, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 115, 116, 114, 105, 110, 103}};
Clo g_heff_2eproject_2estr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2estr_entry, 1, 0};

V g_heff_2eproject_2estr(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_s_241 = heff_field(v_x_240, 0);
    return heff_tag(TAG_Right, 1, (V[]){heff_dup(v_s_241)});
  }
  case TAG_LTag: {
    V v_t_2413;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_246 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_246);
      break;
    }
    case TAG_LTag: {
      V v_t_248 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_248);
      break;
    }
    case TAG_LList: {
      V v_t_2410 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_2410);
      break;
    }
    case TAG_LRec: {
      V v_t_2412 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_2412);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2414 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2413, LBL_start), ((V)&g_heff_2eproject_2estr_str0)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2414});
  }
  case TAG_LList: {
    V v_t_2425;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2418 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2418);
      break;
    }
    case TAG_LTag: {
      V v_t_2420 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2420);
      break;
    }
    case TAG_LList: {
      V v_t_2422 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2422);
      break;
    }
    case TAG_LRec: {
      V v_t_2424 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2424);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2426 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2425, LBL_start), ((V)&g_heff_2eproject_2estr_str1)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2426});
  }
  case TAG_LRec: {
    V v_t_2437;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2430 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2430);
      break;
    }
    case TAG_LTag: {
      V v_t_2432 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2432);
      break;
    }
    case TAG_LList: {
      V v_t_2434 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2434);
      break;
    }
    case TAG_LRec: {
      V v_t_2436 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2436);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2438 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2437, LBL_start), ((V)&g_heff_2eproject_2estr_str2)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2438});
  }
  default: return heff_nomatch(v_x_240);
  }
}
V g_heff_2eproject_2estr_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2estr(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2eproject_2eitems_str0 = {{0x80000000u, K_STR, 0}, 23, 23, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 108, 105, 115, 116, 32, 96, 91, 46, 46, 46, 93, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2eproject_2eitems_str1 = {{0x80000000u, K_STR, 0}, 23, 23, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 108, 105, 115, 116, 32, 96, 91, 46, 46, 46, 93, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2eproject_2eitems_str2 = {{0x80000000u, K_STR, 0}, 23, 23, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 108, 105, 115, 116, 32, 96, 91, 46, 46, 46, 93, 96}};
Clo g_heff_2eproject_2eitems_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2eitems_entry, 1, 0};

V g_heff_2eproject_2eitems(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_t_2411;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_244 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_244);
      break;
    }
    case TAG_LTag: {
      V v_t_246 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_246);
      break;
    }
    case TAG_LList: {
      V v_t_248 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_248);
      break;
    }
    case TAG_LRec: {
      V v_t_2410 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_2410);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2412 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2411, LBL_start), ((V)&g_heff_2eproject_2eitems_str0)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2412});
  }
  case TAG_LTag: {
    V v_t_2423;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2416 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2416);
      break;
    }
    case TAG_LTag: {
      V v_t_2418 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2418);
      break;
    }
    case TAG_LList: {
      V v_t_2420 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2420);
      break;
    }
    case TAG_LRec: {
      V v_t_2422 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2422);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2424 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2423, LBL_start), ((V)&g_heff_2eproject_2eitems_str1)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2424});
  }
  case TAG_LList: {
    V v_xs_2425 = heff_field(v_x_240, 0);
    return heff_tag(TAG_Right, 1, (V[]){heff_dup(v_xs_2425)});
  }
  case TAG_LRec: {
    V v_t_2437;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2430 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2430);
      break;
    }
    case TAG_LTag: {
      V v_t_2432 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2432);
      break;
    }
    case TAG_LList: {
      V v_t_2434 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2434);
      break;
    }
    case TAG_LRec: {
      V v_t_2436 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2436);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2438 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2437, LBL_start), ((V)&g_heff_2eproject_2eitems_str2)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2438});
  }
  default: return heff_nomatch(v_x_240);
  }
}
V g_heff_2eproject_2eitems_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2eitems(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2eversionOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2eproject_2eversionOf_str1 = {{0x80000000u, K_STR, 0}, 45, 45, {96, 32, 105, 115, 32, 110, 111, 32, 118, 101, 114, 115, 105, 111, 110, 58, 32, 119, 114, 105, 116, 101, 32, 96, 97, 46, 98, 46, 99, 96, 44, 32, 116, 104, 114, 101, 101, 32, 110, 117, 109, 98, 101, 114, 115}};
Clo g_heff_2eproject_2eversionOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2eversionOf_entry, 1, 0};

V g_heff_2eproject_2eversionOf(V v_x_240) {
top: ;
  V v_t_241 = (g_heff_2eproject_2estr(v_x_240));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Left: {
    V v_p_242 = heff_field(v_t_241, 0);
    V v_ru_24t_241_24Left = heff_take_reuse(v_t_241, 1ULL);
    return heff_tag_at(v_ru_24t_241_24Left, TAG_Left, 1, (V[]){v_p_242});
  }
  case TAG_Right: {
    V v_v_243 = heff_field(v_t_241, 0);
    V v_ru_24t_241_24Right = heff_take_reuse(v_t_241, 1ULL);
    V v_t_244 = (g_heff_2eproject_2eversion(heff_dup(v_v_243)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_t_244);
      V v_t_2413;
      switch (heff_tag_of(v_x_240)) {
      case TAG_LStr: {
        V v_t_246 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_246);
        break;
      }
      case TAG_LTag: {
        V v_t_248 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_248);
        break;
      }
      case TAG_LList: {
        V v_t_2410 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_2410);
        break;
      }
      case TAG_LRec: {
        V v_t_2412 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_2412);
        break;
      }
      default: heff_nomatch(v_x_240);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2eproject_2eversionOf_str0), heff_strAppend(v_v_243, ((V)&g_heff_2eproject_2eversionOf_str1)));
      V v_t_2415 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2413, LBL_start), v_t_2414});
      return heff_tag_at(v_ru_24t_241_24Right, TAG_Left, 1, (V[]){v_t_2415});
    }
    case TAG_Just: {
      heff_take(v_t_244, 0ULL);
      return heff_tag_at(v_ru_24t_241_24Right, TAG_Right, 1, (V[]){v_v_243});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eproject_2eversionOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2eversionOf(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2enameOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[83]; } g_heff_2eproject_2enameOf_str1 = {{0x80000000u, K_STR, 0}, 83, 83, {96, 32, 99, 97, 110, 110, 111, 116, 32, 98, 101, 32, 105, 109, 112, 111, 114, 116, 101, 100, 32, 98, 121, 58, 32, 97, 32, 110, 97, 109, 101, 32, 105, 115, 32, 97, 32, 108, 111, 119, 101, 114, 99, 97, 115, 101, 32, 108, 101, 116, 116, 101, 114, 44, 32, 116, 104, 101, 110, 32, 108, 101, 116, 116, 101, 114, 115, 44, 32, 100, 105, 103, 105, 116, 115, 32, 97, 110, 100, 32, 96, 95, 96}};
Clo g_heff_2eproject_2enameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2enameOf_entry, 1, 0};

V g_heff_2eproject_2enameOf(V v_x_240) {
top: ;
  V v_t_241 = (g_heff_2eproject_2estr(v_x_240));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Left: {
    V v_p_242 = heff_field(v_t_241, 0);
    V v_ru_24t_241_24Left = heff_take_reuse(v_t_241, 1ULL);
    return heff_tag_at(v_ru_24t_241_24Left, TAG_Left, 1, (V[]){v_p_242});
  }
  case TAG_Right: {
    V v_n_243 = heff_field(v_t_241, 0);
    V v_ru_24t_241_24Right = heff_take_reuse(v_t_241, 1ULL);
    V v_t_244 = (g_heff_2eproject_2eisName(heff_dup(v_n_243)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_t_244);
      return heff_tag_at(v_ru_24t_241_24Right, TAG_Right, 1, (V[]){v_n_243});
    }
    case TAG_False: {
      heff_drop(v_t_244);
      V v_t_2413;
      switch (heff_tag_of(v_x_240)) {
      case TAG_LStr: {
        V v_t_246 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_246);
        break;
      }
      case TAG_LTag: {
        V v_t_248 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_248);
        break;
      }
      case TAG_LList: {
        V v_t_2410 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_2410);
        break;
      }
      case TAG_LRec: {
        V v_t_2412 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_2412);
        break;
      }
      default: heff_nomatch(v_x_240);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2eproject_2enameOf_str0), heff_strAppend(v_n_243, ((V)&g_heff_2eproject_2enameOf_str1)));
      V v_t_2415 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2413, LBL_start), v_t_2414});
      return heff_tag_at(v_ru_24t_241_24Right, TAG_Left, 1, (V[]){v_t_2415});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eproject_2enameOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2enameOf(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2emajorMismatch_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2emajorMismatch_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2emajorMismatch_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eproject_2emajorMismatch_str3 = {{0x80000000u, K_STR, 0}, 8, 8, {118, 101, 114, 115, 105, 111, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[44]; } g_heff_2eproject_2emajorMismatch_str4 = {{0x80000000u, K_STR, 0}, 44, 44, {32, 105, 115, 32, 102, 101, 116, 99, 104, 101, 100, 32, 102, 114, 111, 109, 32, 97, 32, 112, 97, 116, 104, 32, 119, 105, 116, 104, 111, 117, 116, 32, 97, 32, 47, 118, 78, 32, 101, 110, 100, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2emajorMismatch_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eproject_2emajorMismatch_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {118, 101, 114, 115, 105, 111, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[35]; } g_heff_2eproject_2emajorMismatch_str7 = {{0x80000000u, K_STR, 0}, 35, 35, {32, 105, 115, 32, 102, 101, 116, 99, 104, 101, 100, 32, 102, 114, 111, 109, 32, 97, 32, 112, 97, 116, 104, 32, 101, 110, 100, 105, 110, 103, 32, 105, 110, 32, 47}};
Clo g_heff_2eproject_2emajorMismatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2emajorMismatch_entry, 2, 0};

V g_heff_2eproject_2emajorMismatch(V v_path_240, V v_v_241) {
top: ;
  V v_x2_242 = (g_heff_2eproject_2eversion(heff_dup(v_v_241)));
  V v_x1_244;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nothing: {
    heff_drop(v_x2_242);
    v_x1_244 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_x2_242, 0);
    heff_take(v_x2_242, 1ULL);
    v_x1_244 = v_x_243;
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_x2_247;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nil: {
    heff_drop(v_x1_244);
    v_x2_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_244, 0);
    heff_take(v_x1_244, 1ULL);
    v_x2_247 = heff_tag(TAG_Just, 1, (V[]){v_x_245});
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_n_249;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    heff_drop(v_x2_247);
    v_n_249 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take(v_x2_247, 1ULL);
    v_n_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2410 = heff_intLe(MK_INT(2LL), heff_dup(v_n_249));
  V v_t_2412;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_t_2410);
    V v_t_2411 = heff_strAppend(((V)&g_heff_2eproject_2emajorMismatch_str0), heff_intShow(v_n_249));
    v_t_2412 = heff_tag(TAG_Just, 1, (V[]){v_t_2411});
    break;
  }
  case TAG_False: {
    heff_drop(v_n_249);
    heff_drop(v_t_2410);
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    heff_drop(v_t_2412);
    V v_xs_2413 = (g_prelude_2esplitFrom(((V)&g_heff_2eproject_2emajorMismatch_str1), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2414 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2413));
    V v_x_2417;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      heff_drop(v_t_2414);
      v_x_2417 = v_path_240;
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_t_2414, 0);
      heff_take(v_t_2414, 1ULL);
      heff_drop(v_path_240);
      v_x_2417 = v_x_2415;
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2418 = heff_intLe(MK_INT(2LL), heff_strLength(heff_dup(v_x_2417)));
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      heff_drop(v_t_2418);
      V v_t_2419 = heff_strEq(heff_strSlice(heff_dup(v_x_2417), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eproject_2emajorMismatch_str2));
      switch (heff_tag_of(v_t_2419)) {
      case TAG_True: {
        heff_drop(v_t_2419);
        V v_t_2420 = heff_strSlice(heff_dup(v_x_2417), MK_INT(1LL), heff_strLength(v_x_2417));
        V v_t_2421 = (g_heff_2eproject_2eisNumber(v_t_2420));
        switch (heff_tag_of(v_t_2421)) {
        case TAG_True: {
          heff_drop(v_t_2421);
          V v_t_2422 = heff_strAppend(((V)&g_heff_2eproject_2emajorMismatch_str3), heff_strAppend(v_v_241, ((V)&g_heff_2eproject_2emajorMismatch_str4)));
          return heff_tag(TAG_Just, 1, (V[]){v_t_2422});
        }
        case TAG_False: {
          heff_drop(v_v_241);
          heff_drop(v_t_2421);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_t_2421);
        }
      }
      case TAG_False: {
        heff_drop(v_v_241);
        heff_drop(v_x_2417);
        heff_drop(v_t_2419);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_2419);
      }
    }
    case TAG_False: {
      heff_drop(v_v_241);
      heff_drop(v_x_2417);
      heff_drop(v_t_2418);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  case TAG_Just: {
    V v_suffix_2423 = heff_field(v_t_2412, 0);
    V v_ru_24t_2412_24Just = heff_take_reuse(v_t_2412, 1ULL);
    V v_xs_2424 = (g_prelude_2esplitFrom(((V)&g_heff_2eproject_2emajorMismatch_str5), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2425 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2424));
    V v_t_2428;
    switch (heff_tag_of(v_t_2425)) {
    case TAG_Nil: {
      heff_drop(v_t_2425);
      v_t_2428 = v_path_240;
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_t_2425, 0);
      heff_take(v_t_2425, 1ULL);
      heff_drop(v_path_240);
      v_t_2428 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_t_2425);
    }
    V v_t_2429 = heff_strEq(v_t_2428, heff_dup(v_suffix_2423));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      heff_drop(v_v_241);
      heff_drop(v_suffix_2423);
      heff_drop(v_ru_24t_2412_24Just);
      heff_drop(v_t_2429);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      heff_drop(v_t_2429);
      V v_t_2430 = heff_strAppend(((V)&g_heff_2eproject_2emajorMismatch_str6), heff_strAppend(v_v_241, heff_strAppend(((V)&g_heff_2eproject_2emajorMismatch_str7), v_suffix_2423)));
      return heff_tag_at(v_ru_24t_2412_24Just, TAG_Just, 1, (V[]){v_t_2430});
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2eproject_2emajorMismatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2emajorMismatch(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eproject_2erequireOf_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {118, 101, 114, 115, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eproject_2erequireOf_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eproject_2erequireOf_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2erequireOf_str3 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2erequireOf_str4 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2erequireOf_str5 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2erequireOf_str6 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
Clo g_heff_2eproject_2erequireOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2erequireOf_entry, 1, 0};

V g_heff_2eproject_2erequireOf(V v_x_240) {
top: ;
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eproject_2erequireOf_str0), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eproject_2erequireOf_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eproject_2erequireOf_str2), v_t_241})});
  V v_it_243 = ({ V a_0 = v_t_242; V a_1 = v_x_240; V r_ = (g_heff_2eproject_2efieldsAre(a_0, a_1)); heff_drop(v_t_242); r_; });
  switch (heff_tag_of(v_it_243)) {
  case TAG_Left: {
    V v_p_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Left = heff_take_reuse(v_it_243, 1ULL);
    return heff_tag_at(v_ru_24it_243_24Left, TAG_Left, 1, (V[]){v_p_244});
  }
  case TAG_Right: {
    V v_it1_245 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Right = heff_take_reuse(v_it_243, 1ULL);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_Nil: {
      heff_drop(v_it1_245);
      V v_t_2414;
      switch (heff_tag_of(v_x_240)) {
      case TAG_LStr: {
        V v_t_247 = heff_field(v_x_240, 1);
        v_t_2414 = heff_dup(v_t_247);
        break;
      }
      case TAG_LTag: {
        V v_t_249 = heff_field(v_x_240, 1);
        v_t_2414 = heff_dup(v_t_249);
        break;
      }
      case TAG_LList: {
        V v_t_2411 = heff_field(v_x_240, 1);
        v_t_2414 = heff_dup(v_t_2411);
        break;
      }
      case TAG_LRec: {
        V v_t_2413 = heff_field(v_x_240, 1);
        v_t_2414 = heff_dup(v_t_2413);
        break;
      }
      default: heff_nomatch(v_x_240);
      }
      V v_t_2415 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2414, LBL_start), ((V)&g_heff_2eproject_2erequireOf_str3)});
      return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_t_2415});
    }
    case TAG_Cons: {
      V v_n_2416 = heff_field(v_it1_245, 0);
      V v_it12_2417 = heff_field(v_it1_245, 1);
      heff_take(v_it1_245, 3ULL);
      switch (heff_tag_of(v_it12_2417)) {
      case TAG_Nil: {
        heff_drop(v_n_2416);
        heff_drop(v_it12_2417);
        V v_t_2426;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2419 = heff_field(v_x_240, 1);
          v_t_2426 = heff_dup(v_t_2419);
          break;
        }
        case TAG_LTag: {
          V v_t_2421 = heff_field(v_x_240, 1);
          v_t_2426 = heff_dup(v_t_2421);
          break;
        }
        case TAG_LList: {
          V v_t_2423 = heff_field(v_x_240, 1);
          v_t_2426 = heff_dup(v_t_2423);
          break;
        }
        case TAG_LRec: {
          V v_t_2425 = heff_field(v_x_240, 1);
          v_t_2426 = heff_dup(v_t_2425);
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_t_2427 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2426, LBL_start), ((V)&g_heff_2eproject_2erequireOf_str4)});
        return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_t_2427});
      }
      case TAG_Cons: {
        V v_p_2428 = heff_field(v_it12_2417, 0);
        V v_it122_2429 = heff_field(v_it12_2417, 1);
        heff_take(v_it12_2417, 3ULL);
        switch (heff_tag_of(v_it122_2429)) {
        case TAG_Nil: {
          heff_drop(v_n_2416);
          heff_drop(v_p_2428);
          heff_drop(v_it122_2429);
          V v_t_2438;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2431 = heff_field(v_x_240, 1);
            v_t_2438 = heff_dup(v_t_2431);
            break;
          }
          case TAG_LTag: {
            V v_t_2433 = heff_field(v_x_240, 1);
            v_t_2438 = heff_dup(v_t_2433);
            break;
          }
          case TAG_LList: {
            V v_t_2435 = heff_field(v_x_240, 1);
            v_t_2438 = heff_dup(v_t_2435);
            break;
          }
          case TAG_LRec: {
            V v_t_2437 = heff_field(v_x_240, 1);
            v_t_2438 = heff_dup(v_t_2437);
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_t_2439 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2438, LBL_start), ((V)&g_heff_2eproject_2erequireOf_str5)});
          return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_t_2439});
        }
        case TAG_Cons: {
          V v_v_2440 = heff_field(v_it122_2429, 0);
          V v_it1222_2441 = heff_field(v_it122_2429, 1);
          heff_take(v_it122_2429, 3ULL);
          switch (heff_tag_of(v_it1222_2441)) {
          case TAG_Nil: {
            heff_drop(v_it1222_2441);
            V v_t_2442 = ({ V a_0 = v_n_2416; V r_ = (g_heff_2eproject_2enameOf(a_0)); heff_drop(v_n_2416); r_; });
            switch (heff_tag_of(v_t_2442)) {
            case TAG_Left: {
              V v_e_2443 = heff_field(v_t_2442, 0);
              heff_take(v_t_2442, 1ULL);
              heff_drop(v_p_2428);
              heff_drop(v_v_2440);
              return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_e_2443});
            }
            case TAG_Right: {
              V v_name_2444 = heff_field(v_t_2442, 0);
              heff_take(v_t_2442, 1ULL);
              V v_t_2445 = ({ V a_0 = v_v_2440; V r_ = (g_heff_2eproject_2eversionOf(a_0)); heff_drop(v_v_2440); r_; });
              switch (heff_tag_of(v_t_2445)) {
              case TAG_Left: {
                V v_e_2446 = heff_field(v_t_2445, 0);
                heff_take(v_t_2445, 1ULL);
                heff_drop(v_p_2428);
                heff_drop(v_name_2444);
                return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_e_2446});
              }
              case TAG_Right: {
                V v_ver_2447 = heff_field(v_t_2445, 0);
                heff_take(v_t_2445, 1ULL);
                V v_t_2448 = (g_heff_2eproject_2estr(v_p_2428));
                switch (heff_tag_of(v_t_2448)) {
                case TAG_Left: {
                  V v_p_2449 = heff_field(v_t_2448, 0);
                  heff_take(v_t_2448, 1ULL);
                  heff_drop(v_p_2428);
                  heff_drop(v_name_2444);
                  heff_drop(v_ver_2447);
                  return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_p_2449});
                }
                case TAG_Right: {
                  V v_path_2450 = heff_field(v_t_2448, 0);
                  heff_take(v_t_2448, 1ULL);
                  V v_t_2451 = (g_heff_2eproject_2emajorMismatch(heff_dup(v_path_2450), heff_dup(v_ver_2447)));
                  switch (heff_tag_of(v_t_2451)) {
                  case TAG_Nothing: {
                    heff_drop(v_p_2428);
                    heff_drop(v_t_2451);
                    return heff_tag_at(v_ru_24it_243_24Right, TAG_Right, 1, (V[]){heff_rec(3, shape_190_228_355, (V[]){v_name_2444, v_path_2450, v_ver_2447})});
                  }
                  case TAG_Just: {
                    V v_why_2452 = heff_field(v_t_2451, 0);
                    heff_take(v_t_2451, 1ULL);
                    heff_drop(v_name_2444);
                    heff_drop(v_ver_2447);
                    heff_drop(v_path_2450);
                    V v_t_2461;
                    switch (heff_tag_of(v_p_2428)) {
                    case TAG_LStr: {
                      V v_t_2454 = heff_field(v_p_2428, 1);
                      heff_take(v_p_2428, 2ULL);
                      v_t_2461 = v_t_2454;
                      break;
                    }
                    case TAG_LTag: {
                      V v_t_2456 = heff_field(v_p_2428, 1);
                      heff_take(v_p_2428, 2ULL);
                      v_t_2461 = v_t_2456;
                      break;
                    }
                    case TAG_LList: {
                      V v_t_2458 = heff_field(v_p_2428, 1);
                      heff_take(v_p_2428, 2ULL);
                      v_t_2461 = v_t_2458;
                      break;
                    }
                    case TAG_LRec: {
                      V v_t_2460 = heff_field(v_p_2428, 1);
                      heff_take(v_p_2428, 2ULL);
                      v_t_2461 = v_t_2460;
                      break;
                    }
                    default: heff_nomatch(v_p_2428);
                    }
                    V v_e_2462 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2461, LBL_start), v_why_2452});
                    return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_e_2462});
                  }
                  default: return heff_nomatch(v_t_2451);
                  }
                }
                default: return heff_nomatch(v_t_2448);
                }
              }
              default: return heff_nomatch(v_t_2445);
              }
            }
            default: return heff_nomatch(v_t_2442);
            }
          }
          case TAG_Cons: {
            heff_take(v_it1222_2441, 0ULL);
            heff_drop(v_n_2416);
            heff_drop(v_p_2428);
            heff_drop(v_v_2440);
            V v_t_2473;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2466 = heff_field(v_x_240, 1);
              v_t_2473 = heff_dup(v_t_2466);
              break;
            }
            case TAG_LTag: {
              V v_t_2468 = heff_field(v_x_240, 1);
              v_t_2473 = heff_dup(v_t_2468);
              break;
            }
            case TAG_LList: {
              V v_t_2470 = heff_field(v_x_240, 1);
              v_t_2473 = heff_dup(v_t_2470);
              break;
            }
            case TAG_LRec: {
              V v_t_2472 = heff_field(v_x_240, 1);
              v_t_2473 = heff_dup(v_t_2472);
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_t_2474 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2473, LBL_start), ((V)&g_heff_2eproject_2erequireOf_str6)});
            return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_t_2474});
          }
          default: return heff_nomatch(v_it1222_2441);
          }
        }
        default: return heff_nomatch(v_it122_2429);
        }
      }
      default: return heff_nomatch(v_it12_2417);
      }
    }
    default: return heff_nomatch(v_it1_245);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2eproject_2erequireOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2erequireOf(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2ereplaceOf_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {100, 105, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eproject_2ereplaceOf_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2ereplaceOf_str2 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2ereplaceOf_str3 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2ereplaceOf_str4 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
Clo g_heff_2eproject_2ereplaceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2ereplaceOf_entry, 1, 0};

V g_heff_2eproject_2ereplaceOf(V v_x_240) {
top: ;
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eproject_2ereplaceOf_str0), NTAG(TAG_Nil)});
  V v_it_242 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eproject_2ereplaceOf_str1), v_t_241}); V a_1 = v_x_240; V r_ = (g_heff_2eproject_2efieldsAre(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_242)) {
  case TAG_Left: {
    V v_p_243 = heff_field(v_it_242, 0);
    V v_ru_24it_242_24Left = heff_take_reuse(v_it_242, 1ULL);
    return heff_tag_at(v_ru_24it_242_24Left, TAG_Left, 1, (V[]){v_p_243});
  }
  case TAG_Right: {
    V v_it1_244 = heff_field(v_it_242, 0);
    V v_ru_24it_242_24Right = heff_take_reuse(v_it_242, 1ULL);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_Nil: {
      heff_drop(v_it1_244);
      V v_t_2413;
      switch (heff_tag_of(v_x_240)) {
      case TAG_LStr: {
        V v_t_246 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_246);
        break;
      }
      case TAG_LTag: {
        V v_t_248 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_248);
        break;
      }
      case TAG_LList: {
        V v_t_2410 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_2410);
        break;
      }
      case TAG_LRec: {
        V v_t_2412 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_2412);
        break;
      }
      default: heff_nomatch(v_x_240);
      }
      V v_t_2414 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2413, LBL_start), ((V)&g_heff_2eproject_2ereplaceOf_str2)});
      return heff_tag_at(v_ru_24it_242_24Right, TAG_Left, 1, (V[]){v_t_2414});
    }
    case TAG_Cons: {
      V v_n_2415 = heff_field(v_it1_244, 0);
      V v_it12_2416 = heff_field(v_it1_244, 1);
      heff_take(v_it1_244, 3ULL);
      switch (heff_tag_of(v_it12_2416)) {
      case TAG_Nil: {
        heff_drop(v_n_2415);
        heff_drop(v_it12_2416);
        V v_t_2425;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2418 = heff_field(v_x_240, 1);
          v_t_2425 = heff_dup(v_t_2418);
          break;
        }
        case TAG_LTag: {
          V v_t_2420 = heff_field(v_x_240, 1);
          v_t_2425 = heff_dup(v_t_2420);
          break;
        }
        case TAG_LList: {
          V v_t_2422 = heff_field(v_x_240, 1);
          v_t_2425 = heff_dup(v_t_2422);
          break;
        }
        case TAG_LRec: {
          V v_t_2424 = heff_field(v_x_240, 1);
          v_t_2425 = heff_dup(v_t_2424);
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_t_2426 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2425, LBL_start), ((V)&g_heff_2eproject_2ereplaceOf_str3)});
        return heff_tag_at(v_ru_24it_242_24Right, TAG_Left, 1, (V[]){v_t_2426});
      }
      case TAG_Cons: {
        V v_d_2427 = heff_field(v_it12_2416, 0);
        V v_it122_2428 = heff_field(v_it12_2416, 1);
        heff_take(v_it12_2416, 3ULL);
        switch (heff_tag_of(v_it122_2428)) {
        case TAG_Nil: {
          heff_drop(v_it122_2428);
          V v_t_2429 = ({ V a_0 = v_n_2415; V r_ = (g_heff_2eproject_2enameOf(a_0)); heff_drop(v_n_2415); r_; });
          switch (heff_tag_of(v_t_2429)) {
          case TAG_Left: {
            V v_e_2430 = heff_field(v_t_2429, 0);
            heff_take(v_t_2429, 1ULL);
            heff_drop(v_d_2427);
            return heff_tag_at(v_ru_24it_242_24Right, TAG_Left, 1, (V[]){v_e_2430});
          }
          case TAG_Right: {
            V v_name_2431 = heff_field(v_t_2429, 0);
            heff_take(v_t_2429, 1ULL);
            V v_t_2432 = ({ V a_0 = v_d_2427; V r_ = (g_heff_2eproject_2estr(a_0)); heff_drop(v_d_2427); r_; });
            switch (heff_tag_of(v_t_2432)) {
            case TAG_Left: {
              V v_e_2433 = heff_field(v_t_2432, 0);
              heff_take(v_t_2432, 1ULL);
              heff_drop(v_name_2431);
              return heff_tag_at(v_ru_24it_242_24Right, TAG_Left, 1, (V[]){v_e_2433});
            }
            case TAG_Right: {
              V v_dir_2434 = heff_field(v_t_2432, 0);
              heff_take(v_t_2432, 1ULL);
              return heff_tag_at(v_ru_24it_242_24Right, TAG_Right, 1, (V[]){heff_rec(2, shape_190_60, (V[]){v_name_2431, v_dir_2434})});
            }
            default: return heff_nomatch(v_t_2432);
            }
          }
          default: return heff_nomatch(v_t_2429);
          }
        }
        case TAG_Cons: {
          heff_take(v_it122_2428, 0ULL);
          heff_drop(v_n_2415);
          heff_drop(v_d_2427);
          V v_t_2445;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2438 = heff_field(v_x_240, 1);
            v_t_2445 = heff_dup(v_t_2438);
            break;
          }
          case TAG_LTag: {
            V v_t_2440 = heff_field(v_x_240, 1);
            v_t_2445 = heff_dup(v_t_2440);
            break;
          }
          case TAG_LList: {
            V v_t_2442 = heff_field(v_x_240, 1);
            v_t_2445 = heff_dup(v_t_2442);
            break;
          }
          case TAG_LRec: {
            V v_t_2444 = heff_field(v_x_240, 1);
            v_t_2445 = heff_dup(v_t_2444);
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_t_2446 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2445, LBL_start), ((V)&g_heff_2eproject_2ereplaceOf_str4)});
          return heff_tag_at(v_ru_24it_242_24Right, TAG_Left, 1, (V[]){v_t_2446});
        }
        default: return heff_nomatch(v_it122_2428);
        }
      }
      default: return heff_nomatch(v_it12_2416);
      }
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2eproject_2ereplaceOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2ereplaceOf(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eproject_2etwiceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2etwiceGo_entry, 2, 0};

V g_heff_2eproject_2etwiceGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    heff_drop(v_x2_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse(v_x2_241, 3ULL);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 3ULL);
      V v_t_246 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_n_244)}));
      V v_t_247 = (g_prelude_2eany(v_t_246, v_seen_240));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_seen_240);
        heff_drop(v_rest_243);
        heff_drop(v_t_247);
        return heff_tag(TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_n_244, v_x_245})});
      }
      case TAG_False: {
        heff_drop(v_x_245);
        heff_drop(v_t_247);
        V t_0 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_n_244, v_seen_240});
        V t_1 = v_rest_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eproject_2etwiceGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2etwiceGo(a[0], a[1]);
}
Clo g_heff_2eproject_2eunrequired_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2eunrequired_entry, 2, 0};

V g_heff_2eproject_2eunrequired(V v_names_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse(v_x2_241, 3ULL);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 3ULL);
      V v_t_246 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_n_244)}));
      V v_t_247 = (g_prelude_2eany(v_t_246, v_names_240));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_ru_24x2_241_24Cons);
        heff_drop(v_n_244);
        heff_drop(v_x_245);
        heff_drop(v_t_247);
        V t_0 = v_names_240;
        V t_1 = v_rest_243;
        v_names_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_rest_243);
        heff_drop(v_t_247);
        return heff_tag(TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_n_244, v_x_245})});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eproject_2eunrequired_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2eunrequired(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2echeckNames_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2eproject_2echeckNames_str1 = {{0x80000000u, K_STR, 0}, 31, 31, {96, 32, 105, 115, 32, 114, 101, 112, 108, 97, 99, 101, 100, 44, 32, 98, 117, 116, 32, 110, 111, 116, 32, 114, 101, 113, 117, 105, 114, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2echeckNames_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eproject_2echeckNames_str3 = {{0x80000000u, K_STR, 0}, 19, 19, {96, 32, 105, 115, 32, 114, 101, 112, 108, 97, 99, 101, 100, 32, 116, 119, 105, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2echeckNames_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eproject_2echeckNames_str5 = {{0x80000000u, K_STR, 0}, 19, 19, {96, 32, 105, 115, 32, 114, 101, 113, 117, 105, 114, 101, 100, 32, 116, 119, 105, 99, 101}};
Clo g_heff_2eproject_2echeckNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2echeckNames_entry, 4, 0};

V g_heff_2eproject_2echeckNames(V v_rxs_240, V v_rs_241, V v_pxs_242, V v_ps_243) {
top: ;
  V v_t_244 = (g_prelude_2ezipWith_24s732(v_rxs_240, heff_dup(v_rs_241)));
  V v_it_245 = (g_heff_2eproject_2etwiceGo(NTAG(TAG_Nil), v_t_244));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    heff_drop(v_it_245);
    V v_t_246 = (g_prelude_2ezipWith_24s732(heff_dup(v_pxs_242), heff_dup(v_ps_243)));
    V v_it_247 = (g_heff_2eproject_2etwiceGo(NTAG(TAG_Nil), v_t_246));
    switch (heff_tag_of(v_it_247)) {
    case TAG_Nothing: {
      heff_drop(v_it_247);
      V v_t_248 = (g_prelude_2emap_24s451(v_rs_241));
      V v_t_249 = (g_prelude_2ezipWith_24s732(v_pxs_242, v_ps_243));
      V v_it_2410 = ({ V a_0 = v_t_248; V a_1 = v_t_249; V r_ = (g_heff_2eproject_2eunrequired(a_0, a_1)); heff_drop(v_t_248); r_; });
      switch (heff_tag_of(v_it_2410)) {
      case TAG_Nothing: {
        heff_drop(v_it_2410);
        return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_Just: {
        V v_it1_2411 = heff_field(v_it_2410, 0);
        V v_ru_24it_2410_24Just = heff_take_reuse(v_it_2410, 1ULL);
        switch (heff_tag_of(v_it1_2411)) {
        case TAG_MkPair: {
          V v_n_2412 = heff_field(v_it1_2411, 0);
          V v_x_2413 = heff_field(v_it1_2411, 1);
          heff_take(v_it1_2411, 3ULL);
          V v_t_2422;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_LStr: {
            V v_t_2415 = heff_field(v_x_2413, 1);
            heff_take(v_x_2413, 2ULL);
            v_t_2422 = v_t_2415;
            break;
          }
          case TAG_LTag: {
            V v_t_2417 = heff_field(v_x_2413, 1);
            heff_take(v_x_2413, 2ULL);
            v_t_2422 = v_t_2417;
            break;
          }
          case TAG_LList: {
            V v_t_2419 = heff_field(v_x_2413, 1);
            heff_take(v_x_2413, 2ULL);
            v_t_2422 = v_t_2419;
            break;
          }
          case TAG_LRec: {
            V v_t_2421 = heff_field(v_x_2413, 1);
            heff_take(v_x_2413, 2ULL);
            v_t_2422 = v_t_2421;
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          V v_t_2423 = heff_strAppend(((V)&g_heff_2eproject_2echeckNames_str0), heff_strAppend(v_n_2412, ((V)&g_heff_2eproject_2echeckNames_str1)));
          V v_t_2424 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2422, LBL_start), v_t_2423});
          return heff_tag_at(v_ru_24it_2410_24Just, TAG_Left, 1, (V[]){v_t_2424});
        }
        default: return heff_nomatch(v_it1_2411);
        }
      }
      default: return heff_nomatch(v_it_2410);
      }
    }
    case TAG_Just: {
      V v_it1_2425 = heff_field(v_it_247, 0);
      V v_ru_24it_247_24Just = heff_take_reuse(v_it_247, 1ULL);
      heff_drop(v_rs_241);
      heff_drop(v_pxs_242);
      heff_drop(v_ps_243);
      switch (heff_tag_of(v_it1_2425)) {
      case TAG_MkPair: {
        V v_n_2426 = heff_field(v_it1_2425, 0);
        V v_x_2427 = heff_field(v_it1_2425, 1);
        heff_take(v_it1_2425, 3ULL);
        V v_t_2436;
        switch (heff_tag_of(v_x_2427)) {
        case TAG_LStr: {
          V v_t_2429 = heff_field(v_x_2427, 1);
          heff_take(v_x_2427, 2ULL);
          v_t_2436 = v_t_2429;
          break;
        }
        case TAG_LTag: {
          V v_t_2431 = heff_field(v_x_2427, 1);
          heff_take(v_x_2427, 2ULL);
          v_t_2436 = v_t_2431;
          break;
        }
        case TAG_LList: {
          V v_t_2433 = heff_field(v_x_2427, 1);
          heff_take(v_x_2427, 2ULL);
          v_t_2436 = v_t_2433;
          break;
        }
        case TAG_LRec: {
          V v_t_2435 = heff_field(v_x_2427, 1);
          heff_take(v_x_2427, 2ULL);
          v_t_2436 = v_t_2435;
          break;
        }
        default: heff_nomatch(v_x_2427);
        }
        V v_t_2437 = heff_strAppend(((V)&g_heff_2eproject_2echeckNames_str2), heff_strAppend(v_n_2426, ((V)&g_heff_2eproject_2echeckNames_str3)));
        V v_t_2438 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2436, LBL_start), v_t_2437});
        return heff_tag_at(v_ru_24it_247_24Just, TAG_Left, 1, (V[]){v_t_2438});
      }
      default: return heff_nomatch(v_it1_2425);
      }
    }
    default: return heff_nomatch(v_it_247);
    }
  }
  case TAG_Just: {
    V v_it1_2439 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Just = heff_take_reuse(v_it_245, 1ULL);
    heff_drop(v_rs_241);
    heff_drop(v_pxs_242);
    heff_drop(v_ps_243);
    switch (heff_tag_of(v_it1_2439)) {
    case TAG_MkPair: {
      V v_n_2440 = heff_field(v_it1_2439, 0);
      V v_x_2441 = heff_field(v_it1_2439, 1);
      heff_take(v_it1_2439, 3ULL);
      V v_t_2450;
      switch (heff_tag_of(v_x_2441)) {
      case TAG_LStr: {
        V v_t_2443 = heff_field(v_x_2441, 1);
        heff_take(v_x_2441, 2ULL);
        v_t_2450 = v_t_2443;
        break;
      }
      case TAG_LTag: {
        V v_t_2445 = heff_field(v_x_2441, 1);
        heff_take(v_x_2441, 2ULL);
        v_t_2450 = v_t_2445;
        break;
      }
      case TAG_LList: {
        V v_t_2447 = heff_field(v_x_2441, 1);
        heff_take(v_x_2441, 2ULL);
        v_t_2450 = v_t_2447;
        break;
      }
      case TAG_LRec: {
        V v_t_2449 = heff_field(v_x_2441, 1);
        heff_take(v_x_2441, 2ULL);
        v_t_2450 = v_t_2449;
        break;
      }
      default: heff_nomatch(v_x_2441);
      }
      V v_t_2451 = heff_strAppend(((V)&g_heff_2eproject_2echeckNames_str4), heff_strAppend(v_n_2440, ((V)&g_heff_2eproject_2echeckNames_str5)));
      V v_t_2452 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2450, LBL_start), v_t_2451});
      return heff_tag_at(v_ru_24it_245_24Just, TAG_Left, 1, (V[]){v_t_2452});
    }
    default: return heff_nomatch(v_it1_2439);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2eproject_2echeckNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2echeckNames(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eproject_2eallOf_24s733_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2eallOf_24s733_entry, 1, 0};

V g_heff_2eproject_2eallOf_24s733(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_240);
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse(v_x2_240, 3ULL);
    V v_x1_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eproject_2erequireOf(a_0)); heff_drop(v_x_241); r_; });
    V v_x2_244 = (g_heff_2eproject_2eallOf_24s733(v_rest_242));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Left: {
      V v_p_245 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Left = heff_take_reuse(v_x1_243, 1ULL);
      heff_drop(v_ru_24x2_240_24Cons);
      heff_drop(v_x2_244);
      return heff_tag_at(v_ru_24x1_243_24Left, TAG_Left, 1, (V[]){v_p_245});
    }
    case TAG_Right: {
      V v_y_246 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Right = heff_take_reuse(v_x1_243, 1ULL);
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Left: {
        V v_p_247 = heff_field(v_x2_244, 0);
        heff_take(v_x2_244, 1ULL);
        heff_drop(v_ru_24x2_240_24Cons);
        heff_drop(v_y_246);
        return heff_tag_at(v_ru_24x1_243_24Right, TAG_Left, 1, (V[]){v_p_247});
      }
      case TAG_Right: {
        V v_ys_248 = heff_field(v_x2_244, 0);
        heff_take(v_x2_244, 1ULL);
        return heff_tag_at(v_ru_24x1_243_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_y_246, v_ys_248})});
      }
      default: return heff_nomatch(v_x2_244);
      }
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eproject_2eallOf_24s733_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2eallOf_24s733(a[0]);
}
Clo g_heff_2eproject_2eallOf_24s734_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2eallOf_24s734_entry, 1, 0};

V g_heff_2eproject_2eallOf_24s734(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_240);
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse(v_x2_240, 3ULL);
    V v_x1_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eproject_2ereplaceOf(a_0)); heff_drop(v_x_241); r_; });
    V v_x2_244 = (g_heff_2eproject_2eallOf_24s734(v_rest_242));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Left: {
      V v_p_245 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Left = heff_take_reuse(v_x1_243, 1ULL);
      heff_drop(v_ru_24x2_240_24Cons);
      heff_drop(v_x2_244);
      return heff_tag_at(v_ru_24x1_243_24Left, TAG_Left, 1, (V[]){v_p_245});
    }
    case TAG_Right: {
      V v_y_246 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Right = heff_take_reuse(v_x1_243, 1ULL);
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Left: {
        V v_p_247 = heff_field(v_x2_244, 0);
        heff_take(v_x2_244, 1ULL);
        heff_drop(v_ru_24x2_240_24Cons);
        heff_drop(v_y_246);
        return heff_tag_at(v_ru_24x1_243_24Right, TAG_Left, 1, (V[]){v_p_247});
      }
      case TAG_Right: {
        V v_ys_248 = heff_field(v_x2_244, 0);
        heff_take(v_x2_244, 1ULL);
        return heff_tag_at(v_ru_24x1_243_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_y_246, v_ys_248})});
      }
      default: return heff_nomatch(v_x2_244);
      }
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eproject_2eallOf_24s734_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2eallOf_24s734(a[0]);
}
Clo g_heff_2eproject_2epackageOf4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2epackageOf4_entry, 4, 0};

V g_heff_2eproject_2epackageOf4(V v_m_240, V v_h_241, V v_rq_242, V v_rp_243) {
top: ;
  V v_t_244 = (g_heff_2eproject_2estr(v_m_240));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Left: {
    V v_p_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Left = heff_take_reuse(v_t_244, 1ULL);
    return heff_tag_at(v_ru_24t_244_24Left, TAG_Left, 1, (V[]){v_p_245});
  }
  case TAG_Right: {
    V v_mpath_246 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Right = heff_take_reuse(v_t_244, 1ULL);
    V v_t_247 = (g_heff_2eproject_2eversionOf(v_h_241));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Left: {
      V v_p_248 = heff_field(v_t_247, 0);
      heff_take(v_t_247, 1ULL);
      heff_drop(v_mpath_246);
      return heff_tag_at(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_p_248});
    }
    case TAG_Right: {
      V v_hv_249 = heff_field(v_t_247, 0);
      heff_take(v_t_247, 1ULL);
      V v_t_2410 = (g_heff_2eproject_2eitems(v_rq_242));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Left: {
        V v_p_2411 = heff_field(v_t_2410, 0);
        heff_take(v_t_2410, 1ULL);
        heff_drop(v_mpath_246);
        heff_drop(v_hv_249);
        return heff_tag_at(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_p_2411});
      }
      case TAG_Right: {
        V v_rxs_2412 = heff_field(v_t_2410, 0);
        heff_take(v_t_2410, 1ULL);
        V v_t_2413 = (g_heff_2eproject_2eallOf_24s733(heff_dup(v_rxs_2412)));
        switch (heff_tag_of(v_t_2413)) {
        case TAG_Left: {
          V v_p_2414 = heff_field(v_t_2413, 0);
          heff_take(v_t_2413, 1ULL);
          heff_drop(v_mpath_246);
          heff_drop(v_hv_249);
          heff_drop(v_rxs_2412);
          return heff_tag_at(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_p_2414});
        }
        case TAG_Right: {
          V v_rs_2415 = heff_field(v_t_2413, 0);
          heff_take(v_t_2413, 1ULL);
          V v_t_2416 = (g_heff_2eproject_2eitems(v_rp_243));
          switch (heff_tag_of(v_t_2416)) {
          case TAG_Left: {
            V v_p_2417 = heff_field(v_t_2416, 0);
            heff_take(v_t_2416, 1ULL);
            heff_drop(v_mpath_246);
            heff_drop(v_hv_249);
            heff_drop(v_rxs_2412);
            heff_drop(v_rs_2415);
            return heff_tag_at(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_p_2417});
          }
          case TAG_Right: {
            V v_pxs_2418 = heff_field(v_t_2416, 0);
            heff_take(v_t_2416, 1ULL);
            V v_t_2419 = (g_heff_2eproject_2eallOf_24s734(heff_dup(v_pxs_2418)));
            switch (heff_tag_of(v_t_2419)) {
            case TAG_Left: {
              V v_p_2420 = heff_field(v_t_2419, 0);
              heff_take(v_t_2419, 1ULL);
              heff_drop(v_mpath_246);
              heff_drop(v_hv_249);
              heff_drop(v_rxs_2412);
              heff_drop(v_rs_2415);
              heff_drop(v_pxs_2418);
              return heff_tag_at(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_p_2420});
            }
            case TAG_Right: {
              V v_ps_2421 = heff_field(v_t_2419, 0);
              heff_take(v_t_2419, 1ULL);
              V v_t_2422 = (g_heff_2eproject_2echeckNames(v_rxs_2412, heff_dup(v_rs_2415), v_pxs_2418, heff_dup(v_ps_2421)));
              switch (heff_tag_of(v_t_2422)) {
              case TAG_Left: {
                V v_p_2423 = heff_field(v_t_2422, 0);
                heff_take(v_t_2422, 1ULL);
                heff_drop(v_mpath_246);
                heff_drop(v_hv_249);
                heff_drop(v_rs_2415);
                heff_drop(v_ps_2421);
                return heff_tag_at(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_p_2423});
              }
              case TAG_Right: {
                heff_take(v_t_2422, 0ULL);
                return heff_tag_at(v_ru_24t_244_24Right, TAG_Right, 1, (V[]){heff_rec(4, shape_184_118_264_263, (V[]){v_mpath_246, v_hv_249, v_rs_2415, v_ps_2421})});
              }
              default: return heff_nomatch(v_t_2422);
              }
            }
            default: return heff_nomatch(v_t_2419);
            }
          }
          default: return heff_nomatch(v_t_2416);
          }
        }
        default: return heff_nomatch(v_t_2413);
        }
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eproject_2epackageOf4_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2epackageOf4(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eproject_2epackageOf_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 112, 108, 97, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eproject_2epackageOf_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eproject_2epackageOf_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 113, 117, 105, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eproject_2epackageOf_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {109, 111, 100, 117, 108, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2epackageOf_str4 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2epackageOf_str5 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2epackageOf_str6 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2epackageOf_str7 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2epackageOf_str8 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
Clo g_heff_2eproject_2epackageOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2epackageOf_entry, 1, 0};

V g_heff_2eproject_2epackageOf(V v_x_240) {
top: ;
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eproject_2epackageOf_str0), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eproject_2epackageOf_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eproject_2epackageOf_str2), v_t_241})});
  V v_it_243 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eproject_2epackageOf_str3), v_t_242}); V a_1 = v_x_240; V r_ = (g_heff_2eproject_2efieldsAre(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_243)) {
  case TAG_Left: {
    V v_p_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Left = heff_take_reuse(v_it_243, 1ULL);
    return heff_tag_at(v_ru_24it_243_24Left, TAG_Left, 1, (V[]){v_p_244});
  }
  case TAG_Right: {
    V v_it1_245 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Right = heff_take_reuse(v_it_243, 1ULL);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_Nil: {
      heff_drop(v_it1_245);
      V v_t_2414;
      switch (heff_tag_of(v_x_240)) {
      case TAG_LStr: {
        V v_t_247 = heff_field(v_x_240, 1);
        v_t_2414 = heff_dup(v_t_247);
        break;
      }
      case TAG_LTag: {
        V v_t_249 = heff_field(v_x_240, 1);
        v_t_2414 = heff_dup(v_t_249);
        break;
      }
      case TAG_LList: {
        V v_t_2411 = heff_field(v_x_240, 1);
        v_t_2414 = heff_dup(v_t_2411);
        break;
      }
      case TAG_LRec: {
        V v_t_2413 = heff_field(v_x_240, 1);
        v_t_2414 = heff_dup(v_t_2413);
        break;
      }
      default: heff_nomatch(v_x_240);
      }
      V v_t_2415 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2414, LBL_start), ((V)&g_heff_2eproject_2epackageOf_str4)});
      return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_t_2415});
    }
    case TAG_Cons: {
      V v_m_2416 = heff_field(v_it1_245, 0);
      V v_it12_2417 = heff_field(v_it1_245, 1);
      heff_take(v_it1_245, 3ULL);
      switch (heff_tag_of(v_it12_2417)) {
      case TAG_Nil: {
        heff_drop(v_m_2416);
        heff_drop(v_it12_2417);
        V v_t_2426;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2419 = heff_field(v_x_240, 1);
          v_t_2426 = heff_dup(v_t_2419);
          break;
        }
        case TAG_LTag: {
          V v_t_2421 = heff_field(v_x_240, 1);
          v_t_2426 = heff_dup(v_t_2421);
          break;
        }
        case TAG_LList: {
          V v_t_2423 = heff_field(v_x_240, 1);
          v_t_2426 = heff_dup(v_t_2423);
          break;
        }
        case TAG_LRec: {
          V v_t_2425 = heff_field(v_x_240, 1);
          v_t_2426 = heff_dup(v_t_2425);
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_t_2427 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2426, LBL_start), ((V)&g_heff_2eproject_2epackageOf_str5)});
        return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_t_2427});
      }
      case TAG_Cons: {
        V v_h_2428 = heff_field(v_it12_2417, 0);
        V v_it122_2429 = heff_field(v_it12_2417, 1);
        heff_take(v_it12_2417, 3ULL);
        switch (heff_tag_of(v_it122_2429)) {
        case TAG_Nil: {
          heff_drop(v_m_2416);
          heff_drop(v_h_2428);
          heff_drop(v_it122_2429);
          V v_t_2438;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2431 = heff_field(v_x_240, 1);
            v_t_2438 = heff_dup(v_t_2431);
            break;
          }
          case TAG_LTag: {
            V v_t_2433 = heff_field(v_x_240, 1);
            v_t_2438 = heff_dup(v_t_2433);
            break;
          }
          case TAG_LList: {
            V v_t_2435 = heff_field(v_x_240, 1);
            v_t_2438 = heff_dup(v_t_2435);
            break;
          }
          case TAG_LRec: {
            V v_t_2437 = heff_field(v_x_240, 1);
            v_t_2438 = heff_dup(v_t_2437);
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_t_2439 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2438, LBL_start), ((V)&g_heff_2eproject_2epackageOf_str6)});
          return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_t_2439});
        }
        case TAG_Cons: {
          V v_rq_2440 = heff_field(v_it122_2429, 0);
          V v_it1222_2441 = heff_field(v_it122_2429, 1);
          heff_take(v_it122_2429, 3ULL);
          switch (heff_tag_of(v_it1222_2441)) {
          case TAG_Nil: {
            heff_drop(v_m_2416);
            heff_drop(v_h_2428);
            heff_drop(v_rq_2440);
            heff_drop(v_it1222_2441);
            V v_t_2450;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2443 = heff_field(v_x_240, 1);
              v_t_2450 = heff_dup(v_t_2443);
              break;
            }
            case TAG_LTag: {
              V v_t_2445 = heff_field(v_x_240, 1);
              v_t_2450 = heff_dup(v_t_2445);
              break;
            }
            case TAG_LList: {
              V v_t_2447 = heff_field(v_x_240, 1);
              v_t_2450 = heff_dup(v_t_2447);
              break;
            }
            case TAG_LRec: {
              V v_t_2449 = heff_field(v_x_240, 1);
              v_t_2450 = heff_dup(v_t_2449);
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_t_2451 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2450, LBL_start), ((V)&g_heff_2eproject_2epackageOf_str7)});
            return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_t_2451});
          }
          case TAG_Cons: {
            V v_rp_2452 = heff_field(v_it1222_2441, 0);
            V v_it12222_2453 = heff_field(v_it1222_2441, 1);
            heff_take(v_it1222_2441, 3ULL);
            switch (heff_tag_of(v_it12222_2453)) {
            case TAG_Nil: {
              heff_drop(v_ru_24it_243_24Right);
              heff_drop(v_it12222_2453);
              return ({ V a_0 = v_m_2416; V a_1 = v_h_2428; V a_2 = v_rq_2440; V a_3 = v_rp_2452; V r_ = (g_heff_2eproject_2epackageOf4(a_0, a_1, a_2, a_3)); heff_drop(v_m_2416); heff_drop(v_h_2428); heff_drop(v_rq_2440); heff_drop(v_rp_2452); r_; });
            }
            case TAG_Cons: {
              heff_take(v_it12222_2453, 0ULL);
              heff_drop(v_m_2416);
              heff_drop(v_h_2428);
              heff_drop(v_rq_2440);
              heff_drop(v_rp_2452);
              V v_t_2464;
              switch (heff_tag_of(v_x_240)) {
              case TAG_LStr: {
                V v_t_2457 = heff_field(v_x_240, 1);
                v_t_2464 = heff_dup(v_t_2457);
                break;
              }
              case TAG_LTag: {
                V v_t_2459 = heff_field(v_x_240, 1);
                v_t_2464 = heff_dup(v_t_2459);
                break;
              }
              case TAG_LList: {
                V v_t_2461 = heff_field(v_x_240, 1);
                v_t_2464 = heff_dup(v_t_2461);
                break;
              }
              case TAG_LRec: {
                V v_t_2463 = heff_field(v_x_240, 1);
                v_t_2464 = heff_dup(v_t_2463);
                break;
              }
              default: heff_nomatch(v_x_240);
              }
              V v_t_2465 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2464, LBL_start), ((V)&g_heff_2eproject_2epackageOf_str8)});
              return heff_tag_at(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_t_2465});
            }
            default: return heff_nomatch(v_it12222_2453);
            }
          }
          default: return heff_nomatch(v_it1222_2441);
          }
        }
        default: return heff_nomatch(v_it122_2429);
        }
      }
      default: return heff_nomatch(v_it12_2417);
      }
    }
    default: return heff_nomatch(v_it1_245);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2eproject_2epackageOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2epackageOf(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eproject_2ereadPackage_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eproject_2ereadPackage_str1 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 97, 99, 107, 97, 103, 101}};
Clo g_heff_2eproject_2ereadPackage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2ereadPackage_entry, 1, 0};

V g_heff_2eproject_2ereadPackage(V v_src_240) {
top: ;
  V v_t_241 = heff_rec(7, shape_123_167_168_96_325_83_42, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_l_242 = (g_heff_2efmt_2elex_2elexGo(heff_dup(v_src_240), v_t_241, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_243 = heff_get(v_l_242, LBL_errors);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    heff_drop(v_t_243);
    V v_t_244 = heff_rec(7, shape_123_167_168_96_325_83_42, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_l_245 = (g_heff_2efmt_2elex_2elexGo(v_src_240, v_t_244, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V v_t_246 = heff_arrayFromList(heff_get(v_l_245, LBL_tokens));
    V v_t_247 = (g_heff_2eproject_2edeclsGo(((V)&g_heff_2eproject_2ereadPackage_str0), ((V)&g_heff_2eproject_2ereadPackage_str1), v_t_246, MK_INT(0LL), NTAG(TAG_Nothing)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Left: {
      V v_p_248 = heff_field(v_t_247, 0);
      V v_ru_24t_247_24Left = heff_take_reuse(v_t_247, 1ULL);
      return heff_tag_at(v_ru_24t_247_24Left, TAG_Left, 1, (V[]){v_p_248});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_t_247, 0);
      heff_take(v_t_247, 1ULL);
      return ({ V a_0 = v_x_249; V r_ = (g_heff_2eproject_2epackageOf(a_0)); heff_drop(v_x_249); r_; });
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_Cons: {
    V v_e_2410 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    heff_drop(v_src_240);
    V v_t_2412 = heff_rec(2, shape_15_185, (V[]){heff_get(heff_dup(v_e_2410), LBL_start), heff_get(v_e_2410, LBL_msg)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eproject_2ereadPackage_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2ereadPackage(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[38]; } g_heff_2eproject_2ebackendOf_str0 = {{0x80000000u, K_STR, 0}, 38, 38, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 98, 97, 99, 107, 101, 110, 100, 58, 32, 39, 99, 44, 32, 39, 110, 111, 100, 101, 32, 111, 114, 32, 39, 112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2ebackendOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eproject_2ebackendOf_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eproject_2ebackendOf_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eproject_2ebackendOf_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {110, 111, 32, 98, 97, 99, 107, 101, 110, 100, 32, 39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2eproject_2ebackendOf_str5 = {{0x80000000u, K_STR, 0}, 20, 20, {58, 32, 39, 99, 44, 32, 39, 110, 111, 100, 101, 32, 111, 114, 32, 39, 112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[38]; } g_heff_2eproject_2ebackendOf_str6 = {{0x80000000u, K_STR, 0}, 38, 38, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 98, 97, 99, 107, 101, 110, 100, 58, 32, 39, 99, 44, 32, 39, 110, 111, 100, 101, 32, 111, 114, 32, 39, 112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[38]; } g_heff_2eproject_2ebackendOf_str7 = {{0x80000000u, K_STR, 0}, 38, 38, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 98, 97, 99, 107, 101, 110, 100, 58, 32, 39, 99, 44, 32, 39, 110, 111, 100, 101, 32, 111, 114, 32, 39, 112, 97, 103, 101}};
Clo g_heff_2eproject_2ebackendOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2ebackendOf_entry, 1, 0};

V g_heff_2eproject_2ebackendOf(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_t_2411;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_244 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_244);
      break;
    }
    case TAG_LTag: {
      V v_t_246 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_246);
      break;
    }
    case TAG_LList: {
      V v_t_248 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_248);
      break;
    }
    case TAG_LRec: {
      V v_t_2410 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_2410);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2412 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2411, LBL_start), ((V)&g_heff_2eproject_2ebackendOf_str0)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2412});
  }
  case TAG_LTag: {
    V v_b_2413 = heff_field(v_x_240, 0);
    V v_t_2414 = heff_field(v_x_240, 1);
    V v_t_2415 = heff_strEq(heff_dup(v_b_2413), ((V)&g_heff_2eproject_2ebackendOf_str1));
    switch (heff_tag_of(v_t_2415)) {
    case TAG_True: {
      heff_drop(v_t_2415);
      return heff_tag(TAG_Right, 1, (V[]){heff_dup(v_b_2413)});
    }
    case TAG_False: {
      heff_drop(v_t_2415);
      V v_t_2416 = heff_strEq(heff_dup(v_b_2413), ((V)&g_heff_2eproject_2ebackendOf_str2));
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        heff_drop(v_t_2416);
        return heff_tag(TAG_Right, 1, (V[]){heff_dup(v_b_2413)});
      }
      case TAG_False: {
        heff_drop(v_t_2416);
        V v_t_2417 = heff_strEq(heff_dup(v_b_2413), ((V)&g_heff_2eproject_2ebackendOf_str3));
        switch (heff_tag_of(v_t_2417)) {
        case TAG_True: {
          heff_drop(v_t_2417);
          return heff_tag(TAG_Right, 1, (V[]){heff_dup(v_b_2413)});
        }
        case TAG_False: {
          heff_drop(v_t_2417);
          V v_t_2418 = heff_strAppend(((V)&g_heff_2eproject_2ebackendOf_str4), heff_strAppend(heff_dup(v_b_2413), ((V)&g_heff_2eproject_2ebackendOf_str5)));
          V v_t_2419 = heff_rec(2, shape_15_185, (V[]){heff_get(heff_dup(v_t_2414), LBL_start), v_t_2418});
          return heff_tag(TAG_Left, 1, (V[]){v_t_2419});
        }
        default: return heff_nomatch(v_t_2417);
        }
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    default: return heff_nomatch(v_t_2415);
    }
  }
  case TAG_LList: {
    V v_t_2430;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2423 = heff_field(v_x_240, 1);
      v_t_2430 = heff_dup(v_t_2423);
      break;
    }
    case TAG_LTag: {
      V v_t_2425 = heff_field(v_x_240, 1);
      v_t_2430 = heff_dup(v_t_2425);
      break;
    }
    case TAG_LList: {
      V v_t_2427 = heff_field(v_x_240, 1);
      v_t_2430 = heff_dup(v_t_2427);
      break;
    }
    case TAG_LRec: {
      V v_t_2429 = heff_field(v_x_240, 1);
      v_t_2430 = heff_dup(v_t_2429);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2431 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2430, LBL_start), ((V)&g_heff_2eproject_2ebackendOf_str6)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2431});
  }
  case TAG_LRec: {
    V v_t_2442;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2435 = heff_field(v_x_240, 1);
      v_t_2442 = heff_dup(v_t_2435);
      break;
    }
    case TAG_LTag: {
      V v_t_2437 = heff_field(v_x_240, 1);
      v_t_2442 = heff_dup(v_t_2437);
      break;
    }
    case TAG_LList: {
      V v_t_2439 = heff_field(v_x_240, 1);
      v_t_2442 = heff_dup(v_t_2439);
      break;
    }
    case TAG_LRec: {
      V v_t_2441 = heff_field(v_x_240, 1);
      v_t_2442 = heff_dup(v_t_2441);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2443 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2442, LBL_start), ((V)&g_heff_2eproject_2ebackendOf_str7)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2443});
  }
  default: return heff_nomatch(v_x_240);
  }
}
V g_heff_2eproject_2ebackendOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2ebackendOf(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2ebuildOf_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {114, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eproject_2ebuildOf_str1 = {{0x80000000u, K_STR, 0}, 7, 7, {98, 97, 99, 107, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2ebuildOf_str2 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2ebuildOf_str3 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eproject_2ebuildOf_str4 = {{0x80000000u, K_STR, 0}, 25, 25, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 96, 123, 46, 46, 46, 125, 96}};
Clo g_heff_2eproject_2ebuildOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2ebuildOf_entry, 1, 0};

V g_heff_2eproject_2ebuildOf(V v_x_240) {
top: ;
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eproject_2ebuildOf_str0), NTAG(TAG_Nil)});
  V v_it_242 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eproject_2ebuildOf_str1), v_t_241}); V a_1 = v_x_240; V r_ = (g_heff_2eproject_2efieldsAre(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_242)) {
  case TAG_Left: {
    V v_p_243 = heff_field(v_it_242, 0);
    V v_ru_24it_242_24Left = heff_take_reuse(v_it_242, 1ULL);
    return heff_tag_at(v_ru_24it_242_24Left, TAG_Left, 1, (V[]){v_p_243});
  }
  case TAG_Right: {
    V v_it1_244 = heff_field(v_it_242, 0);
    V v_ru_24it_242_24Right = heff_take_reuse(v_it_242, 1ULL);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_Nil: {
      heff_drop(v_it1_244);
      V v_t_2413;
      switch (heff_tag_of(v_x_240)) {
      case TAG_LStr: {
        V v_t_246 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_246);
        break;
      }
      case TAG_LTag: {
        V v_t_248 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_248);
        break;
      }
      case TAG_LList: {
        V v_t_2410 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_2410);
        break;
      }
      case TAG_LRec: {
        V v_t_2412 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_2412);
        break;
      }
      default: heff_nomatch(v_x_240);
      }
      V v_t_2414 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2413, LBL_start), ((V)&g_heff_2eproject_2ebuildOf_str2)});
      return heff_tag_at(v_ru_24it_242_24Right, TAG_Left, 1, (V[]){v_t_2414});
    }
    case TAG_Cons: {
      V v_b_2415 = heff_field(v_it1_244, 0);
      V v_it12_2416 = heff_field(v_it1_244, 1);
      heff_take(v_it1_244, 3ULL);
      switch (heff_tag_of(v_it12_2416)) {
      case TAG_Nil: {
        heff_drop(v_b_2415);
        heff_drop(v_it12_2416);
        V v_t_2425;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2418 = heff_field(v_x_240, 1);
          v_t_2425 = heff_dup(v_t_2418);
          break;
        }
        case TAG_LTag: {
          V v_t_2420 = heff_field(v_x_240, 1);
          v_t_2425 = heff_dup(v_t_2420);
          break;
        }
        case TAG_LList: {
          V v_t_2422 = heff_field(v_x_240, 1);
          v_t_2425 = heff_dup(v_t_2422);
          break;
        }
        case TAG_LRec: {
          V v_t_2424 = heff_field(v_x_240, 1);
          v_t_2425 = heff_dup(v_t_2424);
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_t_2426 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2425, LBL_start), ((V)&g_heff_2eproject_2ebuildOf_str3)});
        return heff_tag_at(v_ru_24it_242_24Right, TAG_Left, 1, (V[]){v_t_2426});
      }
      case TAG_Cons: {
        V v_r_2427 = heff_field(v_it12_2416, 0);
        V v_it122_2428 = heff_field(v_it12_2416, 1);
        heff_take(v_it12_2416, 3ULL);
        switch (heff_tag_of(v_it122_2428)) {
        case TAG_Nil: {
          heff_drop(v_it122_2428);
          V v_t_2429 = ({ V a_0 = v_b_2415; V r_ = (g_heff_2eproject_2ebackendOf(a_0)); heff_drop(v_b_2415); r_; });
          switch (heff_tag_of(v_t_2429)) {
          case TAG_Left: {
            V v_p_2430 = heff_field(v_t_2429, 0);
            heff_take(v_t_2429, 1ULL);
            heff_drop(v_r_2427);
            return heff_tag_at(v_ru_24it_242_24Right, TAG_Left, 1, (V[]){v_p_2430});
          }
          case TAG_Right: {
            V v_backend_2431 = heff_field(v_t_2429, 0);
            heff_take(v_t_2429, 1ULL);
            V v_t_2432 = ({ V a_0 = v_r_2427; V r_ = (g_heff_2eproject_2estr(a_0)); heff_drop(v_r_2427); r_; });
            switch (heff_tag_of(v_t_2432)) {
            case TAG_Left: {
              V v_p_2433 = heff_field(v_t_2432, 0);
              heff_take(v_t_2432, 1ULL);
              heff_drop(v_backend_2431);
              return heff_tag_at(v_ru_24it_242_24Right, TAG_Left, 1, (V[]){v_p_2433});
            }
            case TAG_Right: {
              V v_run_2434 = heff_field(v_t_2432, 0);
              heff_take(v_t_2432, 1ULL);
              return heff_tag_at(v_ru_24it_242_24Right, TAG_Right, 1, (V[]){heff_rec(2, shape_17_273, (V[]){v_backend_2431, v_run_2434})});
            }
            default: return heff_nomatch(v_t_2432);
            }
          }
          default: return heff_nomatch(v_t_2429);
          }
        }
        case TAG_Cons: {
          heff_take(v_it122_2428, 0ULL);
          heff_drop(v_b_2415);
          heff_drop(v_r_2427);
          V v_t_2445;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2438 = heff_field(v_x_240, 1);
            v_t_2445 = heff_dup(v_t_2438);
            break;
          }
          case TAG_LTag: {
            V v_t_2440 = heff_field(v_x_240, 1);
            v_t_2445 = heff_dup(v_t_2440);
            break;
          }
          case TAG_LList: {
            V v_t_2442 = heff_field(v_x_240, 1);
            v_t_2445 = heff_dup(v_t_2442);
            break;
          }
          case TAG_LRec: {
            V v_t_2444 = heff_field(v_x_240, 1);
            v_t_2445 = heff_dup(v_t_2444);
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_t_2446 = heff_rec(2, shape_15_185, (V[]){heff_get(v_t_2445, LBL_start), ((V)&g_heff_2eproject_2ebuildOf_str4)});
          return heff_tag_at(v_ru_24it_242_24Right, TAG_Left, 1, (V[]){v_t_2446});
        }
        default: return heff_nomatch(v_it122_2428);
        }
      }
      default: return heff_nomatch(v_it12_2416);
      }
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2eproject_2ebuildOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2ebuildOf(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eproject_2ereadBuild_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eproject_2ereadBuild_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
Clo g_heff_2eproject_2ereadBuild_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2ereadBuild_entry, 1, 0};

V g_heff_2eproject_2ereadBuild(V v_src_240) {
top: ;
  V v_t_241 = heff_rec(7, shape_123_167_168_96_325_83_42, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_l_242 = (g_heff_2efmt_2elex_2elexGo(heff_dup(v_src_240), v_t_241, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_243 = heff_get(v_l_242, LBL_errors);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    heff_drop(v_t_243);
    V v_t_244 = heff_rec(7, shape_123_167_168_96_325_83_42, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_l_245 = (g_heff_2efmt_2elex_2elexGo(v_src_240, v_t_244, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V v_t_246 = heff_arrayFromList(heff_get(v_l_245, LBL_tokens));
    V v_t_247 = (g_heff_2eproject_2edeclsGo(((V)&g_heff_2eproject_2ereadBuild_str0), ((V)&g_heff_2eproject_2ereadBuild_str1), v_t_246, MK_INT(0LL), NTAG(TAG_Nothing)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Left: {
      V v_p_248 = heff_field(v_t_247, 0);
      V v_ru_24t_247_24Left = heff_take_reuse(v_t_247, 1ULL);
      return heff_tag_at(v_ru_24t_247_24Left, TAG_Left, 1, (V[]){v_p_248});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_t_247, 0);
      heff_take(v_t_247, 1ULL);
      return ({ V a_0 = v_x_249; V r_ = (g_heff_2eproject_2ebuildOf(a_0)); heff_drop(v_x_249); r_; });
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_Cons: {
    V v_e_2410 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    heff_drop(v_src_240);
    V v_t_2412 = heff_rec(2, shape_15_185, (V[]){heff_get(heff_dup(v_e_2410), LBL_start), heff_get(v_e_2410, LBL_msg)});
    return heff_tag(TAG_Left, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eproject_2ereadBuild_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2ereadBuild(a[0]);
}
Clo g_heff_2eproject_2enewerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2enewerGo_entry, 2, 0};

V g_heff_2eproject_2enewerGo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      V v_t_246 = heff_intLt(heff_dup(v_y_244), heff_dup(v_x_242));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_t_246);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        heff_drop(v_t_246);
        V v_t_247 = heff_intEq(heff_dup(v_x_242), heff_dup(v_y_244));
        switch (heff_tag_of(v_t_247)) {
        case TAG_True: {
          heff_drop(v_t_247);
          V t_0 = v_xs_243;
          V t_1 = v_ys_245;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_False: {
          heff_drop(v_t_247);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_247);
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eproject_2enewerGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2enewerGo(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2erepoOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2erepoOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2erepoOf_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
Clo g_heff_2eproject_2erepoOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2erepoOf_entry, 1, 0};

V g_heff_2eproject_2erepoOf(V v_path_240) {
top: ;
  V v_xs_241 = (g_prelude_2esplitFrom(((V)&g_heff_2eproject_2erepoOf_str0), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_241));
  V v_x_245;
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    heff_drop(v_t_242);
    v_x_245 = heff_dup(v_path_240);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_t_242, 0);
    heff_take(v_t_242, 1ULL);
    v_x_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_246 = heff_intLe(MK_INT(2LL), heff_strLength(heff_dup(v_x_245)));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_t_246);
    V v_t_247 = heff_strEq(heff_strSlice(heff_dup(v_x_245), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eproject_2erepoOf_str1));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_t_247);
      V v_t_248 = heff_strSlice(heff_dup(v_x_245), MK_INT(1LL), heff_strLength(v_x_245));
      V v_t_249 = (g_heff_2eproject_2eisNumber(v_t_248));
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        heff_drop(v_t_249);
        V v_xs_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2eproject_2erepoOf_str2), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2411 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2410));
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_Nil: {
          heff_drop(v_t_2411);
          v_t_2414 = heff_dup(v_path_240);
          break;
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_t_2411, 0);
          heff_take(v_t_2411, 1ULL);
          v_t_2414 = v_x_2412;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        V v_t_2415 = heff_intSub(heff_strLength(heff_dup(v_path_240)), heff_strLength(v_t_2414));
        return heff_strSlice(v_path_240, MK_INT(0LL), heff_intSub(v_t_2415, MK_INT(1LL)));
      }
      case TAG_False: {
        heff_drop(v_t_249);
        return v_path_240;
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    case TAG_False: {
      heff_drop(v_x_245);
      heff_drop(v_t_247);
      return v_path_240;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_False: {
    heff_drop(v_x_245);
    heff_drop(v_t_246);
    return v_path_240;
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eproject_2erepoOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2erepoOf(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[68]; } g_heff_2eproject_2esumLine_str0 = {{0x80000000u, K_STR, 0}, 68, 68, {97, 32, 108, 105, 110, 101, 32, 111, 102, 32, 104, 101, 102, 102, 46, 115, 117, 109, 32, 105, 115, 32, 97, 32, 112, 97, 116, 104, 44, 32, 97, 32, 118, 101, 114, 115, 105, 111, 110, 32, 97, 110, 100, 32, 97, 32, 116, 114, 101, 101, 44, 32, 97, 110, 100, 32, 110, 111, 116, 104, 105, 110, 103, 32, 101, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[68]; } g_heff_2eproject_2esumLine_str1 = {{0x80000000u, K_STR, 0}, 68, 68, {97, 32, 108, 105, 110, 101, 32, 111, 102, 32, 104, 101, 102, 102, 46, 115, 117, 109, 32, 105, 115, 32, 97, 32, 112, 97, 116, 104, 44, 32, 97, 32, 118, 101, 114, 115, 105, 111, 110, 32, 97, 110, 100, 32, 97, 32, 116, 114, 101, 101, 44, 32, 97, 110, 100, 32, 110, 111, 116, 104, 105, 110, 103, 32, 101, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2esumLine_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eproject_2esumLine_str3 = {{0x80000000u, K_STR, 0}, 30, 30, {96, 32, 105, 115, 32, 110, 111, 32, 118, 101, 114, 115, 105, 111, 110, 58, 32, 119, 114, 105, 116, 101, 32, 96, 97, 46, 98, 46, 99, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[68]; } g_heff_2eproject_2esumLine_str4 = {{0x80000000u, K_STR, 0}, 68, 68, {97, 32, 108, 105, 110, 101, 32, 111, 102, 32, 104, 101, 102, 102, 46, 115, 117, 109, 32, 105, 115, 32, 97, 32, 112, 97, 116, 104, 44, 32, 97, 32, 118, 101, 114, 115, 105, 111, 110, 32, 97, 110, 100, 32, 97, 32, 116, 114, 101, 101, 44, 32, 97, 110, 100, 32, 110, 111, 116, 104, 105, 110, 103, 32, 101, 108, 115, 101}};
Clo g_heff_2eproject_2esumLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2esumLine_entry, 2, 0};

V g_heff_2eproject_2esumLine(V v_at_240, V v_line_241) {
top: ;
  V v_it_242 = (g_prelude_2ewordsFrom(v_line_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    heff_drop(v_it_242);
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_it_242, 0);
    V v_it2_244 = heff_field(v_it_242, 1);
    V v_ru_24it_242_24Cons = heff_take_reuse(v_it_242, 3ULL);
    switch (heff_tag_of(v_it2_244)) {
    case TAG_Nil: {
      heff_drop(v_p_243);
      heff_drop(v_it2_244);
      heff_drop(v_ru_24it_242_24Cons);
      return heff_tag(TAG_Left, 1, (V[]){heff_rec(2, shape_15_185, (V[]){v_at_240, ((V)&g_heff_2eproject_2esumLine_str0)})});
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_it2_244, 0);
      V v_it22_246 = heff_field(v_it2_244, 1);
      heff_take(v_it2_244, 3ULL);
      switch (heff_tag_of(v_it22_246)) {
      case TAG_Nil: {
        heff_drop(v_p_243);
        heff_drop(v_ru_24it_242_24Cons);
        heff_drop(v_v_245);
        heff_drop(v_it22_246);
        return heff_tag(TAG_Left, 1, (V[]){heff_rec(2, shape_15_185, (V[]){v_at_240, ((V)&g_heff_2eproject_2esumLine_str1)})});
      }
      case TAG_Cons: {
        V v_h_247 = heff_field(v_it22_246, 0);
        V v_it222_248 = heff_field(v_it22_246, 1);
        heff_take(v_it22_246, 3ULL);
        switch (heff_tag_of(v_it222_248)) {
        case TAG_Nil: {
          heff_drop(v_it222_248);
          V v_t_249 = (g_heff_2eproject_2eversion(heff_dup(v_v_245)));
          switch (heff_tag_of(v_t_249)) {
          case TAG_Nothing: {
            heff_drop(v_p_243);
            heff_drop(v_ru_24it_242_24Cons);
            heff_drop(v_h_247);
            heff_drop(v_t_249);
            V v_t_2410 = heff_strAppend(((V)&g_heff_2eproject_2esumLine_str2), heff_strAppend(v_v_245, ((V)&g_heff_2eproject_2esumLine_str3)));
            return heff_tag(TAG_Left, 1, (V[]){heff_rec(2, shape_15_185, (V[]){v_at_240, v_t_2410})});
          }
          case TAG_Just: {
            V v_ru_24t_249_24Just = heff_take_reuse(v_t_249, 0ULL);
            heff_drop(v_at_240);
            V v_t_2412 = heff_tag_at(v_ru_24it_242_24Cons, TAG_Cons, 2, (V[]){heff_rec(3, shape_228_355_115, (V[]){v_p_243, v_v_245, v_h_247}), NTAG(TAG_Nil)});
            return heff_tag_at(v_ru_24t_249_24Just, TAG_Right, 1, (V[]){v_t_2412});
          }
          default: return heff_nomatch(v_t_249);
          }
        }
        case TAG_Cons: {
          heff_take(v_it222_248, 0ULL);
          heff_drop(v_p_243);
          heff_drop(v_ru_24it_242_24Cons);
          heff_drop(v_v_245);
          heff_drop(v_h_247);
          return heff_tag(TAG_Left, 1, (V[]){heff_rec(2, shape_15_185, (V[]){v_at_240, ((V)&g_heff_2eproject_2esumLine_str4)})});
        }
        default: return heff_nomatch(v_it222_248);
        }
      }
      default: return heff_nomatch(v_it22_246);
      }
    }
    default: return heff_nomatch(v_it2_244);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2eproject_2esumLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2esumLine(a[0], a[1]);
}
Clo g_heff_2eproject_2esumGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2esumGo_entry, 2, 0};

V g_heff_2eproject_2esumGo(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2eproject_2esumLine(heff_dup(v_at_240), heff_dup(v_l_242)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Left: {
      V v_p_245 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Left = heff_take_reuse(v_t_244, 1ULL);
      heff_drop(v_at_240);
      return heff_tag_at(v_ru_24t_244_24Left, TAG_Left, 1, (V[]){v_p_245});
    }
    case TAG_Right: {
      V v_xs_246 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Right = heff_take_reuse(v_t_244, 1ULL);
      V v_t_247 = heff_intAdd(v_at_240, heff_strLength(heff_dup(v_l_242)));
      V v_x3_248 = (g_heff_2eproject_2esumGo(heff_intAdd(v_t_247, MK_INT(1LL)), v_rest_243));
      switch (heff_tag_of(v_x3_248)) {
      case TAG_Left: {
        V v_x_249 = heff_field(v_x3_248, 0);
        heff_take(v_x3_248, 1ULL);
        heff_drop(v_xs_246);
        return heff_tag_at(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_x_249});
      }
      case TAG_Right: {
        V v_y_2410 = heff_field(v_x3_248, 0);
        heff_take(v_x3_248, 1ULL);
        return heff_tag_at(v_ru_24t_244_24Right, TAG_Right, 1, (V[]){(g_prelude_2econcatList(v_xs_246, v_y_2410))});
      }
      default: return heff_nomatch(v_x3_248);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eproject_2esumGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eproject_2esumGo(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eproject_2esumBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2esumBefore_entry, 2, 0};

V g_heff_2eproject_2esumBefore(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = heff_strLt(heff_get(heff_dup(v_a_240), LBL_path), heff_get(heff_dup(v_b_241), LBL_path));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    heff_drop(v_t_242);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    heff_drop(v_t_242);
    V v_t_243 = heff_strEq(heff_get(heff_dup(v_a_240), LBL_path), heff_get(heff_dup(v_b_241), LBL_path));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_t_243);
      V v_x2_244 = (g_heff_2eproject_2eversion(heff_get(v_a_240, LBL_version)));
      V v_t_246;
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Nothing: {
        heff_drop(v_x2_244);
        v_t_246 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_245 = heff_field(v_x2_244, 0);
        heff_take(v_x2_244, 1ULL);
        v_t_246 = v_x_245;
        break;
      }
      default: heff_nomatch(v_x2_244);
      }
      V v_x2_247 = (g_heff_2eproject_2eversion(heff_get(v_b_241, LBL_version)));
      V v_t_249;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        heff_drop(v_x2_247);
        v_t_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take(v_x2_247, 1ULL);
        v_t_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_x1_2410 = ({ V a_0 = v_t_246; V a_1 = v_t_249; V r_ = (g_heff_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_246); heff_drop(v_t_249); r_; });
      switch (heff_tag_of(v_x1_2410)) {
      case TAG_True: {
        heff_drop(v_x1_2410);
        return NTAG(TAG_False);
      }
      case TAG_False: {
        heff_drop(v_x1_2410);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_2410);
      }
    }
    case TAG_False: {
      heff_drop(v_a_240);
      heff_drop(v_b_241);
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eproject_2esumBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2esumBefore(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2equoted_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2equoted_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2equoted_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2equoted_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2equoted_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2equoted_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
Clo g_heff_2eproject_2equoted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2equoted_entry, 1, 0};

V g_heff_2eproject_2equoted(V v_s_240) {
top: ;
  V v_x2_241 = (g_prelude_2esplitFrom(((V)&g_heff_2eproject_2equoted_str0), v_s_240, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    v_s_244 = ((V)&g_heff_2eproject_2equoted_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take(v_x2_241, 3ULL);
    v_s_244 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_prelude_2efoldl_24s738(a_0, a_1)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x2_245 = (g_prelude_2esplitFrom(((V)&g_heff_2eproject_2equoted_str2), v_s_244, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_x2_245);
    v_t_248 = ((V)&g_heff_2eproject_2equoted_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take(v_x2_245, 3ULL);
    v_t_248 = ({ V a_0 = v_x_246; V a_1 = v_xs_247; V r_ = (g_prelude_2efoldl_24s739(a_0, a_1)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return heff_strAppend(((V)&g_heff_2eproject_2equoted_str4), heff_strAppend(v_t_248, ((V)&g_heff_2eproject_2equoted_str5)));
}
V g_heff_2eproject_2equoted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2equoted(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2eshowPackage_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2eshowPackage_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eproject_2eshowPackage_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {123, 32, 109, 111, 100, 117, 108, 101, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eproject_2eshowPackage_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {44, 32, 104, 101, 102, 102, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eproject_2eshowPackage_str4 = {{0x80000000u, K_STR, 0}, 13, 13, {44, 32, 114, 101, 113, 117, 105, 114, 101, 32, 61, 32, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eproject_2eshowPackage_str5 = {{0x80000000u, K_STR, 0}, 14, 14, {93, 44, 32, 114, 101, 112, 108, 97, 99, 101, 32, 61, 32, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2eshowPackage_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {93, 32, 125}};
Clo g_heff_2eproject_2eshowPackage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2eshowPackage_entry, 1, 0};

V g_heff_2eproject_2eshowPackage(V v_pk_240) {
top: ;
  V v_t_241 = (g_heff_2eproject_2equoted(heff_get(heff_dup(v_pk_240), LBL_module)));
  V v_t_242 = (g_heff_2eproject_2equoted(heff_get(heff_dup(v_pk_240), LBL_heff)));
  V v_x2_243 = (g_prelude_2emap_24s740(heff_get(heff_dup(v_pk_240), LBL_require)));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_x2_243);
    v_t_246 = ((V)&g_heff_2eproject_2eshowPackage_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take(v_x2_243, 3ULL);
    v_t_246 = ({ V a_0 = v_x_244; V a_1 = v_xs_245; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_x2_247 = (g_prelude_2emap_24s741(heff_get(v_pk_240, LBL_replace)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_x2_247);
    v_t_2410 = ((V)&g_heff_2eproject_2eshowPackage_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take(v_x2_247, 3ULL);
    v_t_2410 = ({ V a_0 = v_x_248; V a_1 = v_xs_249; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  return heff_strAppend(((V)&g_heff_2eproject_2eshowPackage_str2), heff_strAppend(v_t_241, heff_strAppend(((V)&g_heff_2eproject_2eshowPackage_str3), heff_strAppend(v_t_242, heff_strAppend(((V)&g_heff_2eproject_2eshowPackage_str4), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eproject_2eshowPackage_str5), heff_strAppend(v_t_2410, ((V)&g_heff_2eproject_2eshowPackage_str6)))))))));
}
V g_heff_2eproject_2eshowPackage_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2eshowPackage(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2espanGo_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2espanGo_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eproject_2espanGo_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 97, 99, 107, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eproject_2espanGo_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eproject_2espanGo_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
Clo g_heff_2eproject_2espanGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2espanGo_entry, 2, 0};

V g_heff_2eproject_2espanGo(V v_ts_240, V v_i_241) {
top: ;
  V v_t_242 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
  V v_t_243 = heff_strEq(heff_get(v_t_242, LBL_kind), ((V)&g_heff_2eproject_2espanGo_str0));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_ts_240);
    heff_drop(v_i_241);
    heff_drop(v_t_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_False: {
    heff_drop(v_t_243);
    V v_t_244 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
    V v_t_245 = heff_strEq(heff_get(v_t_244, LBL_kind), ((V)&g_heff_2eproject_2espanGo_str1));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      V v_t_246 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
      V v_t_247 = heff_strEq(heff_get(v_t_246, LBL_text), ((V)&g_heff_2eproject_2espanGo_str2));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_t_247);
        V v_t_248 = heff_arrayIndex(heff_dup(v_ts_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
        V v_t_249 = heff_strEq(heff_get(heff_dup(v_t_248), LBL_kind), ((V)&g_heff_2eproject_2espanGo_str3));
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          heff_drop(v_t_249);
          V v_t_2410 = heff_strEq(heff_get(v_t_248, LBL_text), ((V)&g_heff_2eproject_2espanGo_str4));
          switch (heff_tag_of(v_t_2410)) {
          case TAG_True: {
            heff_drop(v_t_2410);
            V v_it_2411 = (g_heff_2eproject_2elitF_24s726(heff_dup(v_ts_240), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))));
            switch (heff_tag_of(v_it_2411)) {
            case TAG_Left: {
              heff_take(v_it_2411, 0ULL);
              heff_drop(v_ts_240);
              heff_drop(v_i_241);
              return NTAG(TAG_Nothing);
            }
            case TAG_Right: {
              V v_it1_2413 = heff_field(v_it_2411, 0);
              V v_ru_24it_2411_24Right = heff_take_reuse(v_it_2411, 1ULL);
              switch (heff_tag_of(v_it1_2413)) {
              case TAG_MkPair: {
                V v_j_2415 = heff_field(v_it1_2413, 1);
                V v_ru_24it1_2413_24MkPair = heff_take_reuse(v_it1_2413, 2ULL);
                V v_t_2416 = heff_arrayIndex(heff_dup(v_ts_240), heff_intAdd(v_i_241, MK_INT(2LL)));
                V v_t_2417 = heff_arrayIndex(v_ts_240, heff_intSub(v_j_2415, MK_INT(1LL)));
                V v_t_2418 = heff_tag_at(v_ru_24it1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_get(v_t_2416, LBL_start), heff_get(v_t_2417, LBL_end)});
                return heff_tag_at(v_ru_24it_2411_24Right, TAG_Just, 1, (V[]){v_t_2418});
              }
              default: return heff_nomatch(v_it1_2413);
              }
            }
            default: return heff_nomatch(v_it_2411);
            }
          }
          case TAG_False: {
            heff_drop(v_t_2410);
            V v_t_2419 = (g_heff_2eproject_2enextDecl(heff_dup(v_ts_240), heff_intAdd(v_i_241, MK_INT(1LL))));
            V t_0 = v_ts_240;
            V t_1 = v_t_2419;
            v_ts_240 = t_0;
            v_i_241 = t_1;
            goto top;
          }
          default: return heff_nomatch(v_t_2410);
          }
        }
        case TAG_False: {
          heff_drop(v_t_248);
          heff_drop(v_t_249);
          V v_t_2420 = (g_heff_2eproject_2enextDecl(heff_dup(v_ts_240), heff_intAdd(v_i_241, MK_INT(1LL))));
          V t_0 = v_ts_240;
          V t_1 = v_t_2420;
          v_ts_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      case TAG_False: {
        heff_drop(v_t_247);
        V v_t_2421 = (g_heff_2eproject_2enextDecl(heff_dup(v_ts_240), heff_intAdd(v_i_241, MK_INT(1LL))));
        V t_0 = v_ts_240;
        V t_1 = v_t_2421;
        v_ts_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_False: {
      heff_drop(v_t_245);
      V v_t_2422 = (g_heff_2eproject_2enextDecl(heff_dup(v_ts_240), heff_intAdd(v_i_241, MK_INT(1LL))));
      V t_0 = v_ts_240;
      V t_1 = v_t_2422;
      v_ts_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eproject_2espanGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2espanGo(a[0], a[1]);
}
Clo g_heff_2eproject_2ewithPackage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eproject_2ewithPackage_entry, 2, 0};

V g_heff_2eproject_2ewithPackage(V v_src_240, V v_pk_241) {
top: ;
  V v_t_242 = heff_rec(7, shape_123_167_168_96_325_83_42, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_l_243 = (g_heff_2efmt_2elex_2elexGo(heff_dup(v_src_240), v_t_242, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_244 = heff_arrayFromList(heff_get(v_l_243, LBL_tokens));
  V v_it_245 = (g_heff_2eproject_2espanGo(v_t_244, MK_INT(0LL)));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    heff_drop(v_pk_241);
    heff_drop(v_it_245);
    return v_src_240;
  }
  case TAG_Just: {
    V v_it1_246 = heff_field(v_it_245, 0);
    heff_take(v_it_245, 1ULL);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_MkPair: {
      V v_from_247 = heff_field(v_it1_246, 0);
      V v_to_248 = heff_field(v_it1_246, 1);
      heff_take(v_it1_246, 3ULL);
      V v_t_249 = (g_heff_2eproject_2eshowPackage(v_pk_241));
      V v_t_2410 = heff_strSlice(heff_dup(v_src_240), v_to_248, heff_strLength(heff_dup(v_src_240)));
      return heff_strAppend(heff_strSlice(v_src_240, MK_INT(0LL), v_from_247), heff_strAppend(v_t_249, v_t_2410));
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2eproject_2ewithPackage_entry(V self, V *a) {
  (void)self;
  return g_heff_2eproject_2ewithPackage(a[0], a[1]);
}