// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadVariant 54613
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_Kept 49931
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkSegment 38079
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_PVar 52952
#define TAG_Pinned 8573
#define TAG_RLocal 34280
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unboxed 46787
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_Wants 58903
#define LBL_binder 558177493
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_defines 1776893014
#define LBL_doc 309170
#define LBL_done 9584713
#define LBL_emits 297985818
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_env 310119
#define LBL_expectFrom 460383968
#define LBL_expectTo 956903013
#define LBL_holds 300818350
#define LBL_item 9738202
#define LBL_js 10160
#define LBL_key 315609
#define LBL_long 9823043
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_owner 307523277
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_pre 320797
#define LBL_runs 10007567
#define LBL_severity 75955546
#define LBL_size 10026184
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_task 10048076
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_total 311908190
#define LBL_units 312791945
#define LBL_value 313331083
#define LBL_ver 326173
#define LBL_version 583465758
#define LBL_watch 314261737
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_js__env[] = {LBL_js, LBL_env};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_path__source__span__defines[] = {LBL_path, LBL_source, LBL_span, LBL_defines};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2edriver_2epromoteAt(V, V, V, V);
V g_heff_2ebuild_2edriver_2epromoteAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epromoteAt_clo;
V g_heff_2ebuild_2eproject_2esumBefore(V, V);
V g_heff_2ebuild_2eproject_2esumBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2esumBefore_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eemit_2ebindName(V, V);
V g_heff_2ecompile_2eemit_2ebindName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindName_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2eprimUses(V, V);
V g_heff_2ecompile_2eemit_2eprimUses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimUses_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2efacts_2esureW(V, V);
V g_heff_2ecompile_2efacts_2esureW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureW_clo;
V g_heff_2ecompile_2efacts_2etailApp(V);
V g_heff_2ecompile_2efacts_2etailApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2etailApp_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682(V, V, V);
V g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2elocals_2epatternBinders(V);
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V);
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo;
V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164(V);
V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
V g_heff_2eutil_2ejson_2eescapeGo(V, V, V);
V g_heff_2eutil_2ejson_2eescapeGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2eescapeGo_clo;
V g_heff_2eutil_2ejson_2estringify(V);
V g_heff_2eutil_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2estringify_clo;
V g_list_2eall_24s1194065168x228565983(V, V);
V g_list_2eall_24s1194065168x228565983_entry(V self, V *a);
extern Clo g_list_2eall_24s1194065168x228565983_clo;
V g_list_2eall_24s1373454977x2143028054(V);
V g_list_2eall_24s1373454977x2143028054_entry(V self, V *a);
extern Clo g_list_2eall_24s1373454977x2143028054_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1081981235x855852216(V, V);
V g_list_2eany_24s1081981235x855852216_entry(V self, V *a);
extern Clo g_list_2eany_24s1081981235x855852216_clo;
V g_list_2eany_24s1177057410x67789151(V, V);
V g_list_2eany_24s1177057410x67789151_entry(V self, V *a);
extern Clo g_list_2eany_24s1177057410x67789151_clo;
V g_list_2eany_24s1182572632x117717553(V, V, V, V, V);
V g_list_2eany_24s1182572632x117717553_entry(V self, V *a);
extern Clo g_list_2eany_24s1182572632x117717553_clo;
V g_list_2eany_24s378803910x892125795(V);
V g_list_2eany_24s378803910x892125795_entry(V self, V *a);
extern Clo g_list_2eany_24s378803910x892125795_clo;
V g_list_2eany_24s495437461x764444341(V);
V g_list_2eany_24s495437461x764444341_entry(V self, V *a);
extern Clo g_list_2eany_24s495437461x764444341_clo;
V g_list_2econcatMap(V, V);
V g_list_2econcatMap_entry(V self, V *a);
extern Clo g_list_2econcatMap_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24f1490579794x1456232270_24dps(V, V, V, V, V, V, V, V);
V g_list_2efilter_24f1490579794x1456232270_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24f1490579794x1456232270_24dps_clo;
V g_list_2efilter_24s1064353769x1815078842_24dps(V, V);
V g_list_2efilter_24s1064353769x1815078842_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1064353769x1815078842_24dps_clo;
V g_list_2efilter_24s1330420811x172858565(V, V, V, V);
V g_list_2efilter_24s1330420811x172858565_entry(V self, V *a);
extern Clo g_list_2efilter_24s1330420811x172858565_clo;
V g_list_2efilter_24s1330420811x172858565_24dps(V, V, V, V, V);
V g_list_2efilter_24s1330420811x172858565_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1330420811x172858565_24dps_clo;
V g_list_2efilter_24s1725367856x1498536808(V);
V g_list_2efilter_24s1725367856x1498536808_entry(V self, V *a);
extern Clo g_list_2efilter_24s1725367856x1498536808_clo;
V g_list_2efilter_24s1725367856x1498536808_24dps(V, V);
V g_list_2efilter_24s1725367856x1498536808_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1725367856x1498536808_24dps_clo;
V g_list_2efilter_24s1875062608x222844981(V, V, V, V, V, V);
V g_list_2efilter_24s1875062608x222844981_entry(V self, V *a);
extern Clo g_list_2efilter_24s1875062608x222844981_clo;
V g_list_2efilter_24s1875062608x222844981_24dps(V, V, V, V, V, V, V);
V g_list_2efilter_24s1875062608x222844981_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1875062608x222844981_24dps_clo;
V g_list_2efilter_24s1966236437x1225976932_24dps(V, V, V);
V g_list_2efilter_24s1966236437x1225976932_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1966236437x1225976932_24dps_clo;
V g_list_2efilter_24s1967523567x64647275_24dps(V, V);
V g_list_2efilter_24s1967523567x64647275_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1967523567x64647275_24dps_clo;
V g_list_2efilter_24s2085830190x1097871222(V);
V g_list_2efilter_24s2085830190x1097871222_entry(V self, V *a);
extern Clo g_list_2efilter_24s2085830190x1097871222_clo;
V g_list_2efilter_24s2085830190x1097871222_24dps(V, V);
V g_list_2efilter_24s2085830190x1097871222_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2085830190x1097871222_24dps_clo;
V g_list_2efilter_24s316268077x2111002396(V, V);
V g_list_2efilter_24s316268077x2111002396_entry(V self, V *a);
extern Clo g_list_2efilter_24s316268077x2111002396_clo;
V g_list_2efilter_24s999680916x306845608_24dps(V, V, V);
V g_list_2efilter_24s999680916x306845608_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s999680916x306845608_24dps_clo;
V g_list_2efind_24s1230956425x1562898054(V, V);
V g_list_2efind_24s1230956425x1562898054_entry(V self, V *a);
extern Clo g_list_2efind_24s1230956425x1562898054_clo;
V g_list_2efind_24s1303721783x1302064695(V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efind_24s1303721783x1302064695_entry(V self, V *a);
extern Clo g_list_2efind_24s1303721783x1302064695_clo;
V g_list_2efind_24s1504327023x469120796(V, V);
V g_list_2efind_24s1504327023x469120796_entry(V self, V *a);
extern Clo g_list_2efind_24s1504327023x469120796_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1117322828x1334654706(V, V, V);
V g_list_2efoldl_24f1117322828x1334654706_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1117322828x1334654706_clo;
V g_list_2efoldl_24f2064224154x1075431823(V, V, V, V);
V g_list_2efoldl_24f2064224154x1075431823_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2064224154x1075431823_clo;
V g_list_2efoldl_24f297647854x479783049(V, V);
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a);
extern Clo g_list_2efoldl_24f297647854x479783049_clo;
V g_list_2efoldl_24f891411706x655200538(V, V);
V g_list_2efoldl_24f891411706x655200538_entry(V self, V *a);
extern Clo g_list_2efoldl_24f891411706x655200538_clo;
V g_list_2efoldl_24s1004873070x1577485130(V, V, V);
V g_list_2efoldl_24s1004873070x1577485130_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1004873070x1577485130_clo;
V g_list_2efoldl_24s1134919403x2060330530(V, V);
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1134919403x2060330530_clo;
V g_list_2efoldl_24s1149369025x804005338(V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1149369025x804005338_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1149369025x804005338_clo;
V g_list_2efoldl_24s135909237x326578890(V, V);
V g_list_2efoldl_24s135909237x326578890_entry(V self, V *a);
extern Clo g_list_2efoldl_24s135909237x326578890_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s1483820613x1826490246(V, V);
V g_list_2efoldl_24s1483820613x1826490246_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1483820613x1826490246_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2efoldl_24s1798985515x221942800(V, V);
V g_list_2efoldl_24s1798985515x221942800_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1798985515x221942800_clo;
V g_list_2efoldl_24s1894035205x969464323(V, V, V);
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1894035205x969464323_clo;
V g_list_2efoldl_24s2002556150x421739076(V, V);
V g_list_2efoldl_24s2002556150x421739076_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2002556150x421739076_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s2051016282x1892781518(V, V, V, V);
V g_list_2efoldl_24s2051016282x1892781518_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2051016282x1892781518_clo;
V g_list_2efoldl_24s2099124872x600887319(V, V);
V g_list_2efoldl_24s2099124872x600887319_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2099124872x600887319_clo;
V g_list_2efoldl_24s2134067310x2049132013(V, V);
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2134067310x2049132013_clo;
V g_list_2efoldl_24s243940296x1179168444(V, V);
V g_list_2efoldl_24s243940296x1179168444_entry(V self, V *a);
extern Clo g_list_2efoldl_24s243940296x1179168444_clo;
V g_list_2efoldl_24s378225814x484524589(V, V);
V g_list_2efoldl_24s378225814x484524589_entry(V self, V *a);
extern Clo g_list_2efoldl_24s378225814x484524589_clo;
V g_list_2efoldl_24s398854970x1533504811(V, V);
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a);
extern Clo g_list_2efoldl_24s398854970x1533504811_clo;
V g_list_2efoldl_24s421921225x565177679(V, V);
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a);
extern Clo g_list_2efoldl_24s421921225x565177679_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2efoldl_24s489050722x1368997552(V, V);
V g_list_2efoldl_24s489050722x1368997552_entry(V self, V *a);
extern Clo g_list_2efoldl_24s489050722x1368997552_clo;
V g_list_2efoldl_24s491084544x100802329(V, V);
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s491084544x100802329_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s728686882x2096535788(V, V, V);
V g_list_2efoldl_24s728686882x2096535788_entry(V self, V *a);
extern Clo g_list_2efoldl_24s728686882x2096535788_clo;
V g_list_2efoldl_24s809624008x2043497973(V, V);
V g_list_2efoldl_24s809624008x2043497973_entry(V self, V *a);
extern Clo g_list_2efoldl_24s809624008x2043497973_clo;
V g_list_2efoldl_24s950896375x422349662(V, V);
V g_list_2efoldl_24s950896375x422349662_entry(V self, V *a);
extern Clo g_list_2efoldl_24s950896375x422349662_clo;
V g_list_2emap_24f130772758x674845987(V, V, V, V);
V g_list_2emap_24f130772758x674845987_entry(V self, V *a);
extern Clo g_list_2emap_24f130772758x674845987_clo;
V g_list_2emap_24f130772758x674845987_24dps(V, V, V, V, V);
V g_list_2emap_24f130772758x674845987_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f130772758x674845987_24dps_clo;
V g_list_2emap_24f1638246995x433291654(V, V, V);
V g_list_2emap_24f1638246995x433291654_entry(V self, V *a);
extern Clo g_list_2emap_24f1638246995x433291654_clo;
V g_list_2emap_24f1638246995x433291654_24dps(V, V, V, V);
V g_list_2emap_24f1638246995x433291654_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1638246995x433291654_24dps_clo;
V g_list_2emap_24f1799988110x1394031252(V, V, V, V);
V g_list_2emap_24f1799988110x1394031252_entry(V self, V *a);
extern Clo g_list_2emap_24f1799988110x1394031252_clo;
V g_list_2emap_24f1799988110x1394031252_24dps(V, V, V, V, V);
V g_list_2emap_24f1799988110x1394031252_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1799988110x1394031252_24dps_clo;
V g_list_2emap_24f378206553x1816388893(V, V, V, V);
V g_list_2emap_24f378206553x1816388893_entry(V self, V *a);
extern Clo g_list_2emap_24f378206553x1816388893_clo;
V g_list_2emap_24f378206553x1816388893_24dps(V, V, V, V, V);
V g_list_2emap_24f378206553x1816388893_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f378206553x1816388893_24dps_clo;
V g_list_2emap_24f990982947x2126256822(V, V);
V g_list_2emap_24f990982947x2126256822_entry(V self, V *a);
extern Clo g_list_2emap_24f990982947x2126256822_clo;
V g_list_2emap_24f990982947x2126256822_24dps(V, V, V);
V g_list_2emap_24f990982947x2126256822_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f990982947x2126256822_24dps_clo;
V g_list_2emap_24s1004924153x684987219(V, V, V);
V g_list_2emap_24s1004924153x684987219_entry(V self, V *a);
extern Clo g_list_2emap_24s1004924153x684987219_clo;
V g_list_2emap_24s1004924153x684987219_24dps(V, V, V, V);
V g_list_2emap_24s1004924153x684987219_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1004924153x684987219_24dps_clo;
V g_list_2emap_24s1068592055x839006909(V, V, V, V);
V g_list_2emap_24s1068592055x839006909_entry(V self, V *a);
extern Clo g_list_2emap_24s1068592055x839006909_clo;
V g_list_2emap_24s1146657978x434453078(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1146657978x434453078_entry(V self, V *a);
extern Clo g_list_2emap_24s1146657978x434453078_clo;
V g_list_2emap_24s1146657978x434453078_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1146657978x434453078_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1146657978x434453078_24dps_clo;
V g_list_2emap_24s1146729723x1441207893(V, V, V);
V g_list_2emap_24s1146729723x1441207893_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_clo;
V g_list_2emap_24s1146729723x1441207893_24dps(V, V, V, V);
V g_list_2emap_24s1146729723x1441207893_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_24dps_clo;
V g_list_2emap_24s1181937096x2120532116_24dps(V, V);
V g_list_2emap_24s1181937096x2120532116_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_24dps_clo;
V g_list_2emap_24s1230969749x2018313496_24dps(V, V);
V g_list_2emap_24s1230969749x2018313496_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_24dps_clo;
V g_list_2emap_24s1234524601x742515152(V);
V g_list_2emap_24s1234524601x742515152_entry(V self, V *a);
extern Clo g_list_2emap_24s1234524601x742515152_clo;
V g_list_2emap_24s1234524601x742515152_24dps(V, V);
V g_list_2emap_24s1234524601x742515152_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1234524601x742515152_24dps_clo;
V g_list_2emap_24s1387309293x1990579214_24dps(V, V);
V g_list_2emap_24s1387309293x1990579214_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1387309293x1990579214_24dps_clo;
V g_list_2emap_24s1397747289x2145601499(V);
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_clo;
V g_list_2emap_24s1397747289x2145601499_24dps(V, V);
V g_list_2emap_24s1397747289x2145601499_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_24dps_clo;
V g_list_2emap_24s1409451498x400757684_24dps(V, V);
V g_list_2emap_24s1409451498x400757684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1409451498x400757684_24dps_clo;
V g_list_2emap_24s1534167768x1221742344_24dps(V, V);
V g_list_2emap_24s1534167768x1221742344_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1534167768x1221742344_24dps_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s1598879313x231311047_24dps(V, V);
V g_list_2emap_24s1598879313x231311047_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_24dps_clo;
V g_list_2emap_24s1661513421x830177447(V, V, V);
V g_list_2emap_24s1661513421x830177447_entry(V self, V *a);
extern Clo g_list_2emap_24s1661513421x830177447_clo;
V g_list_2emap_24s1661513421x830177447_24dps(V, V, V, V);
V g_list_2emap_24s1661513421x830177447_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1661513421x830177447_24dps_clo;
V g_list_2emap_24s1688457226x2006118782_24dps(V, V);
V g_list_2emap_24s1688457226x2006118782_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1688457226x2006118782_24dps_clo;
V g_list_2emap_24s1703643582x349630108_24dps(V, V, V);
V g_list_2emap_24s1703643582x349630108_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1703643582x349630108_24dps_clo;
V g_list_2emap_24s1753874608x910016727(V);
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_clo;
V g_list_2emap_24s1753874608x910016727_24dps(V, V);
V g_list_2emap_24s1753874608x910016727_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_24dps_clo;
V g_list_2emap_24s1782778565x402128078_24dps(V, V);
V g_list_2emap_24s1782778565x402128078_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_24dps_clo;
V g_list_2emap_24s179832492x431904054(V);
V g_list_2emap_24s179832492x431904054_entry(V self, V *a);
extern Clo g_list_2emap_24s179832492x431904054_clo;
V g_list_2emap_24s179832492x431904054_24dps(V, V);
V g_list_2emap_24s179832492x431904054_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s179832492x431904054_24dps_clo;
V g_list_2emap_24s1814289659x520383890_24dps(V, V, V, V);
V g_list_2emap_24s1814289659x520383890_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1814289659x520383890_24dps_clo;
V g_list_2emap_24s1816200867x1876638332_24dps(V, V);
V g_list_2emap_24s1816200867x1876638332_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1816200867x1876638332_24dps_clo;
V g_list_2emap_24s1819241345x1511673126_24dps(V, V);
V g_list_2emap_24s1819241345x1511673126_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_24dps_clo;
V g_list_2emap_24s1854779998x1713580578_24dps(V, V);
V g_list_2emap_24s1854779998x1713580578_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1854779998x1713580578_24dps_clo;
V g_list_2emap_24s1887874170x1747433177_24dps(V, V);
V g_list_2emap_24s1887874170x1747433177_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_24dps_clo;
V g_list_2emap_24s18996220x10511024(V);
V g_list_2emap_24s18996220x10511024_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_clo;
V g_list_2emap_24s18996220x10511024_24dps(V, V);
V g_list_2emap_24s18996220x10511024_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_24dps_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1943354043x700174004_24dps(V, V, V, V);
V g_list_2emap_24s1943354043x700174004_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1943354043x700174004_24dps_clo;
V g_list_2emap_24s1947501783x1475115781(V, V, V);
V g_list_2emap_24s1947501783x1475115781_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_clo;
V g_list_2emap_24s1947501783x1475115781_24dps(V, V, V, V);
V g_list_2emap_24s1947501783x1475115781_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_24dps_clo;
V g_list_2emap_24s2000102784x314586828_24dps(V, V);
V g_list_2emap_24s2000102784x314586828_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_24dps_clo;
V g_list_2emap_24s2005951263x462916503_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s2005951263x462916503_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2005951263x462916503_24dps_clo;
V g_list_2emap_24s296585291x885335139(V);
V g_list_2emap_24s296585291x885335139_entry(V self, V *a);
extern Clo g_list_2emap_24s296585291x885335139_clo;
V g_list_2emap_24s296585291x885335139_24dps(V, V);
V g_list_2emap_24s296585291x885335139_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s296585291x885335139_24dps_clo;
V g_list_2emap_24s338694954x1326523169_24dps(V, V);
V g_list_2emap_24s338694954x1326523169_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_24dps_clo;
V g_list_2emap_24s357242026x384251201_24dps(V, V);
V g_list_2emap_24s357242026x384251201_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_24dps_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s366344330x1145113647_24dps(V, V);
V g_list_2emap_24s366344330x1145113647_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_24dps_clo;
V g_list_2emap_24s388004800x1261967008(V);
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_clo;
V g_list_2emap_24s388004800x1261967008_24dps(V, V);
V g_list_2emap_24s388004800x1261967008_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_24dps_clo;
V g_list_2emap_24s391931963x434308123_24dps(V, V);
V g_list_2emap_24s391931963x434308123_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_24dps_clo;
V g_list_2emap_24s456133444x1904936646(V, V, V, V, V, V, V, V);
V g_list_2emap_24s456133444x1904936646_entry(V self, V *a);
extern Clo g_list_2emap_24s456133444x1904936646_clo;
V g_list_2emap_24s456133444x1904936646_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s456133444x1904936646_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s456133444x1904936646_24dps_clo;
V g_list_2emap_24s467798769x1763085075_24dps(V, V);
V g_list_2emap_24s467798769x1763085075_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_24dps_clo;
V g_list_2emap_24s510639937x1058700299(V);
V g_list_2emap_24s510639937x1058700299_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_clo;
V g_list_2emap_24s510639937x1058700299_24dps(V, V);
V g_list_2emap_24s510639937x1058700299_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_24dps_clo;
V g_list_2emap_24s567711145x425963688(V, V, V, V);
V g_list_2emap_24s567711145x425963688_entry(V self, V *a);
extern Clo g_list_2emap_24s567711145x425963688_clo;
V g_list_2emap_24s567711145x425963688_24dps(V, V, V, V, V);
V g_list_2emap_24s567711145x425963688_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s567711145x425963688_24dps_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2emap_24s759871588x920431471_24dps(V, V);
V g_list_2emap_24s759871588x920431471_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_24dps_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;
V g_list_2emap_24s79542405x478516404_24dps(V, V);
V g_list_2emap_24s79542405x478516404_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_24dps_clo;
V g_list_2emap_24s796727596x829078925(V);
V g_list_2emap_24s796727596x829078925_entry(V self, V *a);
extern Clo g_list_2emap_24s796727596x829078925_clo;
V g_list_2emap_24s796727596x829078925_24dps(V, V);
V g_list_2emap_24s796727596x829078925_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s796727596x829078925_24dps_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_list_2emap_24s803586165x1676441765_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_24dps_clo;
V g_list_2emap_24s89567162x1162500052_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s89567162x1162500052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s89567162x1162500052_24dps_clo;
V g_list_2emap_24s917234327x1197288555(V);
V g_list_2emap_24s917234327x1197288555_entry(V self, V *a);
extern Clo g_list_2emap_24s917234327x1197288555_clo;
V g_list_2emap_24s917234327x1197288555_24dps(V, V);
V g_list_2emap_24s917234327x1197288555_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s917234327x1197288555_24dps_clo;
V g_list_2emap_24s939813003x1383013550(V);
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_clo;
V g_list_2emap_24s939813003x1383013550_24dps(V, V);
V g_list_2emap_24s939813003x1383013550_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_24dps_clo;
V g_list_2emap_24s976303750x321235480(V);
V g_list_2emap_24s976303750x321235480_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_clo;
V g_list_2emap_24s976303750x321235480_24dps(V, V);
V g_list_2emap_24s976303750x321235480_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_24dps_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emerge_24dps(V, V, V, V);
V g_list_2emerge_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24dps_clo;
V g_list_2emerge_24s132798885x1165759438(V, V);
V g_list_2emerge_24s132798885x1165759438_entry(V self, V *a);
extern Clo g_list_2emerge_24s132798885x1165759438_clo;
V g_list_2emerge_24s132798885x1165759438_24dps(V, V, V);
V g_list_2emerge_24s132798885x1165759438_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s132798885x1165759438_24dps_clo;
V g_list_2emerge_24s1904498032x521599863(V, V);
V g_list_2emerge_24s1904498032x521599863_entry(V self, V *a);
extern Clo g_list_2emerge_24s1904498032x521599863_clo;
V g_list_2emerge_24s1904498032x521599863_24dps(V, V, V);
V g_list_2emerge_24s1904498032x521599863_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1904498032x521599863_24dps_clo;
V g_list_2emerge_24s509014022x1733915733_24dps(V, V, V);
V g_list_2emerge_24s509014022x1733915733_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s509014022x1733915733_24dps_clo;
V g_list_2erange_24dps(V, V, V);
V g_list_2erange_24dps_entry(V self, V *a);
extern Clo g_list_2erange_24dps_clo;
V g_list_2ereplicate_24dps(V, V, V);
V g_list_2ereplicate_24dps_entry(V self, V *a);
extern Clo g_list_2ereplicate_24dps_clo;
V g_list_2esortBy_24s1230002843x105774350(V);
V g_list_2esortBy_24s1230002843x105774350_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1230002843x105774350_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24dps(V, V, V, V);
V g_list_2ezipWith_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24dps_clo;
V g_list_2ezipWith_24s1149721393x617397893(V, V, V);
V g_list_2ezipWith_24s1149721393x617397893_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1149721393x617397893_clo;
V g_list_2ezipWith_24s1149721393x617397893_24dps(V, V, V, V);
V g_list_2ezipWith_24s1149721393x617397893_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1149721393x617397893_24dps_clo;
V g_list_2ezipWith_24s29557946x653938035(V, V);
V g_list_2ezipWith_24s29557946x653938035_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s29557946x653938035_clo;
V g_list_2ezipWith_24s29557946x653938035_24dps(V, V, V);
V g_list_2ezipWith_24s29557946x653938035_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s29557946x653938035_24dps_clo;
V g_list_2ezipWith_24s870182194x1066240094(V, V);
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_clo;
V g_list_2ezipWith_24s870182194x1066240094_24dps(V, V, V);
V g_list_2ezipWith_24s870182194x1066240094_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_24dps_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1537904782x516751275(V, V);
V g_prelude_2e_2b_2b_24f1537904782x516751275_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1537904782x516751275_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2ecli_2eflagLine(V);
V g_std_2ecli_2eflagLine_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagLine_clo;
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
V g_list_2econcatMap_lam0(V self, V *args);
Clo g_list_2econcatMap_clo = {{0x80000000u, K_CLO, 0}, g_list_2econcatMap_entry, 2, 0};

V g_list_2econcatMap(V v_f_240, V v_xs_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  return ({ V a_0 = heff_clo_n(g_list_2econcatMap_lam0, 2, 1, (V[]){v_f_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_list_2econcatMap_entry(V self, V *a) {
  (void)self;
  return g_list_2econcatMap(a[0], a[1]);
}
V g_list_2econcatMap_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_244}));
  return (g_prelude_2e_2b_2b(v_t_245, v_acc_243));
}
Clo g_list_2ezipWith_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24dps_entry, 4, 0};

V g_list_2ezipWith_24dps(V v_f_240, V v_xs_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_ys_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_xs_241, 0);
    V v_xs2_245 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_f_240);
      heff_drop(v_x_244);
      heff_drop(v_xs2_245);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_ys_242, 0);
      V v_ys2_247 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_248 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_x_244, v_y_246}));
      V v_cell_249 = heff_tag_at_n(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_f_240;
      V t_1 = v_xs2_245;
      V t_2 = v_ys2_247;
      V t_3 = v_cell_249;
      v_f_240 = t_0;
      v_xs_241 = t_1;
      v_ys_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2ezipWith_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2erange_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2erange_24dps_entry, 3, 0};

V g_list_2erange_24dps(V v_a_240, V v_b_241, V v_d_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_241), heff_dup(v_a_240))) {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_240), heff_hole()});
    V v_u_245 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = heff_intAdd(v_a_240, MK_INT(1LL));
    V t_1 = v_b_241;
    V t_2 = v_cell_244;
    v_a_240 = t_0;
    v_b_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_list_2erange_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2erange_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ereplicate_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ereplicate_24dps_entry, 3, 0};

V g_list_2ereplicate_24dps(V v_n_240, V v_x_241, V v_d_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_x_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_u_245 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_x_241;
    V t_2 = v_cell_244;
    v_n_240 = t_0;
    v_x_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_list_2ereplicate_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ereplicate_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emerge_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_entry, 3, 0};

V g_list_2emerge(V v_le_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      return v_xs_241;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      V v_ru_24ys_242_24Cons = heff_take_reuse_n(v_ys_242, 3ULL, 2);
      heff_drop_tag(v_xs_241, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){heff_dup(v_x_243), heff_dup(v_y_245)}));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_cell_248 = heff_tag_at_n(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_249 = (g_list_2emerge_24dps(v_le_240, v_xs2_244, heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246}), heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      } else {
        heff_drop(v_t_247);
        V v_cell_2410 = heff_tag_at_n(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2411 = (g_list_2emerge_24dps(v_le_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244}), v_ys2_246, heff_dup(v_cell_2410)));
        heff_drop(v_u_2411);
        return v_cell_2410;
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2emerge_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s366344330x1145113647_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366344330x1145113647_entry, 1, 0};

V g_list_2emap_24s366344330x1145113647(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s366344330x1145113647_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366344330x1145113647(a[0]);
}
Clo g_list_2emap_24s366344330x1145113647_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366344330x1145113647_24dps_entry, 2, 0};

V g_list_2emap_24s366344330x1145113647_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366344330x1145113647_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366344330x1145113647_24dps(a[0], a[1]);
}
Clo g_list_2efind_24s1303721783x1302064695_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1303721783x1302064695_entry, 32, 0};

V g_list_2efind_24s1303721783x1302064695(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_lit_2412, V v_lit_2413, V v_lit_2414, V v_lit_2415, V v_lit_2416, V v_lit_2417, V v_lit_2418, V v_lit_2419, V v_lit_2420, V v_lit_2421, V v_lit_2422, V v_lit_2423, V v_lit_2424, V v_lit_2425, V v_lit_2426, V v_lit_2427, V v_lit_2428, V v_lit_2429, V v_lit_2430, V v_x2_2431) {
top: ;
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    heff_drop(v_lit_2410);
    heff_drop(v_lit_2411);
    heff_drop(v_lit_2412);
    heff_drop(v_lit_2413);
    heff_drop(v_lit_2414);
    heff_drop(v_lit_2415);
    heff_drop(v_lit_2416);
    heff_drop(v_lit_2417);
    heff_drop(v_lit_2418);
    heff_drop(v_lit_2419);
    heff_drop(v_lit_2420);
    heff_drop(v_lit_2421);
    heff_drop(v_lit_2422);
    heff_drop(v_lit_2423);
    heff_drop(v_lit_2424);
    heff_drop(v_lit_2425);
    heff_drop(v_lit_2426);
    heff_drop(v_lit_2427);
    heff_drop(v_lit_2428);
    heff_drop(v_lit_2429);
    heff_drop(v_lit_2430);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_xs_2433 = heff_field(v_x2_2431, 1);
    V v_t_2434;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_I8: {
      v_t_2434 = heff_dup(v_lit_241);
      break;
    }
    case TAG_I16: {
      v_t_2434 = heff_dup(v_lit_242);
      break;
    }
    case TAG_I32: {
      v_t_2434 = heff_dup(v_lit_243);
      break;
    }
    case TAG_I64: {
      v_t_2434 = heff_dup(v_lit_244);
      break;
    }
    case TAG_U8: {
      v_t_2434 = heff_dup(v_lit_245);
      break;
    }
    case TAG_U16: {
      v_t_2434 = heff_dup(v_lit_246);
      break;
    }
    case TAG_U32: {
      v_t_2434 = heff_dup(v_lit_247);
      break;
    }
    case TAG_U64: {
      v_t_2434 = heff_dup(v_lit_248);
      break;
    }
    case TAG_F32: {
      v_t_2434 = heff_dup(v_lit_249);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    V v_t_2435;
    switch (heff_tag_of(v_x_2432)) {
    case TAG_OpAdd: {
      v_t_2435 = heff_dup(v_lit_2410);
      break;
    }
    case TAG_OpSub: {
      v_t_2435 = heff_dup(v_lit_2411);
      break;
    }
    case TAG_OpMul: {
      v_t_2435 = heff_dup(v_lit_2412);
      break;
    }
    case TAG_OpDiv: {
      v_t_2435 = heff_dup(v_lit_2413);
      break;
    }
    case TAG_OpRem: {
      v_t_2435 = heff_dup(v_lit_2414);
      break;
    }
    case TAG_OpEq: {
      v_t_2435 = heff_dup(v_lit_2415);
      break;
    }
    case TAG_OpLt: {
      v_t_2435 = heff_dup(v_lit_2416);
      break;
    }
    case TAG_OpLe: {
      v_t_2435 = heff_dup(v_lit_2417);
      break;
    }
    case TAG_OpAnd: {
      v_t_2435 = heff_dup(v_lit_2418);
      break;
    }
    case TAG_OpOr: {
      v_t_2435 = heff_dup(v_lit_2419);
      break;
    }
    case TAG_OpXor: {
      v_t_2435 = heff_dup(v_lit_2420);
      break;
    }
    case TAG_OpShl: {
      v_t_2435 = heff_dup(v_lit_2421);
      break;
    }
    case TAG_OpShr: {
      v_t_2435 = heff_dup(v_lit_2422);
      break;
    }
    case TAG_OpShow: {
      v_t_2435 = heff_dup(v_lit_2423);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2435 = heff_dup(v_lit_2424);
      break;
    }
    case TAG_OpToInt: {
      v_t_2435 = heff_dup(v_lit_2425);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2435 = heff_dup(v_lit_2426);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2435 = heff_dup(v_lit_2427);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2435 = heff_dup(v_lit_2428);
      break;
    }
    case TAG_OpFloor: {
      v_t_2435 = heff_dup(v_lit_2429);
      break;
    }
    default: heff_nomatch(v_x_2432);
    }
    if (heff_strEq_c(heff_strAppend(v_t_2434, v_t_2435), heff_dup(v_lit_2430))) {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_lit_247);
      heff_drop(v_lit_248);
      heff_drop(v_lit_249);
      heff_drop(v_lit_2410);
      heff_drop(v_lit_2411);
      heff_drop(v_lit_2412);
      heff_drop(v_lit_2413);
      heff_drop(v_lit_2414);
      heff_drop(v_lit_2415);
      heff_drop(v_lit_2416);
      heff_drop(v_lit_2417);
      heff_drop(v_lit_2418);
      heff_drop(v_lit_2419);
      heff_drop(v_lit_2420);
      heff_drop(v_lit_2421);
      heff_drop(v_lit_2422);
      heff_drop(v_lit_2423);
      heff_drop(v_lit_2424);
      heff_drop(v_lit_2425);
      heff_drop(v_lit_2426);
      heff_drop(v_lit_2427);
      heff_drop(v_lit_2428);
      heff_drop(v_lit_2429);
      heff_drop(v_lit_2430);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2432)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_lit_2410;
      V t_11 = v_lit_2411;
      V t_12 = v_lit_2412;
      V t_13 = v_lit_2413;
      V t_14 = v_lit_2414;
      V t_15 = v_lit_2415;
      V t_16 = v_lit_2416;
      V t_17 = v_lit_2417;
      V t_18 = v_lit_2418;
      V t_19 = v_lit_2419;
      V t_20 = v_lit_2420;
      V t_21 = v_lit_2421;
      V t_22 = v_lit_2422;
      V t_23 = v_lit_2423;
      V t_24 = v_lit_2424;
      V t_25 = v_lit_2425;
      V t_26 = v_lit_2426;
      V t_27 = v_lit_2427;
      V t_28 = v_lit_2428;
      V t_29 = v_lit_2429;
      V t_30 = v_lit_2430;
      V t_31 = v_xs_2433;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_lit_2411 = t_11;
      v_lit_2412 = t_12;
      v_lit_2413 = t_13;
      v_lit_2414 = t_14;
      v_lit_2415 = t_15;
      v_lit_2416 = t_16;
      v_lit_2417 = t_17;
      v_lit_2418 = t_18;
      v_lit_2419 = t_19;
      v_lit_2420 = t_20;
      v_lit_2421 = t_21;
      v_lit_2422 = t_22;
      v_lit_2423 = t_23;
      v_lit_2424 = t_24;
      v_lit_2425 = t_25;
      v_lit_2426 = t_26;
      v_lit_2427 = t_27;
      v_lit_2428 = t_28;
      v_lit_2429 = t_29;
      v_lit_2430 = t_30;
      v_x2_2431 = t_31;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_list_2efind_24s1303721783x1302064695_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a31 = a[31]; V r = g_list_2efind_24s1303721783x1302064695(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a[13], a[14], a[15], a[16], a[17], a[18], a[19], a[20], a[21], a[22], a[23], a[24], a[25], a[26], a[27], a[28], a[29], a[30], a31); heff_drop(a0); heff_drop(a31); return r;
}
HEFF_LIT(g_list_2emap_24s1409451498x400757684_24dps_str0, 0, "");
Clo g_list_2emap_24s1409451498x400757684_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1409451498x400757684_24dps_entry, 2, 0};

V g_list_2emap_24s1409451498x400757684_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_dup(heff_rfield(v_x_242, 2)), heff_dup(heff_rfield(v_x_242, 3)), heff_tag_n(TAG_Just, 1, (V[]){v_x_242}), ((V)&g_list_2emap_24s1409451498x400757684_24dps_str0), MK_INT(0LL), MK_INT(0LL)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1409451498x400757684_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1409451498x400757684_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1688457226x2006118782_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1688457226x2006118782_24dps_entry, 2, 0};

V g_list_2emap_24s1688457226x2006118782_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1688457226x2006118782_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1688457226x2006118782_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1887874170x1747433177_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1887874170x1747433177_24dps_entry, 2, 0};

V g_list_2emap_24s1887874170x1747433177_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_x_242));
    V v_t_2414;
    switch (heff_tag_of(v_a_244)) {
    case TAG_IsInferable: {
      V v_a_245 = heff_field(v_a_244, 0);
      V v_ru_24a_244_24IsInferable = heff_take_reuse_n(v_a_244, 1ULL, 1);
      V v_t_248;
      switch (heff_tag_of(v_a_245)) {
      case TAG_At: {
        V v_a_247 = heff_dup(heff_field(v_a_245, 1));
        v_t_248 = v_a_247;
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24IsInferable, TAG_TInf, 1, (V[]){v_a_245}), v_t_248});
      break;
    }
    case TAG_IsCheckable: {
      V v_a_249 = heff_field(v_a_244, 0);
      V v_ru_24a_244_24IsCheckable = heff_take_reuse_n(v_a_244, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_a_249)) {
      case TAG_At: {
        V v_a_2411 = heff_dup(heff_field(v_a_249, 1));
        v_t_2412 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_a_249);
      }
      v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24IsCheckable, TAG_TChk, 1, (V[]){v_a_249}), v_t_2412});
      break;
    }
    case TAG_IsType: {
      V v_a_2413 = heff_field(v_a_244, 0);
      heff_take_n(v_a_244, 1ULL, 1);
      v_t_2414 = v_a_2413;
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2415;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1887874170x1747433177_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1887874170x1747433177_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1230969749x2018313496_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230969749x2018313496_24dps_entry, 2, 0};

V g_list_2emap_24s1230969749x2018313496_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1230969749x2018313496_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230969749x2018313496_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s79542405x478516404_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s79542405x478516404_entry, 1, 0};

V g_list_2emap_24s79542405x478516404(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_243));
      v_t_246 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s79542405x478516404_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s79542405x478516404_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s79542405x478516404(a[0]);
}
Clo g_list_2emap_24s1782778565x402128078_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1782778565x402128078_24dps_entry, 2, 0};

V g_list_2emap_24s1782778565x402128078_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2414;
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkEquation: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_ru_24a_244_24MkEquation = heff_take_reuse_n(v_a_244, 15ULL, 4);
        V v_t_2413;
        switch (heff_tag_of(v_a_249)) {
        case TAG_At: {
          V v_a_2410 = heff_field(v_a_249, 0);
          V v_a_2411 = heff_field(v_a_249, 1);
          heff_take_n(v_a_249, 3ULL, 2);
          V v_t_2412 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2410));
          v_t_2413 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2412, v_a_2411});
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2414 = heff_tag_at_n(v_ru_24a_244_24MkEquation, TAG_MkEquation, 4, (V[]){v_a_246, v_a_247, v_a_248, v_t_2413});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2416));
    heff_drop(v_u_2417);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2416;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1782778565x402128078_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1782778565x402128078_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s1330420811x172858565_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1330420811x172858565_entry, 4, 0};

V g_list_2efilter_24s1330420811x172858565(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_rfield(v_x_244, 1)));
    if (heff_intEq_c(v_t_246, heff_dup(v_lit_242))) {
      heff_drop_rec(v_x_244, 8);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = (g_list_2efilter_24s1330420811x172858565_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s1330420811x172858565_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1330420811x172858565(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s338694954x1326523169_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s338694954x1326523169_24dps_entry, 2, 0};

V g_list_2emap_24s338694954x1326523169_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_242, 0), heff_take_field(v_x_242, 1)});
    V v_t_245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_get_n(v_x_242, 2, 3), v_t_244, NTAG(TAG_Nothing)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s338694954x1326523169_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s338694954x1326523169_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s378803910x892125795_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s378803910x892125795_entry, 1, 0};

V g_list_2eany_24s378803910x892125795(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2ecapturing(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s378803910x892125795_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s378803910x892125795(a0); heff_drop(a0); return r;
}
Clo g_list_2eall_24s1194065168x228565983_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1194065168x228565983_entry, 2, 0};

V g_list_2eall_24s1194065168x228565983(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_246, v_lit_240, 1)) {
      heff_drop(v_lit_240);
      return NTAG(TAG_False);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s1194065168x228565983_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall_24s1194065168x228565983(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1598879313x231311047_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1598879313x231311047_entry, 1, 0};

V g_list_2emap_24s1598879313x231311047(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_RepV), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1598879313x231311047_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1598879313x231311047(a[0]);
}
Clo g_list_2emap_24s1598879313x231311047_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1598879313x231311047_24dps_entry, 2, 0};

V g_list_2emap_24s1598879313x231311047_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_RepV), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1598879313x231311047_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1598879313x231311047_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s728686882x2096535788_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s728686882x2096535788_entry, 3, 0};

V g_list_2efoldl_24s728686882x2096535788(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 2, (V[]){heff_dup(v_lit_240), v_x_243}), v_z_241});
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s728686882x2096535788_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s728686882x2096535788(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1134919403x2060330530_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1134919403x2060330530_entry, 2, 0};

V g_list_2efoldl_24s1134919403x2060330530(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Merge: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Boxed: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Unboxed: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Literal: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Wants: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Binds: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Pinned: {
      V v_x_2414 = heff_field(v_x_242, 0);
      v_t_2417 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_2414), NTAG(TAG_MkUnit), v_z_240));
      break;
    }
    case TAG_Kept: {
      v_t_2417 = v_z_240;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2417;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1134919403x2060330530(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s495437461x764444341_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s495437461x764444341_entry, 1, 0};

V g_list_2eany_24s495437461x764444341(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2ecompile_2efacts_2etailApp(a_0)); heff_drop(v_t_246); r_; });
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_247);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s495437461x764444341_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s495437461x764444341(a0); heff_drop(a0); return r;
}
Clo g_list_2efilter_24s2085830190x1097871222_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2085830190x1097871222_entry, 1, 0};

V g_list_2efilter_24s2085830190x1097871222(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      heff_take_n(v_t_245, 0ULL, 2);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_249 = (g_list_2efilter_24s2085830190x1097871222_24dps(v_xs_242, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s2085830190x1097871222_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2085830190x1097871222(a[0]);
}
Clo g_list_2efoldl_24s243940296x1179168444_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s243940296x1179168444_entry, 2, 0};

V g_list_2efoldl_24s243940296x1179168444(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), NTAG(TAG_Nil)});
    V v_t_245 = (g_heff_2ecompile_2efacts_2esureW(v_z_240, v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s243940296x1179168444_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s243940296x1179168444(a[0], a[1]);
}
Clo g_list_2emap_24s1947501783x1475115781_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1947501783x1475115781_entry, 3, 0};

V g_list_2emap_24s1947501783x1475115781(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_intSub(heff_intSub(heff_dup(v_lit_240), v_x_243), heff_dup(v_lit_241));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1947501783x1475115781_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1947501783x1475115781_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1947501783x1475115781(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_str0, 1, "\"");
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_str1, 1, "\"");
Clo g_list_2emap_24s1397747289x2145601499_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1397747289x2145601499_entry, 1, 0};

V g_list_2emap_24s1397747289x2145601499(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2eprint_2eescFrom(v_x_241, MK_INT(0LL)));
    V v_t_244 = heff_strAppend(((V)&g_list_2emap_24s1397747289x2145601499_str0), heff_strAppend(v_t_243, ((V)&g_list_2emap_24s1397747289x2145601499_str1)));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1397747289x2145601499_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1397747289x2145601499(a[0]);
}
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_24dps_str0, 5, "(0 - ");
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_24dps_str1, 1, ")");
Clo g_list_2emap_24s1181937096x2120532116_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1181937096x2120532116_24dps_entry, 2, 0};

V g_list_2emap_24s1181937096x2120532116_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    if (heff_intLt_c(heff_dup(v_x_242), MK_INT(0LL))) {
      V v_t_245 = heff_intShow(heff_intSub(MK_INT(0LL), v_x_242));
      v_t_246 = heff_strAppend(((V)&g_list_2emap_24s1181937096x2120532116_24dps_str0), heff_strAppend(v_t_245, ((V)&g_list_2emap_24s1181937096x2120532116_24dps_str1)));
    } else {
      v_t_246 = heff_intShow(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1181937096x2120532116_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1181937096x2120532116_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s89567162x1162500052_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s89567162x1162500052_24dps_entry, 8, 0};

V g_list_2emap_24s89567162x1162500052_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      V v_t_2412 = (g_heff_2eelab_2eprint_2eescFrom(v_a_2410, heff_dup(v_lit_242)));
      V v_t_2413 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2412, heff_dup(v_lit_243)));
      V v_t_2414 = ({ V a_0 = v_a_2411; V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(a_0)); heff_drop(v_a_2411); r_; });
      V v_t_2415 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2414, heff_dup(v_lit_245)));
      v_t_2416 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2413, v_t_2415));
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s89567162x1162500052_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s89567162x1162500052_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2efilter_24s1966236437x1225976932_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1966236437x1225976932_24dps_entry, 3, 0};

V g_list_2efilter_24s1966236437x1225976932_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_243)) {
    case TAG_UpdateTo: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_2413 = v_a_245;
      break;
    }
    case TAG_UpdateIn: {
      V v_a_249 = heff_dup(heff_field(v_x_243, 0));
      v_t_2413 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_strEq_c_lent(v_t_2413, v_lit_240, 1)) {
      V v_cell_2415 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2416 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2415));
      heff_drop(v_u_2416);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_2415;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1966236437x1225976932_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1966236437x1225976932_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eall_24s1373454977x2143028054_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1373454977x2143028054_entry, 1, 0};

V g_list_2eall_24s1373454977x2143028054(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1373454977x2143028054_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1373454977x2143028054(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s2002556150x421739076_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2002556150x421739076_entry, 2, 0};

V g_list_2efoldl_24s2002556150x421739076(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2438;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ETag: {
      V v_a_2419 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 3);
      v_t_2438 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_2419, NTAG(TAG_Nil)});
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2438 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2438, v_z_240));
    V t_0 = v_t_2439;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2002556150x421739076_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2002556150x421739076(a[0], a[1]);
}
Clo g_list_2efoldl_24s1004873070x1577485130_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1004873070x1577485130_entry, 3, 0};

V g_list_2efoldl_24s1004873070x1577485130(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682(heff_dup(v_lit_240), heff_dup(v_x_243), heff_dup(heff_rfield(v_x_243, 2))));
    V v_t_2410;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_t_245, 0);
      V v_a_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      V v_t_248 = ({ V rv_2 = v_a_246; V rr_ = heff_rec_reuse_nf(v_x_243, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_a_247, 0, 2)));
      v_t_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, v_t_249});
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2411;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1004873070x1577485130_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1004873070x1577485130(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1530401830x609500251_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1530401830x609500251_entry, 2, 0};

V g_list_2efoldl_24s1530401830x609500251(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1530401830x609500251(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s421921225x565177679_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s421921225x565177679_entry, 2, 0};

V g_list_2efoldl_24s421921225x565177679(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_a_246}), v_z_240});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s421921225x565177679(a[0], a[1]);
}
Clo g_list_2ezipWith_24s870182194x1066240094_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s870182194x1066240094_entry, 2, 0};

V g_list_2ezipWith_24s870182194x1066240094(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_247;
      switch (heff_tag_of(v_x_242)) {
      case TAG_RepV: {
        heff_drop_cell(v_ru_24ys_241_24Cons, 2);
        v_t_247 = v_y_244;
        break;
      }
      case TAG_RepFix: {
        v_t_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_RWord, 2, (V[]){v_x_242, v_y_244});
        break;
      }
      case TAG_RepF64: {
        v_t_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_RWord, 2, (V[]){v_x_242, v_y_244});
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s870182194x1066240094_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s870182194x1066240094(a[0], a[1]);
}
Clo g_list_2emap_24s976303750x321235480_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s976303750x321235480_entry, 1, 0};

V g_list_2emap_24s976303750x321235480(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_Given: {
      V v_e_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_249 = v_e_243;
      break;
    }
    case TAG_GivenU: {
      V v_e_245 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_249 = v_e_245;
      break;
    }
    case TAG_LentVar: {
      V v_x_246 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_249 = heff_tag_n(TAG_RLocal, 1, (V[]){v_x_246});
      break;
    }
    case TAG_LentValue: {
      V v_e_248 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_249 = v_e_248;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s976303750x321235480_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s976303750x321235480_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s976303750x321235480(a[0]);
}
Clo g_list_2emap_24s510639937x1058700299_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s510639937x1058700299_entry, 1, 0};

V g_list_2emap_24s510639937x1058700299(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 3, 5), heff_hole()});
    V v_u_244 = (g_list_2emap_24s510639937x1058700299_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s510639937x1058700299_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s510639937x1058700299(a[0]);
}
Clo g_list_2efoldl_24s135909237x326578890_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s135909237x326578890_entry, 2, 0};

V g_list_2efoldl_24s135909237x326578890(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2ecompile_2eemit_2ebindName(heff_take_field(v_z_240, 1), v_x_242));
    V v_t_245 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_a_244, 0)), NTAG(TAG_Nil)});
    V v_t_246 = (g_prelude_2e_2b_2b(heff_get_n(v_z_240, 0, 2), v_t_245));
    V v_t_247 = ({ V rv_0 = v_t_246; V rr_ = heff_rec_reuse_nf(v_a_244, 2ULL, 2, shape_js__env, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s135909237x326578890_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s135909237x326578890(a[0], a[1]);
}
Clo g_list_2emap_24s357242026x384251201_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s357242026x384251201_24dps_entry, 2, 0};

V g_list_2emap_24s357242026x384251201_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s357242026x384251201_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s357242026x384251201_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1146729723x1441207893_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1146729723x1441207893_entry, 3, 0};

V g_list_2emap_24s1146729723x1441207893(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_x_243, heff_dup(v_lit_241)));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1146729723x1441207893_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1146729723x1441207893_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1146729723x1441207893(a[0], a[1], a[2]);
}
Clo g_list_2ezipWith_24s1149721393x617397893_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1149721393x617397893_entry, 3, 0};

V g_list_2ezipWith_24s1149721393x617397893(V v_lit_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247 = heff_strAppend(v_x_243, heff_strAppend(heff_dup(v_lit_240), v_y_245));
      V v_cell_248 = heff_tag_at_n(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s1149721393x617397893_24dps(v_lit_240, v_xs2_244, v_ys2_246, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2ezipWith_24s1149721393x617397893_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1149721393x617397893(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s567711145x425963688_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s567711145x425963688_entry, 4, 0};

V g_list_2emap_24s567711145x425963688(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_244, 0);
      V v_a_247 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 3ULL, 2);
      if (heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_a_246, v_lit_241, v_lit_242, 1))) {
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_a_247});
      } else {
        heff_drop(v_a_247);
        v_t_249 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s567711145x425963688_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s567711145x425963688_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s567711145x425963688(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s398854970x1533504811_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s398854970x1533504811_entry, 2, 0};

V g_list_2efoldl_24s398854970x1533504811(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemit_2eprimUses(v_z_240, v_x_242));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s398854970x1533504811(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s803586165x1676441765_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s803586165x1676441765_entry, 7, 0};

V g_list_2emap_24s803586165x1676441765(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_x_247), heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_x_247, v_lit_243, 2), NTAG(TAG_Nil)));
    V v_a_2410 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_249));
    V v_t_2413;
    switch (heff_tag_of(v_a_2410)) {
    case TAG_Nil: {
      v_t_2413 = heff_dup(v_lit_244);
      break;
    }
    case TAG_Cons: {
      V v_a_2411 = heff_field(v_a_2410, 0);
      V v_a_2412 = heff_field(v_a_2410, 1);
      heff_take_n(v_a_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = heff_dup(v_lit_245); V a_1 = v_a_2411; V a_2 = v_a_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2412); r_; });
      break;
    }
    default: heff_nomatch(v_a_2410);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = (g_list_2emap_24s803586165x1676441765_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s803586165x1676441765(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2efoldl_24s1483820613x1826490246_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1483820613x1826490246_entry, 2, 0};

V g_list_2efoldl_24s1483820613x1826490246(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 1)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1483820613x1826490246_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1483820613x1826490246(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s456133444x1904936646_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s456133444x1904936646_entry, 8, 0};

V g_list_2emap_24s456133444x1904936646(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkDrop: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      switch (heff_tag_of(v_a_2411)) {
      case TAG_Nothing: {
        V v_t_2412 = (g_heff_2ecompile_2eemitc_2emangleW(v_a_2410, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)));
        V v_t_2413 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2412), heff_dup(v_lit_245));
        v_t_2415 = heff_strAppend(heff_dup(v_lit_240), v_t_2413);
        break;
      }
      case TAG_Just: {
        V v_a_2414 = heff_field(v_a_2411, 0);
        heff_take_n(v_a_2411, 1ULL, 1);
        v_t_2415 = ({ V a_0 = v_a_2410; V a_1 = v_a_2414; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_a_2414); r_; });
        break;
      }
      default: heff_nomatch(v_a_2411);
      }
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2415, heff_dup(v_lit_246)), heff_hole()});
    V v_u_2417 = (g_list_2emap_24s456133444x1904936646_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s456133444x1904936646_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s456133444x1904936646(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2eany_24s1177057410x67789151_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1177057410x67789151_entry, 2, 0};

V g_list_2eany_24s1177057410x67789151(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1177057410x67789151_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1177057410x67789151(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1967523567x64647275_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1967523567x64647275_24dps_entry, 2, 0};

V g_list_2efilter_24s1967523567x64647275_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_244 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_a_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_a_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1967523567x64647275_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1967523567x64647275_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s1182572632x117717553_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1182572632x117717553_entry, 5, 0};

V g_list_2eany_24s1182572632x117717553(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_a_247 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_x_245), heff_dup(v_lit_241)));
    V v_t_248 = heff_strSlice(heff_dup(v_lit_242), heff_dup(v_lit_243), heff_strLength_lent(v_a_247, 0));
    if (heff_strEq_c(v_t_248, v_a_247)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2eany_24s1182572632x117717553_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2eany_24s1182572632x117717553(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_list_2efoldl_24s1894035205x969464323_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1894035205x969464323_entry, 3, 0};

V g_list_2efoldl_24s1894035205x969464323(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_intAdd(v_z_241, heff_strLength_lent(v_x_243, 0));
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_t_245, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1894035205x969464323(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s950896375x422349662_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s950896375x422349662_entry, 2, 0};

V g_list_2efoldl_24s950896375x422349662(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_242, 0));
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_list_2emap_24s1937570095x2110149801(heff_get_n(v_t_2412, 2, 3)));
    V v_t_2414 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_t_249, 1, 3), v_t_2413});
    V v_t_2415 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_t_246, 0, 3), v_t_2414, v_z_240));
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s950896375x422349662_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s950896375x422349662(a[0], a[1]);
}
Clo g_list_2efoldl_24s809624008x2043497973_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s809624008x2043497973_entry, 2, 0};

V g_list_2efoldl_24s809624008x2043497973(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s378225814x484524589(v_z_240, heff_rfield(v_x_242, 1)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s809624008x2043497973_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s809624008x2043497973(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2099124872x600887319_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2099124872x600887319_entry, 2, 0};

V g_list_2efoldl_24s2099124872x600887319(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s378225814x484524589(v_z_240, heff_rfield(v_x_242, 2)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2099124872x600887319_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2099124872x600887319(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s391931963x434308123_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s391931963x434308123_24dps_entry, 2, 0};

V g_list_2emap_24s391931963x434308123_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_x_242; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s391931963x434308123_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s391931963x434308123_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s939813003x1383013550_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s939813003x1383013550_entry, 1, 0};

V g_list_2emap_24s939813003x1383013550(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(v_x_241, 2, 5);
    V v_t_247;
    switch (heff_tag_of(v_t_243)) {
    case TAG_SizeDefault: {
      v_t_247 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeNumber: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_t_247 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeName: {
      V v_x_245 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){v_x_245});
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s939813003x1383013550_24dps(v_xs_242, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s939813003x1383013550(a[0]);
}
Clo g_list_2emap_24s796727596x829078925_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s796727596x829078925_entry, 1, 0};

V g_list_2emap_24s796727596x829078925(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s796727596x829078925_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s796727596x829078925_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s796727596x829078925(a[0]);
}
HEFF_LIT(g_list_2emap_24s1534167768x1221742344_24dps_str0, 56, "only the library that goes with heff declares primitives");
Clo g_list_2emap_24s1534167768x1221742344_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1534167768x1221742344_24dps_entry, 2, 0};

V g_list_2emap_24s1534167768x1221742344_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_sp_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(335LL), NTAG(TAG_SError), ((V)&g_list_2emap_24s1534167768x1221742344_24dps_str0), v_sp_245, NTAG(TAG_Nothing)});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1534167768x1221742344_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1534167768x1221742344_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s1725367856x1498536808_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1725367856x1498536808_entry, 1, 0};

V g_list_2efilter_24s1725367856x1498536808(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2425;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_dup(heff_field(v_x_241, 0));
      V v_sp_244 = heff_dup(heff_field(v_x_241, 1));
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_243, 0ULL, 5);
        heff_drop(v_sp_244);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_243, 0ULL, 5);
        heff_drop(v_sp_244);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_243, 0ULL, 4);
        heff_drop(v_sp_244);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2419 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_sp_244})});
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_243, 0ULL, 2);
        heff_drop(v_sp_244);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_243, 0ULL, 1);
        heff_drop(v_sp_244);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2425)) {
    case TAG_Nothing: {
      V v_cell_2426 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2427 = (g_list_2efilter_24s1725367856x1498536808_24dps(v_xs_242, heff_dup(v_cell_2426)));
      heff_drop(v_u_2427);
      return v_cell_2426;
    }
    case TAG_Just: {
      heff_take_n(v_t_2425, 0ULL, 1);
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1725367856x1498536808_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1725367856x1498536808(a[0]);
}
Clo g_list_2efoldl_24s1149369025x804005338_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1149369025x804005338_entry, 8, 0};

V g_list_2efoldl_24s1149369025x804005338(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_z_246, V v_x3_247) {
top: ;
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return v_z_246;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x3_247, 0);
    V v_xs_249 = heff_field(v_x3_247, 1);
    V v_a_2410 = heff_dup(heff_rfield(v_x_248, 4));
    V v_t_2411 = (g_prelude_2esplitFrom(heff_dup(v_lit_242), heff_dup(v_a_2410), heff_dup(v_lit_243), heff_strFind_lent(v_lit_244, v_a_2410, v_lit_245, 2), NTAG(TAG_Nil)));
    V v_t_2412 = (g_list_2emap_24s1068592055x839006909(heff_dup(v_x_248), heff_dup(v_lit_240), heff_dup(v_lit_241), v_t_2411));
    V v_t_2413 = (g_heff_2ebuild_2edriver_2epromoteAt(v_z_246, heff_dup(heff_rfield(v_x_248, 7)), heff_dup(heff_rfield(v_x_248, 8)), v_t_2412));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_t_2413;
    V t_7 = v_xs_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_z_246 = t_6;
    v_x3_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_list_2efoldl_24s1149369025x804005338_entry(V self, V *a) {
  (void)self;
  V a7 = a[7]; V r = g_list_2efoldl_24s1149369025x804005338(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a7); heff_drop(a7); return r;
}
Clo g_list_2efilter_24s1064353769x1815078842_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1064353769x1815078842_24dps_entry, 2, 0};

V g_list_2efilter_24s1064353769x1815078842_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_SError: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_SWarning: {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_SDebug: {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1064353769x1815078842_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1064353769x1815078842_24dps(a[0], a[1]);
}
Clo g_list_2efind_24s1230956425x1562898054_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1230956425x1562898054_entry, 2, 0};

V g_list_2efind_24s1230956425x1562898054(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 13);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1230956425x1562898054_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s1230956425x1562898054(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1798985515x221942800_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1798985515x221942800_entry, 2, 0};

V g_list_2efoldl_24s1798985515x221942800(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_a_244), v_z_240));
      switch (heff_tag_of(v_a_246)) {
      case TAG_Nothing: {
        v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_a_244), heff_dup(v_a_245), v_z_240));
        break;
      }
      case TAG_Just: {
        heff_take_n(v_a_246, 0ULL, 1);
        v_t_248 = v_z_240;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1798985515x221942800_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1798985515x221942800(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s467798769x1763085075_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s467798769x1763085075_24dps_entry, 2, 0};

V g_list_2emap_24s467798769x1763085075_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s467798769x1763085075_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s467798769x1763085075_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s759871588x920431471_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s759871588x920431471_entry, 1, 0};

V g_list_2emap_24s759871588x920431471(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 9), heff_hole()});
    V v_u_244 = (g_list_2emap_24s759871588x920431471_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s759871588x920431471_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s759871588x920431471(a[0]);
}
Clo g_list_2emap_24s1816200867x1876638332_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1816200867x1876638332_24dps_entry, 2, 0};

V g_list_2emap_24s1816200867x1876638332_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1816200867x1876638332_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1816200867x1876638332_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s179832492x431904054_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s179832492x431904054_entry, 1, 0};

V g_list_2emap_24s179832492x431904054(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 5), heff_hole()});
    V v_u_244 = (g_list_2emap_24s179832492x431904054_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s179832492x431904054_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s179832492x431904054(a[0]);
}
Clo g_list_2emap_24s1703643582x349630108_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1703643582x349630108_24dps_entry, 3, 0};

V g_list_2emap_24s1703643582x349630108_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_prelude_2eparseInt(v_x_243));
    V v_t_247;
    switch (heff_tag_of(v_a_245)) {
    case TAG_Nothing: {
      v_t_247 = heff_dup(v_lit_240);
      break;
    }
    case TAG_Just: {
      V v_a_246 = heff_field(v_a_245, 0);
      heff_take_n(v_a_245, 1ULL, 1);
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_a_245);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_248;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1703643582x349630108_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1703643582x349630108_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ezipWith_24s29557946x653938035_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s29557946x653938035_entry, 2, 0};

V g_list_2ezipWith_24s29557946x653938035(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_244, 1, 3), v_x_242});
      V v_cell_247 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s29557946x653938035_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s29557946x653938035_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s29557946x653938035(a[0], a[1]);
}
Clo g_list_2emerge_24s132798885x1165759438_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s132798885x1165759438_entry, 2, 0};

V g_list_2emerge_24s132798885x1165759438(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = (g_heff_2ebuild_2eproject_2esumBefore(heff_dup(v_x_242), heff_dup(v_y_244)));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_cell_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s132798885x1165759438_24dps(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        heff_drop(v_t_246);
        V v_cell_249 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s132798885x1165759438_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s132798885x1165759438_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s132798885x1165759438(a[0], a[1]);
}
Clo g_list_2emap_24s18996220x10511024_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s18996220x10511024_entry, 1, 0};

V g_list_2emap_24s18996220x10511024(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_x_241, 0), heff_get_n(v_x_241, 1, 3)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s18996220x10511024_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s18996220x10511024_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s18996220x10511024(a[0]);
}
Clo g_list_2emap_24s18996220x10511024_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s18996220x10511024_24dps_entry, 2, 0};

V g_list_2emap_24s18996220x10511024_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_x_242, 0), heff_get_n(v_x_242, 1, 3)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s18996220x10511024_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s18996220x10511024_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s489050722x1368997552_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s489050722x1368997552_entry, 2, 0};

V g_list_2efoldl_24s489050722x1368997552(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s1081981235x855852216(heff_dup(v_x_242), v_z_240));
    V v_t_246;
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop(v_t_244);
      v_t_246 = v_z_240;
    } else {
      heff_drop(v_t_244);
      V v_t_245 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
      v_t_246 = (g_prelude_2e_2b_2b(v_z_240, v_t_245));
    }
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s489050722x1368997552_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s489050722x1368997552(a[0], a[1]);
}
Clo g_list_2emap_24s917234327x1197288555_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s917234327x1197288555_entry, 1, 0};

V g_list_2emap_24s917234327x1197288555(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s917234327x1197288555_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s917234327x1197288555_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s917234327x1197288555(a[0]);
}
Clo g_list_2efoldl_24s2031248677x950202423_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2031248677x950202423_entry, 2, 0};

V g_list_2efoldl_24s2031248677x950202423(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b_24f1537904782x516751275(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2031248677x950202423(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1476602679x302842688_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1476602679x302842688_entry, 2, 0};

V g_list_2efoldl_24s1476602679x302842688(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        v_t_2411 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_a_246)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, v_z_240));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1476602679x302842688(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s478414341x1543613922_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s478414341x1543613922_entry, 2, 0};

V g_list_2efoldl_24s478414341x1543613922(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_a_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s478414341x1543613922(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emerge_24s509014022x1733915733_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s509014022x1733915733_24dps_entry, 3, 0};

V g_list_2emerge_24s509014022x1733915733_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 2);
      heff_drop(v_xs2_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_xs_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_y_245, 0)))) {
        V v_cell_248 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_xs2_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246});
        V t_2 = v_cell_248;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_2410 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244});
        V t_1 = v_ys2_246;
        V t_2 = v_cell_2410;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s509014022x1733915733_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s509014022x1733915733_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s2000102784x314586828_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2000102784x314586828_24dps_entry, 2, 0};

V g_list_2emap_24s2000102784x314586828_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x11_244, 0);
        V v_sp_247 = heff_field(v_x11_244, 1);
        heff_take_n(v_x11_244, 3ULL, 4);
        v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_246, v_sp_247})});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2411 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2412;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2000102784x314586828_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2000102784x314586828_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s388004800x1261967008_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s388004800x1261967008_entry, 1, 0};

V g_list_2emap_24s388004800x1261967008(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s388004800x1261967008_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s388004800x1261967008(a[0]);
}
Clo g_list_2emap_24s1004924153x684987219_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1004924153x684987219_entry, 3, 0};

V g_list_2emap_24s1004924153x684987219(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    heff_drop_rec(v_lit_241, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_lit_241, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(heff_rfield(v_lit_241, 1)))));
    V v_t_247 = heff_rec_n(4, shape_path__source__span__defines, (V[]){heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(heff_rfield(v_lit_240, 3)), v_x_243, v_t_246});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s1004924153x684987219_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1004924153x684987219_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1004924153x684987219(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_24dps_str0, 5, "-- | ");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_24dps_str1, 4, "-- |");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_24dps_str2, 0, "");
Clo g_list_2emap_24s1819241345x1511673126_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1819241345x1511673126_24dps_entry, 2, 0};

V g_list_2emap_24s1819241345x1511673126_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    if (heff_strEq_c(heff_strSlice_lent(v_x_242, MK_INT(0LL), MK_INT(5LL), 6), ((V)&g_list_2emap_24s1819241345x1511673126_24dps_str0))) {
      V v_t_245 = heff_strSlice(heff_dup(v_x_242), MK_INT(5LL), heff_strLength(v_x_242));
      v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
    } else {
      if (heff_strEq_c(v_x_242, ((V)&g_list_2emap_24s1819241345x1511673126_24dps_str1))) {
        v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_list_2emap_24s1819241345x1511673126_24dps_str2)});
      } else {
        v_t_247 = NTAG(TAG_Nothing);
      }
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1819241345x1511673126_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1819241345x1511673126_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s2134067310x2049132013_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2134067310x2049132013_entry, 2, 0};

V g_list_2efoldl_24s2134067310x2049132013(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2134067310x2049132013(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s491084544x100802329_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s491084544x100802329_entry, 2, 0};

V g_list_2efoldl_24s491084544x100802329(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_a_248)));
        v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2134067310x2049132013(a_0, a_1)); heff_drop(v_t_249); r_; });
        break;
      }
      case TAG_BadVariant: {
        V v_a_2410 = heff_field(v_a_244, 0);
        v_t_2411 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2410));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, v_z_240));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s491084544x100802329(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emerge_24s1904498032x521599863_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1904498032x521599863_24dps_entry, 3, 0};

V g_list_2emerge_24s1904498032x521599863_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 5);
      heff_drop(v_xs2_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_xs_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 0, 2);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_y_245, 2)), 0, 2);
      if (heff_intLe_c(v_t_247, v_t_248)) {
        V v_cell_2410 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = v_xs2_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246});
        V t_2 = v_cell_2410;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_2412 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
        heff_drop(v_u_2413);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244});
        V t_1 = v_ys2_246;
        V t_2 = v_cell_2412;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1904498032x521599863_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1904498032x521599863_24dps(a[0], a[1], a[2]);
}
Clo g_list_2esortBy_24s1230002843x105774350_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1230002843x105774350_entry, 1, 0};

V g_list_2esortBy_24s1230002843x105774350(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s1230002843x105774350(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s1230002843x105774350(v_t_249));
      return (g_list_2emerge_24s1904498032x521599863(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1230002843x105774350_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1230002843x105774350(a[0]);
}
Clo g_list_2emap_24s1661513421x830177447_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1661513421x830177447_entry, 3, 0};

V g_list_2emap_24s1661513421x830177447(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247;
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_t_246 = heff_intAdd(heff_take_field(v_x_243, 3), heff_dup(v_lit_241));
      v_t_247 = ({ V rv_3 = v_t_246; V rr_ = heff_rec_reuse_nf(v_x_243, 23ULL, 5, shape_task__parent__name__done__total, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      v_t_247 = v_x_243;
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s1661513421x830177447_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1661513421x830177447_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1661513421x830177447(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s1875062608x222844981_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1875062608x222844981_entry, 6, 0};

V g_list_2efilter_24s1875062608x222844981(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_a_248 = heff_dup(heff_rfield(v_x_246, 1));
    V v_t_249 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_a_248), heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_a_248, v_lit_243, 2), NTAG(TAG_Nil)));
    V v_t_2410 = (g_list_2emap_24s649333309x1802289391(v_t_249));
    V v_a_2411 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2410));
    switch (heff_tag_of(v_a_2411)) {
    case TAG_Nil: {
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
      V v_u_2413 = (g_list_2efilter_24s1875062608x222844981_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    case TAG_Cons: {
      V v_a_2414 = heff_field(v_a_2411, 0);
      heff_take_n(v_a_2411, 1ULL, 2);
      if (heff_strEq_c_lent(v_a_2414, v_lit_244, 1)) {
        V v_cell_2417 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
        V v_u_2418 = (g_list_2efilter_24s1875062608x222844981_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2417)));
        heff_drop(v_u_2418);
        return v_cell_2417;
      } else {
        heff_drop_rec(v_x_246, 2);
        heff_drop_cell(v_ru_24x2_245_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_247;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        goto top;
      }
    }
    default: return heff_nomatch(v_a_2411);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2efilter_24s1875062608x222844981_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1875062608x222844981(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s1234524601x742515152_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1234524601x742515152_entry, 1, 0};

V g_list_2emap_24s1234524601x742515152(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V rr_ = heff_rec_reuse_nf(v_x_241, 3ULL, 2, shape_name__key, 15u, 0u); rr_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1234524601x742515152_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1234524601x742515152_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1234524601x742515152(a[0]);
}
Clo g_list_2emap_24s1146657978x434453078_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1146657978x434453078_entry, 8, 0};

V g_list_2emap_24s1146657978x434453078(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_241, 10);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_a_2410 = heff_dup(heff_rfield(v_lit_241, 3));
    V v_t_2415;
    if (heff_intEq_c(heff_dup(v_a_2410), heff_dup(v_lit_242))) {
      heff_drop(v_a_2410);
      v_t_2415 = heff_dup(v_lit_243);
    } else {
      V v_t_2414;
      switch (heff_tag_of(v_x_248)) {
      case TAG_MkPair: {
        V v_a_2413 = heff_dup(heff_field(v_x_248, 1));
        v_t_2414 = v_a_2413;
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      v_t_2415 = heff_intDiv(heff_intMul(v_t_2414, heff_dup(v_lit_244)), v_a_2410);
    }
    V v_t_2416 = heff_strAppend(heff_intShow(v_t_2415), heff_dup(v_lit_245));
    V v_t_2419;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2417 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 2);
      v_t_2419 = v_a_2417;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2420 = heff_strAppend(v_t_2416, heff_strAppend(heff_dup(v_lit_246), v_t_2419));
    V v_cell_2421 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2420), heff_hole()});
    V v_u_2422 = (g_list_2emap_24s1146657978x434453078_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249, heff_dup(v_cell_2421)));
    heff_drop(v_u_2422);
    return v_cell_2421;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s1146657978x434453078_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1146657978x434453078(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2emap_24s1814289659x520383890_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1814289659x520383890_24dps_entry, 4, 0};

V g_list_2emap_24s1814289659x520383890_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_240))) {
      v_t_247 = ({ V rv_1 = heff_dup(v_lit_240); V rv_2 = heff_dup(v_lit_241); V rr_ = heff_rec_reuse_nf(v_x_244, 1ULL, 3, shape_name__path__version, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    } else {
      v_t_247 = v_x_244;
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1814289659x520383890_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1814289659x520383890_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s2005951263x462916503_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2005951263x462916503_24dps_entry, 7, 0};

V g_list_2emap_24s2005951263x462916503_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_x_247, 0));
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2412 = (g_heff_2eutil_2ejson_2eescapeGo(v_t_2411, heff_dup(v_lit_241), heff_dup(v_lit_242)));
    V v_t_2413 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_dup(v_lit_243)));
    V v_t_2416;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_2415 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_t_2416 = v_a_2415;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = heff_strAppend(v_t_2413, heff_strAppend(heff_dup(v_lit_244), v_t_2417));
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_xs_248;
    V t_6 = v_cell_2419;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_x2_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s2005951263x462916503_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2005951263x462916503_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2efind_24s1504327023x469120796_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1504327023x469120796_entry, 2, 0};

V g_list_2efind_24s1504327023x469120796(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 1));
    V v_a_245 = heff_dup(heff_rfield(v_lit_240, 1));
    if (heff_intEq_c(heff_dup(heff_rfield(v_a_244, 0)), heff_dup(heff_rfield(v_a_245, 0)))) {
      if (heff_intEq_c(heff_get_n(v_a_244, 1, 2), heff_get_n(v_a_245, 1, 2))) {
        heff_drop_rec(v_lit_240, 5);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_a_244, 2);
      heff_drop_rec(v_a_245, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1504327023x469120796_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s1504327023x469120796(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1387309293x1990579214_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1387309293x1990579214_24dps_entry, 2, 0};

V g_list_2emap_24s1387309293x1990579214_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 4);
        v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2411 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2412;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1387309293x1990579214_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1387309293x1990579214_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1943354043x700174004_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1943354043x700174004_24dps_entry, 4, 0};

V g_list_2emap_24s1943354043x700174004_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    heff_drop_rec(v_lit_241, 5);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_a_246 = heff_dup(heff_rfield(v_lit_240, 3));
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 0, 2);
    V v_t_248 = heff_strSlice(heff_dup(v_a_246), heff_dup(heff_rfield(v_lit_241, 2)), v_t_247);
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 1, 2);
    V v_t_2410 = heff_strSlice(v_a_246, v_t_249, heff_dup(heff_rfield(v_lit_241, 4)));
    V v_t_2411 = heff_strAppend(v_t_248, heff_strAppend(v_x_244, v_t_2410));
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_2412;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1943354043x700174004_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1943354043x700174004_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efilter_24s999680916x306845608_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s999680916x306845608_24dps_entry, 3, 0};

V g_list_2efilter_24s999680916x306845608_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 4);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s999680916x306845608_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s999680916x306845608_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s2051016282x1892781518_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2051016282x1892781518_entry, 4, 0};

V g_list_2efoldl_24s2051016282x1892781518(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_244, 2)), 0, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_244, 2)), 1, 2);
    V v_t_248 = heff_strSlice(heff_dup(v_z_242), v_t_247, heff_strLength_lent(v_z_242, 0));
    V v_t_249 = heff_strAppend(heff_strSlice_lent(v_z_242, v_lit_240, v_t_246, 5), heff_strAppend(heff_dup(v_lit_241), v_t_248));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_249;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s2051016282x1892781518_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s2051016282x1892781518(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2emap_24s1854779998x1713580578_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1854779998x1713580578_24dps_entry, 2, 0};

V g_list_2emap_24s1854779998x1713580578_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 8), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1854779998x1713580578_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1854779998x1713580578_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s296585291x885335139_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s296585291x885335139_entry, 1, 0};

V g_list_2emap_24s296585291x885335139(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eheadOf(heff_dup(v_x_241)));
    V v_t_244 = (g_std_2ecli_2eline2(v_t_243, heff_get_n(v_x_241, 1, 4)));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s296585291x885335139_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s296585291x885335139_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s296585291x885335139(a[0]);
}
Clo g_list_2emap_24s1753874608x910016727_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1753874608x910016727_entry, 1, 0};

V g_list_2emap_24s1753874608x910016727(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagLine(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1753874608x910016727_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1753874608x910016727(a[0]);
}
Clo g_list_2emap_24f1799988110x1394031252_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1799988110x1394031252_entry, 4, 0};

V g_list_2emap_24f1799988110x1394031252(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_x_244, 1))}));
    V v_t_247 = ({ V a_0 = v_t_246; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = heff_strAppend(heff_take_field(v_x_244, 1), heff_dup(v_lit_242));
      V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 2), heff_get_n(v_x_244, 3, 7)});
      V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), heff_strAppend(heff_dup(v_lit_241), v_t_248), v_t_249, NTAG(TAG_Nothing)});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = (g_list_2emap_24f1799988110x1394031252_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    } else {
      heff_drop_rec(v_x_244, 7);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1799988110x1394031252_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1799988110x1394031252(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f2064224154x1075431823_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2064224154x1075431823_entry, 4, 0};

V g_list_2efoldl_24f2064224154x1075431823(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_strEq_c_lent(v_lit_242, v_x_244, 0)) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f2064224154x1075431823_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f2064224154x1075431823(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2emap_24f1638246995x433291654_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1638246995x433291654_entry, 3, 0};

V g_list_2emap_24f1638246995x433291654(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_intLt_c(heff_dup(v_lit_241), heff_strLength_lent(v_x_243, 0))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_243), heff_hole()});
      V v_u_247 = (g_list_2emap_24f1638246995x433291654_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1638246995x433291654_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1638246995x433291654(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f891411706x655200538_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f891411706x655200538_entry, 2, 0};

V g_list_2efoldl_24f891411706x655200538(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x_247 = heff_get_n(v_t_246, 2, 3);
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f891411706x655200538_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f891411706x655200538(a[0], a[1]);
}
Clo g_list_2emap_24f990982947x2126256822_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f990982947x2126256822_entry, 2, 0};

V g_list_2emap_24f990982947x2126256822(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
      V v_u_246 = (g_list_2emap_24f990982947x2126256822_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f990982947x2126256822_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f990982947x2126256822(a[0], a[1]);
}
Clo g_list_2efoldl_24f297647854x479783049_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f297647854x479783049_entry, 2, 0};

V g_list_2efoldl_24f297647854x479783049(V v_z_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_241, 0);
    V v_cs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_t_244 = (g_list_2efilter_24s316268077x2111002396(heff_dup(v_c_242), v_cs_243));
    V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_z_240});
    V t_1 = v_t_244;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f297647854x479783049(a[0], a[1]);
}
Clo g_list_2efilter_24f1490579794x1456232270_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24f1490579794x1456232270_24dps_entry, 8, 0};

V g_list_2efilter_24f1490579794x1456232270_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2410 = heff_strSlice(heff_dup(v_lit_242), heff_dup(v_lit_243), heff_intAdd(heff_dup(v_lit_244), heff_dup(v_lit_245)));
    V v_x_2411 = heff_strAppend(v_t_2410, v_x_248);
    V v_t_2412 = heff_strSlice(heff_dup(v_x_2411), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_2412, v_lit_241, 1)) {
      V v_cell_2414 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
      V v_u_2415 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2414));
      heff_drop(v_u_2415);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_cell_2414;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_246_24Cons, 2);
      heff_drop(v_x_2411);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_d_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2efilter_24f1490579794x1456232270_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24f1490579794x1456232270_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2emap_24f130772758x674845987_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f130772758x674845987_entry, 4, 0};

V g_list_2emap_24f130772758x674845987(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_241), heff_strLength_lent(v_lit_242, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_242, 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_244, heff_dup(v_lit_240)), heff_hole()});
      V v_u_249 = (g_list_2emap_24f130772758x674845987_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f130772758x674845987_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f130772758x674845987(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f378206553x1816388893_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f378206553x1816388893_entry, 4, 0};

V g_list_2emap_24f378206553x1816388893(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_242))) {
      heff_drop_rec(v_x_244, 5);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V v_t_249;
      if (heff_intEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240))) {
        V v_t_248 = heff_intAdd(heff_take_field(v_x_244, 3), heff_dup(v_lit_241));
        v_t_249 = ({ V rv_3 = v_t_248; V rr_ = heff_rec_reuse_nf(v_x_244, 23ULL, 5, shape_task__parent__name__done__total, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      } else {
        v_t_249 = v_x_244;
      }
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = (g_list_2emap_24f378206553x1816388893_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f378206553x1816388893_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f378206553x1816388893(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f1117322828x1334654706_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1117322828x1334654706_entry, 3, 0};

V g_list_2efoldl_24f1117322828x1334654706(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 6, 10);
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1117322828x1334654706_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1117322828x1334654706(a[0], a[1], a2); heff_drop(a2); return r;
}