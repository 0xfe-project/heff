// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CondRelU 46269
#define TAG_DeclareField 57313
#define TAG_EDo 15964
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ENest 28629
#define TAG_ETry 51493
#define TAG_EVar 52881
#define TAG_EWith 38507
#define TAG_I64 19315
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_PVar 52952
#define TAG_PatVar 49363
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SError 24172
#define TAG_SetField 47531
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_WordLe 48792
#define LBL_body 9524841
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_doc 309170
#define LBL_filter 672649891
#define LBL_forwards 1228451848
#define LBL_key 315609
#define LBL_library 398066429
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ok 10307
#define LBL_path 9928940
#define LBL_severity 75955546
#define LBL_shown 310772011
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_use 325633
#define LBL_version 583465758
#define LBL_x 338
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
static uint32_t shape_name__key__module[] = {LBL_name, LBL_key, LBL_module};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2efacts_2esureW(V, V);
V g_heff_2ecompile_2efacts_2esureW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureW_clo;
V g_heff_2ecompile_2elower_2epieceStep(V, V, V, V, V);
V g_heff_2ecompile_2elower_2epieceStep_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2epieceStep_clo;
V g_heff_2ecompile_2eowned_2ewordOnly(V);
V g_heff_2ecompile_2eowned_2ewordOnly_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2ewordOnly_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2eworker_2ehopeOne(V, V, V, V);
V g_heff_2ecompile_2eworker_2ehopeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ehopeOne_clo;
V g_heff_2eelab_2eclauses_2eanyC(V, V);
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatBinds_24tok2(V, V);
V g_heff_2eelab_2eclauses_2epatBinds_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_24tok2_clo;
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2esyntax_2eformat_2efieldDeclKey(V, V);
V g_heff_2esyntax_2eformat_2efieldDeclKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldDeclKey_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
V g_list_2eall_24s1432467604x1830816726(V, V, V, V, V, V);
V g_list_2eall_24s1432467604x1830816726_entry(V self, V *a);
extern Clo g_list_2eall_24s1432467604x1830816726_clo;
V g_list_2eall_24s1465078656x604124530(V);
V g_list_2eall_24s1465078656x604124530_entry(V self, V *a);
extern Clo g_list_2eall_24s1465078656x604124530_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1037819844x481859879(V, V, V, V, V, V, V, V);
V g_list_2eany_24s1037819844x481859879_entry(V self, V *a);
extern Clo g_list_2eany_24s1037819844x481859879_clo;
V g_list_2eany_24s1082941870x132941142(V, V);
V g_list_2eany_24s1082941870x132941142_entry(V self, V *a);
extern Clo g_list_2eany_24s1082941870x132941142_clo;
V g_list_2eany_24s1287956370x756381573(V, V);
V g_list_2eany_24s1287956370x756381573_entry(V self, V *a);
extern Clo g_list_2eany_24s1287956370x756381573_clo;
V g_list_2eany_24s717144537x1885076661(V);
V g_list_2eany_24s717144537x1885076661_entry(V self, V *a);
extern Clo g_list_2eany_24s717144537x1885076661_clo;
V g_list_2ecollapse_24s2033985552x1651472209(V, V);
V g_list_2ecollapse_24s2033985552x1651472209_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s2033985552x1651472209_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24f1323813142x1311067101(V, V, V, V);
V g_list_2efoldl_24f1323813142x1311067101_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1323813142x1311067101_clo;
V g_list_2efoldl_24f1564248594x622634626(V, V, V);
V g_list_2efoldl_24f1564248594x622634626_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1564248594x622634626_clo;
V g_list_2efoldl_24f891411706x655200538(V, V);
V g_list_2efoldl_24f891411706x655200538_entry(V self, V *a);
extern Clo g_list_2efoldl_24f891411706x655200538_clo;
V g_list_2efoldl_24s1437740164x269163243(V, V);
V g_list_2efoldl_24s1437740164x269163243_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1437740164x269163243_clo;
V g_list_2efoldl_24s1579438642x567671990(V, V, V, V, V);
V g_list_2efoldl_24s1579438642x567671990_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1579438642x567671990_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s2134067310x2049132013(V, V);
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2134067310x2049132013_clo;
V g_list_2efoldl_24s243940296x1179168444(V, V);
V g_list_2efoldl_24s243940296x1179168444_entry(V self, V *a);
extern Clo g_list_2efoldl_24s243940296x1179168444_clo;
V g_list_2efoldl_24s319398146x1205310166(V, V, V, V);
V g_list_2efoldl_24s319398146x1205310166_entry(V self, V *a);
extern Clo g_list_2efoldl_24s319398146x1205310166_clo;
V g_list_2efoldl_24s421921225x565177679(V, V);
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a);
extern Clo g_list_2efoldl_24s421921225x565177679_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s728686882x2096535788(V, V, V);
V g_list_2efoldl_24s728686882x2096535788_entry(V self, V *a);
extern Clo g_list_2efoldl_24s728686882x2096535788_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2ekeepIf_24f1622709115x782387749_24dps(V, V, V);
V g_list_2ekeepIf_24f1622709115x782387749_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1622709115x782387749_24dps_clo;
V g_list_2ekeepIf_24s1252894891x837498180(V, V, V, V);
V g_list_2ekeepIf_24s1252894891x837498180_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1252894891x837498180_clo;
V g_list_2ekeepIf_24s1252894891x837498180_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s1252894891x837498180_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1252894891x837498180_24dps_clo;
V g_list_2ekeepIf_24s1606737509x658906972(V);
V g_list_2ekeepIf_24s1606737509x658906972_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1606737509x658906972_clo;
V g_list_2ekeepIf_24s1606737509x658906972_24dps(V, V);
V g_list_2ekeepIf_24s1606737509x658906972_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1606737509x658906972_24dps_clo;
V g_list_2ekeepIf_24s183165982x1490920686(V);
V g_list_2ekeepIf_24s183165982x1490920686_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s183165982x1490920686_clo;
V g_list_2ekeepIf_24s183165982x1490920686_24dps(V, V);
V g_list_2ekeepIf_24s183165982x1490920686_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s183165982x1490920686_24dps_clo;
V g_list_2ekeepIf_24s25507577x707942422(V, V, V);
V g_list_2ekeepIf_24s25507577x707942422_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s25507577x707942422_clo;
V g_list_2ekeepIf_24s25507577x707942422_24dps(V, V, V, V);
V g_list_2ekeepIf_24s25507577x707942422_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s25507577x707942422_24dps_clo;
V g_list_2ekeepIf_24s44384897x1267641110(V);
V g_list_2ekeepIf_24s44384897x1267641110_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s44384897x1267641110_clo;
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps(V, V, V, V, V);
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps_clo;
V g_list_2emap_24f1512150482x179770396(V, V, V, V);
V g_list_2emap_24f1512150482x179770396_entry(V self, V *a);
extern Clo g_list_2emap_24f1512150482x179770396_clo;
V g_list_2emap_24f1512150482x179770396_24dps(V, V, V, V, V);
V g_list_2emap_24f1512150482x179770396_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1512150482x179770396_24dps_clo;
V g_list_2emap_24f1524014098x1956473147(V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_clo;
V g_list_2emap_24f1524014098x1956473147_24dps(V, V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_24dps_clo;
V g_list_2emap_24f669780424x1745768631_24dps(V, V, V, V, V, V);
V g_list_2emap_24f669780424x1745768631_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f669780424x1745768631_24dps_clo;
V g_list_2emap_24f922554743x1845028609_24dps(V, V, V);
V g_list_2emap_24f922554743x1845028609_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f922554743x1845028609_24dps_clo;
V g_list_2emap_24s1134745827x519521524_24dps(V, V);
V g_list_2emap_24s1134745827x519521524_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1134745827x519521524_24dps_clo;
V g_list_2emap_24s1193924222x1531824795(V, V, V);
V g_list_2emap_24s1193924222x1531824795_entry(V self, V *a);
extern Clo g_list_2emap_24s1193924222x1531824795_clo;
V g_list_2emap_24s1193924222x1531824795_24dps(V, V, V, V);
V g_list_2emap_24s1193924222x1531824795_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1193924222x1531824795_24dps_clo;
V g_list_2emap_24s135291903x1031656159(V, V);
V g_list_2emap_24s135291903x1031656159_entry(V self, V *a);
extern Clo g_list_2emap_24s135291903x1031656159_clo;
V g_list_2emap_24s135291903x1031656159_24dps(V, V, V);
V g_list_2emap_24s135291903x1031656159_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s135291903x1031656159_24dps_clo;
V g_list_2emap_24s1353477632x1698603588_24dps(V, V);
V g_list_2emap_24s1353477632x1698603588_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1353477632x1698603588_24dps_clo;
V g_list_2emap_24s1387309293x1990579214_24dps(V, V);
V g_list_2emap_24s1387309293x1990579214_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1387309293x1990579214_24dps_clo;
V g_list_2emap_24s1534167768x1221742344_24dps(V, V);
V g_list_2emap_24s1534167768x1221742344_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1534167768x1221742344_24dps_clo;
V g_list_2emap_24s1691485302x273983346_24dps(V, V, V);
V g_list_2emap_24s1691485302x273983346_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1691485302x273983346_24dps_clo;
V g_list_2emap_24s1694755346x1599566812(V, V);
V g_list_2emap_24s1694755346x1599566812_entry(V self, V *a);
extern Clo g_list_2emap_24s1694755346x1599566812_clo;
V g_list_2emap_24s1694755346x1599566812_24dps(V, V, V);
V g_list_2emap_24s1694755346x1599566812_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1694755346x1599566812_24dps_clo;
V g_list_2emap_24s1816200867x1876638332_24dps(V, V);
V g_list_2emap_24s1816200867x1876638332_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1816200867x1876638332_24dps_clo;
V g_list_2emap_24s1819241345x1511673126_24dps(V, V);
V g_list_2emap_24s1819241345x1511673126_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_24dps_clo;
V g_list_2emap_24s18996220x10511024(V);
V g_list_2emap_24s18996220x10511024_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_clo;
V g_list_2emap_24s18996220x10511024_24dps(V, V);
V g_list_2emap_24s18996220x10511024_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_24dps_clo;
V g_list_2emap_24s1947501783x1475115781(V, V, V);
V g_list_2emap_24s1947501783x1475115781_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_clo;
V g_list_2emap_24s1947501783x1475115781_24dps(V, V, V, V);
V g_list_2emap_24s1947501783x1475115781_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_24dps_clo;
V g_list_2emap_24s2000102784x314586828_24dps(V, V);
V g_list_2emap_24s2000102784x314586828_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_24dps_clo;
V g_list_2emap_24s2010608108x1221393166(V);
V g_list_2emap_24s2010608108x1221393166_entry(V self, V *a);
extern Clo g_list_2emap_24s2010608108x1221393166_clo;
V g_list_2emap_24s2010608108x1221393166_24dps(V, V);
V g_list_2emap_24s2010608108x1221393166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2010608108x1221393166_24dps_clo;
V g_list_2emap_24s296585291x885335139(V);
V g_list_2emap_24s296585291x885335139_entry(V self, V *a);
extern Clo g_list_2emap_24s296585291x885335139_clo;
V g_list_2emap_24s296585291x885335139_24dps(V, V);
V g_list_2emap_24s296585291x885335139_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s296585291x885335139_24dps_clo;
V g_list_2emap_24s584558070x895760461_24dps(V, V, V);
V g_list_2emap_24s584558070x895760461_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s584558070x895760461_24dps_clo;
V g_list_2emap_24s698781565x943874959(V, V, V, V, V, V, V);
V g_list_2emap_24s698781565x943874959_entry(V self, V *a);
extern Clo g_list_2emap_24s698781565x943874959_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;
V g_list_2emap_24s79542405x478516404_24dps(V, V);
V g_list_2emap_24s79542405x478516404_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_24dps_clo;
V g_list_2emap_24s796727596x829078925(V);
V g_list_2emap_24s796727596x829078925_entry(V self, V *a);
extern Clo g_list_2emap_24s796727596x829078925_clo;
V g_list_2emap_24s796727596x829078925_24dps(V, V);
V g_list_2emap_24s796727596x829078925_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s796727596x829078925_24dps_clo;
V g_list_2emap_24s849938259x51049885_24dps(V, V);
V g_list_2emap_24s849938259x51049885_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s849938259x51049885_24dps_clo;
V g_list_2emap_24s892909862x1245535974(V, V, V, V);
V g_list_2emap_24s892909862x1245535974_entry(V self, V *a);
extern Clo g_list_2emap_24s892909862x1245535974_clo;
V g_list_2emap_24s892909862x1245535974_24dps(V, V, V, V, V);
V g_list_2emap_24s892909862x1245535974_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s892909862x1245535974_24dps_clo;
V g_list_2emerge_2emergeFrom_240_24s825587185x1704110321(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_clo;
V g_list_2ezipWith_24s1928181476x241816070(V, V);
V g_list_2ezipWith_24s1928181476x241816070_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_clo;
V g_list_2ezipWith_24s1928181476x241816070_24dps(V, V, V);
V g_list_2ezipWith_24s1928181476x241816070_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_24dps_clo;
V g_list_2ezipWith_24s29557946x653938035(V, V);
V g_list_2ezipWith_24s29557946x653938035_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s29557946x653938035_clo;
V g_list_2ezipWith_24s29557946x653938035_24dps(V, V, V);
V g_list_2ezipWith_24s29557946x653938035_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s29557946x653938035_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1057423371x1101358195(V, V);
V g_prelude_2e_2b_2b_24f1057423371x1101358195_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
Clo g_list_2ekeepIf_24s1606737509x658906972_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1606737509x658906972_entry, 1, 0};

V g_list_2ekeepIf_24s1606737509x658906972(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = heff_get_n(v_t_245, 2, 3);
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      heff_take_n(v_t_246, 0ULL, 2);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2ekeepIf_24s1606737509x658906972_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1606737509x658906972_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1606737509x658906972(a[0]);
}
Clo g_list_2efoldl_24s1935134062x1256175429_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1935134062x1256175429_entry, 2, 0};

V g_list_2efoldl_24s1935134062x1256175429(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b_24f1057423371x1101358195(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1935134062x1256175429(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s947545569x507961639_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s947545569x507961639_entry, 2, 0};

V g_list_2efoldl_24s947545569x507961639(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_a_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s947545569x507961639(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s717144537x1885076661_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s717144537x1885076661_entry, 1, 0};

V g_list_2eany_24s717144537x1885076661(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkAlt: {
        V v_b_246 = heff_field(v_x11_243, 1);
        switch (heff_tag_of(v_b_246)) {
        case TAG_At: {
          V v_e1_247 = heff_field(v_b_246, 0);
          switch (heff_tag_of(v_e1_247)) {
          case TAG_ELam: {
            switch (heff_tag_of(v_b_246)) {
            case TAG_At: {
              V t_0 = v_xs_242;
              v_x2_240 = t_0;
              goto top;
            }
            default: return heff_nomatch(v_b_246);
            }
          }
          case TAG_EDo: {
            switch (heff_tag_of(v_b_246)) {
            case TAG_At: {
              V t_0 = v_xs_242;
              v_x2_240 = t_0;
              goto top;
            }
            default: return heff_nomatch(v_b_246);
            }
          }
          case TAG_ENest: {
            switch (heff_tag_of(v_b_246)) {
            case TAG_At: {
              return NTAG(TAG_True);
            }
            default: return heff_nomatch(v_b_246);
            }
          }
          case TAG_ELazy: {
            switch (heff_tag_of(v_b_246)) {
            case TAG_At: {
              V t_0 = v_xs_242;
              v_x2_240 = t_0;
              goto top;
            }
            default: return heff_nomatch(v_b_246);
            }
          }
          case TAG_ETry: {
            switch (heff_tag_of(v_b_246)) {
            case TAG_At: {
              V t_0 = v_xs_242;
              v_x2_240 = t_0;
              goto top;
            }
            default: return heff_nomatch(v_b_246);
            }
          }
          case TAG_EWith: {
            switch (heff_tag_of(v_b_246)) {
            case TAG_At: {
              V t_0 = v_xs_242;
              v_x2_240 = t_0;
              goto top;
            }
            default: return heff_nomatch(v_b_246);
            }
          }
          default: {
            HeffT2 v_t_2431 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_b_246)));
            {
              V v_field_2432 = v_t_2431.f[0];
              V v_field_2433 = v_t_2431.f[1];
              V v_x_2434 = v_field_2432;
              V v_y_2435 = v_field_2433;
              heff_drop(v_y_2435);
              if ((heff_dup(v_x_2434) == NTAG(TAG_True))) {
                heff_drop(v_x_2434);
                return NTAG(TAG_True);
              } else {
                heff_drop(v_x_2434);
                V t_0 = v_xs_242;
                v_x2_240 = t_0;
                goto top;
              }
            }
          }
          }
        }
        default: return heff_nomatch(v_b_246);
        }
      }
      default: return heff_nomatch(v_x11_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s717144537x1885076661_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s717144537x1885076661(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s79542405x478516404_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s79542405x478516404_entry, 1, 0};

V g_list_2emap_24s79542405x478516404(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_243));
      v_t_246 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s79542405x478516404_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s79542405x478516404_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s79542405x478516404(a[0]);
}
Clo g_list_2emap_24s892909862x1245535974_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s892909862x1245535974_entry, 4, 0};

V g_list_2emap_24s892909862x1245535974(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_244)) {
    case TAG_At: {
      V v_a_246 = heff_field(v_x_244, 0);
      V v_a_247 = heff_field(v_x_244, 1);
      V v_ru_24x_244_24At = heff_take_reuse_n(v_x_244, 3ULL, 2);
      switch (heff_tag_of(v_a_246)) {
      case TAG_MkEquation: {
        V v_a_249 = heff_field(v_a_246, 1);
        V v_a_2410 = heff_field(v_a_246, 2);
        V v_a_2411 = heff_field(v_a_246, 3);
        V v_ru_24a_246_24MkEquation = heff_take_reuse_n(v_a_246, 14ULL, 4);
        V v_t_2412 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_lit_241));
        V v_t_2413 = heff_tag_at_n(v_ru_24x_244_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_lit_242)}), heff_dup(v_a_249)});
        V v_t_2414 = heff_tag_at_n(v_ru_24a_246_24MkEquation, TAG_MkEquation, 4, (V[]){v_t_2412, v_a_249, heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2413, v_a_2410}), v_a_2411});
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_a_247});
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s892909862x1245535974_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s892909862x1245535974_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s892909862x1245535974(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_list_2emap_24s1691485302x273983346_24dps_str0, 4, "#arg");
HEFF_LIT(g_list_2emap_24s1691485302x273983346_24dps_str1, 7, "#mutual");
HEFF_LIT(g_list_2emap_24s1691485302x273983346_24dps_str2, 4, "#arg");
Clo g_list_2emap_24s1691485302x273983346_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1691485302x273983346_24dps_entry, 3, 0};

V g_list_2emap_24s1691485302x273983346_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_k_245 = heff_dup(v_lit_240);
    V v_d_246 = v_x_243;
    V v_name_247 = heff_take_field(v_d_246, 0);
    V v_span_248 = heff_get_n(v_d_246, 1, 5);
    V v_t_249 = heff_tag_n(TAG_LamName, 2, (V[]){heff_strAppend(heff_dup(v_name_247), ((V)&g_list_2emap_24s1691485302x273983346_24dps_str0)), heff_dup(v_span_248)});
    V v_t_2410 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(heff_dup(v_name_247), ((V)&g_list_2emap_24s1691485302x273983346_24dps_str1))});
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_k_245}), heff_dup(v_span_248)});
    V v_t_2412 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(heff_dup(v_name_247), ((V)&g_list_2emap_24s1691485302x273983346_24dps_str2))});
    V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_span_248)}), NTAG(TAG_Nil)});
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_span_248)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2413})));
    V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_249, v_t_2414}), heff_dup(v_span_248)});
    V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_SetField, 3, (V[]){v_name_247, heff_dup(v_span_248), v_t_2415}), v_span_248});
    V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_2417;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1691485302x273983346_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1691485302x273983346_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s183165982x1490920686_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s183165982x1490920686_entry, 1, 0};

V g_list_2ekeepIf_24s183165982x1490920686(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s183165982x1490920686_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s183165982x1490920686_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s183165982x1490920686(a[0]);
}
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_str0, 1, "_");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_str1, 7, "Float64");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_str2, 4, "Int8");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_str3, 5, "Int16");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_str4, 5, "Int32");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_str5, 5, "Int64");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_str6, 5, "UInt8");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_str7, 6, "UInt16");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_str8, 6, "UInt32");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_str9, 6, "UInt64");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_str10, 7, "Float32");
Clo g_list_2emap_24s2010608108x1221393166_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2010608108x1221393166_entry, 1, 0};

V g_list_2emap_24s2010608108x1221393166(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x_243 = v_x_241;
    V v_t_248;
    if (heff_strEq_c_lent(v_x_243, ((V)&g_list_2emap_24s2010608108x1221393166_str0), 2)) {
      heff_drop(v_x_243);
      v_t_248 = NTAG(TAG_RepV);
    } else {
      if (heff_strEq_c_lent(v_x_243, ((V)&g_list_2emap_24s2010608108x1221393166_str1), 2)) {
        heff_drop(v_x_243);
        v_t_248 = NTAG(TAG_RepF64);
      } else {
        HeffT2 v_t_244 = ({ V a_0 = ((V)&g_list_2emap_24s2010608108x1221393166_str2); V a_1 = ((V)&g_list_2emap_24s2010608108x1221393166_str3); V a_2 = ((V)&g_list_2emap_24s2010608108x1221393166_str4); V a_3 = ((V)&g_list_2emap_24s2010608108x1221393166_str5); V a_4 = ((V)&g_list_2emap_24s2010608108x1221393166_str6); V a_5 = ((V)&g_list_2emap_24s2010608108x1221393166_str7); V a_6 = ((V)&g_list_2emap_24s2010608108x1221393166_str8); V a_7 = ((V)&g_list_2emap_24s2010608108x1221393166_str9); V a_8 = ((V)&g_list_2emap_24s2010608108x1221393166_str10); V a_9 = v_x_243; V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1896676244x1358329894_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(v_x_243); heff_drop(b_10); r_; });
        {
          V v_field_246 = v_t_244.f[1];
          int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
          if ((v_tag_245 == ((int64_t)0ULL))) {
            V v_x_247 = v_field_246;
            v_t_248 = heff_tag_n(TAG_RepFix, 1, (V[]){v_x_247});
          } else {
            heff_drop(v_field_246);
            v_t_248 = NTAG(TAG_RepV);
          }
        }
      }
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s2010608108x1221393166_24dps(v_xs_242, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2010608108x1221393166_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2010608108x1221393166(a[0]);
}
Clo g_list_2efoldl_24s728686882x2096535788_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s728686882x2096535788_entry, 3, 0};

V g_list_2efoldl_24s728686882x2096535788(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 2, (V[]){heff_dup(v_lit_240), v_x_243}), v_z_241});
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s728686882x2096535788_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s728686882x2096535788(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s243940296x1179168444_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s243940296x1179168444_entry, 2, 0};

V g_list_2efoldl_24s243940296x1179168444(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), NTAG(TAG_Nil)});
    V v_t_245 = (g_heff_2ecompile_2efacts_2esureW(v_z_240, v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s243940296x1179168444_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s243940296x1179168444(a[0], a[1]);
}
Clo g_list_2eany_24s1037819844x481859879_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1037819844x481859879_entry, 8, 0};

V g_list_2eany_24s1037819844x481859879(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_245);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_t_2410 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), heff_dup(v_x_248)), heff_dup(v_lit_242));
    V v_t_2413;
    switch (heff_tag_of(v_lit_244)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_lit_244, 0);
      v_t_2413 = heff_dup(v_a_2411);
      break;
    }
    default: heff_nomatch(v_lit_244);
    }
    V v_t_2414 = heff_strAppend(heff_strAppend(heff_dup(v_lit_243), v_t_2413), heff_dup(v_lit_245));
    if (heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_t_2410, v_t_2414, v_lit_246, 3))) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_245);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_xs_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_x2_247 = t_7;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2eany_24s1037819844x481859879_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2eany_24s1037819844x481859879(a[0], a[1], a[2], a[3], a4, a[5], a6, a7); heff_drop(a4); heff_drop(a6); heff_drop(a7); return r;
}
Clo g_list_2efoldl_24s421921225x565177679_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s421921225x565177679_entry, 2, 0};

V g_list_2efoldl_24s421921225x565177679(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_a_246}), v_z_240});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s421921225x565177679(a[0], a[1]);
}
Clo g_list_2eall_24s1465078656x604124530_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1465078656x604124530_entry, 1, 0};

V g_list_2eall_24s1465078656x604124530(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_x1_243 = heff_dup(v_x_241);
    V v_t_2488;
    switch (heff_tag_of(v_x1_243)) {
    case TAG_RLocal: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_True);
      break;
    }
    case TAG_RDup: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_True);
      break;
    }
    case TAG_RClo: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RGet: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RGetRaw: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RInt: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_True);
      break;
    }
    case TAG_RFloat: {
      heff_take_na(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RStr: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_True);
      break;
    }
    case TAG_RBytes: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RFixed: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RF32: {
      heff_take_na(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RNTag: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_True);
      break;
    }
    case TAG_RTag: {
      heff_take_n(v_x1_243, 0ULL, 3);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RTagIn: {
      heff_take_n(v_x1_243, 0ULL, 4);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RRec: {
      heff_take_n(v_x1_243, 0ULL, 3);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RRecIn: {
      heff_take_n(v_x1_243, 0ULL, 8);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RField: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RDupE: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RFieldV: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RGetN: {
      heff_take_n(v_x1_243, 0ULL, 3);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RFieldU: {
      heff_take_n(v_x1_243, 0ULL, 4);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RGetNU: {
      heff_take_n(v_x1_243, 0ULL, 5);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RWord: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RTakeField: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RGetLabel: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RPrimFn: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RPrim: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RLam: {
      heff_take_n(v_x1_243, 0ULL, 4);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RCall: {
      heff_take_n(v_x1_243, 0ULL, 4);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RApply: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RBool: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RAbandon: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RBox: {
      V v_x11_2472 = heff_field(v_x1_243, 0);
      V v_e_2473 = heff_field(v_x1_243, 1);
      heff_take_n(v_x1_243, 3ULL, 2);
      switch (heff_tag_of(v_x11_2472)) {
      case TAG_RepV: {
        heff_drop(v_e_2473);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_RepFix: {
        heff_take_n(v_x11_2472, 0ULL, 1);
        heff_drop(v_e_2473);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        heff_drop(v_e_2473);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2488 = ({ V a_0 = v_e_2473; V r_ = (g_heff_2ecompile_2eowned_2ewordOnly(a_0)); heff_drop(v_e_2473); r_; });
        break;
      }
      default: heff_nomatch(v_x11_2472);
      }
      break;
    }
    case TAG_RUnbox: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RPeek: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RPrimU: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RPrimAt: {
      heff_take_n(v_x1_243, 0ULL, 3);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RFixU: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RF32U: {
      heff_take_na(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_RF64U: {
      heff_take_na(v_x1_243, 0ULL, 1);
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x1_243);
    }
    if ((heff_dup(v_t_2488) == NTAG(TAG_True))) {
      heff_drop(v_t_2488);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_2488);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1465078656x604124530_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1465078656x604124530(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1353477632x1698603588_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1353477632x1698603588_24dps_entry, 2, 0};

V g_list_2emap_24s1353477632x1698603588_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_RFixU, 2, (V[]){NTAG(TAG_I64), MK_INT(0LL)});
    V v_t_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_x_242}), NTAG(TAG_Nil)});
    V v_t_246 = heff_tag_n(TAG_CondRelU, 2, (V[]){NTAG(TAG_WordLe), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_245})});
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1353477632x1698603588_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1353477632x1698603588_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1947501783x1475115781_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1947501783x1475115781_entry, 3, 0};

V g_list_2emap_24s1947501783x1475115781(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_intSub(heff_intSub(heff_dup(v_lit_240), v_x_243), heff_dup(v_lit_241));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1947501783x1475115781_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1947501783x1475115781_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1947501783x1475115781(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s1082941870x132941142_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1082941870x132941142_entry, 2, 0};

V g_list_2eany_24s1082941870x132941142(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_UpdateTo: {
      V v_a_244 = heff_field(v_lit_240, 0);
      v_t_2412 = heff_dup(v_a_244);
      break;
    }
    case TAG_UpdateIn: {
      V v_a_248 = heff_field(v_lit_240, 0);
      v_t_2412 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    if (heff_strEq_c_lent(v_t_2412, v_x_242, 1)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1082941870x132941142_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1082941870x132941142(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s1928181476x241816070_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1928181476x241816070_entry, 2, 0};

V g_list_2ezipWith_24s1928181476x241816070(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_x_242, heff_tag_n(TAG_EVar, 1, (V[]){v_y_244})});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s1928181476x241816070_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1928181476x241816070_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1928181476x241816070(a[0], a[1]);
}
Clo g_list_2efoldl_24s319398146x1205310166_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s319398146x1205310166_entry, 4, 0};

V g_list_2efoldl_24s319398146x1205310166(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_heff_2ecompile_2eworker_2ehopeOne(heff_dup(v_lit_240), heff_dup(v_lit_241), v_z_242, heff_dup(v_x_244)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_246;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s319398146x1205310166_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s319398146x1205310166(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s1579438642x567671990_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1579438642x567671990_entry, 5, 0};

V g_list_2efoldl_24s1579438642x567671990(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_244, 0);
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_t_247 = (g_heff_2ecompile_2elower_2epieceStep(heff_dup(v_lit_240), v_lit_241, heff_dup(v_lit_242), v_z_243, heff_dup(v_x_245)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_247;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s1579438642x567671990_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_list_2efoldl_24s1579438642x567671990(a[0], a1, a[2], a[3], a4); heff_drop(a1); heff_drop(a4); return r;
}
Clo g_list_2efoldl_24s1437740164x269163243_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1437740164x269163243_entry, 2, 0};

V g_list_2efoldl_24s1437740164x269163243(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1437740164x269163243_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1437740164x269163243(a[0], a1); heff_drop(a1); return r;
}
V g_list_2emap_24s584558070x895760461_24dps_lam0(V self, V *args);
Clo g_list_2emap_24s584558070x895760461_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s584558070x895760461_24dps_entry, 3, 0};

V g_list_2emap_24s584558070x895760461_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_245 = heff_dup(v_lit_240);
    V v_x_246 = heff_take_field(v_r_245, 0);
    V v_chk_247 = heff_get_n(v_r_245, 3, 5);
    V v_x2_248 = v_x_243;
    V v_t_2419;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_At: {
      V v_x21_249 = heff_field(v_x2_248, 0);
      V v_sp_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24At = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      switch (heff_tag_of(v_x21_249)) {
      case TAG_MkEquation: {
        V v_f_2411 = heff_field(v_x21_249, 0);
        V v_fsp_2412 = heff_field(v_x21_249, 1);
        V v_ps_2413 = heff_field(v_x21_249, 2);
        V v_rhs_2414 = heff_field(v_x21_249, 3);
        V v_ru_24x21_249_24MkEquation = heff_take_reuse_n(v_x21_249, 15ULL, 4);
        V v_t_2417 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_list_2emap_24s584558070x895760461_24dps_lam0, 1, 1, (V[]){v_x_246}), v_ps_2413));
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop(v_chk_247);
          heff_drop(v_t_2417);
          v_t_2419 = heff_tag_at_n(v_ru_24x2_248_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_249_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_2411, v_fsp_2412, v_ps_2413, v_rhs_2414}), v_sp_2410});
        } else {
          heff_drop(v_t_2417);
          V v_t_2418 = heff_tr(heff_call(v_chk_247, 1, (V[]){v_rhs_2414}));
          v_t_2419 = heff_tag_at_n(v_ru_24x2_248_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_249_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_2411, v_fsp_2412, v_ps_2413, v_t_2418}), v_sp_2410});
        }
        break;
      }
      default: heff_nomatch(v_x21_249);
      }
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_2420;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s584558070x895760461_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s584558070x895760461_24dps(a[0], a[1], a[2]);
}
V g_list_2emap_24s584558070x895760461_24dps_lam0(V self, V *args) {
  V v_p_2415 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2416 = (g_heff_2eelab_2eclauses_2epatBinds(v_p_2415));
  return ({ V a_0 = v_x_246; V a_1 = v_xs_2416; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_x_246); heff_drop(v_xs_2416); r_; });
}
Clo g_list_2emap_24s1134745827x519521524_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1134745827x519521524_24dps_entry, 2, 0};

V g_list_2emap_24s1134745827x519521524_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_ty_244 = heff_take_field(v_x_242, 1);
    V v_size_245 = heff_get_n(v_x_242, 2, 5);
    V v_t_246 = ({ V a_0 = v_ty_244; V a_1 = v_size_245; V r_ = (g_heff_2esyntax_2epresyntax_2esegmentOdd(a_0, a_1)); heff_drop(v_ty_244); heff_drop(v_size_245); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1134745827x519521524_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1134745827x519521524_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s796727596x829078925_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s796727596x829078925_entry, 1, 0};

V g_list_2emap_24s796727596x829078925(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s796727596x829078925_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s796727596x829078925_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s796727596x829078925(a[0]);
}
Clo g_list_2emap_24s1694755346x1599566812_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1694755346x1599566812_entry, 2, 0};

V g_list_2emap_24s1694755346x1599566812(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_name_244 = heff_take_field(v_x_242, 0);
    V v_key_245 = heff_get_n(v_x_242, 1, 2);
    V v_t_246 = heff_rec_n(3, shape_name__key__module, (V[]){v_name_244, v_key_245, heff_dup(heff_rfield(v_lit_240, 0))});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1694755346x1599566812_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1694755346x1599566812_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1694755346x1599566812(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1534167768x1221742344_24dps_str0, 56, "only the library that goes with heff declares primitives");
Clo g_list_2emap_24s1534167768x1221742344_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1534167768x1221742344_24dps_entry, 2, 0};

V g_list_2emap_24s1534167768x1221742344_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_sp_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(335LL), NTAG(TAG_SError), ((V)&g_list_2emap_24s1534167768x1221742344_24dps_str0), v_sp_245, NTAG(TAG_Nothing)});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1534167768x1221742344_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1534167768x1221742344_24dps(a[0], a[1]);
}
Clo g_list_2eall_24s1432467604x1830816726_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1432467604x1830816726_entry, 6, 0};

V g_list_2eall_24s1432467604x1830816726(V v_lit_240, V v_box_24lit_241, V v_box_24lit_242, V v_box_24lit_243, V v_box_24lit_244, V v_x2_245) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
  int64_t v_lit_242 = heff_unbox_word(v_box_24lit_242);
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_244 = heff_unbox_word(v_box_24lit_244);
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_a_248 = heff_strByteAt_lent(v_lit_240, v_x_246, 0);
    if ((((v_lit_241 <= heff_peek_word(v_a_248)) && (heff_peek_word(v_a_248) <= v_lit_242)) || ((v_lit_243 <= heff_peek_word(v_a_248)) && (heff_peek_word(v_a_248) <= v_lit_244)))) {
      heff_drop(v_a_248);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      int64_t t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      int64_t t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    } else {
      heff_drop(v_a_248);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2eall_24s1432467604x1830816726_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a5 = a[5]; V r = g_list_2eall_24s1432467604x1830816726(a0, a[1], a[2], a[3], a[4], a5); heff_drop(a0); heff_drop(a5); return r;
}
Clo g_list_2ezipWith_24s29557946x653938035_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s29557946x653938035_entry, 2, 0};

V g_list_2ezipWith_24s29557946x653938035(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_244, 1, 3), v_x_242});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s29557946x653938035_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s29557946x653938035_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s29557946x653938035(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s25507577x707942422_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s25507577x707942422_entry, 3, 0};

V g_list_2ekeepIf_24s25507577x707942422(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240)) && heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_241)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = (g_list_2ekeepIf_24s25507577x707942422_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s25507577x707942422_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s25507577x707942422(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s18996220x10511024_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s18996220x10511024_entry, 1, 0};

V g_list_2emap_24s18996220x10511024(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_243 = heff_take_field(v_x_241, 0);
    V v_path_244 = heff_get_n(v_x_241, 1, 3);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_243, v_path_244}), heff_hole()});
    V v_u_246 = (g_list_2emap_24s18996220x10511024_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s18996220x10511024_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s18996220x10511024(a[0]);
}
Clo g_list_2ecollapse_24s2033985552x1651472209_clo = {{0x80000000u, K_CLO, 0}, g_list_2ecollapse_24s2033985552x1651472209_entry, 2, 0};

V g_list_2ecollapse_24s2033985552x1651472209(V v_run_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_run_240;
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkPair: {
      V v_below_245 = heff_field(v_x31_242, 1);
      V v_t_2410;
      switch (heff_tag_of(v_below_245)) {
      case TAG_Nil: {
        v_t_2410 = (g_list_2emerge_2emergeFrom_240_24s825587185x1704110321(NTAG(TAG_True), heff_dup(v_below_245), v_run_240));
        break;
      }
      case TAG_Cons: {
        V v_a_246 = heff_field(v_below_245, 0);
        switch (heff_tag_of(v_run_240)) {
        case TAG_Nil: {
          v_t_2410 = (g_list_2emerge_2emergeFrom_240_24s825587185x1704110321(NTAG(TAG_True), heff_dup(v_below_245), v_run_240));
          break;
        }
        case TAG_Cons: {
          V v_b_248 = heff_dup(heff_field(v_run_240, 0));
          if (heff_intLe_c(heff_dup(heff_rfield(v_a_246, 0)), heff_get_n(v_b_248, 0, 2))) {
            v_t_2410 = (g_list_2emerge_2emergeFrom_240_24s825587185x1704110321(NTAG(TAG_True), heff_dup(v_below_245), v_run_240));
          } else {
            v_t_2410 = (g_list_2emerge_2emergeFrom_240_24s825587185x1704110321(NTAG(TAG_False), v_run_240, heff_dup(v_below_245)));
          }
          break;
        }
        default: heff_nomatch(v_run_240);
        }
        break;
      }
      default: heff_nomatch(v_below_245);
      }
      V t_0 = v_t_2410;
      V t_1 = v_rest_243;
      v_run_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2ecollapse_24s2033985552x1651472209_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ecollapse_24s2033985552x1651472209(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s2000102784x314586828_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2000102784x314586828_24dps_entry, 2, 0};

V g_list_2emap_24s2000102784x314586828_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x11_244, 0);
        V v_sp_247 = heff_field(v_x11_244, 1);
        heff_take_n(v_x11_244, 3ULL, 4);
        v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_246, v_sp_247})});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2411 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2412;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2000102784x314586828_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2000102784x314586828_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_24dps_str0, 5, "-- | ");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_24dps_str1, 4, "-- |");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_24dps_str2, 0, "");
Clo g_list_2emap_24s1819241345x1511673126_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1819241345x1511673126_24dps_entry, 2, 0};

V g_list_2emap_24s1819241345x1511673126_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    if (heff_strEq_c(heff_strSlice_lent(v_x_242, MK_INT(0LL), MK_INT(5LL), 6), ((V)&g_list_2emap_24s1819241345x1511673126_24dps_str0))) {
      V v_t_244 = heff_strSlice(heff_dup(v_x_242), MK_INT(5LL), heff_strLength(v_x_242));
      v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    } else {
      if (heff_strEq_c(v_x_242, ((V)&g_list_2emap_24s1819241345x1511673126_24dps_str1))) {
        v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_list_2emap_24s1819241345x1511673126_24dps_str2)});
      } else {
        v_t_245 = NTAG(TAG_Nothing);
      }
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1819241345x1511673126_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1819241345x1511673126_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s2134067310x2049132013_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2134067310x2049132013_entry, 2, 0};

V g_list_2efoldl_24s2134067310x2049132013(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2134067310x2049132013(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1816200867x1876638332_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1816200867x1876638332_24dps_entry, 2, 0};

V g_list_2emap_24s1816200867x1876638332_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1816200867x1876638332_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1816200867x1876638332_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s135291903x1031656159_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s135291903x1031656159_entry, 2, 0};

V g_list_2emap_24s135291903x1031656159(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2efieldDeclKey(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s135291903x1031656159_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s135291903x1031656159_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s135291903x1031656159(a[0], a[1]);
}

HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_246, v_lit_240, 1)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_list_2eany_24s1287956370x756381573_str0, 3, " / ");
HEFF_LIT(g_list_2eany_24s1287956370x756381573_str1, 3, " / ");
Clo g_list_2eany_24s1287956370x756381573_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1287956370x756381573_entry, 2, 0};

V g_list_2eany_24s1287956370x756381573(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_sel_244 = heff_dup(v_lit_240);
    V v_o_245 = heff_dup(v_x_242);
    V v_s_246 = heff_get_n(v_o_245, 0, 12);
    V v_xs_247 = ({ V a_0 = v_s_246; V b_1 = ((V)&g_list_2eany_24s1287956370x756381573_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_list_2eany_24s1287956370x756381573_str1), v_s_246, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_246); heff_drop(b_1); r_; });
    V v_x_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_247; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    V v_y_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_sel_244; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_sel_244); r_; });
    if (heff_intLe_c(v_y_249, v_x_248)) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1287956370x756381573_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1287956370x756381573(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s849938259x51049885_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_24dps_str3, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_24dps_str4, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_24dps_str5, 0, "");
Clo g_list_2emap_24s849938259x51049885_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s849938259x51049885_24dps_entry, 2, 0};

V g_list_2emap_24s849938259x51049885_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_JNull: {
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JArray: {
      V v_ns_248 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = (g_list_2emap_24s698781565x943874959(((V)&g_list_2emap_24s849938259x51049885_24dps_str0), ((V)&g_list_2emap_24s849938259x51049885_24dps_str1), ((V)&g_list_2emap_24s849938259x51049885_24dps_str2), ((V)&g_list_2emap_24s849938259x51049885_24dps_str3), ((V)&g_list_2emap_24s849938259x51049885_24dps_str4), ((V)&g_list_2emap_24s849938259x51049885_24dps_str5), v_ns_248));
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s849938259x51049885_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s849938259x51049885_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1193924222x1531824795_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1193924222x1531824795_entry, 3, 0};

V g_list_2emap_24s1193924222x1531824795(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_240))) {
      v_t_245 = ({ V rv_1 = heff_dup(v_lit_240); V rv_2 = heff_dup(v_lit_241); V rr_ = heff_rec_reuse_nf(v_x_243, 1ULL, 3, shape_name__path__version, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    } else {
      v_t_245 = v_x_243;
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1193924222x1531824795_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1193924222x1531824795_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1193924222x1531824795(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1387309293x1990579214_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1387309293x1990579214_24dps_entry, 2, 0};

V g_list_2emap_24s1387309293x1990579214_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 4);
        v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2411 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2412;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1387309293x1990579214_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1387309293x1990579214_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s296585291x885335139_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s296585291x885335139_entry, 1, 0};

V g_list_2emap_24s296585291x885335139(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eheadOf(heff_dup(v_x_241)));
    V v_t_244 = (g_std_2ecli_2eline2(v_t_243, heff_get_n(v_x_241, 1, 4)));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s296585291x885335139_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s296585291x885335139_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s296585291x885335139(a[0]);
}
Clo g_list_2ekeepIf_24s1252894891x837498180_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1252894891x837498180_entry, 4, 0};

V g_list_2ekeepIf_24s1252894891x837498180(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_241, 6);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 2)), 0, 2);
    V v_t_247 = heff_strFind(heff_strOfRunes(v_t_246), heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_242));
    if (heff_intLe_c_lent(v_lit_240, v_t_247, 2)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = (g_list_2ekeepIf_24s1252894891x837498180_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop_rec(v_x_244, 3);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s1252894891x837498180_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ekeepIf_24s1252894891x837498180(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f1323813142x1311067101_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1323813142x1311067101_entry, 4, 0};

V g_list_2efoldl_24f1323813142x1311067101(V v_lit_240, V v_z_241, V v_p_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_p_242), 1, (V[]){heff_dup(v_x_244)}));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_p_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_p_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_p_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_p_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1323813142x1311067101_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f1323813142x1311067101(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2emap_24f1512150482x179770396_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1512150482x179770396_entry, 4, 0};

V g_list_2emap_24f1512150482x179770396(V v_lit_240, V v_lit_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLt_c_lent(v_b_243, v_a_242, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Nil);
  } else {
    V v_t_244 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(heff_dup(v_a_242)));
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_244, heff_dup(v_lit_241)), heff_hole()});
    V v_u_246 = (g_list_2emap_24f1512150482x179770396_24dps(v_lit_240, v_lit_241, heff_box_word((heff_unbox_word(v_a_242) + ((int64_t)1ULL))), v_b_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
}
V g_list_2emap_24f1512150482x179770396_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1512150482x179770396(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f891411706x655200538_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f891411706x655200538_entry, 2, 0};

V g_list_2efoldl_24f891411706x655200538(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x_247 = heff_get_n(v_t_246, 2, 3);
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f891411706x655200538_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f891411706x655200538(a[0], a[1]);
}
Clo g_list_2emap_24f669780424x1745768631_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f669780424x1745768631_24dps_entry, 6, 0};

V g_list_2emap_24f669780424x1745768631_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_x2_244, V v_d_245) {
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop(v_lit_241);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_x_2410;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_246, 0);
      heff_take_n(v_x_246, 1ULL, 2);
      v_x_2410 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_a_2411 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_lit_241));
    V v_t_2412 = heff_strSlice(heff_dup(v_x_2410), heff_dup(v_lit_242), heff_strLength_lent(v_a_2411, 0));
    V v_t_2416;
    if (heff_strEq_c(v_t_2412, v_a_2411)) {
      V v_t_2413 = heff_strLength(heff_dup(heff_rfield(v_lit_240, 0)));
      V v_t_2414 = heff_strSlice(heff_dup(v_x_2410), heff_box_word((heff_unbox_word(v_t_2413) + v_lit_243)), heff_strLength_lent(v_x_2410, 0));
      V v_t_2415 = heff_rec_n(3, shape_name__key__module, (V[]){v_t_2414, v_x_2410, heff_dup(heff_rfield(v_lit_240, 0))});
      v_t_2416 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
    } else {
      heff_drop(v_x_2410);
      v_t_2416 = NTAG(TAG_Nothing);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    int64_t t_3 = v_lit_243;
    V t_4 = v_xs_247;
    V t_5 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_x2_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f669780424x1745768631_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24f669780424x1745768631_24dps(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
Clo g_list_2emap_24f922554743x1845028609_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f922554743x1845028609_24dps_entry, 3, 0};

V g_list_2emap_24f922554743x1845028609_24dps(V v_p_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_243, 2, 3), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f922554743x1845028609_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f922554743x1845028609_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps_entry, 5, 0};

V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_shown_247 = heff_take_field(v_x_245, 2);
    V v_name_248 = heff_get_n(v_x_245, 0, 4);
    if ((heff_dup(v_shown_247) == NTAG(TAG_True))) {
      heff_drop(v_shown_247);
      V v_x_249 = v_name_248;
      V v_t_2410 = heff_strSlice(heff_dup(v_x_249), heff_dup(v_lit_241), heff_strLength_lent(v_lit_242, 0));
      if (heff_strEq_c_lent(v_t_2410, v_lit_242, 1)) {
        V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_249, heff_dup(v_lit_240)), heff_hole()});
        V v_u_2412 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2411));
        heff_drop(v_u_2412);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_cell_2411;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        v_d_244 = t_4;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        heff_drop(v_x_249);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_d_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_shown_247);
      heff_drop(v_name_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24f1524014098x1956473147_str0, 8, "browser.");
Clo g_list_2emap_24f1524014098x1956473147_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1524014098x1956473147_entry, 4, 0};

V g_list_2emap_24f1524014098x1956473147(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_library_246 = heff_take_field(v_x_244, 7);
    V v_module_247 = heff_get_n(v_x_244, 0, 8);
    if (((heff_dup(v_library_246) == NTAG(TAG_True)) && heff_strEq_c(heff_strSlice_lent(v_module_247, MK_INT(0LL), MK_INT(8LL), 6), ((V)&g_list_2emap_24f1524014098x1956473147_str0)))) {
      heff_drop(v_library_246);
      V v_t_248 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), heff_dup(v_module_247)), heff_dup(v_lit_242));
      V v_t_249 = heff_rec_n(4, shape_module__code__msg__note, (V[]){v_module_247, heff_dup(v_lit_240), v_t_248, NTAG(TAG_Nothing)});
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = (g_list_2emap_24f1524014098x1956473147_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_library_246);
      heff_drop(v_module_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1524014098x1956473147_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1524014098x1956473147(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f1564248594x622634626_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1564248594x622634626_entry, 3, 0};

V g_list_2efoldl_24f1564248594x622634626(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if (!(heff_dup(heff_rfield(v_x_243, 1)) == NTAG(TAG_True))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1564248594x622634626_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1564248594x622634626(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24f1622709115x782387749_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f1622709115x782387749_24dps_entry, 3, 0};

V g_list_2ekeepIf_24f1622709115x782387749_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = (g_list_2ekeepIf_24s44384897x1267641110(v_ys_241));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_243);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_x_244, 2));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_245;
      V t_1 = v_ys_241;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_xs_245;
      V t_1 = v_ys_241;
      V t_2 = v_d_242;
      v_x1_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2ekeepIf_24f1622709115x782387749_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24f1622709115x782387749_24dps(a[0], a[1], a[2]);
}