// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_BoxedWord 41718
#define TAG_CondRelU 46269
#define TAG_DeclareField 57313
#define TAG_EStr 50587
#define TAG_EVar 52881
#define TAG_Element 14172
#define TAG_F32 16337
#define TAG_FailBecause 16014
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Kept 49931
#define TAG_Left 13886
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_Often 32846
#define TAG_PVar 52952
#define TAG_PatVar 49363
#define TAG_Pinned 8573
#define TAG_Positional 16703
#define TAG_RFixU 5362
#define TAG_RLocal 34280
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_Typed 36072
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unboxed 46787
#define TAG_Wants 58903
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_def 308863
#define LBL_discarded 1490202606
#define LBL_doc 309170
#define LBL_end 310101
#define LBL_failure 1292767177
#define LBL_filter 672649891
#define LBL_forwards 1228451848
#define LBL_goldens 436112074
#define LBL_input 301716452
#define LBL_item 9738202
#define LBL_key 315609
#define LBL_labels 836724522
#define LBL_library 398066429
#define LBL_long 9823043
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_out 319944
#define LBL_owner 307523277
#define LBL_part 9928890
#define LBL_path 9928940
#define LBL_pre 320797
#define LBL_property 1899481104
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_severity 75955546
#define LBL_shape 310758331
#define LBL_shown 310772011
#define LBL_shrinks 154032591
#define LBL_size 10026184
#define LBL_skipped 231818613
#define LBL_slots 310891087
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_units 312791945
#define LBL_use 325633
#define LBL_ver 326173
#define LBL_version 583465758
#define LBL_whole 314465745
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_def__slots[] = {LBL_def, LBL_slots};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
static uint32_t shape_name__doc__shape[] = {LBL_name, LBL_doc, LBL_shape};
static uint32_t shape_name__key__module[] = {LBL_name, LBL_key, LBL_module};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_part__input[] = {LBL_part, LBL_input};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
V g_heff_2ebuild_2ebackcache_2eaddEmit(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddEmit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddEmit_clo;
V g_heff_2ebuild_2ecommands_2enewerTagged(V, V, V);
V g_heff_2ebuild_2ecommands_2enewerTagged_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enewerTagged_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eemitc_2emodulePart(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulePart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulePart_clo;
V g_heff_2ecompile_2efacts_2esureW(V, V);
V g_heff_2ecompile_2efacts_2esureW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureW_clo;
HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(V, V, V);
V g_heff_2ecompile_2elower_2epieceStep(V, V, V, V, V);
V g_heff_2ecompile_2elower_2epieceStep_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2epieceStep_clo;
V g_heff_2ecompile_2eowned_2eplainOperand(V);
V g_heff_2ecompile_2eowned_2eplainOperand_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eplainOperand_clo;
V g_heff_2ecompile_2erepr_2ereprOfName(V);
V g_heff_2ecompile_2erepr_2ereprOfName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprOfName_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2eunbox_2eslotsOf(V);
V g_heff_2ecompile_2eunbox_2eslotsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eslotsOf_clo;
V g_heff_2ecompile_2eworker_2ehopeOne(V, V, V, V);
V g_heff_2ecompile_2eworker_2ehopeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ehopeOne_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2erenameEquation(V, V);
V g_heff_2eelab_2eclauses_2erenameEquation_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameEquation_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2esyntax_2eformat_2efieldDeclKey(V, V);
V g_heff_2esyntax_2eformat_2efieldDeclKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldDeclKey_clo;
V g_heff_2esyntax_2epresyntax_2earmStmts(V);
V g_heff_2esyntax_2epresyntax_2earmStmts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmStmts_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
V g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240_clo;
V g_heff_2esyntax_2esurface_2eknotField(V, V);
V g_heff_2esyntax_2esurface_2eknotField_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eknotField_clo;
V g_list_2eall_24s1171800191x1592992932(V);
V g_list_2eall_24s1171800191x1592992932_entry(V self, V *a);
extern Clo g_list_2eall_24s1171800191x1592992932_clo;
V g_list_2eall_24s1373454977x2143028054(V);
V g_list_2eall_24s1373454977x2143028054_entry(V self, V *a);
extern Clo g_list_2eall_24s1373454977x2143028054_clo;
V g_list_2eall_24s1432467604x1830816726(V, V, V, V, V, V);
V g_list_2eall_24s1432467604x1830816726_entry(V self, V *a);
extern Clo g_list_2eall_24s1432467604x1830816726_clo;
V g_list_2eall_24s1465078656x604124530(V);
V g_list_2eall_24s1465078656x604124530_entry(V self, V *a);
extern Clo g_list_2eall_24s1465078656x604124530_clo;
V g_list_2eall_24s442836260x1032582242(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eall_24s442836260x1032582242_entry(V self, V *a);
extern Clo g_list_2eall_24s442836260x1032582242_clo;
V g_list_2eany_24s317268364x1703376737(V);
V g_list_2eany_24s317268364x1703376737_entry(V self, V *a);
extern Clo g_list_2eany_24s317268364x1703376737_clo;
V g_list_2eany_24s717144537x1885076661(V);
V g_list_2eany_24s717144537x1885076661_entry(V self, V *a);
extern Clo g_list_2eany_24s717144537x1885076661_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1327702553x1694210434_24cpr(V, V);
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl_24f1323813142x1311067101(V, V, V, V);
V g_list_2efoldl_24f1323813142x1311067101_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1323813142x1311067101_clo;
V g_list_2efoldl_24f1564248594x622634626(V, V, V);
V g_list_2efoldl_24f1564248594x622634626_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1564248594x622634626_clo;
V g_list_2efoldl_24f891411706x655200538(V, V);
V g_list_2efoldl_24f891411706x655200538_entry(V self, V *a);
extern Clo g_list_2efoldl_24f891411706x655200538_clo;
V g_list_2efoldl_24s1004873070x1577485130(V, V, V);
V g_list_2efoldl_24s1004873070x1577485130_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1004873070x1577485130_clo;
V g_list_2efoldl_24s1134919403x2060330530(V, V);
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1134919403x2060330530_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1437740164x269163243(V, V);
V g_list_2efoldl_24s1437740164x269163243_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1437740164x269163243_clo;
V g_list_2efoldl_24s1483820613x1826490246(V, V);
V g_list_2efoldl_24s1483820613x1826490246_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1483820613x1826490246_clo;
V g_list_2efoldl_24s1579438642x567671990(V, V, V, V, V);
V g_list_2efoldl_24s1579438642x567671990_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1579438642x567671990_clo;
V g_list_2efoldl_24s1917169677x762627694(V, V);
V g_list_2efoldl_24s1917169677x762627694_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1917169677x762627694_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s2051016282x1892781518(V, V, V, V);
V g_list_2efoldl_24s2051016282x1892781518_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2051016282x1892781518_clo;
V g_list_2efoldl_24s2134067310x2049132013(V, V);
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2134067310x2049132013_clo;
V g_list_2efoldl_24s243940296x1179168444(V, V);
V g_list_2efoldl_24s243940296x1179168444_entry(V self, V *a);
extern Clo g_list_2efoldl_24s243940296x1179168444_clo;
V g_list_2efoldl_24s319398146x1205310166(V, V, V, V);
V g_list_2efoldl_24s319398146x1205310166_entry(V self, V *a);
extern Clo g_list_2efoldl_24s319398146x1205310166_clo;
V g_list_2efoldl_24s417343796x227886918(V, V, V);
V g_list_2efoldl_24s417343796x227886918_entry(V self, V *a);
extern Clo g_list_2efoldl_24s417343796x227886918_clo;
V g_list_2efoldl_24s421921225x565177679(V, V);
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a);
extern Clo g_list_2efoldl_24s421921225x565177679_clo;
V g_list_2efoldl_24s532345456x1351763934(V, V);
V g_list_2efoldl_24s532345456x1351763934_entry(V self, V *a);
extern Clo g_list_2efoldl_24s532345456x1351763934_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s728686882x2096535788(V, V, V);
V g_list_2efoldl_24s728686882x2096535788_entry(V self, V *a);
extern Clo g_list_2efoldl_24s728686882x2096535788_clo;
V g_list_2efoldl_24s788343806x1528994845(V, V, V);
V g_list_2efoldl_24s788343806x1528994845_entry(V self, V *a);
extern Clo g_list_2efoldl_24s788343806x1528994845_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2ekeepIf_24f1622709115x782387749_24dps(V, V, V);
V g_list_2ekeepIf_24f1622709115x782387749_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1622709115x782387749_24dps_clo;
V g_list_2ekeepIf_24s1252894891x837498180(V, V, V, V);
V g_list_2ekeepIf_24s1252894891x837498180_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1252894891x837498180_clo;
V g_list_2ekeepIf_24s1252894891x837498180_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s1252894891x837498180_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1252894891x837498180_24dps_clo;
V g_list_2ekeepIf_24s1606737509x658906972(V);
V g_list_2ekeepIf_24s1606737509x658906972_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1606737509x658906972_clo;
V g_list_2ekeepIf_24s1606737509x658906972_24dps(V, V);
V g_list_2ekeepIf_24s1606737509x658906972_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1606737509x658906972_24dps_clo;
V g_list_2ekeepIf_24s183165982x1490920686(V);
V g_list_2ekeepIf_24s183165982x1490920686_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s183165982x1490920686_clo;
V g_list_2ekeepIf_24s183165982x1490920686_24dps(V, V);
V g_list_2ekeepIf_24s183165982x1490920686_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s183165982x1490920686_24dps_clo;
V g_list_2ekeepIf_24s2115931744x466898799_24dps(V, V, V);
V g_list_2ekeepIf_24s2115931744x466898799_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2115931744x466898799_24dps_clo;
V g_list_2ekeepIf_24s25507577x707942422(V, V, V);
V g_list_2ekeepIf_24s25507577x707942422_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s25507577x707942422_clo;
V g_list_2ekeepIf_24s25507577x707942422_24dps(V, V, V, V);
V g_list_2ekeepIf_24s25507577x707942422_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s25507577x707942422_24dps_clo;
V g_list_2ekeepIf_24s44384897x1267641110(V);
V g_list_2ekeepIf_24s44384897x1267641110_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s44384897x1267641110_clo;
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps(V, V, V, V, V);
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps_clo;
V g_list_2emap_24f1744384903x906515519(V);
V g_list_2emap_24f1744384903x906515519_entry(V self, V *a);
extern Clo g_list_2emap_24f1744384903x906515519_clo;
V g_list_2emap_24f1744384903x906515519_24dps(V, V);
V g_list_2emap_24f1744384903x906515519_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1744384903x906515519_24dps_clo;
V g_list_2emap_24f1952774010x636070089(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1952774010x636070089_entry(V self, V *a);
extern Clo g_list_2emap_24f1952774010x636070089_clo;
V g_list_2emap_24f1952774010x636070089_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1952774010x636070089_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1952774010x636070089_24dps_clo;
V g_list_2emap_24f310588246x1624488069_24dps(V, V, V, V, V);
V g_list_2emap_24f310588246x1624488069_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f310588246x1624488069_24dps_clo;
V g_list_2emap_24f669780424x1745768631_24dps(V, V, V, V, V, V);
V g_list_2emap_24f669780424x1745768631_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f669780424x1745768631_24dps_clo;
V g_list_2emap_24f922554743x1845028609_24dps(V, V, V);
V g_list_2emap_24f922554743x1845028609_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f922554743x1845028609_24dps_clo;
V g_list_2emap_24s1134745827x519521524_24dps(V, V);
V g_list_2emap_24s1134745827x519521524_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1134745827x519521524_24dps_clo;
V g_list_2emap_24s1146729723x1441207893(V, V, V);
V g_list_2emap_24s1146729723x1441207893_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_clo;
V g_list_2emap_24s1146729723x1441207893_24dps(V, V, V, V);
V g_list_2emap_24s1146729723x1441207893_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_24dps_clo;
V g_list_2emap_24s1173914895x100384474_24dps(V, V);
V g_list_2emap_24s1173914895x100384474_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24dps_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1181937096x2120532116_24dps(V, V);
V g_list_2emap_24s1181937096x2120532116_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_24dps_clo;
V g_list_2emap_24s1193924222x1531824795(V, V, V);
V g_list_2emap_24s1193924222x1531824795_entry(V self, V *a);
extern Clo g_list_2emap_24s1193924222x1531824795_clo;
V g_list_2emap_24s1193924222x1531824795_24dps(V, V, V, V);
V g_list_2emap_24s1193924222x1531824795_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1193924222x1531824795_24dps_clo;
V g_list_2emap_24s1263350589x621576050(V);
V g_list_2emap_24s1263350589x621576050_entry(V self, V *a);
extern Clo g_list_2emap_24s1263350589x621576050_clo;
V g_list_2emap_24s1263350589x621576050_24dps(V, V);
V g_list_2emap_24s1263350589x621576050_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1263350589x621576050_24dps_clo;
V g_list_2emap_24s135291903x1031656159(V, V);
V g_list_2emap_24s135291903x1031656159_entry(V self, V *a);
extern Clo g_list_2emap_24s135291903x1031656159_clo;
V g_list_2emap_24s135291903x1031656159_24dps(V, V, V);
V g_list_2emap_24s135291903x1031656159_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s135291903x1031656159_24dps_clo;
V g_list_2emap_24s1353477632x1698603588_24dps(V, V);
V g_list_2emap_24s1353477632x1698603588_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1353477632x1698603588_24dps_clo;
V g_list_2emap_24s1387309293x1990579214_24dps(V, V);
V g_list_2emap_24s1387309293x1990579214_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1387309293x1990579214_24dps_clo;
V g_list_2emap_24s1460603830x671758883_24dps(V, V, V);
V g_list_2emap_24s1460603830x671758883_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_24dps_clo;
V g_list_2emap_24s1460603830x671758883_24tok1(V, V, V);
V g_list_2emap_24s1460603830x671758883_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_24tok1_clo;
V g_list_2emap_24s1531382666x123921537(V);
V g_list_2emap_24s1531382666x123921537_entry(V self, V *a);
extern Clo g_list_2emap_24s1531382666x123921537_clo;
V g_list_2emap_24s1531382666x123921537_24dps(V, V);
V g_list_2emap_24s1531382666x123921537_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1531382666x123921537_24dps_clo;
V g_list_2emap_24s1534167768x1221742344_24dps(V, V);
V g_list_2emap_24s1534167768x1221742344_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1534167768x1221742344_24dps_clo;
V g_list_2emap_24s1539380703x380520933(V);
V g_list_2emap_24s1539380703x380520933_entry(V self, V *a);
extern Clo g_list_2emap_24s1539380703x380520933_clo;
V g_list_2emap_24s1539380703x380520933_24dps(V, V);
V g_list_2emap_24s1539380703x380520933_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1539380703x380520933_24dps_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s1598879313x231311047_24dps(V, V);
V g_list_2emap_24s1598879313x231311047_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_24dps_clo;
V g_list_2emap_24s1691485302x273983346_24dps(V, V, V);
V g_list_2emap_24s1691485302x273983346_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1691485302x273983346_24dps_clo;
V g_list_2emap_24s1767134203x962737276(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1767134203x962737276_entry(V self, V *a);
extern Clo g_list_2emap_24s1767134203x962737276_clo;
V g_list_2emap_24s179832492x431904054(V);
V g_list_2emap_24s179832492x431904054_entry(V self, V *a);
extern Clo g_list_2emap_24s179832492x431904054_clo;
V g_list_2emap_24s179832492x431904054_24dps(V, V);
V g_list_2emap_24s179832492x431904054_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s179832492x431904054_24dps_clo;
V g_list_2emap_24s1816200867x1876638332_24dps(V, V);
V g_list_2emap_24s1816200867x1876638332_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1816200867x1876638332_24dps_clo;
V g_list_2emap_24s1819241345x1511673126_24dps(V, V);
V g_list_2emap_24s1819241345x1511673126_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_24dps_clo;
V g_list_2emap_24s1854779998x1713580578_24dps(V, V);
V g_list_2emap_24s1854779998x1713580578_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1854779998x1713580578_24dps_clo;
V g_list_2emap_24s18996220x10511024(V);
V g_list_2emap_24s18996220x10511024_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_clo;
V g_list_2emap_24s18996220x10511024_24dps(V, V);
V g_list_2emap_24s18996220x10511024_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_24dps_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s1947501783x1475115781(V, V, V);
V g_list_2emap_24s1947501783x1475115781_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_clo;
V g_list_2emap_24s1947501783x1475115781_24dps(V, V, V, V);
V g_list_2emap_24s1947501783x1475115781_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_24dps_clo;
V g_list_2emap_24s2000102784x314586828_24dps(V, V);
V g_list_2emap_24s2000102784x314586828_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_24dps_clo;
V g_list_2emap_24s2010608108x1221393166(V);
V g_list_2emap_24s2010608108x1221393166_entry(V self, V *a);
extern Clo g_list_2emap_24s2010608108x1221393166_clo;
V g_list_2emap_24s2010608108x1221393166_24dps(V, V);
V g_list_2emap_24s2010608108x1221393166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2010608108x1221393166_24dps_clo;
V g_list_2emap_24s2015709068x2065046486(V, V, V, V, V, V, V);
V g_list_2emap_24s2015709068x2065046486_entry(V self, V *a);
extern Clo g_list_2emap_24s2015709068x2065046486_clo;
V g_list_2emap_24s2015709068x2065046486_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s2015709068x2065046486_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2015709068x2065046486_24dps_clo;
V g_list_2emap_24s272223926x273382154_24dps(V, V);
V g_list_2emap_24s272223926x273382154_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s272223926x273382154_24dps_clo;
V g_list_2emap_24s296585291x885335139(V);
V g_list_2emap_24s296585291x885335139_entry(V self, V *a);
extern Clo g_list_2emap_24s296585291x885335139_clo;
V g_list_2emap_24s296585291x885335139_24dps(V, V);
V g_list_2emap_24s296585291x885335139_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s296585291x885335139_24dps_clo;
V g_list_2emap_24s338694954x1326523169_24dps(V, V);
V g_list_2emap_24s338694954x1326523169_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_24dps_clo;
V g_list_2emap_24s357242026x384251201_24dps(V, V);
V g_list_2emap_24s357242026x384251201_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_24dps_clo;
V g_list_2emap_24s500386242x1746840051(V);
V g_list_2emap_24s500386242x1746840051_entry(V self, V *a);
extern Clo g_list_2emap_24s500386242x1746840051_clo;
V g_list_2emap_24s500386242x1746840051_24dps(V, V);
V g_list_2emap_24s500386242x1746840051_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s500386242x1746840051_24dps_clo;
V g_list_2emap_24s510639937x1058700299(V);
V g_list_2emap_24s510639937x1058700299_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_clo;
V g_list_2emap_24s510639937x1058700299_24dps(V, V);
V g_list_2emap_24s510639937x1058700299_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_24dps_clo;
V g_list_2emap_24s584558070x895760461_24dps(V, V, V);
V g_list_2emap_24s584558070x895760461_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s584558070x895760461_24dps_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2emap_24s759871588x920431471_24dps(V, V);
V g_list_2emap_24s759871588x920431471_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_24dps_clo;
V g_list_2emap_24s766426360x2144213627_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s766426360x2144213627_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s766426360x2144213627_24dps_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;
V g_list_2emap_24s79542405x478516404_24dps(V, V);
V g_list_2emap_24s79542405x478516404_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_24dps_clo;
V g_list_2emap_24s796727596x829078925(V);
V g_list_2emap_24s796727596x829078925_entry(V self, V *a);
extern Clo g_list_2emap_24s796727596x829078925_clo;
V g_list_2emap_24s796727596x829078925_24dps(V, V);
V g_list_2emap_24s796727596x829078925_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s796727596x829078925_24dps_clo;
V g_list_2emap_24s849938259x51049885_24dps(V, V);
V g_list_2emap_24s849938259x51049885_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s849938259x51049885_24dps_clo;
V g_list_2emap_24s892909862x1245535974(V, V, V, V);
V g_list_2emap_24s892909862x1245535974_entry(V self, V *a);
extern Clo g_list_2emap_24s892909862x1245535974_clo;
V g_list_2emap_24s892909862x1245535974_24dps(V, V, V, V, V);
V g_list_2emap_24s892909862x1245535974_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s892909862x1245535974_24dps_clo;
V g_list_2emap_24s89567162x1162500052_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s89567162x1162500052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s89567162x1162500052_24dps_clo;
V g_list_2emap_24s939813003x1383013550(V);
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_clo;
V g_list_2emap_24s939813003x1383013550_24dps(V, V);
V g_list_2emap_24s939813003x1383013550_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_24dps_clo;
V g_list_2emap_24s976303750x321235480(V);
V g_list_2emap_24s976303750x321235480_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_clo;
V g_list_2emap_24s976303750x321235480_24dps(V, V);
V g_list_2emap_24s976303750x321235480_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_24dps_clo;
V g_list_2emerge_24s2030620912x751826577_24dps(V, V, V);
V g_list_2emerge_24s2030620912x751826577_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s2030620912x751826577_24dps_clo;
V g_list_2emerge_24s2030620912x751826577_24tok2(V, V, V);
V g_list_2emerge_24s2030620912x751826577_24tok2_entry(V self, V *a);
extern Clo g_list_2emerge_24s2030620912x751826577_24tok2_clo;
V g_list_2emerge_24s275559350x890699445(V, V);
V g_list_2emerge_24s275559350x890699445_entry(V self, V *a);
extern Clo g_list_2emerge_24s275559350x890699445_clo;
V g_list_2emerge_24s275559350x890699445_24tok2(V, V, V);
V g_list_2emerge_24s275559350x890699445_24tok2_entry(V self, V *a);
extern Clo g_list_2emerge_24s275559350x890699445_24tok2_clo;
V g_list_2ereplicate_24dps(V, V, V);
V g_list_2ereplicate_24dps_entry(V self, V *a);
extern Clo g_list_2ereplicate_24dps_clo;
V g_list_2esortBy_24s735547525x1777295590(V);
V g_list_2esortBy_24s735547525x1777295590_entry(V self, V *a);
extern Clo g_list_2esortBy_24s735547525x1777295590_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24dps(V, V, V, V);
V g_list_2ezipWith_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24dps_clo;
V g_list_2ezipWith_24s1891751394x1524628247(V, V, V, V, V);
V g_list_2ezipWith_24s1891751394x1524628247_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1891751394x1524628247_clo;
V g_list_2ezipWith_24s1891751394x1524628247_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s1891751394x1524628247_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1891751394x1524628247_24dps_clo;
V g_list_2ezipWith_24s1928181476x241816070(V, V);
V g_list_2ezipWith_24s1928181476x241816070_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_clo;
V g_list_2ezipWith_24s1928181476x241816070_24dps(V, V, V);
V g_list_2ezipWith_24s1928181476x241816070_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_24dps_clo;
V g_list_2ezipWith_24s29557946x653938035(V, V);
V g_list_2ezipWith_24s29557946x653938035_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s29557946x653938035_clo;
V g_list_2ezipWith_24s29557946x653938035_24dps(V, V, V);
V g_list_2ezipWith_24s29557946x653938035_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s29557946x653938035_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1057423371x1101358195(V, V);
V g_prelude_2e_2b_2b_24f1057423371x1101358195_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_clo;
V g_prelude_2e_2b_2b_24f1537904782x516751275(V, V);
V g_prelude_2e_2b_2b_24f1537904782x516751275_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1537904782x516751275_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
V g_std_2ecli_2ereading_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
Clo g_list_2ezipWith_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24dps_entry, 4, 0};

V g_list_2ezipWith_24dps(V v_f_240, V v_x2_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_x3_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_f_240);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_242, 0);
      V v_ys_247 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_248 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_x_244, v_y_246}));
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_f_240;
      V t_1 = v_xs_245;
      V t_2 = v_ys_247;
      V t_3 = v_cell_249;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2ereplicate_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ereplicate_24dps_entry, 3, 0};

V g_list_2ereplicate_24dps(V v_n_240, V v_x_241, V v_d_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_x_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_u_244 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_243));
    heff_drop(v_u_244);
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_x_241;
    V t_2 = v_cell_243;
    v_n_240 = t_0;
    v_x_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_list_2ereplicate_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ereplicate_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s2115931744x466898799_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2115931744x466898799_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s2115931744x466898799_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s2115931744x466898799_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s2115931744x466898799_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s1606737509x658906972_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1606737509x658906972_entry, 1, 0};

V g_list_2ekeepIf_24s1606737509x658906972(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = heff_get_n(v_t_245, 2, 3);
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      heff_take_n(v_t_246, 0ULL, 2);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2ekeepIf_24s1606737509x658906972_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1606737509x658906972_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1606737509x658906972(a[0]);
}
Clo g_list_2efoldl_24s1935134062x1256175429_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1935134062x1256175429_entry, 2, 0};

V g_list_2efoldl_24s1935134062x1256175429(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b_24f1057423371x1101358195(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1935134062x1256175429(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s947545569x507961639_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s947545569x507961639_entry, 2, 0};

V g_list_2efoldl_24s947545569x507961639(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_a_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s947545569x507961639(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s717144537x1885076661_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s717144537x1885076661_entry, 1, 0};

V g_list_2eany_24s717144537x1885076661(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkAlt: {
        V v_b_246 = heff_field(v_x11_243, 1);
        v_t_247 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_b_246)));
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_247);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s717144537x1885076661_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s717144537x1885076661(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s272223926x273382154_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s272223926x273382154_24dps_entry, 2, 0};

V g_list_2emap_24s272223926x273382154_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_MkAlt: {
        V v_p_246 = heff_field(v_x11_244, 0);
        V v_b_247 = heff_field(v_x11_244, 1);
        heff_take_n(v_x11_244, 3ULL, 2);
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2earmStmts(v_b_247));
        v_t_249 = heff_tag_at_n(v_ru_24x_242_24At, TAG_MkPair, 2, (V[]){v_p_246, v_t_248});
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s272223926x273382154_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s272223926x273382154_24dps(a[0], a[1]);
}
Clo g_list_2eall_24s1171800191x1592992932_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1171800191x1592992932_entry, 1, 0};

V g_list_2eall_24s1171800191x1592992932(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_243, 1);
        v_t_247 = (g_heff_2esyntax_2epresyntax_2earmStmts(heff_dup(v_a_246)));
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_a_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_247));
    switch (heff_tag_of(v_a_248)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_a_249 = heff_field(v_a_248, 0);
      heff_take_n(v_a_248, 1ULL, 2);
      switch (heff_tag_of(v_a_249)) {
      case TAG_At: {
        V v_a_2411 = heff_field(v_a_249, 0);
        heff_take_n(v_a_249, 1ULL, 2);
        switch (heff_tag_of(v_a_2411)) {
        case TAG_StmtBind: {
          heff_take_n(v_a_2411, 0ULL, 3);
          return NTAG(TAG_False);
        }
        case TAG_StmtLet: {
          heff_take_n(v_a_2411, 0ULL, 2);
          return NTAG(TAG_False);
        }
        case TAG_StmtExpr: {
          V v_a_2418 = heff_field(v_a_2411, 0);
          heff_take_n(v_a_2411, 1ULL, 1);
          V v_t_2419 = (g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240(v_a_2418));
          if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
            heff_drop(v_t_2419);
            V t_0 = v_xs_242;
            v_x2_240 = t_0;
            goto top;
          } else {
            heff_drop(v_t_2419);
            return NTAG(TAG_False);
          }
        }
        case TAG_StmtLetMut: {
          heff_take_n(v_a_2411, 0ULL, 3);
          return NTAG(TAG_False);
        }
        case TAG_StmtLetElse: {
          heff_take_n(v_a_2411, 0ULL, 3);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_a_2411);
        }
      }
      default: return heff_nomatch(v_a_249);
      }
    }
    default: return heff_nomatch(v_a_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1171800191x1592992932_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1171800191x1592992932(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s79542405x478516404_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s79542405x478516404_entry, 1, 0};

V g_list_2emap_24s79542405x478516404(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_243));
      v_t_246 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s79542405x478516404_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s79542405x478516404_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s79542405x478516404(a[0]);
}
Clo g_list_2emap_24s892909862x1245535974_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s892909862x1245535974_entry, 4, 0};

V g_list_2emap_24s892909862x1245535974(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_244)) {
    case TAG_At: {
      V v_a_246 = heff_field(v_x_244, 0);
      V v_a_247 = heff_field(v_x_244, 1);
      V v_ru_24x_244_24At = heff_take_reuse_n(v_x_244, 3ULL, 2);
      switch (heff_tag_of(v_a_246)) {
      case TAG_MkEquation: {
        V v_a_249 = heff_field(v_a_246, 1);
        V v_a_2410 = heff_field(v_a_246, 2);
        V v_a_2411 = heff_field(v_a_246, 3);
        V v_ru_24a_246_24MkEquation = heff_take_reuse_n(v_a_246, 14ULL, 4);
        V v_t_2412 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_lit_241));
        V v_t_2413 = heff_tag_at_n(v_ru_24x_244_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_lit_242)}), heff_dup(v_a_249)});
        V v_t_2414 = heff_tag_at_n(v_ru_24a_246_24MkEquation, TAG_MkEquation, 4, (V[]){v_t_2412, v_a_249, heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2413, v_a_2410}), v_a_2411});
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_a_247});
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s892909862x1245535974_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s892909862x1245535974_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s892909862x1245535974(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1691485302x273983346_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1691485302x273983346_24dps_entry, 3, 0};

V g_list_2emap_24s1691485302x273983346_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2esurface_2eknotField(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1691485302x273983346_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1691485302x273983346_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s338694954x1326523169_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s338694954x1326523169_24dps_entry, 2, 0};

V g_list_2emap_24s338694954x1326523169_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_msg_244 = heff_take_field(v_x_242, 2);
    V v_start_245 = heff_take_field(v_x_242, 0);
    V v_end_246 = heff_get_n(v_x_242, 1, 3);
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_244, heff_rec_n(2, shape_start__end, (V[]){v_start_245, v_end_246}), NTAG(TAG_Nothing)});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s338694954x1326523169_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s338694954x1326523169_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1891751394x1524628247_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1891751394x1524628247_entry, 5, 0};

V g_list_2ezipWith_24s1891751394x1524628247(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs_246);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_x3_244, 0);
      V v_ys_248 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_2410;
      if (heff_strEq_c_lent(v_x_245, v_lit_240, 0)) {
        heff_drop(v_x_245);
        V v_t_249 = heff_strAppend(heff_dup(v_lit_242), heff_intShow(v_y_247));
        v_t_2410 = heff_strAppend(heff_dup(v_lit_241), v_t_249);
      } else {
        heff_drop(v_y_247);
        v_t_2410 = v_x_245;
      }
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = (g_list_2ezipWith_24s1891751394x1524628247_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_246, v_ys_248, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s1891751394x1524628247_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ezipWith_24s1891751394x1524628247(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s183165982x1490920686_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s183165982x1490920686_entry, 1, 0};

V g_list_2ekeepIf_24s183165982x1490920686(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s183165982x1490920686_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s183165982x1490920686_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s183165982x1490920686(a[0]);
}
Clo g_list_2emap_24s1598879313x231311047_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1598879313x231311047_entry, 1, 0};

V g_list_2emap_24s1598879313x231311047(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_RepV), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1598879313x231311047_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1598879313x231311047(a[0]);
}
Clo g_list_2emap_24s1598879313x231311047_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1598879313x231311047_24dps_entry, 2, 0};

V g_list_2emap_24s1598879313x231311047_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_RepV), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1598879313x231311047_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1598879313x231311047_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2010608108x1221393166_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2010608108x1221393166_entry, 1, 0};

V g_list_2emap_24s2010608108x1221393166(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ecompile_2erepr_2ereprOfName(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2010608108x1221393166_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2010608108x1221393166_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2010608108x1221393166(a[0]);
}
Clo g_list_2efoldl_24s728686882x2096535788_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s728686882x2096535788_entry, 3, 0};

V g_list_2efoldl_24s728686882x2096535788(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 2, (V[]){heff_dup(v_lit_240), v_x_243}), v_z_241});
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s728686882x2096535788_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s728686882x2096535788(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1134919403x2060330530_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1134919403x2060330530_entry, 2, 0};

V g_list_2efoldl_24s1134919403x2060330530(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2420;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Merge: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Boxed: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_BoxedWord: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Element: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Unboxed: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Literal: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Wants: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Binds: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Pinned: {
      V v_x_2416 = heff_field(v_x_242, 0);
      v_t_2420 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, heff_dup(v_x_2416), NTAG(TAG_MkUnit)));
      break;
    }
    case TAG_Kept: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Often: {
      v_t_2420 = v_z_240;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2420;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1134919403x2060330530(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s532345456x1351763934_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s532345456x1351763934_entry, 2, 0};

V g_list_2efoldl_24s532345456x1351763934(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_249;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_x_242, 0);
        v_t_249 = heff_dup(v_a_247);
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, v_t_249, NTAG(TAG_MkUnit)));
    } else {
      heff_drop(v_t_246);
      v_t_2410 = v_z_240;
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s532345456x1351763934_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s532345456x1351763934(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s243940296x1179168444_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s243940296x1179168444_entry, 2, 0};

V g_list_2efoldl_24s243940296x1179168444(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), NTAG(TAG_Nil)});
    V v_t_245 = (g_heff_2ecompile_2efacts_2esureW(v_z_240, v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s243940296x1179168444_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s243940296x1179168444(a[0], a[1]);
}
Clo g_list_2efoldl_24s421921225x565177679_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s421921225x565177679_entry, 2, 0};

V g_list_2efoldl_24s421921225x565177679(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_a_246}), v_z_240});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s421921225x565177679(a[0], a[1]);
}
Clo g_list_2emap_24s976303750x321235480_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s976303750x321235480_entry, 1, 0};

V g_list_2emap_24s976303750x321235480(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_Given: {
      V v_e_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_249 = v_e_243;
      break;
    }
    case TAG_GivenU: {
      V v_e_245 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_249 = v_e_245;
      break;
    }
    case TAG_LentVar: {
      V v_x_246 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_249 = heff_tag_n(TAG_RLocal, 1, (V[]){v_x_246});
      break;
    }
    case TAG_LentValue: {
      V v_e_248 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_249 = v_e_248;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s976303750x321235480_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s976303750x321235480_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s976303750x321235480(a[0]);
}
Clo g_list_2eall_24s1465078656x604124530_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1465078656x604124530_entry, 1, 0};

V g_list_2eall_24s1465078656x604124530(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2eowned_2eplainOperand(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1465078656x604124530_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1465078656x604124530(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24s1353477632x1698603588_24dps_str0, 6, "wordLe");
Clo g_list_2emap_24s1353477632x1698603588_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1353477632x1698603588_24dps_entry, 2, 0};

V g_list_2emap_24s1353477632x1698603588_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_RFixU, 2, (V[]){NTAG(TAG_I64), MK_INT(0LL)});
    V v_t_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_x_242}), NTAG(TAG_Nil)});
    V v_t_246 = heff_tag_n(TAG_CondRelU, 2, (V[]){((V)&g_list_2emap_24s1353477632x1698603588_24dps_str0), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_245})});
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1353477632x1698603588_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1353477632x1698603588_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1263350589x621576050_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1263350589x621576050_entry, 1, 0};

V g_list_2emap_24s1263350589x621576050(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_FtFloat: {
      v_t_245 = NTAG(TAG_RepF64);
      break;
    }
    case TAG_FtFixed: {
      V v_w_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24FtFixed = heff_take_reuse_n(v_x_241, 1ULL, 1);
      int64_t v_t_244;
      switch (heff_tag_of(v_w_243)) {
      case TAG_I8: {
        v_t_244 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_244 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_244 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_244 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_244 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_244 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_244 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_244 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_244 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      if ((v_t_244 == ((int64_t)64ULL))) {
        v_t_245 = heff_tag_at_n(v_ru_24x_241_24FtFixed, TAG_RepFix, 1, (V[]){v_w_243});
      } else {
        heff_drop(v_w_243);
        heff_drop_cell(v_ru_24x_241_24FtFixed, 1);
        v_t_245 = NTAG(TAG_RepV);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_245 = NTAG(TAG_RepV);
      break;
    }
    case TAG_FtAny: {
      v_t_245 = NTAG(TAG_RepV);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1263350589x621576050_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1263350589x621576050_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1263350589x621576050(a[0]);
}
Clo g_list_2emap_24s1947501783x1475115781_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1947501783x1475115781_entry, 3, 0};

V g_list_2emap_24s1947501783x1475115781(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_intSub(heff_intSub(heff_dup(v_lit_240), v_x_243), heff_dup(v_lit_241));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1947501783x1475115781_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1947501783x1475115781_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1947501783x1475115781(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_24dps_str0, 5, "(0 - ");
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_24dps_str1, 1, ")");
Clo g_list_2emap_24s1181937096x2120532116_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1181937096x2120532116_24dps_entry, 2, 0};

V g_list_2emap_24s1181937096x2120532116_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    if (heff_intLt_c_lent(v_x_242, MK_INT(0LL), 2)) {
      V v_t_244 = heff_intShow(heff_intSub(MK_INT(0LL), v_x_242));
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s1181937096x2120532116_24dps_str0), heff_strAppend(v_t_244, ((V)&g_list_2emap_24s1181937096x2120532116_24dps_str1)));
    } else {
      v_t_245 = heff_intShow(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1181937096x2120532116_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1181937096x2120532116_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s89567162x1162500052_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s89567162x1162500052_24dps_entry, 8, 0};

V g_list_2emap_24s89567162x1162500052_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      V v_t_2412 = ({ V a_0 = v_a_2410; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_2410); r_; });
      V v_t_2413 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2412, heff_dup(v_lit_243)));
      V v_t_2414 = ({ V a_0 = v_a_2411; V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(a_0)); heff_drop(v_a_2411); r_; });
      V v_t_2415 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2414, heff_dup(v_lit_245)));
      v_t_2416 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2413, v_t_2415));
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s89567162x1162500052_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s89567162x1162500052_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2eall_24s1373454977x2143028054_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1373454977x2143028054_entry, 1, 0};

V g_list_2eall_24s1373454977x2143028054(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1373454977x2143028054_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1373454977x2143028054(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1004873070x1577485130_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1004873070x1577485130_entry, 3, 0};

V g_list_2efoldl_24s1004873070x1577485130(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(heff_dup(v_lit_240), heff_dup(v_x_243), heff_dup(heff_rfield(v_x_243, 2))));
    V v_t_2412;
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_a_248 = v_field_246;
      V v_a_249 = v_field_247;
      V v_t_2410 = ({ V rv_2 = v_a_248; V rr_ = heff_rec_reuse_nf(v_x_243, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_a_249, 0, 2)));
      v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_t_2411});
    }
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2413;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1004873070x1577485130_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1004873070x1577485130(a[0], a[1], a[2]);
}
Clo g_list_2ezipWith_24s1928181476x241816070_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1928181476x241816070_entry, 2, 0};

V g_list_2ezipWith_24s1928181476x241816070(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_x_242, heff_tag_n(TAG_EVar, 1, (V[]){v_y_244})});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s1928181476x241816070_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1928181476x241816070_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1928181476x241816070(a[0], a[1]);
}
Clo g_list_2emap_24s500386242x1746840051_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s500386242x1746840051_entry, 1, 0};

V g_list_2emap_24s500386242x1746840051(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eunbox_2eslotsOf(heff_dup(v_x_241)));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_def__slots, (V[]){v_x_241, v_t_243}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s500386242x1746840051_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s500386242x1746840051_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s500386242x1746840051(a[0]);
}
Clo g_list_2efoldl_24s319398146x1205310166_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s319398146x1205310166_entry, 4, 0};

V g_list_2efoldl_24s319398146x1205310166(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_heff_2ecompile_2eworker_2ehopeOne(heff_dup(v_lit_240), heff_dup(v_lit_241), v_z_242, v_x_244));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_246;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s319398146x1205310166_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s319398146x1205310166(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2emap_24s510639937x1058700299_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s510639937x1058700299_entry, 1, 0};

V g_list_2emap_24s510639937x1058700299(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 3, 5), heff_hole()});
    V v_u_244 = (g_list_2emap_24s510639937x1058700299_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s510639937x1058700299_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s510639937x1058700299(a[0]);
}
Clo g_list_2efoldl_24s1579438642x567671990_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1579438642x567671990_entry, 5, 0};

V g_list_2efoldl_24s1579438642x567671990(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_244, 0);
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_t_247 = (g_heff_2ecompile_2elower_2epieceStep(heff_dup(v_lit_240), v_lit_241, heff_dup(v_lit_242), v_z_243, heff_dup(v_x_245)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_247;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s1579438642x567671990_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_list_2efoldl_24s1579438642x567671990(a[0], a1, a[2], a[3], a4); heff_drop(a1); heff_drop(a4); return r;
}
Clo g_list_2emap_24s357242026x384251201_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s357242026x384251201_24dps_entry, 2, 0};

V g_list_2emap_24s357242026x384251201_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s357242026x384251201_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s357242026x384251201_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1146729723x1441207893_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1146729723x1441207893_entry, 3, 0};

V g_list_2emap_24s1146729723x1441207893(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_x_243, heff_dup(v_lit_241)));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1146729723x1441207893_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1146729723x1441207893_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1146729723x1441207893(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1483820613x1826490246_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1483820613x1826490246_entry, 2, 0};

V g_list_2efoldl_24s1483820613x1826490246(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 1)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1483820613x1826490246_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1483820613x1826490246(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s766426360x2144213627_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s766426360x2144213627_24dps_entry, 10, 0};

V g_list_2emap_24s766426360x2144213627_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_x2_248, V v_d_249) {
top: ;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_249, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_248, 0);
    V v_xs_2411 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24Cons = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2412 = (g_heff_2ecompile_2eemitc_2emodulePart(heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_x_2410));
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_248_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_249, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_xs_2411;
    V t_9 = v_cell_2413;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_x2_248 = t_8;
    v_d_249 = t_9;
    goto top;
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_list_2emap_24s766426360x2144213627_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2emap_24s766426360x2144213627_24dps(a[0], a[1], a2, a3, a4, a5, a6, a7, a[8], a[9]); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); return r;
}
Clo g_list_2efoldl_24s1917169677x762627694_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1917169677x762627694_entry, 2, 0};

V g_list_2efoldl_24s1917169677x762627694(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_242, 0));
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_list_2emap_24s1937570095x2110149801(heff_get_n(v_t_2412, 2, 3)));
    V v_t_2414 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_t_249, 1, 3), v_t_2413});
    V v_t_2415 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, heff_get_n(v_t_246, 0, 3), v_t_2414));
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1917169677x762627694_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1917169677x762627694(a[0], a[1]);
}
Clo g_list_2efoldl_24s788343806x1528994845_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s788343806x1528994845_entry, 3, 0};

V g_list_2efoldl_24s788343806x1528994845(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2ebackcache_2eaddEmit(heff_dup(v_lit_240), v_z_241, v_x_243));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s788343806x1528994845_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s788343806x1528994845(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s939813003x1383013550_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s939813003x1383013550_entry, 1, 0};

V g_list_2emap_24s939813003x1383013550(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(v_x_241, 2, 5);
    V v_t_248;
    switch (heff_tag_of(v_t_243)) {
    case TAG_SizeDefault: {
      v_t_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeNumber: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_t_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeName: {
      V v_x_245 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 3);
      v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){v_x_245});
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s939813003x1383013550_24dps(v_xs_242, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s939813003x1383013550(a[0]);
}
Clo g_list_2efoldl_24s1437740164x269163243_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1437740164x269163243_entry, 2, 0};

V g_list_2efoldl_24s1437740164x269163243(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1437740164x269163243_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1437740164x269163243(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s584558070x895760461_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s584558070x895760461_24dps_entry, 3, 0};

V g_list_2emap_24s584558070x895760461_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2eelab_2eclauses_2erenameEquation(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s584558070x895760461_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s584558070x895760461_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1134745827x519521524_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1134745827x519521524_24dps_entry, 2, 0};

V g_list_2emap_24s1134745827x519521524_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_ty_244 = heff_take_field(v_x_242, 1);
    V v_size_245 = heff_get_n(v_x_242, 2, 5);
    V v_t_246 = ({ V a_0 = v_ty_244; V a_1 = v_size_245; V r_ = (g_heff_2esyntax_2epresyntax_2esegmentOdd(a_0, a_1)); heff_drop(v_ty_244); heff_drop(v_size_245); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1134745827x519521524_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1134745827x519521524_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s796727596x829078925_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s796727596x829078925_entry, 1, 0};

V g_list_2emap_24s796727596x829078925(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s796727596x829078925_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s796727596x829078925_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s796727596x829078925(a[0]);
}
HEFF_LIT(g_list_2emap_24s1534167768x1221742344_24dps_str0, 56, "only the library that goes with heff declares primitives");
Clo g_list_2emap_24s1534167768x1221742344_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1534167768x1221742344_24dps_entry, 2, 0};

V g_list_2emap_24s1534167768x1221742344_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_sp_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(335LL), NTAG(TAG_SError), ((V)&g_list_2emap_24s1534167768x1221742344_24dps_str0), v_sp_245, NTAG(TAG_Nothing)});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1534167768x1221742344_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1534167768x1221742344_24dps(a[0], a[1]);
}

HeffT2 g_list_2efind_24s1327702553x1694210434_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 14);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s2031248677x950202423_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2031248677x950202423_entry, 2, 0};

V g_list_2efoldl_24s2031248677x950202423(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b_24f1537904782x516751275(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2031248677x950202423(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s2000102784x314586828_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2000102784x314586828_24dps_entry, 2, 0};

V g_list_2emap_24s2000102784x314586828_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x11_244, 0);
        V v_sp_247 = heff_field(v_x11_244, 1);
        heff_take_n(v_x11_244, 3ULL, 4);
        v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_246, v_sp_247})});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2411 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2412;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2000102784x314586828_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2000102784x314586828_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_24dps_str0, 5, "-- | ");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_24dps_str1, 4, "-- |");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_24dps_str2, 0, "");
Clo g_list_2emap_24s1819241345x1511673126_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1819241345x1511673126_24dps_entry, 2, 0};

V g_list_2emap_24s1819241345x1511673126_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    if (heff_strEq_c(heff_strSlice_lent(v_x_242, MK_INT(0LL), MK_INT(5LL), 6), ((V)&g_list_2emap_24s1819241345x1511673126_24dps_str0))) {
      V v_t_244 = heff_strSlice(heff_dup(v_x_242), MK_INT(5LL), heff_strLength(v_x_242));
      v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    } else {
      if (heff_strEq_c(v_x_242, ((V)&g_list_2emap_24s1819241345x1511673126_24dps_str1))) {
        v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_list_2emap_24s1819241345x1511673126_24dps_str2)});
      } else {
        v_t_245 = NTAG(TAG_Nothing);
      }
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1819241345x1511673126_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1819241345x1511673126_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s2134067310x2049132013_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2134067310x2049132013_entry, 2, 0};

V g_list_2efoldl_24s2134067310x2049132013(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2134067310x2049132013(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s759871588x920431471_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s759871588x920431471_entry, 1, 0};

V g_list_2emap_24s759871588x920431471(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 9), heff_hole()});
    V v_u_244 = (g_list_2emap_24s759871588x920431471_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s759871588x920431471_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s759871588x920431471(a[0]);
}
Clo g_list_2emap_24s1816200867x1876638332_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1816200867x1876638332_24dps_entry, 2, 0};

V g_list_2emap_24s1816200867x1876638332_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1816200867x1876638332_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1816200867x1876638332_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s135291903x1031656159_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s135291903x1031656159_entry, 2, 0};

V g_list_2emap_24s135291903x1031656159(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2efieldDeclKey(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s135291903x1031656159_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s135291903x1031656159_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s135291903x1031656159(a[0], a[1]);
}
Clo g_list_2emap_24s179832492x431904054_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s179832492x431904054_entry, 1, 0};

V g_list_2emap_24s179832492x431904054(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 5), heff_hole()});
    V v_u_244 = (g_list_2emap_24s179832492x431904054_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s179832492x431904054_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s179832492x431904054(a[0]);
}
Clo g_list_2esortBy_24s735547525x1777295590_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s735547525x1777295590_entry, 1, 0};

V g_list_2esortBy_24s735547525x1777295590(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_xs_240)) {
      case TAG_Cons: {
        V v_x_243 = heff_field(v_xs_240, 0);
        V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 1ULL, 2);
        return heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_xs_240);
      }
    }
    case TAG_Cons: {
      V v_ru_24xs2_242_24Cons = heff_take_reuse_n(v_xs2_242, 0ULL, 2);
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_248 = (g_list_2etake(heff_intDiv(v_t_247, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_249 = (g_list_2esortBy_24s735547525x1777295590(v_t_248));
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2411 = ({ V a_0 = heff_intDiv(v_t_2410, MK_INT(2LL)); V a_1 = v_xs_240; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop_tag(v_xs_240, 2); r_; });
      V v_t_2412 = (g_list_2esortBy_24s735547525x1777295590(v_t_2411));
      return (g_list_2emerge_24s275559350x890699445_24tok2(v_ru_24xs2_242_24Cons, v_t_249, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s735547525x1777295590_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s735547525x1777295590(a[0]);
}
Clo g_list_2eall_24s1432467604x1830816726_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1432467604x1830816726_entry, 6, 0};

V g_list_2eall_24s1432467604x1830816726(V v_lit_240, V v_box_24lit_241, V v_box_24lit_242, V v_box_24lit_243, V v_box_24lit_244, V v_x2_245) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
  int64_t v_lit_242 = heff_unbox_word(v_box_24lit_242);
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_244 = heff_unbox_word(v_box_24lit_244);
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_a_248 = heff_strByteAt_lent(v_lit_240, v_x_246, 0);
    if ((((v_lit_241 <= heff_peek_word(v_a_248)) && (heff_peek_word(v_a_248) <= v_lit_242)) || ((v_lit_243 <= heff_peek_word(v_a_248)) && (heff_peek_word(v_a_248) <= v_lit_244)))) {
      heff_drop(v_a_248);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      int64_t t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      int64_t t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    } else {
      heff_drop(v_a_248);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2eall_24s1432467604x1830816726_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a5 = a[5]; V r = g_list_2eall_24s1432467604x1830816726(a0, a[1], a[2], a[3], a[4], a5); heff_drop(a0); heff_drop(a5); return r;
}
Clo g_list_2ezipWith_24s29557946x653938035_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s29557946x653938035_entry, 2, 0};

V g_list_2ezipWith_24s29557946x653938035(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_244, 1, 3), v_x_242});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s29557946x653938035_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s29557946x653938035_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s29557946x653938035(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s25507577x707942422_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s25507577x707942422_entry, 3, 0};

V g_list_2ekeepIf_24s25507577x707942422(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240)) && heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_241)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = (g_list_2ekeepIf_24s25507577x707942422_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s25507577x707942422_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s25507577x707942422(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s18996220x10511024_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s18996220x10511024_entry, 1, 0};

V g_list_2emap_24s18996220x10511024(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_243 = heff_take_field(v_x_241, 0);
    V v_path_244 = heff_get_n(v_x_241, 1, 3);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_243, v_path_244}), heff_hole()});
    V v_u_246 = (g_list_2emap_24s18996220x10511024_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s18996220x10511024_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s18996220x10511024(a[0]);
}

HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_246, v_lit_240, 1)) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop(v_x_242);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2eall_24s442836260x1032582242_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s442836260x1032582242_entry, 11, 0};

V g_list_2eall_24s442836260x1032582242(V v_lit_240, V v_box_24lit_241, V v_box_24lit_242, V v_box_24lit_243, V v_box_24lit_244, V v_box_24lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_box_24lit_248, V v_box_24lit_249, V v_x2_2410) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
  int64_t v_lit_242 = heff_unbox_word(v_box_24lit_242);
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_244 = heff_unbox_word(v_box_24lit_244);
  int64_t v_lit_245 = heff_unbox_word(v_box_24lit_245);
  int64_t v_lit_246 = heff_unbox_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_unbox_word(v_box_24lit_247);
  int64_t v_lit_248 = heff_unbox_word(v_box_24lit_248);
  int64_t v_lit_249 = heff_unbox_word(v_box_24lit_249);
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    V v_a_2413 = heff_strByteAt_lent(v_lit_240, v_x_2411, 0);
    if ((((v_lit_241 <= heff_peek_word(v_a_2413)) && (heff_peek_word(v_a_2413) <= v_lit_242)) || (((v_lit_243 <= heff_peek_word(v_a_2413)) && (heff_peek_word(v_a_2413) <= v_lit_244)) || (((v_lit_245 <= heff_peek_word(v_a_2413)) && (heff_peek_word(v_a_2413) <= v_lit_246)) || ((heff_peek_word(v_a_2413) == v_lit_247) || ((heff_peek_word(v_a_2413) == v_lit_248) || (heff_peek_word(v_a_2413) == v_lit_249))))))) {
      heff_drop(v_a_2413);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      int64_t t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      int64_t t_4 = v_lit_244;
      int64_t t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      int64_t t_8 = v_lit_248;
      int64_t t_9 = v_lit_249;
      V t_10 = v_xs_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_x2_2410 = t_10;
      goto top;
    } else {
      heff_drop(v_a_2413);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2eall_24s442836260x1032582242_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a10 = a[10]; V r = g_list_2eall_24s442836260x1032582242(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a10); heff_drop(a0); heff_drop(a10); return r;
}
Clo g_list_2emap_24s2015709068x2065046486_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2015709068x2065046486_entry, 7, 0};

V g_list_2emap_24s2015709068x2065046486(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2412 = heff_tag_n(TAG_FailBecause, 1, (V[]){heff_strAppend(heff_dup(v_lit_243), heff_dup(v_lit_244))});
    V v_t_2413 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_t_2411, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_tag_n(TAG_Just, 1, (V[]){v_t_2412}), heff_dup(v_lit_245), NTAG(TAG_Nil)});
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = (g_list_2emap_24s2015709068x2065046486_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s2015709068x2065046486_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2015709068x2065046486(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2efoldl_24s417343796x227886918_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s417343796x227886918_entry, 3, 0};

V g_list_2efoldl_24s417343796x227886918(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2ecommands_2enewerTagged(heff_dup(v_lit_240), v_z_241, v_x_243));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s417343796x227886918_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s417343796x227886918(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1193924222x1531824795_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1193924222x1531824795_entry, 3, 0};

V g_list_2emap_24s1193924222x1531824795(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_240))) {
      v_t_245 = ({ V rv_1 = heff_dup(v_lit_240); V rv_2 = heff_dup(v_lit_241); V rr_ = heff_rec_reuse_nf(v_x_243, 1ULL, 3, shape_name__path__version, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    } else {
      v_t_245 = v_x_243;
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1193924222x1531824795_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1193924222x1531824795_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1193924222x1531824795(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s849938259x51049885_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_24dps_str3, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_24dps_str4, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s849938259x51049885_24dps_str6, 0, "");
Clo g_list_2emap_24s849938259x51049885_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s849938259x51049885_24dps_entry, 2, 0};

V g_list_2emap_24s849938259x51049885_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_JNull: {
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JArray: {
      V v_ns_248 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = (g_list_2emap_24s1767134203x962737276(((V)&g_list_2emap_24s849938259x51049885_24dps_str0), ((V)&g_list_2emap_24s849938259x51049885_24dps_str1), ((V)&g_list_2emap_24s849938259x51049885_24dps_str2), ((V)&g_list_2emap_24s849938259x51049885_24dps_str3), ((V)&g_list_2emap_24s849938259x51049885_24dps_str4), ((V)&g_list_2emap_24s849938259x51049885_24dps_str5), ((V)&g_list_2emap_24s849938259x51049885_24dps_str6), v_ns_248));
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s849938259x51049885_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s849938259x51049885_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1387309293x1990579214_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1387309293x1990579214_24dps_entry, 2, 0};

V g_list_2emap_24s1387309293x1990579214_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 4);
        v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2411 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2412;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1387309293x1990579214_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1387309293x1990579214_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s2051016282x1892781518_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2051016282x1892781518_entry, 4, 0};

V g_list_2efoldl_24s2051016282x1892781518(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_244, 2)), 0, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_244, 2)), 1, 2);
    V v_t_248 = heff_strSlice(heff_dup(v_z_242), v_t_247, heff_strLength_lent(v_z_242, 0));
    V v_t_249 = heff_strAppend(heff_strSlice_lent(v_z_242, v_lit_240, v_t_246, 5), heff_strAppend(heff_dup(v_lit_241), v_t_248));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_249;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s2051016282x1892781518_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_list_2efoldl_24s2051016282x1892781518(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}
Clo g_list_2emap_24s1854779998x1713580578_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1854779998x1713580578_24dps_entry, 2, 0};

V g_list_2emap_24s1854779998x1713580578_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 8), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1854779998x1713580578_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1854779998x1713580578_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s296585291x885335139_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s296585291x885335139_entry, 1, 0};

V g_list_2emap_24s296585291x885335139(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eheadOf(heff_dup(v_x_241)));
    V v_t_244 = (g_std_2ecli_2eline2(v_t_243, heff_get_n(v_x_241, 1, 4)));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s296585291x885335139_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s296585291x885335139_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s296585291x885335139(a[0]);
}
Clo g_list_2emap_24s1531382666x123921537_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1531382666x123921537_entry, 1, 0};

V g_list_2emap_24s1531382666x123921537(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_243 = heff_take_field(v_x_241, 0);
    V v_doc_244 = heff_take_field(v_x_241, 1);
    V v_args_245 = heff_get_n(v_x_241, 3, 4);
    V v_t_246 = heff_tr(heff_call(v_args_245, 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_t_247 = heff_rec_n(3, shape_name__doc__shape, (V[]){v_name_243, v_doc_244, heff_get_n(v_t_246, 0, 2)});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s1531382666x123921537_24dps(v_xs_242, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1531382666x123921537_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1531382666x123921537(a[0]);
}
HEFF_LIT(g_list_2emap_24s1539380703x380520933_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1539380703x380520933_str1, 0, "");
Clo g_list_2emap_24s1539380703x380520933_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1539380703x380520933_entry, 1, 0};

V g_list_2emap_24s1539380703x380520933(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_list_2emap_24s1539380703x380520933_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_244 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_list_2emap_24s1539380703x380520933_str1)), v_t_243});
    V v_t_245 = heff_rec_n(2, shape_part__input, (V[]){heff_tag_n(TAG_Positional, 1, (V[]){v_x_241}), heff_tag_n(TAG_Typed, 1, (V[]){v_t_244})});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1539380703x380520933_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1539380703x380520933_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1539380703x380520933(a[0]);
}
Clo g_list_2eany_24s317268364x1703376737_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s317268364x1703376737_entry, 1, 0};

V g_list_2eany_24s317268364x1703376737(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if (((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_x_241, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_x_241, MK_INT(0LL), 2)) == ((int64_t)45ULL)))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s317268364x1703376737_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s317268364x1703376737(a0); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s1252894891x837498180_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1252894891x837498180_entry, 4, 0};

V g_list_2ekeepIf_24s1252894891x837498180(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_241, 6);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 2)), 0, 2);
    V v_t_247 = heff_strFind(heff_strOfRunes(v_t_246), heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_242));
    if (heff_intLe_c_lent(v_lit_240, v_t_247, 2)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = (g_list_2ekeepIf_24s1252894891x837498180_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop_rec(v_x_244, 3);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s1252894891x837498180_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ekeepIf_24s1252894891x837498180(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1744384903x906515519_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1744384903x906515519_entry, 1, 0};

V g_list_2emap_24f1744384903x906515519(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Left: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Right: {
      V v_x_244 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_name_245 = heff_take_field(v_x_244, 0);
      V v_span_246 = heff_take_field(v_x_244, 1);
      V v_ty_247 = heff_take_field(v_x_244, 2);
      V v_whole_248 = heff_get_n(v_x_244, 4, 5);
      V v_t_249 = heff_tag_n(TAG_DeclareField, 4, (V[]){v_name_245, v_span_246, v_ty_247, NTAG(TAG_Nothing)});
      V v_cell_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_whole_248}), heff_hole()});
      V v_u_2411 = (g_list_2emap_24f1744384903x906515519_24dps(v_rest_242, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2emap_24f1744384903x906515519_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1744384903x906515519(a[0]);
}
Clo g_list_2emap_24f1952774010x636070089_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1952774010x636070089_entry, 9, 0};

V g_list_2emap_24f1952774010x636070089(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_x2_248) {
top: ;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24Cons = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    if (!heff_strEq_c(heff_strSlice_lent(v_x_249, v_lit_245, v_lit_246, 0), heff_dup(v_lit_247))) {
      V v_t_2412;
      if (heff_strEq_c(heff_strSlice_lent(v_x_249, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
        V v_t_2411 = heff_strSlice(heff_dup(v_x_249), heff_dup(v_lit_244), heff_strLength(v_x_249));
        v_t_2412 = heff_strAppend(heff_dup(v_lit_243), v_t_2411);
      } else {
        v_t_2412 = v_x_249;
      }
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_248_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
      V v_u_2414 = (g_list_2emap_24f1952774010x636070089_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_xs_2410, heff_dup(v_cell_2413)));
      heff_drop(v_u_2414);
      return v_cell_2413;
    } else {
      heff_drop(v_x_249);
      heff_drop_cell(v_ru_24x2_248_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_xs_2410;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_x2_248 = t_8;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_list_2emap_24f1952774010x636070089_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2emap_24f1952774010x636070089(a0, a1, a2, a[3], a4, a5, a6, a7, a[8]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); return r;
}
Clo g_list_2efoldl_24f1323813142x1311067101_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1323813142x1311067101_entry, 4, 0};

V g_list_2efoldl_24f1323813142x1311067101(V v_lit_240, V v_z_241, V v_p_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_p_242), 1, (V[]){heff_dup(v_x_244)}));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_p_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_p_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_p_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_p_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1323813142x1311067101_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f1323813142x1311067101(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f891411706x655200538_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f891411706x655200538_entry, 2, 0};

V g_list_2efoldl_24f891411706x655200538(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x_247 = heff_get_n(v_t_246, 2, 3);
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f891411706x655200538_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f891411706x655200538(a[0], a[1]);
}
Clo g_list_2emap_24f669780424x1745768631_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f669780424x1745768631_24dps_entry, 6, 0};

V g_list_2emap_24f669780424x1745768631_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop(v_lit_241);
    heff_drop(v_lit_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_x_2410;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_246, 0);
      heff_take_n(v_x_246, 1ULL, 2);
      v_x_2410 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_a_2411 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_lit_241));
    V v_t_2412 = heff_strSlice(heff_dup(v_x_2410), heff_dup(v_lit_242), heff_strLength_lent(v_a_2411, 0));
    V v_t_2416;
    if (heff_strEq_c(v_t_2412, v_a_2411)) {
      V v_t_2413 = heff_strLength(heff_dup(heff_rfield(v_lit_240, 0)));
      V v_t_2414 = heff_strSlice(heff_dup(v_x_2410), heff_intAdd(v_t_2413, heff_dup(v_lit_243)), heff_strLength_lent(v_x_2410, 0));
      V v_t_2415 = heff_rec_n(3, shape_name__key__module, (V[]){v_t_2414, v_x_2410, heff_dup(heff_rfield(v_lit_240, 0))});
      v_t_2416 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
    } else {
      heff_drop(v_x_2410);
      v_t_2416 = NTAG(TAG_Nothing);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_xs_247;
    V t_5 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_x2_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f669780424x1745768631_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24f669780424x1745768631_24dps(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
Clo g_list_2emap_24f922554743x1845028609_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f922554743x1845028609_24dps_entry, 3, 0};

V g_list_2emap_24f922554743x1845028609_24dps(V v_p_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_243, 2, 3), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f922554743x1845028609_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f922554743x1845028609_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f1564248594x622634626_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1564248594x622634626_entry, 3, 0};

V g_list_2efoldl_24f1564248594x622634626(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if (!(heff_dup(heff_rfield(v_x_243, 1)) == NTAG(TAG_True))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1564248594x622634626_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1564248594x622634626(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps_entry, 5, 0};

V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_shown_247 = heff_take_field(v_x_245, 2);
    V v_name_248 = heff_get_n(v_x_245, 0, 4);
    if ((heff_dup(v_shown_247) == NTAG(TAG_True))) {
      heff_drop(v_shown_247);
      V v_x_249 = v_name_248;
      V v_t_2410 = heff_strSlice(heff_dup(v_x_249), heff_dup(v_lit_241), heff_strLength_lent(v_lit_242, 0));
      if (heff_strEq_c_lent(v_t_2410, v_lit_242, 1)) {
        V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_249, heff_dup(v_lit_240)), heff_hole()});
        V v_u_2412 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2411));
        heff_drop(v_u_2412);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_cell_2411;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        v_d_244 = t_4;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        heff_drop(v_x_249);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_d_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_shown_247);
      heff_drop(v_name_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_24dps(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24f310588246x1624488069_24dps_str0, 8, "browser.");
Clo g_list_2emap_24f310588246x1624488069_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f310588246x1624488069_24dps_entry, 5, 0};

V g_list_2emap_24f310588246x1624488069_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_library_247 = heff_take_field(v_x_245, 7);
    V v_module_248 = heff_get_n(v_x_245, 0, 8);
    if (((heff_dup(v_library_247) == NTAG(TAG_True)) && heff_strEq_c(heff_strSlice_lent(v_module_248, MK_INT(0LL), MK_INT(8LL), 6), ((V)&g_list_2emap_24f310588246x1624488069_24dps_str0)))) {
      heff_drop(v_library_247);
      V v_t_249 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_dup(v_module_248), heff_dup(v_lit_242)));
      V v_t_2410 = heff_rec_n(4, shape_module__code__msg__note, (V[]){v_module_248, heff_dup(v_lit_240), v_t_249, NTAG(TAG_Nothing)});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_2411;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_library_247);
      heff_drop(v_module_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f310588246x1624488069_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f310588246x1624488069_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2ekeepIf_24f1622709115x782387749_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f1622709115x782387749_24dps_entry, 3, 0};

V g_list_2ekeepIf_24f1622709115x782387749_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = (g_list_2ekeepIf_24s44384897x1267641110(v_ys_241));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_243);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_x_244, 2));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_245;
      V t_1 = v_ys_241;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_xs_245;
      V t_1 = v_ys_241;
      V t_2 = v_d_242;
      v_x1_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2ekeepIf_24f1622709115x782387749_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24f1622709115x782387749_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1173914895x100384474_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1173914895x100384474_24tok2_entry, 2, 0};

V g_list_2emap_24s1173914895x100384474_24tok2(V v_tok_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1173914895x100384474_24dps(v_xs_243, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1173914895x100384474_24tok2(a[0], a[1]);
}
Clo g_list_2emap_24s1460603830x671758883_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1460603830x671758883_24tok1_entry, 3, 0};

V g_list_2emap_24s1460603830x671758883_24tok1(V v_tok_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_EStr, 1, (V[]){heff_dup(v_lit_241)}), heff_hole()});
    V v_u_246 = (g_list_2emap_24s1460603830x671758883_24dps(v_lit_241, v_xs_244, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1460603830x671758883_24tok1_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1460603830x671758883_24tok1(a[0], a[1], a[2]);
}
Clo g_list_2emerge_24s2030620912x751826577_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s2030620912x751826577_24tok2_entry, 3, 0};

V g_list_2emerge_24s2030620912x751826577_24tok2(V v_tok_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_x3_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_241, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop_rec(v_x_243, 2);
      heff_drop(v_xs_244);
      return v_x2_241;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_y_245, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s2030620912x751826577_24dps(v_xs_244, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_245, v_ys_246}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        V v_cell_249 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s2030620912x751826577_24dps(heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_xs_244}), v_ys_246, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_24s2030620912x751826577_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s2030620912x751826577_24tok2(a[0], a[1], a[2]);
}