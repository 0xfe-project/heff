// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236(V, V, V, V);
V g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236_entry(V self, V *a);
extern Clo g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236_clo;
V g_prelude_2ewithCodePoint(V, V);
V g_prelude_2ewithCodePoint_entry(V self, V *a);
extern Clo g_prelude_2ewithCodePoint_clo;
Clo g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236_entry, 4, 0};

V g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236(V v_lit_240, V v_s_241, V v_i_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(heff_strLength_lent(v_s_241, 0), v_i_242, 1)) {
    heff_drop(v_lit_240);
    heff_drop(v_i_242);
    return v_acc_243;
  } else {
    HeffT2 v_t_244 = heff_strRuneDecode_lent(v_s_241, v_i_242, 0);
    {
      V v_rune_245 = v_t_244.f[0];
      V v_width_246 = v_t_244.f[1];
      V v_t_248;
      if ((((heff_runeLe_c(MK_INT(65LL), heff_dup(v_rune_245)) && heff_runeLe_c(heff_dup(v_rune_245), MK_INT(90LL))) || (heff_runeLe_c(MK_INT(97LL), heff_dup(v_rune_245)) && heff_runeLe_c(heff_dup(v_rune_245), MK_INT(122LL)))) || (heff_runeLe_c(MK_INT(48LL), heff_dup(v_rune_245)) && heff_runeLe_c(heff_dup(v_rune_245), MK_INT(57LL))))) {
        if ((heff_runeLe_c(MK_INT(97LL), heff_dup(v_rune_245)) && heff_runeLe_c(heff_dup(v_rune_245), MK_INT(122LL)))) {
          V v_t_247 = heff_intSub(heff_runeToInt(v_rune_245), heff_dup(v_lit_240));
          v_t_248 = heff_runeFromInt(v_t_247);
        } else {
          v_t_248 = v_rune_245;
        }
      } else {
        heff_drop(v_rune_245);
        v_t_248 = MK_INT(95LL);
      }
      V v_t_249 = (g_prelude_2ewithCodePoint(v_acc_243, heff_runeToInt(v_t_248)));
      V v_t_2410 = heff_intAdd(v_i_242, v_width_246);
      V t_0 = v_lit_240;
      V t_1 = v_s_241;
      V t_2 = v_t_2410;
      V t_3 = v_t_249;
      v_lit_240 = t_0;
      v_s_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}