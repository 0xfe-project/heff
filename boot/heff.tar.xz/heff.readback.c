// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"

static V g_heff_2ereadback_2earrayEmpty_val;
static int g_heff_2ereadback_2earrayEmpty_st;
static V g_heff_2ereadback_2earrayEmpty_init(void) {
  return heff_dup(g_array_2eempty_get());
}
V g_heff_2ereadback_2earrayEmpty_get(void) {
  if (g_heff_2ereadback_2earrayEmpty_st == 2) return g_heff_2ereadback_2earrayEmpty_val;
  if (g_heff_2ereadback_2earrayEmpty_st == 1) heff_fail("defined by itself");
  g_heff_2ereadback_2earrayEmpty_st = 1;
  g_heff_2ereadback_2earrayEmpty_val = heff_tr(g_heff_2ereadback_2earrayEmpty_init());
  g_heff_2ereadback_2earrayEmpty_st = 2;
  return g_heff_2ereadback_2earrayEmpty_val;
}
Clo g_heff_2ereadback_2elocalArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2elocalArgs_entry, 1, 0};

V g_heff_2ereadback_2elocalArgs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return heff_tag(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_SpApp: {
    V v_sp_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_VNeu: {
      V v_x121_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      heff_take_n(v_x12_242, 3ULL, 5);
      switch (heff_tag_of(v_x121_243)) {
      case TAG_HLocal: {
        V v_l_248 = heff_field(v_x121_243, 0);
        V v_ru_24x121_243_24HLocal = heff_take_reuse_n(v_x121_243, 1ULL, 1);
        switch (heff_tag_of(v_x122_244)) {
        case TAG_SpId: {
          V v_x2_249 = (g_heff_2ereadback_2elocalArgs(v_sp_241));
          switch (heff_tag_of(v_x2_249)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
            heff_drop(v_l_248);
            heff_drop_cell(v_ru_24x121_243_24HLocal, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_xs_2410 = heff_field(v_x2_249, 0);
            heff_take_n(v_x2_249, 1ULL, 1);
            return heff_tag_at(v_ru_24x121_243_24HLocal, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_l_248, v_xs_2410})});
          }
          default: return heff_nomatch(v_x2_249);
          }
        }
        case TAG_SpApp: {
          heff_take_n(v_x122_244, 0ULL, 2);
          heff_drop(v_sp_241);
          heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
          heff_drop(v_l_248);
          heff_drop_cell(v_ru_24x121_243_24HLocal, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpProj: {
          heff_take_n(v_x122_244, 0ULL, 2);
          heff_drop(v_sp_241);
          heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
          heff_drop(v_l_248);
          heff_drop_cell(v_ru_24x121_243_24HLocal, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpSpec: {
          heff_take_n(v_x122_244, 0ULL, 3);
          heff_drop(v_sp_241);
          heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
          heff_drop(v_l_248);
          heff_drop_cell(v_ru_24x121_243_24HLocal, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x122_244);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_x121_243, 0ULL, 1);
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_x122_244);
        return NTAG(TAG_Nothing);
      }
      case TAG_HMeta: {
        heff_take_n(v_x121_243, 0ULL, 1);
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_x122_244);
        return NTAG(TAG_Nothing);
      }
      case TAG_HError: {
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_x122_244);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x121_243);
      }
    }
    case TAG_VCode: {
      heff_take_n(v_x12_242, 0ULL, 1);
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_VLam: {
      heff_take_n(v_x12_242, 0ULL, 2);
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x12_242, 0ULL, 1);
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_VOpaque: {
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  case TAG_SpProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SpSpec: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ereadback_2elocalArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2elocalArgs(a[0]);
}
Clo g_heff_2ereadback_2ereadbSpine_24s180_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbSpine_24s180_entry, 3, 0};

V g_heff_2ereadback_2ereadbSpine_24s180(V v_n_240, V v_x3_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_SpId: {
    heff_drop(v_n_240);
    return v_t_242;
  }
  case TAG_SpApp: {
    V v_sp_243 = heff_field(v_x3_241, 0);
    V v_v_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24SpApp = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ereadback_2ereadbSpine_24s180(heff_dup(v_n_240), v_sp_243, v_t_242));
    return heff_tag_at(v_ru_24x3_241_24SpApp, TAG_SApp, 2, (V[]){v_t_245, (g_heff_2ereadback_2ereadbTermF_24s178(v_n_240, v_v_244))});
  }
  case TAG_SpProj: {
    V v_sp_246 = heff_field(v_x3_241, 0);
    V v_x_247 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24SpProj = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_248 = (g_heff_2ereadback_2ereadbSpine_24s180(v_n_240, v_sp_246, v_t_242));
    return heff_tag_at(v_ru_24x3_241_24SpProj, TAG_SProj, 2, (V[]){v_t_248, v_x_247});
  }
  case TAG_SpSpec: {
    V v_sp_249 = heff_field(v_x3_241, 0);
    V v_x_2410 = heff_field(v_x3_241, 1);
    V v_v_2411 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24SpSpec = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_t_2412 = (g_heff_2ereadback_2ereadbSpine_24s180(heff_dup(v_n_240), v_sp_249, v_t_242));
    return heff_tag_at(v_ru_24x3_241_24SpSpec, TAG_SSpecialize, 3, (V[]){v_t_2412, v_x_2410, (g_heff_2ereadback_2ereadbTermF_24s178(v_n_240, v_v_2411))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ereadback_2ereadbSpine_24s180_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbSpine_24s180(a[0], a[1], a[2]);
}
V g_heff_2ereadback_2ereadbBare_24s179_lam0(V self, V *args);
Clo g_heff_2ereadback_2ereadbBare_24s179_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbBare_24s179_entry, 3, 0};

V g_heff_2ereadback_2ereadbBare_24s179(V v_n_240, V v_h_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_HLocal: {
    V v_t_249;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_244 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_245 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_244), MK_INT(1LL));
      v_t_249 = heff_tag_at(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_245});
      break;
    }
    case TAG_HGlobal: {
      V v_x_246 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_249 = heff_tag_at(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_246});
      break;
    }
    case TAG_HMeta: {
      V v_m_247 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_248 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_249 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_247, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_248});
      break;
    }
    case TAG_HError: {
      v_t_249 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s180(v_n_240, v_sp_242, v_t_249);
  }
  case TAG_HGlobal: {
    V v_t_2416;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2411 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2412 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_2411), MK_INT(1LL));
      v_t_2416 = heff_tag_at(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2413 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2416 = heff_tag_at(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2413});
      break;
    }
    case TAG_HMeta: {
      V v_m_2414 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2415 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2416 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2414, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2415});
      break;
    }
    case TAG_HError: {
      v_t_2416 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s180(v_n_240, v_sp_242, v_t_2416);
  }
  case TAG_HMeta: {
    V v_m_2417 = heff_field(v_h_241, 0);
    V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
    V v_t_2418 = (g_heff_2ereadback_2elocalArgs(heff_dup(v_sp_242)));
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      V v_t_2419 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s180(v_n_240, v_sp_242, heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2419}));
    }
    case TAG_Just: {
      V v_idxs_2420 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      heff_drop(v_sp_242);
      V v_t_2421 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_idxs_2420));
      V v_t_2423 = (g_prelude_2emap(heff_clo(g_heff_2ereadback_2ereadbBare_24s179_lam0, 1, 1, (V[]){v_n_240}), v_t_2421));
      V v_t_2424 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      return heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_arrayFromList(v_t_2423), v_t_2424});
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  case TAG_HError: {
    V v_t_2430;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2425 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2426 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_2425), MK_INT(1LL));
      v_t_2430 = heff_tag_at(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2426});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2427 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2430 = heff_tag_at(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2427});
      break;
    }
    case TAG_HMeta: {
      V v_m_2428 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2429 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2430 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2428, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2429});
      break;
    }
    case TAG_HError: {
      v_t_2430 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s180(v_n_240, v_sp_242, v_t_2430);
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2ereadback_2ereadbBare_24s179_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbBare_24s179(a[0], a[1], a[2]);
}
V g_heff_2ereadback_2ereadbBare_24s179_lam0(V self, V *args) {
  V v_l_2422 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intSub(heff_intSub(v_n_240, v_l_2422), MK_INT(1LL));
}
V g_heff_2ereadback_2ereadbCloEl_24s181_lam0(V self, V *args);
V g_heff_2ereadback_2ereadbCloEl_24s181_lam1(V self, V *args);
Clo g_heff_2ereadback_2ereadbCloEl_24s181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbCloEl_24s181_entry, 3, 0};

V g_heff_2ereadback_2ereadbCloEl_24s181(V v_n_240, V v_dom_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkClo: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_l_244 = heff_field(v_x4_242, 1);
    V v_f_245 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_n_246 = heff_intAdd(heff_dup(v_n_240), MK_INT(1LL));
    V v_v_248 = (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo(g_heff_2ereadback_2ereadbCloEl_24s181_lam0, 1, 1, (V[]){v_dom_241}), NTAG(TAG_Nothing)));
    V v_x3_2410 = heff_tr(heff_apply(v_f_245, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_l_244, heff_clo(g_heff_2ereadback_2ereadbCloEl_24s181_lam1, 1, 1, (V[]){v_v_248})})}));
    V v_t_2414;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nom: {
      V v_v_2411 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = (g_heff_2ereadback_2ereadbTermF_24s178(v_n_246, v_v_2411));
      break;
    }
    case TAG_Describe: {
      V v_v_2412 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = (g_heff_2ereadback_2ereadbTermF_24s178(v_n_246, v_v_2412));
      break;
    }
    case TAG_Become: {
      V v_v_2413 = heff_field(v_x3_2410, 0);
      V v_ru_24x3_2410_24Become = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = heff_tag_at(v_ru_24x3_2410_24Become, TAG_SIs, 1, (V[]){(g_heff_2ereadback_2ereadbTermF_24s178(v_n_246, v_v_2413))});
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    return heff_tag(TAG_MkAbs, 2, (V[]){v_x_243, v_t_2414});
  }
  case TAG_CloConst: {
    V v_t_2415 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24CloConst = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_dom_241);
    V v_t_2419;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nom: {
      V v_v_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      v_t_2419 = (g_heff_2ereadback_2ereadbTermF_24s178(v_n_240, v_v_2416));
      break;
    }
    case TAG_Describe: {
      V v_v_2417 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      v_t_2419 = (g_heff_2ereadback_2ereadbTermF_24s178(v_n_240, v_v_2417));
      break;
    }
    case TAG_Become: {
      V v_v_2418 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      v_t_2419 = heff_tag_at(v_ru_24x4_242_24CloConst, TAG_SIs, 1, (V[]){(g_heff_2ereadback_2ereadbTermF_24s178(v_n_240, v_v_2418))});
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    return heff_tag(TAG_AbsConst, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ereadback_2ereadbCloEl_24s181_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbCloEl_24s181(a[0], a[1], a[2]);
}
V g_heff_2ereadback_2ereadbCloEl_24s181_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_dom_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_dom_241;
}
V g_heff_2ereadback_2ereadbCloEl_24s181_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_v_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_v_248;
}
V g_heff_2ereadback_2ereadbCloTy_24s183_lam0(V self, V *args);
V g_heff_2ereadback_2ereadbCloTy_24s183_lam1(V self, V *args);
Clo g_heff_2ereadback_2ereadbCloTy_24s183_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbCloTy_24s183_entry, 3, 0};

V g_heff_2ereadback_2ereadbCloTy_24s183(V v_n_240, V v_dom_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkClo: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_l_244 = heff_field(v_x4_242, 1);
    V v_f_245 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_n_246 = heff_intAdd(heff_dup(v_n_240), MK_INT(1LL));
    V v_v_248 = (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo(g_heff_2ereadback_2ereadbCloTy_24s183_lam0, 1, 1, (V[]){v_dom_241}), NTAG(TAG_Nothing)));
    V v_x3_2410 = heff_tr(heff_apply(v_f_245, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_l_244, heff_clo(g_heff_2ereadback_2ereadbCloTy_24s183_lam1, 1, 1, (V[]){v_v_248})})}));
    V v_t_2414;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nom: {
      V v_a_2411 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_n_246, v_a_2411));
      break;
    }
    case TAG_Describe: {
      V v_a_2412 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_n_246, v_a_2412));
      break;
    }
    case TAG_Become: {
      V v_a_2413 = heff_field(v_x3_2410, 0);
      V v_ru_24x3_2410_24Become = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = heff_tag_at(v_ru_24x3_2410_24Become, TAG_SIsTy, 1, (V[]){(g_heff_2ereadback_2ereadbTypeF_24s182(v_n_246, v_a_2413))});
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    return heff_tag(TAG_MkAbs, 2, (V[]){v_x_243, v_t_2414});
  }
  case TAG_CloConst: {
    V v_t_2415 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24CloConst = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_dom_241);
    V v_t_2419;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nom: {
      V v_a_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      v_t_2419 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_n_240, v_a_2416));
      break;
    }
    case TAG_Describe: {
      V v_a_2417 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      v_t_2419 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_n_240, v_a_2417));
      break;
    }
    case TAG_Become: {
      V v_a_2418 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      v_t_2419 = heff_tag_at(v_ru_24x4_242_24CloConst, TAG_SIsTy, 1, (V[]){(g_heff_2ereadback_2ereadbTypeF_24s182(v_n_240, v_a_2418))});
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    return heff_tag(TAG_AbsConst, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ereadback_2ereadbCloTy_24s183_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbCloTy_24s183(a[0], a[1], a[2]);
}
V g_heff_2ereadback_2ereadbCloTy_24s183_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_dom_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_dom_241;
}
V g_heff_2ereadback_2ereadbCloTy_24s183_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_v_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_v_248;
}
V g_heff_2ereadback_2egoRT_24s184_lam0(V self, V *args);
V g_heff_2ereadback_2egoRT_24s184_lam1(V self, V *args);
Clo g_heff_2ereadback_2egoRT_24s184_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2egoRT_24s184_entry, 3, 0};

V g_heff_2ereadback_2egoRT_24s184(V v_i_240, V v_ls_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_ls_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_apply(v_f_243, 1, (V[]){heff_dup(v_ls_241)}));
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkField: {
      V v_ty_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 2);
      V v_t_248 = (g_heff_2ereadback_2ereadbTypeF_24s182(heff_dup(v_i_240), heff_dup(v_ty_246)));
      V v_v_2410 = (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HLocal, 1, (V[]){heff_dup(v_i_240)}), NTAG(TAG_SpId), heff_clo(g_heff_2ereadback_2egoRT_24s184_lam0, 1, 1, (V[]){v_ty_246}), NTAG(TAG_Nothing)));
      return heff_tag_at(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_heff_2ereadback_2egoRT_24s184(heff_intAdd(v_i_240, MK_INT(1LL)), heff_tag(TAG_LSnoc, 2, (V[]){v_ls_241, heff_clo(g_heff_2ereadback_2egoRT_24s184_lam1, 1, 1, (V[]){v_v_2410})}), v_rest_244))});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ereadback_2egoRT_24s184_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2egoRT_24s184(a[0], a[1], a[2]);
}
V g_heff_2ereadback_2egoRT_24s184_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_ty_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_ty_246;
}
V g_heff_2ereadback_2egoRT_24s184_lam1(V self, V *args) {
  V v_u_2411 = args[0];
  V v_v_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return v_v_2410;
}
V g_heff_2ereadback_2ereadbTypeF_24s182_lam1(V self, V *args);
V g_heff_2ereadback_2ereadbTypeF_24s182_lam0(V self, V *args);
Clo g_heff_2ereadback_2ereadbTypeF_24s182_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbTypeF_24s182_entry, 2, 0};

V g_heff_2ereadback_2ereadbTypeF_24s182(V v_n_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_VU: {
    V v_u_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VU = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    heff_drop(v_n_240);
    return heff_tag_at(v_ru_24x3_241_24VU, TAG_SU, 1, (V[]){v_u_242});
  }
  case TAG_VDecode: {
    V v_h_243 = heff_field(v_x3_241, 0);
    V v_sp_244 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 5);
    V v_t_2413;
    switch (heff_tag_of(v_h_243)) {
    case TAG_HLocal: {
      V v_i_248 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HLocal = heff_take_reuse_n(v_h_243, 1ULL, 1);
      V v_t_249 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_248), MK_INT(1LL));
      v_t_2413 = heff_tag_at(v_ru_24h_243_24HLocal, TAG_SLocal, 1, (V[]){v_t_249});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2410 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HGlobal = heff_take_reuse_n(v_h_243, 1ULL, 1);
      v_t_2413 = heff_tag_at(v_ru_24h_243_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2410});
      break;
    }
    case TAG_HMeta: {
      V v_m_2411 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HMeta = heff_take_reuse_n(v_h_243, 1ULL, 1);
      V v_t_2412 = heff_tag_at(v_ru_24h_243_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2413 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2411, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2412});
      break;
    }
    case TAG_HError: {
      v_t_2413 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_243);
    }
    return heff_tag(TAG_SDecode, 1, (V[]){(g_heff_2ereadback_2ereadbSpine_24s180(v_n_240, v_sp_244, v_t_2413))});
  }
  case TAG_VFunction: {
    V v_level_2414 = heff_field(v_x3_241, 0);
    V v_dom_2415 = heff_field(v_x3_241, 1);
    V v_cod_2416 = heff_field(v_x3_241, 2);
    V v_implicit_2417 = heff_field(v_x3_241, 3);
    V v_ru_24x3_241_24VFunction = heff_take_reuse_n(v_x3_241, 15ULL, 4);
    V v_t_2418 = (g_heff_2ereadback_2ereadbTypeF_24s182(heff_dup(v_n_240), heff_dup(v_dom_2415)));
    V v_t_2419 = (g_heff_2ereadback_2ereadbCloTy_24s183(v_n_240, v_dom_2415, v_cod_2416));
    return heff_tag_at(v_ru_24x3_241_24VFunction, TAG_SFunction, 4, (V[]){v_level_2414, v_t_2418, v_t_2419, v_implicit_2417});
  }
  case TAG_VRecord: {
    V v_level_2420 = heff_field(v_x3_241, 0);
    V v_capture_2421 = heff_field(v_x3_241, 1);
    V v_fieldTypes_2422 = heff_field(v_x3_241, 2);
    V v_defaults_2423 = heff_field(v_x3_241, 3);
    heff_take_n(v_x3_241, 15ULL, 4);
    V v_t_2424 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2422), LBL_values));
    V v_t_2425 = (g_heff_2ereadback_2egoRT_24s184(v_n_240, v_capture_2421, v_t_2424));
    V v_t_2426 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_fieldTypes_2422), LBL_keys), heff_get(v_fieldTypes_2422, LBL_byName), heff_arrayFromList(v_t_2425)});
    return heff_tag(TAG_SRecord, 3, (V[]){v_level_2420, v_t_2426, v_defaults_2423});
  }
  case TAG_VSum: {
    V v_st_2427 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VSum = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_xs_2428 = heff_get(heff_dup(v_st_2427), LBL_values);
    V v_t_2434 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2428)), heff_clo(g_heff_2ereadback_2ereadbTypeF_24s182_lam0, 1, 2, (V[]){v_xs_2428, v_n_240}));
    V v_t_2435 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_st_2427), LBL_keys), heff_get(v_st_2427, LBL_byName), v_t_2434});
    return heff_tag_at(v_ru_24x3_241_24VSum, TAG_SSum, 1, (V[]){v_t_2435});
  }
  case TAG_VPrimInt: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimInt);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimFloat);
  }
  case TAG_VPrimString: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimString);
  }
  case TAG_VPrimArray: {
    V v_a_2436 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VPrimArray = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    return heff_tag_at(v_ru_24x3_241_24VPrimArray, TAG_SPrimArray, 1, (V[]){(g_heff_2ereadback_2ereadbTypeF_24s182(v_n_240, v_a_2436))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ereadback_2ereadbTypeF_24s182_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbTypeF_24s182(a[0], a[1]);
}
V g_heff_2ereadback_2ereadbTypeF_24s182_lam1(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  V v_t_2433 = heff_tr(heff_apply(v_t_2432, 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2ereadback_2ereadbTypeF_24s182(v_n_240, v_t_2433));
}
V g_heff_2ereadback_2ereadbTypeF_24s182_lam0(V self, V *args) {
  V v_i_2429 = args[0];
  V v_xs_2428 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2430 = heff_arrayIndex(v_xs_2428, v_i_2429);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2430)), heff_clo(g_heff_2ereadback_2ereadbTypeF_24s182_lam1, 1, 2, (V[]){v_xs_2430, v_n_240}));
}
V g_heff_2ereadback_2ereadbTermF_24s178_lam0(V self, V *args);
Clo g_heff_2ereadback_2ereadbTermF_24s178_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbTermF_24s178_entry, 2, 0};

V g_heff_2ereadback_2ereadbTermF_24s178(V v_n_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_VNeu: {
    V v_h_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 5);
    return (g_heff_2ereadback_2ereadbBare_24s179(v_n_240, v_h_242, v_sp_243));
  }
  case TAG_VCode: {
    V v_a_247 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VCode = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    return heff_tag_at(v_ru_24x3_241_24VCode, TAG_SCode, 1, (V[]){(g_heff_2ereadback_2ereadbTypeF_24s182(v_n_240, v_a_247))});
  }
  case TAG_VLam: {
    V v_fty_248 = heff_field(v_x3_241, 0);
    V v_body_249 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24VLam = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_apply(heff_dup(v_fty_248), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2411 = (g_heff_2ereadback_2ereadbTypeF_24s182(heff_dup(v_n_240), v_t_2410));
    V v_t_2412 = heff_tr(heff_apply(v_fty_248, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2413 = (g_heff_2evalue_2ebehavior(heff_dup(v_t_2412)));
    V v_t_2424;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2413, 0ULL, 1);
      v_t_2424 = v_t_2412;
      break;
    }
    case TAG_LikeFunction: {
      V v_dom_2416 = heff_field(v_t_2413, 1);
      heff_take_n(v_t_2413, 2ULL, 4);
      heff_drop(v_t_2412);
      v_t_2424 = v_dom_2416;
      break;
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2413, 0ULL, 3);
      v_t_2424 = v_t_2412;
      break;
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2413, 0ULL, 1);
      v_t_2424 = v_t_2412;
      break;
    }
    case TAG_LikeInt: {
      v_t_2424 = v_t_2412;
      break;
    }
    case TAG_LikeFloat: {
      v_t_2424 = v_t_2412;
      break;
    }
    case TAG_LikeString: {
      v_t_2424 = v_t_2412;
      break;
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2413, 0ULL, 1);
      v_t_2424 = v_t_2412;
      break;
    }
    case TAG_NoRules: {
      v_t_2424 = v_t_2412;
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    return heff_tag_at(v_ru_24x3_241_24VLam, TAG_SLam, 2, (V[]){v_t_2411, (g_heff_2ereadback_2ereadbCloEl_24s181(v_n_240, v_t_2424, v_body_249))});
  }
  case TAG_VCons: {
    V v_d_2425 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VCons = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_xs_2426 = heff_get(heff_dup(v_d_2425), LBL_values);
    V v_t_2432 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2426)), heff_clo(g_heff_2ereadback_2ereadbTermF_24s178_lam0, 1, 2, (V[]){v_xs_2426, v_n_240}));
    V v_t_2433 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_d_2425), LBL_keys), heff_get(v_d_2425, LBL_byName), v_t_2432});
    return heff_tag_at(v_ru_24x3_241_24VCons, TAG_SCons, 1, (V[]){v_t_2433});
  }
  case TAG_VOpaque: {
    heff_drop(v_n_240);
    return NTAG(TAG_SOpaque);
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ereadback_2ereadbTermF_24s178_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbTermF_24s178(a[0], a[1]);
}
V g_heff_2ereadback_2ereadbTermF_24s178_lam0(V self, V *args) {
  V v_i_2427 = args[0];
  V v_xs_2426 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x3_2428 = heff_arrayIndex(v_xs_2426, v_i_2427);
  switch (heff_tag_of(v_x3_2428)) {
  case TAG_Nom: {
    V v_v_2429 = heff_field(v_x3_2428, 0);
    heff_take_n(v_x3_2428, 1ULL, 1);
    return (g_heff_2ereadback_2ereadbTermF_24s178(v_n_240, v_v_2429));
  }
  case TAG_Describe: {
    V v_v_2430 = heff_field(v_x3_2428, 0);
    heff_take_n(v_x3_2428, 1ULL, 1);
    return (g_heff_2ereadback_2ereadbTermF_24s178(v_n_240, v_v_2430));
  }
  case TAG_Become: {
    V v_v_2431 = heff_field(v_x3_2428, 0);
    V v_ru_24x3_2428_24Become = heff_take_reuse_n(v_x3_2428, 1ULL, 1);
    return heff_tag_at(v_ru_24x3_2428_24Become, TAG_SIs, 1, (V[]){(g_heff_2ereadback_2ereadbTermF_24s178(v_n_240, v_v_2431))});
  }
  default: return heff_nomatch(v_x3_2428);
  }
}
V g_heff_2ereadback_2ereadbBare_24s185_lam0(V self, V *args);
Clo g_heff_2ereadback_2ereadbBare_24s185_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbBare_24s185_entry, 3, 0};

V g_heff_2ereadback_2ereadbBare_24s185(V v_n_240, V v_h_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_HLocal: {
    V v_t_249;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_244 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_245 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_244), MK_INT(1LL));
      v_t_249 = heff_tag_at(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_245});
      break;
    }
    case TAG_HGlobal: {
      V v_x_246 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_249 = heff_tag_at(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_246});
      break;
    }
    case TAG_HMeta: {
      V v_m_247 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_248 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_249 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_247, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_248});
      break;
    }
    case TAG_HError: {
      v_t_249 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s180(v_n_240, v_sp_242, v_t_249);
  }
  case TAG_HGlobal: {
    V v_t_2416;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2411 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2412 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_2411), MK_INT(1LL));
      v_t_2416 = heff_tag_at(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2413 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2416 = heff_tag_at(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2413});
      break;
    }
    case TAG_HMeta: {
      V v_m_2414 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2415 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2416 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2414, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2415});
      break;
    }
    case TAG_HError: {
      v_t_2416 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s180(v_n_240, v_sp_242, v_t_2416);
  }
  case TAG_HMeta: {
    V v_m_2417 = heff_field(v_h_241, 0);
    V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
    V v_t_2418 = (g_heff_2ereadback_2elocalArgs(heff_dup(v_sp_242)));
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      V v_t_2419 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s180(v_n_240, v_sp_242, heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2419}));
    }
    case TAG_Just: {
      V v_idxs_2420 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      heff_drop(v_sp_242);
      V v_t_2421 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_idxs_2420));
      V v_t_2423 = (g_prelude_2emap(heff_clo(g_heff_2ereadback_2ereadbBare_24s185_lam0, 1, 1, (V[]){v_n_240}), v_t_2421));
      V v_t_2424 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      return heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_arrayFromList(v_t_2423), v_t_2424});
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  case TAG_HError: {
    V v_t_2430;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2425 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2426 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_2425), MK_INT(1LL));
      v_t_2430 = heff_tag_at(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2426});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2427 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2430 = heff_tag_at(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2427});
      break;
    }
    case TAG_HMeta: {
      V v_m_2428 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2429 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2430 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2428, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2429});
      break;
    }
    case TAG_HError: {
      v_t_2430 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s180(v_n_240, v_sp_242, v_t_2430);
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2ereadback_2ereadbBare_24s185_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbBare_24s185(a[0], a[1], a[2]);
}
V g_heff_2ereadback_2ereadbBare_24s185_lam0(V self, V *args) {
  V v_l_2422 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intSub(heff_intSub(v_n_240, v_l_2422), MK_INT(1LL));
}