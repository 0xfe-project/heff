// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLocal 28569
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_keys 9783995
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_array_2eempty_get(void);
V g_heff_2ereadback_2earrayEmpty_get(void);
V g_heff_2ereadback_2egoRT_24s354414867x1814623617(V, V, V);
V g_heff_2ereadback_2egoRT_24s354414867x1814623617_entry(V self, V *a);
extern Clo g_heff_2ereadback_2egoRT_24s354414867x1814623617_clo;
V g_heff_2ereadback_2elocalArgs(V);
V g_heff_2ereadback_2elocalArgs_entry(V self, V *a);
extern Clo g_heff_2ereadback_2elocalArgs_clo;
V g_heff_2ereadback_2ereadbBare_24s1356405674x295666330(V, V, V);
V g_heff_2ereadback_2ereadbBare_24s1356405674x295666330_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbBare_24s1356405674x295666330_clo;
V g_heff_2ereadback_2ereadbBare_24s868107334x1094461386(V, V, V);
V g_heff_2ereadback_2ereadbBare_24s868107334x1094461386_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbBare_24s868107334x1094461386_clo;
V g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975(V, V, V);
V g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975_clo;
V g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253(V, V, V);
V g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253_clo;
V g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(V, V, V);
V g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619_clo;
V g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(V, V);
V g_heff_2ereadback_2ereadbTermF_24s131168004x223657298_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbTermF_24s131168004x223657298_clo;
V g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(V, V);
V g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942_entry(V self, V *a);
extern Clo g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942_clo;
V g_heff_2evalue_2ebehavior(V);
V g_heff_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2evalue_2ebehavior_clo;
V g_heff_2evalue_2emkNeu_24s1912479565x1511825694(V, V, V, V);
V g_heff_2evalue_2emkNeu_24s1912479565x1511825694_entry(V self, V *a);
extern Clo g_heff_2evalue_2emkNeu_24s1912479565x1511825694_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;

static V g_heff_2ereadback_2earrayEmpty_val;
static int g_heff_2ereadback_2earrayEmpty_st;
static V g_heff_2ereadback_2earrayEmpty_init(void) {
  return heff_dup(g_array_2eempty_get());
}
V g_heff_2ereadback_2earrayEmpty_get(void) {
  if (g_heff_2ereadback_2earrayEmpty_st == 2) return g_heff_2ereadback_2earrayEmpty_val;
  if (g_heff_2ereadback_2earrayEmpty_st == 1) heff_fail("defined by itself");
  g_heff_2ereadback_2earrayEmpty_st = 1;
  g_heff_2ereadback_2earrayEmpty_val = heff_tr(g_heff_2ereadback_2earrayEmpty_init());
  g_heff_2ereadback_2earrayEmpty_st = 2;
  return g_heff_2ereadback_2earrayEmpty_val;
}
Clo g_heff_2ereadback_2elocalArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2elocalArgs_entry, 1, 0};

V g_heff_2ereadback_2elocalArgs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return heff_tag(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_SpApp: {
    V v_sp_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_VNeu: {
      V v_x121_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      heff_take_n(v_x12_242, 3ULL, 5);
      switch (heff_tag_of(v_x121_243)) {
      case TAG_HLocal: {
        V v_l_248 = heff_field(v_x121_243, 0);
        V v_ru_24x121_243_24HLocal = heff_take_reuse_n(v_x121_243, 1ULL, 1);
        switch (heff_tag_of(v_x122_244)) {
        case TAG_SpId: {
          V v_x2_249 = (g_heff_2ereadback_2elocalArgs(v_sp_241));
          switch (heff_tag_of(v_x2_249)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
            heff_drop(v_l_248);
            heff_drop_cell(v_ru_24x121_243_24HLocal, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_xs_2410 = heff_field(v_x2_249, 0);
            heff_take_n(v_x2_249, 1ULL, 1);
            return heff_tag_at(v_ru_24x121_243_24HLocal, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_l_248, v_xs_2410})});
          }
          default: return heff_nomatch(v_x2_249);
          }
        }
        case TAG_SpApp: {
          heff_take_n(v_x122_244, 0ULL, 2);
          heff_drop(v_sp_241);
          heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
          heff_drop(v_l_248);
          heff_drop_cell(v_ru_24x121_243_24HLocal, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpProj: {
          heff_take_n(v_x122_244, 0ULL, 2);
          heff_drop(v_sp_241);
          heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
          heff_drop(v_l_248);
          heff_drop_cell(v_ru_24x121_243_24HLocal, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpSpec: {
          heff_take_n(v_x122_244, 0ULL, 3);
          heff_drop(v_sp_241);
          heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
          heff_drop(v_l_248);
          heff_drop_cell(v_ru_24x121_243_24HLocal, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x122_244);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_x121_243, 0ULL, 1);
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_x122_244);
        return NTAG(TAG_Nothing);
      }
      case TAG_HMeta: {
        heff_take_n(v_x121_243, 0ULL, 1);
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_x122_244);
        return NTAG(TAG_Nothing);
      }
      case TAG_HError: {
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_x122_244);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x121_243);
      }
    }
    case TAG_VCode: {
      heff_take_n(v_x12_242, 0ULL, 1);
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_VLam: {
      heff_take_n(v_x12_242, 0ULL, 2);
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x12_242, 0ULL, 1);
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_VOpaque: {
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  case TAG_SpProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SpSpec: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ereadback_2elocalArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2elocalArgs(a[0]);
}
Clo g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619_entry, 3, 0};

V g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(V v_n_240, V v_x3_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_SpId: {
    heff_drop(v_n_240);
    return v_t_242;
  }
  case TAG_SpApp: {
    V v_sp_243 = heff_field(v_x3_241, 0);
    V v_v_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24SpApp = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(heff_dup(v_n_240), v_sp_243, v_t_242));
    return heff_tag_at(v_ru_24x3_241_24SpApp, TAG_SApp, 2, (V[]){v_t_245, (g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(v_n_240, v_v_244))});
  }
  case TAG_SpProj: {
    V v_sp_246 = heff_field(v_x3_241, 0);
    V v_x_247 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24SpProj = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_248 = (g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(v_n_240, v_sp_246, v_t_242));
    return heff_tag_at(v_ru_24x3_241_24SpProj, TAG_SProj, 2, (V[]){v_t_248, v_x_247});
  }
  case TAG_SpSpec: {
    V v_sp_249 = heff_field(v_x3_241, 0);
    V v_x_2410 = heff_field(v_x3_241, 1);
    V v_v_2411 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24SpSpec = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_t_2412 = (g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(heff_dup(v_n_240), v_sp_249, v_t_242));
    return heff_tag_at(v_ru_24x3_241_24SpSpec, TAG_SSpecialize, 3, (V[]){v_t_2412, v_x_2410, (g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(v_n_240, v_v_2411))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(a[0], a[1], a[2]);
}
V g_heff_2ereadback_2ereadbBare_24s868107334x1094461386_lam0(V self, V *args);
Clo g_heff_2ereadback_2ereadbBare_24s868107334x1094461386_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbBare_24s868107334x1094461386_entry, 3, 0};

V g_heff_2ereadback_2ereadbBare_24s868107334x1094461386(V v_n_240, V v_h_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_HLocal: {
    V v_t_249;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_244 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_245 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_244), MK_INT(1LL));
      v_t_249 = heff_tag_at(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_245});
      break;
    }
    case TAG_HGlobal: {
      V v_x_246 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_249 = heff_tag_at(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_246});
      break;
    }
    case TAG_HMeta: {
      V v_m_247 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_248 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_249 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_247, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_248});
      break;
    }
    case TAG_HError: {
      v_t_249 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(v_n_240, v_sp_242, v_t_249);
  }
  case TAG_HGlobal: {
    V v_t_2416;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2411 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2412 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_2411), MK_INT(1LL));
      v_t_2416 = heff_tag_at(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2413 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2416 = heff_tag_at(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2413});
      break;
    }
    case TAG_HMeta: {
      V v_m_2414 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2415 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2416 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2414, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2415});
      break;
    }
    case TAG_HError: {
      v_t_2416 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(v_n_240, v_sp_242, v_t_2416);
  }
  case TAG_HMeta: {
    V v_m_2417 = heff_field(v_h_241, 0);
    V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
    V v_t_2418 = (g_heff_2ereadback_2elocalArgs(heff_dup(v_sp_242)));
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      V v_t_2419 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(v_n_240, v_sp_242, heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2419}));
    }
    case TAG_Just: {
      V v_idxs_2420 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      heff_drop(v_sp_242);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_idxs_2420));
      V v_t_2423 = (g_list_2emap(heff_clo(g_heff_2ereadback_2ereadbBare_24s868107334x1094461386_lam0, 1, 1, (V[]){v_n_240}), v_t_2421));
      V v_t_2424 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      return heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_arrayFromList(v_t_2423), v_t_2424});
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  case TAG_HError: {
    V v_t_2430;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2425 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2426 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_2425), MK_INT(1LL));
      v_t_2430 = heff_tag_at(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2426});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2427 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2430 = heff_tag_at(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2427});
      break;
    }
    case TAG_HMeta: {
      V v_m_2428 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2429 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2430 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2428, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2429});
      break;
    }
    case TAG_HError: {
      v_t_2430 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(v_n_240, v_sp_242, v_t_2430);
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2ereadback_2ereadbBare_24s868107334x1094461386_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbBare_24s868107334x1094461386(a[0], a[1], a[2]);
}
V g_heff_2ereadback_2ereadbBare_24s868107334x1094461386_lam0(V self, V *args) {
  V v_l_2422 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intSub(heff_intSub(v_n_240, v_l_2422), MK_INT(1LL));
}
V g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253_lam0(V self, V *args);
V g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253_lam1(V self, V *args);
Clo g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253_entry, 3, 0};

V g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253(V v_n_240, V v_dom_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkClo: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_l_244 = heff_field(v_x4_242, 1);
    V v_f_245 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_n_246 = heff_intAdd(heff_dup(v_n_240), MK_INT(1LL));
    V v_v_248 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(heff_tag(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo(g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253_lam0, 1, 1, (V[]){v_dom_241}), NTAG(TAG_Nothing)));
    V v_x3_2410 = heff_tr(heff_apply(v_f_245, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_l_244, heff_clo(g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253_lam1, 1, 1, (V[]){v_v_248})})}));
    V v_t_2414;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nom: {
      V v_a_2411 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = (g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(v_n_246, v_a_2411));
      break;
    }
    case TAG_Describe: {
      V v_a_2412 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = (g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(v_n_246, v_a_2412));
      break;
    }
    case TAG_Become: {
      V v_a_2413 = heff_field(v_x3_2410, 0);
      V v_ru_24x3_2410_24Become = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = heff_tag_at(v_ru_24x3_2410_24Become, TAG_SIsTy, 1, (V[]){(g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(v_n_246, v_a_2413))});
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    return heff_tag(TAG_MkAbs, 2, (V[]){v_x_243, v_t_2414});
  }
  case TAG_CloConst: {
    V v_t_2415 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24CloConst = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_dom_241);
    V v_t_2419;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nom: {
      V v_a_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      v_t_2419 = (g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(v_n_240, v_a_2416));
      break;
    }
    case TAG_Describe: {
      V v_a_2417 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      v_t_2419 = (g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(v_n_240, v_a_2417));
      break;
    }
    case TAG_Become: {
      V v_a_2418 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      v_t_2419 = heff_tag_at(v_ru_24x4_242_24CloConst, TAG_SIsTy, 1, (V[]){(g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(v_n_240, v_a_2418))});
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    return heff_tag(TAG_AbsConst, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253(a[0], a[1], a[2]);
}
V g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_dom_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_dom_241;
}
V g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_v_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_v_248;
}
V g_heff_2ereadback_2egoRT_24s354414867x1814623617_lam0(V self, V *args);
V g_heff_2ereadback_2egoRT_24s354414867x1814623617_lam1(V self, V *args);
Clo g_heff_2ereadback_2egoRT_24s354414867x1814623617_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2egoRT_24s354414867x1814623617_entry, 3, 0};

V g_heff_2ereadback_2egoRT_24s354414867x1814623617(V v_i_240, V v_ls_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_ls_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_apply(v_f_243, 1, (V[]){heff_dup(v_ls_241)}));
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkField: {
      V v_ty_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 2);
      V v_t_248 = (g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(heff_dup(v_i_240), heff_dup(v_ty_246)));
      V v_v_2410 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(heff_tag(TAG_HLocal, 1, (V[]){heff_dup(v_i_240)}), NTAG(TAG_SpId), heff_clo(g_heff_2ereadback_2egoRT_24s354414867x1814623617_lam0, 1, 1, (V[]){v_ty_246}), NTAG(TAG_Nothing)));
      return heff_tag_at(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_heff_2ereadback_2egoRT_24s354414867x1814623617(heff_intAdd(v_i_240, MK_INT(1LL)), heff_tag(TAG_LSnoc, 2, (V[]){v_ls_241, heff_clo(g_heff_2ereadback_2egoRT_24s354414867x1814623617_lam1, 1, 1, (V[]){v_v_2410})}), v_rest_244))});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ereadback_2egoRT_24s354414867x1814623617_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2egoRT_24s354414867x1814623617(a[0], a[1], a[2]);
}
V g_heff_2ereadback_2egoRT_24s354414867x1814623617_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_ty_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_ty_246;
}
V g_heff_2ereadback_2egoRT_24s354414867x1814623617_lam1(V self, V *args) {
  V v_u_2411 = args[0];
  V v_v_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return v_v_2410;
}
V g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942_lam1(V self, V *args);
V g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942_lam0(V self, V *args);
Clo g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942_entry, 2, 0};

V g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(V v_n_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_VU: {
    V v_u_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VU = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    heff_drop(v_n_240);
    return heff_tag_at(v_ru_24x3_241_24VU, TAG_SU, 1, (V[]){v_u_242});
  }
  case TAG_VDecode: {
    V v_h_243 = heff_field(v_x3_241, 0);
    V v_sp_244 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 5);
    V v_t_2413;
    switch (heff_tag_of(v_h_243)) {
    case TAG_HLocal: {
      V v_i_248 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HLocal = heff_take_reuse_n(v_h_243, 1ULL, 1);
      V v_t_249 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_248), MK_INT(1LL));
      v_t_2413 = heff_tag_at(v_ru_24h_243_24HLocal, TAG_SLocal, 1, (V[]){v_t_249});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2410 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HGlobal = heff_take_reuse_n(v_h_243, 1ULL, 1);
      v_t_2413 = heff_tag_at(v_ru_24h_243_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2410});
      break;
    }
    case TAG_HMeta: {
      V v_m_2411 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HMeta = heff_take_reuse_n(v_h_243, 1ULL, 1);
      V v_t_2412 = heff_tag_at(v_ru_24h_243_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2413 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2411, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2412});
      break;
    }
    case TAG_HError: {
      v_t_2413 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_243);
    }
    return heff_tag(TAG_SDecode, 1, (V[]){(g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(v_n_240, v_sp_244, v_t_2413))});
  }
  case TAG_VFunction: {
    V v_level_2414 = heff_field(v_x3_241, 0);
    V v_dom_2415 = heff_field(v_x3_241, 1);
    V v_cod_2416 = heff_field(v_x3_241, 2);
    V v_implicit_2417 = heff_field(v_x3_241, 3);
    V v_dflt_2418 = heff_field(v_x3_241, 4);
    V v_ru_24x3_241_24VFunction = heff_take_reuse_n(v_x3_241, 31ULL, 5);
    V v_t_2419 = (g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(heff_dup(v_n_240), heff_dup(v_dom_2415)));
    V v_t_2420 = (g_heff_2ereadback_2ereadbCloTy_24s708930204x315028253(v_n_240, v_dom_2415, v_cod_2416));
    return heff_tag_at(v_ru_24x3_241_24VFunction, TAG_SFunction, 5, (V[]){v_level_2414, v_t_2419, v_t_2420, v_implicit_2417, v_dflt_2418});
  }
  case TAG_VRecord: {
    V v_level_2421 = heff_field(v_x3_241, 0);
    V v_capture_2422 = heff_field(v_x3_241, 1);
    V v_fieldTypes_2423 = heff_field(v_x3_241, 2);
    V v_defaults_2424 = heff_field(v_x3_241, 3);
    heff_take_n(v_x3_241, 15ULL, 4);
    V v_t_2425 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2423), LBL_values));
    V v_t_2426 = (g_heff_2ereadback_2egoRT_24s354414867x1814623617(v_n_240, v_capture_2422, v_t_2425));
    V v_t_2427 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_fieldTypes_2423), LBL_keys), heff_get(v_fieldTypes_2423, LBL_byName), heff_arrayFromList(v_t_2426)});
    return heff_tag(TAG_SRecord, 3, (V[]){v_level_2421, v_t_2427, v_defaults_2424});
  }
  case TAG_VSum: {
    V v_st_2428 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VSum = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_xs_2429 = heff_get(heff_dup(v_st_2428), LBL_values);
    V v_t_2435 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2429)), heff_clo(g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942_lam0, 1, 2, (V[]){v_xs_2429, v_n_240}));
    V v_t_2436 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_st_2428), LBL_keys), heff_get(v_st_2428, LBL_byName), v_t_2435});
    return heff_tag_at(v_ru_24x3_241_24VSum, TAG_SSum, 1, (V[]){v_t_2436});
  }
  case TAG_VPrimInt: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimInt);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimFloat);
  }
  case TAG_VPrimString: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimString);
  }
  case TAG_VPrimRune: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimRune);
  }
  case TAG_VPrimArray: {
    V v_a_2437 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VPrimArray = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    return heff_tag_at(v_ru_24x3_241_24VPrimArray, TAG_SPrimArray, 1, (V[]){(g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(v_n_240, v_a_2437))});
  }
  case TAG_VFixed: {
    V v_w_2438 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VFixed = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    heff_drop(v_n_240);
    return heff_tag_at(v_ru_24x3_241_24VFixed, TAG_SFixed, 1, (V[]){v_w_2438});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(a[0], a[1]);
}
V g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942_lam1(V self, V *args) {
  V v_i_2432 = args[0];
  V v_xs_2431 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_arrayIndex(v_xs_2431, v_i_2432);
  V v_t_2434 = heff_tr(heff_apply(v_t_2433, 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(v_n_240, v_t_2434));
}
V g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942_lam0(V self, V *args) {
  V v_i_2430 = args[0];
  V v_xs_2429 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2431 = heff_arrayIndex(v_xs_2429, v_i_2430);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2431)), heff_clo(g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942_lam1, 1, 2, (V[]){v_xs_2431, v_n_240}));
}
V g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975_lam0(V self, V *args);
V g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975_lam1(V self, V *args);
Clo g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975_entry, 3, 0};

V g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975(V v_n_240, V v_dom_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkClo: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_l_244 = heff_field(v_x4_242, 1);
    V v_f_245 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_n_246 = heff_intAdd(heff_dup(v_n_240), MK_INT(1LL));
    V v_v_248 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(heff_tag(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo(g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975_lam0, 1, 1, (V[]){v_dom_241}), NTAG(TAG_Nothing)));
    V v_x3_2410 = heff_tr(heff_apply(v_f_245, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_l_244, heff_clo(g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975_lam1, 1, 1, (V[]){v_v_248})})}));
    V v_t_2414;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nom: {
      V v_v_2411 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = (g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(v_n_246, v_v_2411));
      break;
    }
    case TAG_Describe: {
      V v_v_2412 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = (g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(v_n_246, v_v_2412));
      break;
    }
    case TAG_Become: {
      V v_v_2413 = heff_field(v_x3_2410, 0);
      V v_ru_24x3_2410_24Become = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
      v_t_2414 = heff_tag_at(v_ru_24x3_2410_24Become, TAG_SIs, 1, (V[]){(g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(v_n_246, v_v_2413))});
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    return heff_tag(TAG_MkAbs, 2, (V[]){v_x_243, v_t_2414});
  }
  case TAG_CloConst: {
    V v_t_2415 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24CloConst = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_dom_241);
    V v_t_2419;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nom: {
      V v_v_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      v_t_2419 = (g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(v_n_240, v_v_2416));
      break;
    }
    case TAG_Describe: {
      V v_v_2417 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      v_t_2419 = (g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(v_n_240, v_v_2417));
      break;
    }
    case TAG_Become: {
      V v_v_2418 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      v_t_2419 = heff_tag_at(v_ru_24x4_242_24CloConst, TAG_SIs, 1, (V[]){(g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(v_n_240, v_v_2418))});
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    return heff_tag(TAG_AbsConst, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975(a[0], a[1], a[2]);
}
V g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_dom_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_dom_241;
}
V g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_v_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_v_248;
}
V g_heff_2ereadback_2ereadbTermF_24s131168004x223657298_lam0(V self, V *args);
Clo g_heff_2ereadback_2ereadbTermF_24s131168004x223657298_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbTermF_24s131168004x223657298_entry, 2, 0};

V g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(V v_n_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_VNeu: {
    V v_h_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 5);
    return (g_heff_2ereadback_2ereadbBare_24s868107334x1094461386(v_n_240, v_h_242, v_sp_243));
  }
  case TAG_VCode: {
    V v_a_247 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VCode = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    return heff_tag_at(v_ru_24x3_241_24VCode, TAG_SCode, 1, (V[]){(g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(v_n_240, v_a_247))});
  }
  case TAG_VLam: {
    V v_fty_248 = heff_field(v_x3_241, 0);
    V v_body_249 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24VLam = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_apply(heff_dup(v_fty_248), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2411 = (g_heff_2ereadback_2ereadbTypeF_24s1651943253x898837942(heff_dup(v_n_240), v_t_2410));
    V v_t_2412 = heff_tr(heff_apply(v_fty_248, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2413 = (g_heff_2evalue_2ebehavior(heff_dup(v_t_2412)));
    V v_t_2425;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2413, 0ULL, 1);
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeFunction: {
      V v_dom_2416 = heff_field(v_t_2413, 1);
      heff_take_n(v_t_2413, 2ULL, 4);
      heff_drop(v_t_2412);
      v_t_2425 = v_dom_2416;
      break;
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2413, 0ULL, 3);
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2413, 0ULL, 1);
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeInt: {
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeFloat: {
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeString: {
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeRune: {
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2413, 0ULL, 1);
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2413, 0ULL, 1);
      v_t_2425 = v_t_2412;
      break;
    }
    case TAG_NoRules: {
      v_t_2425 = v_t_2412;
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    return heff_tag_at(v_ru_24x3_241_24VLam, TAG_SLam, 2, (V[]){v_t_2411, (g_heff_2ereadback_2ereadbCloEl_24s1470370720x500434975(v_n_240, v_t_2425, v_body_249))});
  }
  case TAG_VCons: {
    V v_d_2426 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VCons = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_xs_2427 = heff_get(heff_dup(v_d_2426), LBL_values);
    V v_t_2433 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2427)), heff_clo(g_heff_2ereadback_2ereadbTermF_24s131168004x223657298_lam0, 1, 2, (V[]){v_xs_2427, v_n_240}));
    V v_t_2434 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_d_2426), LBL_keys), heff_get(v_d_2426, LBL_byName), v_t_2433});
    return heff_tag_at(v_ru_24x3_241_24VCons, TAG_SCons, 1, (V[]){v_t_2434});
  }
  case TAG_VOpaque: {
    heff_drop(v_n_240);
    return NTAG(TAG_SOpaque);
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ereadback_2ereadbTermF_24s131168004x223657298_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(a[0], a[1]);
}
V g_heff_2ereadback_2ereadbTermF_24s131168004x223657298_lam0(V self, V *args) {
  V v_i_2428 = args[0];
  V v_xs_2427 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x3_2429 = heff_arrayIndex(v_xs_2427, v_i_2428);
  switch (heff_tag_of(v_x3_2429)) {
  case TAG_Nom: {
    V v_v_2430 = heff_field(v_x3_2429, 0);
    heff_take_n(v_x3_2429, 1ULL, 1);
    return (g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(v_n_240, v_v_2430));
  }
  case TAG_Describe: {
    V v_v_2431 = heff_field(v_x3_2429, 0);
    heff_take_n(v_x3_2429, 1ULL, 1);
    return (g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(v_n_240, v_v_2431));
  }
  case TAG_Become: {
    V v_v_2432 = heff_field(v_x3_2429, 0);
    V v_ru_24x3_2429_24Become = heff_take_reuse_n(v_x3_2429, 1ULL, 1);
    return heff_tag_at(v_ru_24x3_2429_24Become, TAG_SIs, 1, (V[]){(g_heff_2ereadback_2ereadbTermF_24s131168004x223657298(v_n_240, v_v_2432))});
  }
  default: return heff_nomatch(v_x3_2429);
  }
}
V g_heff_2ereadback_2ereadbBare_24s1356405674x295666330_lam0(V self, V *args);
Clo g_heff_2ereadback_2ereadbBare_24s1356405674x295666330_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ereadback_2ereadbBare_24s1356405674x295666330_entry, 3, 0};

V g_heff_2ereadback_2ereadbBare_24s1356405674x295666330(V v_n_240, V v_h_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_HLocal: {
    V v_t_249;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_244 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_245 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_244), MK_INT(1LL));
      v_t_249 = heff_tag_at(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_245});
      break;
    }
    case TAG_HGlobal: {
      V v_x_246 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_249 = heff_tag_at(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_246});
      break;
    }
    case TAG_HMeta: {
      V v_m_247 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_248 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_249 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_247, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_248});
      break;
    }
    case TAG_HError: {
      v_t_249 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(v_n_240, v_sp_242, v_t_249);
  }
  case TAG_HGlobal: {
    V v_t_2416;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2411 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2412 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_2411), MK_INT(1LL));
      v_t_2416 = heff_tag_at(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2413 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2416 = heff_tag_at(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2413});
      break;
    }
    case TAG_HMeta: {
      V v_m_2414 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2415 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2416 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2414, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2415});
      break;
    }
    case TAG_HError: {
      v_t_2416 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(v_n_240, v_sp_242, v_t_2416);
  }
  case TAG_HMeta: {
    V v_m_2417 = heff_field(v_h_241, 0);
    V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
    V v_t_2418 = (g_heff_2ereadback_2elocalArgs(heff_dup(v_sp_242)));
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      V v_t_2419 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(v_n_240, v_sp_242, heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2419}));
    }
    case TAG_Just: {
      V v_idxs_2420 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      heff_drop(v_sp_242);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_idxs_2420));
      V v_t_2423 = (g_list_2emap(heff_clo(g_heff_2ereadback_2ereadbBare_24s1356405674x295666330_lam0, 1, 1, (V[]){v_n_240}), v_t_2421));
      V v_t_2424 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      return heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_arrayFromList(v_t_2423), v_t_2424});
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  case TAG_HError: {
    V v_t_2430;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2425 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2426 = heff_intSub(heff_intSub(heff_dup(v_n_240), v_i_2425), MK_INT(1LL));
      v_t_2430 = heff_tag_at(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2426});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2427 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2430 = heff_tag_at(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2427});
      break;
    }
    case TAG_HMeta: {
      V v_m_2428 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2429 = heff_tag_at(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2430 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_2428, heff_dup(g_heff_2ereadback_2earrayEmpty_get()), v_t_2429});
      break;
    }
    case TAG_HError: {
      v_t_2430 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2ereadback_2ereadbSpine_24s787795751x1394697619(v_n_240, v_sp_242, v_t_2430);
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2ereadback_2ereadbBare_24s1356405674x295666330_entry(V self, V *a) {
  (void)self;
  return g_heff_2ereadback_2ereadbBare_24s1356405674x295666330(a[0], a[1], a[2]);
}
V g_heff_2ereadback_2ereadbBare_24s1356405674x295666330_lam0(V self, V *args) {
  V v_l_2422 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intSub(heff_intSub(v_n_240, v_l_2422), MK_INT(1LL));
}