// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
HeffT3 g_regex_2eclassFrom_2eclassRune_240_24cpr(V, V);
V g_regex_2econtrolEscape(V);
V g_regex_2econtrolEscape_entry(V self, V *a);
extern Clo g_regex_2econtrolEscape_clo;
HEFF_LIT(g_regex_2eclassFrom_2eclassRune_240_24cpr_str0, 17, "a `[` with no `]`");
HEFF_LIT(g_regex_2eclassFrom_2eclassRune_240_24cpr_str1, 16, "a `\\` at the end");
HEFF_LIT(g_regex_2eclassFrom_2eclassRune_240_24cpr_str2, 2, "`\\");
HEFF_LIT(g_regex_2eclassFrom_2eclassRune_240_24cpr_str3, 58, "` is not read: escape only what is not a letter or a digit");

HeffT3 g_regex_2eclassFrom_2eclassRune_240_24cpr(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_i_241, 1)) {
    heff_drop(v_i_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassFrom_2eclassRune_240_24cpr_str0), MK_INT(0LL)}});
  } else {
    if (!(heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)92ULL))) {
      HeffT2 v_t_242 = heff_strRuneDecode_lent(v_s_240, v_i_241, 0);
      {
        V v_rune_243 = v_t_242.f[0];
        V v_width_244 = v_t_242.f[1];
        V v_f_245 = heff_runeToInt(v_rune_243);
        V v_f_246 = heff_intAdd(v_i_241, v_width_244);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_245, v_f_246}});
      }
    } else {
      if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd_lent(v_i_241, MK_INT(1LL), 2))) {
        heff_drop(v_i_241);
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassFrom_2eclassRune_240_24cpr_str1), MK_INT(0LL)}});
      } else {
        V v_t_247 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2);
        V v_x_248 = (g_regex_2econtrolEscape(v_t_247));
        if (heff_intLe_c(MK_INT(0LL), v_x_248)) {
          V v_t_249 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2);
          V v_t_2410 = (g_regex_2econtrolEscape(v_t_249));
          V v_f_2411 = heff_intAdd(v_i_241, MK_INT(2LL));
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2410, v_f_2411}});
        } else {
          V v_c_2412 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2);
          if ((((((int64_t)48ULL) <= heff_peek_word(v_c_2412)) && (heff_peek_word(v_c_2412) <= ((int64_t)57ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_2412)) && (heff_peek_word(v_c_2412) <= ((int64_t)90ULL))) || ((((int64_t)97ULL) <= heff_peek_word(v_c_2412)) && (heff_peek_word(v_c_2412) <= ((int64_t)122ULL)))))) {
            heff_drop(v_c_2412);
            V v_i_2413 = heff_intAdd(v_i_241, MK_INT(1LL));
            V v_t_2414 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_2413), heff_intAdd(v_i_2413, MK_INT(1LL)));
            V v_f_2415 = heff_strAppend(heff_strAppend(((V)&g_regex_2eclassFrom_2eclassRune_240_24cpr_str2), v_t_2414), ((V)&g_regex_2eclassFrom_2eclassRune_240_24cpr_str3));
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2415, MK_INT(0LL)}});
          } else {
            heff_drop(v_c_2412);
            V v_i_2416 = heff_intAdd(v_i_241, MK_INT(1LL));
            HeffT2 v_t_2417 = heff_strRuneDecode_lent(v_s_240, v_i_2416, 0);
            {
              V v_rune_2418 = v_t_2417.f[0];
              V v_width_2419 = v_t_2417.f[1];
              V v_f_2420 = heff_runeToInt(v_rune_2418);
              V v_f_2421 = heff_intAdd(v_i_2416, v_width_2419);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_2420, v_f_2421}});
            }
          }
        }
      }
    }
  }
}