// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
HeffT2 g_regex_2eclassFrom_2eclassRune_240_24cpr(V, V);
V g_regex_2econtrolEscape(V);
V g_regex_2econtrolEscape_entry(V self, V *a);
extern Clo g_regex_2econtrolEscape_clo;
HEFF_LIT(g_regex_2eclassFrom_2eclassRune_240_24cpr_str0, 17, "a `[` with no `]`");
HEFF_LIT(g_regex_2eclassFrom_2eclassRune_240_24cpr_str1, 16, "a `\\` at the end");
HEFF_LIT(g_regex_2eclassFrom_2eclassRune_240_24cpr_str2, 2, "`\\");
HEFF_LIT(g_regex_2eclassFrom_2eclassRune_240_24cpr_str3, 58, "` is not read: escape only what is not a letter or a digit");

HeffT2 g_regex_2eclassFrom_2eclassRune_240_24cpr(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassFrom_2eclassRune_240_24cpr_str0)}});
  } else {
    if (!(heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)92ULL))) {
      HeffT2 v_t_242 = heff_strRuneDecode_lent(v_s_240, v_i_241, 0);
      {
        V v_rune_243 = v_t_242.f[0];
        V v_width_244 = v_t_242.f[1];
        V v_t_245 = heff_runeToInt(v_rune_243);
        V v_t_246 = heff_intAdd(v_i_241, v_width_244);
        V v_f_247 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_246});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_247}});
      }
    } else {
      if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) {
        heff_drop(v_i_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassFrom_2eclassRune_240_24cpr_str1)}});
      } else {
        V v_t_248 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
        V v_x_249 = (g_regex_2econtrolEscape(v_t_248));
        if (heff_intLe_c(MK_INT(0LL), v_x_249)) {
          V v_t_2410 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
          V v_t_2411 = (g_regex_2econtrolEscape(v_t_2410));
          V v_f_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, heff_intAdd(v_i_241, MK_INT(2LL))});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2412}});
        } else {
          V v_c_2413 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
          if ((((((int64_t)48ULL) <= heff_peek_word(v_c_2413)) && (heff_peek_word(v_c_2413) <= ((int64_t)57ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_2413)) && (heff_peek_word(v_c_2413) <= ((int64_t)90ULL))) || ((((int64_t)97ULL) <= heff_peek_word(v_c_2413)) && (heff_peek_word(v_c_2413) <= ((int64_t)122ULL)))))) {
            heff_drop(v_c_2413);
            V v_i_2414 = heff_intAdd(v_i_241, MK_INT(1LL));
            V v_t_2415 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_2414), heff_intAdd(v_i_2414, MK_INT(1LL)));
            V v_f_2416 = heff_strAppend(heff_strAppend(((V)&g_regex_2eclassFrom_2eclassRune_240_24cpr_str2), v_t_2415), ((V)&g_regex_2eclassFrom_2eclassRune_240_24cpr_str3));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
          } else {
            heff_drop(v_c_2413);
            V v_i_2417 = heff_intAdd(v_i_241, MK_INT(1LL));
            HeffT2 v_t_2418 = heff_strRuneDecode_lent(v_s_240, v_i_2417, 0);
            {
              V v_rune_2419 = v_t_2418.f[0];
              V v_width_2420 = v_t_2418.f[1];
              V v_t_2421 = heff_runeToInt(v_rune_2419);
              V v_t_2422 = heff_intAdd(v_i_2417, v_width_2420);
              V v_f_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, v_t_2422});
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2423}});
            }
          }
        }
      }
    }
  }
}