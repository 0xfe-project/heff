// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_bytes_2eempty_get(void);

static V g_bytes_2eempty_val;
static HEFF_ONCE g_bytes_2eempty_st;
static V g_bytes_2eempty_init(void) {
  return heff_bytesFromList(NTAG(TAG_Nil));
}
V g_bytes_2eempty_get(void) {
  if (HEFF_DONE(g_bytes_2eempty_st)) return g_bytes_2eempty_val;
  return heff_global(&g_bytes_2eempty_val, &g_bytes_2eempty_st, g_bytes_2eempty_init);
}