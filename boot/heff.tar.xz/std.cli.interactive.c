// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Among 19600
#define TAG_ArrowDown 21357
#define TAG_ArrowLeft 52976
#define TAG_ArrowRight 29566
#define TAG_ArrowUp 57900
#define TAG_BackTab 60780
#define TAG_Backspace 1027
#define TAG_Bold 53386
#define TAG_Char 10597
#define TAG_Continue 52606
#define TAG_Control 37853
#define TAG_Delete 50238
#define TAG_Dim 16148
#define TAG_Dirs 41877
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Enter 13030
#define TAG_Escape 55216
#define TAG_Files 59123
#define TAG_Flagged 28540
#define TAG_Home 35586
#define TAG_Inverse 25398
#define TAG_Many 40086
#define TAG_None 17785
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_PageDown 11812
#define TAG_PageUp 3752
#define TAG_Picked 5619
#define TAG_Plain 3036
#define TAG_Positional 16703
#define TAG_Rest 61983
#define TAG_Sequence 46672
#define TAG_Some 35658
#define TAG_Tab 31265
#define TAG_Typed 36072
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_columns 1181578779
#define LBL_complete 145693389
#define LBL_cursor 598022785
#define LBL_doc 309170
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_filter 672649891
#define LBL_flags 298871457
#define LBL_form 9644427
#define LBL_input 301716452
#define LBL_long 9823043
#define LBL_menu 9843238
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_options 1129866465
#define LBL_part 9928890
#define LBL_pos 320718
#define LBL_prog 9945121
#define LBL_required 351999471
#define LBL_rows 10002080
#define LBL_shape 310758331
#define LBL_short 310771862
#define LBL_slots 310891087
#define LBL_style 311138763
#define LBL_text 10052084
#define LBL_typing 1088343202
#define LBL_values 1123329101
static uint32_t shape_entry__slots__at[] = {LBL_entry, LBL_slots, LBL_at};
static uint32_t shape_options__at[] = {LBL_options, LBL_at};
static uint32_t shape_part__input[] = {LBL_part, LBL_input};
static uint32_t shape_prog__entries__filter__typing__menu__form[] = {LBL_prog, LBL_entries, LBL_filter, LBL_typing, LBL_menu, LBL_form};
static uint32_t shape_rows__cursor[] = {LBL_rows, LBL_cursor};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_list_2eany_24s317268364x1703376737(V);
V g_list_2eany_24s317268364x1703376737_entry(V self, V *a);
extern Clo g_list_2eany_24s317268364x1703376737_clo;
V g_list_2eany_24s624430845x1248965393(V);
V g_list_2eany_24s624430845x1248965393_entry(V self, V *a);
extern Clo g_list_2eany_24s624430845x1248965393_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24f1084934118x784646860(V, V, V, V, V);
V g_list_2efoldl_24f1084934118x784646860_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1084934118x784646860_clo;
V g_list_2efoldl_24f1563799791x267609364(V, V);
V g_list_2efoldl_24f1563799791x267609364_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1563799791x267609364_clo;
V g_list_2efoldl_24f1763211578x1610911617(V, V, V, V, V, V);
V g_list_2efoldl_24f1763211578x1610911617_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1763211578x1610911617_clo;
V g_list_2efoldl_24f545139853x5269120(V, V);
V g_list_2efoldl_24f545139853x5269120_entry(V self, V *a);
extern Clo g_list_2efoldl_24f545139853x5269120_clo;
V g_list_2efoldl_24f547094838x440994078(V, V, V);
V g_list_2efoldl_24f547094838x440994078_entry(V self, V *a);
extern Clo g_list_2efoldl_24f547094838x440994078_clo;
V g_list_2efoldl_24s1396019640x159929943(V, V, V);
V g_list_2efoldl_24s1396019640x159929943_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1396019640x159929943_clo;
V g_list_2efoldl_24s1722219619x1576677028(V, V);
V g_list_2efoldl_24s1722219619x1576677028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1722219619x1576677028_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s6718001x1068992521(V, V, V);
V g_list_2efoldl_24s6718001x1068992521_entry(V self, V *a);
extern Clo g_list_2efoldl_24s6718001x1068992521_clo;
V g_list_2ekeepIf_24s1252894891x837498180(V, V, V, V);
V g_list_2ekeepIf_24s1252894891x837498180_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1252894891x837498180_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1511070573x340395911(V, V, V);
V g_list_2emap_24f1511070573x340395911_entry(V self, V *a);
extern Clo g_list_2emap_24f1511070573x340395911_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s1539380703x380520933(V);
V g_list_2emap_24s1539380703x380520933_entry(V self, V *a);
extern Clo g_list_2emap_24s1539380703x380520933_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s456747242x756515627(V);
V g_list_2emap_24s456747242x756515627_entry(V self, V *a);
extern Clo g_list_2emap_24s456747242x756515627_clo;
V g_list_2emap_24s865484684x739952503(V);
V g_list_2emap_24s865484684x739952503_entry(V self, V *a);
extern Clo g_list_2emap_24s865484684x739952503_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2ewords_2ewordsFrom_240(V, V, V, V);
V g_prelude_2ewords_2ewordsFrom_240_entry(V self, V *a);
extern Clo g_prelude_2ewords_2ewordsFrom_240_clo;
V g_std_2ecli_2einteractive_2eflagWord(V, V);
V g_std_2ecli_2einteractive_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eflagWord_clo;
V g_std_2ecli_2einteractive_2eformStep(V, V, V);
V g_std_2ecli_2einteractive_2eformStep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformStep_clo;
V g_std_2ecli_2einteractive_2eformView(V, V, V);
V g_std_2ecli_2einteractive_2eformView_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformView_clo;
V g_std_2ecli_2einteractive_2eformWords(V);
V g_std_2ecli_2einteractive_2eformWords_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformWords_clo;
V g_std_2ecli_2einteractive_2elistStep(V, V);
V g_std_2ecli_2einteractive_2elistStep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2elistStep_clo;
V g_std_2ecli_2einteractive_2elistView(V, V);
V g_std_2ecli_2einteractive_2elistView_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2elistView_clo;
V g_std_2ecli_2einteractive_2emoved(V, V);
V g_std_2ecli_2einteractive_2emoved_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2emoved_clo;
V g_std_2ecli_2einteractive_2epartLabel(V);
V g_std_2ecli_2einteractive_2epartLabel_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epartLabel_clo;
V g_std_2ecli_2einteractive_2epartSaid(V);
V g_std_2ecli_2einteractive_2epartSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epartSaid_clo;
V g_std_2ecli_2einteractive_2eposWords(V, V);
V g_std_2ecli_2einteractive_2eposWords_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eposWords_clo;
V g_std_2ecli_2einteractive_2eslotRows(V, V, V, V);
V g_std_2ecli_2einteractive_2eslotRows_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotRows_clo;
V g_std_2ecli_2einteractive_2eslotRows_24dps(V, V, V, V, V);
V g_std_2ecli_2einteractive_2eslotRows_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotRows_24dps_clo;
V g_std_2ecli_2einteractive_2eslotStep(V, V, V);
V g_std_2ecli_2einteractive_2eslotStep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotStep_clo;
V g_std_2ecli_2einteractive_2estep(V, V);
V g_std_2ecli_2einteractive_2estep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2estep_clo;
V g_std_2ecli_2einteractive_2eswitchOptions_get(void);
V g_std_2ecli_2einteractive_2etypedOnList(V, V);
V g_std_2ecli_2einteractive_2etypedOnList_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2etypedOnList_clo;
V g_std_2ecli_2einteractive_2etypedOnList_24tok1(V, V, V);
V g_std_2ecli_2einteractive_2etypedOnList_24tok1_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2etypedOnList_24tok1_clo;
V g_std_2ecli_2einteractive_2eupdateAt(V, V, V);
V g_std_2ecli_2einteractive_2eupdateAt_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eupdateAt_clo;
V g_std_2ecli_2einteractive_2eupdateAt_24dps(V, V, V, V);
V g_std_2ecli_2einteractive_2eupdateAt_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eupdateAt_24dps_clo;
V g_std_2ecli_2einteractive_2eview(V, V);
V g_std_2ecli_2einteractive_2eview_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eview_clo;
HeffT2 g_std_2ecli_2eproblemOf_24cpr(V, V);
V g_std_2ecli_2eproblemSaid(V);
V g_std_2ecli_2eproblemSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2eproblemSaid_clo;
V g_std_2eterminal_2ewidget_2ebold(V);
V g_std_2eterminal_2ewidget_2ebold_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ebold_clo;
V g_std_2eterminal_2ewidget_2echoiceKey(V, V);
V g_std_2eterminal_2ewidget_2echoiceKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2echoiceKey_clo;
V g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614(V, V, V, V);
V g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_clo;
V g_std_2eterminal_2ewidget_2econtrolMove(V, V, V);
V g_std_2eterminal_2ewidget_2econtrolMove_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2econtrolMove_clo;
V g_std_2eterminal_2ewidget_2efieldKey(V, V);
V g_std_2eterminal_2ewidget_2efieldKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2efieldKey_clo;
V g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(V, V);
V g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734_clo;
V g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_get(void);
V g_std_2eterminal_2ewidget_2einverse(V);
V g_std_2eterminal_2ewidget_2einverse_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2einverse_clo;
V g_std_2eterminal_2ewidget_2emenu_get(void);
V g_std_2eterminal_2ewidget_2emenuKey(V, V, V);
V g_std_2eterminal_2ewidget_2emenuKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuKey_clo;
V g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240(V, V, V);
V g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_clo;
V g_std_2eterminal_2ewidget_2epad(V, V);
V g_std_2eterminal_2ewidget_2epad_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2epad_clo;
V g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240(V, V, V);
V g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_clo;
HEFF_LIT(g_std_2ecli_2einteractive_2eswitchOptions_str0, 2, "on");
HEFF_LIT(g_std_2ecli_2einteractive_2eswitchOptions_str1, 3, "off");

static V g_std_2ecli_2einteractive_2eswitchOptions_val;
static HEFF_ONCE g_std_2ecli_2einteractive_2eswitchOptions_st;
static V g_std_2ecli_2einteractive_2eswitchOptions_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2einteractive_2eswitchOptions_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2einteractive_2eswitchOptions_str1), v_t_240});
}
V g_std_2ecli_2einteractive_2eswitchOptions_get(void) {
  if (HEFF_DONE(g_std_2ecli_2einteractive_2eswitchOptions_st)) return g_std_2ecli_2einteractive_2eswitchOptions_val;
  return heff_global(&g_std_2ecli_2einteractive_2eswitchOptions_val, &g_std_2ecli_2einteractive_2eswitchOptions_st, g_std_2ecli_2einteractive_2eswitchOptions_init);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eposWords_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eposWords_str1, 0, "");
Clo g_std_2ecli_2einteractive_2eposWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eposWords_entry, 2, 0};

V g_std_2ecli_2einteractive_2eposWords(V v_a_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_a_240)) {
  case TAG_One: {
    V v_t_242 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
    V v_t_244 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_243), MK_INT(-1LL)));
    V v_t_245 = heff_strSlice(heff_dup(v_t_241), v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
    if (heff_strEq_c(v_t_245, ((V)&g_std_2ecli_2einteractive_2eposWords_str0))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_246 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
      V v_t_248 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_247), MK_INT(-1LL)));
      V v_t_249 = heff_strSlice(heff_dup(v_t_241), v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    }
  }
  case TAG_Optional: {
    V v_t_2410 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
    V v_t_2412 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_2411), MK_INT(-1LL)));
    V v_t_2413 = heff_strSlice(heff_dup(v_t_241), v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
    if (heff_strEq_c(v_t_2413, ((V)&g_std_2ecli_2einteractive_2eposWords_str1))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_2414 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
      V v_t_2416 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_2415), MK_INT(-1LL)));
      V v_t_2417 = heff_strSlice(heff_dup(v_t_241), v_t_2414, heff_intAdd(v_t_2416, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    }
  }
  case TAG_Many: {
    return (g_prelude_2ewords_2ewordsFrom_240(v_t_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  }
  case TAG_Some: {
    return (g_prelude_2ewords_2ewordsFrom_240(v_t_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  }
  case TAG_Rest: {
    return (g_prelude_2ewords_2ewordsFrom_240(v_t_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_a_240);
  }
}
V g_std_2ecli_2einteractive_2eposWords_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ecli_2einteractive_2eposWords(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str1, 2, "on");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str2, 2, "--");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str3, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str4, 2, "--");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str5, 1, "=");
Clo g_std_2ecli_2einteractive_2eflagWord_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eflagWord_entry, 2, 0};

V g_std_2ecli_2einteractive_2eflagWord(V v_f_240, V v_v_241) {
top: ;
  V v_meta_242 = heff_take_field(v_f_240, 2);
  V v_long_243 = heff_get_n(v_f_240, 0, 8);
  if (heff_strEq_c(v_meta_242, ((V)&g_std_2ecli_2einteractive_2eflagWord_str0))) {
    if (heff_strEq_c(v_v_241, ((V)&g_std_2ecli_2einteractive_2eflagWord_str1))) {
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2einteractive_2eflagWord_str2), v_long_243), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_long_243);
      return NTAG(TAG_Nil);
    }
  } else {
    if (heff_strEq_c_lent(v_v_241, ((V)&g_std_2ecli_2einteractive_2eflagWord_str3), 2)) {
      heff_drop(v_v_241);
      heff_drop(v_long_243);
      return NTAG(TAG_Nil);
    } else {
      V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2eflagWord_str4), v_long_243), ((V)&g_std_2ecli_2einteractive_2eflagWord_str5));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_244, v_v_241), NTAG(TAG_Nil)});
    }
  }
}
V g_std_2ecli_2einteractive_2eflagWord_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eflagWord(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eformWords_str0, 2, "--");
Clo g_std_2ecli_2einteractive_2eformWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformWords_entry, 1, 0};

V g_std_2ecli_2einteractive_2eformWords(V v_fm_240) {
top: ;
  V v_entry_241 = heff_take_field(v_fm_240, 0);
  V v_slots_242 = heff_get_n(v_fm_240, 1, 3);
  V v_t_243 = heff_get_n(heff_get_n(v_entry_241, 2, 3), 1, 2);
  V v_rest_244 = ({ V a_0 = v_t_243; V r_ = (g_list_2eany_24s624430845x1248965393(a_0)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_list_2efoldl_24f1563799791x267609364(NTAG(TAG_Nil), heff_dup(v_slots_242)));
  V v_ps_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1722219619x1576677028(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_list_2efoldl_24f545139853x5269120(NTAG(TAG_Nil), v_slots_242));
  V v_fs_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1722219619x1576677028(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_list_2eany_24s317268364x1703376737(v_ps_246));
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_rest_244);
    heff_drop(v_t_249);
    return (g_prelude_2e_2b_2b(v_fs_248, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2einteractive_2eformWords_str0), v_ps_246})));
  } else {
    heff_drop(v_t_249);
    if ((heff_dup(v_rest_244) == NTAG(TAG_True))) {
      heff_drop(v_rest_244);
      return (g_prelude_2e_2b_2b(v_fs_248, v_ps_246));
    } else {
      heff_drop(v_rest_244);
      return (g_prelude_2e_2b_2b(v_ps_246, v_fs_248));
    }
  }
}
V g_std_2ecli_2einteractive_2eformWords_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformWords(a[0]);
}
Clo g_std_2ecli_2einteractive_2emoved_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2emoved_entry, 2, 0};

V g_std_2ecli_2einteractive_2emoved(V v_k_240, V v_m_241) {
top: ;
  V v_t_242 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = heff_dup(v_m_241); V b_4 = MK_INT(0LL); V a_5 = heff_rfield(v_m_241, 1); V r_ = (g_list_2efoldl_24f1763211578x1610911617(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(b_4); r_; });
  V v_t_243 = (g_std_2eterminal_2ewidget_2emenuKey(v_t_242, v_k_240, heff_take_field(v_m_241, 4)));
  V v_t_244 = ({ V rv_4 = v_t_243; V rr_ = heff_rec_reuse_nf(v_m_241, 47ULL, 6, shape_prog__entries__filter__typing__menu__form, 3327u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  return heff_tag_n(TAG_Continue, 1, (V[]){v_t_244});
}
V g_std_2ecli_2einteractive_2emoved_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2emoved(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2ecli_2einteractive_2etypedOnList_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2etypedOnList_entry, 2, 0};

V g_std_2ecli_2einteractive_2etypedOnList(V v_c_240, V v_m_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_m_241, 3));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_f_243 = (g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(v_c_240, heff_take_field(v_m_241, 2)));
    V v_t_244 = heff_take_field(v_m_241, 3);
    V v_t_248;
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      v_t_248 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = heff_dup(heff_rfield(v_f_243, 0));
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nil: {
        v_t_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_245, 0ULL, 2);
        v_t_248 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
    }
    V v_t_249 = ({ V rv_2 = v_f_243; V rv_3 = v_t_248; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_249});
  } else {
    heff_drop(v_t_242);
    if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(113LL))) {
      heff_drop(v_c_240);
      heff_drop_rec(v_m_241, 6);
      return heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
    } else {
      if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(106LL))) {
        heff_drop(v_c_240);
        return ({ V b_0 = NTAG(TAG_ArrowDown); V a_1 = v_m_241; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
      } else {
        if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(107LL))) {
          heff_drop(v_c_240);
          return ({ V b_0 = NTAG(TAG_ArrowUp); V a_1 = v_m_241; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
        } else {
          if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(47LL))) {
            heff_drop(v_c_240);
            V v_t_2410 = ({ V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_m_241, 55ULL, 6, shape_prog__entries__filter__typing__menu__form, 3903u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
            return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2410});
          } else {
            V v_f_2411 = (g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(v_c_240, heff_take_field(v_m_241, 2)));
            V v_t_2412 = heff_take_field(v_m_241, 3);
            V v_t_2416;
            if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
              heff_drop(v_t_2412);
              v_t_2416 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2412);
              V v_t_2413 = heff_dup(heff_rfield(v_f_2411, 0));
              switch (heff_tag_of(v_t_2413)) {
              case TAG_Nil: {
                v_t_2416 = NTAG(TAG_False);
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_t_2413, 0ULL, 2);
                v_t_2416 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_t_2413);
              }
            }
            V v_t_2417 = ({ V rv_2 = v_f_2411; V rv_3 = v_t_2416; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
            return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2417});
          }
        }
      }
    }
  }
}
V g_std_2ecli_2einteractive_2etypedOnList_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2etypedOnList(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2elistStep_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2elistStep_str1, 0, "");
Clo g_std_2ecli_2einteractive_2elistStep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2elistStep_entry, 2, 0};

V g_std_2ecli_2einteractive_2elistStep(V v_k_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    V v_c_242 = heff_field(v_k_240, 0);
    V v_ru_24k_240_24Char = heff_take_reuse_n(v_k_240, 1ULL, 1);
    return (g_std_2ecli_2einteractive_2etypedOnList_24tok1(v_ru_24k_240_24Char, v_c_242, v_m_241));
  }
  case TAG_Enter: {
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_m_241, 4)), 0, 1);
    V v_t_244 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s1252894891x837498180(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
    HeffT3 v_t_245 = ({ V a_0 = v_t_243; V a_1 = v_t_244; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      V v_field_248 = v_t_245.f[2];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        V v_x12_2410 = v_field_248;
        heff_drop(v_x12_2410);
        V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_x_249, 2)), 1, 2);
        V v_t_2412 = (g_list_2emap_24s1539380703x380520933(v_t_2411));
        V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_x_249, 2)), 0, 2);
        V v_t_2414 = (g_list_2emap_24s456747242x756515627(v_t_2413));
        V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2414));
        V v_t_2416 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_entry__slots__at, (V[]){v_x_249, v_t_2415, MK_INT(0LL)})});
        V v_t_2417 = ({ V rv_5 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2417});
      } else {
        heff_drop(v_field_247);
        heff_drop(v_field_248);
        return heff_tag_n(TAG_Continue, 1, (V[]){v_m_241});
      }
    }
  }
  case TAG_Escape: {
    V v_m_2418 = v_m_241;
    V v_t_2419 = heff_take_field(v_m_2418, 3);
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop(v_t_2419);
      V v_t_2420 = heff_take_field(v_m_2418, 0);
      V v_t_2421 = heff_take_field(v_m_2418, 1);
      V v_t_2422 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_std_2ecli_2einteractive_2elistStep_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_f_2423 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_std_2ecli_2einteractive_2elistStep_str1)), v_t_2422});
      V v_t_2424 = heff_dup(heff_rfield(v_f_2423, 0));
      V v_t_2427;
      switch (heff_tag_of(v_t_2424)) {
      case TAG_Nil: {
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2424, 0ULL, 2);
        v_t_2427 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2424);
      }
      V v_t_2428 = ({ V rv_0 = v_t_2420; V rv_1 = v_t_2421; V rv_2 = v_f_2423; V rv_3 = v_t_2427; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_2418, 32ULL, 6, shape_prog__entries__filter__typing__menu__form, 3072u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
      return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2428});
    } else {
      heff_drop_rec(v_m_2418, 6);
      heff_drop(v_t_2419);
      return heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
    }
  }
  case TAG_Tab: {
    V v_t_2429 = heff_get_n(heff_dup(heff_rfield(v_m_241, 4)), 0, 1);
    V v_t_2430 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s1252894891x837498180(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
    HeffT3 v_t_2431 = ({ V a_0 = v_t_2429; V a_1 = v_t_2430; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2430); r_; });
    {
      V v_field_2433 = v_t_2431.f[1];
      V v_field_2434 = v_t_2431.f[2];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        V v_x_2435 = v_field_2433;
        V v_x12_2436 = v_field_2434;
        heff_drop(v_x12_2436);
        V v_t_2437 = heff_get_n(heff_dup(heff_rfield(v_x_2435, 2)), 1, 2);
        V v_t_2438 = (g_list_2emap_24s1539380703x380520933(v_t_2437));
        V v_t_2439 = heff_get_n(heff_dup(heff_rfield(v_x_2435, 2)), 0, 2);
        V v_t_2440 = (g_list_2emap_24s456747242x756515627(v_t_2439));
        V v_t_2441 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2440));
        V v_t_2442 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_entry__slots__at, (V[]){v_x_2435, v_t_2441, MK_INT(0LL)})});
        V v_t_2443 = ({ V rv_5 = v_t_2442; V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2443});
      } else {
        heff_drop(v_field_2433);
        heff_drop(v_field_2434);
        return heff_tag_n(TAG_Continue, 1, (V[]){v_m_241});
      }
    }
  }
  case TAG_BackTab: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_Backspace: {
    V v_f_2444 = ({ V b_0 = NTAG(TAG_Backspace); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2445 = heff_take_field(v_m_241, 3);
    V v_t_2449;
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_t_2445);
      v_t_2449 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2445);
      V v_t_2446 = heff_dup(heff_rfield(v_f_2444, 0));
      switch (heff_tag_of(v_t_2446)) {
      case TAG_Nil: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2446, 0ULL, 2);
        v_t_2449 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2446);
      }
    }
    V v_t_2450 = ({ V rv_2 = v_f_2444; V rv_3 = v_t_2449; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2450});
  }
  case TAG_Delete: {
    V v_f_2451 = ({ V b_0 = NTAG(TAG_Delete); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2452 = heff_take_field(v_m_241, 3);
    V v_t_2456;
    if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
      heff_drop(v_t_2452);
      v_t_2456 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2452);
      V v_t_2453 = heff_dup(heff_rfield(v_f_2451, 0));
      switch (heff_tag_of(v_t_2453)) {
      case TAG_Nil: {
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2453, 0ULL, 2);
        v_t_2456 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2453);
      }
    }
    V v_t_2457 = ({ V rv_2 = v_f_2451; V rv_3 = v_t_2456; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2457});
  }
  case TAG_ArrowUp: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_ArrowDown: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_ArrowLeft: {
    V v_f_2458 = ({ V b_0 = NTAG(TAG_ArrowLeft); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2459 = heff_take_field(v_m_241, 3);
    V v_t_2463;
    if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
      heff_drop(v_t_2459);
      v_t_2463 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2459);
      V v_t_2460 = heff_dup(heff_rfield(v_f_2458, 0));
      switch (heff_tag_of(v_t_2460)) {
      case TAG_Nil: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2460, 0ULL, 2);
        v_t_2463 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2460);
      }
    }
    V v_t_2464 = ({ V rv_2 = v_f_2458; V rv_3 = v_t_2463; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2464});
  }
  case TAG_ArrowRight: {
    V v_f_2465 = ({ V b_0 = NTAG(TAG_ArrowRight); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2466 = heff_take_field(v_m_241, 3);
    V v_t_2470;
    if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
      heff_drop(v_t_2466);
      v_t_2470 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2466);
      V v_t_2467 = heff_dup(heff_rfield(v_f_2465, 0));
      switch (heff_tag_of(v_t_2467)) {
      case TAG_Nil: {
        v_t_2470 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2467, 0ULL, 2);
        v_t_2470 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2467);
      }
    }
    V v_t_2471 = ({ V rv_2 = v_f_2465; V rv_3 = v_t_2470; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2471});
  }
  case TAG_Home: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_End: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_PageUp: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_PageDown: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_Control: {
    V v_c_2472 = heff_field(v_k_240, 0);
    V v_ru_24k_240_24Control = heff_take_reuse_n(v_k_240, 1ULL, 1);
    V v_c_2473 = v_c_2472;
    V v_m_2474 = v_m_241;
    if ((heff_runeEq_c(heff_dup(v_c_2473), MK_INT(110LL)) || heff_runeEq_c(heff_dup(v_c_2473), MK_INT(112LL)))) {
      V v_lit_2475 = v_c_2473;
      V v_m_2476 = v_m_2474;
      V v_lit_2477 = v_lit_2475;
      V v_n_2478 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = heff_dup(v_m_2476); V b_4 = MK_INT(0LL); V a_5 = heff_rfield(v_m_2476, 1); V r_ = (g_list_2efoldl_24f1763211578x1610911617(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(b_4); r_; });
      V v_m_2479 = heff_take_field(v_m_2476, 4);
      V v_t_2480 = (g_std_2eterminal_2ewidget_2econtrolMove(v_n_2478, v_lit_2477, v_m_2479));
      V v_t_2481 = ({ V rv_4 = v_t_2480; V rr_ = heff_rec_reuse_nf(v_m_2476, 47ULL, 6, shape_prog__entries__filter__typing__menu__form, 3327u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_2481});
    } else {
      V v_f_2482 = heff_tr(heff_call(heff_dup(g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_get()), 2, (V[]){v_c_2473, heff_take_field(v_m_2474, 2)}));
      V v_t_2483 = heff_take_field(v_m_2474, 3);
      V v_t_2487;
      if ((heff_dup(v_t_2483) == NTAG(TAG_True))) {
        heff_drop(v_t_2483);
        v_t_2487 = NTAG(TAG_True);
      } else {
        heff_drop(v_t_2483);
        V v_t_2484 = heff_dup(heff_rfield(v_f_2482, 0));
        switch (heff_tag_of(v_t_2484)) {
        case TAG_Nil: {
          v_t_2487 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2484, 0ULL, 2);
          v_t_2487 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_t_2484);
        }
      }
      V v_t_2488 = ({ V rv_2 = v_f_2482; V rv_3 = v_t_2487; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_2474, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
      return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_2488});
    }
  }
  case TAG_Sequence: {
    return ({ V a_0 = v_k_240; V a_1 = v_m_241; V r_ = (g_std_2ecli_2einteractive_2emoved(a_0, a_1)); heff_drop_tag(v_k_240, 1); r_; });
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2ecli_2einteractive_2elistStep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2elistStep(a[0], a[1]);
}
Clo g_std_2ecli_2einteractive_2eupdateAt_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eupdateAt_entry, 3, 0};

V g_std_2ecli_2einteractive_2eupdateAt(V v_i_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_g_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      V v_t_245 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_243}));
      return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_xs_244});
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = (g_std_2ecli_2einteractive_2eupdateAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_g_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2einteractive_2eupdateAt_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eupdateAt(a[0], a[1], a[2]);
}
Clo g_std_2ecli_2einteractive_2eupdateAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eupdateAt_24dps_entry, 4, 0};

V g_std_2ecli_2einteractive_2eupdateAt_24dps(V v_i_240, V v_g_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_g_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_246 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_244}));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_xs_245}));
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_g_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_i_240 = t_0;
      v_g_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2einteractive_2eupdateAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eupdateAt_24dps(a[0], a[1], a[2], a[3]);
}
V g_std_2ecli_2einteractive_2eslotStep_lam0(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam1(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam2(V self, V *args);
Clo g_std_2ecli_2einteractive_2eslotStep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotStep_entry, 3, 0};

V g_std_2ecli_2einteractive_2eslotStep(V v_k_240, V v_m_241, V v_fm_242) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    V v_c_243 = heff_field(v_k_240, 0);
    V v_ru_24k_240_24Char = heff_take_reuse_n(v_k_240, 1ULL, 1);
    HeffT3 v_t_244 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
    V v_t_2413;
    {
      V v_field_246 = v_t_244.f[1];
      V v_field_247 = v_t_244.f[2];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_246;
        V v_x12_249 = v_field_247;
        heff_drop(v_x12_249);
        V v_t_2410 = heff_get_n(v_x_248, 1, 2);
        switch (heff_tag_of(v_t_2410)) {
        case TAG_Typed: {
          heff_take_n(v_t_2410, 0ULL, 1);
          v_t_2413 = NTAG(TAG_False);
          break;
        }
        case TAG_Picked: {
          heff_take_n(v_t_2410, 0ULL, 1);
          v_t_2413 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
      } else {
        heff_drop(v_field_246);
        heff_drop(v_field_247);
        v_t_2413 = NTAG(TAG_False);
      }
    }
    if (((heff_dup(v_t_2413) == NTAG(TAG_True)) && heff_runeEq_c(heff_dup(v_c_243), MK_INT(113LL)))) {
      heff_drop_rec(v_fm_242, 3);
      heff_drop(v_c_243);
      heff_drop(v_t_2413);
      V v_t_2414 = ({ V rv_5 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2414});
    } else {
      heff_drop(v_t_2413);
      HeffT3 v_t_2415 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
      V v_t_2424;
      {
        V v_field_2417 = v_t_2415.f[1];
        V v_field_2418 = v_t_2415.f[2];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_x_2419 = v_field_2417;
          V v_x12_2420 = v_field_2418;
          heff_drop(v_x12_2420);
          V v_t_2421 = heff_get_n(v_x_2419, 1, 2);
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Typed: {
            heff_take_n(v_t_2421, 0ULL, 1);
            v_t_2424 = NTAG(TAG_False);
            break;
          }
          case TAG_Picked: {
            heff_take_n(v_t_2421, 0ULL, 1);
            v_t_2424 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
        } else {
          heff_drop(v_field_2417);
          heff_drop(v_field_2418);
          v_t_2424 = NTAG(TAG_False);
        }
      }
      if (((heff_dup(v_t_2424) == NTAG(TAG_True)) && heff_runeEq_c(heff_dup(v_c_243), MK_INT(106LL)))) {
        heff_drop(v_c_243);
        heff_drop(v_t_2424);
        V v_t_2425 = heff_dup(heff_rfield(v_fm_242, 1));
        V v_t_2431;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_Nil: {
          v_t_2431 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2425, 0ULL, 2);
          V v_t_2428 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
          V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
          V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
          v_t_2431 = heff_intMod(heff_intAdd(v_t_2428, v_t_2429), v_t_2430);
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        V v_fm_2432 = ({ V rv_2 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2433 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2432}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2433});
      } else {
        heff_drop(v_t_2424);
        HeffT3 v_t_2434 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
        V v_t_2443;
        {
          V v_field_2436 = v_t_2434.f[1];
          V v_field_2437 = v_t_2434.f[2];
          int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
          if ((v_tag_2435 == ((int64_t)0ULL))) {
            V v_x_2438 = v_field_2436;
            V v_x12_2439 = v_field_2437;
            heff_drop(v_x12_2439);
            V v_t_2440 = heff_get_n(v_x_2438, 1, 2);
            switch (heff_tag_of(v_t_2440)) {
            case TAG_Typed: {
              heff_take_n(v_t_2440, 0ULL, 1);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_Picked: {
              heff_take_n(v_t_2440, 0ULL, 1);
              v_t_2443 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_t_2440);
            }
          } else {
            heff_drop(v_field_2436);
            heff_drop(v_field_2437);
            v_t_2443 = NTAG(TAG_False);
          }
        }
        if (((heff_dup(v_t_2443) == NTAG(TAG_True)) && heff_runeEq_c(heff_dup(v_c_243), MK_INT(107LL)))) {
          heff_drop(v_c_243);
          heff_drop(v_t_2443);
          V v_t_2444 = heff_dup(heff_rfield(v_fm_242, 1));
          V v_t_2450;
          switch (heff_tag_of(v_t_2444)) {
          case TAG_Nil: {
            v_t_2450 = MK_INT(0LL);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_t_2444, 0ULL, 2);
            V v_t_2447 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
            V v_t_2448 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
            V v_t_2449 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
            v_t_2450 = heff_intMod(heff_intAdd(v_t_2447, v_t_2448), v_t_2449);
            break;
          }
          default: heff_nomatch(v_t_2444);
          }
          V v_fm_2451 = ({ V rv_2 = v_t_2450; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_t_2452 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2451}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
          return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2452});
        } else {
          heff_drop(v_t_2443);
          V v_t_2476 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam0, 1, 1, (V[]){v_c_243}), heff_take_field(v_fm_242, 1)));
          V v_fm_2477 = ({ V rv_1 = v_t_2476; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2478 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2477}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
          return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2478});
        }
      }
    }
  }
  case TAG_Control: {
    V v_c_2479 = heff_field(v_k_240, 0);
    V v_ru_24k_240_24Control = heff_take_reuse_n(v_k_240, 1ULL, 1);
    if (heff_runeEq_c(heff_dup(v_c_2479), MK_INT(110LL))) {
      heff_drop(v_c_2479);
      V v_t_2480 = heff_dup(heff_rfield(v_fm_242, 1));
      V v_t_2486;
      switch (heff_tag_of(v_t_2480)) {
      case TAG_Nil: {
        v_t_2486 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2480, 0ULL, 2);
        V v_t_2483 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
        V v_t_2484 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
        V v_t_2485 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
        v_t_2486 = heff_intMod(heff_intAdd(v_t_2483, v_t_2484), v_t_2485);
        break;
      }
      default: heff_nomatch(v_t_2480);
      }
      V v_fm_2487 = ({ V rv_2 = v_t_2486; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2488 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2487}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_2488});
    } else {
      if (heff_runeEq_c(heff_dup(v_c_2479), MK_INT(112LL))) {
        heff_drop(v_c_2479);
        V v_t_2489 = heff_dup(heff_rfield(v_fm_242, 1));
        V v_t_2495;
        switch (heff_tag_of(v_t_2489)) {
        case TAG_Nil: {
          v_t_2495 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2489, 0ULL, 2);
          V v_t_2492 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
          V v_t_2493 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
          V v_t_2494 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
          v_t_2495 = heff_intMod(heff_intAdd(v_t_2492, v_t_2493), v_t_2494);
          break;
        }
        default: heff_nomatch(v_t_2489);
        }
        V v_fm_2496 = ({ V rv_2 = v_t_2495; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2497 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2496}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_2497});
      } else {
        V v_t_24106 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam1, 1, 1, (V[]){v_c_2479}), heff_take_field(v_fm_242, 1)));
        V v_fm_24107 = ({ V rv_1 = v_t_24106; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24108 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24107}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_24108});
      }
    }
  }
  default: {
    V v_t_24116 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam2, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24117 = ({ V rv_1 = v_t_24116; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24118 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24117}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24118});
  }
  }
}
V g_std_2ecli_2einteractive_2eslotStep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eslotStep(a[0], a[1], a[2]);
}
V g_std_2ecli_2einteractive_2eslotStep_lam0(V self, V *args) {
  V v_s_2453 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2454 = heff_take_field(v_s_2453, 1);
  V v_t_2475;
  switch (heff_tag_of(v_t_2454)) {
  case TAG_Typed: {
    V v_f_2455 = heff_field(v_t_2454, 0);
    V v_ru_24t_2454_24Typed = heff_take_reuse_n(v_t_2454, 1ULL, 1);
    V v_t_2456 = (g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(v_c_243, v_f_2455));
    v_t_2475 = heff_tag_at_n(v_ru_24t_2454_24Typed, TAG_Typed, 1, (V[]){v_t_2456});
    break;
  }
  case TAG_Picked: {
    V v_c_2457 = heff_field(v_t_2454, 0);
    V v_ru_24t_2454_24Picked = heff_take_reuse_n(v_t_2454, 1ULL, 1);
    V v_lit_2458 = v_c_243;
    V v_c_2459 = v_c_2457;
    V v_t_2474;
    if ((heff_runeEq_c(heff_dup(v_lit_2458), MK_INT(32LL)) || heff_runeEq_c(heff_dup(v_lit_2458), MK_INT(108LL)))) {
      heff_drop(v_lit_2458);
      V v_t_2460 = heff_dup(heff_rfield(v_c_2459, 0));
      V v_t_2466;
      switch (heff_tag_of(v_t_2460)) {
      case TAG_Nil: {
        v_t_2466 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2460, 0ULL, 2);
        V v_t_2463 = heff_intAdd(heff_dup(heff_rfield(v_c_2459, 1)), MK_INT(1LL));
        V v_t_2464 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_2459, 0)));
        V v_t_2465 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_2459, 0)));
        v_t_2466 = heff_intMod(heff_intAdd(v_t_2463, v_t_2464), v_t_2465);
        break;
      }
      default: heff_nomatch(v_t_2460);
      }
      v_t_2474 = ({ V rv_1 = v_t_2466; V rr_ = heff_rec_reuse_nf(v_c_2459, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    } else {
      if (heff_runeEq_c(v_lit_2458, MK_INT(104LL))) {
        V v_t_2467 = heff_dup(heff_rfield(v_c_2459, 0));
        V v_t_2473;
        switch (heff_tag_of(v_t_2467)) {
        case TAG_Nil: {
          v_t_2473 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2467, 0ULL, 2);
          V v_t_2470 = heff_intAdd(heff_dup(heff_rfield(v_c_2459, 1)), MK_INT(-1LL));
          V v_t_2471 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_2459, 0)));
          V v_t_2472 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_2459, 0)));
          v_t_2473 = heff_intMod(heff_intAdd(v_t_2470, v_t_2471), v_t_2472);
          break;
        }
        default: heff_nomatch(v_t_2467);
        }
        v_t_2474 = ({ V rv_1 = v_t_2473; V rr_ = heff_rec_reuse_nf(v_c_2459, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      } else {
        v_t_2474 = v_c_2459;
      }
    }
    v_t_2475 = heff_tag_at_n(v_ru_24t_2454_24Picked, TAG_Picked, 1, (V[]){v_t_2474});
    break;
  }
  default: heff_nomatch(v_t_2454);
  }
  return ({ V rv_1 = v_t_2475; V rr_ = heff_rec_reuse_nf(v_s_2453, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam1(V self, V *args) {
  V v_s_2498 = args[0];
  V v_c_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2499 = heff_take_field(v_s_2498, 1);
  V v_t_24105;
  switch (heff_tag_of(v_t_2499)) {
  case TAG_Typed: {
    V v_f_24100 = heff_field(v_t_2499, 0);
    V v_ru_24t_2499_24Typed = heff_take_reuse_n(v_t_2499, 1ULL, 1);
    V v_t_24101 = heff_tr(heff_call(heff_dup(g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_get()), 2, (V[]){v_c_2479, v_f_24100}));
    v_t_24105 = heff_tag_at_n(v_ru_24t_2499_24Typed, TAG_Typed, 1, (V[]){v_t_24101});
    break;
  }
  case TAG_Picked: {
    V v_c_24102 = heff_field(v_t_2499, 0);
    V v_ru_24t_2499_24Picked = heff_take_reuse_n(v_t_2499, 1ULL, 1);
    V v_lit_24103 = v_c_2479;
    heff_drop(v_lit_24103);
    V v_c_24104 = v_c_24102;
    v_t_24105 = heff_tag_at_n(v_ru_24t_2499_24Picked, TAG_Picked, 1, (V[]){v_c_24104});
    break;
  }
  default: heff_nomatch(v_t_2499);
  }
  return ({ V rv_1 = v_t_24105; V rr_ = heff_rec_reuse_nf(v_s_2498, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam2(V self, V *args) {
  V v_s_24109 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24110 = heff_take_field(v_s_24109, 1);
  V v_t_24115;
  switch (heff_tag_of(v_t_24110)) {
  case TAG_Typed: {
    V v_f_24111 = heff_field(v_t_24110, 0);
    V v_ru_24t_24110_24Typed = heff_take_reuse_n(v_t_24110, 1ULL, 1);
    V v_t_24112 = ({ V a_0 = v_k_240; V a_1 = v_f_24111; V r_ = (g_std_2eterminal_2ewidget_2efieldKey(a_0, a_1)); heff_drop(v_k_240); r_; });
    v_t_24115 = heff_tag_at_n(v_ru_24t_24110_24Typed, TAG_Typed, 1, (V[]){v_t_24112});
    break;
  }
  case TAG_Picked: {
    V v_c_24113 = heff_field(v_t_24110, 0);
    V v_ru_24t_24110_24Picked = heff_take_reuse_n(v_t_24110, 1ULL, 1);
    V v_t_24114 = ({ V a_0 = v_k_240; V a_1 = v_c_24113; V r_ = (g_std_2eterminal_2ewidget_2echoiceKey(a_0, a_1)); heff_drop(v_k_240); r_; });
    v_t_24115 = heff_tag_at_n(v_ru_24t_24110_24Picked, TAG_Picked, 1, (V[]){v_t_24114});
    break;
  }
  default: heff_nomatch(v_t_24110);
  }
  return ({ V rv_1 = v_t_24115; V rr_ = heff_rec_reuse_nf(v_s_24109, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
Clo g_std_2ecli_2einteractive_2eformStep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformStep_entry, 3, 0};

V g_std_2ecli_2einteractive_2eformStep(V v_k_240, V v_m_241, V v_fm_242) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Enter: {
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 2, 3);
    V v_t_245 = (g_std_2ecli_2einteractive_2eformWords(heff_dup(v_fm_242)));
    HeffT2 v_t_246 = (g_std_2ecli_2eproblemOf_24cpr(v_t_244, v_t_245));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop_rec(v_fm_242, 3);
        V v_p_249 = v_field_248;
        heff_drop(v_p_249);
        return heff_tag_n(TAG_Continue, 1, (V[]){v_m_241});
      } else {
        heff_drop_rec(v_m_241, 6);
        heff_drop(v_field_248);
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 0, 3);
        V v_t_2411 = (g_std_2ecli_2einteractive_2eformWords(v_fm_242));
        V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2411})});
        return heff_tag_n(TAG_Done, 1, (V[]){v_t_2412});
      }
    }
  }
  case TAG_Escape: {
    heff_drop_rec(v_fm_242, 3);
    V v_t_2413 = ({ V rv_5 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2413});
  }
  case TAG_Tab: {
    V v_t_2414 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2420;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      v_t_2420 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2414, 0ULL, 2);
      V v_t_2417 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
      V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      v_t_2420 = heff_intMod(heff_intAdd(v_t_2417, v_t_2418), v_t_2419);
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_fm_2421 = ({ V rv_2 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2422 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2421}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2422});
  }
  case TAG_BackTab: {
    V v_t_2423 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2429;
    switch (heff_tag_of(v_t_2423)) {
    case TAG_Nil: {
      v_t_2429 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2423, 0ULL, 2);
      V v_t_2426 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
      V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      v_t_2429 = heff_intMod(heff_intAdd(v_t_2426, v_t_2427), v_t_2428);
      break;
    }
    default: heff_nomatch(v_t_2423);
    }
    V v_fm_2430 = ({ V rv_2 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2431 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2430}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2431});
  }
  case TAG_Backspace: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Delete: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_ArrowUp: {
    V v_t_2432 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2438;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nil: {
      v_t_2438 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2432, 0ULL, 2);
      V v_t_2435 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
      V v_t_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2437 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      v_t_2438 = heff_intMod(heff_intAdd(v_t_2435, v_t_2436), v_t_2437);
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    V v_fm_2439 = ({ V rv_2 = v_t_2438; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2440 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2439}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2440});
  }
  case TAG_ArrowDown: {
    V v_t_2441 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2447;
    switch (heff_tag_of(v_t_2441)) {
    case TAG_Nil: {
      v_t_2447 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2441, 0ULL, 2);
      V v_t_2444 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
      V v_t_2445 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      v_t_2447 = heff_intMod(heff_intAdd(v_t_2444, v_t_2445), v_t_2446);
      break;
    }
    default: heff_nomatch(v_t_2441);
    }
    V v_fm_2448 = ({ V rv_2 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2449 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2448}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2449});
  }
  case TAG_ArrowLeft: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_ArrowRight: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Home: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_End: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_PageUp: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_PageDown: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Control: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Sequence: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2ecli_2einteractive_2eformStep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformStep(a[0], a[1], a[2]);
}
Clo g_std_2ecli_2einteractive_2estep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2estep_entry, 2, 0};

V g_std_2ecli_2einteractive_2estep(V v_k_240, V v_m_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_m_241, 5));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    HEFF_LAST return g_std_2ecli_2einteractive_2elistStep(v_k_240, v_m_241);
  }
  case TAG_Just: {
    V v_fm_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    return (g_std_2ecli_2einteractive_2eformStep(v_k_240, v_m_241, v_fm_243));
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2ecli_2einteractive_2estep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2estep(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str0, 14, ": its commands");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str1, 8, "filter: ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str2, 71, "type to filter, \342\206\221 \342\206\223 or j k to move, Enter to fill one in, q to quit");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str3, 2, "  ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str4, 23, "no command's name has `");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str5, 7, "` in it");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str6, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str7, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str8, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str9, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str10, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str11, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str12, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str13, 1, " ");
V g_std_2ecli_2einteractive_2elistView_lam0(V self, V *args);
Clo g_std_2ecli_2einteractive_2elistView_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2elistView_entry, 2, 0};

V g_std_2ecli_2einteractive_2elistView(V v_size_240, V v_m_241) {
top: ;
  V v_rows_242 = heff_take_field(v_size_240, 1);
  V v_columns_243 = heff_get_n(v_size_240, 0, 2);
  V v_h_244 = heff_intSub(heff_dup(v_rows_242), MK_INT(1LL));
  V v_t_245 = heff_rec_n(2, shape_text__style, (V[]){heff_dup(heff_rfield(v_m_241, 0)), NTAG(TAG_Bold)});
  V v_t_246 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str0), NTAG(TAG_Plain)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = heff_dup(heff_rfield(v_m_241, 3));
  V v_t_2414;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    V v_t_249 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str1), NTAG(TAG_Plain)});
    V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_m_241, 2)), 0, 2);
    V v_t_2411 = heff_rec_n(2, shape_text__style, (V[]){heff_strOfRunes(v_t_2410), NTAG(TAG_Plain)});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2412});
  } else {
    heff_drop(v_t_248);
    V v_t_2413 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str2), NTAG(TAG_Dim)});
    v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  }
  V v_h_2415 = heff_intSub(v_rows_242, MK_INT(4LL));
  V v_m_2416 = heff_dup(heff_rfield(v_m_241, 4));
  V v_t_2417 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s1252894891x837498180(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
  V v_w_2418 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2417; V r_ = (g_list_2efoldl_24s6718001x1068992521(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s1252894891x837498180(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
  V v_items_2428 = (g_list_2emap(heff_clo_n(g_std_2ecli_2einteractive_2elistView_lam0, 1, 1, (V[]){v_w_2418}), v_t_2419));
  V v_t_2430;
  if (heff_intLt_c(heff_dup(heff_rfield(v_m_2416, 0)), heff_dup(v_h_2415))) {
    v_t_2430 = MK_INT(0LL);
  } else {
    V v_t_2429 = heff_intSub(heff_dup(heff_rfield(v_m_2416, 0)), heff_dup(v_h_2415));
    v_t_2430 = heff_intAdd(v_t_2429, MK_INT(1LL));
  }
  V v_t_2431 = (g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240(heff_get_n(v_m_2416, 0, 1), MK_INT(0LL), v_items_2428));
  V v_t_2432 = ({ V a_0 = v_t_2430; V a_1 = v_t_2431; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2431); r_; });
  V v_t_2433 = (g_list_2etake(v_h_2415, v_t_2432));
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2433});
  V v_rs_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2434})});
  V v_t_2436 = (g_list_2ereplicate(heff_dup(v_h_244), NTAG(TAG_Nil)));
  V v_t_2437 = (g_prelude_2e_2b_2b(v_rs_2435, v_t_2436));
  V v_t_2438 = (g_list_2etake(v_h_244, v_t_2437));
  V v_m_2439 = heff_dup(v_m_241);
  V v_filter_2440 = heff_take_field(v_m_2439, 2);
  V v_prog_2441 = heff_get_n(v_m_2439, 0, 6);
  V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_m_241, 4)), 0, 1);
  V v_t_2443 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s1252894891x837498180(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
  HeffT3 v_t_2444 = ({ V a_0 = v_t_2442; V a_1 = v_t_2443; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2443); r_; });
  V v_x2_2450;
  {
    V v_field_2446 = v_t_2444.f[1];
    V v_field_2447 = v_t_2444.f[2];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    if ((v_tag_2445 == ((int64_t)0ULL))) {
      V v_x_2448 = v_field_2446;
      V v_x12_2449 = v_field_2447;
      heff_drop(v_x12_2449);
      v_x2_2450 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2448});
    } else {
      heff_drop(v_field_2446);
      heff_drop(v_field_2447);
      v_x2_2450 = NTAG(TAG_Nothing);
    }
  }
  V v_s_2481;
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_Nothing: {
    heff_drop(v_prog_2441);
    V v_t_2451 = heff_strOfRunes(heff_get_n(v_filter_2440, 0, 2));
    v_s_2481 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2elistView_str4), v_t_2451), ((V)&g_std_2ecli_2einteractive_2elistView_str5));
    break;
  }
  case TAG_Just: {
    V v_e_2452 = heff_field(v_x2_2450, 0);
    heff_take_n(v_x2_2450, 1ULL, 1);
    heff_drop_rec(v_filter_2440, 2);
    V v_name_2453 = heff_take_field(v_e_2452, 0);
    V v_shape_2454 = heff_get_n(v_e_2452, 2, 3);
    V v_t_2455 = heff_strAppend(heff_strAppend(v_prog_2441, ((V)&g_std_2ecli_2einteractive_2elistView_str6)), v_name_2453);
    V v_t_2456 = heff_dup(heff_rfield(v_shape_2454, 1));
    V v_t_2480;
    switch (heff_tag_of(v_t_2456)) {
    case TAG_Nil: {
      V v_t_2457 = heff_dup(heff_rfield(v_shape_2454, 0));
      switch (heff_tag_of(v_t_2457)) {
      case TAG_Nil: {
        heff_drop_rec(v_shape_2454, 2);
        v_t_2480 = ((V)&g_std_2ecli_2einteractive_2elistView_str7);
        break;
      }
      case TAG_Cons: {
        V v_ru_24t_2457_24Cons = heff_take_reuse_n(v_t_2457, 0ULL, 2);
        V v_sh_2460 = v_shape_2454;
        V v_pos_2461 = heff_take_field(v_sh_2460, 1);
        V v_flags_2462 = heff_get_n(v_sh_2460, 0, 2);
        V v_t_2463 = (g_list_2emap_24s2029999044x514618413(v_pos_2461));
        V v_t_2464 = (g_list_2emap_24s1281445768x1036802655(v_flags_2462));
        V v_xs_2465 = (g_prelude_2e_2b_2b_24tok2(v_ru_24t_2457_24Cons, v_t_2463, v_t_2464));
        V v_t_2468;
        switch (heff_tag_of(v_xs_2465)) {
        case TAG_Nil: {
          v_t_2468 = ((V)&g_std_2ecli_2einteractive_2elistView_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2466 = heff_field(v_xs_2465, 0);
          V v_xs_2467 = heff_field(v_xs_2465, 1);
          heff_take_n(v_xs_2465, 3ULL, 2);
          v_t_2468 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2elistView_str9); V a_1 = v_x_2466; V a_2 = v_xs_2467; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2467); r_; });
          break;
        }
        default: heff_nomatch(v_xs_2465);
        }
        v_t_2480 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2elistView_str10), v_t_2468);
        break;
      }
      default: heff_nomatch(v_t_2457);
      }
      break;
    }
    case TAG_Cons: {
      V v_ru_24t_2456_24Cons = heff_take_reuse_n(v_t_2456, 0ULL, 2);
      V v_sh_2471 = v_shape_2454;
      V v_pos_2472 = heff_take_field(v_sh_2471, 1);
      V v_flags_2473 = heff_get_n(v_sh_2471, 0, 2);
      V v_t_2474 = (g_list_2emap_24s2029999044x514618413(v_pos_2472));
      V v_t_2475 = (g_list_2emap_24s1281445768x1036802655(v_flags_2473));
      V v_xs_2476 = (g_prelude_2e_2b_2b_24tok2(v_ru_24t_2456_24Cons, v_t_2474, v_t_2475));
      V v_t_2479;
      switch (heff_tag_of(v_xs_2476)) {
      case TAG_Nil: {
        v_t_2479 = ((V)&g_std_2ecli_2einteractive_2elistView_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2477 = heff_field(v_xs_2476, 0);
        V v_xs_2478 = heff_field(v_xs_2476, 1);
        heff_take_n(v_xs_2476, 3ULL, 2);
        v_t_2479 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2elistView_str12); V a_1 = v_x_2477; V a_2 = v_xs_2478; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2478); r_; });
        break;
      }
      default: heff_nomatch(v_xs_2476);
      }
      v_t_2480 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2elistView_str13), v_t_2479);
      break;
    }
    default: heff_nomatch(v_t_2456);
    }
    v_s_2481 = heff_strAppend(v_t_2455, v_t_2480);
    break;
  }
  default: heff_nomatch(v_x2_2450);
  }
  V v_s_2482 = (g_std_2eterminal_2ewidget_2epad(v_columns_243, v_s_2481));
  V v_t_2483 = heff_rec_n(2, shape_text__style, (V[]){v_s_2482, NTAG(TAG_Inverse)});
  V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2483, NTAG(TAG_Nil)});
  V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
  V v_t_2486 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2485));
  V v_t_2487 = heff_take_field(v_m_241, 3);
  V v_t_2493;
  if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
    heff_drop(v_t_2487);
    V v_f_2488 = heff_get_n(v_m_241, 2, 6);
    V v_at_2489 = heff_take_field(v_f_2488, 1);
    V v_text_2490 = heff_get_n(v_f_2488, 0, 2);
    V v_t_2491 = ({ V a_0 = MK_INT(0LL); V a_1 = v_at_2489; V a_2 = v_text_2490; V r_ = (g_list_2efoldl_24f547094838x440994078(a_0, a_1, a_2)); heff_drop(v_text_2490); r_; });
    V v_t_2492 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_intAdd(MK_INT(8LL), v_t_2491), MK_INT(1LL)});
    v_t_2493 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2492});
  } else {
    heff_drop_rec(v_m_241, 6);
    heff_drop(v_t_2487);
    v_t_2493 = NTAG(TAG_Nothing);
  }
  return heff_rec_n(2, shape_rows__cursor, (V[]){v_t_2486, v_t_2493});
}
V g_std_2ecli_2einteractive_2elistView_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2elistView(a[0], a[1]);
}
V g_std_2ecli_2einteractive_2elistView_lam0(V self, V *args) {
  V v_e_2420 = args[0];
  V v_w_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_name_2421 = heff_take_field(v_e_2420, 0);
  V v_doc_2422 = heff_get_n(v_e_2420, 1, 3);
  V v_s_2423 = (g_std_2eterminal_2ewidget_2epad(v_w_2418, v_name_2421));
  V v_t_2424 = heff_rec_n(2, shape_text__style, (V[]){v_s_2423, NTAG(TAG_Bold)});
  V v_t_2425 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str3), NTAG(TAG_Plain)});
  V v_t_2426 = heff_rec_n(2, shape_text__style, (V[]){v_doc_2422, NTAG(TAG_Dim)});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_t_2427})});
}
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str0, 1, "[");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str1, 1, "]");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str2, 1, "[");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str3, 4, "...]");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str4, 3, "...");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str5, 1, "[");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str6, 4, "...]");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str7, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str8, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str9, 1, "-");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str10, 2, ", ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str11, 2, "--");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str12, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str13, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str14, 1, "=");
Clo g_std_2ecli_2einteractive_2epartLabel_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2epartLabel_entry, 1, 0};

V g_std_2ecli_2einteractive_2epartLabel(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Positional: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_meta_242 = heff_dup(heff_rfield(v_p_241, 0));
    V v_arity_243 = heff_dup(heff_rfield(v_p_241, 1));
    V v_m_244 = v_meta_242;
    switch (heff_tag_of(v_arity_243)) {
    case TAG_One: {
      return v_m_244;
    }
    case TAG_Optional: {
      return heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str0), v_m_244), ((V)&g_std_2ecli_2einteractive_2epartLabel_str1));
    }
    case TAG_Many: {
      return heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str2), v_m_244), ((V)&g_std_2ecli_2einteractive_2epartLabel_str3));
    }
    case TAG_Some: {
      return heff_strAppend(v_m_244, ((V)&g_std_2ecli_2einteractive_2epartLabel_str4));
    }
    case TAG_Rest: {
      return heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str5), v_m_244), ((V)&g_std_2ecli_2einteractive_2epartLabel_str6));
    }
    default: return heff_nomatch(v_arity_243);
    }
  }
  case TAG_Flagged: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_short_246 = heff_dup(heff_rfield(v_f_245, 1));
    V v_long_247 = heff_dup(heff_rfield(v_f_245, 0));
    V v_meta_248 = heff_dup(heff_rfield(v_f_245, 2));
    V v_t_249;
    if (heff_strEq_c_lent(v_short_246, ((V)&g_std_2ecli_2einteractive_2epartLabel_str7), 2)) {
      heff_drop(v_short_246);
      v_t_249 = ((V)&g_std_2ecli_2einteractive_2epartLabel_str8);
    } else {
      v_t_249 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str9), v_short_246), ((V)&g_std_2ecli_2einteractive_2epartLabel_str10));
    }
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_std_2ecli_2einteractive_2epartLabel_str11)), v_long_247);
    V v_t_2411;
    if (heff_strEq_c_lent(v_meta_248, ((V)&g_std_2ecli_2einteractive_2epartLabel_str12), 2)) {
      heff_drop(v_meta_248);
      v_t_2411 = ((V)&g_std_2ecli_2einteractive_2epartLabel_str13);
    } else {
      v_t_2411 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str14), v_meta_248);
    }
    return heff_strAppend(v_t_2410, v_t_2411);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2epartLabel_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2epartLabel(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRows_str0, 2, "> ");
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRows_str1, 2, "  ");
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRows_str2, 2, "  ");
Clo g_std_2ecli_2einteractive_2eslotRows_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotRows_entry, 4, 0};

V g_std_2ecli_2einteractive_2eslotRows(V v_w_240, V v_at_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    heff_drop(v_at_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x4_243, 0);
    V v_ss_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_w_246 = heff_dup(v_w_240);
    V v_on_247 = heff_bool(heff_intEq_c_lent(v_i_242, v_at_241, 0));
    V v_s_248 = v_s_244;
    V v_part_249 = heff_take_field(v_s_248, 0);
    V v_input_2410 = heff_get_n(v_s_248, 1, 2);
    V v_t_2411;
    if ((heff_dup(v_on_247) == NTAG(TAG_True))) {
      v_t_2411 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRows_str0), NTAG(TAG_Bold)});
    } else {
      v_t_2411 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRows_str1), NTAG(TAG_Plain)});
    }
    V v_t_2412 = (g_std_2ecli_2einteractive_2epartLabel(v_part_249));
    V v_s_2413 = (g_std_2eterminal_2ewidget_2epad(v_w_246, v_t_2412));
    V v_t_2414 = heff_rec_n(2, shape_text__style, (V[]){v_s_2413, NTAG(TAG_Plain)});
    V v_t_2415 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRows_str2), NTAG(TAG_Plain)});
    V v_on_2416 = v_on_247;
    V v_part_2417 = v_part_249;
    V v_x3_2418 = v_input_2410;
    V v_t_2435;
    switch (heff_tag_of(v_x3_2418)) {
    case TAG_Typed: {
      V v_t_2419 = heff_field(v_x3_2418, 0);
      heff_take_n(v_x3_2418, 1ULL, 1);
      if (!(heff_dup(v_on_2416) == NTAG(TAG_True))) {
        heff_drop(v_on_2416);
        V v_t_2420 = heff_dup(heff_rfield(v_t_2419, 0));
        switch (heff_tag_of(v_t_2420)) {
        case TAG_Nil: {
          heff_drop_rec(v_t_2419, 2);
          V v_t_2423;
          switch (heff_tag_of(v_part_2417)) {
          case TAG_Positional: {
            V v_p_2421 = heff_field(v_part_2417, 0);
            heff_take_n(v_part_2417, 1ULL, 1);
            v_t_2423 = heff_get_n(v_p_2421, 0, 3);
            break;
          }
          case TAG_Flagged: {
            V v_f_2422 = heff_field(v_part_2417, 0);
            heff_take_n(v_part_2417, 1ULL, 1);
            v_t_2423 = heff_get_n(v_f_2422, 2, 8);
            break;
          }
          default: heff_nomatch(v_part_2417);
          }
          V v_t_2424 = heff_rec_n(2, shape_text__style, (V[]){v_t_2423, NTAG(TAG_Dim)});
          v_t_2435 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2420, 0ULL, 2);
          heff_drop(v_part_2417);
          V v_t_2427 = heff_strOfRunes(heff_get_n(v_t_2419, 0, 2));
          V v_t_2428 = heff_rec_n(2, shape_text__style, (V[]){v_t_2427, NTAG(TAG_Plain)});
          v_t_2435 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_t_2420);
        }
      } else {
        heff_drop(v_on_2416);
        heff_drop(v_part_2417);
        V v_t_2429 = heff_strOfRunes(heff_get_n(v_t_2419, 0, 2));
        V v_t_2430 = heff_rec_n(2, shape_text__style, (V[]){v_t_2429, NTAG(TAG_Plain)});
        v_t_2435 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
      }
      break;
    }
    case TAG_Picked: {
      V v_c_2431 = heff_field(v_x3_2418, 0);
      heff_take_n(v_x3_2418, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_part_2417);
      V v_at_2432 = heff_take_field(v_c_2431, 1);
      V v_options_2433 = heff_get_n(v_c_2431, 0, 2);
      V v_t_2434;
      if ((heff_dup(v_on_2416) == NTAG(TAG_True))) {
        heff_drop(v_on_2416);
        v_t_2434 = ((V)&g_std_2eterminal_2ewidget_2einverse_clo);
      } else {
        heff_drop(v_on_2416);
        v_t_2434 = ((V)&g_std_2eterminal_2ewidget_2ebold_clo);
      }
      v_t_2435 = (g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614(v_t_2434, v_at_2432, MK_INT(0LL), v_options_2433));
      break;
    }
    default: heff_nomatch(v_x3_2418);
    }
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2435})});
    V v_cell_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2436}), heff_hole()});
    V v_u_2438 = (g_std_2ecli_2einteractive_2eslotRows_24dps(v_w_240, v_at_241, heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL))), v_ss_245, heff_dup(v_cell_2437)));
    heff_drop(v_u_2438);
    return v_cell_2437;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2ecli_2einteractive_2eslotRows_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eslotRows(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRows_24dps_str0, 2, "> ");
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRows_24dps_str1, 2, "  ");
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRows_24dps_str2, 2, "  ");
Clo g_std_2ecli_2einteractive_2eslotRows_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotRows_24dps_entry, 5, 0};

V g_std_2ecli_2einteractive_2eslotRows_24dps(V v_w_240, V v_at_241, V v_i_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    heff_drop(v_at_241);
    heff_drop(v_i_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_245 = heff_field(v_x4_243, 0);
    V v_ss_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_w_247 = heff_dup(v_w_240);
    V v_on_248 = heff_bool(heff_intEq_c_lent(v_i_242, v_at_241, 0));
    V v_s_249 = v_s_245;
    V v_part_2410 = heff_take_field(v_s_249, 0);
    V v_input_2411 = heff_get_n(v_s_249, 1, 2);
    V v_t_2412;
    if ((heff_dup(v_on_248) == NTAG(TAG_True))) {
      v_t_2412 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRows_24dps_str0), NTAG(TAG_Bold)});
    } else {
      v_t_2412 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRows_24dps_str1), NTAG(TAG_Plain)});
    }
    V v_t_2413 = (g_std_2ecli_2einteractive_2epartLabel(v_part_2410));
    V v_s_2414 = (g_std_2eterminal_2ewidget_2epad(v_w_247, v_t_2413));
    V v_t_2415 = heff_rec_n(2, shape_text__style, (V[]){v_s_2414, NTAG(TAG_Plain)});
    V v_t_2416 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRows_24dps_str2), NTAG(TAG_Plain)});
    V v_on_2417 = v_on_248;
    V v_part_2418 = v_part_2410;
    V v_x3_2419 = v_input_2411;
    V v_t_2436;
    switch (heff_tag_of(v_x3_2419)) {
    case TAG_Typed: {
      V v_t_2420 = heff_field(v_x3_2419, 0);
      heff_take_n(v_x3_2419, 1ULL, 1);
      if (!(heff_dup(v_on_2417) == NTAG(TAG_True))) {
        heff_drop(v_on_2417);
        V v_t_2421 = heff_dup(heff_rfield(v_t_2420, 0));
        switch (heff_tag_of(v_t_2421)) {
        case TAG_Nil: {
          heff_drop_rec(v_t_2420, 2);
          V v_t_2424;
          switch (heff_tag_of(v_part_2418)) {
          case TAG_Positional: {
            V v_p_2422 = heff_field(v_part_2418, 0);
            heff_take_n(v_part_2418, 1ULL, 1);
            v_t_2424 = heff_get_n(v_p_2422, 0, 3);
            break;
          }
          case TAG_Flagged: {
            V v_f_2423 = heff_field(v_part_2418, 0);
            heff_take_n(v_part_2418, 1ULL, 1);
            v_t_2424 = heff_get_n(v_f_2423, 2, 8);
            break;
          }
          default: heff_nomatch(v_part_2418);
          }
          V v_t_2425 = heff_rec_n(2, shape_text__style, (V[]){v_t_2424, NTAG(TAG_Dim)});
          v_t_2436 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2421, 0ULL, 2);
          heff_drop(v_part_2418);
          V v_t_2428 = heff_strOfRunes(heff_get_n(v_t_2420, 0, 2));
          V v_t_2429 = heff_rec_n(2, shape_text__style, (V[]){v_t_2428, NTAG(TAG_Plain)});
          v_t_2436 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_t_2421);
        }
      } else {
        heff_drop(v_on_2417);
        heff_drop(v_part_2418);
        V v_t_2430 = heff_strOfRunes(heff_get_n(v_t_2420, 0, 2));
        V v_t_2431 = heff_rec_n(2, shape_text__style, (V[]){v_t_2430, NTAG(TAG_Plain)});
        v_t_2436 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
      }
      break;
    }
    case TAG_Picked: {
      V v_c_2432 = heff_field(v_x3_2419, 0);
      heff_take_n(v_x3_2419, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_part_2418);
      V v_at_2433 = heff_take_field(v_c_2432, 1);
      V v_options_2434 = heff_get_n(v_c_2432, 0, 2);
      V v_t_2435;
      if ((heff_dup(v_on_2417) == NTAG(TAG_True))) {
        heff_drop(v_on_2417);
        v_t_2435 = ((V)&g_std_2eterminal_2ewidget_2einverse_clo);
      } else {
        heff_drop(v_on_2417);
        v_t_2435 = ((V)&g_std_2eterminal_2ewidget_2ebold_clo);
      }
      v_t_2436 = (g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614(v_t_2435, v_at_2433, MK_INT(0LL), v_options_2434));
      break;
    }
    default: heff_nomatch(v_x3_2419);
    }
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2436})});
    V v_cell_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2437}), heff_hole()});
    V v_u_2439 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2438));
    heff_drop(v_u_2439);
    V t_0 = v_w_240;
    V t_1 = v_at_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_ss_246;
    V t_4 = v_cell_2438;
    v_w_240 = t_0;
    v_at_241 = t_1;
    v_i_242 = t_2;
    v_x4_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2ecli_2einteractive_2eslotRows_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eslotRows_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str0, 16, "one word, wanted");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str1, 40, "one word, or none: the command's default");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str2, 36, "any number of words, split at spaces");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str3, 33, "one word or more, split at spaces");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str4, 51, "the rest of the words, as they are, split at spaces");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str5, 2, ": ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str6, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str7, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str8, 8, "; a file");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str9, 4, "; a ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str10, 5, " file");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str11, 13, "; a directory");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str12, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str13, 2, ", ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str14, 9, "; one of ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str15, 2, "--");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str16, 2, ": ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str17, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str18, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str19, 2, "; ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str20, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str21, 38, "a switch, off or on (\342\206\220 \342\206\222 or space)");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str22, 37, "a value, typed; left empty, not given");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str23, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str24, 2, ", ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str25, 7, "one of ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str26, 19, " (\342\206\220 \342\206\222 or space)");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str27, 8, "; wanted");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str28, 0, "");
Clo g_std_2ecli_2einteractive_2epartSaid_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2epartSaid_entry, 1, 0};

V g_std_2ecli_2einteractive_2epartSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Positional: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_meta_242 = heff_dup(heff_rfield(v_p_241, 0));
    V v_arity_243 = heff_dup(heff_rfield(v_p_241, 1));
    V v_complete_244 = heff_dup(heff_rfield(v_p_241, 2));
    V v_t_245;
    switch (heff_tag_of(v_arity_243)) {
    case TAG_One: {
      v_t_245 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str0);
      break;
    }
    case TAG_Optional: {
      v_t_245 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str1);
      break;
    }
    case TAG_Many: {
      v_t_245 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str2);
      break;
    }
    case TAG_Some: {
      v_t_245 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str3);
      break;
    }
    case TAG_Rest: {
      v_t_245 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str4);
      break;
    }
    default: heff_nomatch(v_arity_243);
    }
    V v_t_246 = heff_strAppend(heff_strAppend(v_meta_242, ((V)&g_std_2ecli_2einteractive_2epartSaid_str5)), v_t_245);
    V v_t_2412;
    switch (heff_tag_of(v_complete_244)) {
    case TAG_None: {
      v_t_2412 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str6);
      break;
    }
    case TAG_Files: {
      V v_sfx_247 = heff_field(v_complete_244, 0);
      heff_take_n(v_complete_244, 1ULL, 1);
      if (heff_strEq_c_lent(v_sfx_247, ((V)&g_std_2ecli_2einteractive_2epartSaid_str7), 2)) {
        heff_drop(v_sfx_247);
        v_t_2412 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str8);
      } else {
        v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str9), v_sfx_247), ((V)&g_std_2ecli_2einteractive_2epartSaid_str10));
      }
      break;
    }
    case TAG_Dirs: {
      v_t_2412 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str11);
      break;
    }
    case TAG_Among: {
      V v_ws_248 = heff_field(v_complete_244, 0);
      heff_take_n(v_complete_244, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_ws_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_ws_248, 0);
        V v_xs_2410 = heff_field(v_ws_248, 1);
        heff_take_n(v_ws_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str13); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_ws_248);
      }
      v_t_2412 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str14), v_t_2411);
      break;
    }
    default: heff_nomatch(v_complete_244);
    }
    return heff_strAppend(v_t_246, v_t_2412);
  }
  case TAG_Flagged: {
    V v_f_2413 = heff_field(v_x1_240, 0);
    V v_long_2414 = heff_dup(heff_rfield(v_f_2413, 0));
    V v_doc_2415 = heff_dup(heff_rfield(v_f_2413, 3));
    V v_meta_2416 = heff_dup(heff_rfield(v_f_2413, 2));
    V v_values_2417 = heff_dup(heff_rfield(v_f_2413, 4));
    V v_required_2418 = heff_dup(heff_rfield(v_f_2413, 6));
    V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str15), v_long_2414), ((V)&g_std_2ecli_2einteractive_2epartSaid_str16));
    V v_t_2420;
    if (heff_strEq_c_lent(v_doc_2415, ((V)&g_std_2ecli_2einteractive_2epartSaid_str17), 2)) {
      heff_drop(v_doc_2415);
      v_t_2420 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str18);
    } else {
      v_t_2420 = heff_strAppend(v_doc_2415, ((V)&g_std_2ecli_2einteractive_2epartSaid_str19));
    }
    V v_t_2426;
    if (heff_strEq_c(v_meta_2416, ((V)&g_std_2ecli_2einteractive_2epartSaid_str20))) {
      heff_drop(v_values_2417);
      v_t_2426 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str21);
    } else {
      switch (heff_tag_of(v_values_2417)) {
      case TAG_Nil: {
        v_t_2426 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str22);
        break;
      }
      case TAG_Cons: {
        V v_t_2425;
        switch (heff_tag_of(v_values_2417)) {
        case TAG_Nil: {
          v_t_2425 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str23);
          break;
        }
        case TAG_Cons: {
          V v_x_2423 = heff_field(v_values_2417, 0);
          V v_xs_2424 = heff_field(v_values_2417, 1);
          heff_take_n(v_values_2417, 3ULL, 2);
          v_t_2425 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str24); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
          break;
        }
        default: heff_nomatch(v_values_2417);
        }
        v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str25), v_t_2425), ((V)&g_std_2ecli_2einteractive_2epartSaid_str26));
        break;
      }
      default: heff_nomatch(v_values_2417);
      }
    }
    V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2419, v_t_2420), v_t_2426);
    V v_t_2428;
    if ((heff_dup(v_required_2418) == NTAG(TAG_True))) {
      heff_drop(v_required_2418);
      v_t_2428 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str27);
    } else {
      heff_drop(v_required_2418);
      v_t_2428 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str28);
    }
    return heff_strAppend(v_t_2427, v_t_2428);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2epartSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2epartSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str1, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str2, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str3, 2, "$ ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str5, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str6, 9, "not yet: ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str7, 13, "  (Esc: back)");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str8, 60, "Enter: run it  \302\267  Tab \342\206\221 \342\206\223: another field  \302\267  Esc: back");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str9, 0, "");
Clo g_std_2ecli_2einteractive_2eformView_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformView_entry, 3, 0};

V g_std_2ecli_2einteractive_2eformView(V v_size_240, V v_m_241, V v_fm_242) {
top: ;
  V v_rows_243 = heff_take_field(v_size_240, 1);
  V v_columns_244 = heff_get_n(v_size_240, 0, 2);
  V v_h_245 = heff_intSub(v_rows_243, MK_INT(1LL));
  V v_t_246 = heff_strAppend(heff_dup(heff_rfield(v_m_241, 0)), ((V)&g_std_2ecli_2einteractive_2eformView_str0));
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 0, 3);
  V v_t_248 = heff_rec_n(2, shape_text__style, (V[]){heff_strAppend(v_t_246, v_t_247), NTAG(TAG_Bold)});
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 1, 3);
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewords_2ewordsFrom_240(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_list_2emap_24f1511070573x340395911(heff_dup(v_columns_244), ((V)&g_std_2ecli_2einteractive_2eformView_str1), v_t_2410));
  V v_t_2412 = (g_list_2efoldl_24s1396019640x159929943(MK_INT(0LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
  V v_t_2413 = (g_std_2ecli_2einteractive_2eslotRows(v_t_2412, heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(0LL), heff_dup(heff_rfield(v_fm_242, 1))));
  HeffT3 v_t_2414 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
  V v_t_2423;
  {
    V v_field_2416 = v_t_2414.f[1];
    V v_field_2417 = v_t_2414.f[2];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2416;
      V v_x12_2419 = v_field_2417;
      heff_drop(v_x12_2419);
      V v_s_2420 = ({ V b_0 = heff_get_n(v_x_2418, 0, 2); V r_ = (g_std_2ecli_2einteractive_2epartSaid(b_0)); heff_drop(b_0); r_; });
      V v_t_2421 = ({ V a_0 = v_s_2420; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewords_2ewordsFrom_240(a_0, a_1, a_2, a_3)); heff_drop(v_s_2420); r_; });
      V v_t_2422 = (g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240(heff_dup(v_columns_244), ((V)&g_std_2ecli_2einteractive_2eformView_str2), v_t_2421));
      v_t_2423 = (g_list_2emap_24s865484684x739952503(v_t_2422));
    } else {
      heff_drop(v_field_2416);
      heff_drop(v_field_2417);
      v_t_2423 = NTAG(TAG_Nil);
    }
  }
  V v_t_2424 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eformView_str3), NTAG(TAG_Plain)});
  V v_ws_2425 = (g_std_2ecli_2einteractive_2eformWords(heff_dup(v_fm_242)));
  V v_t_2426 = heff_strAppend(heff_get_n(v_m_241, 0, 6), ((V)&g_std_2ecli_2einteractive_2eformView_str4));
  V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 0, 3);
  V v_s_2428 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2eformView_str5); V a_1 = heff_strAppend(v_t_2426, v_t_2427); V a_2 = v_ws_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(a_0, a_1, a_2)); heff_drop(v_ws_2425); r_; });
  V v_t_2429 = heff_rec_n(2, shape_text__style, (V[]){v_s_2428, NTAG(TAG_Bold)});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2430}), NTAG(TAG_Nil)});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2431});
  V v_t_2433 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2432));
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2433});
  V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2434));
  V v_ys_2436 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2435});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2411, v_ys_2436));
  V v_rs_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, v_t_2438});
  V v_t_2440 = (g_list_2ereplicate(heff_dup(v_h_245), NTAG(TAG_Nil)));
  V v_t_2441 = (g_prelude_2e_2b_2b(v_rs_2439, v_t_2440));
  V v_t_2442 = (g_list_2etake(v_h_245, v_t_2441));
  V v_t_2443 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 2, 3);
  V v_t_2444 = (g_std_2ecli_2einteractive_2eformWords(heff_dup(v_fm_242)));
  HeffT2 v_t_2445 = (g_std_2ecli_2eproblemOf_24cpr(v_t_2443, v_t_2444));
  V v_t_2453;
  {
    V v_field_2447 = v_t_2445.f[1];
    int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
    V v_s_2450;
    if ((v_tag_2446 == ((int64_t)0ULL))) {
      V v_p_2448 = v_field_2447;
      V v_t_2449 = ({ V a_0 = v_p_2448; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop(v_p_2448); r_; });
      v_s_2450 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2eformView_str6), v_t_2449), ((V)&g_std_2ecli_2einteractive_2eformView_str7));
    } else {
      heff_drop(v_field_2447);
      v_s_2450 = ((V)&g_std_2ecli_2einteractive_2eformView_str8);
    }
    V v_s_2451 = (g_std_2eterminal_2ewidget_2epad(heff_dup(v_columns_244), v_s_2450));
    V v_t_2452 = heff_rec_n(2, shape_text__style, (V[]){v_s_2451, NTAG(TAG_Inverse)});
    v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
  }
  V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
  V v_t_2455 = (g_prelude_2e_2b_2b(v_t_2442, v_t_2454));
  V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 1, 3);
  V v_t_2457 = ({ V a_0 = v_t_2456; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewords_2ewordsFrom_240(a_0, a_1, a_2, a_3)); heff_drop(v_t_2456); r_; });
  V v_t_2458 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_columns_244; V a_3 = ((V)&g_std_2ecli_2einteractive_2eformView_str9); V a_4 = v_t_2457; V r_ = (g_list_2efoldl_24f1084934118x784646860(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2457); r_; });
  V v_top_2459 = heff_intAdd(v_t_2458, MK_INT(2LL));
  V v_w_2460 = (g_list_2efoldl_24s1396019640x159929943(MK_INT(0LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
  V v_fm_2461 = heff_dup(v_fm_242);
  HeffT3 v_t_2462 = ({ V a_0 = heff_take_field(v_fm_242, 2); V b_1 = heff_get_n(v_fm_242, 1, 3); HeffT3 r_ = (g_list_2edrop_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_s_2468;
  {
    V v_field_2464 = v_t_2462.f[1];
    V v_field_2465 = v_t_2462.f[2];
    int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
    if ((v_tag_2463 == ((int64_t)0ULL))) {
      V v_x_2466 = v_field_2464;
      V v_x12_2467 = v_field_2465;
      heff_drop(v_x12_2467);
      v_s_2468 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2466});
    } else {
      heff_drop(v_field_2464);
      heff_drop(v_field_2465);
      v_s_2468 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2479;
  switch (heff_tag_of(v_s_2468)) {
  case TAG_Nothing: {
    heff_drop(v_top_2459);
    heff_drop(v_w_2460);
    heff_drop_rec(v_fm_2461, 3);
    v_t_2479 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_s1_2469 = heff_field(v_s_2468, 0);
    V v_ru_24s_2468_24Just = heff_take_reuse_n(v_s_2468, 1ULL, 1);
    V v_t_2470 = heff_get_n(v_s1_2469, 1, 2);
    switch (heff_tag_of(v_t_2470)) {
    case TAG_Typed: {
      V v_t_2471 = heff_field(v_t_2470, 0);
      heff_take_n(v_t_2470, 1ULL, 1);
      V v_at_2472 = heff_take_field(v_t_2471, 1);
      V v_text_2473 = heff_get_n(v_t_2471, 0, 2);
      V v_t_2474 = heff_intAdd(heff_intAdd(MK_INT(2LL), v_w_2460), MK_INT(2LL));
      V v_t_2475 = ({ V a_0 = MK_INT(0LL); V a_1 = v_at_2472; V a_2 = v_text_2473; V r_ = (g_list_2efoldl_24f547094838x440994078(a_0, a_1, a_2)); heff_drop(v_text_2473); r_; });
      V v_t_2476 = heff_intAdd(v_top_2459, heff_get_n(v_fm_2461, 2, 3));
      V v_t_2477 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_intAdd(v_t_2474, v_t_2475), v_t_2476});
      v_t_2479 = heff_tag_at_n(v_ru_24s_2468_24Just, TAG_Just, 1, (V[]){v_t_2477});
      break;
    }
    case TAG_Picked: {
      heff_take_n(v_t_2470, 0ULL, 1);
      heff_drop(v_top_2459);
      heff_drop(v_w_2460);
      heff_drop_rec(v_fm_2461, 3);
      heff_drop_cell(v_ru_24s_2468_24Just, 1);
      v_t_2479 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2470);
    }
    break;
  }
  default: heff_nomatch(v_s_2468);
  }
  return heff_rec_n(2, shape_rows__cursor, (V[]){v_t_2455, v_t_2479});
}
V g_std_2ecli_2einteractive_2eformView_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformView(a[0], a[1], a[2]);
}
Clo g_std_2ecli_2einteractive_2eview_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eview_entry, 2, 0};

V g_std_2ecli_2einteractive_2eview(V v_size_240, V v_m_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_m_241, 5));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    HEFF_LAST return g_std_2ecli_2einteractive_2elistView(v_size_240, v_m_241);
  }
  case TAG_Just: {
    V v_fm_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    return (g_std_2ecli_2einteractive_2eformView(v_size_240, v_m_241, v_fm_243));
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2ecli_2einteractive_2eview_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eview(a[0], a[1]);
}
Clo g_std_2ecli_2einteractive_2etypedOnList_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2etypedOnList_24tok1_entry, 3, 0};

V g_std_2ecli_2einteractive_2etypedOnList_24tok1(V v_tok_240, V v_c_241, V v_m_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_m_242, 3));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_f_244 = (g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(v_c_241, heff_take_field(v_m_242, 2)));
    V v_t_245 = heff_take_field(v_m_242, 3);
    V v_t_249;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      v_t_249 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V v_t_246 = heff_dup(heff_rfield(v_f_244, 0));
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        v_t_249 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_246, 0ULL, 2);
        v_t_249 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_246);
      }
    }
    V v_t_2410 = ({ V rv_2 = v_f_244; V rv_3 = v_t_249; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_242, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_at_n(v_tok_240, TAG_Continue, 1, (V[]){v_t_2410});
  } else {
    heff_drop(v_t_243);
    if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(113LL))) {
      heff_drop(v_c_241);
      heff_drop_rec(v_m_242, 6);
      return heff_tag_at_n(v_tok_240, TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
    } else {
      if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(106LL))) {
        heff_drop_cell(v_tok_240, 1);
        heff_drop(v_c_241);
        return ({ V b_0 = NTAG(TAG_ArrowDown); V a_1 = v_m_242; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
      } else {
        if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(107LL))) {
          heff_drop_cell(v_tok_240, 1);
          heff_drop(v_c_241);
          return ({ V b_0 = NTAG(TAG_ArrowUp); V a_1 = v_m_242; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
        } else {
          if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(47LL))) {
            heff_drop(v_c_241);
            V v_t_2411 = ({ V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_m_242, 55ULL, 6, shape_prog__entries__filter__typing__menu__form, 3903u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
            return heff_tag_at_n(v_tok_240, TAG_Continue, 1, (V[]){v_t_2411});
          } else {
            V v_f_2412 = (g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(v_c_241, heff_take_field(v_m_242, 2)));
            V v_t_2413 = heff_take_field(v_m_242, 3);
            V v_t_2417;
            if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
              heff_drop(v_t_2413);
              v_t_2417 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2413);
              V v_t_2414 = heff_dup(heff_rfield(v_f_2412, 0));
              switch (heff_tag_of(v_t_2414)) {
              case TAG_Nil: {
                v_t_2417 = NTAG(TAG_False);
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_t_2414, 0ULL, 2);
                v_t_2417 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_t_2414);
              }
            }
            V v_t_2418 = ({ V rv_2 = v_f_2412; V rv_3 = v_t_2417; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_242, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
            return heff_tag_at_n(v_tok_240, TAG_Continue, 1, (V[]){v_t_2418});
          }
        }
      }
    }
  }
}
V g_std_2ecli_2einteractive_2etypedOnList_24tok1_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2etypedOnList_24tok1(a[0], a[1], a[2]);
}