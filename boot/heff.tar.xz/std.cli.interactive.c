// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Among 19600
#define TAG_ArrowDown 21357
#define TAG_ArrowLeft 52976
#define TAG_ArrowRight 29566
#define TAG_ArrowUp 57900
#define TAG_BackTab 60780
#define TAG_Backspace 1027
#define TAG_Bold 53386
#define TAG_Char 10597
#define TAG_Continue 52606
#define TAG_Control 37853
#define TAG_Delete 50238
#define TAG_Dim 16148
#define TAG_Dirs 41877
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Enter 13030
#define TAG_Escape 55216
#define TAG_Files 59123
#define TAG_Flagged 28540
#define TAG_Home 35586
#define TAG_Inverse 25398
#define TAG_Many 40086
#define TAG_None 17785
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_PageDown 11812
#define TAG_PageUp 3752
#define TAG_Picked 5619
#define TAG_Plain 3036
#define TAG_Positional 16703
#define TAG_Rest 61983
#define TAG_Sequence 46672
#define TAG_Some 35657
#define TAG_Tab 31265
#define TAG_Typed 36072
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_columns 1181578779
#define LBL_complete 145693389
#define LBL_cursor 598022785
#define LBL_doc 309170
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_filter 672649891
#define LBL_flags 298871457
#define LBL_form 9644427
#define LBL_input 301716452
#define LBL_long 9823043
#define LBL_menu 9843238
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_options 1129866465
#define LBL_part 9928890
#define LBL_pos 320718
#define LBL_prog 9945121
#define LBL_required 351999471
#define LBL_rows 10002080
#define LBL_shape 310758331
#define LBL_short 310771862
#define LBL_slots 310891087
#define LBL_style 311138763
#define LBL_text 10052084
#define LBL_typing 1088343202
#define LBL_values 1123329101
static uint32_t shape_entry__slots__at[] = {LBL_entry, LBL_slots, LBL_at};
static uint32_t shape_options__at[] = {LBL_options, LBL_at};
static uint32_t shape_part__input[] = {LBL_part, LBL_input};
static uint32_t shape_prog__entries__filter__typing__menu__form[] = {LBL_prog, LBL_entries, LBL_filter, LBL_typing, LBL_menu, LBL_form};
static uint32_t shape_rows__cursor[] = {LBL_rows, LBL_cursor};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_list_2eany_24s1817246263x1083513945(V, V);
V g_list_2eany_24s1817246263x1083513945_entry(V self, V *a);
extern Clo g_list_2eany_24s1817246263x1083513945_clo;
V g_list_2eany_24s317268364x1703376737(V);
V g_list_2eany_24s317268364x1703376737_entry(V self, V *a);
extern Clo g_list_2eany_24s317268364x1703376737_clo;
V g_list_2eany_24s624430845x1248965393(V);
V g_list_2eany_24s624430845x1248965393_entry(V self, V *a);
extern Clo g_list_2eany_24s624430845x1248965393_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24f1563799791x267609364(V, V);
V g_list_2efoldl_24f1563799791x267609364_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1563799791x267609364_clo;
V g_list_2efoldl_24f354261656x2102112793(V, V, V, V, V);
V g_list_2efoldl_24f354261656x2102112793_entry(V self, V *a);
extern Clo g_list_2efoldl_24f354261656x2102112793_clo;
V g_list_2efoldl_24f545139853x5269120(V, V);
V g_list_2efoldl_24f545139853x5269120_entry(V self, V *a);
extern Clo g_list_2efoldl_24f545139853x5269120_clo;
V g_list_2efoldl_24f547094838x440994078(V, V, V);
V g_list_2efoldl_24f547094838x440994078_entry(V self, V *a);
extern Clo g_list_2efoldl_24f547094838x440994078_clo;
V g_list_2efoldl_24f639372865x1756770401(V, V, V, V, V, V);
V g_list_2efoldl_24f639372865x1756770401_entry(V self, V *a);
extern Clo g_list_2efoldl_24f639372865x1756770401_clo;
V g_list_2efoldl_24s1082575184x1482248631(V, V, V);
V g_list_2efoldl_24s1082575184x1482248631_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1082575184x1482248631_clo;
V g_list_2efoldl_24s1722219619x1576677028(V, V);
V g_list_2efoldl_24s1722219619x1576677028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1722219619x1576677028_clo;
V g_list_2efoldl_24s34462041x653372414(V, V, V);
V g_list_2efoldl_24s34462041x653372414_entry(V self, V *a);
extern Clo g_list_2efoldl_24s34462041x653372414_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s676546201x1093915011(V, V, V, V);
V g_list_2ekeepIf_24s676546201x1093915011_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s676546201x1093915011_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1016251237x587084191(V, V, V);
V g_list_2emap_24f1016251237x587084191_entry(V self, V *a);
extern Clo g_list_2emap_24f1016251237x587084191_clo;
V g_list_2emap_24s1171333510x402969237(V);
V g_list_2emap_24s1171333510x402969237_entry(V self, V *a);
extern Clo g_list_2emap_24s1171333510x402969237_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s1539380703x380520933(V);
V g_list_2emap_24s1539380703x380520933_entry(V self, V *a);
extern Clo g_list_2emap_24s1539380703x380520933_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s456747242x756515627(V);
V g_list_2emap_24s456747242x756515627_entry(V self, V *a);
extern Clo g_list_2emap_24s456747242x756515627_clo;
V g_list_2emap_24s865484684x739952503(V);
V g_list_2emap_24s865484684x739952503_entry(V self, V *a);
extern Clo g_list_2emap_24s865484684x739952503_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
V g_std_2ecli_2einteractive_2ecalledAs(V, V);
V g_std_2ecli_2einteractive_2ecalledAs_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2ecalledAs_clo;
V g_std_2ecli_2einteractive_2econtrolOnList(V, V);
V g_std_2ecli_2einteractive_2econtrolOnList_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2econtrolOnList_clo;
V g_std_2ecli_2einteractive_2eescapedList(V);
V g_std_2ecli_2einteractive_2eescapedList_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eescapedList_clo;
V g_std_2ecli_2einteractive_2eflagSlot(V);
V g_std_2ecli_2einteractive_2eflagSlot_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eflagSlot_clo;
V g_std_2ecli_2einteractive_2eflagWord(V, V);
V g_std_2ecli_2einteractive_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eflagWord_clo;
V g_std_2ecli_2einteractive_2eformCursor(V, V, V, V);
V g_std_2ecli_2einteractive_2eformCursor_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformCursor_clo;
V g_std_2ecli_2einteractive_2eformStep(V, V, V);
V g_std_2ecli_2einteractive_2eformStep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformStep_clo;
V g_std_2ecli_2einteractive_2eformView(V, V, V);
V g_std_2ecli_2einteractive_2eformView_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformView_clo;
V g_std_2ecli_2einteractive_2eformWords(V);
V g_std_2ecli_2einteractive_2eformWords_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformWords_clo;
V g_std_2ecli_2einteractive_2einputRow(V, V, V);
V g_std_2ecli_2einteractive_2einputRow_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2einputRow_clo;
V g_std_2ecli_2einteractive_2elistStep(V, V);
V g_std_2ecli_2einteractive_2elistStep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2elistStep_clo;
V g_std_2ecli_2einteractive_2elistView(V, V);
V g_std_2ecli_2einteractive_2elistView_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2elistView_clo;
V g_std_2ecli_2einteractive_2emoved(V, V);
V g_std_2ecli_2einteractive_2emoved_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2emoved_clo;
V g_std_2ecli_2einteractive_2epartLabel(V);
V g_std_2ecli_2einteractive_2epartLabel_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epartLabel_clo;
V g_std_2ecli_2einteractive_2epartSaid(V);
V g_std_2ecli_2einteractive_2epartSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epartSaid_clo;
V g_std_2ecli_2einteractive_2epartWords(V, V);
V g_std_2ecli_2einteractive_2epartWords_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epartWords_clo;
V g_std_2ecli_2einteractive_2eplainByte(V);
V g_std_2ecli_2einteractive_2eplainByte_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eplainByte_clo;
V g_std_2ecli_2einteractive_2eplainFrom(V, V);
V g_std_2ecli_2einteractive_2eplainFrom_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eplainFrom_clo;
V g_std_2ecli_2einteractive_2eposWords(V, V);
V g_std_2ecli_2einteractive_2eposWords_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eposWords_clo;
V g_std_2ecli_2einteractive_2equoted(V);
V g_std_2ecli_2einteractive_2equoted_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2equoted_clo;
V g_std_2ecli_2einteractive_2eslotRow(V, V, V);
V g_std_2ecli_2einteractive_2eslotRow_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotRow_clo;
V g_std_2ecli_2einteractive_2eslotRows(V, V, V, V);
V g_std_2ecli_2einteractive_2eslotRows_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotRows_clo;
V g_std_2ecli_2einteractive_2eslotRows_24dps(V, V, V, V, V);
V g_std_2ecli_2einteractive_2eslotRows_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotRows_24dps_clo;
V g_std_2ecli_2einteractive_2eslotStep(V, V, V);
V g_std_2ecli_2einteractive_2eslotStep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotStep_clo;
V g_std_2ecli_2einteractive_2estep(V, V);
V g_std_2ecli_2einteractive_2estep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2estep_clo;
V g_std_2ecli_2einteractive_2eswitchOptions_get(void);
V g_std_2ecli_2einteractive_2etypedOnList(V, V);
V g_std_2ecli_2einteractive_2etypedOnList_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2etypedOnList_clo;
V g_std_2ecli_2einteractive_2eupdateAt(V, V, V);
V g_std_2ecli_2einteractive_2eupdateAt_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eupdateAt_clo;
V g_std_2ecli_2einteractive_2eupdateAt_24dps(V, V, V, V);
V g_std_2ecli_2einteractive_2eupdateAt_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eupdateAt_24dps_clo;
V g_std_2ecli_2einteractive_2eview(V, V);
V g_std_2ecli_2einteractive_2eview_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eview_clo;
HeffT2 g_std_2ecli_2eproblemOf_24cpr(V, V);
V g_std_2ecli_2eproblemSaid(V);
V g_std_2ecli_2eproblemSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2eproblemSaid_clo;
V g_std_2eterminal_2ewidget_2ebold(V);
V g_std_2eterminal_2ewidget_2ebold_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ebold_clo;
V g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747(V, V, V, V);
V g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_clo;
V g_std_2eterminal_2ewidget_2echoiceKey(V, V);
V g_std_2eterminal_2ewidget_2echoiceKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2echoiceKey_clo;
V g_std_2eterminal_2ewidget_2efieldKey(V, V);
V g_std_2eterminal_2ewidget_2efieldKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2efieldKey_clo;
V g_std_2eterminal_2ewidget_2einverse(V);
V g_std_2eterminal_2ewidget_2einverse_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2einverse_clo;
V g_std_2eterminal_2ewidget_2emenu_get(void);
V g_std_2eterminal_2ewidget_2emenuFrom(V, V, V);
V g_std_2eterminal_2ewidget_2emenuFrom_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuFrom_clo;
V g_std_2eterminal_2ewidget_2emenuKey(V, V, V);
V g_std_2eterminal_2ewidget_2emenuKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuKey_clo;
V g_std_2eterminal_2ewidget_2epad(V, V);
V g_std_2eterminal_2ewidget_2epad_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2epad_clo;
V g_std_2eterminal_2ewidget_2ewrapGo(V, V, V);
V g_std_2eterminal_2ewidget_2ewrapGo_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ewrapGo_clo;
HEFF_LIT(g_std_2ecli_2einteractive_2eswitchOptions_str0, 2, "on");
HEFF_LIT(g_std_2ecli_2einteractive_2eswitchOptions_str1, 3, "off");

static V g_std_2ecli_2einteractive_2eswitchOptions_val;
static HEFF_ONCE g_std_2ecli_2einteractive_2eswitchOptions_st;
static V g_std_2ecli_2einteractive_2eswitchOptions_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2einteractive_2eswitchOptions_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2einteractive_2eswitchOptions_str1), v_t_240});
}
V g_std_2ecli_2einteractive_2eswitchOptions_get(void) {
  if (HEFF_DONE(g_std_2ecli_2einteractive_2eswitchOptions_st)) return g_std_2ecli_2einteractive_2eswitchOptions_val;
  return heff_global(&g_std_2ecli_2einteractive_2eswitchOptions_val, &g_std_2ecli_2einteractive_2eswitchOptions_st, g_std_2ecli_2einteractive_2eswitchOptions_init);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eflagSlot_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagSlot_str1, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagSlot_str2, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagSlot_str3, 0, "");
Clo g_std_2ecli_2einteractive_2eflagSlot_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eflagSlot_entry, 1, 0};

V g_std_2ecli_2einteractive_2eflagSlot(V v_f_240) {
top: ;
  V v_t_2410;
  if (heff_strEq_c(heff_dup(heff_rfield(v_f_240, 2)), ((V)&g_std_2ecli_2einteractive_2eflagSlot_str0))) {
    v_t_2410 = heff_tag_n(TAG_Picked, 1, (V[]){heff_rec_n(2, shape_options__at, (V[]){heff_dup(g_std_2ecli_2einteractive_2eswitchOptions_get()), MK_INT(0LL)})});
  } else {
    V v_t_242 = heff_dup(heff_rfield(v_f_240, 4));
    switch (heff_tag_of(v_t_242)) {
    case TAG_Nil: {
      V v_t_243 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_std_2ecli_2einteractive_2eflagSlot_str1)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_244 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_std_2ecli_2einteractive_2eflagSlot_str2)), v_t_243});
      v_t_2410 = heff_tag_n(TAG_Typed, 1, (V[]){v_t_244});
      break;
    }
    case TAG_Cons: {
      V v_ru_24t_242_24Cons = heff_take_reuse_n(v_t_242, 0ULL, 2);
      V v_t_247 = heff_dup(heff_rfield(v_f_240, 6));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24t_242_24Cons, 2);
        heff_drop(v_t_247);
        V v_t_248 = heff_rec_n(2, shape_options__at, (V[]){heff_dup(heff_rfield(v_f_240, 4)), MK_INT(0LL)});
        v_t_2410 = heff_tag_n(TAG_Picked, 1, (V[]){v_t_248});
      } else {
        heff_drop(v_t_247);
        V v_t_249 = heff_tag_at_n(v_ru_24t_242_24Cons, TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2einteractive_2eflagSlot_str3), heff_dup(heff_rfield(v_f_240, 4))});
        v_t_2410 = heff_tag_n(TAG_Picked, 1, (V[]){heff_rec_n(2, shape_options__at, (V[]){v_t_249, MK_INT(0LL)})});
      }
      break;
    }
    default: heff_nomatch(v_t_242);
    }
  }
  return heff_rec_n(2, shape_part__input, (V[]){heff_tag_n(TAG_Flagged, 1, (V[]){v_f_240}), v_t_2410});
}
V g_std_2ecli_2einteractive_2eflagSlot_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eflagSlot(a[0]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eposWords_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eposWords_str1, 0, "");
Clo g_std_2ecli_2einteractive_2eposWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eposWords_entry, 2, 0};

V g_std_2ecli_2einteractive_2eposWords(V v_a_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_a_240)) {
  case TAG_One: {
    V v_t_242 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
    V v_t_244 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_243), MK_INT(-1LL)));
    V v_t_245 = heff_strSlice(heff_dup(v_t_241), v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
    if (heff_strEq_c(v_t_245, ((V)&g_std_2ecli_2einteractive_2eposWords_str0))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_247 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
      V v_t_249 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_248), MK_INT(-1LL)));
      V v_t_2410 = heff_strSlice(heff_dup(v_t_241), v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    }
  }
  case TAG_Optional: {
    V v_t_2411 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
    V v_t_2413 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_2412), MK_INT(-1LL)));
    V v_t_2414 = heff_strSlice(heff_dup(v_t_241), v_t_2411, heff_intAdd(v_t_2413, MK_INT(1LL)));
    if (heff_strEq_c(v_t_2414, ((V)&g_std_2ecli_2einteractive_2eposWords_str1))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_2416 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
      V v_t_2418 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_2417), MK_INT(-1LL)));
      V v_t_2419 = heff_strSlice(heff_dup(v_t_241), v_t_2416, heff_intAdd(v_t_2418, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    }
  }
  case TAG_Many: {
    return (g_prelude_2ewordsFrom(v_t_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  }
  case TAG_Some: {
    return (g_prelude_2ewordsFrom(v_t_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  }
  case TAG_Rest: {
    return (g_prelude_2ewordsFrom(v_t_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_a_240);
  }
}
V g_std_2ecli_2einteractive_2eposWords_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ecli_2einteractive_2eposWords(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str1, 2, "on");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str2, 2, "--");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str3, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str4, 1, "=");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str5, 2, "--");
Clo g_std_2ecli_2einteractive_2eflagWord_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eflagWord_entry, 2, 0};

V g_std_2ecli_2einteractive_2eflagWord(V v_f_240, V v_v_241) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_f_240, 2)), ((V)&g_std_2ecli_2einteractive_2eflagWord_str0))) {
    if (heff_strEq_c(v_v_241, ((V)&g_std_2ecli_2einteractive_2eflagWord_str1))) {
      V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2eflagWord_str2), heff_get_n(v_f_240, 0, 8));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    } else {
      heff_drop_rec(v_f_240, 8);
      return NTAG(TAG_Nil);
    }
  } else {
    if (heff_strEq_c_lent(v_v_241, ((V)&g_std_2ecli_2einteractive_2eflagWord_str3), 2)) {
      heff_drop_rec(v_f_240, 8);
      heff_drop(v_v_241);
      return NTAG(TAG_Nil);
    } else {
      V v_t_246 = heff_strAppend(heff_get_n(v_f_240, 0, 8), heff_strAppend(((V)&g_std_2ecli_2einteractive_2eflagWord_str4), v_v_241));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2einteractive_2eflagWord_str5), v_t_246), NTAG(TAG_Nil)});
    }
  }
}
V g_std_2ecli_2einteractive_2eflagWord_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eflagWord(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2epartWords_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartWords_str1, 0, "");
Clo g_std_2ecli_2einteractive_2epartWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2epartWords_entry, 2, 0};

V g_std_2ecli_2einteractive_2epartWords(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Positional: {
    V v_p_242 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Typed: {
      V v_t_243 = heff_field(v_x2_241, 0);
      V v_t_244 = heff_strOfRunes(heff_dup(heff_rfield(v_t_243, 0)));
      return ({ V a_0 = heff_rfield(v_p_242, 1); V a_1 = v_t_244; V r_ = (g_std_2ecli_2einteractive_2eposWords(a_0, a_1)); heff_drop(v_t_244); r_; });
    }
    case TAG_Picked: {
      V v_c_245 = heff_field(v_x2_241, 0);
      HeffT3 v_t_246 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_c_245, 1)), heff_rfield(v_c_245, 0)));
      V v_t_2413;
      {
        V v_field_248 = v_t_246.f[1];
        V v_field_249 = v_t_246.f[2];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_248;
          V v_x12_2412 = v_field_249;
          heff_drop(v_x12_2412);
          v_t_2413 = v_x_2411;
        } else {
          heff_drop(v_field_248);
          heff_drop(v_field_249);
          v_t_2413 = ((V)&g_std_2ecli_2einteractive_2epartWords_str0);
        }
      }
      return ({ V a_0 = heff_rfield(v_p_242, 1); V a_1 = v_t_2413; V r_ = (g_std_2ecli_2einteractive_2eposWords(a_0, a_1)); heff_drop(v_t_2413); r_; });
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Flagged: {
    V v_f_2414 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Typed: {
      V v_t_2415 = heff_field(v_x2_241, 0);
      V v_s_2416 = heff_strOfRunes(heff_dup(heff_rfield(v_t_2415, 0)));
      V v_t_2417 = (g_prelude_2eskipSpaces(v_s_2416, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_s_2416, 0)) - ((int64_t)1ULL));
      V v_t_2419 = (g_prelude_2eskipSpaces(v_s_2416, heff_box_word(v_t_2418), MK_INT(-1LL)));
      V v_t_2420 = heff_strSlice(v_s_2416, v_t_2417, heff_intAdd(v_t_2419, MK_INT(1LL)));
      HEFF_LAST return g_std_2ecli_2einteractive_2eflagWord(heff_dup(v_f_2414), v_t_2420);
    }
    case TAG_Picked: {
      V v_c_2421 = heff_field(v_x2_241, 0);
      HeffT3 v_t_2422 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_c_2421, 1)), heff_rfield(v_c_2421, 0)));
      V v_t_2429;
      {
        V v_field_2424 = v_t_2422.f[1];
        V v_field_2425 = v_t_2422.f[2];
        int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
        if ((v_tag_2423 == ((int64_t)0ULL))) {
          V v_x_2427 = v_field_2424;
          V v_x12_2428 = v_field_2425;
          heff_drop(v_x12_2428);
          v_t_2429 = v_x_2427;
        } else {
          heff_drop(v_field_2424);
          heff_drop(v_field_2425);
          v_t_2429 = ((V)&g_std_2ecli_2einteractive_2epartWords_str1);
        }
      }
      HEFF_LAST return g_std_2ecli_2einteractive_2eflagWord(heff_dup(v_f_2414), v_t_2429);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2epartWords_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ecli_2einteractive_2epartWords(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2eformWords_str0, 2, "--");
Clo g_std_2ecli_2einteractive_2eformWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformWords_entry, 1, 0};

V g_std_2ecli_2einteractive_2eformWords(V v_fm_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_fm_240, 0)), 2, 3);
  V v_rest_242 = ({ V b_0 = heff_get_n(v_t_241, 1, 2); V r_ = (g_list_2eany_24s624430845x1248965393(b_0)); heff_drop(b_0); r_; });
  V v_t_243 = (g_list_2efoldl_24f1563799791x267609364(NTAG(TAG_Nil), heff_dup(heff_rfield(v_fm_240, 1))));
  V v_ps_244 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s1722219619x1576677028(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_list_2efoldl_24f545139853x5269120(NTAG(TAG_Nil), heff_get_n(v_fm_240, 1, 3)));
  V v_fs_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1722219619x1576677028(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_list_2eany_24s317268364x1703376737(v_ps_244));
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_rest_242);
    heff_drop(v_t_247);
    return (g_prelude_2e_2b_2b(v_fs_246, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2einteractive_2eformWords_str0), v_ps_244})));
  } else {
    heff_drop(v_t_247);
    if ((heff_dup(v_rest_242) == NTAG(TAG_True))) {
      heff_drop(v_rest_242);
      return (g_prelude_2e_2b_2b(v_fs_246, v_ps_244));
    } else {
      heff_drop(v_rest_242);
      return (g_prelude_2e_2b_2b(v_ps_244, v_fs_246));
    }
  }
}
V g_std_2ecli_2einteractive_2eformWords_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformWords(a[0]);
}
Clo g_std_2ecli_2einteractive_2eplainByte_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eplainByte_entry, 1, 0};

V g_std_2ecli_2einteractive_2eplainByte(V v_box_24b_240) {
  int64_t v_b_240 = heff_unbox_word(v_box_24b_240);
top: ;
  V v_t_242 = heff_bool(((((int64_t)48ULL) <= v_b_240) && (v_b_240 <= ((int64_t)57ULL))));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_242);
    V v_t_244 = heff_bool(((((int64_t)65ULL) <= v_b_240) && (v_b_240 <= ((int64_t)90ULL))));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      if ((((int64_t)97ULL) <= v_b_240)) {
        if ((v_b_240 <= ((int64_t)122ULL))) {
          return NTAG(TAG_True);
        } else {
          V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(43LL), NTAG(TAG_Nil)});
          V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(64LL), heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(37LL), v_t_247})});
          V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(58LL), heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(44LL), v_t_248})});
          V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(47LL), heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(61LL), v_t_249})});
          V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(95LL), heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(46LL), v_t_2410})});
          return ({ V a_0 = heff_box_word(v_b_240); V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(45LL), v_t_2411}); V r_ = (g_list_2eany_24s1817246263x1083513945(a_0, b_1)); heff_drop(b_1); r_; });
        }
      } else {
        V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(43LL), NTAG(TAG_Nil)});
        V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(64LL), heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(37LL), v_t_2412})});
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(58LL), heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(44LL), v_t_2413})});
        V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(47LL), heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(61LL), v_t_2414})});
        V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(95LL), heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(46LL), v_t_2415})});
        return ({ V a_0 = heff_box_word(v_b_240); V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(45LL), v_t_2416}); V r_ = (g_list_2eany_24s1817246263x1083513945(a_0, b_1)); heff_drop(b_1); r_; });
      }
    }
  }
}
V g_std_2ecli_2einteractive_2eplainByte_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eplainByte(a[0]);
}
Clo g_std_2ecli_2einteractive_2eplainFrom_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eplainFrom_entry, 2, 0};

V g_std_2ecli_2einteractive_2eplainFrom(V v_w_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_w_240, 0)) <= v_i_241)) {
    return NTAG(TAG_True);
  } else {
    V v_t_243 = (g_std_2ecli_2einteractive_2eplainByte(heff_strByteAt_lent(v_w_240, heff_box_word(v_i_241), 2)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_w_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_w_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
}
V g_std_2ecli_2einteractive_2eplainFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2eplainFrom(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str1, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str2, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str3, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str4, 4, "'\\''");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str5, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str6, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str7, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str8, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str9, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str10, 4, "'\\''");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str11, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str12, 1, "'");
Clo g_std_2ecli_2einteractive_2equoted_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2equoted_entry, 1, 0};

V g_std_2ecli_2einteractive_2equoted(V v_w_240) {
top: ;
  if (heff_strEq_c_lent(v_w_240, ((V)&g_std_2ecli_2einteractive_2equoted_str0), 2)) {
    V v_x2_242 = ({ V b_0 = ((V)&g_std_2ecli_2einteractive_2equoted_str1); V a_1 = v_w_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ecli_2einteractive_2equoted_str2), v_w_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_w_240); r_; });
    V v_t_245;
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_std_2ecli_2einteractive_2equoted_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2equoted_str4); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    return heff_strAppend(((V)&g_std_2ecli_2einteractive_2equoted_str5), heff_strAppend(v_t_245, ((V)&g_std_2ecli_2einteractive_2equoted_str6)));
  } else {
    V v_t_246 = (g_std_2ecli_2einteractive_2eplainFrom(v_w_240, MK_INT(0LL)));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return v_w_240;
    } else {
      heff_drop(v_t_246);
      V v_x2_247 = ({ V b_0 = ((V)&g_std_2ecli_2einteractive_2equoted_str7); V a_1 = v_w_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ecli_2einteractive_2equoted_str8), v_w_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_w_240); r_; });
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_std_2ecli_2einteractive_2equoted_str9);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2equoted_str10); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      return heff_strAppend(((V)&g_std_2ecli_2einteractive_2equoted_str11), heff_strAppend(v_t_2410, ((V)&g_std_2ecli_2einteractive_2equoted_str12)));
    }
  }
}
V g_std_2ecli_2einteractive_2equoted_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2equoted(a[0]);
}
Clo g_std_2ecli_2einteractive_2emoved_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2emoved_entry, 2, 0};

V g_std_2ecli_2einteractive_2emoved(V v_k_240, V v_m_241) {
top: ;
  V v_t_242 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = heff_dup(v_m_241); V b_4 = MK_INT(0LL); V a_5 = heff_rfield(v_m_241, 1); V r_ = (g_list_2efoldl_24f639372865x1756770401(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(b_4); r_; });
  V v_t_243 = (g_std_2eterminal_2ewidget_2emenuKey(v_t_242, v_k_240, heff_take_field(v_m_241, 4)));
  V v_t_244 = ({ V rv_4 = v_t_243; V rr_ = heff_rec_reuse_nf(v_m_241, 47ULL, 6, shape_prog__entries__filter__typing__menu__form, 3327u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  return heff_tag_n(TAG_Continue, 1, (V[]){v_t_244});
}
V g_std_2ecli_2einteractive_2emoved_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2emoved(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2ecli_2einteractive_2etypedOnList_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2etypedOnList_entry, 2, 0};

V g_std_2ecli_2einteractive_2etypedOnList(V v_c_240, V v_m_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_m_241, 3));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_f_243 = ({ V b_0 = heff_tag_n(TAG_Char, 1, (V[]){v_c_240}); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_244 = heff_take_field(v_m_241, 3);
    V v_t_248;
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      v_t_248 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = heff_dup(heff_rfield(v_f_243, 0));
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nil: {
        v_t_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_245, 0ULL, 2);
        v_t_248 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
    }
    V v_t_249 = ({ V rv_2 = v_f_243; V rv_3 = v_t_248; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_249});
  } else {
    heff_drop(v_t_242);
    if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(113LL))) {
      heff_drop(v_c_240);
      heff_drop_rec(v_m_241, 6);
      return heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
    } else {
      if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(106LL))) {
        heff_drop(v_c_240);
        return ({ V b_0 = NTAG(TAG_ArrowDown); V a_1 = v_m_241; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
      } else {
        if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(107LL))) {
          heff_drop(v_c_240);
          return ({ V b_0 = NTAG(TAG_ArrowUp); V a_1 = v_m_241; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
        } else {
          if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(47LL))) {
            heff_drop(v_c_240);
            V v_t_2414 = ({ V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_m_241, 55ULL, 6, shape_prog__entries__filter__typing__menu__form, 3903u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
            return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2414});
          } else {
            V v_f_2415 = ({ V b_0 = heff_tag_n(TAG_Char, 1, (V[]){v_c_240}); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2416 = heff_take_field(v_m_241, 3);
            V v_t_2420;
            if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
              heff_drop(v_t_2416);
              v_t_2420 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2416);
              V v_t_2417 = heff_dup(heff_rfield(v_f_2415, 0));
              switch (heff_tag_of(v_t_2417)) {
              case TAG_Nil: {
                v_t_2420 = NTAG(TAG_False);
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_t_2417, 0ULL, 2);
                v_t_2420 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_t_2417);
              }
            }
            V v_t_2421 = ({ V rv_2 = v_f_2415; V rv_3 = v_t_2420; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
            return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2421});
          }
        }
      }
    }
  }
}
V g_std_2ecli_2einteractive_2etypedOnList_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2etypedOnList(a[0], a[1]);
}
Clo g_std_2ecli_2einteractive_2econtrolOnList_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2econtrolOnList_entry, 2, 0};

V g_std_2ecli_2einteractive_2econtrolOnList(V v_c_240, V v_m_241) {
top: ;
  if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(110LL))) {
    return ({ V b_0 = heff_tag_n(TAG_Control, 1, (V[]){v_c_240}); V a_1 = v_m_241; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
  } else {
    if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(112LL))) {
      return ({ V b_0 = heff_tag_n(TAG_Control, 1, (V[]){v_c_240}); V a_1 = v_m_241; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
    } else {
      V v_f_244 = ({ V b_0 = heff_tag_n(TAG_Control, 1, (V[]){v_c_240}); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_245 = heff_take_field(v_m_241, 3);
      V v_t_249;
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        v_t_249 = NTAG(TAG_True);
      } else {
        heff_drop(v_t_245);
        V v_t_246 = heff_dup(heff_rfield(v_f_244, 0));
        switch (heff_tag_of(v_t_246)) {
        case TAG_Nil: {
          v_t_249 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_246, 0ULL, 2);
          v_t_249 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_t_246);
        }
      }
      V v_t_2410 = ({ V rv_2 = v_f_244; V rv_3 = v_t_249; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
      return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2410});
    }
  }
}
V g_std_2ecli_2einteractive_2econtrolOnList_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2econtrolOnList(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eescapedList_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eescapedList_str1, 0, "");
Clo g_std_2ecli_2einteractive_2eescapedList_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eescapedList_entry, 1, 0};

V g_std_2ecli_2einteractive_2eescapedList(V v_m_240) {
top: ;
  V v_t_241 = heff_take_field(v_m_240, 3);
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    V v_t_242 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_std_2ecli_2einteractive_2eescapedList_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_f_243 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_std_2ecli_2einteractive_2eescapedList_str1)), v_t_242});
    V v_t_244 = heff_dup(heff_rfield(v_f_243, 0));
    V v_t_247;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nil: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_247 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_t_248 = ({ V rv_2 = v_f_243; V rv_3 = v_t_247; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_240, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_248});
  } else {
    heff_drop_rec(v_m_240, 6);
    heff_drop(v_t_241);
    return heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
  }
}
V g_std_2ecli_2einteractive_2eescapedList_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eescapedList(a[0]);
}
Clo g_std_2ecli_2einteractive_2elistStep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2elistStep_entry, 2, 0};

V g_std_2ecli_2einteractive_2elistStep(V v_k_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    V v_c_242 = heff_field(v_k_240, 0);
    HEFF_LAST return g_std_2ecli_2einteractive_2etypedOnList(heff_dup(v_c_242), v_m_241);
  }
  case TAG_Enter: {
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_m_241, 4)), 0, 1);
    V v_t_244 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s676546201x1093915011(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
    HeffT3 v_t_245 = ({ V a_0 = v_t_243; V a_1 = v_t_244; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      V v_field_248 = v_t_245.f[2];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_2410 = v_field_247;
        V v_x12_2411 = v_field_248;
        heff_drop(v_x12_2411);
        V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_x_2410, 2)), 1, 2);
        V v_t_2413 = (g_list_2emap_24s1539380703x380520933(v_t_2412));
        V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_x_2410, 2)), 0, 2);
        V v_t_2415 = (g_list_2emap_24s456747242x756515627(v_t_2414));
        V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2415));
        V v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_entry__slots__at, (V[]){v_x_2410, v_t_2416, MK_INT(0LL)})});
        V v_t_2418 = ({ V rv_5 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2418});
      } else {
        heff_drop(v_field_247);
        heff_drop(v_field_248);
        return heff_tag_n(TAG_Continue, 1, (V[]){v_m_241});
      }
    }
  }
  case TAG_Escape: {
    return (g_std_2ecli_2einteractive_2eescapedList(v_m_241));
  }
  case TAG_Tab: {
    V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_m_241, 4)), 0, 1);
    V v_t_2420 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s676546201x1093915011(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
    HeffT3 v_t_2421 = ({ V a_0 = v_t_2419; V a_1 = v_t_2420; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2420); r_; });
    {
      V v_field_2423 = v_t_2421.f[1];
      V v_field_2424 = v_t_2421.f[2];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        V v_x_2426 = v_field_2423;
        V v_x12_2427 = v_field_2424;
        heff_drop(v_x12_2427);
        V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_x_2426, 2)), 1, 2);
        V v_t_2429 = (g_list_2emap_24s1539380703x380520933(v_t_2428));
        V v_t_2430 = heff_get_n(heff_dup(heff_rfield(v_x_2426, 2)), 0, 2);
        V v_t_2431 = (g_list_2emap_24s456747242x756515627(v_t_2430));
        V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2429, v_t_2431));
        V v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_entry__slots__at, (V[]){v_x_2426, v_t_2432, MK_INT(0LL)})});
        V v_t_2434 = ({ V rv_5 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2434});
      } else {
        heff_drop(v_field_2423);
        heff_drop(v_field_2424);
        return heff_tag_n(TAG_Continue, 1, (V[]){v_m_241});
      }
    }
  }
  case TAG_BackTab: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_Backspace: {
    V v_f_2435 = ({ V b_0 = NTAG(TAG_Backspace); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2436 = heff_take_field(v_m_241, 3);
    V v_t_2440;
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop(v_t_2436);
      v_t_2440 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2436);
      V v_t_2437 = heff_dup(heff_rfield(v_f_2435, 0));
      switch (heff_tag_of(v_t_2437)) {
      case TAG_Nil: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2437, 0ULL, 2);
        v_t_2440 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2437);
      }
    }
    V v_t_2441 = ({ V rv_2 = v_f_2435; V rv_3 = v_t_2440; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2441});
  }
  case TAG_Delete: {
    V v_f_2442 = ({ V b_0 = NTAG(TAG_Delete); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2443 = heff_take_field(v_m_241, 3);
    V v_t_2447;
    if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
      heff_drop(v_t_2443);
      v_t_2447 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2443);
      V v_t_2444 = heff_dup(heff_rfield(v_f_2442, 0));
      switch (heff_tag_of(v_t_2444)) {
      case TAG_Nil: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2444, 0ULL, 2);
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2444);
      }
    }
    V v_t_2448 = ({ V rv_2 = v_f_2442; V rv_3 = v_t_2447; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2448});
  }
  case TAG_ArrowUp: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_ArrowDown: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_ArrowLeft: {
    V v_f_2449 = ({ V b_0 = NTAG(TAG_ArrowLeft); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2450 = heff_take_field(v_m_241, 3);
    V v_t_2454;
    if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
      heff_drop(v_t_2450);
      v_t_2454 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2450);
      V v_t_2451 = heff_dup(heff_rfield(v_f_2449, 0));
      switch (heff_tag_of(v_t_2451)) {
      case TAG_Nil: {
        v_t_2454 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2451, 0ULL, 2);
        v_t_2454 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2451);
      }
    }
    V v_t_2455 = ({ V rv_2 = v_f_2449; V rv_3 = v_t_2454; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2455});
  }
  case TAG_ArrowRight: {
    V v_f_2456 = ({ V b_0 = NTAG(TAG_ArrowRight); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2457 = heff_take_field(v_m_241, 3);
    V v_t_2461;
    if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
      heff_drop(v_t_2457);
      v_t_2461 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2457);
      V v_t_2458 = heff_dup(heff_rfield(v_f_2456, 0));
      switch (heff_tag_of(v_t_2458)) {
      case TAG_Nil: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2458, 0ULL, 2);
        v_t_2461 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2458);
      }
    }
    V v_t_2462 = ({ V rv_2 = v_f_2456; V rv_3 = v_t_2461; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2462});
  }
  case TAG_Home: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_End: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_PageUp: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_PageDown: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_Control: {
    V v_c_2463 = heff_field(v_k_240, 0);
    HEFF_LAST return g_std_2ecli_2einteractive_2econtrolOnList(heff_dup(v_c_2463), v_m_241);
  }
  case TAG_Sequence: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2ecli_2einteractive_2elistStep_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2elistStep(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2ecli_2einteractive_2eupdateAt_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eupdateAt_entry, 3, 0};

V g_std_2ecli_2einteractive_2eupdateAt(V v_i_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_g_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      V v_t_246 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_243}));
      return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, v_xs_244});
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_248 = (g_std_2ecli_2einteractive_2eupdateAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_g_241, v_xs_244, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2einteractive_2eupdateAt_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eupdateAt(a[0], a[1], a[2]);
}
Clo g_std_2ecli_2einteractive_2eupdateAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eupdateAt_24dps_entry, 4, 0};

V g_std_2ecli_2einteractive_2eupdateAt_24dps(V v_i_240, V v_g_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_g_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_247 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_244}));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_xs_245}));
    } else {
      V v_cell_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_g_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_248;
      v_i_240 = t_0;
      v_g_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2einteractive_2eupdateAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eupdateAt_24dps(a[0], a[1], a[2], a[3]);
}
V g_std_2ecli_2einteractive_2eslotStep_lam0(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam1(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam2(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam3(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam4(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam5(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam6(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam7(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam8(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam9(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam10(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam11(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam12(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam13(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam14(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam15(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam16(V self, V *args);
Clo g_std_2ecli_2einteractive_2eslotStep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotStep_entry, 3, 0};

V g_std_2ecli_2einteractive_2eslotStep(V v_k_240, V v_m_241, V v_fm_242) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    V v_c_243 = heff_field(v_k_240, 0);
    V v_ru_24k_240_24Char = heff_take_reuse_n(v_k_240, 1ULL, 1);
    HeffT3 v_t_244 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
    {
      V v_field_246 = v_t_244.f[1];
      V v_field_247 = v_t_244.f[2];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_t_2414;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_246;
        V v_x12_2410 = v_field_247;
        heff_drop(v_x12_2410);
        V v_t_2411 = heff_get_n(v_x_249, 1, 2);
        switch (heff_tag_of(v_t_2411)) {
        case TAG_Typed: {
          heff_take_n(v_t_2411, 0ULL, 1);
          v_t_2414 = NTAG(TAG_False);
          break;
        }
        case TAG_Picked: {
          heff_take_n(v_t_2411, 0ULL, 1);
          v_t_2414 = heff_runeEq(heff_dup(v_c_243), MK_INT(113LL));
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
      } else {
        heff_drop(v_field_246);
        heff_drop(v_field_247);
        v_t_2414 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop_rec(v_fm_242, 3);
        heff_drop(v_c_243);
        heff_drop(v_t_2414);
        V v_t_2415 = ({ V rv_5 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2415});
      } else {
        heff_drop(v_t_2414);
        HeffT3 v_t_2416 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
        {
          V v_field_2418 = v_t_2416.f[1];
          V v_field_2419 = v_t_2416.f[2];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          V v_t_2426;
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            V v_x_2421 = v_field_2418;
            V v_x12_2422 = v_field_2419;
            heff_drop(v_x12_2422);
            V v_t_2423 = heff_get_n(v_x_2421, 1, 2);
            switch (heff_tag_of(v_t_2423)) {
            case TAG_Typed: {
              heff_take_n(v_t_2423, 0ULL, 1);
              v_t_2426 = NTAG(TAG_False);
              break;
            }
            case TAG_Picked: {
              heff_take_n(v_t_2423, 0ULL, 1);
              v_t_2426 = heff_runeEq(heff_dup(v_c_243), MK_INT(106LL));
              break;
            }
            default: heff_nomatch(v_t_2423);
            }
          } else {
            heff_drop(v_field_2418);
            heff_drop(v_field_2419);
            v_t_2426 = NTAG(TAG_False);
          }
          if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
            heff_drop(v_c_243);
            heff_drop(v_t_2426);
            V v_t_2427 = heff_dup(heff_rfield(v_fm_242, 1));
            V v_t_2433;
            switch (heff_tag_of(v_t_2427)) {
            case TAG_Nil: {
              v_t_2433 = MK_INT(0LL);
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_t_2427, 0ULL, 2);
              V v_t_2430 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
              V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
              V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
              v_t_2433 = heff_intMod(heff_intAdd(v_t_2430, v_t_2431), v_t_2432);
              break;
            }
            default: heff_nomatch(v_t_2427);
            }
            V v_fm_2434 = ({ V rv_2 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            V v_t_2435 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2434}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
            return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2435});
          } else {
            heff_drop(v_t_2426);
            HeffT3 v_t_2436 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
            {
              V v_field_2438 = v_t_2436.f[1];
              V v_field_2439 = v_t_2436.f[2];
              int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
              V v_t_2446;
              if ((v_tag_2437 == ((int64_t)0ULL))) {
                V v_x_2441 = v_field_2438;
                V v_x12_2442 = v_field_2439;
                heff_drop(v_x12_2442);
                V v_t_2443 = heff_get_n(v_x_2441, 1, 2);
                switch (heff_tag_of(v_t_2443)) {
                case TAG_Typed: {
                  heff_take_n(v_t_2443, 0ULL, 1);
                  v_t_2446 = NTAG(TAG_False);
                  break;
                }
                case TAG_Picked: {
                  heff_take_n(v_t_2443, 0ULL, 1);
                  v_t_2446 = heff_runeEq(heff_dup(v_c_243), MK_INT(107LL));
                  break;
                }
                default: heff_nomatch(v_t_2443);
                }
              } else {
                heff_drop(v_field_2438);
                heff_drop(v_field_2439);
                v_t_2446 = NTAG(TAG_False);
              }
              if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
                heff_drop(v_c_243);
                heff_drop(v_t_2446);
                V v_t_2447 = heff_dup(heff_rfield(v_fm_242, 1));
                V v_t_2453;
                switch (heff_tag_of(v_t_2447)) {
                case TAG_Nil: {
                  v_t_2453 = MK_INT(0LL);
                  break;
                }
                case TAG_Cons: {
                  heff_take_n(v_t_2447, 0ULL, 2);
                  V v_t_2450 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
                  V v_t_2451 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
                  V v_t_2452 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
                  v_t_2453 = heff_intMod(heff_intAdd(v_t_2450, v_t_2451), v_t_2452);
                  break;
                }
                default: heff_nomatch(v_t_2447);
                }
                V v_fm_2454 = ({ V rv_2 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
                V v_t_2455 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2454}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
                return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2455});
              } else {
                heff_drop(v_t_2446);
                V v_t_2463 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam0, 1, 1, (V[]){v_c_243}), heff_take_field(v_fm_242, 1)));
                V v_fm_2464 = ({ V rv_1 = v_t_2463; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_2465 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2464}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
                return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2465});
              }
            }
          }
        }
      }
    }
  }
  case TAG_Enter: {
    V v_t_2473 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam1, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_2474 = ({ V rv_1 = v_t_2473; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2475 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2474}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2475});
  }
  case TAG_Escape: {
    V v_t_2483 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam2, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_2484 = ({ V rv_1 = v_t_2483; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2485 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2484}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2485});
  }
  case TAG_Tab: {
    V v_t_2493 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam3, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_2494 = ({ V rv_1 = v_t_2493; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2495 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2494}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2495});
  }
  case TAG_BackTab: {
    V v_t_24103 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam4, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24104 = ({ V rv_1 = v_t_24103; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24105 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24104}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24105});
  }
  case TAG_Backspace: {
    V v_t_24113 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam5, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24114 = ({ V rv_1 = v_t_24113; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24115 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24114}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24115});
  }
  case TAG_Delete: {
    V v_t_24123 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam6, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24124 = ({ V rv_1 = v_t_24123; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24125 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24124}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24125});
  }
  case TAG_ArrowUp: {
    V v_t_24133 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam7, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24134 = ({ V rv_1 = v_t_24133; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24135 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24134}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24135});
  }
  case TAG_ArrowDown: {
    V v_t_24143 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam8, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24144 = ({ V rv_1 = v_t_24143; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24145 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24144}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24145});
  }
  case TAG_ArrowLeft: {
    V v_t_24153 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam9, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24154 = ({ V rv_1 = v_t_24153; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24155 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24154}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24155});
  }
  case TAG_ArrowRight: {
    V v_t_24163 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam10, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24164 = ({ V rv_1 = v_t_24163; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24165 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24164}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24165});
  }
  case TAG_Home: {
    V v_t_24173 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam11, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24174 = ({ V rv_1 = v_t_24173; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24175 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24174}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24175});
  }
  case TAG_End: {
    V v_t_24183 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam12, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24184 = ({ V rv_1 = v_t_24183; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24185 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24184}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24185});
  }
  case TAG_PageUp: {
    V v_t_24193 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam13, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24194 = ({ V rv_1 = v_t_24193; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24195 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24194}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24195});
  }
  case TAG_PageDown: {
    V v_t_24203 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam14, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24204 = ({ V rv_1 = v_t_24203; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24205 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24204}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24205});
  }
  case TAG_Control: {
    V v_c_24206 = heff_field(v_k_240, 0);
    V v_ru_24k_240_24Control = heff_take_reuse_n(v_k_240, 1ULL, 1);
    if (heff_runeEq_c(heff_dup(v_c_24206), MK_INT(110LL))) {
      heff_drop(v_c_24206);
      V v_t_24208 = heff_dup(heff_rfield(v_fm_242, 1));
      V v_t_24214;
      switch (heff_tag_of(v_t_24208)) {
      case TAG_Nil: {
        v_t_24214 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_24208, 0ULL, 2);
        V v_t_24211 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
        V v_t_24212 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
        V v_t_24213 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
        v_t_24214 = heff_intMod(heff_intAdd(v_t_24211, v_t_24212), v_t_24213);
        break;
      }
      default: heff_nomatch(v_t_24208);
      }
      V v_fm_24215 = ({ V rv_2 = v_t_24214; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_24216 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24215}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_24216});
    } else {
      if (heff_runeEq_c(heff_dup(v_c_24206), MK_INT(112LL))) {
        heff_drop(v_c_24206);
        V v_t_24218 = heff_dup(heff_rfield(v_fm_242, 1));
        V v_t_24224;
        switch (heff_tag_of(v_t_24218)) {
        case TAG_Nil: {
          v_t_24224 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_24218, 0ULL, 2);
          V v_t_24221 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
          V v_t_24222 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
          V v_t_24223 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
          v_t_24224 = heff_intMod(heff_intAdd(v_t_24221, v_t_24222), v_t_24223);
          break;
        }
        default: heff_nomatch(v_t_24218);
        }
        V v_fm_24225 = ({ V rv_2 = v_t_24224; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_24226 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24225}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_24226});
      } else {
        V v_t_24234 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam15, 1, 1, (V[]){v_c_24206}), heff_take_field(v_fm_242, 1)));
        V v_fm_24235 = ({ V rv_1 = v_t_24234; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24236 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24235}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_24236});
      }
    }
  }
  case TAG_Sequence: {
    V v_t_24245 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam16, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24246 = ({ V rv_1 = v_t_24245; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24247 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24246}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24247});
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2ecli_2einteractive_2eslotStep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eslotStep(a[0], a[1], a[2]);
}
V g_std_2ecli_2einteractive_2eslotStep_lam0(V self, V *args) {
  V v_s_2456 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2457 = heff_take_field(v_s_2456, 1);
  V v_t_2462;
  switch (heff_tag_of(v_t_2457)) {
  case TAG_Typed: {
    V v_f_2458 = heff_field(v_t_2457, 0);
    V v_ru_24t_2457_24Typed = heff_take_reuse_n(v_t_2457, 1ULL, 1);
    V v_t_2459 = ({ V b_0 = heff_tag_n(TAG_Char, 1, (V[]){v_c_243}); V a_1 = v_f_2458; V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    v_t_2462 = heff_tag_at_n(v_ru_24t_2457_24Typed, TAG_Typed, 1, (V[]){v_t_2459});
    break;
  }
  case TAG_Picked: {
    V v_c_2460 = heff_field(v_t_2457, 0);
    V v_ru_24t_2457_24Picked = heff_take_reuse_n(v_t_2457, 1ULL, 1);
    V v_t_2461 = ({ V b_0 = heff_tag_n(TAG_Char, 1, (V[]){v_c_243}); V a_1 = v_c_2460; V r_ = (g_std_2eterminal_2ewidget_2echoiceKey(b_0, a_1)); heff_drop(b_0); r_; });
    v_t_2462 = heff_tag_at_n(v_ru_24t_2457_24Picked, TAG_Picked, 1, (V[]){v_t_2461});
    break;
  }
  default: heff_nomatch(v_t_2457);
  }
  return ({ V rv_1 = v_t_2462; V rr_ = heff_rec_reuse_nf(v_s_2456, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam1(V self, V *args) {
  V v_s_2466 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2467 = heff_take_field(v_s_2466, 1);
  V v_t_2472;
  switch (heff_tag_of(v_t_2467)) {
  case TAG_Typed: {
    V v_f_2468 = heff_field(v_t_2467, 0);
    V v_ru_24t_2467_24Typed = heff_take_reuse_n(v_t_2467, 1ULL, 1);
    V v_t_2469 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_2468));
    v_t_2472 = heff_tag_at_n(v_ru_24t_2467_24Typed, TAG_Typed, 1, (V[]){v_t_2469});
    break;
  }
  case TAG_Picked: {
    V v_c_2470 = heff_field(v_t_2467, 0);
    V v_ru_24t_2467_24Picked = heff_take_reuse_n(v_t_2467, 1ULL, 1);
    V v_t_2471 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_2470));
    v_t_2472 = heff_tag_at_n(v_ru_24t_2467_24Picked, TAG_Picked, 1, (V[]){v_t_2471});
    break;
  }
  default: heff_nomatch(v_t_2467);
  }
  return ({ V rv_1 = v_t_2472; V rr_ = heff_rec_reuse_nf(v_s_2466, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam2(V self, V *args) {
  V v_s_2476 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2477 = heff_take_field(v_s_2476, 1);
  V v_t_2482;
  switch (heff_tag_of(v_t_2477)) {
  case TAG_Typed: {
    V v_f_2478 = heff_field(v_t_2477, 0);
    V v_ru_24t_2477_24Typed = heff_take_reuse_n(v_t_2477, 1ULL, 1);
    V v_t_2479 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_2478));
    v_t_2482 = heff_tag_at_n(v_ru_24t_2477_24Typed, TAG_Typed, 1, (V[]){v_t_2479});
    break;
  }
  case TAG_Picked: {
    V v_c_2480 = heff_field(v_t_2477, 0);
    V v_ru_24t_2477_24Picked = heff_take_reuse_n(v_t_2477, 1ULL, 1);
    V v_t_2481 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_2480));
    v_t_2482 = heff_tag_at_n(v_ru_24t_2477_24Picked, TAG_Picked, 1, (V[]){v_t_2481});
    break;
  }
  default: heff_nomatch(v_t_2477);
  }
  return ({ V rv_1 = v_t_2482; V rr_ = heff_rec_reuse_nf(v_s_2476, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam3(V self, V *args) {
  V v_s_2486 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2487 = heff_take_field(v_s_2486, 1);
  V v_t_2492;
  switch (heff_tag_of(v_t_2487)) {
  case TAG_Typed: {
    V v_f_2488 = heff_field(v_t_2487, 0);
    V v_ru_24t_2487_24Typed = heff_take_reuse_n(v_t_2487, 1ULL, 1);
    V v_t_2489 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_2488));
    v_t_2492 = heff_tag_at_n(v_ru_24t_2487_24Typed, TAG_Typed, 1, (V[]){v_t_2489});
    break;
  }
  case TAG_Picked: {
    V v_c_2490 = heff_field(v_t_2487, 0);
    V v_ru_24t_2487_24Picked = heff_take_reuse_n(v_t_2487, 1ULL, 1);
    V v_t_2491 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_2490));
    v_t_2492 = heff_tag_at_n(v_ru_24t_2487_24Picked, TAG_Picked, 1, (V[]){v_t_2491});
    break;
  }
  default: heff_nomatch(v_t_2487);
  }
  return ({ V rv_1 = v_t_2492; V rr_ = heff_rec_reuse_nf(v_s_2486, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam4(V self, V *args) {
  V v_s_2496 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2497 = heff_take_field(v_s_2496, 1);
  V v_t_24102;
  switch (heff_tag_of(v_t_2497)) {
  case TAG_Typed: {
    V v_f_2498 = heff_field(v_t_2497, 0);
    V v_ru_24t_2497_24Typed = heff_take_reuse_n(v_t_2497, 1ULL, 1);
    V v_t_2499 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_2498));
    v_t_24102 = heff_tag_at_n(v_ru_24t_2497_24Typed, TAG_Typed, 1, (V[]){v_t_2499});
    break;
  }
  case TAG_Picked: {
    V v_c_24100 = heff_field(v_t_2497, 0);
    V v_ru_24t_2497_24Picked = heff_take_reuse_n(v_t_2497, 1ULL, 1);
    V v_t_24101 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24100));
    v_t_24102 = heff_tag_at_n(v_ru_24t_2497_24Picked, TAG_Picked, 1, (V[]){v_t_24101});
    break;
  }
  default: heff_nomatch(v_t_2497);
  }
  return ({ V rv_1 = v_t_24102; V rr_ = heff_rec_reuse_nf(v_s_2496, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam5(V self, V *args) {
  V v_s_24106 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24107 = heff_take_field(v_s_24106, 1);
  V v_t_24112;
  switch (heff_tag_of(v_t_24107)) {
  case TAG_Typed: {
    V v_f_24108 = heff_field(v_t_24107, 0);
    V v_ru_24t_24107_24Typed = heff_take_reuse_n(v_t_24107, 1ULL, 1);
    V v_t_24109 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24108));
    v_t_24112 = heff_tag_at_n(v_ru_24t_24107_24Typed, TAG_Typed, 1, (V[]){v_t_24109});
    break;
  }
  case TAG_Picked: {
    V v_c_24110 = heff_field(v_t_24107, 0);
    V v_ru_24t_24107_24Picked = heff_take_reuse_n(v_t_24107, 1ULL, 1);
    V v_t_24111 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24110));
    v_t_24112 = heff_tag_at_n(v_ru_24t_24107_24Picked, TAG_Picked, 1, (V[]){v_t_24111});
    break;
  }
  default: heff_nomatch(v_t_24107);
  }
  return ({ V rv_1 = v_t_24112; V rr_ = heff_rec_reuse_nf(v_s_24106, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam6(V self, V *args) {
  V v_s_24116 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24117 = heff_take_field(v_s_24116, 1);
  V v_t_24122;
  switch (heff_tag_of(v_t_24117)) {
  case TAG_Typed: {
    V v_f_24118 = heff_field(v_t_24117, 0);
    V v_ru_24t_24117_24Typed = heff_take_reuse_n(v_t_24117, 1ULL, 1);
    V v_t_24119 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24118));
    v_t_24122 = heff_tag_at_n(v_ru_24t_24117_24Typed, TAG_Typed, 1, (V[]){v_t_24119});
    break;
  }
  case TAG_Picked: {
    V v_c_24120 = heff_field(v_t_24117, 0);
    V v_ru_24t_24117_24Picked = heff_take_reuse_n(v_t_24117, 1ULL, 1);
    V v_t_24121 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24120));
    v_t_24122 = heff_tag_at_n(v_ru_24t_24117_24Picked, TAG_Picked, 1, (V[]){v_t_24121});
    break;
  }
  default: heff_nomatch(v_t_24117);
  }
  return ({ V rv_1 = v_t_24122; V rr_ = heff_rec_reuse_nf(v_s_24116, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam7(V self, V *args) {
  V v_s_24126 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24127 = heff_take_field(v_s_24126, 1);
  V v_t_24132;
  switch (heff_tag_of(v_t_24127)) {
  case TAG_Typed: {
    V v_f_24128 = heff_field(v_t_24127, 0);
    V v_ru_24t_24127_24Typed = heff_take_reuse_n(v_t_24127, 1ULL, 1);
    V v_t_24129 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24128));
    v_t_24132 = heff_tag_at_n(v_ru_24t_24127_24Typed, TAG_Typed, 1, (V[]){v_t_24129});
    break;
  }
  case TAG_Picked: {
    V v_c_24130 = heff_field(v_t_24127, 0);
    V v_ru_24t_24127_24Picked = heff_take_reuse_n(v_t_24127, 1ULL, 1);
    V v_t_24131 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24130));
    v_t_24132 = heff_tag_at_n(v_ru_24t_24127_24Picked, TAG_Picked, 1, (V[]){v_t_24131});
    break;
  }
  default: heff_nomatch(v_t_24127);
  }
  return ({ V rv_1 = v_t_24132; V rr_ = heff_rec_reuse_nf(v_s_24126, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam8(V self, V *args) {
  V v_s_24136 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24137 = heff_take_field(v_s_24136, 1);
  V v_t_24142;
  switch (heff_tag_of(v_t_24137)) {
  case TAG_Typed: {
    V v_f_24138 = heff_field(v_t_24137, 0);
    V v_ru_24t_24137_24Typed = heff_take_reuse_n(v_t_24137, 1ULL, 1);
    V v_t_24139 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24138));
    v_t_24142 = heff_tag_at_n(v_ru_24t_24137_24Typed, TAG_Typed, 1, (V[]){v_t_24139});
    break;
  }
  case TAG_Picked: {
    V v_c_24140 = heff_field(v_t_24137, 0);
    V v_ru_24t_24137_24Picked = heff_take_reuse_n(v_t_24137, 1ULL, 1);
    V v_t_24141 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24140));
    v_t_24142 = heff_tag_at_n(v_ru_24t_24137_24Picked, TAG_Picked, 1, (V[]){v_t_24141});
    break;
  }
  default: heff_nomatch(v_t_24137);
  }
  return ({ V rv_1 = v_t_24142; V rr_ = heff_rec_reuse_nf(v_s_24136, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam9(V self, V *args) {
  V v_s_24146 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24147 = heff_take_field(v_s_24146, 1);
  V v_t_24152;
  switch (heff_tag_of(v_t_24147)) {
  case TAG_Typed: {
    V v_f_24148 = heff_field(v_t_24147, 0);
    V v_ru_24t_24147_24Typed = heff_take_reuse_n(v_t_24147, 1ULL, 1);
    V v_t_24149 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24148));
    v_t_24152 = heff_tag_at_n(v_ru_24t_24147_24Typed, TAG_Typed, 1, (V[]){v_t_24149});
    break;
  }
  case TAG_Picked: {
    V v_c_24150 = heff_field(v_t_24147, 0);
    V v_ru_24t_24147_24Picked = heff_take_reuse_n(v_t_24147, 1ULL, 1);
    V v_t_24151 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24150));
    v_t_24152 = heff_tag_at_n(v_ru_24t_24147_24Picked, TAG_Picked, 1, (V[]){v_t_24151});
    break;
  }
  default: heff_nomatch(v_t_24147);
  }
  return ({ V rv_1 = v_t_24152; V rr_ = heff_rec_reuse_nf(v_s_24146, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam10(V self, V *args) {
  V v_s_24156 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24157 = heff_take_field(v_s_24156, 1);
  V v_t_24162;
  switch (heff_tag_of(v_t_24157)) {
  case TAG_Typed: {
    V v_f_24158 = heff_field(v_t_24157, 0);
    V v_ru_24t_24157_24Typed = heff_take_reuse_n(v_t_24157, 1ULL, 1);
    V v_t_24159 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24158));
    v_t_24162 = heff_tag_at_n(v_ru_24t_24157_24Typed, TAG_Typed, 1, (V[]){v_t_24159});
    break;
  }
  case TAG_Picked: {
    V v_c_24160 = heff_field(v_t_24157, 0);
    V v_ru_24t_24157_24Picked = heff_take_reuse_n(v_t_24157, 1ULL, 1);
    V v_t_24161 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24160));
    v_t_24162 = heff_tag_at_n(v_ru_24t_24157_24Picked, TAG_Picked, 1, (V[]){v_t_24161});
    break;
  }
  default: heff_nomatch(v_t_24157);
  }
  return ({ V rv_1 = v_t_24162; V rr_ = heff_rec_reuse_nf(v_s_24156, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam11(V self, V *args) {
  V v_s_24166 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24167 = heff_take_field(v_s_24166, 1);
  V v_t_24172;
  switch (heff_tag_of(v_t_24167)) {
  case TAG_Typed: {
    V v_f_24168 = heff_field(v_t_24167, 0);
    V v_ru_24t_24167_24Typed = heff_take_reuse_n(v_t_24167, 1ULL, 1);
    V v_t_24169 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24168));
    v_t_24172 = heff_tag_at_n(v_ru_24t_24167_24Typed, TAG_Typed, 1, (V[]){v_t_24169});
    break;
  }
  case TAG_Picked: {
    V v_c_24170 = heff_field(v_t_24167, 0);
    V v_ru_24t_24167_24Picked = heff_take_reuse_n(v_t_24167, 1ULL, 1);
    V v_t_24171 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24170));
    v_t_24172 = heff_tag_at_n(v_ru_24t_24167_24Picked, TAG_Picked, 1, (V[]){v_t_24171});
    break;
  }
  default: heff_nomatch(v_t_24167);
  }
  return ({ V rv_1 = v_t_24172; V rr_ = heff_rec_reuse_nf(v_s_24166, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam12(V self, V *args) {
  V v_s_24176 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24177 = heff_take_field(v_s_24176, 1);
  V v_t_24182;
  switch (heff_tag_of(v_t_24177)) {
  case TAG_Typed: {
    V v_f_24178 = heff_field(v_t_24177, 0);
    V v_ru_24t_24177_24Typed = heff_take_reuse_n(v_t_24177, 1ULL, 1);
    V v_t_24179 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24178));
    v_t_24182 = heff_tag_at_n(v_ru_24t_24177_24Typed, TAG_Typed, 1, (V[]){v_t_24179});
    break;
  }
  case TAG_Picked: {
    V v_c_24180 = heff_field(v_t_24177, 0);
    V v_ru_24t_24177_24Picked = heff_take_reuse_n(v_t_24177, 1ULL, 1);
    V v_t_24181 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24180));
    v_t_24182 = heff_tag_at_n(v_ru_24t_24177_24Picked, TAG_Picked, 1, (V[]){v_t_24181});
    break;
  }
  default: heff_nomatch(v_t_24177);
  }
  return ({ V rv_1 = v_t_24182; V rr_ = heff_rec_reuse_nf(v_s_24176, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam13(V self, V *args) {
  V v_s_24186 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24187 = heff_take_field(v_s_24186, 1);
  V v_t_24192;
  switch (heff_tag_of(v_t_24187)) {
  case TAG_Typed: {
    V v_f_24188 = heff_field(v_t_24187, 0);
    V v_ru_24t_24187_24Typed = heff_take_reuse_n(v_t_24187, 1ULL, 1);
    V v_t_24189 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24188));
    v_t_24192 = heff_tag_at_n(v_ru_24t_24187_24Typed, TAG_Typed, 1, (V[]){v_t_24189});
    break;
  }
  case TAG_Picked: {
    V v_c_24190 = heff_field(v_t_24187, 0);
    V v_ru_24t_24187_24Picked = heff_take_reuse_n(v_t_24187, 1ULL, 1);
    V v_t_24191 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24190));
    v_t_24192 = heff_tag_at_n(v_ru_24t_24187_24Picked, TAG_Picked, 1, (V[]){v_t_24191});
    break;
  }
  default: heff_nomatch(v_t_24187);
  }
  return ({ V rv_1 = v_t_24192; V rr_ = heff_rec_reuse_nf(v_s_24186, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam14(V self, V *args) {
  V v_s_24196 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24197 = heff_take_field(v_s_24196, 1);
  V v_t_24202;
  switch (heff_tag_of(v_t_24197)) {
  case TAG_Typed: {
    V v_f_24198 = heff_field(v_t_24197, 0);
    V v_ru_24t_24197_24Typed = heff_take_reuse_n(v_t_24197, 1ULL, 1);
    V v_t_24199 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24198));
    v_t_24202 = heff_tag_at_n(v_ru_24t_24197_24Typed, TAG_Typed, 1, (V[]){v_t_24199});
    break;
  }
  case TAG_Picked: {
    V v_c_24200 = heff_field(v_t_24197, 0);
    V v_ru_24t_24197_24Picked = heff_take_reuse_n(v_t_24197, 1ULL, 1);
    V v_t_24201 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24200));
    v_t_24202 = heff_tag_at_n(v_ru_24t_24197_24Picked, TAG_Picked, 1, (V[]){v_t_24201});
    break;
  }
  default: heff_nomatch(v_t_24197);
  }
  return ({ V rv_1 = v_t_24202; V rr_ = heff_rec_reuse_nf(v_s_24196, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam15(V self, V *args) {
  V v_s_24227 = args[0];
  V v_c_24206 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24228 = heff_take_field(v_s_24227, 1);
  V v_t_24233;
  switch (heff_tag_of(v_t_24228)) {
  case TAG_Typed: {
    V v_f_24229 = heff_field(v_t_24228, 0);
    V v_ru_24t_24228_24Typed = heff_take_reuse_n(v_t_24228, 1ULL, 1);
    V v_t_24230 = ({ V b_0 = heff_tag_n(TAG_Control, 1, (V[]){v_c_24206}); V a_1 = v_f_24229; V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    v_t_24233 = heff_tag_at_n(v_ru_24t_24228_24Typed, TAG_Typed, 1, (V[]){v_t_24230});
    break;
  }
  case TAG_Picked: {
    V v_c_24231 = heff_field(v_t_24228, 0);
    V v_ru_24t_24228_24Picked = heff_take_reuse_n(v_t_24228, 1ULL, 1);
    V v_t_24232 = ({ V b_0 = heff_tag_n(TAG_Control, 1, (V[]){v_c_24206}); V a_1 = v_c_24231; V r_ = (g_std_2eterminal_2ewidget_2echoiceKey(b_0, a_1)); heff_drop(b_0); r_; });
    v_t_24233 = heff_tag_at_n(v_ru_24t_24228_24Picked, TAG_Picked, 1, (V[]){v_t_24232});
    break;
  }
  default: heff_nomatch(v_t_24228);
  }
  return ({ V rv_1 = v_t_24233; V rr_ = heff_rec_reuse_nf(v_s_24227, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam16(V self, V *args) {
  V v_s_24238 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24239 = heff_take_field(v_s_24238, 1);
  V v_t_24244;
  switch (heff_tag_of(v_t_24239)) {
  case TAG_Typed: {
    V v_f_24240 = heff_field(v_t_24239, 0);
    V v_ru_24t_24239_24Typed = heff_take_reuse_n(v_t_24239, 1ULL, 1);
    V v_t_24241 = ({ V a_0 = v_k_240; V a_1 = v_f_24240; V r_ = (g_std_2eterminal_2ewidget_2efieldKey(a_0, a_1)); heff_drop_tag(v_k_240, 1); r_; });
    v_t_24244 = heff_tag_at_n(v_ru_24t_24239_24Typed, TAG_Typed, 1, (V[]){v_t_24241});
    break;
  }
  case TAG_Picked: {
    V v_c_24242 = heff_field(v_t_24239, 0);
    V v_ru_24t_24239_24Picked = heff_take_reuse_n(v_t_24239, 1ULL, 1);
    V v_t_24243 = ({ V a_0 = v_k_240; V a_1 = v_c_24242; V r_ = (g_std_2eterminal_2ewidget_2echoiceKey(a_0, a_1)); heff_drop_tag(v_k_240, 1); r_; });
    v_t_24244 = heff_tag_at_n(v_ru_24t_24239_24Picked, TAG_Picked, 1, (V[]){v_t_24243});
    break;
  }
  default: heff_nomatch(v_t_24239);
  }
  return ({ V rv_1 = v_t_24244; V rr_ = heff_rec_reuse_nf(v_s_24238, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
Clo g_std_2ecli_2einteractive_2eformStep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformStep_entry, 3, 0};

V g_std_2ecli_2einteractive_2eformStep(V v_k_240, V v_m_241, V v_fm_242) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Enter: {
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 2, 3);
    V v_t_245 = (g_std_2ecli_2einteractive_2eformWords(heff_dup(v_fm_242)));
    HeffT2 v_t_246 = (g_std_2ecli_2eproblemOf_24cpr(v_t_244, v_t_245));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop_rec(v_fm_242, 3);
        V v_p_2410 = v_field_248;
        heff_drop(v_p_2410);
        return heff_tag_n(TAG_Continue, 1, (V[]){v_m_241});
      } else {
        heff_drop_rec(v_m_241, 6);
        heff_drop(v_field_248);
        V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 0, 3);
        V v_t_2412 = (g_std_2ecli_2einteractive_2eformWords(v_fm_242));
        V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2412})});
        return heff_tag_n(TAG_Done, 1, (V[]){v_t_2413});
      }
    }
  }
  case TAG_Escape: {
    heff_drop_rec(v_fm_242, 3);
    V v_t_2414 = ({ V rv_5 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2414});
  }
  case TAG_Tab: {
    V v_t_2415 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2421;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nil: {
      v_t_2421 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2415, 0ULL, 2);
      V v_t_2418 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
      V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      v_t_2421 = heff_intMod(heff_intAdd(v_t_2418, v_t_2419), v_t_2420);
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V v_fm_2422 = ({ V rv_2 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2423 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2422}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2423});
  }
  case TAG_BackTab: {
    V v_t_2424 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2430;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      v_t_2430 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2424, 0ULL, 2);
      V v_t_2427 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
      V v_t_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      v_t_2430 = heff_intMod(heff_intAdd(v_t_2427, v_t_2428), v_t_2429);
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    V v_fm_2431 = ({ V rv_2 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2432 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2431}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2432});
  }
  case TAG_Backspace: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Delete: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_ArrowUp: {
    V v_t_2433 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2439;
    switch (heff_tag_of(v_t_2433)) {
    case TAG_Nil: {
      v_t_2439 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2433, 0ULL, 2);
      V v_t_2436 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
      V v_t_2437 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      v_t_2439 = heff_intMod(heff_intAdd(v_t_2436, v_t_2437), v_t_2438);
      break;
    }
    default: heff_nomatch(v_t_2433);
    }
    V v_fm_2440 = ({ V rv_2 = v_t_2439; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2441 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2440}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2441});
  }
  case TAG_ArrowDown: {
    V v_t_2442 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2448;
    switch (heff_tag_of(v_t_2442)) {
    case TAG_Nil: {
      v_t_2448 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2442, 0ULL, 2);
      V v_t_2445 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
      V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2447 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      v_t_2448 = heff_intMod(heff_intAdd(v_t_2445, v_t_2446), v_t_2447);
      break;
    }
    default: heff_nomatch(v_t_2442);
    }
    V v_fm_2449 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2450 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2449}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2450});
  }
  case TAG_ArrowLeft: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_ArrowRight: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Home: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_End: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_PageUp: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_PageDown: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Control: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Sequence: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2ecli_2einteractive_2eformStep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformStep(a[0], a[1], a[2]);
}
Clo g_std_2ecli_2einteractive_2estep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2estep_entry, 2, 0};

V g_std_2ecli_2einteractive_2estep(V v_k_240, V v_m_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_m_241, 5));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    return ({ V a_0 = v_k_240; V a_1 = v_m_241; V r_ = (g_std_2ecli_2einteractive_2elistStep(a_0, a_1)); heff_drop(v_k_240); r_; });
  }
  case TAG_Just: {
    V v_fm_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    return (g_std_2ecli_2einteractive_2eformStep(v_k_240, v_m_241, v_fm_243));
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2ecli_2einteractive_2estep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2estep(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str0, 7, "` in it");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str1, 23, "no command's name has `");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str2, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str3, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str5, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str6, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str7, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str8, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str9, 1, " ");
Clo g_std_2ecli_2einteractive_2ecalledAs_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2ecalledAs_entry, 2, 0};

V g_std_2ecli_2einteractive_2ecalledAs(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_get_n(heff_get_n(v_m_240, 2, 6), 0, 2);
    V v_t_243 = heff_strAppend(heff_strOfRunes(v_t_242), ((V)&g_std_2ecli_2einteractive_2ecalledAs_str0));
    return heff_strAppend(((V)&g_std_2ecli_2einteractive_2ecalledAs_str1), v_t_243);
  }
  case TAG_Just: {
    V v_e_244 = heff_field(v_x2_241, 0);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_244, 2)), 1, 2);
    V v_t_2425;
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nil: {
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_244, 2)), 0, 2);
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        v_t_2425 = ((V)&g_std_2ecli_2einteractive_2ecalledAs_str2);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_246, 0ULL, 2);
        V v_sh_249 = heff_dup(heff_rfield(v_e_244, 2));
        V v_t_2410 = (g_list_2emap_24s2029999044x514618413(heff_take_field(v_sh_249, 1)));
        V v_t_2411 = (g_list_2emap_24s1281445768x1036802655(heff_get_n(v_sh_249, 0, 2)));
        V v_xs_2412 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2411));
        V v_t_2415;
        switch (heff_tag_of(v_xs_2412)) {
        case TAG_Nil: {
          v_t_2415 = ((V)&g_std_2ecli_2einteractive_2ecalledAs_str3);
          break;
        }
        case TAG_Cons: {
          V v_x_2413 = heff_field(v_xs_2412, 0);
          V v_xs_2414 = heff_field(v_xs_2412, 1);
          heff_take_n(v_xs_2412, 3ULL, 2);
          v_t_2415 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2ecalledAs_str4); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
          break;
        }
        default: heff_nomatch(v_xs_2412);
        }
        v_t_2425 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2ecalledAs_str5), v_t_2415);
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_245, 0ULL, 2);
      V v_sh_2418 = heff_dup(heff_rfield(v_e_244, 2));
      V v_t_2419 = (g_list_2emap_24s2029999044x514618413(heff_take_field(v_sh_2418, 1)));
      V v_t_2420 = (g_list_2emap_24s1281445768x1036802655(heff_get_n(v_sh_2418, 0, 2)));
      V v_xs_2421 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2420));
      V v_t_2424;
      switch (heff_tag_of(v_xs_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_std_2ecli_2einteractive_2ecalledAs_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_xs_2421, 0);
        V v_xs_2423 = heff_field(v_xs_2421, 1);
        heff_take_n(v_xs_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2ecalledAs_str7); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_xs_2421);
      }
      v_t_2425 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2ecalledAs_str8), v_t_2424);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2426 = heff_strAppend(heff_dup(heff_rfield(v_e_244, 0)), v_t_2425);
    return heff_strAppend(heff_get_n(v_m_240, 0, 6), heff_strAppend(((V)&g_std_2ecli_2einteractive_2ecalledAs_str9), v_t_2426));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2einteractive_2ecalledAs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2einteractive_2ecalledAs(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str0, 14, ": its commands");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str1, 8, "filter: ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str2, 71, "type to filter, \342\206\221 \342\206\223 or j k to move, Enter to fill one in, q to quit");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str3, 2, "  ");
V g_std_2ecli_2einteractive_2elistView_lam0(V self, V *args);
Clo g_std_2ecli_2einteractive_2elistView_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2elistView_entry, 2, 0};

V g_std_2ecli_2einteractive_2elistView(V v_size_240, V v_m_241) {
top: ;
  V v_h_242 = heff_intSub(heff_dup(heff_rfield(v_size_240, 1)), MK_INT(1LL));
  V v_t_243 = heff_rec_n(2, shape_text__style, (V[]){heff_dup(heff_rfield(v_m_241, 0)), NTAG(TAG_Bold)});
  V v_t_244 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str0), NTAG(TAG_Plain)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = heff_dup(heff_rfield(v_m_241, 3));
  V v_t_2412;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_t_247 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str1), NTAG(TAG_Plain)});
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_m_241, 2)), 0, 2);
    V v_t_249 = heff_rec_n(2, shape_text__style, (V[]){heff_strOfRunes(v_t_248), NTAG(TAG_Plain)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2410});
  } else {
    heff_drop(v_t_246);
    V v_t_2411 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str2), NTAG(TAG_Dim)});
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  }
  V v_h_2413 = heff_intSub(heff_take_field(v_size_240, 1), MK_INT(4LL));
  V v_m_2414 = heff_dup(heff_rfield(v_m_241, 4));
  V v_t_2415 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s676546201x1093915011(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
  V v_w_2416 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2415; V r_ = (g_list_2efoldl_24s1082575184x1482248631(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s676546201x1093915011(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
  V v_items_2424 = (g_list_2emap(heff_clo_n(g_std_2ecli_2einteractive_2elistView_lam0, 1, 1, (V[]){v_w_2416}), v_t_2417));
  V v_t_2427;
  if (heff_intLt_c(heff_dup(heff_rfield(v_m_2414, 0)), heff_dup(v_h_2413))) {
    v_t_2427 = MK_INT(0LL);
  } else {
    V v_t_2426 = heff_intSub(heff_dup(heff_rfield(v_m_2414, 0)), heff_dup(v_h_2413));
    v_t_2427 = heff_intAdd(v_t_2426, MK_INT(1LL));
  }
  V v_t_2428 = (g_std_2eterminal_2ewidget_2emenuFrom(heff_get_n(v_m_2414, 0, 1), MK_INT(0LL), v_items_2424));
  V v_t_2429 = ({ V a_0 = v_t_2427; V a_1 = v_t_2428; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2428); r_; });
  V v_t_2430 = (g_list_2etake(v_h_2413, v_t_2429));
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2430});
  V v_rs_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_245}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2431})});
  V v_t_2433 = (g_list_2ereplicate(heff_dup(v_h_242), NTAG(TAG_Nil)));
  V v_t_2434 = (g_prelude_2e_2b_2b(v_rs_2432, v_t_2433));
  V v_t_2435 = (g_list_2etake(v_h_242, v_t_2434));
  V v_t_2436 = heff_get_n(heff_dup(heff_rfield(v_m_241, 4)), 0, 1);
  V v_t_2437 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s676546201x1093915011(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
  HeffT3 v_t_2438 = ({ V a_0 = v_t_2436; V a_1 = v_t_2437; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2437); r_; });
  V v_t_2445;
  {
    V v_field_2440 = v_t_2438.f[1];
    V v_field_2441 = v_t_2438.f[2];
    int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
    if ((v_tag_2439 == ((int64_t)0ULL))) {
      V v_x_2443 = v_field_2440;
      V v_x12_2444 = v_field_2441;
      heff_drop(v_x12_2444);
      v_t_2445 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2443});
    } else {
      heff_drop(v_field_2440);
      heff_drop(v_field_2441);
      v_t_2445 = NTAG(TAG_Nothing);
    }
  }
  V v_s_2446 = ({ V a_0 = heff_dup(v_m_241); V a_1 = v_t_2445; V r_ = (g_std_2ecli_2einteractive_2ecalledAs(a_0, a_1)); heff_drop(v_t_2445); r_; });
  V v_s_2447 = (g_std_2eterminal_2ewidget_2epad(heff_get_n(v_size_240, 0, 2), v_s_2446));
  V v_t_2448 = heff_rec_n(2, shape_text__style, (V[]){v_s_2447, NTAG(TAG_Inverse)});
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, NTAG(TAG_Nil)});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
  V v_t_2451 = (g_prelude_2e_2b_2b(v_t_2435, v_t_2450));
  V v_t_2452 = heff_take_field(v_m_241, 3);
  V v_t_2456;
  if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
    heff_drop(v_t_2452);
    V v_f_2453 = heff_get_n(v_m_241, 2, 6);
    V v_t_2454 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_take_field(v_f_2453, 1); V b_2 = heff_get_n(v_f_2453, 0, 2); V r_ = (g_list_2efoldl_24f547094838x440994078(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2455 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_intAdd(MK_INT(8LL), v_t_2454), MK_INT(1LL)});
    v_t_2456 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2455});
  } else {
    heff_drop_rec(v_m_241, 6);
    heff_drop(v_t_2452);
    v_t_2456 = NTAG(TAG_Nothing);
  }
  return heff_rec_n(2, shape_rows__cursor, (V[]){v_t_2451, v_t_2456});
}
V g_std_2ecli_2einteractive_2elistView_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2elistView(a[0], a[1]);
}
V g_std_2ecli_2einteractive_2elistView_lam0(V self, V *args) {
  V v_e_2418 = args[0];
  V v_w_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_s_2419 = (g_std_2eterminal_2ewidget_2epad(v_w_2416, heff_take_field(v_e_2418, 0)));
  V v_t_2420 = heff_rec_n(2, shape_text__style, (V[]){v_s_2419, NTAG(TAG_Bold)});
  V v_t_2421 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str3), NTAG(TAG_Plain)});
  V v_t_2422 = heff_rec_n(2, shape_text__style, (V[]){heff_get_n(v_e_2418, 1, 3), NTAG(TAG_Dim)});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2423})});
}
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str0, 1, "[");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str1, 1, "]");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str2, 1, "[");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str3, 4, "...]");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str4, 3, "...");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str5, 1, "[");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str6, 4, "...]");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str7, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str8, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str9, 2, ", ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str10, 1, "-");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str11, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str12, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str13, 1, "=");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str14, 2, "--");
Clo g_std_2ecli_2einteractive_2epartLabel_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2epartLabel_entry, 1, 0};

V g_std_2ecli_2einteractive_2epartLabel(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Positional: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_m_242 = heff_dup(heff_rfield(v_p_241, 0));
    V v_t_243 = heff_dup(heff_rfield(v_p_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_One: {
      return v_m_242;
    }
    case TAG_Optional: {
      return heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str0), heff_strAppend(v_m_242, ((V)&g_std_2ecli_2einteractive_2epartLabel_str1)));
    }
    case TAG_Many: {
      return heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str2), heff_strAppend(v_m_242, ((V)&g_std_2ecli_2einteractive_2epartLabel_str3)));
    }
    case TAG_Some: {
      return heff_strAppend(v_m_242, ((V)&g_std_2ecli_2einteractive_2epartLabel_str4));
    }
    case TAG_Rest: {
      return heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str5), heff_strAppend(v_m_242, ((V)&g_std_2ecli_2einteractive_2epartLabel_str6)));
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_Flagged: {
    V v_f_244 = heff_field(v_x1_240, 0);
    V v_t_247;
    if (heff_strEq_c(heff_dup(heff_rfield(v_f_244, 1)), ((V)&g_std_2ecli_2einteractive_2epartLabel_str7))) {
      v_t_247 = ((V)&g_std_2ecli_2einteractive_2epartLabel_str8);
    } else {
      V v_t_246 = heff_strAppend(heff_dup(heff_rfield(v_f_244, 1)), ((V)&g_std_2ecli_2einteractive_2epartLabel_str9));
      v_t_247 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str10), v_t_246);
    }
    V v_t_249;
    if (heff_strEq_c(heff_dup(heff_rfield(v_f_244, 2)), ((V)&g_std_2ecli_2einteractive_2epartLabel_str11))) {
      v_t_249 = ((V)&g_std_2ecli_2einteractive_2epartLabel_str12);
    } else {
      v_t_249 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str13), heff_dup(heff_rfield(v_f_244, 2)));
    }
    V v_t_2410 = heff_strAppend(heff_dup(heff_rfield(v_f_244, 0)), v_t_249);
    return heff_strAppend(v_t_247, heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str14), v_t_2410));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2epartLabel_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2epartLabel(a0); heff_drop(a0); return r;
}
Clo g_std_2ecli_2einteractive_2einputRow_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2einputRow_entry, 3, 0};

V g_std_2ecli_2einteractive_2einputRow(V v_on_240, V v_part_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Typed: {
    V v_t_243 = heff_field(v_x3_242, 0);
    if ((heff_dup(v_on_240) == NTAG(TAG_True))) {
      V v_t_244 = heff_strOfRunes(heff_dup(heff_rfield(v_t_243, 0)));
      V v_t_245 = heff_rec_n(2, shape_text__style, (V[]){v_t_244, NTAG(TAG_Plain)});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    } else {
      V v_t_246 = heff_dup(heff_rfield(v_t_243, 0));
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        V v_t_249;
        switch (heff_tag_of(v_part_241)) {
        case TAG_Positional: {
          V v_p_247 = heff_field(v_part_241, 0);
          v_t_249 = heff_dup(heff_rfield(v_p_247, 0));
          break;
        }
        case TAG_Flagged: {
          V v_f_248 = heff_field(v_part_241, 0);
          v_t_249 = heff_dup(heff_rfield(v_f_248, 2));
          break;
        }
        default: heff_nomatch(v_part_241);
        }
        V v_t_2410 = heff_rec_n(2, shape_text__style, (V[]){v_t_249, NTAG(TAG_Dim)});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      }
      case TAG_Cons: {
        V v_ru_24t_246_24Cons = heff_take_reuse_n(v_t_246, 0ULL, 2);
        V v_t_2413 = heff_strOfRunes(heff_dup(heff_rfield(v_t_243, 0)));
        V v_t_2414 = heff_rec_n(2, shape_text__style, (V[]){v_t_2413, NTAG(TAG_Plain)});
        return heff_tag_at_n(v_ru_24t_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
  }
  case TAG_Picked: {
    V v_c_2415 = heff_field(v_x3_242, 0);
    V v_t_2416;
    if ((heff_dup(v_on_240) == NTAG(TAG_True))) {
      v_t_2416 = ((V)&g_std_2eterminal_2ewidget_2einverse_clo);
    } else {
      v_t_2416 = ((V)&g_std_2eterminal_2ewidget_2ebold_clo);
    }
    return (g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747(v_t_2416, heff_dup(heff_rfield(v_c_2415, 1)), MK_INT(0LL), heff_dup(heff_rfield(v_c_2415, 0))));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2einteractive_2einputRow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_std_2ecli_2einteractive_2einputRow(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRow_str0, 2, "> ");
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRow_str1, 2, "  ");
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRow_str2, 2, "  ");
Clo g_std_2ecli_2einteractive_2eslotRow_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotRow_entry, 3, 0};

V g_std_2ecli_2einteractive_2eslotRow(V v_w_240, V v_on_241, V v_s_242) {
top: ;
  V v_t_243;
  if ((heff_dup(v_on_241) == NTAG(TAG_True))) {
    v_t_243 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRow_str0), NTAG(TAG_Bold)});
  } else {
    v_t_243 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRow_str1), NTAG(TAG_Plain)});
  }
  V v_t_244 = (g_std_2ecli_2einteractive_2epartLabel(heff_rfield(v_s_242, 0)));
  V v_s_245 = (g_std_2eterminal_2ewidget_2epad(v_w_240, v_t_244));
  V v_t_246 = heff_rec_n(2, shape_text__style, (V[]){v_s_245, NTAG(TAG_Plain)});
  V v_t_247 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRow_str2), NTAG(TAG_Plain)});
  V v_t_248 = ({ V a_0 = v_on_241; V b_1 = heff_take_field(v_s_242, 0); V b_2 = heff_get_n(v_s_242, 1, 2); V r_ = (g_std_2ecli_2einteractive_2einputRow(a_0, b_1, b_2)); heff_drop(b_1); heff_drop(b_2); r_; });
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_248})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_249});
}
V g_std_2ecli_2einteractive_2eslotRow_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2einteractive_2eslotRow(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_std_2ecli_2einteractive_2eslotRows_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotRows_entry, 4, 0};

V g_std_2ecli_2einteractive_2eslotRows(V v_w_240, V v_at_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    heff_drop(v_at_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x4_243, 0);
    V v_ss_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = ({ V a_0 = heff_dup(v_w_240); V b_1 = heff_intEq_lent(v_i_242, v_at_241, 0); V a_2 = v_s_244; V r_ = (g_std_2ecli_2einteractive_2eslotRow(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_std_2ecli_2einteractive_2eslotRows_24dps(v_w_240, v_at_241, heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL))), v_ss_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2ecli_2einteractive_2eslotRows_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eslotRows(a[0], a[1], a[2], a[3]);
}
Clo g_std_2ecli_2einteractive_2eslotRows_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotRows_24dps_entry, 5, 0};

V g_std_2ecli_2einteractive_2eslotRows_24dps(V v_w_240, V v_at_241, V v_i_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    heff_drop(v_at_241);
    heff_drop(v_i_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_245 = heff_field(v_x4_243, 0);
    V v_ss_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = ({ V a_0 = heff_dup(v_w_240); V b_1 = heff_intEq_lent(v_i_242, v_at_241, 0); V a_2 = v_s_245; V r_ = (g_std_2ecli_2einteractive_2eslotRow(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    V v_cell_248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_w_240;
    V t_1 = v_at_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_ss_246;
    V t_4 = v_cell_248;
    v_w_240 = t_0;
    v_at_241 = t_1;
    v_i_242 = t_2;
    v_x4_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2ecli_2einteractive_2eslotRows_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eslotRows_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str0, 16, "one word, wanted");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str1, 40, "one word, or none: the command's default");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str2, 36, "any number of words, split at spaces");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str3, 33, "one word or more, split at spaces");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str4, 51, "the rest of the words, as they are, split at spaces");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str5, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str6, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str7, 8, "; a file");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str8, 4, "; a ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str9, 5, " file");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str10, 13, "; a directory");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str11, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str12, 2, ", ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str13, 9, "; one of ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str14, 2, ": ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str15, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str16, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str17, 2, "; ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str18, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str19, 38, "a switch, off or on (\342\206\220 \342\206\222 or space)");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str20, 37, "a value, typed; left empty, not given");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str21, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str22, 2, ", ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str23, 7, "one of ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str24, 19, " (\342\206\220 \342\206\222 or space)");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str25, 8, "; wanted");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str26, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str27, 2, ": ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str28, 2, "--");
Clo g_std_2ecli_2einteractive_2epartSaid_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2epartSaid_entry, 1, 0};

V g_std_2ecli_2einteractive_2epartSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Positional: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_t_242 = heff_dup(heff_rfield(v_p_241, 1));
    V v_t_243;
    switch (heff_tag_of(v_t_242)) {
    case TAG_One: {
      v_t_243 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str0);
      break;
    }
    case TAG_Optional: {
      v_t_243 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str1);
      break;
    }
    case TAG_Many: {
      v_t_243 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str2);
      break;
    }
    case TAG_Some: {
      v_t_243 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str3);
      break;
    }
    case TAG_Rest: {
      v_t_243 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str4);
      break;
    }
    default: heff_nomatch(v_t_242);
    }
    V v_t_244 = heff_dup(heff_rfield(v_p_241, 2));
    V v_t_2411;
    switch (heff_tag_of(v_t_244)) {
    case TAG_None: {
      v_t_2411 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str5);
      break;
    }
    case TAG_Files: {
      V v_sfx_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      if (heff_strEq_c_lent(v_sfx_245, ((V)&g_std_2ecli_2einteractive_2epartSaid_str6), 2)) {
        heff_drop(v_sfx_245);
        v_t_2411 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str7);
      } else {
        v_t_2411 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str8), heff_strAppend(v_sfx_245, ((V)&g_std_2ecli_2einteractive_2epartSaid_str9)));
      }
      break;
    }
    case TAG_Dirs: {
      v_t_2411 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str10);
      break;
    }
    case TAG_Among: {
      V v_ws_247 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_t_2410;
      switch (heff_tag_of(v_ws_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_ws_247, 0);
        V v_xs_249 = heff_field(v_ws_247, 1);
        heff_take_n(v_ws_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str12); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_ws_247);
      }
      v_t_2411 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str13), v_t_2410);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_t_2412 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str14), heff_strAppend(v_t_243, v_t_2411));
    return heff_strAppend(heff_dup(heff_rfield(v_p_241, 0)), v_t_2412);
  }
  case TAG_Flagged: {
    V v_f_2413 = heff_field(v_x1_240, 0);
    V v_t_2415;
    if (heff_strEq_c(heff_dup(heff_rfield(v_f_2413, 3)), ((V)&g_std_2ecli_2einteractive_2epartSaid_str15))) {
      v_t_2415 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str16);
    } else {
      v_t_2415 = heff_strAppend(heff_dup(heff_rfield(v_f_2413, 3)), ((V)&g_std_2ecli_2einteractive_2epartSaid_str17));
    }
    V v_t_2424;
    if (heff_strEq_c(heff_dup(heff_rfield(v_f_2413, 2)), ((V)&g_std_2ecli_2einteractive_2epartSaid_str18))) {
      v_t_2424 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str19);
    } else {
      V v_t_2417 = heff_dup(heff_rfield(v_f_2413, 4));
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str20);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2417, 0ULL, 2);
        V v_t_2420 = heff_dup(heff_rfield(v_f_2413, 4));
        V v_t_2423;
        switch (heff_tag_of(v_t_2420)) {
        case TAG_Nil: {
          v_t_2423 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str21);
          break;
        }
        case TAG_Cons: {
          V v_x_2421 = heff_field(v_t_2420, 0);
          V v_xs_2422 = heff_field(v_t_2420, 1);
          heff_take_n(v_t_2420, 3ULL, 2);
          v_t_2423 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str22); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
          break;
        }
        default: heff_nomatch(v_t_2420);
        }
        v_t_2424 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str23), heff_strAppend(v_t_2423, ((V)&g_std_2ecli_2einteractive_2epartSaid_str24)));
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
    }
    V v_t_2425 = heff_dup(heff_rfield(v_f_2413, 6));
    V v_t_2426;
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_t_2425);
      v_t_2426 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str25);
    } else {
      heff_drop(v_t_2425);
      v_t_2426 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str26);
    }
    V v_t_2427 = heff_strAppend(v_t_2415, heff_strAppend(v_t_2424, v_t_2426));
    V v_t_2428 = heff_strAppend(heff_dup(heff_rfield(v_f_2413, 0)), heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str27), v_t_2427));
    return heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str28), v_t_2428);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2epartSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2epartSaid(a0); heff_drop(a0); return r;
}
Clo g_std_2ecli_2einteractive_2eformCursor_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformCursor_entry, 4, 0};

V g_std_2ecli_2einteractive_2eformCursor(V v_top_240, V v_w_241, V v_fm_242, V v_s_243) {
top: ;
  switch (heff_tag_of(v_s_243)) {
  case TAG_Nothing: {
    heff_drop(v_top_240);
    heff_drop(v_w_241);
    heff_drop_rec(v_fm_242, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_s1_244 = heff_field(v_s_243, 0);
    V v_ru_24s_243_24Just = heff_take_reuse_n(v_s_243, 1ULL, 1);
    V v_t_245 = heff_get_n(v_s1_244, 1, 2);
    switch (heff_tag_of(v_t_245)) {
    case TAG_Typed: {
      V v_t_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V v_t_247 = heff_intAdd(heff_intAdd(MK_INT(2LL), v_w_241), MK_INT(2LL));
      V v_t_248 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_take_field(v_t_246, 1); V b_2 = heff_get_n(v_t_246, 0, 2); V r_ = (g_list_2efoldl_24f547094838x440994078(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_249 = heff_intAdd(v_top_240, heff_get_n(v_fm_242, 2, 3));
      V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_intAdd(v_t_247, v_t_248), v_t_249});
      return heff_tag_at_n(v_ru_24s_243_24Just, TAG_Just, 1, (V[]){v_t_2410});
    }
    case TAG_Picked: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_top_240);
      heff_drop(v_w_241);
      heff_drop_rec(v_fm_242, 3);
      heff_drop_cell(v_ru_24s_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_s_243);
  }
}
V g_std_2ecli_2einteractive_2eformCursor_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformCursor(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str1, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str2, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str3, 2, "$ ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str5, 9, "not yet: ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str6, 13, "  (Esc: back)");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str7, 60, "Enter: run it  \302\267  Tab \342\206\221 \342\206\223: another field  \302\267  Esc: back");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str8, 0, "");
Clo g_std_2ecli_2einteractive_2eformView_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformView_entry, 3, 0};

V g_std_2ecli_2einteractive_2eformView(V v_size_240, V v_m_241, V v_fm_242) {
top: ;
  V v_h_243 = heff_intSub(heff_take_field(v_size_240, 1), MK_INT(1LL));
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 0, 3);
  V v_t_245 = heff_strAppend(heff_dup(heff_rfield(v_m_241, 0)), heff_strAppend(((V)&g_std_2ecli_2einteractive_2eformView_str0), v_t_244));
  V v_t_246 = heff_rec_n(2, shape_text__style, (V[]){v_t_245, NTAG(TAG_Bold)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 1, 3);
  V v_t_249 = ({ V a_0 = v_t_248; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewordsFrom(a_0, a_1, a_2, a_3)); heff_drop(v_t_248); r_; });
  V v_t_2410 = (g_list_2emap_24f1016251237x587084191(heff_dup(heff_rfield(v_size_240, 0)), ((V)&g_std_2ecli_2einteractive_2eformView_str1), v_t_249));
  V v_t_2411 = (g_list_2efoldl_24s34462041x653372414(MK_INT(0LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
  V v_t_2412 = (g_std_2ecli_2einteractive_2eslotRows(v_t_2411, heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(0LL), heff_dup(heff_rfield(v_fm_242, 1))));
  HeffT3 v_t_2413 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
  V v_t_2423;
  {
    V v_field_2415 = v_t_2413.f[1];
    V v_field_2416 = v_t_2413.f[2];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2415;
      V v_x12_2419 = v_field_2416;
      heff_drop(v_x12_2419);
      V v_s_2420 = ({ V b_0 = heff_get_n(v_x_2418, 0, 2); V r_ = (g_std_2ecli_2einteractive_2epartSaid(b_0)); heff_drop(b_0); r_; });
      V v_t_2421 = ({ V a_0 = v_s_2420; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewordsFrom(a_0, a_1, a_2, a_3)); heff_drop(v_s_2420); r_; });
      V v_t_2422 = (g_std_2eterminal_2ewidget_2ewrapGo(heff_dup(heff_rfield(v_size_240, 0)), ((V)&g_std_2ecli_2einteractive_2eformView_str2), v_t_2421));
      v_t_2423 = (g_list_2emap_24s865484684x739952503(v_t_2422));
    } else {
      heff_drop(v_field_2415);
      heff_drop(v_field_2416);
      v_t_2423 = NTAG(TAG_Nil);
    }
  }
  V v_t_2424 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eformView_str3), NTAG(TAG_Plain)});
  V v_ws_2425 = (g_std_2ecli_2einteractive_2eformWords(heff_dup(v_fm_242)));
  V v_t_2426 = (g_list_2emap_24s1171333510x402969237(v_ws_2425));
  V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 0, 3);
  V v_s_2428 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2eformView_str4); V a_1 = heff_get_n(v_m_241, 0, 6); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2426}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2429 = heff_rec_n(2, shape_text__style, (V[]){v_s_2428, NTAG(TAG_Bold)});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2430}), NTAG(TAG_Nil)});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2431});
  V v_t_2433 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2432));
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2433});
  V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2434));
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2435});
  V v_rs_2437 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2410}), v_t_2436));
  V v_t_2438 = (g_list_2ereplicate(heff_dup(v_h_243), NTAG(TAG_Nil)));
  V v_t_2439 = (g_prelude_2e_2b_2b(v_rs_2437, v_t_2438));
  V v_t_2440 = (g_list_2etake(v_h_243, v_t_2439));
  V v_t_2441 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 2, 3);
  V v_t_2442 = (g_std_2ecli_2einteractive_2eformWords(heff_dup(v_fm_242)));
  HeffT2 v_t_2443 = (g_std_2ecli_2eproblemOf_24cpr(v_t_2441, v_t_2442));
  V v_t_2452;
  {
    V v_field_2445 = v_t_2443.f[1];
    int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
    V v_s_2449;
    if ((v_tag_2444 == ((int64_t)0ULL))) {
      V v_p_2447 = v_field_2445;
      V v_t_2448 = ({ V a_0 = v_p_2447; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop(v_p_2447); r_; });
      v_s_2449 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2eformView_str5), heff_strAppend(v_t_2448, ((V)&g_std_2ecli_2einteractive_2eformView_str6)));
    } else {
      heff_drop(v_field_2445);
      v_s_2449 = ((V)&g_std_2ecli_2einteractive_2eformView_str7);
    }
    V v_s_2450 = (g_std_2eterminal_2ewidget_2epad(heff_dup(heff_rfield(v_size_240, 0)), v_s_2449));
    V v_t_2451 = heff_rec_n(2, shape_text__style, (V[]){v_s_2450, NTAG(TAG_Inverse)});
    v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
  }
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
  V v_t_2454 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2453));
  V v_t_2455 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 1, 3);
  V v_t_2456 = ({ V a_0 = v_t_2455; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewordsFrom(a_0, a_1, a_2, a_3)); heff_drop(v_t_2455); r_; });
  V v_t_2457 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_get_n(v_size_240, 0, 2); V a_3 = ((V)&g_std_2ecli_2einteractive_2eformView_str8); V a_4 = v_t_2456; V r_ = (g_list_2efoldl_24f354261656x2102112793(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2456); r_; });
  V v_t_2458 = (g_list_2efoldl_24s34462041x653372414(MK_INT(0LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
  HeffT3 v_t_2459 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
  V v_t_2466;
  {
    V v_field_2461 = v_t_2459.f[1];
    V v_field_2462 = v_t_2459.f[2];
    int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
    if ((v_tag_2460 == ((int64_t)0ULL))) {
      V v_x_2464 = v_field_2461;
      V v_x12_2465 = v_field_2462;
      heff_drop(v_x12_2465);
      v_t_2466 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2464});
    } else {
      heff_drop(v_field_2461);
      heff_drop(v_field_2462);
      v_t_2466 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2467 = (g_std_2ecli_2einteractive_2eformCursor(heff_intAdd(v_t_2457, MK_INT(2LL)), v_t_2458, v_fm_242, v_t_2466));
  return heff_rec_n(2, shape_rows__cursor, (V[]){v_t_2454, v_t_2467});
}
V g_std_2ecli_2einteractive_2eformView_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformView(a[0], a[1], a[2]);
}
Clo g_std_2ecli_2einteractive_2eview_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eview_entry, 2, 0};

V g_std_2ecli_2einteractive_2eview(V v_size_240, V v_m_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_m_241, 5));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    HEFF_LAST return g_std_2ecli_2einteractive_2elistView(v_size_240, v_m_241);
  }
  case TAG_Just: {
    V v_fm_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    return (g_std_2ecli_2einteractive_2eformView(v_size_240, v_m_241, v_fm_243));
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2ecli_2einteractive_2eview_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eview(a[0], a[1]);
}