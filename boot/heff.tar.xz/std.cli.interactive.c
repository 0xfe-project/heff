// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Among 19600
#define TAG_ArrowDown 21357
#define TAG_ArrowLeft 52976
#define TAG_ArrowRight 29566
#define TAG_ArrowUp 57900
#define TAG_BackTab 60780
#define TAG_Backspace 1027
#define TAG_Bold 53386
#define TAG_Char 10597
#define TAG_Continue 52606
#define TAG_Control 37853
#define TAG_Delete 50238
#define TAG_Dim 16148
#define TAG_Dirs 41877
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Enter 13030
#define TAG_Escape 55216
#define TAG_Files 59123
#define TAG_Flagged 28540
#define TAG_Home 35586
#define TAG_Inverse 25398
#define TAG_Many 40086
#define TAG_None 17785
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_PageDown 11812
#define TAG_PageUp 3752
#define TAG_Picked 5619
#define TAG_Plain 3036
#define TAG_Positional 16703
#define TAG_Rest 61983
#define TAG_Sequence 46672
#define TAG_Some 35657
#define TAG_Tab 31265
#define TAG_Typed 36072
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_columns 1181578779
#define LBL_complete 145693389
#define LBL_cursor 598022785
#define LBL_doc 309170
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_filter 672649891
#define LBL_flags 298871457
#define LBL_form 9644427
#define LBL_input 301716452
#define LBL_long 9823043
#define LBL_menu 9843238
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_options 1129866465
#define LBL_part 9928890
#define LBL_pos 320718
#define LBL_prog 9945121
#define LBL_required 351999471
#define LBL_rows 10002080
#define LBL_shape 310758331
#define LBL_short 310771862
#define LBL_slots 310891087
#define LBL_style 311138763
#define LBL_text 10052084
#define LBL_typing 1088343202
#define LBL_values 1123329101
static uint32_t shape_entry__slots__at[] = {LBL_entry, LBL_slots, LBL_at};
static uint32_t shape_options__at[] = {LBL_options, LBL_at};
static uint32_t shape_part__input[] = {LBL_part, LBL_input};
static uint32_t shape_prog__entries__filter__typing__menu__form[] = {LBL_prog, LBL_entries, LBL_filter, LBL_typing, LBL_menu, LBL_form};
static uint32_t shape_rows__cursor[] = {LBL_rows, LBL_cursor};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_list_2eany_24s317268364x1703376737(V);
V g_list_2eany_24s317268364x1703376737_entry(V self, V *a);
extern Clo g_list_2eany_24s317268364x1703376737_clo;
V g_list_2eany_24s624430845x1248965393(V);
V g_list_2eany_24s624430845x1248965393_entry(V self, V *a);
extern Clo g_list_2eany_24s624430845x1248965393_clo;
V g_list_2eany_24s781693278x668067139(V, V);
V g_list_2eany_24s781693278x668067139_entry(V self, V *a);
extern Clo g_list_2eany_24s781693278x668067139_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24f1563799791x267609364(V, V);
V g_list_2efoldl_24f1563799791x267609364_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1563799791x267609364_clo;
V g_list_2efoldl_24f1763211578x1610911617(V, V, V, V, V, V);
V g_list_2efoldl_24f1763211578x1610911617_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1763211578x1610911617_clo;
V g_list_2efoldl_24f354261656x2102112793(V, V, V, V, V);
V g_list_2efoldl_24f354261656x2102112793_entry(V self, V *a);
extern Clo g_list_2efoldl_24f354261656x2102112793_clo;
V g_list_2efoldl_24f545139853x5269120(V, V);
V g_list_2efoldl_24f545139853x5269120_entry(V self, V *a);
extern Clo g_list_2efoldl_24f545139853x5269120_clo;
V g_list_2efoldl_24f547094838x440994078(V, V, V);
V g_list_2efoldl_24f547094838x440994078_entry(V self, V *a);
extern Clo g_list_2efoldl_24f547094838x440994078_clo;
V g_list_2efoldl_24s1396019640x159929943(V, V, V);
V g_list_2efoldl_24s1396019640x159929943_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1396019640x159929943_clo;
V g_list_2efoldl_24s1722219619x1576677028(V, V);
V g_list_2efoldl_24s1722219619x1576677028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1722219619x1576677028_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s6718001x1068992521(V, V, V);
V g_list_2efoldl_24s6718001x1068992521_entry(V self, V *a);
extern Clo g_list_2efoldl_24s6718001x1068992521_clo;
V g_list_2ekeepIf_24s1252894891x837498180(V, V, V, V);
V g_list_2ekeepIf_24s1252894891x837498180_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1252894891x837498180_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1016251237x587084191(V, V, V);
V g_list_2emap_24f1016251237x587084191_entry(V self, V *a);
extern Clo g_list_2emap_24f1016251237x587084191_clo;
V g_list_2emap_24s1171333510x402969237(V);
V g_list_2emap_24s1171333510x402969237_entry(V self, V *a);
extern Clo g_list_2emap_24s1171333510x402969237_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s1539380703x380520933(V);
V g_list_2emap_24s1539380703x380520933_entry(V self, V *a);
extern Clo g_list_2emap_24s1539380703x380520933_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s456747242x756515627(V);
V g_list_2emap_24s456747242x756515627_entry(V self, V *a);
extern Clo g_list_2emap_24s456747242x756515627_clo;
V g_list_2emap_24s865484684x739952503(V);
V g_list_2emap_24s865484684x739952503_entry(V self, V *a);
extern Clo g_list_2emap_24s865484684x739952503_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
V g_std_2ecli_2einteractive_2ecalledAs(V, V);
V g_std_2ecli_2einteractive_2ecalledAs_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2ecalledAs_clo;
V g_std_2ecli_2einteractive_2econtrolOnList(V, V);
V g_std_2ecli_2einteractive_2econtrolOnList_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2econtrolOnList_clo;
V g_std_2ecli_2einteractive_2econtrolOnList_24tok1(V, V, V);
V g_std_2ecli_2einteractive_2econtrolOnList_24tok1_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2econtrolOnList_24tok1_clo;
V g_std_2ecli_2einteractive_2eescapedList(V);
V g_std_2ecli_2einteractive_2eescapedList_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eescapedList_clo;
V g_std_2ecli_2einteractive_2eflagSlot(V);
V g_std_2ecli_2einteractive_2eflagSlot_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eflagSlot_clo;
V g_std_2ecli_2einteractive_2eflagWord(V, V);
V g_std_2ecli_2einteractive_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eflagWord_clo;
V g_std_2ecli_2einteractive_2eformCursor(V, V, V, V);
V g_std_2ecli_2einteractive_2eformCursor_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformCursor_clo;
V g_std_2ecli_2einteractive_2eformStep(V, V, V);
V g_std_2ecli_2einteractive_2eformStep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformStep_clo;
V g_std_2ecli_2einteractive_2eformView(V, V, V);
V g_std_2ecli_2einteractive_2eformView_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformView_clo;
V g_std_2ecli_2einteractive_2eformWords(V);
V g_std_2ecli_2einteractive_2eformWords_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformWords_clo;
V g_std_2ecli_2einteractive_2einputRow(V, V, V);
V g_std_2ecli_2einteractive_2einputRow_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2einputRow_clo;
V g_std_2ecli_2einteractive_2elistStep(V, V);
V g_std_2ecli_2einteractive_2elistStep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2elistStep_clo;
V g_std_2ecli_2einteractive_2elistView(V, V);
V g_std_2ecli_2einteractive_2elistView_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2elistView_clo;
V g_std_2ecli_2einteractive_2emoved(V, V);
V g_std_2ecli_2einteractive_2emoved_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2emoved_clo;
V g_std_2ecli_2einteractive_2epartLabel(V);
V g_std_2ecli_2einteractive_2epartLabel_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epartLabel_clo;
V g_std_2ecli_2einteractive_2epartSaid(V);
V g_std_2ecli_2einteractive_2epartSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epartSaid_clo;
V g_std_2ecli_2einteractive_2epartWords(V, V);
V g_std_2ecli_2einteractive_2epartWords_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epartWords_clo;
V g_std_2ecli_2einteractive_2eplainByte(V);
V g_std_2ecli_2einteractive_2eplainByte_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eplainByte_clo;
V g_std_2ecli_2einteractive_2eplainFrom(V, V);
V g_std_2ecli_2einteractive_2eplainFrom_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eplainFrom_clo;
V g_std_2ecli_2einteractive_2eposWords(V, V);
V g_std_2ecli_2einteractive_2eposWords_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eposWords_clo;
V g_std_2ecli_2einteractive_2equoted(V);
V g_std_2ecli_2einteractive_2equoted_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2equoted_clo;
V g_std_2ecli_2einteractive_2eslotRow(V, V, V);
V g_std_2ecli_2einteractive_2eslotRow_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotRow_clo;
V g_std_2ecli_2einteractive_2eslotRows(V, V, V, V);
V g_std_2ecli_2einteractive_2eslotRows_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotRows_clo;
V g_std_2ecli_2einteractive_2eslotRows_24dps(V, V, V, V, V);
V g_std_2ecli_2einteractive_2eslotRows_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotRows_24dps_clo;
V g_std_2ecli_2einteractive_2eslotStep(V, V, V);
V g_std_2ecli_2einteractive_2eslotStep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotStep_clo;
V g_std_2ecli_2einteractive_2estep(V, V);
V g_std_2ecli_2einteractive_2estep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2estep_clo;
V g_std_2ecli_2einteractive_2eswitchOptions_get(void);
V g_std_2ecli_2einteractive_2etypedOnList(V, V);
V g_std_2ecli_2einteractive_2etypedOnList_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2etypedOnList_clo;
V g_std_2ecli_2einteractive_2etypedOnList_24tok1(V, V, V);
V g_std_2ecli_2einteractive_2etypedOnList_24tok1_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2etypedOnList_24tok1_clo;
V g_std_2ecli_2einteractive_2eupdateAt(V, V, V);
V g_std_2ecli_2einteractive_2eupdateAt_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eupdateAt_clo;
V g_std_2ecli_2einteractive_2eupdateAt_24dps(V, V, V, V);
V g_std_2ecli_2einteractive_2eupdateAt_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eupdateAt_24dps_clo;
V g_std_2ecli_2einteractive_2eview(V, V);
V g_std_2ecli_2einteractive_2eview_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eview_clo;
HeffT2 g_std_2ecli_2eproblemOf_24cpr(V, V);
V g_std_2ecli_2eproblemSaid(V);
V g_std_2ecli_2eproblemSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2eproblemSaid_clo;
V g_std_2eterminal_2ewidget_2ebold(V);
V g_std_2eterminal_2ewidget_2ebold_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ebold_clo;
V g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747(V, V, V, V);
V g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_clo;
V g_std_2eterminal_2ewidget_2echoiceKey(V, V);
V g_std_2eterminal_2ewidget_2echoiceKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2echoiceKey_clo;
V g_std_2eterminal_2ewidget_2efieldKey(V, V);
V g_std_2eterminal_2ewidget_2efieldKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2efieldKey_clo;
V g_std_2eterminal_2ewidget_2einverse(V);
V g_std_2eterminal_2ewidget_2einverse_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2einverse_clo;
V g_std_2eterminal_2ewidget_2emenu_get(void);
V g_std_2eterminal_2ewidget_2emenuFrom(V, V, V);
V g_std_2eterminal_2ewidget_2emenuFrom_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuFrom_clo;
V g_std_2eterminal_2ewidget_2emenuKey(V, V, V);
V g_std_2eterminal_2ewidget_2emenuKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuKey_clo;
V g_std_2eterminal_2ewidget_2epad(V, V);
V g_std_2eterminal_2ewidget_2epad_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2epad_clo;
V g_std_2eterminal_2ewidget_2ewrapGo(V, V, V);
V g_std_2eterminal_2ewidget_2ewrapGo_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ewrapGo_clo;
HEFF_LIT(g_std_2ecli_2einteractive_2eswitchOptions_str0, 2, "on");
HEFF_LIT(g_std_2ecli_2einteractive_2eswitchOptions_str1, 3, "off");

static V g_std_2ecli_2einteractive_2eswitchOptions_val;
static HEFF_ONCE g_std_2ecli_2einteractive_2eswitchOptions_st;
static V g_std_2ecli_2einteractive_2eswitchOptions_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2einteractive_2eswitchOptions_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2einteractive_2eswitchOptions_str1), v_t_240});
}
V g_std_2ecli_2einteractive_2eswitchOptions_get(void) {
  if (HEFF_DONE(g_std_2ecli_2einteractive_2eswitchOptions_st)) return g_std_2ecli_2einteractive_2eswitchOptions_val;
  return heff_global(&g_std_2ecli_2einteractive_2eswitchOptions_val, &g_std_2ecli_2einteractive_2eswitchOptions_st, g_std_2ecli_2einteractive_2eswitchOptions_init);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eflagSlot_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagSlot_str1, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagSlot_str2, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagSlot_str3, 0, "");
Clo g_std_2ecli_2einteractive_2eflagSlot_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eflagSlot_entry, 1, 0};

V g_std_2ecli_2einteractive_2eflagSlot(V v_f_240) {
top: ;
  V v_t_249;
  if (heff_strEq_c(heff_dup(heff_rfield(v_f_240, 2)), ((V)&g_std_2ecli_2einteractive_2eflagSlot_str0))) {
    v_t_249 = heff_tag_n(TAG_Picked, 1, (V[]){heff_rec_n(2, shape_options__at, (V[]){heff_dup(g_std_2ecli_2einteractive_2eswitchOptions_get()), MK_INT(0LL)})});
  } else {
    V v_t_241 = heff_dup(heff_rfield(v_f_240, 4));
    switch (heff_tag_of(v_t_241)) {
    case TAG_Nil: {
      V v_t_242 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_std_2ecli_2einteractive_2eflagSlot_str1)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_243 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_std_2ecli_2einteractive_2eflagSlot_str2)), v_t_242});
      v_t_249 = heff_tag_n(TAG_Typed, 1, (V[]){v_t_243});
      break;
    }
    case TAG_Cons: {
      V v_ru_24t_241_24Cons = heff_take_reuse_n(v_t_241, 0ULL, 2);
      V v_t_246 = heff_dup(heff_rfield(v_f_240, 6));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24t_241_24Cons, 2);
        heff_drop(v_t_246);
        V v_t_247 = heff_rec_n(2, shape_options__at, (V[]){heff_dup(heff_rfield(v_f_240, 4)), MK_INT(0LL)});
        v_t_249 = heff_tag_n(TAG_Picked, 1, (V[]){v_t_247});
      } else {
        heff_drop(v_t_246);
        V v_t_248 = heff_tag_at_n(v_ru_24t_241_24Cons, TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2einteractive_2eflagSlot_str3), heff_dup(heff_rfield(v_f_240, 4))});
        v_t_249 = heff_tag_n(TAG_Picked, 1, (V[]){heff_rec_n(2, shape_options__at, (V[]){v_t_248, MK_INT(0LL)})});
      }
      break;
    }
    default: heff_nomatch(v_t_241);
    }
  }
  return heff_rec_n(2, shape_part__input, (V[]){heff_tag_n(TAG_Flagged, 1, (V[]){v_f_240}), v_t_249});
}
V g_std_2ecli_2einteractive_2eflagSlot_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eflagSlot(a[0]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eposWords_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eposWords_str1, 0, "");
Clo g_std_2ecli_2einteractive_2eposWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eposWords_entry, 2, 0};

V g_std_2ecli_2einteractive_2eposWords(V v_a_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_a_240)) {
  case TAG_One: {
    V v_t_242 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
    V v_t_244 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_243), MK_INT(-1LL)));
    V v_t_245 = heff_strSlice(heff_dup(v_t_241), v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
    if (heff_strEq_c(v_t_245, ((V)&g_std_2ecli_2einteractive_2eposWords_str0))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_246 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
      V v_t_248 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_247), MK_INT(-1LL)));
      V v_t_249 = heff_strSlice(heff_dup(v_t_241), v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    }
  }
  case TAG_Optional: {
    V v_t_2410 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
    V v_t_2412 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_2411), MK_INT(-1LL)));
    V v_t_2413 = heff_strSlice(heff_dup(v_t_241), v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
    if (heff_strEq_c(v_t_2413, ((V)&g_std_2ecli_2einteractive_2eposWords_str1))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_2414 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
      V v_t_2416 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_2415), MK_INT(-1LL)));
      V v_t_2417 = heff_strSlice(heff_dup(v_t_241), v_t_2414, heff_intAdd(v_t_2416, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    }
  }
  case TAG_Many: {
    return (g_prelude_2ewordsFrom(v_t_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  }
  case TAG_Some: {
    return (g_prelude_2ewordsFrom(v_t_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  }
  case TAG_Rest: {
    return (g_prelude_2ewordsFrom(v_t_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_a_240);
  }
}
V g_std_2ecli_2einteractive_2eposWords_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ecli_2einteractive_2eposWords(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str1, 2, "on");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str2, 2, "--");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str3, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str4, 1, "=");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str5, 2, "--");
Clo g_std_2ecli_2einteractive_2eflagWord_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eflagWord_entry, 2, 0};

V g_std_2ecli_2einteractive_2eflagWord(V v_f_240, V v_v_241) {
top: ;
  V v_meta_242 = heff_take_field(v_f_240, 2);
  V v_long_243 = heff_get_n(v_f_240, 0, 8);
  if (heff_strEq_c(v_meta_242, ((V)&g_std_2ecli_2einteractive_2eflagWord_str0))) {
    if (heff_strEq_c(v_v_241, ((V)&g_std_2ecli_2einteractive_2eflagWord_str1))) {
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2einteractive_2eflagWord_str2), v_long_243), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_long_243);
      return NTAG(TAG_Nil);
    }
  } else {
    if (heff_strEq_c_lent(v_v_241, ((V)&g_std_2ecli_2einteractive_2eflagWord_str3), 2)) {
      heff_drop(v_v_241);
      heff_drop(v_long_243);
      return NTAG(TAG_Nil);
    } else {
      V v_t_244 = heff_strAppend(v_long_243, heff_strAppend(((V)&g_std_2ecli_2einteractive_2eflagWord_str4), v_v_241));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2einteractive_2eflagWord_str5), v_t_244), NTAG(TAG_Nil)});
    }
  }
}
V g_std_2ecli_2einteractive_2eflagWord_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eflagWord(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2epartWords_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartWords_str1, 0, "");
Clo g_std_2ecli_2einteractive_2epartWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2epartWords_entry, 2, 0};

V g_std_2ecli_2einteractive_2epartWords(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Positional: {
    V v_p_242 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Typed: {
      V v_t_243 = heff_field(v_x2_241, 0);
      V v_t_244 = heff_strOfRunes(heff_dup(heff_rfield(v_t_243, 0)));
      return ({ V a_0 = heff_rfield(v_p_242, 1); V a_1 = v_t_244; V r_ = (g_std_2ecli_2einteractive_2eposWords(a_0, a_1)); heff_drop(v_t_244); r_; });
    }
    case TAG_Picked: {
      V v_c_245 = heff_field(v_x2_241, 0);
      V v_at_246 = heff_dup(heff_rfield(v_c_245, 1));
      V v_options_247 = heff_dup(heff_rfield(v_c_245, 0));
      HeffT3 v_t_248 = ({ V a_0 = v_at_246; V a_1 = v_options_247; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_options_247); r_; });
      V v_t_2414;
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          V v_x12_2413 = v_field_2411;
          heff_drop(v_x12_2413);
          v_t_2414 = v_x_2412;
        } else {
          heff_drop(v_field_2410);
          heff_drop(v_field_2411);
          v_t_2414 = ((V)&g_std_2ecli_2einteractive_2epartWords_str0);
        }
      }
      return ({ V a_0 = heff_rfield(v_p_242, 1); V a_1 = v_t_2414; V r_ = (g_std_2ecli_2einteractive_2eposWords(a_0, a_1)); heff_drop(v_t_2414); r_; });
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Flagged: {
    V v_f_2415 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Typed: {
      V v_t_2416 = heff_field(v_x2_241, 0);
      V v_s_2417 = heff_strOfRunes(heff_dup(heff_rfield(v_t_2416, 0)));
      V v_t_2418 = (g_prelude_2eskipSpaces(v_s_2417, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_s_2417, 0)) - ((int64_t)1ULL));
      V v_t_2420 = (g_prelude_2eskipSpaces(v_s_2417, heff_box_word(v_t_2419), MK_INT(-1LL)));
      V v_t_2421 = heff_strSlice(v_s_2417, v_t_2418, heff_intAdd(v_t_2420, MK_INT(1LL)));
      HEFF_LAST return g_std_2ecli_2einteractive_2eflagWord(heff_dup(v_f_2415), v_t_2421);
    }
    case TAG_Picked: {
      V v_c_2422 = heff_field(v_x2_241, 0);
      V v_at_2423 = heff_dup(heff_rfield(v_c_2422, 1));
      V v_options_2424 = heff_dup(heff_rfield(v_c_2422, 0));
      HeffT3 v_t_2425 = ({ V a_0 = v_at_2423; V a_1 = v_options_2424; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_options_2424); r_; });
      V v_t_2431;
      {
        V v_field_2427 = v_t_2425.f[1];
        V v_field_2428 = v_t_2425.f[2];
        int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
        if ((v_tag_2426 == ((int64_t)0ULL))) {
          V v_x_2429 = v_field_2427;
          V v_x12_2430 = v_field_2428;
          heff_drop(v_x12_2430);
          v_t_2431 = v_x_2429;
        } else {
          heff_drop(v_field_2427);
          heff_drop(v_field_2428);
          v_t_2431 = ((V)&g_std_2ecli_2einteractive_2epartWords_str1);
        }
      }
      HEFF_LAST return g_std_2ecli_2einteractive_2eflagWord(heff_dup(v_f_2415), v_t_2431);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2epartWords_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ecli_2einteractive_2epartWords(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2eformWords_str0, 2, "--");
Clo g_std_2ecli_2einteractive_2eformWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformWords_entry, 1, 0};

V g_std_2ecli_2einteractive_2eformWords(V v_fm_240) {
top: ;
  V v_entry_241 = heff_take_field(v_fm_240, 0);
  V v_slots_242 = heff_get_n(v_fm_240, 1, 3);
  V v_t_243 = heff_get_n(heff_get_n(v_entry_241, 2, 3), 1, 2);
  V v_rest_244 = ({ V a_0 = v_t_243; V r_ = (g_list_2eany_24s624430845x1248965393(a_0)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_list_2efoldl_24f1563799791x267609364(NTAG(TAG_Nil), heff_dup(v_slots_242)));
  V v_ps_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1722219619x1576677028(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_list_2efoldl_24f545139853x5269120(NTAG(TAG_Nil), v_slots_242));
  V v_fs_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1722219619x1576677028(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_list_2eany_24s317268364x1703376737(v_ps_246));
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_rest_244);
    heff_drop(v_t_249);
    return (g_prelude_2e_2b_2b(v_fs_248, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2einteractive_2eformWords_str0), v_ps_246})));
  } else {
    heff_drop(v_t_249);
    if ((heff_dup(v_rest_244) == NTAG(TAG_True))) {
      heff_drop(v_rest_244);
      return (g_prelude_2e_2b_2b(v_fs_248, v_ps_246));
    } else {
      heff_drop(v_rest_244);
      return (g_prelude_2e_2b_2b(v_ps_246, v_fs_248));
    }
  }
}
V g_std_2ecli_2einteractive_2eformWords_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformWords(a[0]);
}
Clo g_std_2ecli_2einteractive_2eplainByte_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eplainByte_entry, 1, 0};

V g_std_2ecli_2einteractive_2eplainByte(V v_box_24b_240) {
  int64_t v_b_240 = heff_unbox_word(v_box_24b_240);
top: ;
  if (((((int64_t)48ULL) <= v_b_240) && (v_b_240 <= ((int64_t)57ULL)))) {
    return NTAG(TAG_True);
  } else {
    if (((((int64_t)65ULL) <= v_b_240) && (v_b_240 <= ((int64_t)90ULL)))) {
      return NTAG(TAG_True);
    } else {
      if (((((int64_t)97ULL) <= v_b_240) && (v_b_240 <= ((int64_t)122ULL)))) {
        return NTAG(TAG_True);
      } else {
        V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(43LL), NTAG(TAG_Nil)});
        V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(64LL), heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(37LL), v_t_241})});
        V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(58LL), heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(44LL), v_t_242})});
        V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(47LL), heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(61LL), v_t_243})});
        V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(95LL), heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(46LL), v_t_244})});
        return ({ V a_0 = heff_box_word(v_b_240); V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(45LL), v_t_245}); V r_ = (g_list_2eany_24s781693278x668067139(a_0, b_1)); heff_drop(b_1); r_; });
      }
    }
  }
}
V g_std_2ecli_2einteractive_2eplainByte_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eplainByte(a[0]);
}
Clo g_std_2ecli_2einteractive_2eplainFrom_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eplainFrom_entry, 2, 0};

V g_std_2ecli_2einteractive_2eplainFrom(V v_w_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_w_240, 0)) <= v_i_241)) {
    return NTAG(TAG_True);
  } else {
    V v_t_242 = (g_std_2ecli_2einteractive_2eplainByte(heff_strByteAt_lent(v_w_240, heff_box_word(v_i_241), 2)));
    if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
      heff_drop(v_t_242);
      V t_0 = v_w_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_w_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_242);
      return NTAG(TAG_False);
    }
  }
}
V g_std_2ecli_2einteractive_2eplainFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2eplainFrom(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str1, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str2, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str3, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str4, 4, "'\\''");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str5, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str6, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str7, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str8, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str9, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str10, 4, "'\\''");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str11, 1, "'");
HEFF_LIT(g_std_2ecli_2einteractive_2equoted_str12, 1, "'");
Clo g_std_2ecli_2einteractive_2equoted_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2equoted_entry, 1, 0};

V g_std_2ecli_2einteractive_2equoted(V v_w_240) {
top: ;
  if (!heff_strEq_c_lent(v_w_240, ((V)&g_std_2ecli_2einteractive_2equoted_str0), 2)) {
    V v_t_241 = (g_std_2ecli_2einteractive_2eplainFrom(v_w_240, MK_INT(0LL)));
    if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
      heff_drop(v_t_241);
      return v_w_240;
    } else {
      heff_drop(v_t_241);
      V v_x2_242 = ({ V b_0 = ((V)&g_std_2ecli_2einteractive_2equoted_str1); V a_1 = v_w_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ecli_2einteractive_2equoted_str2), v_w_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_w_240); r_; });
      V v_t_245;
      switch (heff_tag_of(v_x2_242)) {
      case TAG_Nil: {
        v_t_245 = ((V)&g_std_2ecli_2einteractive_2equoted_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_243 = heff_field(v_x2_242, 0);
        V v_xs_244 = heff_field(v_x2_242, 1);
        heff_take_n(v_x2_242, 3ULL, 2);
        v_t_245 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2equoted_str4); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
        break;
      }
      default: heff_nomatch(v_x2_242);
      }
      return heff_strAppend(((V)&g_std_2ecli_2einteractive_2equoted_str5), heff_strAppend(v_t_245, ((V)&g_std_2ecli_2einteractive_2equoted_str6)));
    }
  } else {
    V v_x2_246 = ({ V b_0 = ((V)&g_std_2ecli_2einteractive_2equoted_str7); V a_1 = v_w_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ecli_2einteractive_2equoted_str8), v_w_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_w_240); r_; });
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_std_2ecli_2einteractive_2equoted_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2equoted_str10); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_strAppend(((V)&g_std_2ecli_2einteractive_2equoted_str11), heff_strAppend(v_t_249, ((V)&g_std_2ecli_2einteractive_2equoted_str12)));
  }
}
V g_std_2ecli_2einteractive_2equoted_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2equoted(a[0]);
}
Clo g_std_2ecli_2einteractive_2emoved_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2emoved_entry, 2, 0};

V g_std_2ecli_2einteractive_2emoved(V v_k_240, V v_m_241) {
top: ;
  V v_t_242 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = heff_dup(v_m_241); V b_4 = MK_INT(0LL); V a_5 = heff_rfield(v_m_241, 1); V r_ = (g_list_2efoldl_24f1763211578x1610911617(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(b_4); r_; });
  V v_t_243 = (g_std_2eterminal_2ewidget_2emenuKey(v_t_242, v_k_240, heff_take_field(v_m_241, 4)));
  V v_t_244 = ({ V rv_4 = v_t_243; V rr_ = heff_rec_reuse_nf(v_m_241, 47ULL, 6, shape_prog__entries__filter__typing__menu__form, 3327u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  return heff_tag_n(TAG_Continue, 1, (V[]){v_t_244});
}
V g_std_2ecli_2einteractive_2emoved_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2emoved(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2ecli_2einteractive_2etypedOnList_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2etypedOnList_entry, 2, 0};

V g_std_2ecli_2einteractive_2etypedOnList(V v_c_240, V v_m_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_m_241, 3));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_f_243 = ({ V b_0 = heff_tag_n(TAG_Char, 1, (V[]){v_c_240}); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_244 = heff_take_field(v_m_241, 3);
    V v_t_248;
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      v_t_248 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = heff_dup(heff_rfield(v_f_243, 0));
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nil: {
        v_t_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_245, 0ULL, 2);
        v_t_248 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
    }
    V v_t_249 = ({ V rv_2 = v_f_243; V rv_3 = v_t_248; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_249});
  } else {
    heff_drop(v_t_242);
    if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(113LL))) {
      heff_drop(v_c_240);
      heff_drop_rec(v_m_241, 6);
      return heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
    } else {
      if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(106LL))) {
        heff_drop(v_c_240);
        return ({ V b_0 = NTAG(TAG_ArrowDown); V a_1 = v_m_241; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
      } else {
        if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(107LL))) {
          heff_drop(v_c_240);
          return ({ V b_0 = NTAG(TAG_ArrowUp); V a_1 = v_m_241; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
        } else {
          if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(47LL))) {
            heff_drop(v_c_240);
            V v_t_2410 = ({ V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_m_241, 55ULL, 6, shape_prog__entries__filter__typing__menu__form, 3903u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
            return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2410});
          } else {
            V v_f_2411 = ({ V b_0 = heff_tag_n(TAG_Char, 1, (V[]){v_c_240}); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2412 = heff_take_field(v_m_241, 3);
            V v_t_2416;
            if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
              heff_drop(v_t_2412);
              v_t_2416 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2412);
              V v_t_2413 = heff_dup(heff_rfield(v_f_2411, 0));
              switch (heff_tag_of(v_t_2413)) {
              case TAG_Nil: {
                v_t_2416 = NTAG(TAG_False);
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_t_2413, 0ULL, 2);
                v_t_2416 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_t_2413);
              }
            }
            V v_t_2417 = ({ V rv_2 = v_f_2411; V rv_3 = v_t_2416; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
            return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2417});
          }
        }
      }
    }
  }
}
V g_std_2ecli_2einteractive_2etypedOnList_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2etypedOnList(a[0], a[1]);
}
Clo g_std_2ecli_2einteractive_2econtrolOnList_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2econtrolOnList_entry, 2, 0};

V g_std_2ecli_2einteractive_2econtrolOnList(V v_c_240, V v_m_241) {
top: ;
  if ((heff_runeEq_c(heff_dup(v_c_240), MK_INT(110LL)) || heff_runeEq_c(heff_dup(v_c_240), MK_INT(112LL)))) {
    return ({ V b_0 = heff_tag_n(TAG_Control, 1, (V[]){v_c_240}); V a_1 = v_m_241; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
  } else {
    V v_f_242 = ({ V b_0 = heff_tag_n(TAG_Control, 1, (V[]){v_c_240}); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_243 = heff_take_field(v_m_241, 3);
    V v_t_247;
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      v_t_247 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V v_t_244 = heff_dup(heff_rfield(v_f_242, 0));
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nil: {
        v_t_247 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_244, 0ULL, 2);
        v_t_247 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_244);
      }
    }
    V v_t_248 = ({ V rv_2 = v_f_242; V rv_3 = v_t_247; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_248});
  }
}
V g_std_2ecli_2einteractive_2econtrolOnList_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2econtrolOnList(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eescapedList_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eescapedList_str1, 0, "");
Clo g_std_2ecli_2einteractive_2eescapedList_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eescapedList_entry, 1, 0};

V g_std_2ecli_2einteractive_2eescapedList(V v_m_240) {
top: ;
  V v_typing_241 = heff_take_field(v_m_240, 3);
  V v_prog_242 = heff_take_field(v_m_240, 0);
  V v_entries_243 = heff_take_field(v_m_240, 1);
  V v_form_244 = heff_get_n(v_m_240, 5, 6);
  if ((heff_dup(v_typing_241) == NTAG(TAG_True))) {
    heff_drop(v_typing_241);
    V v_t_245 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_std_2ecli_2einteractive_2eescapedList_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_f_246 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_std_2ecli_2einteractive_2eescapedList_str1)), v_t_245});
    V v_t_247 = heff_dup(heff_rfield(v_f_246, 0));
    V v_t_2410;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nil: {
      v_t_2410 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_247, 0ULL, 2);
      v_t_2410 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    return heff_tag_n(TAG_Continue, 1, (V[]){heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_242, v_entries_243, v_f_246, v_t_2410, heff_dup(g_std_2eterminal_2ewidget_2emenu_get()), v_form_244})});
  } else {
    heff_drop(v_typing_241);
    heff_drop(v_prog_242);
    heff_drop(v_entries_243);
    heff_drop(v_form_244);
    return heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
  }
}
V g_std_2ecli_2einteractive_2eescapedList_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eescapedList(a[0]);
}
Clo g_std_2ecli_2einteractive_2elistStep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2elistStep_entry, 2, 0};

V g_std_2ecli_2einteractive_2elistStep(V v_k_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    V v_c_242 = heff_field(v_k_240, 0);
    HEFF_LAST return g_std_2ecli_2einteractive_2etypedOnList(heff_dup(v_c_242), v_m_241);
  }
  case TAG_Enter: {
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_m_241, 4)), 0, 1);
    V v_t_244 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s1252894891x837498180(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
    HeffT3 v_t_245 = ({ V a_0 = v_t_243; V a_1 = v_t_244; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      V v_field_248 = v_t_245.f[2];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        V v_x12_2410 = v_field_248;
        heff_drop(v_x12_2410);
        V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_x_249, 2)), 1, 2);
        V v_t_2412 = (g_list_2emap_24s1539380703x380520933(v_t_2411));
        V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_x_249, 2)), 0, 2);
        V v_t_2414 = (g_list_2emap_24s456747242x756515627(v_t_2413));
        V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2414));
        V v_t_2416 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_entry__slots__at, (V[]){v_x_249, v_t_2415, MK_INT(0LL)})});
        V v_t_2417 = ({ V rv_5 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2417});
      } else {
        heff_drop(v_field_247);
        heff_drop(v_field_248);
        return heff_tag_n(TAG_Continue, 1, (V[]){v_m_241});
      }
    }
  }
  case TAG_Escape: {
    return (g_std_2ecli_2einteractive_2eescapedList(v_m_241));
  }
  case TAG_Tab: {
    V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_m_241, 4)), 0, 1);
    V v_t_2419 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s1252894891x837498180(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
    HeffT3 v_t_2420 = ({ V a_0 = v_t_2418; V a_1 = v_t_2419; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2419); r_; });
    {
      V v_field_2422 = v_t_2420.f[1];
      V v_field_2423 = v_t_2420.f[2];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_x_2424 = v_field_2422;
        V v_x12_2425 = v_field_2423;
        heff_drop(v_x12_2425);
        V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_x_2424, 2)), 1, 2);
        V v_t_2427 = (g_list_2emap_24s1539380703x380520933(v_t_2426));
        V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_x_2424, 2)), 0, 2);
        V v_t_2429 = (g_list_2emap_24s456747242x756515627(v_t_2428));
        V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2427, v_t_2429));
        V v_t_2431 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_entry__slots__at, (V[]){v_x_2424, v_t_2430, MK_INT(0LL)})});
        V v_t_2432 = ({ V rv_5 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2432});
      } else {
        heff_drop(v_field_2422);
        heff_drop(v_field_2423);
        return heff_tag_n(TAG_Continue, 1, (V[]){v_m_241});
      }
    }
  }
  case TAG_BackTab: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_Backspace: {
    V v_f_2433 = ({ V b_0 = NTAG(TAG_Backspace); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2434 = heff_take_field(v_m_241, 3);
    V v_t_2438;
    if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
      heff_drop(v_t_2434);
      v_t_2438 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2434);
      V v_t_2435 = heff_dup(heff_rfield(v_f_2433, 0));
      switch (heff_tag_of(v_t_2435)) {
      case TAG_Nil: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2435, 0ULL, 2);
        v_t_2438 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2435);
      }
    }
    V v_t_2439 = ({ V rv_2 = v_f_2433; V rv_3 = v_t_2438; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2439});
  }
  case TAG_Delete: {
    V v_f_2440 = ({ V b_0 = NTAG(TAG_Delete); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2441 = heff_take_field(v_m_241, 3);
    V v_t_2445;
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop(v_t_2441);
      v_t_2445 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2441);
      V v_t_2442 = heff_dup(heff_rfield(v_f_2440, 0));
      switch (heff_tag_of(v_t_2442)) {
      case TAG_Nil: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2442, 0ULL, 2);
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2442);
      }
    }
    V v_t_2446 = ({ V rv_2 = v_f_2440; V rv_3 = v_t_2445; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2446});
  }
  case TAG_ArrowUp: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_ArrowDown: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_ArrowLeft: {
    V v_f_2447 = ({ V b_0 = NTAG(TAG_ArrowLeft); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2448 = heff_take_field(v_m_241, 3);
    V v_t_2452;
    if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
      heff_drop(v_t_2448);
      v_t_2452 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2448);
      V v_t_2449 = heff_dup(heff_rfield(v_f_2447, 0));
      switch (heff_tag_of(v_t_2449)) {
      case TAG_Nil: {
        v_t_2452 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2449, 0ULL, 2);
        v_t_2452 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2449);
      }
    }
    V v_t_2453 = ({ V rv_2 = v_f_2447; V rv_3 = v_t_2452; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2453});
  }
  case TAG_ArrowRight: {
    V v_f_2454 = ({ V b_0 = NTAG(TAG_ArrowRight); V a_1 = heff_take_field(v_m_241, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2455 = heff_take_field(v_m_241, 3);
    V v_t_2459;
    if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
      heff_drop(v_t_2455);
      v_t_2459 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2455);
      V v_t_2456 = heff_dup(heff_rfield(v_f_2454, 0));
      switch (heff_tag_of(v_t_2456)) {
      case TAG_Nil: {
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2456, 0ULL, 2);
        v_t_2459 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2456);
      }
    }
    V v_t_2460 = ({ V rv_2 = v_f_2454; V rv_3 = v_t_2459; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2460});
  }
  case TAG_Home: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_End: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_PageUp: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_PageDown: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_Control: {
    V v_c_2461 = heff_field(v_k_240, 0);
    HEFF_LAST return g_std_2ecli_2einteractive_2econtrolOnList(heff_dup(v_c_2461), v_m_241);
  }
  case TAG_Sequence: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2ecli_2einteractive_2elistStep_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2elistStep(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2ecli_2einteractive_2eupdateAt_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eupdateAt_entry, 3, 0};

V g_std_2ecli_2einteractive_2eupdateAt(V v_i_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_g_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      V v_t_245 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_243}));
      return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_xs_244});
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = (g_std_2ecli_2einteractive_2eupdateAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_g_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2einteractive_2eupdateAt_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eupdateAt(a[0], a[1], a[2]);
}
Clo g_std_2ecli_2einteractive_2eupdateAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eupdateAt_24dps_entry, 4, 0};

V g_std_2ecli_2einteractive_2eupdateAt_24dps(V v_i_240, V v_g_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_g_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_246 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_244}));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_xs_245}));
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_g_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_i_240 = t_0;
      v_g_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2einteractive_2eupdateAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eupdateAt_24dps(a[0], a[1], a[2], a[3]);
}
V g_std_2ecli_2einteractive_2eslotStep_lam0(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam1(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam2(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam3(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam4(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam5(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam6(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam7(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam8(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam9(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam10(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam11(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam12(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam13(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam14(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam15(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam16(V self, V *args);
Clo g_std_2ecli_2einteractive_2eslotStep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotStep_entry, 3, 0};

V g_std_2ecli_2einteractive_2eslotStep(V v_k_240, V v_m_241, V v_fm_242) {
top: ;
  V v_at_243 = heff_take_field(v_fm_242, 2);
  V v_slots_244 = heff_take_field(v_fm_242, 1);
  V v_entry_245 = heff_get_n(v_fm_242, 0, 3);
  V v_prog_246 = heff_take_field(v_m_241, 0);
  V v_entries_247 = heff_take_field(v_m_241, 1);
  V v_filter_248 = heff_take_field(v_m_241, 2);
  V v_typing_249 = heff_take_field(v_m_241, 3);
  V v_menu_2410 = heff_get_n(v_m_241, 4, 6);
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    V v_c_2411 = heff_field(v_k_240, 0);
    V v_ru_24k_240_24Char = heff_take_reuse_n(v_k_240, 1ULL, 1);
    HeffT3 v_t_2412 = (g_list_2edrop_24cpr(heff_dup(v_at_243), v_slots_244));
    V v_t_2421;
    {
      V v_field_2414 = v_t_2412.f[1];
      V v_field_2415 = v_t_2412.f[2];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        V v_x_2416 = v_field_2414;
        V v_x12_2417 = v_field_2415;
        heff_drop(v_x12_2417);
        V v_t_2418 = heff_get_n(v_x_2416, 1, 2);
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Typed: {
          heff_take_n(v_t_2418, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_Picked: {
          heff_take_n(v_t_2418, 0ULL, 1);
          v_t_2421 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
      } else {
        heff_drop(v_field_2414);
        heff_drop(v_field_2415);
        v_t_2421 = NTAG(TAG_False);
      }
    }
    if (((heff_dup(v_t_2421) == NTAG(TAG_True)) && heff_runeEq_c(heff_dup(v_c_2411), MK_INT(113LL)))) {
      heff_drop(v_at_243);
      heff_drop(v_slots_244);
      heff_drop(v_entry_245);
      heff_drop(v_c_2411);
      heff_drop(v_t_2421);
      V v_t_2422 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2422});
    } else {
      heff_drop(v_t_2421);
      HeffT3 v_t_2423 = (g_list_2edrop_24cpr(heff_dup(v_at_243), v_slots_244));
      V v_t_2432;
      {
        V v_field_2425 = v_t_2423.f[1];
        V v_field_2426 = v_t_2423.f[2];
        int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
        if ((v_tag_2424 == ((int64_t)0ULL))) {
          V v_x_2427 = v_field_2425;
          V v_x12_2428 = v_field_2426;
          heff_drop(v_x12_2428);
          V v_t_2429 = heff_get_n(v_x_2427, 1, 2);
          switch (heff_tag_of(v_t_2429)) {
          case TAG_Typed: {
            heff_take_n(v_t_2429, 0ULL, 1);
            v_t_2432 = NTAG(TAG_False);
            break;
          }
          case TAG_Picked: {
            heff_take_n(v_t_2429, 0ULL, 1);
            v_t_2432 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_t_2429);
          }
        } else {
          heff_drop(v_field_2425);
          heff_drop(v_field_2426);
          v_t_2432 = NTAG(TAG_False);
        }
      }
      if (((heff_dup(v_t_2432) == NTAG(TAG_True)) && heff_runeEq_c(heff_dup(v_c_2411), MK_INT(106LL)))) {
        heff_drop(v_c_2411);
        heff_drop(v_t_2432);
        V v_t_2438;
        switch (heff_tag_of(v_slots_244)) {
        case TAG_Nil: {
          heff_drop(v_at_243);
          v_t_2438 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          V v_t_2435 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_slots_244));
          V v_t_2436 = heff_intAdd(heff_intAdd(v_at_243, MK_INT(1LL)), v_t_2435);
          V v_t_2437 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_slots_244));
          v_t_2438 = heff_intMod(v_t_2436, v_t_2437);
          break;
        }
        default: heff_nomatch(v_slots_244);
        }
        V v_fm_2439 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_slots_244, v_t_2438});
        V v_t_2440 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_2439})});
        return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2440});
      } else {
        heff_drop(v_t_2432);
        HeffT3 v_t_2441 = (g_list_2edrop_24cpr(heff_dup(v_at_243), v_slots_244));
        V v_t_2450;
        {
          V v_field_2443 = v_t_2441.f[1];
          V v_field_2444 = v_t_2441.f[2];
          int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
          if ((v_tag_2442 == ((int64_t)0ULL))) {
            V v_x_2445 = v_field_2443;
            V v_x12_2446 = v_field_2444;
            heff_drop(v_x12_2446);
            V v_t_2447 = heff_get_n(v_x_2445, 1, 2);
            switch (heff_tag_of(v_t_2447)) {
            case TAG_Typed: {
              heff_take_n(v_t_2447, 0ULL, 1);
              v_t_2450 = NTAG(TAG_False);
              break;
            }
            case TAG_Picked: {
              heff_take_n(v_t_2447, 0ULL, 1);
              v_t_2450 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_t_2447);
            }
          } else {
            heff_drop(v_field_2443);
            heff_drop(v_field_2444);
            v_t_2450 = NTAG(TAG_False);
          }
        }
        if (((heff_dup(v_t_2450) == NTAG(TAG_True)) && heff_runeEq_c(heff_dup(v_c_2411), MK_INT(107LL)))) {
          heff_drop(v_c_2411);
          heff_drop(v_t_2450);
          V v_t_2456;
          switch (heff_tag_of(v_slots_244)) {
          case TAG_Nil: {
            heff_drop(v_at_243);
            v_t_2456 = MK_INT(0LL);
            break;
          }
          case TAG_Cons: {
            V v_t_2453 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_slots_244));
            V v_t_2454 = heff_intAdd(heff_intAdd(v_at_243, MK_INT(-1LL)), v_t_2453);
            V v_t_2455 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_slots_244));
            v_t_2456 = heff_intMod(v_t_2454, v_t_2455);
            break;
          }
          default: heff_nomatch(v_slots_244);
          }
          V v_fm_2457 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_slots_244, v_t_2456});
          V v_t_2458 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_2457})});
          return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2458});
        } else {
          heff_drop(v_t_2450);
          V v_t_2467 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam0, 1, 1, (V[]){v_c_2411}), v_slots_244));
          V v_fm_2468 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_2467, v_at_243});
          V v_t_2469 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_2468})});
          return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2469});
        }
      }
    }
  }
  case TAG_Enter: {
    V v_t_2478 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam1, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_2479 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_2478, v_at_243});
    V v_t_2480 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_2479})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2480});
  }
  case TAG_Escape: {
    V v_t_2489 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam2, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_2490 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_2489, v_at_243});
    V v_t_2491 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_2490})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2491});
  }
  case TAG_Tab: {
    V v_t_24100 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam3, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_24101 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24100, v_at_243});
    V v_t_24102 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24101})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24102});
  }
  case TAG_BackTab: {
    V v_t_24111 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam4, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_24112 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24111, v_at_243});
    V v_t_24113 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24112})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24113});
  }
  case TAG_Backspace: {
    V v_t_24122 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam5, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_24123 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24122, v_at_243});
    V v_t_24124 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24123})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24124});
  }
  case TAG_Delete: {
    V v_t_24133 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam6, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_24134 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24133, v_at_243});
    V v_t_24135 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24134})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24135});
  }
  case TAG_ArrowUp: {
    V v_t_24144 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam7, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_24145 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24144, v_at_243});
    V v_t_24146 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24145})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24146});
  }
  case TAG_ArrowDown: {
    V v_t_24155 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam8, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_24156 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24155, v_at_243});
    V v_t_24157 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24156})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24157});
  }
  case TAG_ArrowLeft: {
    V v_t_24166 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam9, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_24167 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24166, v_at_243});
    V v_t_24168 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24167})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24168});
  }
  case TAG_ArrowRight: {
    V v_t_24177 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam10, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_24178 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24177, v_at_243});
    V v_t_24179 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24178})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24179});
  }
  case TAG_Home: {
    V v_t_24188 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam11, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_24189 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24188, v_at_243});
    V v_t_24190 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24189})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24190});
  }
  case TAG_End: {
    V v_t_24199 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam12, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_24200 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24199, v_at_243});
    V v_t_24201 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24200})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24201});
  }
  case TAG_PageUp: {
    V v_t_24210 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam13, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_24211 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24210, v_at_243});
    V v_t_24212 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24211})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24212});
  }
  case TAG_PageDown: {
    V v_t_24221 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam14, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_24222 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24221, v_at_243});
    V v_t_24223 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24222})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24223});
  }
  case TAG_Control: {
    V v_c_24224 = heff_field(v_k_240, 0);
    V v_ru_24k_240_24Control = heff_take_reuse_n(v_k_240, 1ULL, 1);
    if (heff_runeEq_c(heff_dup(v_c_24224), MK_INT(110LL))) {
      heff_drop(v_c_24224);
      V v_t_24230;
      switch (heff_tag_of(v_slots_244)) {
      case TAG_Nil: {
        heff_drop(v_at_243);
        v_t_24230 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        V v_t_24227 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_slots_244));
        V v_t_24228 = heff_intAdd(heff_intAdd(v_at_243, MK_INT(1LL)), v_t_24227);
        V v_t_24229 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_slots_244));
        v_t_24230 = heff_intMod(v_t_24228, v_t_24229);
        break;
      }
      default: heff_nomatch(v_slots_244);
      }
      V v_fm_24231 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_slots_244, v_t_24230});
      V v_t_24232 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24231})});
      return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_24232});
    } else {
      if (heff_runeEq_c(heff_dup(v_c_24224), MK_INT(112LL))) {
        heff_drop(v_c_24224);
        V v_t_24238;
        switch (heff_tag_of(v_slots_244)) {
        case TAG_Nil: {
          heff_drop(v_at_243);
          v_t_24238 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          V v_t_24235 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_slots_244));
          V v_t_24236 = heff_intAdd(heff_intAdd(v_at_243, MK_INT(-1LL)), v_t_24235);
          V v_t_24237 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_slots_244));
          v_t_24238 = heff_intMod(v_t_24236, v_t_24237);
          break;
        }
        default: heff_nomatch(v_slots_244);
        }
        V v_fm_24239 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_slots_244, v_t_24238});
        V v_t_24240 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24239})});
        return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_24240});
      } else {
        V v_t_24249 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam15, 1, 1, (V[]){v_c_24224}), v_slots_244));
        V v_fm_24250 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24249, v_at_243});
        V v_t_24251 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24250})});
        return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_24251});
      }
    }
  }
  case TAG_Sequence: {
    V v_t_24261 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(v_at_243), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam16, 1, 1, (V[]){v_k_240}), v_slots_244));
    V v_fm_24262 = heff_rec_n(3, shape_entry__slots__at, (V[]){v_entry_245, v_t_24261, v_at_243});
    V v_t_24263 = heff_rec_n(6, shape_prog__entries__filter__typing__menu__form, (V[]){v_prog_246, v_entries_247, v_filter_248, v_typing_249, v_menu_2410, heff_tag_n(TAG_Just, 1, (V[]){v_fm_24262})});
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24263});
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2ecli_2einteractive_2eslotStep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eslotStep(a[0], a[1], a[2]);
}
V g_std_2ecli_2einteractive_2eslotStep_lam0(V self, V *args) {
  V v_s_2459 = args[0];
  V v_c_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_2460 = heff_take_field(v_s_2459, 0);
  V v_input_2461 = heff_get_n(v_s_2459, 1, 2);
  V v_t_2466;
  switch (heff_tag_of(v_input_2461)) {
  case TAG_Typed: {
    V v_f_2462 = heff_field(v_input_2461, 0);
    V v_ru_24input_2461_24Typed = heff_take_reuse_n(v_input_2461, 1ULL, 1);
    V v_t_2463 = ({ V b_0 = heff_tag_n(TAG_Char, 1, (V[]){v_c_2411}); V a_1 = v_f_2462; V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    v_t_2466 = heff_tag_at_n(v_ru_24input_2461_24Typed, TAG_Typed, 1, (V[]){v_t_2463});
    break;
  }
  case TAG_Picked: {
    V v_c_2464 = heff_field(v_input_2461, 0);
    V v_ru_24input_2461_24Picked = heff_take_reuse_n(v_input_2461, 1ULL, 1);
    V v_t_2465 = ({ V b_0 = heff_tag_n(TAG_Char, 1, (V[]){v_c_2411}); V a_1 = v_c_2464; V r_ = (g_std_2eterminal_2ewidget_2echoiceKey(b_0, a_1)); heff_drop(b_0); r_; });
    v_t_2466 = heff_tag_at_n(v_ru_24input_2461_24Picked, TAG_Picked, 1, (V[]){v_t_2465});
    break;
  }
  default: heff_nomatch(v_input_2461);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_2460, v_t_2466});
}
V g_std_2ecli_2einteractive_2eslotStep_lam1(V self, V *args) {
  V v_s_2470 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_2471 = heff_take_field(v_s_2470, 0);
  V v_input_2472 = heff_get_n(v_s_2470, 1, 2);
  V v_t_2477;
  switch (heff_tag_of(v_input_2472)) {
  case TAG_Typed: {
    V v_f_2473 = heff_field(v_input_2472, 0);
    V v_ru_24input_2472_24Typed = heff_take_reuse_n(v_input_2472, 1ULL, 1);
    V v_t_2474 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_2473));
    v_t_2477 = heff_tag_at_n(v_ru_24input_2472_24Typed, TAG_Typed, 1, (V[]){v_t_2474});
    break;
  }
  case TAG_Picked: {
    V v_c_2475 = heff_field(v_input_2472, 0);
    V v_ru_24input_2472_24Picked = heff_take_reuse_n(v_input_2472, 1ULL, 1);
    V v_t_2476 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_2475));
    v_t_2477 = heff_tag_at_n(v_ru_24input_2472_24Picked, TAG_Picked, 1, (V[]){v_t_2476});
    break;
  }
  default: heff_nomatch(v_input_2472);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_2471, v_t_2477});
}
V g_std_2ecli_2einteractive_2eslotStep_lam2(V self, V *args) {
  V v_s_2481 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_2482 = heff_take_field(v_s_2481, 0);
  V v_input_2483 = heff_get_n(v_s_2481, 1, 2);
  V v_t_2488;
  switch (heff_tag_of(v_input_2483)) {
  case TAG_Typed: {
    V v_f_2484 = heff_field(v_input_2483, 0);
    V v_ru_24input_2483_24Typed = heff_take_reuse_n(v_input_2483, 1ULL, 1);
    V v_t_2485 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_2484));
    v_t_2488 = heff_tag_at_n(v_ru_24input_2483_24Typed, TAG_Typed, 1, (V[]){v_t_2485});
    break;
  }
  case TAG_Picked: {
    V v_c_2486 = heff_field(v_input_2483, 0);
    V v_ru_24input_2483_24Picked = heff_take_reuse_n(v_input_2483, 1ULL, 1);
    V v_t_2487 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_2486));
    v_t_2488 = heff_tag_at_n(v_ru_24input_2483_24Picked, TAG_Picked, 1, (V[]){v_t_2487});
    break;
  }
  default: heff_nomatch(v_input_2483);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_2482, v_t_2488});
}
V g_std_2ecli_2einteractive_2eslotStep_lam3(V self, V *args) {
  V v_s_2492 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_2493 = heff_take_field(v_s_2492, 0);
  V v_input_2494 = heff_get_n(v_s_2492, 1, 2);
  V v_t_2499;
  switch (heff_tag_of(v_input_2494)) {
  case TAG_Typed: {
    V v_f_2495 = heff_field(v_input_2494, 0);
    V v_ru_24input_2494_24Typed = heff_take_reuse_n(v_input_2494, 1ULL, 1);
    V v_t_2496 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_2495));
    v_t_2499 = heff_tag_at_n(v_ru_24input_2494_24Typed, TAG_Typed, 1, (V[]){v_t_2496});
    break;
  }
  case TAG_Picked: {
    V v_c_2497 = heff_field(v_input_2494, 0);
    V v_ru_24input_2494_24Picked = heff_take_reuse_n(v_input_2494, 1ULL, 1);
    V v_t_2498 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_2497));
    v_t_2499 = heff_tag_at_n(v_ru_24input_2494_24Picked, TAG_Picked, 1, (V[]){v_t_2498});
    break;
  }
  default: heff_nomatch(v_input_2494);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_2493, v_t_2499});
}
V g_std_2ecli_2einteractive_2eslotStep_lam4(V self, V *args) {
  V v_s_24103 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_24104 = heff_take_field(v_s_24103, 0);
  V v_input_24105 = heff_get_n(v_s_24103, 1, 2);
  V v_t_24110;
  switch (heff_tag_of(v_input_24105)) {
  case TAG_Typed: {
    V v_f_24106 = heff_field(v_input_24105, 0);
    V v_ru_24input_24105_24Typed = heff_take_reuse_n(v_input_24105, 1ULL, 1);
    V v_t_24107 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24106));
    v_t_24110 = heff_tag_at_n(v_ru_24input_24105_24Typed, TAG_Typed, 1, (V[]){v_t_24107});
    break;
  }
  case TAG_Picked: {
    V v_c_24108 = heff_field(v_input_24105, 0);
    V v_ru_24input_24105_24Picked = heff_take_reuse_n(v_input_24105, 1ULL, 1);
    V v_t_24109 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24108));
    v_t_24110 = heff_tag_at_n(v_ru_24input_24105_24Picked, TAG_Picked, 1, (V[]){v_t_24109});
    break;
  }
  default: heff_nomatch(v_input_24105);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_24104, v_t_24110});
}
V g_std_2ecli_2einteractive_2eslotStep_lam5(V self, V *args) {
  V v_s_24114 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_24115 = heff_take_field(v_s_24114, 0);
  V v_input_24116 = heff_get_n(v_s_24114, 1, 2);
  V v_t_24121;
  switch (heff_tag_of(v_input_24116)) {
  case TAG_Typed: {
    V v_f_24117 = heff_field(v_input_24116, 0);
    V v_ru_24input_24116_24Typed = heff_take_reuse_n(v_input_24116, 1ULL, 1);
    V v_t_24118 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24117));
    v_t_24121 = heff_tag_at_n(v_ru_24input_24116_24Typed, TAG_Typed, 1, (V[]){v_t_24118});
    break;
  }
  case TAG_Picked: {
    V v_c_24119 = heff_field(v_input_24116, 0);
    V v_ru_24input_24116_24Picked = heff_take_reuse_n(v_input_24116, 1ULL, 1);
    V v_t_24120 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24119));
    v_t_24121 = heff_tag_at_n(v_ru_24input_24116_24Picked, TAG_Picked, 1, (V[]){v_t_24120});
    break;
  }
  default: heff_nomatch(v_input_24116);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_24115, v_t_24121});
}
V g_std_2ecli_2einteractive_2eslotStep_lam6(V self, V *args) {
  V v_s_24125 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_24126 = heff_take_field(v_s_24125, 0);
  V v_input_24127 = heff_get_n(v_s_24125, 1, 2);
  V v_t_24132;
  switch (heff_tag_of(v_input_24127)) {
  case TAG_Typed: {
    V v_f_24128 = heff_field(v_input_24127, 0);
    V v_ru_24input_24127_24Typed = heff_take_reuse_n(v_input_24127, 1ULL, 1);
    V v_t_24129 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24128));
    v_t_24132 = heff_tag_at_n(v_ru_24input_24127_24Typed, TAG_Typed, 1, (V[]){v_t_24129});
    break;
  }
  case TAG_Picked: {
    V v_c_24130 = heff_field(v_input_24127, 0);
    V v_ru_24input_24127_24Picked = heff_take_reuse_n(v_input_24127, 1ULL, 1);
    V v_t_24131 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24130));
    v_t_24132 = heff_tag_at_n(v_ru_24input_24127_24Picked, TAG_Picked, 1, (V[]){v_t_24131});
    break;
  }
  default: heff_nomatch(v_input_24127);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_24126, v_t_24132});
}
V g_std_2ecli_2einteractive_2eslotStep_lam7(V self, V *args) {
  V v_s_24136 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_24137 = heff_take_field(v_s_24136, 0);
  V v_input_24138 = heff_get_n(v_s_24136, 1, 2);
  V v_t_24143;
  switch (heff_tag_of(v_input_24138)) {
  case TAG_Typed: {
    V v_f_24139 = heff_field(v_input_24138, 0);
    V v_ru_24input_24138_24Typed = heff_take_reuse_n(v_input_24138, 1ULL, 1);
    V v_t_24140 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24139));
    v_t_24143 = heff_tag_at_n(v_ru_24input_24138_24Typed, TAG_Typed, 1, (V[]){v_t_24140});
    break;
  }
  case TAG_Picked: {
    V v_c_24141 = heff_field(v_input_24138, 0);
    V v_ru_24input_24138_24Picked = heff_take_reuse_n(v_input_24138, 1ULL, 1);
    V v_t_24142 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24141));
    v_t_24143 = heff_tag_at_n(v_ru_24input_24138_24Picked, TAG_Picked, 1, (V[]){v_t_24142});
    break;
  }
  default: heff_nomatch(v_input_24138);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_24137, v_t_24143});
}
V g_std_2ecli_2einteractive_2eslotStep_lam8(V self, V *args) {
  V v_s_24147 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_24148 = heff_take_field(v_s_24147, 0);
  V v_input_24149 = heff_get_n(v_s_24147, 1, 2);
  V v_t_24154;
  switch (heff_tag_of(v_input_24149)) {
  case TAG_Typed: {
    V v_f_24150 = heff_field(v_input_24149, 0);
    V v_ru_24input_24149_24Typed = heff_take_reuse_n(v_input_24149, 1ULL, 1);
    V v_t_24151 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24150));
    v_t_24154 = heff_tag_at_n(v_ru_24input_24149_24Typed, TAG_Typed, 1, (V[]){v_t_24151});
    break;
  }
  case TAG_Picked: {
    V v_c_24152 = heff_field(v_input_24149, 0);
    V v_ru_24input_24149_24Picked = heff_take_reuse_n(v_input_24149, 1ULL, 1);
    V v_t_24153 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24152));
    v_t_24154 = heff_tag_at_n(v_ru_24input_24149_24Picked, TAG_Picked, 1, (V[]){v_t_24153});
    break;
  }
  default: heff_nomatch(v_input_24149);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_24148, v_t_24154});
}
V g_std_2ecli_2einteractive_2eslotStep_lam9(V self, V *args) {
  V v_s_24158 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_24159 = heff_take_field(v_s_24158, 0);
  V v_input_24160 = heff_get_n(v_s_24158, 1, 2);
  V v_t_24165;
  switch (heff_tag_of(v_input_24160)) {
  case TAG_Typed: {
    V v_f_24161 = heff_field(v_input_24160, 0);
    V v_ru_24input_24160_24Typed = heff_take_reuse_n(v_input_24160, 1ULL, 1);
    V v_t_24162 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24161));
    v_t_24165 = heff_tag_at_n(v_ru_24input_24160_24Typed, TAG_Typed, 1, (V[]){v_t_24162});
    break;
  }
  case TAG_Picked: {
    V v_c_24163 = heff_field(v_input_24160, 0);
    V v_ru_24input_24160_24Picked = heff_take_reuse_n(v_input_24160, 1ULL, 1);
    V v_t_24164 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24163));
    v_t_24165 = heff_tag_at_n(v_ru_24input_24160_24Picked, TAG_Picked, 1, (V[]){v_t_24164});
    break;
  }
  default: heff_nomatch(v_input_24160);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_24159, v_t_24165});
}
V g_std_2ecli_2einteractive_2eslotStep_lam10(V self, V *args) {
  V v_s_24169 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_24170 = heff_take_field(v_s_24169, 0);
  V v_input_24171 = heff_get_n(v_s_24169, 1, 2);
  V v_t_24176;
  switch (heff_tag_of(v_input_24171)) {
  case TAG_Typed: {
    V v_f_24172 = heff_field(v_input_24171, 0);
    V v_ru_24input_24171_24Typed = heff_take_reuse_n(v_input_24171, 1ULL, 1);
    V v_t_24173 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24172));
    v_t_24176 = heff_tag_at_n(v_ru_24input_24171_24Typed, TAG_Typed, 1, (V[]){v_t_24173});
    break;
  }
  case TAG_Picked: {
    V v_c_24174 = heff_field(v_input_24171, 0);
    V v_ru_24input_24171_24Picked = heff_take_reuse_n(v_input_24171, 1ULL, 1);
    V v_t_24175 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24174));
    v_t_24176 = heff_tag_at_n(v_ru_24input_24171_24Picked, TAG_Picked, 1, (V[]){v_t_24175});
    break;
  }
  default: heff_nomatch(v_input_24171);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_24170, v_t_24176});
}
V g_std_2ecli_2einteractive_2eslotStep_lam11(V self, V *args) {
  V v_s_24180 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_24181 = heff_take_field(v_s_24180, 0);
  V v_input_24182 = heff_get_n(v_s_24180, 1, 2);
  V v_t_24187;
  switch (heff_tag_of(v_input_24182)) {
  case TAG_Typed: {
    V v_f_24183 = heff_field(v_input_24182, 0);
    V v_ru_24input_24182_24Typed = heff_take_reuse_n(v_input_24182, 1ULL, 1);
    V v_t_24184 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24183));
    v_t_24187 = heff_tag_at_n(v_ru_24input_24182_24Typed, TAG_Typed, 1, (V[]){v_t_24184});
    break;
  }
  case TAG_Picked: {
    V v_c_24185 = heff_field(v_input_24182, 0);
    V v_ru_24input_24182_24Picked = heff_take_reuse_n(v_input_24182, 1ULL, 1);
    V v_t_24186 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24185));
    v_t_24187 = heff_tag_at_n(v_ru_24input_24182_24Picked, TAG_Picked, 1, (V[]){v_t_24186});
    break;
  }
  default: heff_nomatch(v_input_24182);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_24181, v_t_24187});
}
V g_std_2ecli_2einteractive_2eslotStep_lam12(V self, V *args) {
  V v_s_24191 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_24192 = heff_take_field(v_s_24191, 0);
  V v_input_24193 = heff_get_n(v_s_24191, 1, 2);
  V v_t_24198;
  switch (heff_tag_of(v_input_24193)) {
  case TAG_Typed: {
    V v_f_24194 = heff_field(v_input_24193, 0);
    V v_ru_24input_24193_24Typed = heff_take_reuse_n(v_input_24193, 1ULL, 1);
    V v_t_24195 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24194));
    v_t_24198 = heff_tag_at_n(v_ru_24input_24193_24Typed, TAG_Typed, 1, (V[]){v_t_24195});
    break;
  }
  case TAG_Picked: {
    V v_c_24196 = heff_field(v_input_24193, 0);
    V v_ru_24input_24193_24Picked = heff_take_reuse_n(v_input_24193, 1ULL, 1);
    V v_t_24197 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24196));
    v_t_24198 = heff_tag_at_n(v_ru_24input_24193_24Picked, TAG_Picked, 1, (V[]){v_t_24197});
    break;
  }
  default: heff_nomatch(v_input_24193);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_24192, v_t_24198});
}
V g_std_2ecli_2einteractive_2eslotStep_lam13(V self, V *args) {
  V v_s_24202 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_24203 = heff_take_field(v_s_24202, 0);
  V v_input_24204 = heff_get_n(v_s_24202, 1, 2);
  V v_t_24209;
  switch (heff_tag_of(v_input_24204)) {
  case TAG_Typed: {
    V v_f_24205 = heff_field(v_input_24204, 0);
    V v_ru_24input_24204_24Typed = heff_take_reuse_n(v_input_24204, 1ULL, 1);
    V v_t_24206 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24205));
    v_t_24209 = heff_tag_at_n(v_ru_24input_24204_24Typed, TAG_Typed, 1, (V[]){v_t_24206});
    break;
  }
  case TAG_Picked: {
    V v_c_24207 = heff_field(v_input_24204, 0);
    V v_ru_24input_24204_24Picked = heff_take_reuse_n(v_input_24204, 1ULL, 1);
    V v_t_24208 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24207));
    v_t_24209 = heff_tag_at_n(v_ru_24input_24204_24Picked, TAG_Picked, 1, (V[]){v_t_24208});
    break;
  }
  default: heff_nomatch(v_input_24204);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_24203, v_t_24209});
}
V g_std_2ecli_2einteractive_2eslotStep_lam14(V self, V *args) {
  V v_s_24213 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_24214 = heff_take_field(v_s_24213, 0);
  V v_input_24215 = heff_get_n(v_s_24213, 1, 2);
  V v_t_24220;
  switch (heff_tag_of(v_input_24215)) {
  case TAG_Typed: {
    V v_f_24216 = heff_field(v_input_24215, 0);
    V v_ru_24input_24215_24Typed = heff_take_reuse_n(v_input_24215, 1ULL, 1);
    V v_t_24217 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, v_f_24216));
    v_t_24220 = heff_tag_at_n(v_ru_24input_24215_24Typed, TAG_Typed, 1, (V[]){v_t_24217});
    break;
  }
  case TAG_Picked: {
    V v_c_24218 = heff_field(v_input_24215, 0);
    V v_ru_24input_24215_24Picked = heff_take_reuse_n(v_input_24215, 1ULL, 1);
    V v_t_24219 = (g_std_2eterminal_2ewidget_2echoiceKey(v_k_240, v_c_24218));
    v_t_24220 = heff_tag_at_n(v_ru_24input_24215_24Picked, TAG_Picked, 1, (V[]){v_t_24219});
    break;
  }
  default: heff_nomatch(v_input_24215);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_24214, v_t_24220});
}
V g_std_2ecli_2einteractive_2eslotStep_lam15(V self, V *args) {
  V v_s_24241 = args[0];
  V v_c_24224 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_24242 = heff_take_field(v_s_24241, 0);
  V v_input_24243 = heff_get_n(v_s_24241, 1, 2);
  V v_t_24248;
  switch (heff_tag_of(v_input_24243)) {
  case TAG_Typed: {
    V v_f_24244 = heff_field(v_input_24243, 0);
    V v_ru_24input_24243_24Typed = heff_take_reuse_n(v_input_24243, 1ULL, 1);
    V v_t_24245 = ({ V b_0 = heff_tag_n(TAG_Control, 1, (V[]){v_c_24224}); V a_1 = v_f_24244; V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    v_t_24248 = heff_tag_at_n(v_ru_24input_24243_24Typed, TAG_Typed, 1, (V[]){v_t_24245});
    break;
  }
  case TAG_Picked: {
    V v_c_24246 = heff_field(v_input_24243, 0);
    V v_ru_24input_24243_24Picked = heff_take_reuse_n(v_input_24243, 1ULL, 1);
    V v_t_24247 = ({ V b_0 = heff_tag_n(TAG_Control, 1, (V[]){v_c_24224}); V a_1 = v_c_24246; V r_ = (g_std_2eterminal_2ewidget_2echoiceKey(b_0, a_1)); heff_drop(b_0); r_; });
    v_t_24248 = heff_tag_at_n(v_ru_24input_24243_24Picked, TAG_Picked, 1, (V[]){v_t_24247});
    break;
  }
  default: heff_nomatch(v_input_24243);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_24242, v_t_24248});
}
V g_std_2ecli_2einteractive_2eslotStep_lam16(V self, V *args) {
  V v_s_24253 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_part_24254 = heff_take_field(v_s_24253, 0);
  V v_input_24255 = heff_get_n(v_s_24253, 1, 2);
  V v_t_24260;
  switch (heff_tag_of(v_input_24255)) {
  case TAG_Typed: {
    V v_f_24256 = heff_field(v_input_24255, 0);
    V v_ru_24input_24255_24Typed = heff_take_reuse_n(v_input_24255, 1ULL, 1);
    V v_t_24257 = ({ V a_0 = v_k_240; V a_1 = v_f_24256; V r_ = (g_std_2eterminal_2ewidget_2efieldKey(a_0, a_1)); heff_drop_tag(v_k_240, 1); r_; });
    v_t_24260 = heff_tag_at_n(v_ru_24input_24255_24Typed, TAG_Typed, 1, (V[]){v_t_24257});
    break;
  }
  case TAG_Picked: {
    V v_c_24258 = heff_field(v_input_24255, 0);
    V v_ru_24input_24255_24Picked = heff_take_reuse_n(v_input_24255, 1ULL, 1);
    V v_t_24259 = ({ V a_0 = v_k_240; V a_1 = v_c_24258; V r_ = (g_std_2eterminal_2ewidget_2echoiceKey(a_0, a_1)); heff_drop_tag(v_k_240, 1); r_; });
    v_t_24260 = heff_tag_at_n(v_ru_24input_24255_24Picked, TAG_Picked, 1, (V[]){v_t_24259});
    break;
  }
  default: heff_nomatch(v_input_24255);
  }
  return heff_rec_n(2, shape_part__input, (V[]){v_part_24254, v_t_24260});
}
Clo g_std_2ecli_2einteractive_2eformStep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformStep_entry, 3, 0};

V g_std_2ecli_2einteractive_2eformStep(V v_k_240, V v_m_241, V v_fm_242) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Enter: {
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 2, 3);
    V v_t_245 = (g_std_2ecli_2einteractive_2eformWords(heff_dup(v_fm_242)));
    HeffT2 v_t_246 = (g_std_2ecli_2eproblemOf_24cpr(v_t_244, v_t_245));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop_rec(v_fm_242, 3);
        V v_p_249 = v_field_248;
        heff_drop(v_p_249);
        return heff_tag_n(TAG_Continue, 1, (V[]){v_m_241});
      } else {
        heff_drop_rec(v_m_241, 6);
        heff_drop(v_field_248);
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 0, 3);
        V v_t_2411 = (g_std_2ecli_2einteractive_2eformWords(v_fm_242));
        V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2411})});
        return heff_tag_n(TAG_Done, 1, (V[]){v_t_2412});
      }
    }
  }
  case TAG_Escape: {
    heff_drop_rec(v_fm_242, 3);
    V v_t_2413 = ({ V rv_5 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2413});
  }
  case TAG_Tab: {
    V v_t_2414 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2420;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      v_t_2420 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2414, 0ULL, 2);
      V v_t_2417 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
      V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      v_t_2420 = heff_intMod(heff_intAdd(v_t_2417, v_t_2418), v_t_2419);
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_fm_2421 = ({ V rv_2 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2422 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2421}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2422});
  }
  case TAG_BackTab: {
    V v_t_2423 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2429;
    switch (heff_tag_of(v_t_2423)) {
    case TAG_Nil: {
      v_t_2429 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2423, 0ULL, 2);
      V v_t_2426 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
      V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      v_t_2429 = heff_intMod(heff_intAdd(v_t_2426, v_t_2427), v_t_2428);
      break;
    }
    default: heff_nomatch(v_t_2423);
    }
    V v_fm_2430 = ({ V rv_2 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2431 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2430}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2431});
  }
  case TAG_Backspace: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Delete: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_ArrowUp: {
    V v_t_2432 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2438;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nil: {
      v_t_2438 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2432, 0ULL, 2);
      V v_t_2435 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
      V v_t_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2437 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      v_t_2438 = heff_intMod(heff_intAdd(v_t_2435, v_t_2436), v_t_2437);
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    V v_fm_2439 = ({ V rv_2 = v_t_2438; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2440 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2439}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2440});
  }
  case TAG_ArrowDown: {
    V v_t_2441 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2447;
    switch (heff_tag_of(v_t_2441)) {
    case TAG_Nil: {
      v_t_2447 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2441, 0ULL, 2);
      V v_t_2444 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
      V v_t_2445 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      v_t_2447 = heff_intMod(heff_intAdd(v_t_2444, v_t_2445), v_t_2446);
      break;
    }
    default: heff_nomatch(v_t_2441);
    }
    V v_fm_2448 = ({ V rv_2 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2449 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2448}); V rr_ = heff_rec_reuse_nf(v_m_241, 31ULL, 6, shape_prog__entries__filter__typing__menu__form, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2449});
  }
  case TAG_ArrowLeft: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_ArrowRight: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Home: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_End: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_PageUp: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_PageDown: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Control: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Sequence: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2ecli_2einteractive_2eformStep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformStep(a[0], a[1], a[2]);
}
Clo g_std_2ecli_2einteractive_2estep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2estep_entry, 2, 0};

V g_std_2ecli_2einteractive_2estep(V v_k_240, V v_m_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_m_241, 5));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    return ({ V a_0 = v_k_240; V a_1 = v_m_241; V r_ = (g_std_2ecli_2einteractive_2elistStep(a_0, a_1)); heff_drop(v_k_240); r_; });
  }
  case TAG_Just: {
    V v_fm_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    return (g_std_2ecli_2einteractive_2eformStep(v_k_240, v_m_241, v_fm_243));
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2ecli_2einteractive_2estep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2estep(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str0, 23, "no command's name has `");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str1, 7, "` in it");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str2, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str3, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str5, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str6, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str7, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str8, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ecalledAs_str9, 1, " ");
Clo g_std_2ecli_2einteractive_2ecalledAs_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2ecalledAs_entry, 2, 0};

V g_std_2ecli_2einteractive_2ecalledAs(V v_m_240, V v_x2_241) {
top: ;
  V v_filter_242 = heff_take_field(v_m_240, 2);
  V v_prog_243 = heff_get_n(v_m_240, 0, 6);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_prog_243);
    V v_t_244 = heff_strOfRunes(heff_get_n(v_filter_242, 0, 2));
    return heff_strAppend(((V)&g_std_2ecli_2einteractive_2ecalledAs_str0), heff_strAppend(v_t_244, ((V)&g_std_2ecli_2einteractive_2ecalledAs_str1)));
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_filter_242, 2);
    V v_name_246 = heff_dup(heff_rfield(v_e_245, 0));
    V v_shape_247 = heff_dup(heff_rfield(v_e_245, 2));
    V v_t_248 = heff_dup(heff_rfield(v_shape_247, 1));
    V v_t_2432;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nil: {
      V v_t_249 = heff_dup(heff_rfield(v_shape_247, 0));
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nil: {
        heff_drop_rec(v_shape_247, 2);
        v_t_2432 = ((V)&g_std_2ecli_2einteractive_2ecalledAs_str2);
        break;
      }
      case TAG_Cons: {
        V v_ru_24t_249_24Cons = heff_take_reuse_n(v_t_249, 0ULL, 2);
        V v_sh_2412 = v_shape_247;
        V v_pos_2413 = heff_take_field(v_sh_2412, 1);
        V v_flags_2414 = heff_get_n(v_sh_2412, 0, 2);
        V v_t_2415 = (g_list_2emap_24s2029999044x514618413(v_pos_2413));
        V v_t_2416 = (g_list_2emap_24s1281445768x1036802655(v_flags_2414));
        V v_xs_2417 = (g_prelude_2e_2b_2b_24tok2(v_ru_24t_249_24Cons, v_t_2415, v_t_2416));
        V v_t_2420;
        switch (heff_tag_of(v_xs_2417)) {
        case TAG_Nil: {
          v_t_2420 = ((V)&g_std_2ecli_2einteractive_2ecalledAs_str3);
          break;
        }
        case TAG_Cons: {
          V v_x_2418 = heff_field(v_xs_2417, 0);
          V v_xs_2419 = heff_field(v_xs_2417, 1);
          heff_take_n(v_xs_2417, 3ULL, 2);
          v_t_2420 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2ecalledAs_str4); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
          break;
        }
        default: heff_nomatch(v_xs_2417);
        }
        v_t_2432 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2ecalledAs_str5), v_t_2420);
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    case TAG_Cons: {
      V v_ru_24t_248_24Cons = heff_take_reuse_n(v_t_248, 0ULL, 2);
      V v_sh_2423 = v_shape_247;
      V v_pos_2424 = heff_take_field(v_sh_2423, 1);
      V v_flags_2425 = heff_get_n(v_sh_2423, 0, 2);
      V v_t_2426 = (g_list_2emap_24s2029999044x514618413(v_pos_2424));
      V v_t_2427 = (g_list_2emap_24s1281445768x1036802655(v_flags_2425));
      V v_xs_2428 = (g_prelude_2e_2b_2b_24tok2(v_ru_24t_248_24Cons, v_t_2426, v_t_2427));
      V v_t_2431;
      switch (heff_tag_of(v_xs_2428)) {
      case TAG_Nil: {
        v_t_2431 = ((V)&g_std_2ecli_2einteractive_2ecalledAs_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_2429 = heff_field(v_xs_2428, 0);
        V v_xs_2430 = heff_field(v_xs_2428, 1);
        heff_take_n(v_xs_2428, 3ULL, 2);
        v_t_2431 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2ecalledAs_str7); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
        break;
      }
      default: heff_nomatch(v_xs_2428);
      }
      v_t_2432 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2ecalledAs_str8), v_t_2431);
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2433 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2ecalledAs_str9), heff_strAppend(v_name_246, v_t_2432));
    return heff_strAppend(v_prog_243, v_t_2433);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2einteractive_2ecalledAs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2einteractive_2ecalledAs(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str0, 14, ": its commands");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str1, 8, "filter: ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str2, 71, "type to filter, \342\206\221 \342\206\223 or j k to move, Enter to fill one in, q to quit");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str3, 2, "  ");
V g_std_2ecli_2einteractive_2elistView_lam0(V self, V *args);
Clo g_std_2ecli_2einteractive_2elistView_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2elistView_entry, 2, 0};

V g_std_2ecli_2einteractive_2elistView(V v_size_240, V v_m_241) {
top: ;
  V v_rows_242 = heff_take_field(v_size_240, 1);
  V v_columns_243 = heff_get_n(v_size_240, 0, 2);
  V v_h_244 = heff_intSub(heff_dup(v_rows_242), MK_INT(1LL));
  V v_t_245 = heff_rec_n(2, shape_text__style, (V[]){heff_dup(heff_rfield(v_m_241, 0)), NTAG(TAG_Bold)});
  V v_t_246 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str0), NTAG(TAG_Plain)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = heff_dup(heff_rfield(v_m_241, 3));
  V v_t_2414;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    V v_t_249 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str1), NTAG(TAG_Plain)});
    V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_m_241, 2)), 0, 2);
    V v_t_2411 = heff_rec_n(2, shape_text__style, (V[]){heff_strOfRunes(v_t_2410), NTAG(TAG_Plain)});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2412});
  } else {
    heff_drop(v_t_248);
    V v_t_2413 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str2), NTAG(TAG_Dim)});
    v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  }
  V v_h_2415 = heff_intSub(v_rows_242, MK_INT(4LL));
  V v_m_2416 = heff_dup(heff_rfield(v_m_241, 4));
  V v_t_2417 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s1252894891x837498180(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
  V v_w_2418 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2417; V r_ = (g_list_2efoldl_24s6718001x1068992521(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s1252894891x837498180(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
  V v_items_2428 = (g_list_2emap(heff_clo_n(g_std_2ecli_2einteractive_2elistView_lam0, 1, 1, (V[]){v_w_2418}), v_t_2419));
  V v_t_2430;
  if (heff_intLt_c(heff_dup(heff_rfield(v_m_2416, 0)), heff_dup(v_h_2415))) {
    v_t_2430 = MK_INT(0LL);
  } else {
    V v_t_2429 = heff_intSub(heff_dup(heff_rfield(v_m_2416, 0)), heff_dup(v_h_2415));
    v_t_2430 = heff_intAdd(v_t_2429, MK_INT(1LL));
  }
  V v_t_2431 = (g_std_2eterminal_2ewidget_2emenuFrom(heff_get_n(v_m_2416, 0, 1), MK_INT(0LL), v_items_2428));
  V v_t_2432 = ({ V a_0 = v_t_2430; V a_1 = v_t_2431; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2431); r_; });
  V v_t_2433 = (g_list_2etake(v_h_2415, v_t_2432));
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2433});
  V v_rs_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2434})});
  V v_t_2436 = (g_list_2ereplicate(heff_dup(v_h_244), NTAG(TAG_Nil)));
  V v_t_2437 = (g_prelude_2e_2b_2b(v_rs_2435, v_t_2436));
  V v_t_2438 = (g_list_2etake(v_h_244, v_t_2437));
  V v_t_2439 = heff_get_n(heff_dup(heff_rfield(v_m_241, 4)), 0, 1);
  V v_t_2440 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_m_241); V b_2 = MK_INT(0LL); V a_3 = heff_dup(heff_rfield(v_m_241, 1)); V r_ = (g_list_2ekeepIf_24s1252894891x837498180(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
  HeffT3 v_t_2441 = ({ V a_0 = v_t_2439; V a_1 = v_t_2440; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2440); r_; });
  V v_t_2447;
  {
    V v_field_2443 = v_t_2441.f[1];
    V v_field_2444 = v_t_2441.f[2];
    int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
    if ((v_tag_2442 == ((int64_t)0ULL))) {
      V v_x_2445 = v_field_2443;
      V v_x12_2446 = v_field_2444;
      heff_drop(v_x12_2446);
      v_t_2447 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2445});
    } else {
      heff_drop(v_field_2443);
      heff_drop(v_field_2444);
      v_t_2447 = NTAG(TAG_Nothing);
    }
  }
  V v_s_2448 = ({ V a_0 = heff_dup(v_m_241); V a_1 = v_t_2447; V r_ = (g_std_2ecli_2einteractive_2ecalledAs(a_0, a_1)); heff_drop(v_t_2447); r_; });
  V v_s_2449 = (g_std_2eterminal_2ewidget_2epad(v_columns_243, v_s_2448));
  V v_t_2450 = heff_rec_n(2, shape_text__style, (V[]){v_s_2449, NTAG(TAG_Inverse)});
  V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, NTAG(TAG_Nil)});
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
  V v_t_2453 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2452));
  V v_t_2454 = heff_take_field(v_m_241, 3);
  V v_t_2460;
  if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
    heff_drop(v_t_2454);
    V v_f_2455 = heff_get_n(v_m_241, 2, 6);
    V v_at_2456 = heff_take_field(v_f_2455, 1);
    V v_text_2457 = heff_get_n(v_f_2455, 0, 2);
    V v_t_2458 = ({ V a_0 = MK_INT(0LL); V a_1 = v_at_2456; V a_2 = v_text_2457; V r_ = (g_list_2efoldl_24f547094838x440994078(a_0, a_1, a_2)); heff_drop(v_text_2457); r_; });
    V v_t_2459 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_intAdd(MK_INT(8LL), v_t_2458), MK_INT(1LL)});
    v_t_2460 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2459});
  } else {
    heff_drop_rec(v_m_241, 6);
    heff_drop(v_t_2454);
    v_t_2460 = NTAG(TAG_Nothing);
  }
  return heff_rec_n(2, shape_rows__cursor, (V[]){v_t_2453, v_t_2460});
}
V g_std_2ecli_2einteractive_2elistView_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2elistView(a[0], a[1]);
}
V g_std_2ecli_2einteractive_2elistView_lam0(V self, V *args) {
  V v_e_2420 = args[0];
  V v_w_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_name_2421 = heff_take_field(v_e_2420, 0);
  V v_doc_2422 = heff_get_n(v_e_2420, 1, 3);
  V v_s_2423 = (g_std_2eterminal_2ewidget_2epad(v_w_2418, v_name_2421));
  V v_t_2424 = heff_rec_n(2, shape_text__style, (V[]){v_s_2423, NTAG(TAG_Bold)});
  V v_t_2425 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str3), NTAG(TAG_Plain)});
  V v_t_2426 = heff_rec_n(2, shape_text__style, (V[]){v_doc_2422, NTAG(TAG_Dim)});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_t_2427})});
}
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str0, 1, "[");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str1, 1, "]");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str2, 1, "[");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str3, 4, "...]");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str4, 3, "...");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str5, 1, "[");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str6, 4, "...]");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str7, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str8, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str9, 1, "-");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str10, 2, ", ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str11, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str12, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str13, 1, "=");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str14, 2, "--");
Clo g_std_2ecli_2einteractive_2epartLabel_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2epartLabel_entry, 1, 0};

V g_std_2ecli_2einteractive_2epartLabel(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Positional: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_meta_242 = heff_dup(heff_rfield(v_p_241, 0));
    V v_arity_243 = heff_dup(heff_rfield(v_p_241, 1));
    V v_m_244 = v_meta_242;
    switch (heff_tag_of(v_arity_243)) {
    case TAG_One: {
      return v_m_244;
    }
    case TAG_Optional: {
      return heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str0), heff_strAppend(v_m_244, ((V)&g_std_2ecli_2einteractive_2epartLabel_str1)));
    }
    case TAG_Many: {
      return heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str2), heff_strAppend(v_m_244, ((V)&g_std_2ecli_2einteractive_2epartLabel_str3)));
    }
    case TAG_Some: {
      return heff_strAppend(v_m_244, ((V)&g_std_2ecli_2einteractive_2epartLabel_str4));
    }
    case TAG_Rest: {
      return heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str5), heff_strAppend(v_m_244, ((V)&g_std_2ecli_2einteractive_2epartLabel_str6)));
    }
    default: return heff_nomatch(v_arity_243);
    }
  }
  case TAG_Flagged: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_short_246 = heff_dup(heff_rfield(v_f_245, 1));
    V v_long_247 = heff_dup(heff_rfield(v_f_245, 0));
    V v_meta_248 = heff_dup(heff_rfield(v_f_245, 2));
    V v_t_249;
    if (heff_strEq_c_lent(v_short_246, ((V)&g_std_2ecli_2einteractive_2epartLabel_str7), 2)) {
      heff_drop(v_short_246);
      v_t_249 = ((V)&g_std_2ecli_2einteractive_2epartLabel_str8);
    } else {
      v_t_249 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str9), heff_strAppend(v_short_246, ((V)&g_std_2ecli_2einteractive_2epartLabel_str10)));
    }
    V v_t_2410;
    if (heff_strEq_c_lent(v_meta_248, ((V)&g_std_2ecli_2einteractive_2epartLabel_str11), 2)) {
      heff_drop(v_meta_248);
      v_t_2410 = ((V)&g_std_2ecli_2einteractive_2epartLabel_str12);
    } else {
      v_t_2410 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str13), v_meta_248);
    }
    V v_t_2411 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str14), heff_strAppend(v_long_247, v_t_2410));
    return heff_strAppend(v_t_249, v_t_2411);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2epartLabel_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2epartLabel(a0); heff_drop(a0); return r;
}
Clo g_std_2ecli_2einteractive_2einputRow_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2einputRow_entry, 3, 0};

V g_std_2ecli_2einteractive_2einputRow(V v_on_240, V v_part_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Typed: {
    V v_t_243 = heff_field(v_x3_242, 0);
    if (!(heff_dup(v_on_240) == NTAG(TAG_True))) {
      V v_t_244 = heff_dup(heff_rfield(v_t_243, 0));
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nil: {
        V v_t_247;
        switch (heff_tag_of(v_part_241)) {
        case TAG_Positional: {
          V v_p_245 = heff_field(v_part_241, 0);
          v_t_247 = heff_dup(heff_rfield(v_p_245, 0));
          break;
        }
        case TAG_Flagged: {
          V v_f_246 = heff_field(v_part_241, 0);
          v_t_247 = heff_dup(heff_rfield(v_f_246, 2));
          break;
        }
        default: heff_nomatch(v_part_241);
        }
        V v_t_248 = heff_rec_n(2, shape_text__style, (V[]){v_t_247, NTAG(TAG_Dim)});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
      }
      case TAG_Cons: {
        V v_ru_24t_244_24Cons = heff_take_reuse_n(v_t_244, 0ULL, 2);
        V v_t_2411 = heff_strOfRunes(heff_dup(heff_rfield(v_t_243, 0)));
        V v_t_2412 = heff_rec_n(2, shape_text__style, (V[]){v_t_2411, NTAG(TAG_Plain)});
        return heff_tag_at_n(v_ru_24t_244_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_t_244);
      }
    } else {
      V v_t_2413 = heff_strOfRunes(heff_dup(heff_rfield(v_t_243, 0)));
      V v_t_2414 = heff_rec_n(2, shape_text__style, (V[]){v_t_2413, NTAG(TAG_Plain)});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
    }
  }
  case TAG_Picked: {
    V v_c_2415 = heff_field(v_x3_242, 0);
    V v_at_2416 = heff_dup(heff_rfield(v_c_2415, 1));
    V v_options_2417 = heff_dup(heff_rfield(v_c_2415, 0));
    V v_t_2418;
    if ((heff_dup(v_on_240) == NTAG(TAG_True))) {
      v_t_2418 = ((V)&g_std_2eterminal_2ewidget_2einverse_clo);
    } else {
      v_t_2418 = ((V)&g_std_2eterminal_2ewidget_2ebold_clo);
    }
    return (g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747(v_t_2418, v_at_2416, MK_INT(0LL), v_options_2417));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2einteractive_2einputRow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_std_2ecli_2einteractive_2einputRow(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRow_str0, 2, "> ");
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRow_str1, 2, "  ");
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRow_str2, 2, "  ");
Clo g_std_2ecli_2einteractive_2eslotRow_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotRow_entry, 3, 0};

V g_std_2ecli_2einteractive_2eslotRow(V v_w_240, V v_on_241, V v_s_242) {
top: ;
  V v_part_243 = heff_take_field(v_s_242, 0);
  V v_input_244 = heff_get_n(v_s_242, 1, 2);
  V v_t_245;
  if ((heff_dup(v_on_241) == NTAG(TAG_True))) {
    v_t_245 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRow_str0), NTAG(TAG_Bold)});
  } else {
    v_t_245 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRow_str1), NTAG(TAG_Plain)});
  }
  V v_t_246 = (g_std_2ecli_2einteractive_2epartLabel(v_part_243));
  V v_s_247 = (g_std_2eterminal_2ewidget_2epad(v_w_240, v_t_246));
  V v_t_248 = heff_rec_n(2, shape_text__style, (V[]){v_s_247, NTAG(TAG_Plain)});
  V v_t_249 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRow_str2), NTAG(TAG_Plain)});
  V v_t_2410 = ({ V a_0 = v_on_241; V a_1 = v_part_243; V a_2 = v_input_244; V r_ = (g_std_2ecli_2einteractive_2einputRow(a_0, a_1, a_2)); heff_drop(v_part_243); heff_drop(v_input_244); r_; });
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2410})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2411});
}
V g_std_2ecli_2einteractive_2eslotRow_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2einteractive_2eslotRow(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_std_2ecli_2einteractive_2eslotRows_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotRows_entry, 4, 0};

V g_std_2ecli_2einteractive_2eslotRows(V v_w_240, V v_at_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    heff_drop(v_at_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x4_243, 0);
    V v_ss_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_bool(heff_intEq_c_lent(v_i_242, v_at_241, 0));
    V v_t_247 = ({ V a_0 = heff_dup(v_w_240); V a_1 = v_t_246; V a_2 = v_s_244; V r_ = (g_std_2ecli_2einteractive_2eslotRow(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
    V v_cell_248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_std_2ecli_2einteractive_2eslotRows_24dps(v_w_240, v_at_241, heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL))), v_ss_245, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2ecli_2einteractive_2eslotRows_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eslotRows(a[0], a[1], a[2], a[3]);
}
Clo g_std_2ecli_2einteractive_2eslotRows_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotRows_24dps_entry, 5, 0};

V g_std_2ecli_2einteractive_2eslotRows_24dps(V v_w_240, V v_at_241, V v_i_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    heff_drop(v_at_241);
    heff_drop(v_i_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_245 = heff_field(v_x4_243, 0);
    V v_ss_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = heff_bool(heff_intEq_c_lent(v_i_242, v_at_241, 0));
    V v_t_248 = ({ V a_0 = heff_dup(v_w_240); V a_1 = v_t_247; V a_2 = v_s_245; V r_ = (g_std_2ecli_2einteractive_2eslotRow(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
    V v_cell_249 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_w_240;
    V t_1 = v_at_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_ss_246;
    V t_4 = v_cell_249;
    v_w_240 = t_0;
    v_at_241 = t_1;
    v_i_242 = t_2;
    v_x4_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2ecli_2einteractive_2eslotRows_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eslotRows_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str0, 16, "one word, wanted");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str1, 40, "one word, or none: the command's default");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str2, 36, "any number of words, split at spaces");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str3, 33, "one word or more, split at spaces");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str4, 51, "the rest of the words, as they are, split at spaces");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str5, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str6, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str7, 8, "; a file");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str8, 4, "; a ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str9, 5, " file");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str10, 13, "; a directory");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str11, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str12, 2, ", ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str13, 9, "; one of ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str14, 2, ": ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str15, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str16, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str17, 2, "; ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str18, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str19, 38, "a switch, off or on (\342\206\220 \342\206\222 or space)");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str20, 37, "a value, typed; left empty, not given");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str21, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str22, 2, ", ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str23, 7, "one of ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str24, 19, " (\342\206\220 \342\206\222 or space)");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str25, 8, "; wanted");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str26, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str27, 2, ": ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str28, 2, "--");
Clo g_std_2ecli_2einteractive_2epartSaid_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2epartSaid_entry, 1, 0};

V g_std_2ecli_2einteractive_2epartSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Positional: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_meta_242 = heff_dup(heff_rfield(v_p_241, 0));
    V v_arity_243 = heff_dup(heff_rfield(v_p_241, 1));
    V v_complete_244 = heff_dup(heff_rfield(v_p_241, 2));
    V v_t_245;
    switch (heff_tag_of(v_arity_243)) {
    case TAG_One: {
      v_t_245 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str0);
      break;
    }
    case TAG_Optional: {
      v_t_245 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str1);
      break;
    }
    case TAG_Many: {
      v_t_245 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str2);
      break;
    }
    case TAG_Some: {
      v_t_245 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str3);
      break;
    }
    case TAG_Rest: {
      v_t_245 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str4);
      break;
    }
    default: heff_nomatch(v_arity_243);
    }
    V v_t_2411;
    switch (heff_tag_of(v_complete_244)) {
    case TAG_None: {
      v_t_2411 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str5);
      break;
    }
    case TAG_Files: {
      V v_sfx_246 = heff_field(v_complete_244, 0);
      heff_take_n(v_complete_244, 1ULL, 1);
      if (heff_strEq_c_lent(v_sfx_246, ((V)&g_std_2ecli_2einteractive_2epartSaid_str6), 2)) {
        heff_drop(v_sfx_246);
        v_t_2411 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str7);
      } else {
        v_t_2411 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str8), heff_strAppend(v_sfx_246, ((V)&g_std_2ecli_2einteractive_2epartSaid_str9)));
      }
      break;
    }
    case TAG_Dirs: {
      v_t_2411 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str10);
      break;
    }
    case TAG_Among: {
      V v_ws_247 = heff_field(v_complete_244, 0);
      heff_take_n(v_complete_244, 1ULL, 1);
      V v_t_2410;
      switch (heff_tag_of(v_ws_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_ws_247, 0);
        V v_xs_249 = heff_field(v_ws_247, 1);
        heff_take_n(v_ws_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str12); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_ws_247);
      }
      v_t_2411 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str13), v_t_2410);
      break;
    }
    default: heff_nomatch(v_complete_244);
    }
    V v_t_2412 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str14), heff_strAppend(v_t_245, v_t_2411));
    return heff_strAppend(v_meta_242, v_t_2412);
  }
  case TAG_Flagged: {
    V v_f_2413 = heff_field(v_x1_240, 0);
    V v_long_2414 = heff_dup(heff_rfield(v_f_2413, 0));
    V v_doc_2415 = heff_dup(heff_rfield(v_f_2413, 3));
    V v_meta_2416 = heff_dup(heff_rfield(v_f_2413, 2));
    V v_values_2417 = heff_dup(heff_rfield(v_f_2413, 4));
    V v_required_2418 = heff_dup(heff_rfield(v_f_2413, 6));
    V v_t_2419;
    if (heff_strEq_c_lent(v_doc_2415, ((V)&g_std_2ecli_2einteractive_2epartSaid_str15), 2)) {
      heff_drop(v_doc_2415);
      v_t_2419 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str16);
    } else {
      v_t_2419 = heff_strAppend(v_doc_2415, ((V)&g_std_2ecli_2einteractive_2epartSaid_str17));
    }
    V v_t_2425;
    if (heff_strEq_c(v_meta_2416, ((V)&g_std_2ecli_2einteractive_2epartSaid_str18))) {
      heff_drop(v_values_2417);
      v_t_2425 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str19);
    } else {
      switch (heff_tag_of(v_values_2417)) {
      case TAG_Nil: {
        v_t_2425 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str20);
        break;
      }
      case TAG_Cons: {
        V v_t_2424;
        switch (heff_tag_of(v_values_2417)) {
        case TAG_Nil: {
          v_t_2424 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str21);
          break;
        }
        case TAG_Cons: {
          V v_x_2422 = heff_field(v_values_2417, 0);
          V v_xs_2423 = heff_field(v_values_2417, 1);
          heff_take_n(v_values_2417, 3ULL, 2);
          v_t_2424 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str22); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
          break;
        }
        default: heff_nomatch(v_values_2417);
        }
        v_t_2425 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str23), heff_strAppend(v_t_2424, ((V)&g_std_2ecli_2einteractive_2epartSaid_str24)));
        break;
      }
      default: heff_nomatch(v_values_2417);
      }
    }
    V v_t_2426;
    if ((heff_dup(v_required_2418) == NTAG(TAG_True))) {
      heff_drop(v_required_2418);
      v_t_2426 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str25);
    } else {
      heff_drop(v_required_2418);
      v_t_2426 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str26);
    }
    V v_t_2427 = heff_strAppend(v_t_2419, heff_strAppend(v_t_2425, v_t_2426));
    V v_t_2428 = heff_strAppend(v_long_2414, heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str27), v_t_2427));
    return heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str28), v_t_2428);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2epartSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2epartSaid(a0); heff_drop(a0); return r;
}
Clo g_std_2ecli_2einteractive_2eformCursor_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformCursor_entry, 4, 0};

V g_std_2ecli_2einteractive_2eformCursor(V v_top_240, V v_w_241, V v_fm_242, V v_s_243) {
top: ;
  switch (heff_tag_of(v_s_243)) {
  case TAG_Nothing: {
    heff_drop(v_top_240);
    heff_drop(v_w_241);
    heff_drop_rec(v_fm_242, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_s1_244 = heff_field(v_s_243, 0);
    V v_ru_24s_243_24Just = heff_take_reuse_n(v_s_243, 1ULL, 1);
    V v_t_245 = heff_get_n(v_s1_244, 1, 2);
    switch (heff_tag_of(v_t_245)) {
    case TAG_Typed: {
      V v_t_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V v_at_247 = heff_take_field(v_t_246, 1);
      V v_text_248 = heff_get_n(v_t_246, 0, 2);
      V v_t_249 = heff_intAdd(heff_intAdd(MK_INT(2LL), v_w_241), MK_INT(2LL));
      V v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = v_at_247; V a_2 = v_text_248; V r_ = (g_list_2efoldl_24f547094838x440994078(a_0, a_1, a_2)); heff_drop(v_text_248); r_; });
      V v_t_2411 = heff_intAdd(v_top_240, heff_get_n(v_fm_242, 2, 3));
      V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_intAdd(v_t_249, v_t_2410), v_t_2411});
      return heff_tag_at_n(v_ru_24s_243_24Just, TAG_Just, 1, (V[]){v_t_2412});
    }
    case TAG_Picked: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_top_240);
      heff_drop(v_w_241);
      heff_drop_rec(v_fm_242, 3);
      heff_drop_cell(v_ru_24s_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_s_243);
  }
}
V g_std_2ecli_2einteractive_2eformCursor_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformCursor(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str1, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str2, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str3, 2, "$ ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str5, 9, "not yet: ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str6, 13, "  (Esc: back)");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str7, 60, "Enter: run it  \302\267  Tab \342\206\221 \342\206\223: another field  \302\267  Esc: back");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str8, 0, "");
Clo g_std_2ecli_2einteractive_2eformView_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformView_entry, 3, 0};

V g_std_2ecli_2einteractive_2eformView(V v_size_240, V v_m_241, V v_fm_242) {
top: ;
  V v_rows_243 = heff_take_field(v_size_240, 1);
  V v_columns_244 = heff_get_n(v_size_240, 0, 2);
  V v_h_245 = heff_intSub(v_rows_243, MK_INT(1LL));
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 0, 3);
  V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_m_241, 0)), heff_strAppend(((V)&g_std_2ecli_2einteractive_2eformView_str0), v_t_246));
  V v_t_248 = heff_rec_n(2, shape_text__style, (V[]){v_t_247, NTAG(TAG_Bold)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 1, 3);
  V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewordsFrom(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = (g_list_2emap_24f1016251237x587084191(heff_dup(v_columns_244), ((V)&g_std_2ecli_2einteractive_2eformView_str1), v_t_2411));
  V v_t_2413 = (g_list_2efoldl_24s1396019640x159929943(MK_INT(0LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
  V v_t_2414 = (g_std_2ecli_2einteractive_2eslotRows(v_t_2413, heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(0LL), heff_dup(heff_rfield(v_fm_242, 1))));
  HeffT3 v_t_2415 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
  V v_t_2424;
  {
    V v_field_2417 = v_t_2415.f[1];
    V v_field_2418 = v_t_2415.f[2];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2417;
      V v_x12_2420 = v_field_2418;
      heff_drop(v_x12_2420);
      V v_s_2421 = ({ V b_0 = heff_get_n(v_x_2419, 0, 2); V r_ = (g_std_2ecli_2einteractive_2epartSaid(b_0)); heff_drop(b_0); r_; });
      V v_t_2422 = ({ V a_0 = v_s_2421; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewordsFrom(a_0, a_1, a_2, a_3)); heff_drop(v_s_2421); r_; });
      V v_t_2423 = (g_std_2eterminal_2ewidget_2ewrapGo(heff_dup(v_columns_244), ((V)&g_std_2ecli_2einteractive_2eformView_str2), v_t_2422));
      v_t_2424 = (g_list_2emap_24s865484684x739952503(v_t_2423));
    } else {
      heff_drop(v_field_2417);
      heff_drop(v_field_2418);
      v_t_2424 = NTAG(TAG_Nil);
    }
  }
  V v_t_2425 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eformView_str3), NTAG(TAG_Plain)});
  V v_ws_2426 = (g_std_2ecli_2einteractive_2eformWords(heff_dup(v_fm_242)));
  V v_t_2427 = (g_list_2emap_24s1171333510x402969237(v_ws_2426));
  V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 0, 3);
  V v_s_2429 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2eformView_str4); V a_1 = heff_get_n(v_m_241, 0, 6); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2427}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2430 = heff_rec_n(2, shape_text__style, (V[]){v_s_2429, NTAG(TAG_Bold)});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_t_2431}), NTAG(TAG_Nil)});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2432});
  V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2433));
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2434});
  V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2435));
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2436});
  V v_rs_2438 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2412}), v_t_2437));
  V v_t_2439 = (g_list_2ereplicate(heff_dup(v_h_245), NTAG(TAG_Nil)));
  V v_t_2440 = (g_prelude_2e_2b_2b(v_rs_2438, v_t_2439));
  V v_t_2441 = (g_list_2etake(v_h_245, v_t_2440));
  V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 2, 3);
  V v_t_2443 = (g_std_2ecli_2einteractive_2eformWords(heff_dup(v_fm_242)));
  HeffT2 v_t_2444 = (g_std_2ecli_2eproblemOf_24cpr(v_t_2442, v_t_2443));
  V v_t_2452;
  {
    V v_field_2446 = v_t_2444.f[1];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    V v_s_2449;
    if ((v_tag_2445 == ((int64_t)0ULL))) {
      V v_p_2447 = v_field_2446;
      V v_t_2448 = ({ V a_0 = v_p_2447; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop(v_p_2447); r_; });
      v_s_2449 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2eformView_str5), heff_strAppend(v_t_2448, ((V)&g_std_2ecli_2einteractive_2eformView_str6)));
    } else {
      heff_drop(v_field_2446);
      v_s_2449 = ((V)&g_std_2ecli_2einteractive_2eformView_str7);
    }
    V v_s_2450 = (g_std_2eterminal_2ewidget_2epad(heff_dup(v_columns_244), v_s_2449));
    V v_t_2451 = heff_rec_n(2, shape_text__style, (V[]){v_s_2450, NTAG(TAG_Inverse)});
    v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
  }
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
  V v_t_2454 = (g_prelude_2e_2b_2b(v_t_2441, v_t_2453));
  V v_t_2455 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 1, 3);
  V v_t_2456 = ({ V a_0 = v_t_2455; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewordsFrom(a_0, a_1, a_2, a_3)); heff_drop(v_t_2455); r_; });
  V v_t_2457 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_columns_244; V a_3 = ((V)&g_std_2ecli_2einteractive_2eformView_str8); V a_4 = v_t_2456; V r_ = (g_list_2efoldl_24f354261656x2102112793(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2456); r_; });
  V v_t_2458 = (g_list_2efoldl_24s1396019640x159929943(MK_INT(0LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
  HeffT3 v_t_2459 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
  V v_t_2465;
  {
    V v_field_2461 = v_t_2459.f[1];
    V v_field_2462 = v_t_2459.f[2];
    int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
    if ((v_tag_2460 == ((int64_t)0ULL))) {
      V v_x_2463 = v_field_2461;
      V v_x12_2464 = v_field_2462;
      heff_drop(v_x12_2464);
      v_t_2465 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2463});
    } else {
      heff_drop(v_field_2461);
      heff_drop(v_field_2462);
      v_t_2465 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2466 = (g_std_2ecli_2einteractive_2eformCursor(heff_intAdd(v_t_2457, MK_INT(2LL)), v_t_2458, v_fm_242, v_t_2465));
  return heff_rec_n(2, shape_rows__cursor, (V[]){v_t_2454, v_t_2466});
}
V g_std_2ecli_2einteractive_2eformView_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformView(a[0], a[1], a[2]);
}
Clo g_std_2ecli_2einteractive_2eview_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eview_entry, 2, 0};

V g_std_2ecli_2einteractive_2eview(V v_size_240, V v_m_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_m_241, 5));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    HEFF_LAST return g_std_2ecli_2einteractive_2elistView(v_size_240, v_m_241);
  }
  case TAG_Just: {
    V v_fm_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    return (g_std_2ecli_2einteractive_2eformView(v_size_240, v_m_241, v_fm_243));
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2ecli_2einteractive_2eview_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eview(a[0], a[1]);
}
Clo g_std_2ecli_2einteractive_2econtrolOnList_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2econtrolOnList_24tok1_entry, 3, 0};

V g_std_2ecli_2einteractive_2econtrolOnList_24tok1(V v_tok_240, V v_c_241, V v_m_242) {
top: ;
  if ((heff_runeEq_c(heff_dup(v_c_241), MK_INT(110LL)) || heff_runeEq_c(heff_dup(v_c_241), MK_INT(112LL)))) {
    return ({ V b_0 = heff_tag_at_n(v_tok_240, TAG_Control, 1, (V[]){v_c_241}); V a_1 = v_m_242; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
  } else {
    V v_f_243 = ({ V b_0 = heff_tag_at_n(v_tok_240, TAG_Control, 1, (V[]){v_c_241}); V a_1 = heff_take_field(v_m_242, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_244 = heff_take_field(v_m_242, 3);
    V v_t_248;
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      v_t_248 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = heff_dup(heff_rfield(v_f_243, 0));
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nil: {
        v_t_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_245, 0ULL, 2);
        v_t_248 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
    }
    V v_t_249 = ({ V rv_2 = v_f_243; V rv_3 = v_t_248; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_242, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_249});
  }
}
V g_std_2ecli_2einteractive_2econtrolOnList_24tok1_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2econtrolOnList_24tok1(a[0], a[1], a[2]);
}
Clo g_std_2ecli_2einteractive_2etypedOnList_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2etypedOnList_24tok1_entry, 3, 0};

V g_std_2ecli_2einteractive_2etypedOnList_24tok1(V v_tok_240, V v_c_241, V v_m_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_m_242, 3));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_f_244 = ({ V b_0 = heff_tag_at_n(v_tok_240, TAG_Char, 1, (V[]){v_c_241}); V a_1 = heff_take_field(v_m_242, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_245 = heff_take_field(v_m_242, 3);
    V v_t_249;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      v_t_249 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V v_t_246 = heff_dup(heff_rfield(v_f_244, 0));
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        v_t_249 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_246, 0ULL, 2);
        v_t_249 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_246);
      }
    }
    V v_t_2410 = ({ V rv_2 = v_f_244; V rv_3 = v_t_249; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_242, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2410});
  } else {
    heff_drop(v_t_243);
    if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(113LL))) {
      heff_drop(v_c_241);
      heff_drop_rec(v_m_242, 6);
      return heff_tag_at_n(v_tok_240, TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
    } else {
      if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(106LL))) {
        heff_drop_cell(v_tok_240, 1);
        heff_drop(v_c_241);
        return ({ V b_0 = NTAG(TAG_ArrowDown); V a_1 = v_m_242; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
      } else {
        if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(107LL))) {
          heff_drop_cell(v_tok_240, 1);
          heff_drop(v_c_241);
          return ({ V b_0 = NTAG(TAG_ArrowUp); V a_1 = v_m_242; V r_ = (g_std_2ecli_2einteractive_2emoved(b_0, a_1)); heff_drop(b_0); r_; });
        } else {
          if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(47LL))) {
            heff_drop(v_c_241);
            V v_t_2411 = ({ V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_m_242, 55ULL, 6, shape_prog__entries__filter__typing__menu__form, 3903u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
            return heff_tag_at_n(v_tok_240, TAG_Continue, 1, (V[]){v_t_2411});
          } else {
            V v_f_2412 = ({ V b_0 = heff_tag_at_n(v_tok_240, TAG_Char, 1, (V[]){v_c_241}); V a_1 = heff_take_field(v_m_242, 2); V r_ = (g_std_2eterminal_2ewidget_2efieldKey(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2413 = heff_take_field(v_m_242, 3);
            V v_t_2417;
            if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
              heff_drop(v_t_2413);
              v_t_2417 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2413);
              V v_t_2414 = heff_dup(heff_rfield(v_f_2412, 0));
              switch (heff_tag_of(v_t_2414)) {
              case TAG_Nil: {
                v_t_2417 = NTAG(TAG_False);
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_t_2414, 0ULL, 2);
                v_t_2417 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_t_2414);
              }
            }
            V v_t_2418 = ({ V rv_2 = v_f_2412; V rv_3 = v_t_2417; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_242, 35ULL, 6, shape_prog__entries__filter__typing__menu__form, 3087u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
            return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2418});
          }
        }
      }
    }
  }
}
V g_std_2ecli_2einteractive_2etypedOnList_24tok1_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2etypedOnList_24tok1(a[0], a[1], a[2]);
}