// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_fuel 9649789
#define LBL_jobs 9763101
#define LBL_packages 1496006433
#define LBL_pattern 1588251091
#define LBL_seed 10021688
#define LBL_update 1108295668
static uint32_t shape_seed__pattern__jobs__update__fuel[] = {LBL_seed, LBL_pattern, LBL_jobs, LBL_update, LBL_fuel};
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo;
V g_heff_2ebuild_2etesting_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_clo;
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_str3, 1, "\012");
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam3(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_entry, 7, 0};

V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0(V v_hd_240, V v_f_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_k_245, V v_x_246) {
top: ;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Left: {
    V v_c_248 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
    return heff_tail(v_c_248, 2, (V[]){heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam0, 1, 6, (V[]){v_f_241, v_hd_240, v_lit_242, v_lit_243, v_lit_244, v_k_245})});
  }
  case TAG_Right: {
    V v_y_2418 = heff_field(v_x_246, 0);
    V v_c_2419 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
    return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam3, 1, 7, (V[]){v_f_241, v_hd_240, heff_dup(v_y_2418), v_lit_242, v_lit_243, v_lit_244, v_k_245})});
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a6); return r;
}
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_lit_242 = heff_env(self)[1];
  V v_lit_243 = heff_env(self)[2];
  V v_lit_244 = heff_env(self)[3];
  V v_f_241 = heff_env(self)[4];
  V v_hd_240 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_t_2412 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2411, heff_dup(heff_rfield(v_x_2410, 4))));
  heff_clo_take(self, 7);
  V v_x_2413 = (g_list_2efoldl_24s571074576x1179600767(v_x_2410, v_t_2412));
  V v_j_2414 = heff_strFind(((V)&g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_str0), ((V)&g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_str1), MK_INT(0LL));
  V v_t_2415;
  if (heff_intLt_c_lent(v_j_2414, MK_INT(0LL), 2)) {
    heff_drop(v_j_2414);
    v_t_2415 = MK_INT(0LL);
  } else {
    v_t_2415 = v_j_2414;
  }
  V v_t_2416 = heff_rec_n(5, shape_seed__pattern__jobs__update__fuel, (V[]){v_lit_242, v_lit_243, v_lit_244, NTAG(TAG_False), NTAG(TAG_False)});
  V v_t_2417 = heff_bool(heff_strEq_c(heff_strSlice_lent(((V)&g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_str2), MK_INT(0LL), v_t_2415, 3), heff_dup(g_heff_2ebuild_2etesting_2eexpectErrorsLine_get())));
  heff_drop(v_t_2415);
  return ({ V a_0 = v_t_2416; V a_1 = v_f_241; V a_2 = v_t_2417; V a_3 = v_x_2413; V a_4 = v_hd_240; V a_5 = v_k_245; V r_ = (g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2417); r_; });
}
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_lit_242 = heff_env(self)[1];
  V v_lit_243 = heff_env(self)[2];
  V v_lit_244 = heff_env(self)[3];
  V v_f_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam2, 1, 7, (V[]){v_x_2410, v_lit_242, v_lit_243, v_lit_244, v_f_241, v_hd_240, v_k_245})));
}
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_249, heff_dup(v_f_241), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam1, 1, 6, (V[]){v_hd_240, v_lit_242, v_lit_243, v_lit_244, v_f_241, v_k_245})));
}
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_y_2418 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_f_241 = heff_env(self)[5];
  V v_hd_240 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  V v_t_2423 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2422, heff_dup(heff_rfield(v_x_2421, 4))));
  heff_clo_take(self, 8);
  V v_x_2424 = (g_list_2efoldl_24s571074576x1179600767(v_x_2421, v_t_2423));
  V v_d_2425 = heff_strLength_lent(v_y_2418, 0);
  V v_j_2426 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_str3), v_y_2418, MK_INT(0LL), 5);
  V v_t_2427;
  if (heff_intLt_c_lent(v_j_2426, MK_INT(0LL), 2)) {
    heff_drop(v_j_2426);
    v_t_2427 = v_d_2425;
  } else {
    heff_drop(v_d_2425);
    v_t_2427 = v_j_2426;
  }
  V v_t_2428 = heff_rec_n(5, shape_seed__pattern__jobs__update__fuel, (V[]){v_lit_242, v_lit_243, v_lit_244, NTAG(TAG_False), NTAG(TAG_False)});
  V v_t_2429 = heff_bool(heff_strEq_c(heff_strSlice_lent(v_y_2418, MK_INT(0LL), v_t_2427, 2), heff_dup(g_heff_2ebuild_2etesting_2eexpectErrorsLine_get())));
  heff_drop(v_y_2418);
  heff_drop(v_t_2427);
  return ({ V a_0 = v_t_2428; V a_1 = v_f_241; V a_2 = v_t_2429; V a_3 = v_x_2424; V a_4 = v_hd_240; V a_5 = v_k_245; V r_ = (g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2429); r_; });
}
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_y_2418 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_f_241 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam5, 1, 8, (V[]){v_x_2421, v_y_2418, v_lit_242, v_lit_243, v_lit_244, v_f_241, v_hd_240, v_k_245})));
}
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_y_2418 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_2420, heff_dup(v_f_241), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_lam4, 1, 7, (V[]){v_hd_240, v_y_2418, v_lit_242, v_lit_243, v_lit_244, v_f_241, v_k_245})));
}