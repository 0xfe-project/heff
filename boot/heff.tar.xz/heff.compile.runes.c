// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Enter_24heff_2ecompile_2erunes_2ereads 18072
#define TAG_IntShl 35657
#define TAG_IntShr 35663
#define TAG_Keep 49586
#define TAG_MkArm 55352
#define TAG_Perform 19235
#define TAG_StrRuneAt 38304
#define TAG_StrRuneDecode 45427
#define TAG_StrRuneWidth 48503
#define TAG_Tip 31527
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_rune 10007553
#define LBL_runeName 1565672251
#define LBL_sure 10037468
#define LBL_vars 10107635
#define LBL_widthName 1572745494
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__vars__runeName__widthName[] = {LBL_key, LBL_vars, LBL_runeName, LBL_widthName};
static uint32_t shape_rune__key__args__vars__at__sure[] = {LBL_rune, LBL_key, LBL_args, LBL_vars, LBL_at, LBL_sure};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econcatMapI(V, V);
V g_heff_2ecompile_2eir_2econcatMapI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_clo;
V g_heff_2ecompile_2eir_2efoldParts(V, V, V);
V g_heff_2ecompile_2eir_2efoldParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldParts_clo;
V g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle(V, V, V, V);
V g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_clo;
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok1(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok1_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok2_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok3(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok3_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_clo;
V g_heff_2ecompile_2erunes_2ealiasing(V, V, V);
V g_heff_2ecompile_2erunes_2ealiasing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2ealiasing_clo;
V g_heff_2ecompile_2erunes_2ealongOf(V, V);
V g_heff_2ecompile_2erunes_2ealongOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2ealongOf_clo;
V g_heff_2ecompile_2erunes_2eanyReads(V, V, V);
V g_heff_2ecompile_2erunes_2eanyReads_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2eanyReads_clo;
HeffT2 g_heff_2ecompile_2erunes_2eatomKey_24cpr(V, V);
HeffT2 g_heff_2ecompile_2erunes_2eatomKeys_24cpr(V, V);
V g_heff_2ecompile_2erunes_2econdSure(V, V);
V g_heff_2ecompile_2erunes_2econdSure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2econdSure_clo;
V g_heff_2ecompile_2erunes_2edefOf(V);
V g_heff_2ecompile_2erunes_2edefOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2edefOf_clo;
V g_heff_2ecompile_2erunes_2eexprOf(V);
V g_heff_2ecompile_2erunes_2eexprOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2eexprOf_clo;
V g_heff_2ecompile_2erunes_2efirstSure(V, V);
V g_heff_2ecompile_2erunes_2efirstSure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2efirstSure_clo;
V g_heff_2ecompile_2erunes_2enamed(V, V, V);
V g_heff_2ecompile_2erunes_2enamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2enamed_clo;
V g_heff_2ecompile_2erunes_2enamedAlong(V, V, V);
V g_heff_2ecompile_2erunes_2enamedAlong_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2enamedAlong_clo;
HeffT2 g_heff_2ecompile_2erunes_2eoperandKey_24cpr(V, V);
V g_heff_2ecompile_2erunes_2eoperandVars(V, V);
V g_heff_2ecompile_2erunes_2eoperandVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2eoperandVars_clo;
HeffT2 g_heff_2ecompile_2erunes_2epairAlong_24cpr(V, V, V, V);
V g_heff_2ecompile_2erunes_2ereadOf(V, V, V, V, V);
V g_heff_2ecompile_2erunes_2ereadOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2ereadOf_clo;
HeffT2 g_heff_2ecompile_2erunes_2ereadOf_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ecompile_2erunes_2ereadOf2_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2erunes_2ereadOnceAt(V, V, V, V, V, V);
V g_heff_2ecompile_2erunes_2ereadOnceAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2ereadOnceAt_clo;
V g_heff_2ecompile_2erunes_2ereadOnceAt_24dps(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_clo;
V g_heff_2ecompile_2erunes_2ereads(V);
V g_heff_2ecompile_2erunes_2ereads_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2ereads_clo;
V g_heff_2ecompile_2erunes_2esureW(V, V, V, V);
V g_heff_2ecompile_2erunes_2esureW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2esureW_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1806601701x937560846(V, V);
V g_list_2eany_24s1806601701x937560846_entry(V self, V *a);
extern Clo g_list_2eany_24s1806601701x937560846_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2efoldl_24s1045622919x1125142156(V, V);
V g_list_2efoldl_24s1045622919x1125142156_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1045622919x1125142156_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s403268044x1108109324(V, V);
V g_list_2ekeepIf_24s403268044x1108109324_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s403268044x1108109324_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
HEFF_LIT(g_heff_2ecompile_2erunes_2eatomKey_24cpr_str0, 1, "v");
HEFF_LIT(g_heff_2ecompile_2erunes_2eatomKey_24cpr_str1, 1, "i");

HeffT2 g_heff_2ecompile_2erunes_2eatomKey_24cpr(V v_al_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_al_240, v_x_242));
    V v_t_247;
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_245;
        v_t_247 = v_x_246;
      } else {
        heff_drop(v_field_245);
        v_t_247 = heff_dup(v_x_242);
      }
    }
    V v_f_248 = heff_strAppend(((V)&g_heff_2ecompile_2erunes_2eatomKey_24cpr_str0), v_t_247);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
  }
  case TAG_EGlobal: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    V v_n_2433 = heff_field(v_x2_241, 0);
    V v_f_2434 = heff_strAppend(((V)&g_heff_2ecompile_2erunes_2eatomKey_24cpr_str1), heff_intShow(heff_dup(v_n_2433)));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2434}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_heff_2ecompile_2erunes_2eatomKeys_24cpr(V v_al_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = ({ V a_0 = v_al_240; V a_1 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2erunes_2eatomKey_24cpr(a_0, a_1)); heff_drop(v_e_242); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_k_247 = v_field_246;
        HeffT2 v_t_248 = (g_heff_2ecompile_2erunes_2eatomKeys_24cpr(v_al_240, v_rest_243));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x_2411 = v_field_2410;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_k_247, v_x_2411})}});
          } else {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_k_247);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2erunes_2eoperandKey_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erunes_2eoperandKey_24cpr_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2erunes_2eoperandKey_24cpr_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2erunes_2eoperandKey_24cpr_str3, 1, ")");

HeffT2 g_heff_2ecompile_2erunes_2eoperandKey_24cpr(V v_al_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EPrimCall: {
    V v_p_242 = heff_field(v_e_241, 0);
    V v_argv_243 = heff_field(v_e_241, 1);
    switch (heff_tag_of(v_p_242)) {
    case TAG_IntShl: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_IntShr: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ArrayIndex: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ArrayGenerate: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Keep: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Perform: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: {
      HeffT2 v_t_244 = (g_heff_2ecompile_2erunes_2eatomKeys_24cpr(v_al_240, heff_dup(v_argv_243)));
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          V v_x_247 = v_field_246;
          V v_t_248 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_242));
          V v_t_2411;
          switch (heff_tag_of(v_x_247)) {
          case TAG_Nil: {
            v_t_2411 = ((V)&g_heff_2ecompile_2erunes_2eoperandKey_24cpr_str0);
            break;
          }
          case TAG_Cons: {
            V v_x_249 = heff_field(v_x_247, 0);
            V v_xs_2410 = heff_field(v_x_247, 1);
            heff_take_n(v_x_247, 3ULL, 2);
            v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2erunes_2eoperandKey_24cpr_str1); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
            break;
          }
          default: heff_nomatch(v_x_247);
          }
          V v_t_2412 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2erunes_2eoperandKey_24cpr_str2)), v_t_2411);
          V v_f_2413 = heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2erunes_2eoperandKey_24cpr_str3));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
        } else {
          heff_drop(v_field_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    }
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2erunes_2eatomKey_24cpr(v_al_240, v_e_241);
  }
  }
}
Clo g_heff_2ecompile_2erunes_2eoperandVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2eoperandVars_entry, 2, 0};

V g_heff_2ecompile_2erunes_2eoperandVars(V v_al_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    HeffT2 v_t_243 = ({ V a_0 = v_al_240; V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_al_240); r_; });
    V v_t_247;
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_245;
        v_t_247 = v_x_246;
      } else {
        heff_drop(v_field_245);
        v_t_247 = heff_dup(v_x_242);
      }
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ERecord: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrim: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_argv_2429 = heff_field(v_x2_241, 1);
    V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erunes_2eoperandVars_clo), 1, (V[]){v_al_240}));
    HEFF_LAST return g_heff_2ecompile_2eir_2econcatMapI(v_t_2430, v_argv_2429);
  }
  case TAG_ECall: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ESet: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EValues: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_drop(v_al_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erunes_2eoperandVars_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erunes_2eoperandVars(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erunes_2ereadOf2_24cpr_str0, 1, ";");

HeffT2 g_heff_2ecompile_2erunes_2ereadOf2_24cpr(V v_al_240, V v_rune_241, V v_sure_242, V v_at_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_al_240);
    heff_drop(v_rune_241);
    heff_drop(v_sure_242);
    heff_drop(v_at_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_s_245 = heff_field(v_x5_244, 0);
    V v_x52_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x52_246)) {
    case TAG_Nil: {
      heff_drop(v_al_240);
      heff_drop(v_rune_241);
      heff_drop(v_sure_242);
      heff_drop(v_at_243);
      heff_drop(v_s_245);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_i_247 = heff_field(v_x52_246, 0);
      V v_x522_248 = heff_field(v_x52_246, 1);
      V v_ru_24x52_246_24Cons = heff_take_reuse_n(v_x52_246, 3ULL, 2);
      switch (heff_tag_of(v_x522_248)) {
      case TAG_Nil: {
        HeffT2 v_t_249 = (g_heff_2ecompile_2erunes_2eoperandKey_24cpr(v_al_240, v_s_245));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_ks_2412 = v_field_2411;
            HeffT2 v_t_2413 = (g_heff_2ecompile_2erunes_2eoperandKey_24cpr(v_al_240, v_i_247));
            {
              V v_field_2415 = v_t_2413.f[1];
              int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
              if ((v_tag_2414 == ((int64_t)0ULL))) {
                V v_x_2416 = v_field_2415;
                V v_t_2417 = heff_strAppend(heff_strAppend(v_ks_2412, ((V)&g_heff_2ecompile_2erunes_2ereadOf2_24cpr_str0)), v_x_2416);
                V v_t_2418 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_i_247), NTAG(TAG_Nil)});
                V v_t_2419 = (g_heff_2ecompile_2erunes_2eoperandVars(heff_dup(v_al_240), v_s_245));
                V v_t_2420 = ({ V a_0 = v_al_240; V a_1 = v_i_247; V r_ = (g_heff_2ecompile_2erunes_2eoperandVars(a_0, a_1)); heff_drop(v_i_247); r_; });
                V v_t_2421 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x52_246_24Cons, v_t_2419, v_t_2420));
                V v_f_2422 = heff_rec_n(6, shape_rune__key__args__vars__at__sure, (V[]){v_rune_241, v_t_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_s_245, v_t_2418}), v_t_2421, v_at_243, v_sure_242});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2422}});
              } else {
                heff_drop(v_al_240);
                heff_drop(v_rune_241);
                heff_drop(v_sure_242);
                heff_drop(v_at_243);
                heff_drop(v_s_245);
                heff_drop_cell(v_ru_24x5_244_24Cons, 2);
                heff_drop(v_i_247);
                heff_drop_cell(v_ru_24x52_246_24Cons, 2);
                heff_drop(v_ks_2412);
                heff_drop(v_field_2415);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_al_240);
            heff_drop(v_rune_241);
            heff_drop(v_sure_242);
            heff_drop(v_at_243);
            heff_drop(v_s_245);
            heff_drop_cell(v_ru_24x5_244_24Cons, 2);
            heff_drop(v_i_247);
            heff_drop_cell(v_ru_24x52_246_24Cons, 2);
            heff_drop(v_field_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_x522_248, 0ULL, 2);
        heff_drop(v_al_240);
        heff_drop(v_rune_241);
        heff_drop(v_sure_242);
        heff_drop(v_at_243);
        heff_drop(v_s_245);
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_i_247);
        heff_drop_cell(v_ru_24x52_246_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x522_248)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x52_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x5_244)}});
  }
}

HeffT2 g_heff_2ecompile_2erunes_2ereadOf_24cpr(V v_al_240, V v_sure_241, V v_at_242, V v_p_243, V v_argv_244) {
top: ;
  switch (heff_tag_of(v_p_243)) {
  case TAG_StrRuneAt: {
    HEFF_LAST return g_heff_2ecompile_2erunes_2ereadOf2_24cpr(v_al_240, NTAG(TAG_True), v_sure_241, v_at_242, v_argv_244);
  }
  case TAG_StrRuneWidth: {
    HEFF_LAST return g_heff_2ecompile_2erunes_2ereadOf2_24cpr(v_al_240, NTAG(TAG_False), v_sure_241, v_at_242, v_argv_244);
  }
  default: {
    heff_drop(v_al_240);
    heff_drop(v_sure_241);
    heff_drop(v_at_242);
    heff_drop(v_argv_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  }
}
Clo g_heff_2ecompile_2erunes_2ereadOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2ereadOf_entry, 5, 0};

V g_heff_2ecompile_2erunes_2ereadOf(V v_al_240, V v_sure_241, V v_at_242, V v_p_243, V v_argv_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2ecompile_2erunes_2ereadOf_24cpr(v_al_240, v_sure_241, v_at_242, v_p_243, v_argv_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_247});
    } else {
      heff_drop(v_field_247);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2erunes_2ereadOf_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erunes_2ereadOf(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erunes_2econdSure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2econdSure_entry, 2, 0};

V g_heff_2ecompile_2erunes_2econdSure(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    return v_rest_241;
  }
  case TAG_CFalse: {
    return v_rest_241;
  }
  case TAG_CRel: {
    V v_x_243 = heff_field(v_x1_240, 1);
    V v_y_244 = heff_field(v_x1_240, 2);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_y_244), v_rest_241})});
  }
  case TAG_CTest: {
    V v_x_245 = heff_field(v_x1_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_245), v_rest_241});
  }
  case TAG_CNot: {
    V v_c_246 = heff_field(v_x1_240, 0);
    V t_0 = v_c_246;
    V t_1 = v_rest_241;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    goto top;
  }
  case TAG_CIf: {
    V v_a_247 = heff_field(v_x1_240, 0);
    V t_0 = v_a_247;
    V t_1 = v_rest_241;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erunes_2econdSure_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erunes_2econdSure(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erunes_2esureW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2esureW_entry, 4, 0};

V g_heff_2ecompile_2erunes_2esureW(V v_al_240, V v_at_241, V v_acc_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_al_240);
    heff_drop(v_at_241);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EApp: {
      V v_f_246 = heff_field(v_x41_244, 0);
      V v_argv_247 = heff_field(v_x41_244, 1);
      V v_ru_24x41_244_24EApp = heff_take_reuse_n(v_x41_244, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x41_244_24EApp, v_argv_247, v_rest_245));
      V t_0 = v_al_240;
      V t_1 = v_at_241;
      V t_2 = v_acc_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_f_246, v_t_248});
      v_al_240 = t_0;
      v_at_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_249 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x4_243_24Cons, v_fs_249, v_rest_245));
      V t_0 = v_al_240;
      V t_1 = v_at_241;
      V t_2 = v_acc_242;
      V t_3 = v_t_2411;
      v_al_240 = t_0;
      v_at_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2412 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 4);
      V t_0 = v_al_240;
      V t_1 = v_at_241;
      V t_2 = v_acc_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e_2412, v_rest_245});
      v_al_240 = t_0;
      v_at_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2417 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 3);
      V v_t_2419 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_243_24Cons, v_argv_2417, v_rest_245));
      V t_0 = v_al_240;
      V t_1 = v_at_241;
      V t_2 = v_acc_242;
      V t_3 = v_t_2419;
      v_al_240 = t_0;
      v_at_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2420 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 2);
      V t_0 = v_al_240;
      V t_1 = v_at_241;
      V t_2 = v_acc_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_s_2420, v_rest_245});
      v_al_240 = t_0;
      v_at_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_p_2422 = heff_field(v_x41_244, 0);
      V v_argv_2423 = heff_field(v_x41_244, 1);
      V v_ru_24x41_244_24EPrimCall = heff_take_reuse_n(v_x41_244, 3ULL, 2);
      HeffT2 v_t_2424 = ({ V a_0 = heff_dup(v_al_240); V a_1 = NTAG(TAG_True); V a_2 = heff_dup(v_at_241); V a_3 = v_p_2422; V a_4 = heff_dup(v_argv_2423); HeffT2 r_ = (g_heff_2ecompile_2erunes_2ereadOf_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_p_2422); r_; });
      V v_t_2428;
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_r_2427 = v_field_2426;
          v_t_2428 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_r_2427, v_acc_242});
        } else {
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          heff_drop(v_field_2426);
          v_t_2428 = v_acc_242;
        }
      }
      V v_t_2429 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x41_244_24EPrimCall, v_argv_2423, v_rest_245));
      V t_0 = v_al_240;
      V t_1 = v_at_241;
      V t_2 = v_t_2428;
      V t_3 = v_t_2429;
      v_al_240 = t_0;
      v_at_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2431 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      V v_t_2432 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_243_24Cons, v_argv_2431, v_rest_245));
      V t_0 = v_al_240;
      V t_1 = v_at_241;
      V t_2 = v_acc_242;
      V t_3 = v_t_2432;
      v_al_240 = t_0;
      v_at_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2433 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2434 = ({ V a_0 = v_c_2433; V a_1 = v_rest_245; V r_ = (g_heff_2ecompile_2erunes_2econdSure(a_0, a_1)); heff_drop(v_c_2433); r_; });
      V t_0 = v_al_240;
      V t_1 = v_at_241;
      V t_2 = v_acc_242;
      V t_3 = v_t_2434;
      v_al_240 = t_0;
      v_at_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2435 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      V v_t_2436 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_243_24Cons, v_es_2435, v_rest_245));
      V t_0 = v_al_240;
      V t_1 = v_at_241;
      V t_2 = v_acc_242;
      V t_3 = v_t_2436;
      v_al_240 = t_0;
      v_at_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: {
      heff_drop(v_x41_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_al_240;
      V t_1 = v_at_241;
      V t_2 = v_acc_242;
      V t_3 = v_rest_245;
      v_al_240 = t_0;
      v_at_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erunes_2esureW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erunes_2esureW(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erunes_2eanyReads_lam2(V self, V *args);
V g_heff_2ecompile_2erunes_2eanyReads_lam1(V self, V *args);
V g_heff_2ecompile_2erunes_2eanyReads_lam0(V self, V *args);
Clo g_heff_2ecompile_2erunes_2eanyReads_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2eanyReads_entry, 3, 0};

V g_heff_2ecompile_2erunes_2eanyReads(V v_al_240, V v_at_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_ELam: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_al_240);
    heff_drop(v_at_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_al_240);
    heff_drop(v_at_241);
    return NTAG(TAG_Nil);
  }
  default: {
    V v_al_247 = heff_dup(v_al_240);
    V v_at_248 = heff_dup(v_at_241);
    V v_e_249 = heff_dup(v_e_242);
    V v_x1_2449;
    switch (heff_tag_of(v_e_249)) {
    case TAG_EVar: {
      heff_take_n(v_e_249, 0ULL, 1);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e_249, 0ULL, 1);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_e_249, 0ULL, 2);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_e_249, 0ULL, 2);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_e_249, 0ULL, 3);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_e_249, 0ULL, 2);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_e_249, 0ULL, 4);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_e_249, 0ULL, 3);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_e_249, 0ULL, 2);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_e_249, 0ULL, 1);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      V v_p_2431 = heff_field(v_e_249, 0);
      V v_argv_2432 = heff_field(v_e_249, 1);
      heff_take_n(v_e_249, 3ULL, 2);
      v_x1_2449 = ({ V a_0 = v_al_247; V a_1 = NTAG(TAG_False); V a_2 = v_at_248; V a_3 = v_p_2431; V a_4 = v_argv_2432; V r_ = (g_heff_2ecompile_2erunes_2ereadOf(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_p_2431); r_; });
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_e_249, 0ULL, 2);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_e_249, 0ULL, 1);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_e_249, 0ULL, 1);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_e_249, 0ULL, 1);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_e_249, 0ULL, 1);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_e_249, 0ULL, 2);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e_249, 0ULL, 1);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_e_249, 0ULL, 1);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_e_249, 0ULL, 3);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_e_249, 0ULL, 1);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_e_249, 0ULL, 2);
      heff_drop(v_al_247);
      heff_drop(v_at_248);
      v_x1_2449 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_249);
    }
    V v_rs_2459 = heff_tr(g_heff_2ecompile_2eir_2efoldParts(heff_clo_n(g_heff_2ecompile_2erunes_2eanyReads_lam0, 3, 2, (V[]){v_al_240, v_at_241}), v_e_242, NTAG(TAG_Nil)));
    switch (heff_tag_of(v_x1_2449)) {
    case TAG_Nothing: {
      return v_rs_2459;
    }
    case TAG_Just: {
      V v_r_2460 = heff_field(v_x1_2449, 0);
      heff_take_n(v_x1_2449, 1ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_2460, v_rs_2459});
    }
    default: return heff_nomatch(v_x1_2449);
    }
  }
  }
}
V g_heff_2ecompile_2erunes_2eanyReads_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erunes_2eanyReads(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erunes_2eanyReads_lam2(V self, V *args) {
  V v_x_2455 = args[0];
  V v_r_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_x_2455}));
  return ({ V a_0 = v_t_2456; V b_1 = heff_get_n(v_r_2454, 3, 6); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2ecompile_2erunes_2eanyReads_lam1(V self, V *args) {
  V v_r_2454 = args[0];
  V v_xs_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2457 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erunes_2eanyReads_lam2, 1, 1, (V[]){v_r_2454}); V a_1 = v_xs_2450; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2450); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2457) == NTAG(TAG_True)));
  heff_drop(v_x1_2457);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erunes_2eanyReads_lam0(V self, V *args) {
  V v_xs_2450 = args[0];
  V v_p_2451 = args[1];
  V v_rs_2452 = args[2];
  V v_al_240 = heff_env(self)[0];
  V v_at_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_rs_2453 = (g_heff_2ecompile_2erunes_2eanyReads(v_al_240, v_at_241, v_p_2451));
  V v_t_2458 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erunes_2eanyReads_lam1, 1, 1, (V[]){v_xs_2450}), v_rs_2453));
  return (g_heff_2ecompile_2eir_2eappendI(v_t_2458, v_rs_2452));
}
Clo g_heff_2ecompile_2erunes_2efirstSure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2efirstSure_entry, 2, 0};

V g_heff_2ecompile_2erunes_2efirstSure(V v_x1_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_r_241;
  }
  case TAG_Cons: {
    V v_q_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    V v_t_244;
    if (((heff_dup(heff_rfield(v_q_242, 5)) == NTAG(TAG_True)) && (heff_strEq_c(heff_dup(heff_rfield(v_q_242, 1)), heff_dup(heff_rfield(v_r_241, 1))) && heff_intLt_c(heff_dup(heff_rfield(v_q_242, 4)), heff_dup(heff_rfield(v_r_241, 4)))))) {
      heff_drop_rec(v_r_241, 6);
      v_t_244 = heff_dup(v_q_242);
    } else {
      v_t_244 = v_r_241;
    }
    V t_0 = v_rs_243;
    V t_1 = v_t_244;
    v_x1_240 = t_0;
    v_r_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erunes_2efirstSure_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erunes_2efirstSure(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erunes_2ealiasing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2ealiasing_entry, 3, 0};

V g_heff_2ecompile_2erunes_2ealiasing(V v_al_240, V v_x_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_a_242, 0);
    V v_t_244 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_al_240, NTAG(TAG_Nil)));
    V v_ps_245 = (g_list_2ekeepIf_24s403268044x1108109324(v_x_241, v_t_244));
    V v_t_246 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_245; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_245); r_; });
    HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_al_240, v_y_243));
    V v_t_2411;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_x_2410 = v_field_249;
        v_t_2411 = v_x_2410;
      } else {
        heff_drop(v_field_249);
        v_t_2411 = heff_dup(v_y_243);
      }
    }
    HEFF_LAST return g_std_2eordmap_2einsert_24s615484302x989744458(v_t_246, v_x_241, v_t_2411);
  }
  default: {
    V v_t_2412 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_al_240, NTAG(TAG_Nil)));
    V v_ps_2413 = ({ V a_0 = v_x_241; V a_1 = v_t_2412; V r_ = (g_list_2ekeepIf_24s403268044x1108109324(a_0, a_1)); heff_drop(v_x_241); r_; });
    return ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2413; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2413); r_; });
  }
  }
}
V g_heff_2ecompile_2erunes_2ealiasing_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2erunes_2ealiasing(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam2(V self, V *args);
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam3(V self, V *args);
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam5(V self, V *args);
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam4(V self, V *args);
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam6(V self, V *args);

HeffT2 g_heff_2ecompile_2erunes_2epairAlong_24cpr(V v_al_240, V v_at_241, V v_seen_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_ELet: {
    V v_x_244 = heff_field(v_e_243, 0);
    V v_a_245 = heff_field(v_e_243, 1);
    V v_b_246 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_247 = (g_heff_2ecompile_2erunes_2eanyReads(heff_dup(v_al_240), heff_dup(v_at_241), heff_dup(v_a_245)));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_245), NTAG(TAG_Nil)});
    V v_t_249 = (g_heff_2ecompile_2erunes_2esureW(heff_dup(v_al_240), heff_dup(v_at_241), v_t_247, v_t_248));
    V v_rs_2410 = (g_heff_2ecompile_2eir_2eappendI(v_t_249, heff_dup(v_seen_242)));
    HeffT2 v_t_2414 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam0, 1, 1, (V[]){heff_dup(v_rs_2410)}), v_rs_2410));
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        heff_drop(v_al_240);
        heff_drop(v_at_241);
        heff_drop(v_seen_242);
        heff_drop(v_x_244);
        heff_drop(v_a_245);
        heff_drop(v_b_246);
        V v_r_2417 = v_field_2416;
        V v_r_2418 = ({ V a_0 = v_rs_2410; V a_1 = v_r_2417; V r_ = (g_heff_2ecompile_2erunes_2efirstSure(a_0, a_1)); heff_drop(v_rs_2410); r_; });
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_r_2418}});
      } else {
        heff_drop(v_rs_2410);
        heff_drop(v_field_2416);
        V v_t_2419 = (g_heff_2ecompile_2erunes_2ealiasing(v_al_240, heff_dup(v_x_244), v_a_245));
        V v_t_2420 = (g_heff_2ecompile_2erunes_2eanyReads(heff_dup(v_al_240), heff_dup(v_at_241), heff_dup(v_a_245)));
        V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_245, NTAG(TAG_Nil)});
        V v_t_2422 = (g_heff_2ecompile_2erunes_2esureW(v_al_240, heff_dup(v_at_241), v_t_2420, v_t_2421));
        V v_rs_2423 = (g_heff_2ecompile_2eir_2eappendI(v_t_2422, v_seen_242));
        V v_t_2429 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam1, 1, 1, (V[]){v_x_244}), v_rs_2423));
        V t_0 = v_t_2419;
        V t_1 = heff_intAdd(v_at_241, MK_INT(1LL));
        V t_2 = v_t_2429;
        V t_3 = v_b_246;
        v_al_240 = t_0;
        v_at_241 = t_1;
        v_seen_242 = t_2;
        v_e_243 = t_3;
        goto top;
      }
    }
  }
  case TAG_ESet: {
    V v_xs_2430 = heff_field(v_e_243, 0);
    V v_a_2431 = heff_field(v_e_243, 1);
    V v_b_2432 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_2433 = (g_heff_2ecompile_2erunes_2eanyReads(heff_dup(v_al_240), heff_dup(v_at_241), heff_dup(v_a_2431)));
    V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2431), NTAG(TAG_Nil)});
    V v_t_2435 = (g_heff_2ecompile_2erunes_2esureW(heff_dup(v_al_240), heff_dup(v_at_241), v_t_2433, v_t_2434));
    V v_rs_2436 = (g_heff_2ecompile_2eir_2eappendI(v_t_2435, heff_dup(v_seen_242)));
    HeffT2 v_t_2440 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam3, 1, 1, (V[]){heff_dup(v_rs_2436)}), v_rs_2436));
    {
      V v_field_2442 = v_t_2440.f[1];
      int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
      if ((v_tag_2441 == ((int64_t)0ULL))) {
        heff_drop(v_al_240);
        heff_drop(v_at_241);
        heff_drop(v_seen_242);
        heff_drop(v_xs_2430);
        heff_drop(v_a_2431);
        heff_drop(v_b_2432);
        V v_r_2443 = v_field_2442;
        V v_r_2444 = ({ V a_0 = v_rs_2436; V a_1 = v_r_2443; V r_ = (g_heff_2ecompile_2erunes_2efirstSure(a_0, a_1)); heff_drop(v_rs_2436); r_; });
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_r_2444}});
      } else {
        heff_drop(v_rs_2436);
        heff_drop(v_field_2442);
        V v_t_2445 = (g_list_2efoldl_24s1045622919x1125142156(heff_dup(v_al_240), v_xs_2430));
        V v_t_2446 = (g_heff_2ecompile_2erunes_2eanyReads(heff_dup(v_al_240), heff_dup(v_at_241), heff_dup(v_a_2431)));
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2431, NTAG(TAG_Nil)});
        V v_t_2448 = (g_heff_2ecompile_2erunes_2esureW(v_al_240, heff_dup(v_at_241), v_t_2446, v_t_2447));
        V v_rs_2449 = (g_heff_2ecompile_2eir_2eappendI(v_t_2448, v_seen_242));
        V v_t_2454 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam4, 1, 1, (V[]){v_xs_2430}), v_rs_2449));
        V t_0 = v_t_2445;
        V t_1 = heff_intAdd(v_at_241, MK_INT(1LL));
        V t_2 = v_t_2454;
        V t_3 = v_b_2432;
        v_al_240 = t_0;
        v_at_241 = t_1;
        v_seen_242 = t_2;
        v_e_243 = t_3;
        goto top;
      }
    }
  }
  default: {
    V v_t_2455 = (g_heff_2ecompile_2erunes_2eanyReads(heff_dup(v_al_240), heff_dup(v_at_241), heff_dup(v_e_243)));
    V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    V v_t_2457 = (g_heff_2ecompile_2erunes_2esureW(v_al_240, v_at_241, v_t_2455, v_t_2456));
    V v_rs_2458 = (g_heff_2ecompile_2eir_2eappendI(v_t_2457, v_seen_242));
    HeffT2 v_t_2462 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam6, 1, 1, (V[]){heff_dup(v_rs_2458)}), v_rs_2458));
    {
      V v_field_2464 = v_t_2462.f[1];
      int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
      if ((v_tag_2463 == ((int64_t)0ULL))) {
        V v_r_2465 = v_field_2464;
        V v_f_2466 = ({ V a_0 = v_rs_2458; V a_1 = v_r_2465; V r_ = (g_heff_2ecompile_2erunes_2efirstSure(a_0, a_1)); heff_drop(v_rs_2458); r_; });
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2466}});
      } else {
        heff_drop(v_rs_2458);
        heff_drop(v_field_2464);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  }
}
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam0(V self, V *args) {
  V v_r_2411 = args[0];
  V v_rs_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_dup(heff_rfield(v_r_2411, 5));
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    V v_r_2413 = (g_heff_2ecompile_2erunes_2efirstSure(v_rs_2410, v_r_2411));
    return ({ V a_0 = v_r_2413; V a_1 = v_rs_2410; V r_ = (g_list_2eany_24s1806601701x937560846(a_0, a_1)); heff_drop(v_rs_2410); r_; });
  } else {
    heff_drop_rec(v_r_2411, 6);
    heff_drop(v_rs_2410);
    heff_drop(v_t_2412);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_r_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_x_2426}));
  return ({ V a_0 = v_t_2427; V b_1 = heff_get_n(v_r_2424, 3, 6); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam1(V self, V *args) {
  V v_r_2424 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
  V v_x1_2428 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam2, 1, 1, (V[]){v_r_2424}); V a_1 = v_t_2425; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_2425, 2); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2428) == NTAG(TAG_True)));
  heff_drop(v_x1_2428);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam3(V self, V *args) {
  V v_r_2437 = args[0];
  V v_rs_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438 = heff_dup(heff_rfield(v_r_2437, 5));
  if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
    heff_drop(v_t_2438);
    V v_r_2439 = (g_heff_2ecompile_2erunes_2efirstSure(v_rs_2436, v_r_2437));
    return ({ V a_0 = v_r_2439; V a_1 = v_rs_2436; V r_ = (g_list_2eany_24s1806601701x937560846(a_0, a_1)); heff_drop(v_rs_2436); r_; });
  } else {
    heff_drop_rec(v_r_2437, 6);
    heff_drop(v_rs_2436);
    heff_drop(v_t_2438);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam5(V self, V *args) {
  V v_x_2451 = args[0];
  V v_r_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2452 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_x_2451}));
  return ({ V a_0 = v_t_2452; V b_1 = heff_get_n(v_r_2450, 3, 6); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam4(V self, V *args) {
  V v_r_2450 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2453 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam5, 1, 1, (V[]){v_r_2450}); V a_1 = v_xs_2430; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2430); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2453) == NTAG(TAG_True)));
  heff_drop(v_x1_2453);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erunes_2epairAlong_24cpr_lam6(V self, V *args) {
  V v_r_2459 = args[0];
  V v_rs_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2460 = heff_dup(heff_rfield(v_r_2459, 5));
  if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
    heff_drop(v_t_2460);
    V v_r_2461 = (g_heff_2ecompile_2erunes_2efirstSure(v_rs_2458, v_r_2459));
    return ({ V a_0 = v_r_2461; V a_1 = v_rs_2458; V r_ = (g_list_2eany_24s1806601701x937560846(a_0, a_1)); heff_drop(v_rs_2458); r_; });
  } else {
    heff_drop_rec(v_r_2459, 6);
    heff_drop(v_rs_2458);
    heff_drop(v_t_2460);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2erunes_2enamed_lam1(V self, V *args);
V g_heff_2ecompile_2erunes_2enamed_lam0(V self, V *args);
Clo g_heff_2ecompile_2erunes_2enamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2enamed_entry, 3, 0};

V g_heff_2ecompile_2erunes_2enamed(V v_o_240, V v_al_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_ELam: {
    V v_e1_243 = heff_field(v_e_242, 0);
    V v_b_244 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop_rec(v_o_240, 4);
    heff_drop(v_al_241);
    return heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_e1_243, v_b_244});
  }
  case TAG_EPrimCall: {
    V v_e1_245 = heff_field(v_e_242, 0);
    V v_argv_246 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_247 = (g_heff_2ecompile_2erunes_2ereadOf_24cpr(heff_dup(v_al_241), NTAG(TAG_False), MK_INT(0LL), v_e1_245, heff_dup(v_argv_246)));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_r_2410 = v_field_249;
        V v_key_2411 = heff_take_field(v_r_2410, 1);
        V v_rune_2412 = heff_get_n(v_r_2410, 0, 6);
        if (heff_strEq_c(v_key_2411, heff_dup(heff_rfield(v_o_240, 0)))) {
          heff_drop(v_al_241);
          heff_drop(v_e1_245);
          heff_drop(v_argv_246);
          heff_drop_cell(v_ru_24e_242_24EPrimCall, 2);
          V v_t_2413;
          if ((heff_dup(v_rune_2412) == NTAG(TAG_True))) {
            heff_drop(v_rune_2412);
            v_t_2413 = heff_get_n(v_o_240, 2, 4);
          } else {
            heff_drop(v_rune_2412);
            v_t_2413 = heff_get_n(v_o_240, 3, 4);
          }
          return heff_tag_n(TAG_EVar, 1, (V[]){v_t_2413});
        } else {
          heff_drop(v_rune_2412);
          V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erunes_2enamed_clo), 2, (V[]){v_o_240, v_al_241}));
          V v_t_2415 = (g_list_2emap(v_t_2414, v_argv_246));
          return heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_e1_245, v_t_2415});
        }
      } else {
        heff_drop(v_field_249);
        V v_t_2416 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erunes_2enamed_clo), 2, (V[]){v_o_240, v_al_241}));
        V v_t_2417 = (g_list_2emap(v_t_2416, v_argv_246));
        return heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_e1_245, v_t_2417});
      }
    }
  }
  case TAG_EFix: {
    V v_x_2418 = heff_field(v_e_242, 0);
    V v_b_2419 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EFix = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop_rec(v_o_240, 4);
    heff_drop(v_al_241);
    return heff_tag_at_n(v_ru_24e_242_24EFix, TAG_EFix, 2, (V[]){v_x_2418, v_b_2419});
  }
  default: {
    return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2erunes_2enamed_lam0, 2, 2, (V[]){v_o_240, v_al_241}), v_e_242));
  }
  }
}
V g_heff_2ecompile_2erunes_2enamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erunes_2enamed(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erunes_2enamed_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_x_2422}));
  return ({ V a_0 = v_t_2423; V b_1 = heff_get_n(v_o_240, 1, 4); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2ecompile_2erunes_2enamed_lam0(V self, V *args) {
  V v_xs_2420 = args[0];
  V v_p_2421 = args[1];
  V v_o_240 = heff_env(self)[0];
  V v_al_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erunes_2enamed_lam1, 1, 1, (V[]){heff_dup(v_o_240)}); V a_1 = v_xs_2420; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2420); r_; });
  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
    heff_drop_rec(v_o_240, 4);
    heff_drop(v_al_241);
    heff_drop(v_t_2424);
    return v_p_2421;
  } else {
    heff_drop(v_t_2424);
    return (g_heff_2ecompile_2erunes_2enamed(v_o_240, v_al_241, v_p_2421));
  }
}
V g_heff_2ecompile_2erunes_2enamedAlong_lam0(V self, V *args);
V g_heff_2ecompile_2erunes_2enamedAlong_lam1(V self, V *args);
Clo g_heff_2ecompile_2erunes_2enamedAlong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2enamedAlong_entry, 3, 0};

V g_heff_2ecompile_2erunes_2enamedAlong(V v_o_240, V v_al_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_ELet: {
    V v_x_243 = heff_field(v_e_242, 0);
    V v_a_244 = heff_field(v_e_242, 1);
    V v_b_245 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_o_246 = heff_dup(v_o_240);
    V v_key_247 = heff_take_field(v_o_246, 0);
    V v_runeName_248 = heff_take_field(v_o_246, 2);
    V v_widthName_249 = heff_get_n(v_o_246, 3, 4);
    V v_al_2410 = heff_dup(v_al_241);
    V v_e_2411 = heff_dup(v_a_244);
    V v_x1_2458;
    switch (heff_tag_of(v_e_2411)) {
    case TAG_EVar: {
      heff_take_n(v_e_2411, 0ULL, 1);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e_2411, 0ULL, 1);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_e_2411, 0ULL, 2);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_e_2411, 0ULL, 2);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_e_2411, 0ULL, 3);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_e_2411, 0ULL, 2);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_e_2411, 0ULL, 4);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_e_2411, 0ULL, 3);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_e_2411, 0ULL, 2);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_e_2411, 0ULL, 1);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      V v_p_2433 = heff_field(v_e_2411, 0);
      V v_argv_2434 = heff_field(v_e_2411, 1);
      heff_take_n(v_e_2411, 3ULL, 2);
      HeffT2 v_t_2435 = ({ V a_0 = v_al_2410; V a_1 = NTAG(TAG_False); V a_2 = MK_INT(0LL); V a_3 = v_p_2433; V a_4 = v_argv_2434; HeffT2 r_ = (g_heff_2ecompile_2erunes_2ereadOf_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_p_2433); r_; });
      {
        V v_field_2437 = v_t_2435.f[1];
        int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
        if ((v_tag_2436 == ((int64_t)0ULL))) {
          V v_r_2438 = v_field_2437;
          V v_key_2439 = heff_take_field(v_r_2438, 1);
          V v_rune_2440 = heff_get_n(v_r_2438, 0, 6);
          if (heff_strEq_c(v_key_2439, v_key_247)) {
            V v_t_2441;
            if ((heff_dup(v_rune_2440) == NTAG(TAG_True))) {
              heff_drop(v_widthName_249);
              heff_drop(v_rune_2440);
              v_t_2441 = v_runeName_248;
            } else {
              heff_drop(v_runeName_248);
              heff_drop(v_rune_2440);
              v_t_2441 = v_widthName_249;
            }
            v_x1_2458 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2441});
          } else {
            heff_drop(v_runeName_248);
            heff_drop(v_widthName_249);
            heff_drop(v_rune_2440);
            v_x1_2458 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_key_247);
          heff_drop(v_runeName_248);
          heff_drop(v_widthName_249);
          heff_drop(v_field_2437);
          v_x1_2458 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_e_2411, 0ULL, 2);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_e_2411, 0ULL, 1);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_e_2411, 0ULL, 1);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_e_2411, 0ULL, 1);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_e_2411, 0ULL, 1);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_e_2411, 0ULL, 2);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e_2411, 0ULL, 1);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_e_2411, 0ULL, 1);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_e_2411, 0ULL, 3);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_e_2411, 0ULL, 1);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_e_2411, 0ULL, 2);
      heff_drop(v_key_247);
      heff_drop(v_runeName_248);
      heff_drop(v_widthName_249);
      heff_drop(v_al_2410);
      v_x1_2458 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_2411);
    }
    V v_a_2459 = (g_heff_2ecompile_2erunes_2enamed(heff_dup(v_o_240), heff_dup(v_al_241), heff_dup(v_a_244)));
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
    V v_t_2463 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erunes_2enamedAlong_lam0, 1, 1, (V[]){heff_dup(v_o_240)}); V a_1 = v_t_2460; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_2460, 2); r_; });
    V v_b_2465;
    if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
      heff_drop_rec(v_o_240, 4);
      heff_drop(v_al_241);
      heff_drop(v_a_244);
      heff_drop(v_t_2463);
      v_b_2465 = v_b_245;
    } else {
      heff_drop(v_t_2463);
      V v_t_2464 = ({ V a_0 = v_al_241; V a_1 = heff_dup(v_x_243); V a_2 = v_a_244; V r_ = (g_heff_2ecompile_2erunes_2ealiasing(a_0, a_1, a_2)); heff_drop(v_al_241); heff_drop(v_a_244); r_; });
      v_b_2465 = (g_heff_2ecompile_2erunes_2enamedAlong(v_o_240, v_t_2464, v_b_245));
    }
    switch (heff_tag_of(v_x1_2458)) {
    case TAG_Nothing: {
      return heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_243, v_a_2459, v_b_2465});
    }
    case TAG_Just: {
      V v_y_2466 = heff_field(v_x1_2458, 0);
      heff_take_n(v_x1_2458, 1ULL, 1);
      heff_drop_cell(v_ru_24e_242_24ELet, 3);
      heff_drop(v_a_2459);
      return ({ V b_0 = MK_INT(1LL); V a_1 = v_x_243; V a_2 = v_y_2466; V a_3 = v_b_2465; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_x_243); r_; });
    }
    default: return heff_nomatch(v_x1_2458);
    }
  }
  case TAG_ESet: {
    V v_xs_2467 = heff_field(v_e_242, 0);
    V v_a_2468 = heff_field(v_e_242, 1);
    V v_b_2469 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ESet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2470 = (g_heff_2ecompile_2erunes_2enamed(heff_dup(v_o_240), heff_dup(v_al_241), v_a_2468));
    V v_t_2473 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2erunes_2enamedAlong_lam1, 1, 1, (V[]){heff_dup(v_o_240)}), v_xs_2467));
    V v_t_2475;
    if ((heff_dup(v_t_2473) == NTAG(TAG_True))) {
      heff_drop_rec(v_o_240, 4);
      heff_drop(v_al_241);
      heff_drop(v_t_2473);
      v_t_2475 = v_b_2469;
    } else {
      heff_drop(v_t_2473);
      V v_t_2474 = (g_list_2efoldl_24s1045622919x1125142156(v_al_241, v_xs_2467));
      v_t_2475 = (g_heff_2ecompile_2erunes_2enamedAlong(v_o_240, v_t_2474, v_b_2469));
    }
    return heff_tag_at_n(v_ru_24e_242_24ESet, TAG_ESet, 3, (V[]){v_xs_2467, v_t_2470, v_t_2475});
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2erunes_2enamed(v_o_240, v_al_241, v_e_242);
  }
  }
}
V g_heff_2ecompile_2erunes_2enamedAlong_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erunes_2enamedAlong(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erunes_2enamedAlong_lam0(V self, V *args) {
  V v_x_2461 = args[0];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2462 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_x_2461}));
  return ({ V a_0 = v_t_2462; V b_1 = heff_get_n(v_o_240, 1, 4); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2ecompile_2erunes_2enamedAlong_lam1(V self, V *args) {
  V v_x_2471 = args[0];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2472 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_x_2471}));
  return ({ V a_0 = v_t_2472; V b_1 = heff_get_n(v_o_240, 1, 4); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2ecompile_2erunes_2ereadOnceAt_str0, 4, "#_,_");
HEFF_LIT(g_heff_2ecompile_2erunes_2ereadOnceAt_str1, 4, "#_,_");
HEFF_LIT(g_heff_2ecompile_2erunes_2ereadOnceAt_str2, 4, "#_,_");
V g_heff_2ecompile_2erunes_2ereadOnceAt_lam0(V self, V *args);
Clo g_heff_2ecompile_2erunes_2ereadOnceAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2ereadOnceAt_entry, 6, 0};

V g_heff_2ecompile_2erunes_2ereadOnceAt(V v_o_240, V v_al_241, V v_args_242, V v_t_243, V v_at_244, V v_e_245) {
top: ;
  switch (heff_tag_of(v_e_245)) {
  case TAG_ELet: {
    V v_x_246 = heff_field(v_e_245, 0);
    V v_a_247 = heff_field(v_e_245, 1);
    V v_b_248 = heff_field(v_e_245, 2);
    V v_ru_24e_245_24ELet = heff_take_reuse_n(v_e_245, 7ULL, 3);
    if (heff_intLt_c_lent(MK_INT(0LL), v_at_244, 1)) {
      V v_cell_249 = heff_tag_at_n(v_ru_24e_245_24ELet, TAG_ELet, 3, (V[]){heff_dup(v_x_246), heff_dup(v_a_247), heff_hole()});
      V v_t_2410 = ({ V a_0 = v_al_241; V a_1 = v_x_246; V a_2 = v_a_247; V r_ = (g_heff_2ecompile_2erunes_2ealiasing(a_0, a_1, a_2)); heff_drop(v_al_241); heff_drop(v_a_247); r_; });
      V v_u_2411 = (g_heff_2ecompile_2erunes_2ereadOnceAt_24dps(v_o_240, v_t_2410, v_args_242, v_t_243, heff_intSub(v_at_244, MK_INT(1LL)), v_b_248, heff_dup(v_cell_249)));
      heff_drop(v_u_2411);
      return v_cell_249;
    } else {
      heff_drop(v_at_244);
      V v_t_2412 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrRuneDecode), v_args_242});
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_240, 3)), NTAG(TAG_Nil)});
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_240, 2)), v_t_2413});
      V v_t_2415 = (g_heff_2ecompile_2erunes_2enamedAlong(v_o_240, v_al_241, heff_tag_at_n(v_ru_24e_245_24ELet, TAG_ELet, 3, (V[]){v_x_246, v_a_247, v_b_248})));
      V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2erunes_2ereadOnceAt_str0), v_t_2414, v_t_2415}), NTAG(TAG_Nil)});
      V v_t_2417 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_243)}), v_t_2416});
      return heff_tag_n(TAG_ELet, 3, (V[]){v_t_243, v_t_2412, v_t_2417});
    }
  }
  case TAG_ESet: {
    V v_xs_2418 = heff_field(v_e_245, 0);
    V v_a_2419 = heff_field(v_e_245, 1);
    V v_b_2420 = heff_field(v_e_245, 2);
    V v_ru_24e_245_24ESet = heff_take_reuse_n(v_e_245, 7ULL, 3);
    if (heff_intLt_c_lent(MK_INT(0LL), v_at_244, 1)) {
      V v_cell_2421 = heff_tag_at_n(v_ru_24e_245_24ESet, TAG_ESet, 3, (V[]){heff_dup(v_xs_2418), v_a_2419, heff_hole()});
      V v_t_2422 = ({ V a_0 = v_al_241; V a_1 = v_xs_2418; V r_ = (g_list_2efoldl_24s1045622919x1125142156(a_0, a_1)); heff_drop(v_xs_2418); r_; });
      V v_u_2423 = (g_heff_2ecompile_2erunes_2ereadOnceAt_24dps(v_o_240, v_t_2422, v_args_242, v_t_243, heff_intSub(v_at_244, MK_INT(1LL)), v_b_2420, heff_dup(v_cell_2421)));
      heff_drop(v_u_2423);
      return v_cell_2421;
    } else {
      heff_drop(v_at_244);
      V v_t_2424 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrRuneDecode), v_args_242});
      V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_240, 3)), NTAG(TAG_Nil)});
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_240, 2)), v_t_2425});
      V v_t_2427 = (g_heff_2ecompile_2erunes_2enamed(heff_dup(v_o_240), heff_dup(v_al_241), v_a_2419));
      V v_t_2430 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2erunes_2ereadOnceAt_lam0, 1, 1, (V[]){heff_dup(v_o_240)}), v_xs_2418));
      V v_t_2432;
      if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
        heff_drop_rec(v_o_240, 4);
        heff_drop(v_al_241);
        heff_drop(v_t_2430);
        v_t_2432 = v_b_2420;
      } else {
        heff_drop(v_t_2430);
        V v_t_2431 = (g_list_2efoldl_24s1045622919x1125142156(v_al_241, v_xs_2418));
        v_t_2432 = (g_heff_2ecompile_2erunes_2enamedAlong(v_o_240, v_t_2431, v_b_2420));
      }
      V v_t_2433 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2erunes_2ereadOnceAt_str1), v_t_2426, heff_tag_at_n(v_ru_24e_245_24ESet, TAG_ESet, 3, (V[]){v_xs_2418, v_t_2427, v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
      V v_t_2435 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_243)}), v_t_2434});
      return heff_tag_n(TAG_ELet, 3, (V[]){v_t_243, v_t_2424, v_t_2435});
    }
  }
  default: {
    heff_drop(v_at_244);
    V v_t_2436 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrRuneDecode), v_args_242});
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_240, 3)), NTAG(TAG_Nil)});
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_240, 2)), v_t_2437});
    V v_t_2439 = (g_heff_2ecompile_2erunes_2enamedAlong(v_o_240, v_al_241, v_e_245));
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2erunes_2ereadOnceAt_str2), v_t_2438, v_t_2439}), NTAG(TAG_Nil)});
    V v_t_2441 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_243)}), v_t_2440});
    return heff_tag_n(TAG_ELet, 3, (V[]){v_t_243, v_t_2436, v_t_2441});
  }
  }
}
V g_heff_2ecompile_2erunes_2ereadOnceAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erunes_2ereadOnceAt(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2erunes_2ereadOnceAt_lam0(V self, V *args) {
  V v_x_2428 = args[0];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_x_2428}));
  return ({ V a_0 = v_t_2429; V b_1 = heff_get_n(v_o_240, 1, 4); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_str0, 4, "#_,_");
HEFF_LIT(g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_str1, 4, "#_,_");
HEFF_LIT(g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_str2, 4, "#_,_");
V g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_entry, 7, 0};

V g_heff_2ecompile_2erunes_2ereadOnceAt_24dps(V v_o_240, V v_al_241, V v_args_242, V v_t_243, V v_at_244, V v_e_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_e_245)) {
  case TAG_ELet: {
    V v_x_247 = heff_field(v_e_245, 0);
    V v_a_248 = heff_field(v_e_245, 1);
    V v_b_249 = heff_field(v_e_245, 2);
    V v_ru_24e_245_24ELet = heff_take_reuse_n(v_e_245, 7ULL, 3);
    if (heff_intLt_c_lent(MK_INT(0LL), v_at_244, 1)) {
      V v_cell_2410 = heff_tag_at_n(v_ru_24e_245_24ELet, TAG_ELet, 3, (V[]){heff_dup(v_x_247), heff_dup(v_a_248), heff_hole()});
      V v_u_2411 = heff_setField(v_d_246, MK_INT(2LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V v_t_2412 = ({ V a_0 = v_al_241; V a_1 = v_x_247; V a_2 = v_a_248; V r_ = (g_heff_2ecompile_2erunes_2ealiasing(a_0, a_1, a_2)); heff_drop(v_al_241); heff_drop(v_a_248); r_; });
      V t_0 = v_o_240;
      V t_1 = v_t_2412;
      V t_2 = v_args_242;
      V t_3 = v_t_243;
      V t_4 = heff_intSub(v_at_244, MK_INT(1LL));
      V t_5 = v_b_249;
      V t_6 = v_cell_2410;
      v_o_240 = t_0;
      v_al_241 = t_1;
      v_args_242 = t_2;
      v_t_243 = t_3;
      v_at_244 = t_4;
      v_e_245 = t_5;
      v_d_246 = t_6;
      goto top;
    } else {
      heff_drop(v_at_244);
      V v_t_2413 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrRuneDecode), v_args_242});
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_240, 3)), NTAG(TAG_Nil)});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_240, 2)), v_t_2414});
      V v_t_2416 = (g_heff_2ecompile_2erunes_2enamedAlong(v_o_240, v_al_241, heff_tag_at_n(v_ru_24e_245_24ELet, TAG_ELet, 3, (V[]){v_x_247, v_a_248, v_b_249})));
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_str0), v_t_2415, v_t_2416}), NTAG(TAG_Nil)});
      V v_t_2418 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_243)}), v_t_2417});
      return heff_setField(v_d_246, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_t_243, v_t_2413, v_t_2418}));
    }
  }
  case TAG_ESet: {
    V v_xs_2419 = heff_field(v_e_245, 0);
    V v_a_2420 = heff_field(v_e_245, 1);
    V v_b_2421 = heff_field(v_e_245, 2);
    V v_ru_24e_245_24ESet = heff_take_reuse_n(v_e_245, 7ULL, 3);
    if (heff_intLt_c_lent(MK_INT(0LL), v_at_244, 1)) {
      V v_cell_2422 = heff_tag_at_n(v_ru_24e_245_24ESet, TAG_ESet, 3, (V[]){heff_dup(v_xs_2419), v_a_2420, heff_hole()});
      V v_u_2423 = heff_setField(v_d_246, MK_INT(2LL), heff_dup(v_cell_2422));
      heff_drop(v_u_2423);
      V v_t_2424 = ({ V a_0 = v_al_241; V a_1 = v_xs_2419; V r_ = (g_list_2efoldl_24s1045622919x1125142156(a_0, a_1)); heff_drop(v_xs_2419); r_; });
      V t_0 = v_o_240;
      V t_1 = v_t_2424;
      V t_2 = v_args_242;
      V t_3 = v_t_243;
      V t_4 = heff_intSub(v_at_244, MK_INT(1LL));
      V t_5 = v_b_2421;
      V t_6 = v_cell_2422;
      v_o_240 = t_0;
      v_al_241 = t_1;
      v_args_242 = t_2;
      v_t_243 = t_3;
      v_at_244 = t_4;
      v_e_245 = t_5;
      v_d_246 = t_6;
      goto top;
    } else {
      heff_drop(v_at_244);
      V v_t_2425 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrRuneDecode), v_args_242});
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_240, 3)), NTAG(TAG_Nil)});
      V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_240, 2)), v_t_2426});
      V v_t_2428 = (g_heff_2ecompile_2erunes_2enamed(heff_dup(v_o_240), heff_dup(v_al_241), v_a_2420));
      V v_t_2431 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_lam0, 1, 1, (V[]){heff_dup(v_o_240)}), v_xs_2419));
      V v_t_2433;
      if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
        heff_drop_rec(v_o_240, 4);
        heff_drop(v_al_241);
        heff_drop(v_t_2431);
        v_t_2433 = v_b_2421;
      } else {
        heff_drop(v_t_2431);
        V v_t_2432 = (g_list_2efoldl_24s1045622919x1125142156(v_al_241, v_xs_2419));
        v_t_2433 = (g_heff_2ecompile_2erunes_2enamedAlong(v_o_240, v_t_2432, v_b_2421));
      }
      V v_t_2434 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_str1), v_t_2427, heff_tag_at_n(v_ru_24e_245_24ESet, TAG_ESet, 3, (V[]){v_xs_2419, v_t_2428, v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
      V v_t_2436 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_243)}), v_t_2435});
      return heff_setField(v_d_246, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_t_243, v_t_2425, v_t_2436}));
    }
  }
  default: {
    heff_drop(v_at_244);
    V v_t_2437 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrRuneDecode), v_args_242});
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_240, 3)), NTAG(TAG_Nil)});
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_240, 2)), v_t_2438});
    V v_t_2440 = (g_heff_2ecompile_2erunes_2enamedAlong(v_o_240, v_al_241, v_e_245));
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_str2), v_t_2439, v_t_2440}), NTAG(TAG_Nil)});
    V v_t_2442 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_243)}), v_t_2441});
    return heff_setField(v_d_246, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_t_243, v_t_2437, v_t_2442}));
  }
  }
}
V g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erunes_2ereadOnceAt_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2erunes_2ereadOnceAt_24dps_lam0(V self, V *args) {
  V v_x_2429 = args[0];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_x_2429}));
  return ({ V a_0 = v_t_2430; V b_1 = heff_get_n(v_o_240, 1, 4); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2ecompile_2erunes_2ealongOf_lam0(V self, V *args);
V g_heff_2ecompile_2erunes_2ealongOf_lam1(V self, V *args);
V g_heff_2ecompile_2erunes_2ealongOf_lam2(V self, V *args);
Clo g_heff_2ecompile_2erunes_2ealongOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2ealongOf_entry, 2, 0};

V g_heff_2ecompile_2erunes_2ealongOf(V v_go_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_ELet: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_a_243 = heff_field(v_e_241, 1);
    V v_b_244 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_243}));
    return heff_clo_n(g_heff_2ecompile_2erunes_2ealongOf_lam0, 1, 4, (V[]){v_m_245, v_go_240, v_b_244, v_x_242});
  }
  case TAG_ESet: {
    V v_xs_2414 = heff_field(v_e_241, 0);
    V v_a_2415 = heff_field(v_e_241, 1);
    V v_b_2416 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2417 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_2415}));
    return heff_clo_n(g_heff_2ecompile_2erunes_2ealongOf_lam1, 1, 4, (V[]){v_m_2417, v_go_240, v_b_2416, v_xs_2414});
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(heff_clo_n(g_heff_2ecompile_2erunes_2ealongOf_lam2, 1, 1, (V[]){v_go_240}), v_e_241);
  }
  }
}
V g_heff_2ecompile_2erunes_2ealongOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erunes_2ealongOf(a[0], a[1]);
}
V g_heff_2ecompile_2erunes_2ealongOf_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_b_244 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2erunes_2ealongOf(v_go_240, v_b_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_242, v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2erunes_2ealongOf_lam1(V self, V *args) {
  V v_n_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_b_2416 = heff_env(self)[2];
  V v_xs_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_n_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    V v_m_2422 = (g_heff_2ecompile_2erunes_2ealongOf(v_go_240, v_b_2416));
    V v_x2_2423 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_n_2421}));
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_n_2425 = heff_field(v_x2_2423, 1);
      heff_take_n(v_x2_2423, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2414, v_x_2420, v_x_2424}), v_n_2425});
    }
    default: return heff_nomatch(v_x2_2423);
    }
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2erunes_2ealongOf_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2426);
  return v_go_240;
}
HEFF_LIT(g_heff_2ecompile_2erunes_2eexprOf_str0, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2erunes_2eexprOf_str1, 5, "rune$");
HEFF_LIT(g_heff_2ecompile_2erunes_2eexprOf_str2, 6, "width$");
V g_heff_2ecompile_2erunes_2eexprOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2erunes_2eexprOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2eexprOf_entry, 1, 0};

V g_heff_2ecompile_2erunes_2eexprOf(V v_e_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2erunes_2epairAlong_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_e_240)));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_r_244 = v_field_243;
      V v_key_245 = heff_take_field(v_r_244, 1);
      V v_vars_246 = heff_take_field(v_r_244, 3);
      V v_args_247 = heff_take_field(v_r_244, 2);
      V v_at_248 = heff_get_n(v_r_244, 4, 6);
      return heff_clo_n(g_heff_2ecompile_2erunes_2eexprOf_lam0, 1, 5, (V[]){v_key_245, v_vars_246, v_args_247, v_at_248, v_e_240});
    } else {
      heff_drop(v_field_243);
      return (g_heff_2ecompile_2erunes_2ealongOf(((V)&g_heff_2ecompile_2erunes_2eexprOf_clo), v_e_240));
    }
  }
}
V g_heff_2ecompile_2erunes_2eexprOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erunes_2eexprOf(a[0]);
}
V g_heff_2ecompile_2erunes_2eexprOf_lam0(V self, V *args) {
  V v_n_249 = args[0];
  V v_key_245 = heff_env(self)[0];
  V v_vars_246 = heff_env(self)[1];
  V v_args_247 = heff_env(self)[2];
  V v_at_248 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2410 = heff_strAppend(((V)&g_heff_2ecompile_2erunes_2eexprOf_str0), heff_intShow(heff_dup(v_n_249)));
  V v_n_2411 = heff_intAdd(v_n_249, MK_INT(1LL));
  V v_x_2412 = heff_strAppend(((V)&g_heff_2ecompile_2erunes_2eexprOf_str1), heff_intShow(heff_dup(v_n_2411)));
  V v_n_2413 = heff_intAdd(v_n_2411, MK_INT(1LL));
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2erunes_2eexprOf_str2), heff_intShow(heff_dup(v_n_2413)));
  V v_t_2415 = (g_heff_2ecompile_2erunes_2ereadOnceAt(heff_rec_n(4, shape_key__vars__runeName__widthName, (V[]){v_key_245, v_vars_246, v_x_2412, v_t_2414}), heff_dup(g_std_2eordmap_2eempty_get()), v_args_247, v_x_2410, v_at_248, v_e_240));
  V v_t_2416 = (g_heff_2ecompile_2erunes_2eexprOf(v_t_2415));
  V f_ = v_t_2416;
  args[0] = heff_intAdd(v_n_2413, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ecompile_2erunes_2ereads_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erunes_2ereads_str1, 0, "");
Clo g_heff_2ecompile_2erunes_2ereads_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2ereads_entry, 1, 0};

V g_heff_2ecompile_2erunes_2ereads(V v_e_240) {
top: ;
  return (g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle(NTAG(TAG_Enter_24heff_2ecompile_2erunes_2ereads), ((V)&g_heff_2ecompile_2erunes_2ereads_str0), ((V)&g_heff_2ecompile_2erunes_2ereads_str1), v_e_240));
}
V g_heff_2ecompile_2erunes_2ereads_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erunes_2ereads(a[0]);
}
V g_heff_2ecompile_2erunes_2edefOf_lam0(V self, V *args);
V g_heff_2ecompile_2erunes_2edefOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2erunes_2edefOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erunes_2edefOf_entry, 1, 0};

V g_heff_2ecompile_2erunes_2edefOf(V v_d_240) {
top: ;
  V v_t_241 = (g_heff_2ecompile_2erunes_2ereads(heff_dup(heff_rfield(v_d_240, 2))));
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    V v_m_242 = (g_heff_2ecompile_2erunes_2eexprOf(heff_dup(heff_rfield(v_d_240, 2))));
    return heff_clo_n(g_heff_2ecompile_2erunes_2edefOf_lam0, 1, 2, (V[]){v_m_242, v_d_240});
  } else {
    heff_drop(v_t_241);
    return heff_clo_n(g_heff_2ecompile_2erunes_2edefOf_lam1, 1, 1, (V[]){v_d_240});
  }
}
V g_heff_2ecompile_2erunes_2edefOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erunes_2edefOf(a[0]);
}
V g_heff_2ecompile_2erunes_2edefOf_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_d_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_244 = heff_tr(heff_call(v_m_242, 1, (V[]){v_n_243}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_n_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = ({ V rv_2 = v_x_245; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_t_247, v_n_246});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2erunes_2edefOf_lam1(V self, V *args) {
  V v_n_248 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_n_248});
}