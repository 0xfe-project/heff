// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkTry 8097
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_end 310101
#define LBL_guard 300063423
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_stmts 311127493
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s112965014x579570295_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1754932173x1305177089_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s2006690287x151588326_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s301034265x1732874986_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eannLamOf(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo;
V g_heff_2esyntax_2epresyntax_2ewithScopeOf(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithScopeOf_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epatNames_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2epatNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatNames_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epatNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_243, ((V)&g_heff_2esyntax_2epresyntax_2epatNames_str0), 2)) {
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        heff_drop(v_x_243);
        return NTAG(TAG_Nil);
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_247 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_247));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_248); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2411 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2411));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2412); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2418 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2418));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2419); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2421 = heff_field(v_x11_241, 0);
      V v_q_2423 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_cell_2424 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2421, heff_hole()});
      V v_u_2425 = (g_heff_2esyntax_2epresyntax_2epatNames_24dps(v_q_2423, heff_dup(v_cell_2424)));
      heff_drop(v_u_2425);
      return v_cell_2424;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatNames(a[0]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_dup(heff_field(v_x3_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_x3_241, 1));
    switch (heff_tag_of(v_x31_242)) {
    case TAG_EVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EBinary: {
      V v_segs_2410 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EBinary = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      HeffT2 v_t_2411 = (g_heff_2esyntax_2epresyntax_2eaccList_24s2006690287x151588326_24cpr(v_st_240, v_segs_2410));
      {
        V v_field_2412 = v_t_2411.f[0];
        V v_field_2413 = v_t_2411.f[1];
        V v_x_2414 = v_field_2412;
        V v_y_2415 = v_field_2413;
        V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EBinary, TAG_EBinary, 1, (V[]){v_y_2415}), v_sp_243});
        return ((HeffT2){{v_x_2414, v_t_2416}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EApp: {
      V v_h_2419 = heff_field(v_x31_242, 0);
      V v_args_2420 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EApp = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_2421;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_2421 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_2421 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_h_2419)));
      }
      HeffT2 v_t_2422 = (g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(v_t_2421, v_args_2420));
      {
        V v_field_2423 = v_t_2422.f[0];
        V v_field_2424 = v_t_2422.f[1];
        V v_x_2425 = v_field_2423;
        V v_y_2426 = v_field_2424;
        V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EApp, TAG_EApp, 2, (V[]){v_h_2419, v_y_2426}), v_sp_243});
        return ((HeffT2){{v_x_2425, v_t_2427}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENamed: {
      V v_x_2429 = heff_field(v_x31_242, 0);
      V v_e_2430 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ENamed = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_2431;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_2431 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_2431 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_2430)));
      }
      V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENamed, TAG_ENamed, 2, (V[]){v_x_2429, v_e_2430}), v_sp_243});
      return ((HeffT2){{v_t_2431, v_t_2432}});
    }
    case TAG_EPi: {
      heff_take_n(v_x31_242, 0ULL, 2);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ELam: {
      V v_b_2435 = heff_field(v_x31_242, 0);
      V v_body_2436 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELam = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_2437;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_2437 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_2437 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_body_2436)));
      }
      V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELam, TAG_ELam, 2, (V[]){v_b_2435, v_body_2436}), v_sp_243});
      return ((HeffT2){{v_t_2437, v_t_2438}});
    }
    case TAG_EAnn: {
      V v_e_2439 = heff_field(v_x31_242, 0);
      V v_t_2440 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EAnn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_2441;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_2441 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_2441 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_2439)));
      }
      V v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAnn, TAG_EAnn, 2, (V[]){v_e_2439, v_t_2440}), v_sp_243});
      return ((HeffT2){{v_t_2441, v_t_2442}});
    }
    case TAG_ESpec: {
      V v_a_2443 = heff_field(v_x31_242, 0);
      V v_x_2444 = heff_field(v_x31_242, 1);
      V v_xsp_2445 = heff_field(v_x31_242, 2);
      V v_v_2446 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24ESpec = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      heff_drop_tag(v_x3_241, 2);
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_2443, v_x_2444, v_xsp_2445, v_v_2446}), v_sp_243});
        return ((HeffT2){{NTAG(TAG_True), v_t_2447}});
      } else {
        heff_drop(v_st_240);
        V v_t_2448 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_2443)));
        V v_t_2449;
        if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
          heff_drop(v_t_2448);
          v_t_2449 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_2448);
          v_t_2449 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_v_2446)));
        }
        V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_2443, v_x_2444, v_xsp_2445, v_v_2446}), v_sp_243});
        return ((HeffT2){{v_t_2449, v_t_2450}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EStruct: {
      V v_fs_2453 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EStruct = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      HeffT2 v_t_2454 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1754932173x1305177089_24cpr(v_st_240, v_fs_2453));
      {
        V v_field_2455 = v_t_2454.f[0];
        V v_field_2456 = v_t_2454.f[1];
        V v_x_2457 = v_field_2455;
        V v_y_2458 = v_field_2456;
        V v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EStruct, TAG_EStruct, 1, (V[]){v_y_2458}), v_sp_243});
        return ((HeffT2){{v_x_2457, v_t_2459}});
      }
    }
    case TAG_EUpdate: {
      V v_a_2460 = heff_field(v_x31_242, 0);
      V v_fs_2461 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EUpdate = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_2462;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_2462 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_2462 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_2460)));
      }
      HeffT2 v_t_2463 = (g_heff_2esyntax_2epresyntax_2eaccList_24s112965014x579570295_24cpr(v_t_2462, v_fs_2461));
      {
        V v_field_2464 = v_t_2463.f[0];
        V v_field_2465 = v_t_2463.f[1];
        V v_x_2466 = v_field_2464;
        V v_y_2467 = v_field_2465;
        V v_t_2468 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EUpdate, TAG_EUpdate, 2, (V[]){v_a_2460, v_y_2467}), v_sp_243});
        return ((HeffT2){{v_x_2466, v_t_2468}});
      }
    }
    case TAG_EMatch: {
      V v_s_2469 = heff_field(v_x31_242, 0);
      V v_alts_2470 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EMatch = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_2471;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_2471 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_2471 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_s_2469)));
      }
      HeffT2 v_t_2472 = (g_heff_2esyntax_2epresyntax_2eaccList_24s301034265x1732874986_24cpr(v_t_2471, v_alts_2470));
      {
        V v_field_2473 = v_t_2472.f[0];
        V v_field_2474 = v_t_2472.f[1];
        V v_x_2475 = v_field_2473;
        V v_y_2476 = v_field_2474;
        V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2469, v_y_2476}), v_sp_243});
        return ((HeffT2){{v_x_2475, v_t_2477}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_2478 = heff_field(v_x31_242, 0);
      V v_a_2479 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELetIn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        switch (heff_tag_of(v_a_2479)) {
        case TAG_At: {
          V v_x31_2480 = heff_field(v_a_2479, 0);
          V v_sp_2481 = heff_field(v_a_2479, 1);
          V v_ru_24a_2479_24At = heff_take_reuse_n(v_a_2479, 3ULL, 2);
          switch (heff_tag_of(v_x31_2480)) {
          case TAG_MkAlt: {
            V v_p_2482 = heff_field(v_x31_2480, 0);
            V v_e_2483 = heff_field(v_x31_2480, 1);
            V v_ru_24x31_2480_24MkAlt = heff_take_reuse_n(v_x31_2480, 3ULL, 2);
            V v_t_2484 = heff_tag_at_n(v_ru_24a_2479_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2482, v_e_2483}), v_sp_2481});
            V v_t_2485 = heff_tag_at_n(v_ru_24x31_2480_24MkAlt, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_2478, v_t_2484}), v_sp_243});
            return ((HeffT2){{NTAG(TAG_True), v_t_2485}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2480)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_a_2479)}});
        }
      } else {
        heff_drop(v_st_240);
        V v_t_2486 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_rhs_2478)));
        switch (heff_tag_of(v_a_2479)) {
        case TAG_At: {
          V v_x31_2487 = heff_field(v_a_2479, 0);
          V v_sp_2488 = heff_field(v_a_2479, 1);
          V v_ru_24a_2479_24At = heff_take_reuse_n(v_a_2479, 3ULL, 2);
          switch (heff_tag_of(v_x31_2487)) {
          case TAG_MkAlt: {
            V v_p_2489 = heff_field(v_x31_2487, 0);
            V v_e_2490 = heff_field(v_x31_2487, 1);
            V v_ru_24x31_2487_24MkAlt = heff_take_reuse_n(v_x31_2487, 3ULL, 2);
            V v_t_2491;
            if ((heff_dup(v_t_2486) == NTAG(TAG_True))) {
              heff_drop(v_t_2486);
              v_t_2491 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2486);
              v_t_2491 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_2490)));
            }
            V v_t_2492 = heff_tag_at_n(v_ru_24a_2479_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2489, v_e_2490}), v_sp_2488});
            V v_t_2493 = heff_tag_at_n(v_ru_24x31_2487_24MkAlt, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_2478, v_t_2492}), v_sp_243});
            return ((HeffT2){{v_t_2491, v_t_2493}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2487)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_a_2479)}});
        }
      }
    }
    case TAG_EDo: {
      V v_ss_2494 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EDo = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      HeffT2 v_t_2495 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_st_240, v_ss_2494));
      {
        V v_field_2496 = v_t_2495.f[0];
        V v_field_2497 = v_t_2495.f[1];
        V v_x_2498 = v_field_2496;
        V v_y_2499 = v_field_2497;
        V v_t_24100 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EDo, TAG_EDo, 1, (V[]){v_y_2499}), v_sp_243});
        return ((HeffT2){{v_x_2498, v_t_24100}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_242, 0ULL, 2);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EAssign: {
      V v_x_24104 = heff_field(v_x31_242, 0);
      V v_xsp_24105 = heff_field(v_x31_242, 1);
      V v_e_24106 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EAssign = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_tag(v_x3_241, 2);
      V v_t_24107;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_24107 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_24107 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_24106)));
      }
      V v_t_24108 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAssign, TAG_EAssign, 3, (V[]){v_x_24104, v_xsp_24105, v_e_24106}), v_sp_243});
      return ((HeffT2){{v_t_24107, v_t_24108}});
    }
    case TAG_EWhile: {
      V v_c_24109 = heff_field(v_x31_242, 0);
      V v_body_24110 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EWhile = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_24111;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_24111 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_24111 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_c_24109)));
      }
      HeffT2 v_t_24112 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_t_24111, v_body_24110));
      {
        V v_field_24113 = v_t_24112.f[0];
        V v_field_24114 = v_t_24112.f[1];
        V v_x_24115 = v_field_24113;
        V v_y_24116 = v_field_24114;
        V v_t_24117 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWhile, TAG_EWhile, 2, (V[]){v_c_24109, v_y_24116}), v_sp_243});
        return ((HeffT2){{v_x_24115, v_t_24117}});
      }
    }
    case TAG_EFor: {
      V v_p_24118 = heff_field(v_x31_242, 0);
      V v_c_24119 = heff_field(v_x31_242, 1);
      V v_body_24120 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EFor = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_tag(v_x3_241, 2);
      V v_t_24121;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_24121 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_24121 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_c_24119)));
      }
      HeffT2 v_t_24122 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_t_24121, v_body_24120));
      {
        V v_field_24123 = v_t_24122.f[0];
        V v_field_24124 = v_t_24122.f[1];
        V v_x_24125 = v_field_24123;
        V v_y_24126 = v_field_24124;
        V v_t_24127 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EFor, TAG_EFor, 3, (V[]){v_p_24118, v_c_24119, v_y_24126}), v_sp_243});
        return ((HeffT2){{v_x_24125, v_t_24127}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24128 = heff_field(v_x31_242, 0);
      V v_a_24129 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EIfThen = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        V v_t_24130 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24128, v_a_24129}), v_sp_243});
        return ((HeffT2){{NTAG(TAG_True), v_t_24130}});
      } else {
        heff_drop(v_st_240);
        V v_t_24131 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_c_24128)));
        V v_t_24132;
        if ((heff_dup(v_t_24131) == NTAG(TAG_True))) {
          heff_drop(v_t_24131);
          v_t_24132 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_24131);
          v_t_24132 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_24129)));
        }
        V v_t_24133 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24128, v_a_24129}), v_sp_243});
        return ((HeffT2){{v_t_24132, v_t_24133}});
      }
    }
    case TAG_EBreak: {
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EContinue: {
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EReturn: {
      V v_e_24134 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EReturn = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      V v_t_24135;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_24135 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_24135 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_24134)));
      }
      V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EReturn, TAG_EReturn, 1, (V[]){v_e_24134}), v_sp_243});
      return ((HeffT2){{v_t_24135, v_t_24136}});
    }
    case TAG_ENest: {
      V v_e_24137 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ENest = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      V v_t_24138;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_24138 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_24138 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_24137)));
      }
      V v_t_24139 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENest, TAG_ENest, 1, (V[]){v_e_24137}), v_sp_243});
      return ((HeffT2){{v_t_24138, v_t_24139}});
    }
    case TAG_ELazy: {
      V v_e_24140 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ELazy = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      V v_t_24141;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_24141 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_24141 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_24140)));
      }
      V v_t_24142 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELazy, TAG_ELazy, 1, (V[]){v_e_24140}), v_sp_243});
      return ((HeffT2){{v_t_24141, v_t_24142}});
    }
    case TAG_ETuple: {
      V v_es_24143 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETuple = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      HeffT2 v_t_24144 = (g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(v_st_240, v_es_24143));
      {
        V v_field_24145 = v_t_24144.f[0];
        V v_field_24146 = v_t_24144.f[1];
        V v_x_24147 = v_field_24145;
        V v_y_24148 = v_field_24146;
        V v_t_24149 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETuple, TAG_ETuple, 1, (V[]){v_y_24148}), v_sp_243});
        return ((HeffT2){{v_x_24147, v_t_24149}});
      }
    }
    case TAG_ETry: {
      V v_tr_24150 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETry = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      switch (heff_tag_of(v_tr_24150)) {
      case TAG_MkTry: {
        V v_err_24151 = heff_field(v_tr_24150, 0);
        V v_body_24152 = heff_field(v_tr_24150, 1);
        V v_c_24153 = heff_field(v_tr_24150, 2);
        V v_ru_24tr_24150_24MkTry = heff_take_reuse_n(v_tr_24150, 7ULL, 3);
        HeffT2 v_t_24154 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_st_240, v_body_24152));
        {
          V v_field_24155 = v_t_24154.f[0];
          V v_field_24156 = v_t_24154.f[1];
          V v_x_24157 = v_field_24155;
          V v_y_24158 = v_field_24156;
          switch (heff_tag_of(v_c_24153)) {
          case TAG_MkCatchArm: {
            V v_b_24159 = heff_field(v_c_24153, 0);
            V v_ss_24160 = heff_field(v_c_24153, 1);
            V v_ru_24c_24153_24MkCatchArm = heff_take_reuse_n(v_c_24153, 3ULL, 2);
            HeffT2 v_t_24161 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_x_24157, v_ss_24160));
            {
              V v_field_24162 = v_t_24161.f[0];
              V v_field_24163 = v_t_24161.f[1];
              V v_x_24164 = v_field_24162;
              V v_y_24165 = v_field_24163;
              V v_t_24166 = heff_tag_at_n(v_ru_24tr_24150_24MkTry, TAG_MkTry, 3, (V[]){v_err_24151, v_y_24158, heff_tag_n(TAG_MkCatchArm, 2, (V[]){v_b_24159, v_y_24165})});
              V v_t_24167 = heff_tag_at_n(v_ru_24c_24153_24MkCatchArm, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETry, TAG_ETry, 1, (V[]){v_t_24166}), v_sp_243});
              return ((HeffT2){{v_x_24164, v_t_24167}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_c_24153)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_tr_24150)}});
      }
    }
    case TAG_EWith: {
      V v_w_24168 = heff_field(v_x31_242, 0);
      V v_x_24169 = heff_field(v_x31_242, 1);
      V v_xsp_24170 = heff_field(v_x31_242, 2);
      V v_body_24171 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24EWith = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      heff_drop_tag(v_x3_241, 2);
      V v_t_24172;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_24172 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_24172 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_w_24168)));
      }
      HeffT2 v_t_24173 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_t_24172, v_body_24171));
      {
        V v_field_24174 = v_t_24173.f[0];
        V v_field_24175 = v_t_24173.f[1];
        V v_x_24176 = v_field_24174;
        V v_y_24177 = v_field_24175;
        V v_t_24178 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWith, TAG_EWith, 4, (V[]){v_w_24168, v_x_24169, v_xsp_24170, v_y_24177}), v_sp_243});
        return ((HeffT2){{v_x_24176, v_t_24178}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithScopeOf_str0, 10, "leaveScope");
Clo g_heff_2esyntax_2epresyntax_2ewithScopeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewithScopeOf_entry, 8, 0};

V g_heff_2esyntax_2epresyntax_2ewithScopeOf(V v_t_240, V v_cx_241, V v_sp_242, V v_w_243, V v_x_244, V v_xsp_245, V v_body_246, V v_end_247) {
top: ;
  V v_t_248 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
  HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_248}), NTAG(TAG_Nil), v_w_243));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_x_2412 = v_field_2410;
    V v_y_2413 = v_field_2411;
    V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
    V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2414}), heff_dup(heff_rfield(v_cx_241, 3))});
    V v_t_2416 = heff_intAdd(heff_dup(heff_rfield(v_cx_241, 4)), MK_INT(1LL));
    V v_t_2417 = heff_rec_n(5, shape_names__muts__loop__sp__depth, (V[]){heff_dup(heff_rfield(v_cx_241, 0)), heff_dup(heff_rfield(v_cx_241, 1)), heff_dup(heff_rfield(v_cx_241, 2)), heff_dup(heff_rfield(v_cx_241, 3)), v_t_2416});
    V v_e_2418 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_t_2417, v_body_246, v_end_247}));
    V v_t_2419 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_244, heff_dup(v_xsp_245)}), heff_dup(v_e_2418)});
    V v_t_2422;
    switch (heff_tag_of(v_e_2418)) {
    case TAG_At: {
      V v_s_2421 = heff_field(v_e_2418, 1);
      heff_take_n(v_e_2418, 2ULL, 2);
      v_t_2422 = v_s_2421;
      break;
    }
    default: heff_nomatch(v_e_2418);
    }
    V v_t_2423 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_245, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_t_2423}), NTAG(TAG_Nil)});
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2eapp(v_y_2413, v_t_2424));
    V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithScopeOf_str0)}), v_sp_242});
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
    V v_t_2428 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_t_2427})));
    return ({ V a_0 = v_cx_241; V a_1 = v_x_2412; V a_2 = v_t_2428; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
  }
}
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewithScopeOf(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eannLamOf_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2eannLamOf(V v_x_240, V v_xsp_241, V v_t_242, V v_x4_243, V v_sp_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(v_x_240, v_xsp_241, v_t_242, v_x4_243, v_sp_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_field_247});
    } else {
      if ((v_tag_246 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_247});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){v_field_247});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eannLamOf(a[0], a[1], a[2], a[3], a[4]);
}