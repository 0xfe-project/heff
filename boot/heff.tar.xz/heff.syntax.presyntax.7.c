// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndGive 48080
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_IAnn 21211
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_INominal 43674
#define TAG_INotationVar 46285
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkTry 8097
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TPi 30745
#define TAG_TSig 38418
#define TAG_TSum 38796
#define LBL_decl 9574769
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_head 9693863
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1242283185x1541081116_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1677166586x1409031985_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1685160129x1203636606_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s496186332x30239536_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s589295666x2074476083_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s814616358x897102902_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo;
V g_heff_2esyntax_2epresyntax_2eannLamOf(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eappOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryIn(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
HeffT2 g_heff_2esyntax_2epresyntax_2edoBlock_24s1455639597x676970604_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo;
V g_heff_2esyntax_2epresyntax_2epiBinderOf(V, V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo;
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo;
V g_heff_2esyntax_2epresyntax_2ereversedBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo;
V g_heff_2esyntax_2epresyntax_2erunArgs(V, V);
V g_heff_2esyntax_2epresyntax_2erunArgs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2erunArgs_clo;
V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s280627497x741826998_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeBinary_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_24tok2_clo;
V g_list_2eall_24s1414119352x995333365(V, V);
V g_list_2eall_24s1414119352x995333365_entry(V self, V *a);
extern Clo g_list_2eall_24s1414119352x995333365_clo;
V g_list_2eany_24s2074406606x298866118(V);
V g_list_2eany_24s2074406606x298866118_entry(V self, V *a);
extern Clo g_list_2eany_24s2074406606x298866118_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1230969749x2018313496(V);
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1258450377x973220636(V);
V g_list_2emap_24s1258450377x973220636_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_clo;
V g_list_2emap_24s137457135x961689574(V);
V g_list_2emap_24s137457135x961689574_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s2016093283x1174801437(V, V);
V g_list_2emap_24s2016093283x1174801437_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_clo;
V g_list_2emap_24s2039279853x710813703(V, V);
V g_list_2emap_24s2039279853x710813703_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_clo;
V g_list_2emap_24s205414595x1692305030(V);
V g_list_2emap_24s205414595x1692305030_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24s961097229x1129443801(V);
V g_list_2emap_24s961097229x1129443801_entry(V self, V *a);
extern Clo g_list_2emap_24s961097229x1129443801_clo;
V g_list_2emap_24s97919758x216970748(V, V);
V g_list_2emap_24s97919758x216970748_entry(V self, V *a);
extern Clo g_list_2emap_24s97919758x216970748_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ereversedBytes_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ereversedBytes(V v_s_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return v_acc_242;
  } else {
    V v_t_243 = heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)1ULL))), 6);
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_strAppend(v_t_243, v_acc_242);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2ereversedBytes(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str0, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str2, 4, "Unit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str3, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2eleaving_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eleaving_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2eleaving(V v_cx_240, V v_sp_241, V v_n_242, V v_call_243) {
top: ;
  if (heff_intLe_c_lent(v_n_242, MK_INT(0LL), 2)) {
    heff_drop_rec(v_cx_240, 6);
    heff_drop(v_sp_241);
    heff_drop(v_n_242);
    return v_call_243;
  } else {
    V v_e_244 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_240), heff_dup(v_sp_241), heff_intSub(v_n_242, MK_INT(1LL)), v_call_243));
    V v_sp_247;
    switch (heff_tag_of(v_e_244)) {
    case TAG_At: {
      V v_s_246 = heff_dup(heff_field(v_e_244, 1));
      v_sp_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_e_244);
    }
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str0)}), heff_dup(v_sp_247)});
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str1)}), v_sp_247});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_248, v_t_2410));
    V v_t_2414;
    switch (heff_tag_of(v_e_244)) {
    case TAG_At: {
      V v_s_2413 = heff_dup(heff_field(v_e_244, 1));
      v_t_2414 = v_s_2413;
      break;
    }
    default: heff_nomatch(v_e_244);
    }
    V v_e_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_e_244, v_t_2411}), v_t_2414});
    V v_t_2416 = heff_get_n(heff_get_n(v_cx_240, 0, 6), 1, 3);
    V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2416}), heff_dup(v_sp_241)});
    V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str2)}), heff_dup(v_sp_241)});
    V v_t_2419 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamAnn, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str3), heff_dup(v_sp_241), v_t_2418}), v_e_2415});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_241}), NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2417, v_t_2420));
  }
}
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eleaving(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epatNames_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2epatNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatNames_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epatNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_243, ((V)&g_heff_2esyntax_2epresyntax_2epatNames_str0), 2)) {
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        heff_drop(v_x_243);
        return NTAG(TAG_Nil);
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_246 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_246));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_247); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2410 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2411); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2417 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2417));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2418); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2420 = heff_field(v_x11_241, 0);
      V v_q_2422 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_cell_2423 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2420, heff_hole()});
      V v_u_2424 = (g_heff_2esyntax_2epresyntax_2epatNames_24dps(v_q_2422, heff_dup(v_cell_2423)));
      heff_drop(v_u_2424);
      return v_cell_2423;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatNames(a[0]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1677166586x1409031985_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24MkAlt = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_2437;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2437 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_247)) {
          case TAG_At: {
            V v_a_248 = heff_dup(heff_field(v_a_247, 0));
            switch (heff_tag_of(v_a_248)) {
            case TAG_ELam: {
              heff_take_n(v_a_248, 0ULL, 2);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_a_248, 0ULL, 4);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            default: {
              heff_drop(v_a_248);
              HeffT2 v_t_2432 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_247)));
              {
                V v_field_2433 = v_t_2432.f[0];
                V v_field_2434 = v_t_2432.f[1];
                V v_a_2435 = v_field_2433;
                V v_a_2436 = v_field_2434;
                heff_drop(v_a_2436);
                v_a_2437 = v_a_2435;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_247);
          }
        }
        HeffT2 v_t_2438 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1677166586x1409031985_24cpr(v_a_2437, v_xs_243));
        {
          V v_field_2439 = v_t_2438.f[0];
          V v_field_2440 = v_t_2438.f[1];
          V v_x_2441 = v_field_2439;
          V v_y_2442 = v_field_2440;
          V v_t_2443 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24MkAlt, TAG_MkAlt, 2, (V[]){v_a_246, v_a_247}), v_a_245});
          return ((HeffT2){{v_x_2441, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2443, v_y_2442})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s280627497x741826998_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_StmtBind: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_e_246 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtBind = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2436;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2436 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_246)) {
        case TAG_At: {
          V v_a_247 = heff_dup(heff_field(v_e_246, 0));
          switch (heff_tag_of(v_a_247)) {
          case TAG_ELam: {
            heff_take_n(v_a_247, 0ULL, 2);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2436 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          case TAG_EDo: {
            heff_take_n(v_a_247, 0ULL, 1);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2436 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_a_247, 0ULL, 1);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2436 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          case TAG_ELazy: {
            heff_take_n(v_a_247, 0ULL, 1);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2436 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_a_247, 0ULL, 1);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2436 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_a_247, 0ULL, 4);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2436 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          default: {
            heff_drop(v_a_247);
            HeffT2 v_t_2431 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_246)));
            {
              V v_field_2432 = v_t_2431.f[0];
              V v_field_2433 = v_t_2431.f[1];
              V v_a_2434 = v_field_2432;
              V v_a_2435 = v_field_2433;
              heff_drop(v_a_2435);
              v_x_2436 = v_a_2434;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_246);
        }
      }
      return ((HeffT3){{v_x_2436, heff_tag_at_n(v_ru_24x31_242_24StmtBind, TAG_StmtBind, 3, (V[]){v_x_244, v_xsp_245, v_e_246}), v_sp_243}});
    }
    case TAG_StmtLet: {
      V v_p_2437 = heff_field(v_x31_242, 0);
      V v_e_2438 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      V v_x_2468;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2468 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_2438)) {
        case TAG_At: {
          V v_a_2439 = heff_dup(heff_field(v_e_2438, 0));
          switch (heff_tag_of(v_a_2439)) {
          case TAG_ELam: {
            heff_take_n(v_a_2439, 0ULL, 2);
            switch (heff_tag_of(v_e_2438)) {
            case TAG_At: {
              v_x_2468 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2438);
            }
            break;
          }
          case TAG_EDo: {
            heff_take_n(v_a_2439, 0ULL, 1);
            switch (heff_tag_of(v_e_2438)) {
            case TAG_At: {
              v_x_2468 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2438);
            }
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_a_2439, 0ULL, 1);
            switch (heff_tag_of(v_e_2438)) {
            case TAG_At: {
              v_x_2468 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_2438);
            }
            break;
          }
          case TAG_ELazy: {
            heff_take_n(v_a_2439, 0ULL, 1);
            switch (heff_tag_of(v_e_2438)) {
            case TAG_At: {
              v_x_2468 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2438);
            }
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_a_2439, 0ULL, 1);
            switch (heff_tag_of(v_e_2438)) {
            case TAG_At: {
              v_x_2468 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2438);
            }
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_a_2439, 0ULL, 4);
            switch (heff_tag_of(v_e_2438)) {
            case TAG_At: {
              v_x_2468 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2438);
            }
            break;
          }
          default: {
            heff_drop(v_a_2439);
            HeffT2 v_t_2463 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_2438)));
            {
              V v_field_2464 = v_t_2463.f[0];
              V v_field_2465 = v_t_2463.f[1];
              V v_a_2466 = v_field_2464;
              V v_a_2467 = v_field_2465;
              heff_drop(v_a_2467);
              v_x_2468 = v_a_2466;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_2438);
        }
      }
      return ((HeffT3){{v_x_2468, heff_tag_at_n(v_ru_24x3_241_24At, TAG_StmtLet, 2, (V[]){v_p_2437, v_e_2438}), v_sp_243}});
    }
    case TAG_StmtExpr: {
      V v_e_2469 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24StmtExpr = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2499;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2499 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_2469)) {
        case TAG_At: {
          V v_a_2470 = heff_dup(heff_field(v_e_2469, 0));
          switch (heff_tag_of(v_a_2470)) {
          case TAG_ELam: {
            heff_take_n(v_a_2470, 0ULL, 2);
            switch (heff_tag_of(v_e_2469)) {
            case TAG_At: {
              v_x_2499 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2469);
            }
            break;
          }
          case TAG_EDo: {
            heff_take_n(v_a_2470, 0ULL, 1);
            switch (heff_tag_of(v_e_2469)) {
            case TAG_At: {
              v_x_2499 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2469);
            }
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_a_2470, 0ULL, 1);
            switch (heff_tag_of(v_e_2469)) {
            case TAG_At: {
              v_x_2499 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_2469);
            }
            break;
          }
          case TAG_ELazy: {
            heff_take_n(v_a_2470, 0ULL, 1);
            switch (heff_tag_of(v_e_2469)) {
            case TAG_At: {
              v_x_2499 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2469);
            }
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_a_2470, 0ULL, 1);
            switch (heff_tag_of(v_e_2469)) {
            case TAG_At: {
              v_x_2499 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2469);
            }
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_a_2470, 0ULL, 4);
            switch (heff_tag_of(v_e_2469)) {
            case TAG_At: {
              v_x_2499 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2469);
            }
            break;
          }
          default: {
            heff_drop(v_a_2470);
            HeffT2 v_t_2494 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_2469)));
            {
              V v_field_2495 = v_t_2494.f[0];
              V v_field_2496 = v_t_2494.f[1];
              V v_a_2497 = v_field_2495;
              V v_a_2498 = v_field_2496;
              heff_drop(v_a_2498);
              v_x_2499 = v_a_2497;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_2469);
        }
      }
      return ((HeffT3){{v_x_2499, heff_tag_at_n(v_ru_24x31_242_24StmtExpr, TAG_StmtExpr, 1, (V[]){v_e_2469}), v_sp_243}});
    }
    case TAG_StmtLetMut: {
      V v_x_24100 = heff_field(v_x31_242, 0);
      V v_xsp_24101 = heff_field(v_x31_242, 1);
      V v_e_24102 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtLetMut = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_24132;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_24132 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_24102)) {
        case TAG_At: {
          V v_a_24103 = heff_dup(heff_field(v_e_24102, 0));
          switch (heff_tag_of(v_a_24103)) {
          case TAG_ELam: {
            heff_take_n(v_a_24103, 0ULL, 2);
            switch (heff_tag_of(v_e_24102)) {
            case TAG_At: {
              v_x_24132 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24102);
            }
            break;
          }
          case TAG_EDo: {
            heff_take_n(v_a_24103, 0ULL, 1);
            switch (heff_tag_of(v_e_24102)) {
            case TAG_At: {
              v_x_24132 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24102);
            }
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_a_24103, 0ULL, 1);
            switch (heff_tag_of(v_e_24102)) {
            case TAG_At: {
              v_x_24132 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_24102);
            }
            break;
          }
          case TAG_ELazy: {
            heff_take_n(v_a_24103, 0ULL, 1);
            switch (heff_tag_of(v_e_24102)) {
            case TAG_At: {
              v_x_24132 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24102);
            }
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_a_24103, 0ULL, 1);
            switch (heff_tag_of(v_e_24102)) {
            case TAG_At: {
              v_x_24132 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24102);
            }
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_a_24103, 0ULL, 4);
            switch (heff_tag_of(v_e_24102)) {
            case TAG_At: {
              v_x_24132 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24102);
            }
            break;
          }
          default: {
            heff_drop(v_a_24103);
            HeffT2 v_t_24127 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24102)));
            {
              V v_field_24128 = v_t_24127.f[0];
              V v_field_24129 = v_t_24127.f[1];
              V v_a_24130 = v_field_24128;
              V v_a_24131 = v_field_24129;
              heff_drop(v_a_24131);
              v_x_24132 = v_a_24130;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_24102);
        }
      }
      return ((HeffT3){{v_x_24132, heff_tag_at_n(v_ru_24x31_242_24StmtLetMut, TAG_StmtLetMut, 3, (V[]){v_x_24100, v_xsp_24101, v_e_24102}), v_sp_243}});
    }
    case TAG_StmtLetElse: {
      V v_p_24133 = heff_field(v_x31_242, 0);
      V v_e_24134 = heff_field(v_x31_242, 1);
      V v_ss_24135 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtLetElse = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_24165;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_24165 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_24134)) {
        case TAG_At: {
          V v_a_24136 = heff_dup(heff_field(v_e_24134, 0));
          switch (heff_tag_of(v_a_24136)) {
          case TAG_ELam: {
            heff_take_n(v_a_24136, 0ULL, 2);
            switch (heff_tag_of(v_e_24134)) {
            case TAG_At: {
              v_x_24165 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24134);
            }
            break;
          }
          case TAG_EDo: {
            heff_take_n(v_a_24136, 0ULL, 1);
            switch (heff_tag_of(v_e_24134)) {
            case TAG_At: {
              v_x_24165 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24134);
            }
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_a_24136, 0ULL, 1);
            switch (heff_tag_of(v_e_24134)) {
            case TAG_At: {
              v_x_24165 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_24134);
            }
            break;
          }
          case TAG_ELazy: {
            heff_take_n(v_a_24136, 0ULL, 1);
            switch (heff_tag_of(v_e_24134)) {
            case TAG_At: {
              v_x_24165 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24134);
            }
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_a_24136, 0ULL, 1);
            switch (heff_tag_of(v_e_24134)) {
            case TAG_At: {
              v_x_24165 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24134);
            }
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_a_24136, 0ULL, 4);
            switch (heff_tag_of(v_e_24134)) {
            case TAG_At: {
              v_x_24165 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24134);
            }
            break;
          }
          default: {
            heff_drop(v_a_24136);
            HeffT2 v_t_24160 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24134)));
            {
              V v_field_24161 = v_t_24160.f[0];
              V v_field_24162 = v_t_24160.f[1];
              V v_a_24163 = v_field_24161;
              V v_a_24164 = v_field_24162;
              heff_drop(v_a_24164);
              v_x_24165 = v_a_24163;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_24134);
        }
      }
      HeffT2 v_t_24166 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(v_x_24165, v_ss_24135));
      {
        V v_field_24167 = v_t_24166.f[0];
        V v_field_24168 = v_t_24166.f[1];
        V v_x_24169 = v_field_24167;
        V v_y_24170 = v_field_24168;
        return ((HeffT3){{v_x_24169, heff_tag_at_n(v_ru_24x31_242_24StmtLetElse, TAG_StmtLetElse, 3, (V[]){v_p_24133, v_e_24134, v_y_24170}), v_sp_243}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_dup(heff_field(v_x3_241, 0));
    switch (heff_tag_of(v_x31_242)) {
    case TAG_EVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENotationVar: {
      heff_take_n(v_x31_242, 0ULL, 3);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EFloat: {
      heff_take_nf(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EBinary: {
      V v_segs_2413 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EBinary = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2415 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2416 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1685160129x1203636606_24cpr(v_st_240, v_segs_2413));
        {
          V v_field_2417 = v_t_2416.f[0];
          V v_field_2418 = v_t_2416.f[1];
          V v_x_2419 = v_field_2417;
          V v_y_2420 = v_field_2418;
          V v_t_2421 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EBinary, TAG_EBinary, 1, (V[]){v_y_2420}), v_sp_2415});
          return ((HeffT2){{v_x_2419, v_t_2421}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EApp: {
      V v_h_2424 = heff_field(v_x31_242, 0);
      V v_args_2425 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EApp = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2427 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2457;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2457 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_h_2424)) {
          case TAG_At: {
            V v_e1_2428 = heff_dup(heff_field(v_h_2424, 0));
            switch (heff_tag_of(v_e1_2428)) {
            case TAG_ELam: {
              heff_take_n(v_e1_2428, 0ULL, 2);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2457 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_2428, 0ULL, 1);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2457 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_2428, 0ULL, 1);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2457 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_2428, 0ULL, 1);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2457 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_2428, 0ULL, 1);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2457 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_2428, 0ULL, 4);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2457 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2428);
              HeffT2 v_t_2452 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_h_2424)));
              {
                V v_field_2453 = v_t_2452.f[0];
                V v_field_2454 = v_t_2452.f[1];
                V v_x_2455 = v_field_2453;
                V v_y_2456 = v_field_2454;
                heff_drop(v_y_2456);
                v_x_2457 = v_x_2455;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_h_2424);
          }
        }
        HeffT2 v_t_2458 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1242283185x1541081116_24cpr(v_x_2457, v_args_2425));
        {
          V v_field_2459 = v_t_2458.f[0];
          V v_field_2460 = v_t_2458.f[1];
          V v_x_2461 = v_field_2459;
          V v_y_2462 = v_field_2460;
          V v_t_2463 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EApp, TAG_EApp, 2, (V[]){v_h_2424, v_y_2462}), v_sp_2427});
          return ((HeffT2){{v_x_2461, v_t_2463}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENamed: {
      V v_x_2465 = heff_field(v_x31_242, 0);
      V v_e_2466 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ENamed = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2468 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2498;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2498 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_2466)) {
          case TAG_At: {
            V v_e1_2469 = heff_dup(heff_field(v_e_2466, 0));
            switch (heff_tag_of(v_e1_2469)) {
            case TAG_ELam: {
              heff_take_n(v_e1_2469, 0ULL, 2);
              switch (heff_tag_of(v_e_2466)) {
              case TAG_At: {
                v_x_2498 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2466);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_2469, 0ULL, 1);
              switch (heff_tag_of(v_e_2466)) {
              case TAG_At: {
                v_x_2498 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2466);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_2469, 0ULL, 1);
              switch (heff_tag_of(v_e_2466)) {
              case TAG_At: {
                v_x_2498 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_2466);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_2469, 0ULL, 1);
              switch (heff_tag_of(v_e_2466)) {
              case TAG_At: {
                v_x_2498 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2466);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_2469, 0ULL, 1);
              switch (heff_tag_of(v_e_2466)) {
              case TAG_At: {
                v_x_2498 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2466);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_2469, 0ULL, 4);
              switch (heff_tag_of(v_e_2466)) {
              case TAG_At: {
                v_x_2498 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2466);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2469);
              HeffT2 v_t_2493 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_2466)));
              {
                V v_field_2494 = v_t_2493.f[0];
                V v_field_2495 = v_t_2493.f[1];
                V v_x_2496 = v_field_2494;
                V v_y_2497 = v_field_2495;
                heff_drop(v_y_2497);
                v_x_2498 = v_x_2496;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_2466);
          }
        }
        V v_t_2499 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENamed, TAG_ENamed, 2, (V[]){v_x_2465, v_e_2466}), v_sp_2468});
        return ((HeffT2){{v_x_2498, v_t_2499}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ELam: {
      V v_b_24102 = heff_field(v_x31_242, 0);
      V v_body_24103 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELam = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24105 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24135;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24135 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_body_24103)) {
          case TAG_At: {
            V v_e1_24106 = heff_dup(heff_field(v_body_24103, 0));
            switch (heff_tag_of(v_e1_24106)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24106, 0ULL, 2);
              switch (heff_tag_of(v_body_24103)) {
              case TAG_At: {
                v_x_24135 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_body_24103);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24106, 0ULL, 1);
              switch (heff_tag_of(v_body_24103)) {
              case TAG_At: {
                v_x_24135 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_body_24103);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24106, 0ULL, 1);
              switch (heff_tag_of(v_body_24103)) {
              case TAG_At: {
                v_x_24135 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_body_24103);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24106, 0ULL, 1);
              switch (heff_tag_of(v_body_24103)) {
              case TAG_At: {
                v_x_24135 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_body_24103);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24106, 0ULL, 1);
              switch (heff_tag_of(v_body_24103)) {
              case TAG_At: {
                v_x_24135 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_body_24103);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24106, 0ULL, 4);
              switch (heff_tag_of(v_body_24103)) {
              case TAG_At: {
                v_x_24135 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_body_24103);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24106);
              HeffT2 v_t_24130 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_body_24103)));
              {
                V v_field_24131 = v_t_24130.f[0];
                V v_field_24132 = v_t_24130.f[1];
                V v_x_24133 = v_field_24131;
                V v_y_24134 = v_field_24132;
                heff_drop(v_y_24134);
                v_x_24135 = v_x_24133;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_body_24103);
          }
        }
        V v_t_24136 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELam, TAG_ELam, 2, (V[]){v_b_24102, v_body_24103}), v_sp_24105});
        return ((HeffT2){{v_x_24135, v_t_24136}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EAnn: {
      V v_e_24137 = heff_field(v_x31_242, 0);
      V v_t_24138 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EAnn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24140 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24170;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24170 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_24137)) {
          case TAG_At: {
            V v_e1_24141 = heff_dup(heff_field(v_e_24137, 0));
            switch (heff_tag_of(v_e1_24141)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24141, 0ULL, 2);
              switch (heff_tag_of(v_e_24137)) {
              case TAG_At: {
                v_x_24170 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24137);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24141, 0ULL, 1);
              switch (heff_tag_of(v_e_24137)) {
              case TAG_At: {
                v_x_24170 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24137);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24141, 0ULL, 1);
              switch (heff_tag_of(v_e_24137)) {
              case TAG_At: {
                v_x_24170 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24137);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24141, 0ULL, 1);
              switch (heff_tag_of(v_e_24137)) {
              case TAG_At: {
                v_x_24170 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24137);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24141, 0ULL, 1);
              switch (heff_tag_of(v_e_24137)) {
              case TAG_At: {
                v_x_24170 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24137);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24141, 0ULL, 4);
              switch (heff_tag_of(v_e_24137)) {
              case TAG_At: {
                v_x_24170 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24137);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24141);
              HeffT2 v_t_24165 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24137)));
              {
                V v_field_24166 = v_t_24165.f[0];
                V v_field_24167 = v_t_24165.f[1];
                V v_x_24168 = v_field_24166;
                V v_y_24169 = v_field_24167;
                heff_drop(v_y_24169);
                v_x_24170 = v_x_24168;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24137);
          }
        }
        V v_t_24171 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAnn, TAG_EAnn, 2, (V[]){v_e_24137, v_t_24138}), v_sp_24140});
        return ((HeffT2){{v_x_24170, v_t_24171}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESpec: {
      V v_a_24172 = heff_field(v_x31_242, 0);
      V v_x_24173 = heff_field(v_x31_242, 1);
      V v_xsp_24174 = heff_field(v_x31_242, 2);
      V v_v_24175 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24ESpec = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24177 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_24178 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
          return ((HeffT2){{NTAG(TAG_True), v_t_24178}});
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_24172)) {
          case TAG_At: {
            V v_e1_24179 = heff_dup(heff_field(v_a_24172, 0));
            switch (heff_tag_of(v_e1_24179)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24179, 0ULL, 2);
              V v_x_24212;
              switch (heff_tag_of(v_v_24175)) {
              case TAG_At: {
                V v_e1_24183 = heff_dup(heff_field(v_v_24175, 0));
                switch (heff_tag_of(v_e1_24183)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24183, 0ULL, 2);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24212 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24183, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24212 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24183, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24212 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24183, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24212 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24183, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24212 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24183, 0ULL, 4);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24212 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24183);
                  HeffT2 v_t_24207 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_v_24175)));
                  {
                    V v_field_24208 = v_t_24207.f[0];
                    V v_field_24209 = v_t_24207.f[1];
                    V v_x_24210 = v_field_24208;
                    V v_y_24211 = v_field_24209;
                    heff_drop(v_y_24211);
                    v_x_24212 = v_x_24210;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_v_24175);
              }
              V v_t_24213 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
              return ((HeffT2){{v_x_24212, v_t_24213}});
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24179, 0ULL, 1);
              V v_x_24244;
              switch (heff_tag_of(v_v_24175)) {
              case TAG_At: {
                V v_e1_24215 = heff_dup(heff_field(v_v_24175, 0));
                switch (heff_tag_of(v_e1_24215)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24215, 0ULL, 2);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24244 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24215, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24244 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24215, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24244 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24215, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24244 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24215, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24244 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24215, 0ULL, 4);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24244 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24215);
                  HeffT2 v_t_24239 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_v_24175)));
                  {
                    V v_field_24240 = v_t_24239.f[0];
                    V v_field_24241 = v_t_24239.f[1];
                    V v_x_24242 = v_field_24240;
                    V v_y_24243 = v_field_24241;
                    heff_drop(v_y_24243);
                    v_x_24244 = v_x_24242;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_v_24175);
              }
              V v_t_24245 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
              return ((HeffT2){{v_x_24244, v_t_24245}});
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24179, 0ULL, 1);
              V v_t_24247 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
              return ((HeffT2){{NTAG(TAG_True), v_t_24247}});
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24179, 0ULL, 1);
              V v_x_24278;
              switch (heff_tag_of(v_v_24175)) {
              case TAG_At: {
                V v_e1_24249 = heff_dup(heff_field(v_v_24175, 0));
                switch (heff_tag_of(v_e1_24249)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24249, 0ULL, 2);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24278 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24249, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24278 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24249, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24278 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24249, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24278 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24249, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24278 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24249, 0ULL, 4);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24278 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24249);
                  HeffT2 v_t_24273 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_v_24175)));
                  {
                    V v_field_24274 = v_t_24273.f[0];
                    V v_field_24275 = v_t_24273.f[1];
                    V v_x_24276 = v_field_24274;
                    V v_y_24277 = v_field_24275;
                    heff_drop(v_y_24277);
                    v_x_24278 = v_x_24276;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_v_24175);
              }
              V v_t_24279 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
              return ((HeffT2){{v_x_24278, v_t_24279}});
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24179, 0ULL, 1);
              V v_x_24310;
              switch (heff_tag_of(v_v_24175)) {
              case TAG_At: {
                V v_e1_24281 = heff_dup(heff_field(v_v_24175, 0));
                switch (heff_tag_of(v_e1_24281)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24281, 0ULL, 2);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24310 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24281, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24310 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24281, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24310 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24281, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24310 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24281, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24310 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24281, 0ULL, 4);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24310 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24281);
                  HeffT2 v_t_24305 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_v_24175)));
                  {
                    V v_field_24306 = v_t_24305.f[0];
                    V v_field_24307 = v_t_24305.f[1];
                    V v_x_24308 = v_field_24306;
                    V v_y_24309 = v_field_24307;
                    heff_drop(v_y_24309);
                    v_x_24310 = v_x_24308;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_v_24175);
              }
              V v_t_24311 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
              return ((HeffT2){{v_x_24310, v_t_24311}});
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24179, 0ULL, 4);
              V v_x_24345;
              switch (heff_tag_of(v_v_24175)) {
              case TAG_At: {
                V v_e1_24316 = heff_dup(heff_field(v_v_24175, 0));
                switch (heff_tag_of(v_e1_24316)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24316, 0ULL, 2);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24345 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24316, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24345 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24316, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24345 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24316, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24345 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24316, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24345 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24316, 0ULL, 4);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24345 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24316);
                  HeffT2 v_t_24340 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_v_24175)));
                  {
                    V v_field_24341 = v_t_24340.f[0];
                    V v_field_24342 = v_t_24340.f[1];
                    V v_x_24343 = v_field_24341;
                    V v_y_24344 = v_field_24342;
                    heff_drop(v_y_24344);
                    v_x_24345 = v_x_24343;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_v_24175);
              }
              V v_t_24346 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
              return ((HeffT2){{v_x_24345, v_t_24346}});
            }
            default: {
              heff_drop(v_e1_24179);
              HeffT2 v_t_24347 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24172)));
              {
                V v_field_24348 = v_t_24347.f[0];
                V v_field_24349 = v_t_24347.f[1];
                V v_x_24350 = v_field_24348;
                V v_y_24351 = v_field_24349;
                heff_drop(v_y_24351);
                V v_x_24381;
                if ((heff_dup(v_x_24350) == NTAG(TAG_True))) {
                  heff_drop(v_x_24350);
                  v_x_24381 = NTAG(TAG_True);
                } else {
                  heff_drop(v_x_24350);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    V v_e1_24352 = heff_dup(heff_field(v_v_24175, 0));
                    switch (heff_tag_of(v_e1_24352)) {
                    case TAG_ELam: {
                      heff_take_n(v_e1_24352, 0ULL, 2);
                      switch (heff_tag_of(v_v_24175)) {
                      case TAG_At: {
                        v_x_24381 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_v_24175);
                      }
                      break;
                    }
                    case TAG_EDo: {
                      heff_take_n(v_e1_24352, 0ULL, 1);
                      switch (heff_tag_of(v_v_24175)) {
                      case TAG_At: {
                        v_x_24381 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_v_24175);
                      }
                      break;
                    }
                    case TAG_ENest: {
                      heff_take_n(v_e1_24352, 0ULL, 1);
                      switch (heff_tag_of(v_v_24175)) {
                      case TAG_At: {
                        v_x_24381 = NTAG(TAG_True);
                        break;
                      }
                      default: heff_nomatch(v_v_24175);
                      }
                      break;
                    }
                    case TAG_ELazy: {
                      heff_take_n(v_e1_24352, 0ULL, 1);
                      switch (heff_tag_of(v_v_24175)) {
                      case TAG_At: {
                        v_x_24381 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_v_24175);
                      }
                      break;
                    }
                    case TAG_ETry: {
                      heff_take_n(v_e1_24352, 0ULL, 1);
                      switch (heff_tag_of(v_v_24175)) {
                      case TAG_At: {
                        v_x_24381 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_v_24175);
                      }
                      break;
                    }
                    case TAG_EWith: {
                      heff_take_n(v_e1_24352, 0ULL, 4);
                      switch (heff_tag_of(v_v_24175)) {
                      case TAG_At: {
                        v_x_24381 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_v_24175);
                      }
                      break;
                    }
                    default: {
                      heff_drop(v_e1_24352);
                      HeffT2 v_t_24376 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_v_24175)));
                      {
                        V v_field_24377 = v_t_24376.f[0];
                        V v_field_24378 = v_t_24376.f[1];
                        V v_x_24379 = v_field_24377;
                        V v_y_24380 = v_field_24378;
                        heff_drop(v_y_24380);
                        v_x_24381 = v_x_24379;
                      }
                      break;
                    }
                    }
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                }
                V v_t_24382 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
                return ((HeffT2){{v_x_24381, v_t_24382}});
              }
            }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24172)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EStruct: {
      V v_fs_24385 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EStruct = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24387 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24388 = (g_heff_2esyntax_2epresyntax_2eaccList_24s814616358x897102902_24cpr(v_st_240, v_fs_24385));
        {
          V v_field_24389 = v_t_24388.f[0];
          V v_field_24390 = v_t_24388.f[1];
          V v_x_24391 = v_field_24389;
          V v_y_24392 = v_field_24390;
          V v_t_24393 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EStruct, TAG_EStruct, 1, (V[]){v_y_24392}), v_sp_24387});
          return ((HeffT2){{v_x_24391, v_t_24393}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EUpdate: {
      V v_a_24394 = heff_field(v_x31_242, 0);
      V v_fs_24395 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EUpdate = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24397 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24427;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24427 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_24394)) {
          case TAG_At: {
            V v_e1_24398 = heff_dup(heff_field(v_a_24394, 0));
            switch (heff_tag_of(v_e1_24398)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24398, 0ULL, 2);
              switch (heff_tag_of(v_a_24394)) {
              case TAG_At: {
                v_x_24427 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_24394);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24398, 0ULL, 1);
              switch (heff_tag_of(v_a_24394)) {
              case TAG_At: {
                v_x_24427 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_24394);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24398, 0ULL, 1);
              switch (heff_tag_of(v_a_24394)) {
              case TAG_At: {
                v_x_24427 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_24394);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24398, 0ULL, 1);
              switch (heff_tag_of(v_a_24394)) {
              case TAG_At: {
                v_x_24427 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_24394);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24398, 0ULL, 1);
              switch (heff_tag_of(v_a_24394)) {
              case TAG_At: {
                v_x_24427 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_24394);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24398, 0ULL, 4);
              switch (heff_tag_of(v_a_24394)) {
              case TAG_At: {
                v_x_24427 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_24394);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24398);
              HeffT2 v_t_24422 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24394)));
              {
                V v_field_24423 = v_t_24422.f[0];
                V v_field_24424 = v_t_24422.f[1];
                V v_x_24425 = v_field_24423;
                V v_y_24426 = v_field_24424;
                heff_drop(v_y_24426);
                v_x_24427 = v_x_24425;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_24394);
          }
        }
        HeffT2 v_t_24428 = (g_heff_2esyntax_2epresyntax_2eaccList_24s496186332x30239536_24cpr(v_x_24427, v_fs_24395));
        {
          V v_field_24429 = v_t_24428.f[0];
          V v_field_24430 = v_t_24428.f[1];
          V v_x_24431 = v_field_24429;
          V v_y_24432 = v_field_24430;
          V v_t_24433 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EUpdate, TAG_EUpdate, 2, (V[]){v_a_24394, v_y_24432}), v_sp_24397});
          return ((HeffT2){{v_x_24431, v_t_24433}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EMatch: {
      V v_s_24434 = heff_field(v_x31_242, 0);
      V v_alts_24435 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EMatch = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24437 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24467;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24467 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_s_24434)) {
          case TAG_At: {
            V v_e1_24438 = heff_dup(heff_field(v_s_24434, 0));
            switch (heff_tag_of(v_e1_24438)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24438, 0ULL, 2);
              switch (heff_tag_of(v_s_24434)) {
              case TAG_At: {
                v_x_24467 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_s_24434);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24438, 0ULL, 1);
              switch (heff_tag_of(v_s_24434)) {
              case TAG_At: {
                v_x_24467 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_s_24434);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24438, 0ULL, 1);
              switch (heff_tag_of(v_s_24434)) {
              case TAG_At: {
                v_x_24467 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_s_24434);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24438, 0ULL, 1);
              switch (heff_tag_of(v_s_24434)) {
              case TAG_At: {
                v_x_24467 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_s_24434);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24438, 0ULL, 1);
              switch (heff_tag_of(v_s_24434)) {
              case TAG_At: {
                v_x_24467 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_s_24434);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24438, 0ULL, 4);
              switch (heff_tag_of(v_s_24434)) {
              case TAG_At: {
                v_x_24467 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_s_24434);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24438);
              HeffT2 v_t_24462 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_s_24434)));
              {
                V v_field_24463 = v_t_24462.f[0];
                V v_field_24464 = v_t_24462.f[1];
                V v_x_24465 = v_field_24463;
                V v_y_24466 = v_field_24464;
                heff_drop(v_y_24466);
                v_x_24467 = v_x_24465;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_s_24434);
          }
        }
        HeffT2 v_t_24468 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1677166586x1409031985_24cpr(v_x_24467, v_alts_24435));
        {
          V v_field_24469 = v_t_24468.f[0];
          V v_field_24470 = v_t_24468.f[1];
          V v_x_24471 = v_field_24469;
          V v_y_24472 = v_field_24470;
          V v_t_24473 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_24434, v_y_24472}), v_sp_24437});
          return ((HeffT2){{v_x_24471, v_t_24473}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_24474 = heff_field(v_x31_242, 0);
      V v_a_24475 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELetIn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24477 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_24475)) {
          case TAG_At: {
            V v_x31_24478 = heff_field(v_a_24475, 0);
            V v_sp_24479 = heff_field(v_a_24475, 1);
            V v_ru_24a_24475_24At = heff_take_reuse_n(v_a_24475, 3ULL, 2);
            switch (heff_tag_of(v_x31_24478)) {
            case TAG_MkAlt: {
              V v_p_24480 = heff_field(v_x31_24478, 0);
              V v_e_24481 = heff_field(v_x31_24478, 1);
              V v_ru_24x31_24478_24MkAlt = heff_take_reuse_n(v_x31_24478, 3ULL, 2);
              V v_t_24482 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_24478_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_24480, v_e_24481}), v_sp_24479});
              V v_t_24483 = heff_tag_at_n(v_ru_24a_24475_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_24474, v_t_24482}), v_sp_24477});
              return ((HeffT2){{NTAG(TAG_True), v_t_24483}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24478)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24475)}});
          }
        } else {
          heff_drop(v_st_240);
          V v_x_24513;
          switch (heff_tag_of(v_rhs_24474)) {
          case TAG_At: {
            V v_e1_24484 = heff_dup(heff_field(v_rhs_24474, 0));
            switch (heff_tag_of(v_e1_24484)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24484, 0ULL, 2);
              switch (heff_tag_of(v_rhs_24474)) {
              case TAG_At: {
                v_x_24513 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_rhs_24474);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24484, 0ULL, 1);
              switch (heff_tag_of(v_rhs_24474)) {
              case TAG_At: {
                v_x_24513 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_rhs_24474);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24484, 0ULL, 1);
              switch (heff_tag_of(v_rhs_24474)) {
              case TAG_At: {
                v_x_24513 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_rhs_24474);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24484, 0ULL, 1);
              switch (heff_tag_of(v_rhs_24474)) {
              case TAG_At: {
                v_x_24513 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_rhs_24474);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24484, 0ULL, 1);
              switch (heff_tag_of(v_rhs_24474)) {
              case TAG_At: {
                v_x_24513 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_rhs_24474);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24484, 0ULL, 4);
              switch (heff_tag_of(v_rhs_24474)) {
              case TAG_At: {
                v_x_24513 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_rhs_24474);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24484);
              HeffT2 v_t_24508 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_rhs_24474)));
              {
                V v_field_24509 = v_t_24508.f[0];
                V v_field_24510 = v_t_24508.f[1];
                V v_x_24511 = v_field_24509;
                V v_y_24512 = v_field_24510;
                heff_drop(v_y_24512);
                v_x_24513 = v_x_24511;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_rhs_24474);
          }
          switch (heff_tag_of(v_a_24475)) {
          case TAG_At: {
            V v_x31_24514 = heff_field(v_a_24475, 0);
            V v_sp_24515 = heff_field(v_a_24475, 1);
            V v_ru_24a_24475_24At = heff_take_reuse_n(v_a_24475, 3ULL, 2);
            switch (heff_tag_of(v_x31_24514)) {
            case TAG_MkAlt: {
              V v_p_24516 = heff_field(v_x31_24514, 0);
              V v_e_24517 = heff_field(v_x31_24514, 1);
              V v_ru_24x31_24514_24MkAlt = heff_take_reuse_n(v_x31_24514, 3ULL, 2);
              V v_x_24547;
              if ((heff_dup(v_x_24513) == NTAG(TAG_True))) {
                heff_drop(v_x_24513);
                v_x_24547 = NTAG(TAG_True);
              } else {
                heff_drop(v_x_24513);
                switch (heff_tag_of(v_e_24517)) {
                case TAG_At: {
                  V v_e1_24518 = heff_dup(heff_field(v_e_24517, 0));
                  switch (heff_tag_of(v_e1_24518)) {
                  case TAG_ELam: {
                    heff_take_n(v_e1_24518, 0ULL, 2);
                    switch (heff_tag_of(v_e_24517)) {
                    case TAG_At: {
                      v_x_24547 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_e_24517);
                    }
                    break;
                  }
                  case TAG_EDo: {
                    heff_take_n(v_e1_24518, 0ULL, 1);
                    switch (heff_tag_of(v_e_24517)) {
                    case TAG_At: {
                      v_x_24547 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_e_24517);
                    }
                    break;
                  }
                  case TAG_ENest: {
                    heff_take_n(v_e1_24518, 0ULL, 1);
                    switch (heff_tag_of(v_e_24517)) {
                    case TAG_At: {
                      v_x_24547 = NTAG(TAG_True);
                      break;
                    }
                    default: heff_nomatch(v_e_24517);
                    }
                    break;
                  }
                  case TAG_ELazy: {
                    heff_take_n(v_e1_24518, 0ULL, 1);
                    switch (heff_tag_of(v_e_24517)) {
                    case TAG_At: {
                      v_x_24547 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_e_24517);
                    }
                    break;
                  }
                  case TAG_ETry: {
                    heff_take_n(v_e1_24518, 0ULL, 1);
                    switch (heff_tag_of(v_e_24517)) {
                    case TAG_At: {
                      v_x_24547 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_e_24517);
                    }
                    break;
                  }
                  case TAG_EWith: {
                    heff_take_n(v_e1_24518, 0ULL, 4);
                    switch (heff_tag_of(v_e_24517)) {
                    case TAG_At: {
                      v_x_24547 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_e_24517);
                    }
                    break;
                  }
                  default: {
                    heff_drop(v_e1_24518);
                    HeffT2 v_t_24542 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24517)));
                    {
                      V v_field_24543 = v_t_24542.f[0];
                      V v_field_24544 = v_t_24542.f[1];
                      V v_x_24545 = v_field_24543;
                      V v_y_24546 = v_field_24544;
                      heff_drop(v_y_24546);
                      v_x_24547 = v_x_24545;
                    }
                    break;
                  }
                  }
                  break;
                }
                default: heff_nomatch(v_e_24517);
                }
              }
              V v_t_24548 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_24514_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_24516, v_e_24517}), v_sp_24515});
              V v_t_24549 = heff_tag_at_n(v_ru_24a_24475_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_24474, v_t_24548}), v_sp_24477});
              return ((HeffT2){{v_x_24547, v_t_24549}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24514)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24475)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24550 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EDo = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24552 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24553 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(v_st_240, v_ss_24550));
        {
          V v_field_24554 = v_t_24553.f[0];
          V v_field_24555 = v_t_24553.f[1];
          V v_x_24556 = v_field_24554;
          V v_y_24557 = v_field_24555;
          V v_t_24558 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EDo, TAG_EDo, 1, (V[]){v_y_24557}), v_sp_24552});
          return ((HeffT2){{v_x_24556, v_t_24558}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EAssign: {
      V v_x_24562 = heff_field(v_x31_242, 0);
      V v_xsp_24563 = heff_field(v_x31_242, 1);
      V v_e_24564 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EAssign = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24566 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24596;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24596 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_24564)) {
          case TAG_At: {
            V v_e1_24567 = heff_dup(heff_field(v_e_24564, 0));
            switch (heff_tag_of(v_e1_24567)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24567, 0ULL, 2);
              switch (heff_tag_of(v_e_24564)) {
              case TAG_At: {
                v_x_24596 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24564);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24567, 0ULL, 1);
              switch (heff_tag_of(v_e_24564)) {
              case TAG_At: {
                v_x_24596 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24564);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24567, 0ULL, 1);
              switch (heff_tag_of(v_e_24564)) {
              case TAG_At: {
                v_x_24596 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24564);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24567, 0ULL, 1);
              switch (heff_tag_of(v_e_24564)) {
              case TAG_At: {
                v_x_24596 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24564);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24567, 0ULL, 1);
              switch (heff_tag_of(v_e_24564)) {
              case TAG_At: {
                v_x_24596 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24564);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24567, 0ULL, 4);
              switch (heff_tag_of(v_e_24564)) {
              case TAG_At: {
                v_x_24596 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24564);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24567);
              HeffT2 v_t_24591 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24564)));
              {
                V v_field_24592 = v_t_24591.f[0];
                V v_field_24593 = v_t_24591.f[1];
                V v_x_24594 = v_field_24592;
                V v_y_24595 = v_field_24593;
                heff_drop(v_y_24595);
                v_x_24596 = v_x_24594;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24564);
          }
        }
        V v_t_24597 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAssign, TAG_EAssign, 3, (V[]){v_x_24562, v_xsp_24563, v_e_24564}), v_sp_24566});
        return ((HeffT2){{v_x_24596, v_t_24597}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24598 = heff_field(v_x31_242, 0);
      V v_body_24599 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EWhile = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24601 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24631;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24631 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_c_24598)) {
          case TAG_At: {
            V v_e1_24602 = heff_dup(heff_field(v_c_24598, 0));
            switch (heff_tag_of(v_e1_24602)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24602, 0ULL, 2);
              switch (heff_tag_of(v_c_24598)) {
              case TAG_At: {
                v_x_24631 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24598);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24602, 0ULL, 1);
              switch (heff_tag_of(v_c_24598)) {
              case TAG_At: {
                v_x_24631 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24598);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24602, 0ULL, 1);
              switch (heff_tag_of(v_c_24598)) {
              case TAG_At: {
                v_x_24631 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_c_24598);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24602, 0ULL, 1);
              switch (heff_tag_of(v_c_24598)) {
              case TAG_At: {
                v_x_24631 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24598);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24602, 0ULL, 1);
              switch (heff_tag_of(v_c_24598)) {
              case TAG_At: {
                v_x_24631 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24598);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24602, 0ULL, 4);
              switch (heff_tag_of(v_c_24598)) {
              case TAG_At: {
                v_x_24631 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24598);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24602);
              HeffT2 v_t_24626 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_c_24598)));
              {
                V v_field_24627 = v_t_24626.f[0];
                V v_field_24628 = v_t_24626.f[1];
                V v_x_24629 = v_field_24627;
                V v_y_24630 = v_field_24628;
                heff_drop(v_y_24630);
                v_x_24631 = v_x_24629;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_c_24598);
          }
        }
        HeffT2 v_t_24632 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(v_x_24631, v_body_24599));
        {
          V v_field_24633 = v_t_24632.f[0];
          V v_field_24634 = v_t_24632.f[1];
          V v_x_24635 = v_field_24633;
          V v_y_24636 = v_field_24634;
          V v_t_24637 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWhile, TAG_EWhile, 2, (V[]){v_c_24598, v_y_24636}), v_sp_24601});
          return ((HeffT2){{v_x_24635, v_t_24637}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EFor: {
      V v_p_24638 = heff_field(v_x31_242, 0);
      V v_c_24639 = heff_field(v_x31_242, 1);
      V v_body_24640 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EFor = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24642 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24672;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24672 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_c_24639)) {
          case TAG_At: {
            V v_e1_24643 = heff_dup(heff_field(v_c_24639, 0));
            switch (heff_tag_of(v_e1_24643)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24643, 0ULL, 2);
              switch (heff_tag_of(v_c_24639)) {
              case TAG_At: {
                v_x_24672 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24639);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24643, 0ULL, 1);
              switch (heff_tag_of(v_c_24639)) {
              case TAG_At: {
                v_x_24672 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24639);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24643, 0ULL, 1);
              switch (heff_tag_of(v_c_24639)) {
              case TAG_At: {
                v_x_24672 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_c_24639);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24643, 0ULL, 1);
              switch (heff_tag_of(v_c_24639)) {
              case TAG_At: {
                v_x_24672 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24639);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24643, 0ULL, 1);
              switch (heff_tag_of(v_c_24639)) {
              case TAG_At: {
                v_x_24672 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24639);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24643, 0ULL, 4);
              switch (heff_tag_of(v_c_24639)) {
              case TAG_At: {
                v_x_24672 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24639);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24643);
              HeffT2 v_t_24667 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_c_24639)));
              {
                V v_field_24668 = v_t_24667.f[0];
                V v_field_24669 = v_t_24667.f[1];
                V v_x_24670 = v_field_24668;
                V v_y_24671 = v_field_24669;
                heff_drop(v_y_24671);
                v_x_24672 = v_x_24670;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_c_24639);
          }
        }
        HeffT2 v_t_24673 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(v_x_24672, v_body_24640));
        {
          V v_field_24674 = v_t_24673.f[0];
          V v_field_24675 = v_t_24673.f[1];
          V v_x_24676 = v_field_24674;
          V v_y_24677 = v_field_24675;
          V v_t_24678 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EFor, TAG_EFor, 3, (V[]){v_p_24638, v_c_24639, v_y_24677}), v_sp_24642});
          return ((HeffT2){{v_x_24676, v_t_24678}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24679 = heff_field(v_x31_242, 0);
      V v_a_24680 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EIfThen = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24682 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_24683 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
          return ((HeffT2){{NTAG(TAG_True), v_t_24683}});
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_c_24679)) {
          case TAG_At: {
            V v_e1_24684 = heff_dup(heff_field(v_c_24679, 0));
            switch (heff_tag_of(v_e1_24684)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24684, 0ULL, 2);
              V v_x_24717;
              switch (heff_tag_of(v_a_24680)) {
              case TAG_At: {
                V v_e1_24688 = heff_dup(heff_field(v_a_24680, 0));
                switch (heff_tag_of(v_e1_24688)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24688, 0ULL, 2);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24717 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24688, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24717 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24688, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24717 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24688, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24717 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24688, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24717 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24688, 0ULL, 4);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24717 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24688);
                  HeffT2 v_t_24712 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24680)));
                  {
                    V v_field_24713 = v_t_24712.f[0];
                    V v_field_24714 = v_t_24712.f[1];
                    V v_x_24715 = v_field_24713;
                    V v_y_24716 = v_field_24714;
                    heff_drop(v_y_24716);
                    v_x_24717 = v_x_24715;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_a_24680);
              }
              V v_t_24718 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
              return ((HeffT2){{v_x_24717, v_t_24718}});
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24684, 0ULL, 1);
              V v_x_24749;
              switch (heff_tag_of(v_a_24680)) {
              case TAG_At: {
                V v_e1_24720 = heff_dup(heff_field(v_a_24680, 0));
                switch (heff_tag_of(v_e1_24720)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24720, 0ULL, 2);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24749 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24720, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24749 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24720, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24749 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24720, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24749 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24720, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24749 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24720, 0ULL, 4);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24749 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24720);
                  HeffT2 v_t_24744 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24680)));
                  {
                    V v_field_24745 = v_t_24744.f[0];
                    V v_field_24746 = v_t_24744.f[1];
                    V v_x_24747 = v_field_24745;
                    V v_y_24748 = v_field_24746;
                    heff_drop(v_y_24748);
                    v_x_24749 = v_x_24747;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_a_24680);
              }
              V v_t_24750 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
              return ((HeffT2){{v_x_24749, v_t_24750}});
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24684, 0ULL, 1);
              V v_t_24752 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
              return ((HeffT2){{NTAG(TAG_True), v_t_24752}});
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24684, 0ULL, 1);
              V v_x_24783;
              switch (heff_tag_of(v_a_24680)) {
              case TAG_At: {
                V v_e1_24754 = heff_dup(heff_field(v_a_24680, 0));
                switch (heff_tag_of(v_e1_24754)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24754, 0ULL, 2);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24783 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24754, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24783 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24754, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24783 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24754, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24783 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24754, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24783 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24754, 0ULL, 4);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24783 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24754);
                  HeffT2 v_t_24778 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24680)));
                  {
                    V v_field_24779 = v_t_24778.f[0];
                    V v_field_24780 = v_t_24778.f[1];
                    V v_x_24781 = v_field_24779;
                    V v_y_24782 = v_field_24780;
                    heff_drop(v_y_24782);
                    v_x_24783 = v_x_24781;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_a_24680);
              }
              V v_t_24784 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
              return ((HeffT2){{v_x_24783, v_t_24784}});
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24684, 0ULL, 1);
              V v_x_24815;
              switch (heff_tag_of(v_a_24680)) {
              case TAG_At: {
                V v_e1_24786 = heff_dup(heff_field(v_a_24680, 0));
                switch (heff_tag_of(v_e1_24786)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24786, 0ULL, 2);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24815 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24786, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24815 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24786, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24815 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24786, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24815 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24786, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24815 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24786, 0ULL, 4);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24815 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24786);
                  HeffT2 v_t_24810 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24680)));
                  {
                    V v_field_24811 = v_t_24810.f[0];
                    V v_field_24812 = v_t_24810.f[1];
                    V v_x_24813 = v_field_24811;
                    V v_y_24814 = v_field_24812;
                    heff_drop(v_y_24814);
                    v_x_24815 = v_x_24813;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_a_24680);
              }
              V v_t_24816 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
              return ((HeffT2){{v_x_24815, v_t_24816}});
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24684, 0ULL, 4);
              V v_x_24850;
              switch (heff_tag_of(v_a_24680)) {
              case TAG_At: {
                V v_e1_24821 = heff_dup(heff_field(v_a_24680, 0));
                switch (heff_tag_of(v_e1_24821)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24821, 0ULL, 2);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24850 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24821, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24850 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24821, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24850 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24821, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24850 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24821, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24850 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24821, 0ULL, 4);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24850 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24821);
                  HeffT2 v_t_24845 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24680)));
                  {
                    V v_field_24846 = v_t_24845.f[0];
                    V v_field_24847 = v_t_24845.f[1];
                    V v_x_24848 = v_field_24846;
                    V v_y_24849 = v_field_24847;
                    heff_drop(v_y_24849);
                    v_x_24850 = v_x_24848;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_a_24680);
              }
              V v_t_24851 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
              return ((HeffT2){{v_x_24850, v_t_24851}});
            }
            default: {
              heff_drop(v_e1_24684);
              HeffT2 v_t_24852 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_c_24679)));
              {
                V v_field_24853 = v_t_24852.f[0];
                V v_field_24854 = v_t_24852.f[1];
                V v_x_24855 = v_field_24853;
                V v_y_24856 = v_field_24854;
                heff_drop(v_y_24856);
                V v_x_24886;
                if ((heff_dup(v_x_24855) == NTAG(TAG_True))) {
                  heff_drop(v_x_24855);
                  v_x_24886 = NTAG(TAG_True);
                } else {
                  heff_drop(v_x_24855);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    V v_e1_24857 = heff_dup(heff_field(v_a_24680, 0));
                    switch (heff_tag_of(v_e1_24857)) {
                    case TAG_ELam: {
                      heff_take_n(v_e1_24857, 0ULL, 2);
                      switch (heff_tag_of(v_a_24680)) {
                      case TAG_At: {
                        v_x_24886 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_a_24680);
                      }
                      break;
                    }
                    case TAG_EDo: {
                      heff_take_n(v_e1_24857, 0ULL, 1);
                      switch (heff_tag_of(v_a_24680)) {
                      case TAG_At: {
                        v_x_24886 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_a_24680);
                      }
                      break;
                    }
                    case TAG_ENest: {
                      heff_take_n(v_e1_24857, 0ULL, 1);
                      switch (heff_tag_of(v_a_24680)) {
                      case TAG_At: {
                        v_x_24886 = NTAG(TAG_True);
                        break;
                      }
                      default: heff_nomatch(v_a_24680);
                      }
                      break;
                    }
                    case TAG_ELazy: {
                      heff_take_n(v_e1_24857, 0ULL, 1);
                      switch (heff_tag_of(v_a_24680)) {
                      case TAG_At: {
                        v_x_24886 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_a_24680);
                      }
                      break;
                    }
                    case TAG_ETry: {
                      heff_take_n(v_e1_24857, 0ULL, 1);
                      switch (heff_tag_of(v_a_24680)) {
                      case TAG_At: {
                        v_x_24886 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_a_24680);
                      }
                      break;
                    }
                    case TAG_EWith: {
                      heff_take_n(v_e1_24857, 0ULL, 4);
                      switch (heff_tag_of(v_a_24680)) {
                      case TAG_At: {
                        v_x_24886 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_a_24680);
                      }
                      break;
                    }
                    default: {
                      heff_drop(v_e1_24857);
                      HeffT2 v_t_24881 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24680)));
                      {
                        V v_field_24882 = v_t_24881.f[0];
                        V v_field_24883 = v_t_24881.f[1];
                        V v_x_24884 = v_field_24882;
                        V v_y_24885 = v_field_24883;
                        heff_drop(v_y_24885);
                        v_x_24886 = v_x_24884;
                      }
                      break;
                    }
                    }
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                }
                V v_t_24887 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
                return ((HeffT2){{v_x_24886, v_t_24887}});
              }
            }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_c_24679)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EBreak: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EReturn: {
      V v_e_24888 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EReturn = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24890 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24920;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24920 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_24888)) {
          case TAG_At: {
            V v_e1_24891 = heff_dup(heff_field(v_e_24888, 0));
            switch (heff_tag_of(v_e1_24891)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24891, 0ULL, 2);
              switch (heff_tag_of(v_e_24888)) {
              case TAG_At: {
                v_x_24920 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24888);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24891, 0ULL, 1);
              switch (heff_tag_of(v_e_24888)) {
              case TAG_At: {
                v_x_24920 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24888);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24891, 0ULL, 1);
              switch (heff_tag_of(v_e_24888)) {
              case TAG_At: {
                v_x_24920 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24888);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24891, 0ULL, 1);
              switch (heff_tag_of(v_e_24888)) {
              case TAG_At: {
                v_x_24920 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24888);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24891, 0ULL, 1);
              switch (heff_tag_of(v_e_24888)) {
              case TAG_At: {
                v_x_24920 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24888);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24891, 0ULL, 4);
              switch (heff_tag_of(v_e_24888)) {
              case TAG_At: {
                v_x_24920 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24888);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24891);
              HeffT2 v_t_24915 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24888)));
              {
                V v_field_24916 = v_t_24915.f[0];
                V v_field_24917 = v_t_24915.f[1];
                V v_x_24918 = v_field_24916;
                V v_y_24919 = v_field_24917;
                heff_drop(v_y_24919);
                v_x_24920 = v_x_24918;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24888);
          }
        }
        V v_t_24921 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EReturn, TAG_EReturn, 1, (V[]){v_e_24888}), v_sp_24890});
        return ((HeffT2){{v_x_24920, v_t_24921}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ENest: {
      V v_e_24922 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ENest = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24924 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24954;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24954 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_24922)) {
          case TAG_At: {
            V v_e1_24925 = heff_dup(heff_field(v_e_24922, 0));
            switch (heff_tag_of(v_e1_24925)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24925, 0ULL, 2);
              switch (heff_tag_of(v_e_24922)) {
              case TAG_At: {
                v_x_24954 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24922);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24925, 0ULL, 1);
              switch (heff_tag_of(v_e_24922)) {
              case TAG_At: {
                v_x_24954 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24922);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24925, 0ULL, 1);
              switch (heff_tag_of(v_e_24922)) {
              case TAG_At: {
                v_x_24954 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24922);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24925, 0ULL, 1);
              switch (heff_tag_of(v_e_24922)) {
              case TAG_At: {
                v_x_24954 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24922);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24925, 0ULL, 1);
              switch (heff_tag_of(v_e_24922)) {
              case TAG_At: {
                v_x_24954 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24922);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24925, 0ULL, 4);
              switch (heff_tag_of(v_e_24922)) {
              case TAG_At: {
                v_x_24954 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24922);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24925);
              HeffT2 v_t_24949 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24922)));
              {
                V v_field_24950 = v_t_24949.f[0];
                V v_field_24951 = v_t_24949.f[1];
                V v_x_24952 = v_field_24950;
                V v_y_24953 = v_field_24951;
                heff_drop(v_y_24953);
                v_x_24954 = v_x_24952;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24922);
          }
        }
        V v_t_24955 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENest, TAG_ENest, 1, (V[]){v_e_24922}), v_sp_24924});
        return ((HeffT2){{v_x_24954, v_t_24955}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24956 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ELazy = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24958 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24988;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24988 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_24956)) {
          case TAG_At: {
            V v_e1_24959 = heff_dup(heff_field(v_e_24956, 0));
            switch (heff_tag_of(v_e1_24959)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24959, 0ULL, 2);
              switch (heff_tag_of(v_e_24956)) {
              case TAG_At: {
                v_x_24988 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24956);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24959, 0ULL, 1);
              switch (heff_tag_of(v_e_24956)) {
              case TAG_At: {
                v_x_24988 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24956);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24959, 0ULL, 1);
              switch (heff_tag_of(v_e_24956)) {
              case TAG_At: {
                v_x_24988 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24956);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24959, 0ULL, 1);
              switch (heff_tag_of(v_e_24956)) {
              case TAG_At: {
                v_x_24988 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24956);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24959, 0ULL, 1);
              switch (heff_tag_of(v_e_24956)) {
              case TAG_At: {
                v_x_24988 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24956);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24959, 0ULL, 4);
              switch (heff_tag_of(v_e_24956)) {
              case TAG_At: {
                v_x_24988 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24956);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24959);
              HeffT2 v_t_24983 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24956)));
              {
                V v_field_24984 = v_t_24983.f[0];
                V v_field_24985 = v_t_24983.f[1];
                V v_x_24986 = v_field_24984;
                V v_y_24987 = v_field_24985;
                heff_drop(v_y_24987);
                v_x_24988 = v_x_24986;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24956);
          }
        }
        V v_t_24989 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELazy, TAG_ELazy, 1, (V[]){v_e_24956}), v_sp_24958});
        return ((HeffT2){{v_x_24988, v_t_24989}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24990 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETuple = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24992 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24993 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1242283185x1541081116_24cpr(v_st_240, v_es_24990));
        {
          V v_field_24994 = v_t_24993.f[0];
          V v_field_24995 = v_t_24993.f[1];
          V v_x_24996 = v_field_24994;
          V v_y_24997 = v_field_24995;
          V v_t_24998 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETuple, TAG_ETuple, 1, (V[]){v_y_24997}), v_sp_24992});
          return ((HeffT2){{v_x_24996, v_t_24998}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24999 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETry = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_241001 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        switch (heff_tag_of(v_tr_24999)) {
        case TAG_MkTry: {
          V v_err_241002 = heff_field(v_tr_24999, 0);
          V v_body_241003 = heff_field(v_tr_24999, 1);
          V v_c_241004 = heff_field(v_tr_24999, 2);
          V v_ru_24tr_24999_24MkTry = heff_take_reuse_n(v_tr_24999, 7ULL, 3);
          HeffT2 v_t_241005 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(v_st_240, v_body_241003));
          {
            V v_field_241006 = v_t_241005.f[0];
            V v_field_241007 = v_t_241005.f[1];
            V v_x_241008 = v_field_241006;
            V v_y_241009 = v_field_241007;
            switch (heff_tag_of(v_c_241004)) {
            case TAG_MkCatchArm: {
              V v_b_241010 = heff_field(v_c_241004, 0);
              V v_ss_241011 = heff_field(v_c_241004, 1);
              V v_ru_24c_241004_24MkCatchArm = heff_take_reuse_n(v_c_241004, 3ULL, 2);
              HeffT2 v_t_241012 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(v_x_241008, v_ss_241011));
              {
                V v_field_241013 = v_t_241012.f[0];
                V v_field_241014 = v_t_241012.f[1];
                V v_x_241015 = v_field_241013;
                V v_y_241016 = v_field_241014;
                V v_t_241017 = heff_tag_at_n(v_ru_24tr_24999_24MkTry, TAG_MkTry, 3, (V[]){v_err_241002, v_y_241009, heff_tag_at_n(v_ru_24c_241004_24MkCatchArm, TAG_MkCatchArm, 2, (V[]){v_b_241010, v_y_241016})});
                V v_t_241018 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETry, TAG_ETry, 1, (V[]){v_t_241017}), v_sp_241001});
                return ((HeffT2){{v_x_241015, v_t_241018}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_c_241004)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_tr_24999)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWith: {
      V v_w_241019 = heff_field(v_x31_242, 0);
      V v_x_241020 = heff_field(v_x31_242, 1);
      V v_xsp_241021 = heff_field(v_x31_242, 2);
      V v_body_241022 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24EWith = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_241024 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_241054;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_241054 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_w_241019)) {
          case TAG_At: {
            V v_e1_241025 = heff_dup(heff_field(v_w_241019, 0));
            switch (heff_tag_of(v_e1_241025)) {
            case TAG_ELam: {
              heff_take_n(v_e1_241025, 0ULL, 2);
              switch (heff_tag_of(v_w_241019)) {
              case TAG_At: {
                v_x_241054 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_w_241019);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_241025, 0ULL, 1);
              switch (heff_tag_of(v_w_241019)) {
              case TAG_At: {
                v_x_241054 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_w_241019);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_241025, 0ULL, 1);
              switch (heff_tag_of(v_w_241019)) {
              case TAG_At: {
                v_x_241054 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_w_241019);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_241025, 0ULL, 1);
              switch (heff_tag_of(v_w_241019)) {
              case TAG_At: {
                v_x_241054 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_w_241019);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_241025, 0ULL, 1);
              switch (heff_tag_of(v_w_241019)) {
              case TAG_At: {
                v_x_241054 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_w_241019);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_241025, 0ULL, 4);
              switch (heff_tag_of(v_w_241019)) {
              case TAG_At: {
                v_x_241054 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_w_241019);
              }
              break;
            }
            default: {
              heff_drop(v_e1_241025);
              HeffT2 v_t_241049 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_w_241019)));
              {
                V v_field_241050 = v_t_241049.f[0];
                V v_field_241051 = v_t_241049.f[1];
                V v_x_241052 = v_field_241050;
                V v_y_241053 = v_field_241051;
                heff_drop(v_y_241053);
                v_x_241054 = v_x_241052;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_w_241019);
          }
        }
        HeffT2 v_t_241055 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(v_x_241054, v_body_241022));
        {
          V v_field_241056 = v_t_241055.f[0];
          V v_field_241057 = v_t_241055.f[1];
          V v_x_241058 = v_field_241056;
          V v_y_241059 = v_field_241057;
          V v_t_241060 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWith, TAG_EWith, 4, (V[]){v_w_241019, v_x_241020, v_xsp_241021, v_y_241059}), v_sp_241024});
          return ((HeffT2){{v_x_241058, v_t_241060}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eisControl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eisControl_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eisControl(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_False);
    }
    case TAG_ENotationVar: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EString: {
      return NTAG(TAG_False);
    }
    case TAG_EBinary: {
      return NTAG(TAG_False);
    }
    case TAG_ERune: {
      return NTAG(TAG_False);
    }
    case TAG_EWord: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_EProject: {
      return NTAG(TAG_False);
    }
    case TAG_ENamed: {
      return NTAG(TAG_False);
    }
    case TAG_EPi: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      return NTAG(TAG_False);
    }
    case TAG_ESpec: {
      return NTAG(TAG_False);
    }
    case TAG_ESig: {
      return NTAG(TAG_False);
    }
    case TAG_ESum: {
      return NTAG(TAG_False);
    }
    case TAG_EStruct: {
      return NTAG(TAG_False);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      V v_alts_2436 = heff_field(v_x11_241, 1);
      HEFF_LAST return g_list_2eany_24s2074406606x298866118(heff_dup(v_alts_2436));
    }
    case TAG_ELetIn: {
      return NTAG(TAG_False);
    }
    case TAG_EDo: {
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      return NTAG(TAG_False);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_EAssign: {
      return NTAG(TAG_True);
    }
    case TAG_EWhile: {
      return NTAG(TAG_True);
    }
    case TAG_EFor: {
      return NTAG(TAG_True);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_True);
    }
    case TAG_EBreak: {
      return NTAG(TAG_True);
    }
    case TAG_EContinue: {
      return NTAG(TAG_True);
    }
    case TAG_EReturn: {
      return NTAG(TAG_True);
    }
    case TAG_ENest: {
      return NTAG(TAG_False);
    }
    case TAG_ELazy: {
      return NTAG(TAG_False);
    }
    case TAG_ETuple: {
      return NTAG(TAG_False);
    }
    case TAG_ETry: {
      return NTAG(TAG_True);
    }
    case TAG_EWith: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2eisControl(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_st_2418;
    if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
      heff_drop(v_st_240);
      v_st_2418 = NTAG(TAG_True);
    } else {
      heff_drop(v_st_240);
      switch (heff_tag_of(v_x_242)) {
      case TAG_At: {
        V v_a_244 = heff_dup(heff_field(v_x_242, 0));
        switch (heff_tag_of(v_a_244)) {
        case TAG_ELam: {
          heff_take_n(v_a_244, 0ULL, 2);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2418 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        case TAG_EReturn: {
          heff_take_n(v_a_244, 0ULL, 1);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2418 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        default: {
          heff_drop(v_a_244);
          HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_x_242)));
          {
            V v_field_2414 = v_t_2413.f[0];
            V v_field_2415 = v_t_2413.f[1];
            V v_a_2416 = v_field_2414;
            V v_a_2417 = v_field_2415;
            heff_drop(v_a_2417);
            v_st_2418 = v_a_2416;
          }
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_x_242);
      }
    }
    HeffT2 v_t_2419 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24cpr(v_st_2418, v_xs_243));
    {
      V v_field_2420 = v_t_2419.f[0];
      V v_field_2421 = v_t_2419.f[1];
      V v_x_2422 = v_field_2420;
      V v_y_2423 = v_field_2421;
      return ((HeffT2){{v_x_2422, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_y_2423})}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s589295666x2074476083_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24MkAlt = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_2422;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2422 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_247)) {
          case TAG_At: {
            V v_a_248 = heff_dup(heff_field(v_a_247, 0));
            switch (heff_tag_of(v_a_248)) {
            case TAG_ELam: {
              heff_take_n(v_a_248, 0ULL, 2);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2422 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2422 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            default: {
              heff_drop(v_a_248);
              HeffT2 v_t_2417 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_247)));
              {
                V v_field_2418 = v_t_2417.f[0];
                V v_field_2419 = v_t_2417.f[1];
                V v_a_2420 = v_field_2418;
                V v_a_2421 = v_field_2419;
                heff_drop(v_a_2421);
                v_a_2422 = v_a_2420;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_247);
          }
        }
        HeffT2 v_t_2423 = (g_heff_2esyntax_2epresyntax_2eaccList_24s589295666x2074476083_24cpr(v_a_2422, v_xs_243));
        {
          V v_field_2424 = v_t_2423.f[0];
          V v_field_2425 = v_t_2423.f[1];
          V v_x_2426 = v_field_2424;
          V v_y_2427 = v_field_2425;
          V v_t_2428 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24MkAlt, TAG_MkAlt, 2, (V[]){v_a_246, v_a_247}), v_a_245});
          return ((HeffT2){{v_x_2426, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2428, v_y_2427})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xsp_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PiNamed = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_x1_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_244}));
    V v_t_2415;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_IsInferable: {
      V v_i_246 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsInferable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_249;
      switch (heff_tag_of(v_i_246)) {
      case TAG_At: {
        V v_s_248 = heff_dup(heff_field(v_i_246, 1));
        v_t_249 = v_s_248;
        break;
      }
      default: heff_nomatch(v_i_246);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsInferable, TAG_TInf, 1, (V[]){v_i_246}), v_t_249});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2410 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsCheckable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_dup(heff_field(v_c_2410, 1));
        v_t_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2410}), v_t_2413});
      break;
    }
    case TAG_IsType: {
      V v_t_2414 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      v_t_2415 = v_t_2414;
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_242, v_xsp_243, v_t_2415});
  }
  case TAG_PiImplicit: {
    V v_x_2416 = heff_field(v_x2_241, 0);
    V v_xsp_2417 = heff_field(v_x2_241, 1);
    V v_bsp_2418 = heff_field(v_x2_241, 2);
    V v_t_2419 = heff_field(v_x2_241, 3);
    V v_d_2420 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24PiImplicit = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_x1_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2419}));
    V v_t_2431;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_IsInferable: {
      V v_i_2422 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsInferable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2425;
      switch (heff_tag_of(v_i_2422)) {
      case TAG_At: {
        V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
        v_t_2425 = v_s_2424;
        break;
      }
      default: heff_nomatch(v_i_2422);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsInferable, TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2426 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsCheckable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2429;
      switch (heff_tag_of(v_c_2426)) {
      case TAG_At: {
        V v_s_2428 = heff_dup(heff_field(v_c_2426, 1));
        v_t_2429 = v_s_2428;
        break;
      }
      default: heff_nomatch(v_c_2426);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2426}), v_t_2429});
      break;
    }
    case TAG_IsType: {
      V v_t_2430 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 1);
      v_t_2431 = v_t_2430;
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    V v_t_2444;
    switch (heff_tag_of(v_d_2420)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 2);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2432 = heff_field(v_d_2420, 0);
      V v_ru_24d_2420_24Just = heff_take_reuse_n(v_d_2420, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsInferable = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsInferable, TAG_CInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        v_t_2443 = v_c_2438;
        break;
      }
      case TAG_IsType: {
        V v_t_2439 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsType = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2442;
        switch (heff_tag_of(v_t_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_t_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_t_2439);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsType, TAG_CType, 1, (V[]){v_t_2439}), v_t_2442});
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      v_t_2444 = heff_tag_at_n(v_ru_24d_2420_24Just, TAG_Just, 1, (V[]){v_t_2443});
      break;
    }
    default: heff_nomatch(v_d_2420);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2416, v_xsp_2417, v_bsp_2418, v_t_2431, v_t_2444});
  }
  case TAG_PiInstance: {
    V v_x_2445 = heff_field(v_x2_241, 0);
    V v_xsp_2446 = heff_field(v_x2_241, 1);
    V v_bsp_2447 = heff_field(v_x2_241, 2);
    V v_t_2448 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiInstance = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_x1_2449 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2448}));
    V v_t_2459;
    switch (heff_tag_of(v_x1_2449)) {
    case TAG_IsInferable: {
      V v_i_2450 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsInferable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2453;
      switch (heff_tag_of(v_i_2450)) {
      case TAG_At: {
        V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
        v_t_2453 = v_s_2452;
        break;
      }
      default: heff_nomatch(v_i_2450);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsInferable, TAG_TInf, 1, (V[]){v_i_2450}), v_t_2453});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2454 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsCheckable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_c_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_c_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_c_2454);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2454}), v_t_2457});
      break;
    }
    case TAG_IsType: {
      V v_t_2458 = heff_field(v_x1_2449, 0);
      heff_take_n(v_x1_2449, 1ULL, 1);
      v_t_2459 = v_t_2458;
      break;
    }
    default: heff_nomatch(v_x1_2449);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2445, v_xsp_2446, v_bsp_2447, v_t_2459});
  }
  case TAG_PiAnon: {
    V v_t_2460 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PiAnon = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2460}));
    V v_t_2471;
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_IsInferable: {
      V v_i_2462 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24IsInferable = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      V v_t_2465;
      switch (heff_tag_of(v_i_2462)) {
      case TAG_At: {
        V v_s_2464 = heff_dup(heff_field(v_i_2462, 1));
        v_t_2465 = v_s_2464;
        break;
      }
      default: heff_nomatch(v_i_2462);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsInferable, TAG_TInf, 1, (V[]){v_i_2462}), v_t_2465});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2466 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24IsCheckable = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      V v_t_2469;
      switch (heff_tag_of(v_c_2466)) {
      case TAG_At: {
        V v_s_2468 = heff_dup(heff_field(v_c_2466, 1));
        v_t_2469 = v_s_2468;
        break;
      }
      default: heff_nomatch(v_c_2466);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2466}), v_t_2469});
      break;
    }
    case TAG_IsType: {
      V v_t_2470 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      v_t_2471 = v_t_2470;
      break;
    }
    default: heff_nomatch(v_x1_2461);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2471});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_d_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclareField = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_246}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        V v_ru_24x1_248_24IsInferable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_248_24IsInferable, TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        V v_ru_24x1_248_24IsCheckable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_248_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      V v_t_2431;
      switch (heff_tag_of(v_d_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 2);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2419 = heff_field(v_d_247, 0);
        V v_ru_24d_247_24Just = heff_take_reuse_n(v_d_247, 1ULL, 1);
        V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2419}));
        V v_t_2430;
        switch (heff_tag_of(v_x1_2420)) {
        case TAG_IsInferable: {
          V v_i_2421 = heff_field(v_x1_2420, 0);
          V v_ru_24x1_2420_24IsInferable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_i_2421)) {
          case TAG_At: {
            V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_i_2421);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsInferable, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2425 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          v_t_2430 = v_c_2425;
          break;
        }
        case TAG_IsType: {
          V v_t_2426 = heff_field(v_x1_2420, 0);
          V v_ru_24x1_2420_24IsType = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
          V v_t_2429;
          switch (heff_tag_of(v_t_2426)) {
          case TAG_At: {
            V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
            v_t_2429 = v_s_2428;
            break;
          }
          default: heff_nomatch(v_t_2426);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsType, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
          break;
        }
        default: heff_nomatch(v_x1_2420);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24d_247_24Just, TAG_Just, 1, (V[]){v_t_2430});
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_244, v_xsp_245, v_t_2418, v_t_2431}), v_sp_243});
    }
    case TAG_BadFieldDecl: {
      V v_e_2432 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldDecl = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsInferable = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsInferable, TAG_TInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsCheckable = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2441;
        switch (heff_tag_of(v_c_2438)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_c_2438, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_c_2438);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2438}), v_t_2441});
        break;
      }
      case TAG_IsType: {
        V v_t_2442 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2443 = v_t_2442;
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2443}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eannLamOf_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2eannLamOf(V v_x_240, V v_xsp_241, V v_t_242, V v_x4_243, V v_sp_244) {
top: ;
  HeffT3 v_t_245 = (g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(v_x_240, v_xsp_241, v_t_242, v_x4_243, v_sp_244));
  {
    V v_field_247 = v_t_245.f[1];
    V v_field_248 = v_t_245.f[2];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_247, v_field_248})});
    } else {
      if ((v_tag_246 == ((int64_t)1ULL))) {
        heff_drop(v_field_248);
        return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_247});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_247, v_field_248})});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eannLamOf(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str4, 67, " := e` sets a `let mut` variable: it is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str5, 45, "a `while` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str6, 43, "a `for` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str7, 78, "an `if` without `else` is a statement of a `do` block: a value's has an `else`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str8, 78, "`break` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str9, 81, "`continue` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str10, 103, "`return e` ends a `do` block as one of its statements (or an arm of its `if` or `case`), not as a value");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str11, 67, "`(<- c)`, the value of an action, is in a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str12, 72, "a `try` is a statement of a `do` block (or an arm of its `if` or `case`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str13, 73, "a `with` is a statement of a `do` block (or an arm of its `if` or `case`)");
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_IVar, 1, (V[]){v_x_244}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_245});
    }
    case TAG_EImplicitVar: {
      V v_x_246 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EImplicitVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_IVar, 1, (V[]){v_x_246}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_247});
    }
    case TAG_ENotationVar: {
      V v_x_248 = heff_field(v_x21_242, 0);
      V v_ksp_249 = heff_field(v_x21_242, 1);
      V v_said_2410 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24ENotationVar = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      heff_drop_rec(v_r_240, 2);
      V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ENotationVar, TAG_INotationVar, 3, (V[]){v_x_248, v_ksp_249, v_said_2410}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2411});
    }
    case TAG_ETag: {
      V v_t_2412 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ETag = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2413 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_2412, heff_dup(v_sp_243), NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2413, v_sp_243})});
    }
    case TAG_EInt: {
      V v_i_2414 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInt = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_IInt, 1, (V[]){v_i_2414}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2415});
    }
    case TAG_EFloat: {
      V v_x_2416 = heff_tget_v(v_x21_242, 0);
      V v_ru_24x21_242_24EFloat = heff_take_reuse_nf(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_IFloat, 1, (V[]){v_x_2416}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2417});
    }
    case TAG_EString: {
      V v_x_2418 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EString = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EString, TAG_IString, 1, (V[]){v_x_2418}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2419});
    }
    case TAG_EBinary: {
      V v_segs_2420 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EBinary = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return ({ V a_0 = v_ru_24x21_242_24EBinary; V a_1 = v_r_240; V b_2 = NTAG(TAG_False); V a_3 = v_segs_2420; V a_4 = v_sp_243; V r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
    }
    case TAG_ERune: {
      V v_c_2421 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ERune = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2422 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_IRune, 1, (V[]){v_c_2421}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2422});
    }
    case TAG_EWord: {
      V v_w_2423 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      return (g_heff_2esyntax_2epresyntax_2ewordOf_24tok2(v_ru_24x2_241_24At, v_w_2423, v_sp_243));
    }
    case TAG_EApp: {
      V v_h_2424 = heff_field(v_x21_242, 0);
      V v_args_2425 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2426 = (g_heff_2esyntax_2epresyntax_2erunArgs(heff_dup(v_h_2424), v_args_2425));
      return (g_heff_2esyntax_2epresyntax_2eappOf_24tok2(v_ru_24x2_241_24At, v_r_240, v_h_2424, v_t_2426, v_sp_243));
    }
    case TAG_EProject: {
      V v_ru_24x21_242_24EProject = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2428 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EProject, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2428, v_sp_243})});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_2431 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2431, v_sp_243})});
    }
    case TAG_EPi: {
      V v_b_2432 = heff_field(v_x21_242, 0);
      V v_cod_2433 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2434 = (g_heff_2esyntax_2epresyntax_2epiBinderOf(heff_dup(v_r_240), v_b_2432));
      V v_x1_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_cod_2433}));
      V v_t_2445;
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_IsInferable: {
        V v_i_2436 = heff_field(v_x1_2435, 0);
        V v_ru_24x1_2435_24IsInferable = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
        V v_t_2439;
        switch (heff_tag_of(v_i_2436)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_i_2436, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_i_2436);
        }
        v_t_2445 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2435_24IsInferable, TAG_TInf, 1, (V[]){v_i_2436}), v_t_2439});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2440 = heff_field(v_x1_2435, 0);
        V v_ru_24x1_2435_24IsCheckable = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
        V v_t_2443;
        switch (heff_tag_of(v_c_2440)) {
        case TAG_At: {
          V v_s_2442 = heff_dup(heff_field(v_c_2440, 1));
          v_t_2443 = v_s_2442;
          break;
        }
        default: heff_nomatch(v_c_2440);
        }
        v_t_2445 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2435_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2440}), v_t_2443});
        break;
      }
      case TAG_IsType: {
        V v_t_2444 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2445 = v_t_2444;
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
      V v_t_2446 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TPi, 2, (V[]){v_t_2434, v_t_2445}), v_sp_243});
      return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2446});
    }
    case TAG_ELam: {
      V v_x211_2447 = heff_field(v_x21_242, 0);
      V v_body_2448 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x211_2447)) {
      case TAG_LamName: {
        V v_x_2449 = heff_field(v_x211_2447, 0);
        V v_xsp_2450 = heff_field(v_x211_2447, 1);
        heff_take_n(v_x211_2447, 3ULL, 2);
        V v_x1_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2448}));
        V v_t_2461;
        switch (heff_tag_of(v_x1_2451)) {
        case TAG_IsInferable: {
          V v_i_2452 = heff_field(v_x1_2451, 0);
          V v_ru_24x1_2451_24IsInferable = heff_take_reuse_n(v_x1_2451, 1ULL, 1);
          V v_t_2455;
          switch (heff_tag_of(v_i_2452)) {
          case TAG_At: {
            V v_s_2454 = heff_dup(heff_field(v_i_2452, 1));
            v_t_2455 = v_s_2454;
            break;
          }
          default: heff_nomatch(v_i_2452);
          }
          v_t_2461 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2451_24IsInferable, TAG_CInf, 1, (V[]){v_i_2452}), v_t_2455});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2456 = heff_field(v_x1_2451, 0);
          heff_take_n(v_x1_2451, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2461 = v_c_2456;
          break;
        }
        case TAG_IsType: {
          V v_t_2457 = heff_field(v_x1_2451, 0);
          V v_ru_24x1_2451_24IsType = heff_take_reuse_n(v_x1_2451, 1ULL, 1);
          V v_t_2460;
          switch (heff_tag_of(v_t_2457)) {
          case TAG_At: {
            V v_s_2459 = heff_dup(heff_field(v_t_2457, 1));
            v_t_2460 = v_s_2459;
            break;
          }
          default: heff_nomatch(v_t_2457);
          }
          v_t_2461 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2451_24IsType, TAG_CType, 1, (V[]){v_t_2457}), v_t_2460});
          break;
        }
        default: heff_nomatch(v_x1_2451);
        }
        V v_t_2462 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2449, v_xsp_2450, v_t_2461}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2462});
      }
      case TAG_LamImplicit: {
        V v_x_2463 = heff_field(v_x211_2447, 0);
        V v_xsp_2464 = heff_field(v_x211_2447, 1);
        heff_take_n(v_x211_2447, 3ULL, 2);
        V v_x1_2465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2448}));
        V v_t_2475;
        switch (heff_tag_of(v_x1_2465)) {
        case TAG_IsInferable: {
          V v_i_2466 = heff_field(v_x1_2465, 0);
          V v_ru_24x1_2465_24IsInferable = heff_take_reuse_n(v_x1_2465, 1ULL, 1);
          V v_t_2469;
          switch (heff_tag_of(v_i_2466)) {
          case TAG_At: {
            V v_s_2468 = heff_dup(heff_field(v_i_2466, 1));
            v_t_2469 = v_s_2468;
            break;
          }
          default: heff_nomatch(v_i_2466);
          }
          v_t_2475 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2465_24IsInferable, TAG_CInf, 1, (V[]){v_i_2466}), v_t_2469});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2470 = heff_field(v_x1_2465, 0);
          heff_take_n(v_x1_2465, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2475 = v_c_2470;
          break;
        }
        case TAG_IsType: {
          V v_t_2471 = heff_field(v_x1_2465, 0);
          V v_ru_24x1_2465_24IsType = heff_take_reuse_n(v_x1_2465, 1ULL, 1);
          V v_t_2474;
          switch (heff_tag_of(v_t_2471)) {
          case TAG_At: {
            V v_s_2473 = heff_dup(heff_field(v_t_2471, 1));
            v_t_2474 = v_s_2473;
            break;
          }
          default: heff_nomatch(v_t_2471);
          }
          v_t_2475 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2465_24IsType, TAG_CType, 1, (V[]){v_t_2471}), v_t_2474});
          break;
        }
        default: heff_nomatch(v_x1_2465);
        }
        V v_t_2476 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2463, v_xsp_2464, v_t_2475}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2476});
      }
      case TAG_LamAnn: {
        V v_x_2477 = heff_field(v_x211_2447, 0);
        V v_xsp_2478 = heff_field(v_x211_2447, 1);
        V v_t_2479 = heff_field(v_x211_2447, 2);
        heff_take_n(v_x211_2447, 7ULL, 3);
        heff_drop_cell(v_ru_24x21_242_24ELam, 2);
        V v_x1_2480 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2479}));
        V v_t_2490;
        switch (heff_tag_of(v_x1_2480)) {
        case TAG_IsInferable: {
          V v_i_2481 = heff_field(v_x1_2480, 0);
          V v_ru_24x1_2480_24IsInferable = heff_take_reuse_n(v_x1_2480, 1ULL, 1);
          V v_t_2484;
          switch (heff_tag_of(v_i_2481)) {
          case TAG_At: {
            V v_s_2483 = heff_dup(heff_field(v_i_2481, 1));
            v_t_2484 = v_s_2483;
            break;
          }
          default: heff_nomatch(v_i_2481);
          }
          v_t_2490 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2480_24IsInferable, TAG_TInf, 1, (V[]){v_i_2481}), v_t_2484});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2485 = heff_field(v_x1_2480, 0);
          V v_ru_24x1_2480_24IsCheckable = heff_take_reuse_n(v_x1_2480, 1ULL, 1);
          V v_t_2488;
          switch (heff_tag_of(v_c_2485)) {
          case TAG_At: {
            V v_s_2487 = heff_dup(heff_field(v_c_2485, 1));
            v_t_2488 = v_s_2487;
            break;
          }
          default: heff_nomatch(v_c_2485);
          }
          v_t_2490 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2480_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2485}), v_t_2488});
          break;
        }
        case TAG_IsType: {
          V v_t_2489 = heff_field(v_x1_2480, 0);
          heff_take_n(v_x1_2480, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2490 = v_t_2489;
          break;
        }
        default: heff_nomatch(v_x1_2480);
        }
        V v_t_2491 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2448}));
        return (g_heff_2esyntax_2epresyntax_2eannLamOf(v_x_2477, v_xsp_2478, v_t_2490, v_t_2491, v_sp_243));
      }
      default: return heff_nomatch(v_x211_2447);
      }
    }
    case TAG_EAnn: {
      V v_a_2492 = heff_field(v_x21_242, 0);
      V v_t_2493 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_2494 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_2492}));
      V v_t_24104;
      switch (heff_tag_of(v_x1_2494)) {
      case TAG_IsInferable: {
        V v_i_2495 = heff_field(v_x1_2494, 0);
        V v_ru_24x1_2494_24IsInferable = heff_take_reuse_n(v_x1_2494, 1ULL, 1);
        V v_t_2498;
        switch (heff_tag_of(v_i_2495)) {
        case TAG_At: {
          V v_s_2497 = heff_dup(heff_field(v_i_2495, 1));
          v_t_2498 = v_s_2497;
          break;
        }
        default: heff_nomatch(v_i_2495);
        }
        v_t_24104 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2494_24IsInferable, TAG_CInf, 1, (V[]){v_i_2495}), v_t_2498});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2499 = heff_field(v_x1_2494, 0);
        heff_take_n(v_x1_2494, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24104 = v_c_2499;
        break;
      }
      case TAG_IsType: {
        V v_t_24100 = heff_field(v_x1_2494, 0);
        V v_ru_24x1_2494_24IsType = heff_take_reuse_n(v_x1_2494, 1ULL, 1);
        V v_t_24103;
        switch (heff_tag_of(v_t_24100)) {
        case TAG_At: {
          V v_s_24102 = heff_dup(heff_field(v_t_24100, 1));
          v_t_24103 = v_s_24102;
          break;
        }
        default: heff_nomatch(v_t_24100);
        }
        v_t_24104 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2494_24IsType, TAG_CType, 1, (V[]){v_t_24100}), v_t_24103});
        break;
      }
      default: heff_nomatch(v_x1_2494);
      }
      V v_x1_24105 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2493}));
      V v_t_24115;
      switch (heff_tag_of(v_x1_24105)) {
      case TAG_IsInferable: {
        V v_i_24106 = heff_field(v_x1_24105, 0);
        V v_ru_24x1_24105_24IsInferable = heff_take_reuse_n(v_x1_24105, 1ULL, 1);
        V v_t_24109;
        switch (heff_tag_of(v_i_24106)) {
        case TAG_At: {
          V v_s_24108 = heff_dup(heff_field(v_i_24106, 1));
          v_t_24109 = v_s_24108;
          break;
        }
        default: heff_nomatch(v_i_24106);
        }
        v_t_24115 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24105_24IsInferable, TAG_TInf, 1, (V[]){v_i_24106}), v_t_24109});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24110 = heff_field(v_x1_24105, 0);
        V v_ru_24x1_24105_24IsCheckable = heff_take_reuse_n(v_x1_24105, 1ULL, 1);
        V v_t_24113;
        switch (heff_tag_of(v_c_24110)) {
        case TAG_At: {
          V v_s_24112 = heff_dup(heff_field(v_c_24110, 1));
          v_t_24113 = v_s_24112;
          break;
        }
        default: heff_nomatch(v_c_24110);
        }
        v_t_24115 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24105_24IsCheckable, TAG_TChk, 1, (V[]){v_c_24110}), v_t_24113});
        break;
      }
      case TAG_IsType: {
        V v_t_24114 = heff_field(v_x1_24105, 0);
        heff_take_n(v_x1_24105, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EAnn, 2);
        v_t_24115 = v_t_24114;
        break;
      }
      default: heff_nomatch(v_x1_24105);
      }
      V v_t_24116 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_24104, v_t_24115}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24116});
    }
    case TAG_ESpec: {
      V v_a_24117 = heff_field(v_x21_242, 0);
      V v_x_24118 = heff_field(v_x21_242, 1);
      V v_fsp_24119 = heff_field(v_x21_242, 2);
      V v_v_24120 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24ESpec = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_24121 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24117}));
      V v_t_24122 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24121));
      V v_x1_24123 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_24120}));
      V v_t_24133;
      switch (heff_tag_of(v_x1_24123)) {
      case TAG_IsInferable: {
        V v_i_24124 = heff_field(v_x1_24123, 0);
        V v_ru_24x1_24123_24IsInferable = heff_take_reuse_n(v_x1_24123, 1ULL, 1);
        V v_t_24127;
        switch (heff_tag_of(v_i_24124)) {
        case TAG_At: {
          V v_s_24126 = heff_dup(heff_field(v_i_24124, 1));
          v_t_24127 = v_s_24126;
          break;
        }
        default: heff_nomatch(v_i_24124);
        }
        v_t_24133 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24123_24IsInferable, TAG_CInf, 1, (V[]){v_i_24124}), v_t_24127});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24128 = heff_field(v_x1_24123, 0);
        heff_take_n(v_x1_24123, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24133 = v_c_24128;
        break;
      }
      case TAG_IsType: {
        V v_t_24129 = heff_field(v_x1_24123, 0);
        V v_ru_24x1_24123_24IsType = heff_take_reuse_n(v_x1_24123, 1ULL, 1);
        V v_t_24132;
        switch (heff_tag_of(v_t_24129)) {
        case TAG_At: {
          V v_s_24131 = heff_dup(heff_field(v_t_24129, 1));
          v_t_24132 = v_s_24131;
          break;
        }
        default: heff_nomatch(v_t_24129);
        }
        v_t_24133 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24123_24IsType, TAG_CType, 1, (V[]){v_t_24129}), v_t_24132});
        break;
      }
      default: heff_nomatch(v_x1_24123);
      }
      V v_t_24134 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESpec, TAG_ISpec, 4, (V[]){v_t_24122, v_x_24118, v_fsp_24119, v_t_24133}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24134});
    }
    case TAG_ESig: {
      V v_fs_24135 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESig = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24136 = (g_list_2emap_24s2016093283x1174801437(v_r_240, v_fs_24135));
      V v_t_24137 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_TSig, 1, (V[]){v_t_24136}), v_sp_243});
      return heff_tag_n(TAG_IsType, 1, (V[]){v_t_24137});
    }
    case TAG_ESum: {
      V v_vs_24138 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESum = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24139 = (g_list_2emap_24s97919758x216970748(v_r_240, v_vs_24138));
      V v_t_24140 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_TSum, 1, (V[]){v_t_24139}), v_sp_243});
      return heff_tag_n(TAG_IsType, 1, (V[]){v_t_24140});
    }
    case TAG_EStruct: {
      V v_fs_24141 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EStruct = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24142 = (g_list_2emap_24s2039279853x710813703(v_r_240, v_fs_24141));
      V v_t_24143 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_CStruct, 1, (V[]){v_t_24142}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24143});
    }
    case TAG_EUpdate: {
      V v_a_24144 = heff_field(v_x21_242, 0);
      V v_fs_24145 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EUpdate = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24146 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24144}));
      V v_t_24147 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24146));
      V v_t_24148 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo), 1, (V[]){v_r_240}));
      V v_t_24149 = (g_list_2emap(v_t_24148, v_fs_24145));
      V v_t_24150 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_IUpdate, 2, (V[]){v_t_24147, v_t_24149}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24150});
    }
    case TAG_EMatch: {
      V v_s_24151 = heff_field(v_x21_242, 0);
      V v_alts_24152 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EMatch = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24153 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24151}));
      V v_t_24154 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24153));
      V v_t_24155 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ealtOf_clo), 1, (V[]){v_r_240}));
      V v_t_24156 = (g_list_2emap(v_t_24155, v_alts_24152));
      V v_t_24157 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_CMatch, 2, (V[]){v_t_24154, v_t_24156}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24157});
    }
    case TAG_ELetIn: {
      V v_rhs_24158 = heff_field(v_x21_242, 0);
      V v_a_24159 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24160 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_24158}));
      V v_t_24161 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24160));
      V v_t_24177;
      switch (heff_tag_of(v_a_24159)) {
      case TAG_At: {
        V v_x21_24162 = heff_field(v_a_24159, 0);
        V v_sp_24163 = heff_field(v_a_24159, 1);
        V v_ru_24a_24159_24At = heff_take_reuse_n(v_a_24159, 3ULL, 2);
        switch (heff_tag_of(v_x21_24162)) {
        case TAG_MkAlt: {
          V v_p_24164 = heff_field(v_x21_24162, 0);
          V v_b_24165 = heff_field(v_x21_24162, 1);
          heff_take_n(v_x21_24162, 3ULL, 2);
          V v_x1_24166 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_24165}));
          V v_t_24176;
          switch (heff_tag_of(v_x1_24166)) {
          case TAG_IsInferable: {
            V v_i_24167 = heff_field(v_x1_24166, 0);
            V v_ru_24x1_24166_24IsInferable = heff_take_reuse_n(v_x1_24166, 1ULL, 1);
            V v_t_24170;
            switch (heff_tag_of(v_i_24167)) {
            case TAG_At: {
              V v_s_24169 = heff_dup(heff_field(v_i_24167, 1));
              v_t_24170 = v_s_24169;
              break;
            }
            default: heff_nomatch(v_i_24167);
            }
            v_t_24176 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24166_24IsInferable, TAG_CInf, 1, (V[]){v_i_24167}), v_t_24170});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24171 = heff_field(v_x1_24166, 0);
            heff_take_n(v_x1_24166, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            v_t_24176 = v_c_24171;
            break;
          }
          case TAG_IsType: {
            V v_t_24172 = heff_field(v_x1_24166, 0);
            V v_ru_24x1_24166_24IsType = heff_take_reuse_n(v_x1_24166, 1ULL, 1);
            V v_t_24175;
            switch (heff_tag_of(v_t_24172)) {
            case TAG_At: {
              V v_s_24174 = heff_dup(heff_field(v_t_24172, 1));
              v_t_24175 = v_s_24174;
              break;
            }
            default: heff_nomatch(v_t_24172);
            }
            v_t_24176 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24166_24IsType, TAG_CType, 1, (V[]){v_t_24172}), v_t_24175});
            break;
          }
          default: heff_nomatch(v_x1_24166);
          }
          v_t_24177 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_24159_24At, TAG_MkAlt, 2, (V[]){v_p_24164, v_t_24176}), v_sp_24163});
          break;
        }
        default: heff_nomatch(v_x21_24162);
        }
        break;
      }
      default: heff_nomatch(v_a_24159);
      }
      V v_t_24178 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24161, v_t_24177}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24178});
    }
    case TAG_EDo: {
      V v_stmts_24179 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EDo = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      HeffT2 v_t_24180 = (g_heff_2esyntax_2epresyntax_2edoBlock_24s1455639597x676970604_24cpr(heff_dup(v_sp_243), v_stmts_24179));
      {
        V v_field_24182 = v_t_24180.f[1];
        int64_t v_tag_24181 = ((int64_t)v_t_24180.f[0]);
        if ((v_tag_24181 == ((int64_t)0ULL))) {
          heff_drop(v_sp_243);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop_cell(v_ru_24x21_242_24EDo, 1);
          V v_e_27_24183 = v_field_24182;
          return heff_tail(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_27_24183});
        } else {
          heff_drop_rec(v_r_240, 2);
          heff_drop(v_field_24182);
          V v_t_24184 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2), NTAG(TAG_Nothing)});
          return heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24184, v_sp_243})});
        }
      }
    }
    case TAG_ELocal: {
      V v_body_24185 = heff_field(v_x21_242, 0);
      V v_ds_24186 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_24187 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 1, (V[]){v_body_24185}));
      V v_t_24197;
      switch (heff_tag_of(v_x1_24187)) {
      case TAG_IsInferable: {
        V v_i_24188 = heff_field(v_x1_24187, 0);
        V v_ru_24x1_24187_24IsInferable = heff_take_reuse_n(v_x1_24187, 1ULL, 1);
        V v_t_24191;
        switch (heff_tag_of(v_i_24188)) {
        case TAG_At: {
          V v_s_24190 = heff_dup(heff_field(v_i_24188, 1));
          v_t_24191 = v_s_24190;
          break;
        }
        default: heff_nomatch(v_i_24188);
        }
        v_t_24197 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24187_24IsInferable, TAG_CInf, 1, (V[]){v_i_24188}), v_t_24191});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24192 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24197 = v_c_24192;
        break;
      }
      case TAG_IsType: {
        V v_t_24193 = heff_field(v_x1_24187, 0);
        V v_ru_24x1_24187_24IsType = heff_take_reuse_n(v_x1_24187, 1ULL, 1);
        V v_t_24196;
        switch (heff_tag_of(v_t_24193)) {
        case TAG_At: {
          V v_s_24195 = heff_dup(heff_field(v_t_24193, 1));
          v_t_24196 = v_s_24195;
          break;
        }
        default: heff_nomatch(v_t_24193);
        }
        v_t_24197 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24187_24IsType, TAG_CType, 1, (V[]){v_t_24193}), v_t_24196});
        break;
      }
      default: heff_nomatch(v_x1_24187);
      }
      V v_t_24198 = (g_list_2emap(heff_get_n(v_r_240, 1, 2), v_ds_24186));
      V v_t_24199 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CLocal, 2, (V[]){v_t_24197, v_t_24198}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24199});
    }
    case TAG_EInvalid: {
      V v_why_24200 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInvalid = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24201 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_why_24200, NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24201, v_sp_243})});
    }
    case TAG_EAssign: {
      V v_x_24202 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EAssign = heff_take_reuse_n(v_x21_242, 1ULL, 3);
      heff_drop_rec(v_r_240, 2);
      V v_t_24205 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3), v_x_24202), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str4));
      V v_t_24206 = heff_tag_at_n(v_ru_24x21_242_24EAssign, TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_t_24205, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24206, v_sp_243})});
    }
    case TAG_EWhile: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_24209 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str5), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24209, v_sp_243})});
    }
    case TAG_EFor: {
      V v_ru_24x21_242_24EFor = heff_take_reuse_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_r_240, 2);
      V v_t_24213 = heff_tag_at_n(v_ru_24x21_242_24EFor, TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str6), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24213, v_sp_243})});
    }
    case TAG_EIfThen: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_24216 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str7), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24216, v_sp_243})});
    }
    case TAG_EBreak: {
      heff_drop_rec(v_r_240, 2);
      V v_t_24217 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str8), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24217, v_sp_243})});
    }
    case TAG_EContinue: {
      heff_drop_rec(v_r_240, 2);
      V v_t_24218 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str9), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24218, v_sp_243})});
    }
    case TAG_EReturn: {
      V v_ru_24x21_242_24EReturn = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24220 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str10), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EReturn, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24220, v_sp_243})});
    }
    case TAG_ENest: {
      V v_ru_24x21_242_24ENest = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24222 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str11), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24ENest, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24222, v_sp_243})});
    }
    case TAG_ELazy: {
      V v_e_24223 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ELazy = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_24224 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24223}));
      V v_t_24234;
      switch (heff_tag_of(v_x1_24224)) {
      case TAG_IsInferable: {
        V v_i_24225 = heff_field(v_x1_24224, 0);
        heff_take_n(v_x1_24224, 1ULL, 1);
        V v_t_24228;
        switch (heff_tag_of(v_i_24225)) {
        case TAG_At: {
          V v_s_24227 = heff_dup(heff_field(v_i_24225, 1));
          v_t_24228 = v_s_24227;
          break;
        }
        default: heff_nomatch(v_i_24225);
        }
        v_t_24234 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ELazy, TAG_CInf, 1, (V[]){v_i_24225}), v_t_24228});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24229 = heff_field(v_x1_24224, 0);
        heff_take_n(v_x1_24224, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        heff_drop_cell(v_ru_24x21_242_24ELazy, 1);
        v_t_24234 = v_c_24229;
        break;
      }
      case TAG_IsType: {
        V v_t_24230 = heff_field(v_x1_24224, 0);
        heff_take_n(v_x1_24224, 1ULL, 1);
        V v_t_24233;
        switch (heff_tag_of(v_t_24230)) {
        case TAG_At: {
          V v_s_24232 = heff_dup(heff_field(v_t_24230, 1));
          v_t_24233 = v_s_24232;
          break;
        }
        default: heff_nomatch(v_t_24230);
        }
        v_t_24234 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ELazy, TAG_CType, 1, (V[]){v_t_24230}), v_t_24233});
        break;
      }
      default: heff_nomatch(v_x1_24224);
      }
      V v_t_24235 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ILazy, 1, (V[]){v_t_24234}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24235});
    }
    case TAG_ETuple: {
      V v_es_24236 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ETuple = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24248 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2eclassifyTermF_lam0, 1, 1, (V[]){v_r_240}), v_es_24236));
      V v_t_24249 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETuple, TAG_ITuple, 1, (V[]){v_t_24248}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24249});
    }
    case TAG_ETry: {
      V v_ru_24x21_242_24ETry = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24251 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str12), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24ETry, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24251, v_sp_243})});
    }
    case TAG_EWith: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_r_240, 2);
      V v_t_24256 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str13), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24256, v_sp_243})});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_lam0(V self, V *args) {
  V v_e_24237 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24238 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24237}));
  switch (heff_tag_of(v_x1_24238)) {
  case TAG_IsInferable: {
    V v_i_24239 = heff_field(v_x1_24238, 0);
    V v_ru_24x1_24238_24IsInferable = heff_take_reuse_n(v_x1_24238, 1ULL, 1);
    V v_t_24242;
    switch (heff_tag_of(v_i_24239)) {
    case TAG_At: {
      V v_s_24241 = heff_dup(heff_field(v_i_24239, 1));
      v_t_24242 = v_s_24241;
      break;
    }
    default: heff_nomatch(v_i_24239);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24238_24IsInferable, TAG_CInf, 1, (V[]){v_i_24239}), v_t_24242});
  }
  case TAG_IsCheckable: {
    V v_c_24243 = heff_field(v_x1_24238, 0);
    heff_take_n(v_x1_24238, 1ULL, 1);
    return v_c_24243;
  }
  case TAG_IsType: {
    V v_t_24244 = heff_field(v_x1_24238, 0);
    V v_ru_24x1_24238_24IsType = heff_take_reuse_n(v_x1_24238, 1ULL, 1);
    V v_t_24247;
    switch (heff_tag_of(v_t_24244)) {
    case TAG_At: {
      V v_s_24246 = heff_dup(heff_field(v_t_24244, 1));
      v_t_24247 = v_s_24246;
      break;
    }
    default: heff_nomatch(v_t_24244);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24238_24IsType, TAG_CType, 1, (V[]){v_t_24244}), v_t_24247});
  }
  default: return heff_nomatch(v_x1_24238);
  }
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xsp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    HeffT3 v_t_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_243));
    V v_t_2417;
    {
      V v_field_246 = v_t_244.f[1];
      V v_field_247 = v_t_244.f[2];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_c_248 = heff_tag_n(TAG_At, 2, (V[]){v_field_246, v_field_247});
        V v_t_2411;
        switch (heff_tag_of(v_c_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_c_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_c_248);
        }
        v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_248}), v_t_2411});
      } else {
        if ((v_tag_245 == ((int64_t)1ULL))) {
          heff_drop(v_field_247);
          V v_i_2412 = v_field_246;
          V v_t_2415;
          switch (heff_tag_of(v_i_2412)) {
          case TAG_At: {
            V v_s_2414 = heff_dup(heff_field(v_i_2412, 1));
            v_t_2415 = v_s_2414;
            break;
          }
          default: heff_nomatch(v_i_2412);
          }
          v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2412}), v_t_2415});
        } else {
          V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){v_field_246, v_field_247});
          v_t_2417 = v_t_2416;
        }
      }
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_241, v_xsp_242, v_t_2417});
  }
  case TAG_PiImplicit: {
    V v_x_2418 = heff_field(v_x2_240, 0);
    V v_xsp_2419 = heff_field(v_x2_240, 1);
    V v_bsp_2420 = heff_field(v_x2_240, 2);
    V v_t_2421 = heff_field(v_x2_240, 3);
    V v_d_2422 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    HeffT3 v_t_2423 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2421));
    V v_t_2436;
    {
      V v_field_2425 = v_t_2423.f[1];
      V v_field_2426 = v_t_2423.f[2];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_c_2427 = heff_tag_n(TAG_At, 2, (V[]){v_field_2425, v_field_2426});
        V v_t_2430;
        switch (heff_tag_of(v_c_2427)) {
        case TAG_At: {
          V v_s_2429 = heff_dup(heff_field(v_c_2427, 1));
          v_t_2430 = v_s_2429;
          break;
        }
        default: heff_nomatch(v_c_2427);
        }
        v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2427}), v_t_2430});
      } else {
        if ((v_tag_2424 == ((int64_t)1ULL))) {
          heff_drop(v_field_2426);
          V v_i_2431 = v_field_2425;
          V v_t_2434;
          switch (heff_tag_of(v_i_2431)) {
          case TAG_At: {
            V v_s_2433 = heff_dup(heff_field(v_i_2431, 1));
            v_t_2434 = v_s_2433;
            break;
          }
          default: heff_nomatch(v_i_2431);
          }
          v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2431}), v_t_2434});
        } else {
          V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){v_field_2425, v_field_2426});
          v_t_2436 = v_t_2435;
        }
      }
    }
    V v_t_2452;
    switch (heff_tag_of(v_d_2422)) {
    case TAG_Nothing: {
      v_t_2452 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2437 = heff_field(v_d_2422, 0);
      V v_ru_24d_2422_24Just = heff_take_reuse_n(v_d_2422, 1ULL, 1);
      HeffT3 v_t_2438 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_2437));
      V v_t_2451;
      {
        V v_field_2440 = v_t_2438.f[1];
        V v_field_2441 = v_t_2438.f[2];
        int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
        if ((v_tag_2439 == ((int64_t)0ULL))) {
          V v_c_2442 = heff_tag_n(TAG_At, 2, (V[]){v_field_2440, v_field_2441});
          v_t_2451 = v_c_2442;
        } else {
          if ((v_tag_2439 == ((int64_t)1ULL))) {
            heff_drop(v_field_2441);
            V v_i_2443 = v_field_2440;
            V v_t_2446;
            switch (heff_tag_of(v_i_2443)) {
            case TAG_At: {
              V v_s_2445 = heff_dup(heff_field(v_i_2443, 1));
              v_t_2446 = v_s_2445;
              break;
            }
            default: heff_nomatch(v_i_2443);
            }
            v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2443}), v_t_2446});
          } else {
            V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){v_field_2440, v_field_2441});
            V v_t_2450;
            switch (heff_tag_of(v_t_2447)) {
            case TAG_At: {
              V v_s_2449 = heff_dup(heff_field(v_t_2447, 1));
              v_t_2450 = v_s_2449;
              break;
            }
            default: heff_nomatch(v_t_2447);
            }
            v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2447}), v_t_2450});
          }
        }
      }
      v_t_2452 = heff_tag_at_n(v_ru_24d_2422_24Just, TAG_Just, 1, (V[]){v_t_2451});
      break;
    }
    default: heff_nomatch(v_d_2422);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2418, v_xsp_2419, v_bsp_2420, v_t_2436, v_t_2452});
  }
  case TAG_PiInstance: {
    V v_x_2453 = heff_field(v_x2_240, 0);
    V v_xsp_2454 = heff_field(v_x2_240, 1);
    V v_bsp_2455 = heff_field(v_x2_240, 2);
    V v_t_2456 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    HeffT3 v_t_2457 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2456));
    V v_t_2470;
    {
      V v_field_2459 = v_t_2457.f[1];
      V v_field_2460 = v_t_2457.f[2];
      int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
      if ((v_tag_2458 == ((int64_t)0ULL))) {
        V v_c_2461 = heff_tag_n(TAG_At, 2, (V[]){v_field_2459, v_field_2460});
        V v_t_2464;
        switch (heff_tag_of(v_c_2461)) {
        case TAG_At: {
          V v_s_2463 = heff_dup(heff_field(v_c_2461, 1));
          v_t_2464 = v_s_2463;
          break;
        }
        default: heff_nomatch(v_c_2461);
        }
        v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2461}), v_t_2464});
      } else {
        if ((v_tag_2458 == ((int64_t)1ULL))) {
          heff_drop(v_field_2460);
          V v_i_2465 = v_field_2459;
          V v_t_2468;
          switch (heff_tag_of(v_i_2465)) {
          case TAG_At: {
            V v_s_2467 = heff_dup(heff_field(v_i_2465, 1));
            v_t_2468 = v_s_2467;
            break;
          }
          default: heff_nomatch(v_i_2465);
          }
          v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2465}), v_t_2468});
        } else {
          V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){v_field_2459, v_field_2460});
          v_t_2470 = v_t_2469;
        }
      }
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2453, v_xsp_2454, v_bsp_2455, v_t_2470});
  }
  case TAG_PiAnon: {
    V v_t_2471 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    HeffT3 v_t_2472 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2471));
    V v_t_2485;
    {
      V v_field_2474 = v_t_2472.f[1];
      V v_field_2475 = v_t_2472.f[2];
      int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
      if ((v_tag_2473 == ((int64_t)0ULL))) {
        V v_c_2476 = heff_tag_n(TAG_At, 2, (V[]){v_field_2474, v_field_2475});
        V v_t_2479;
        switch (heff_tag_of(v_c_2476)) {
        case TAG_At: {
          V v_s_2478 = heff_dup(heff_field(v_c_2476, 1));
          v_t_2479 = v_s_2478;
          break;
        }
        default: heff_nomatch(v_c_2476);
        }
        v_t_2485 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2476}), v_t_2479});
      } else {
        if ((v_tag_2473 == ((int64_t)1ULL))) {
          heff_drop(v_field_2475);
          V v_i_2480 = v_field_2474;
          V v_t_2483;
          switch (heff_tag_of(v_i_2480)) {
          case TAG_At: {
            V v_s_2482 = heff_dup(heff_field(v_i_2480, 1));
            v_t_2483 = v_s_2482;
            break;
          }
          default: heff_nomatch(v_i_2480);
          }
          v_t_2485 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2480}), v_t_2483});
        } else {
          V v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){v_field_2474, v_field_2475});
          v_t_2485 = v_t_2484;
        }
      }
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2485});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str1, 11, "bytesConcat");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str2, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str3, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str4, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str6, 67, " := e` sets a `let mut` variable: it is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str7, 45, "a `while` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str8, 43, "a `for` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str9, 78, "an `if` without `else` is a statement of a `do` block: a value's has an `else`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str10, 78, "`break` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str11, 81, "`continue` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str12, 103, "`return e` ends a `do` block as one of its statements (or an arm of its `if` or `case`), not as a value");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str13, 67, "`(<- c)`, the value of an action, is in a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str14, 72, "a `try` is a statement of a `do` block (or an arm of its `if` or `case`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str15, 73, "a `with` is a statement of a `do` block (or an arm of its `if` or `case`)");

HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EVar = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EVar, TAG_IVar, 1, (V[]){v_x_243}), v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_244, MK_INT(0LL)}});
    }
    case TAG_EImplicitVar: {
      V v_x_245 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EImplicitVar = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_246 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EImplicitVar, TAG_IVar, 1, (V[]){v_x_245}), v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_246, MK_INT(0LL)}});
    }
    case TAG_ENotationVar: {
      V v_x_247 = heff_field(v_x21_241, 0);
      V v_ksp_248 = heff_field(v_x21_241, 1);
      V v_said_249 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ENotationVar = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ENotationVar, TAG_INotationVar, 3, (V[]){v_x_247, v_ksp_248, v_said_249}), v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2410, MK_INT(0LL)}});
    }
    case TAG_ETag: {
      V v_t_2411 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2412 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_2411, heff_dup(v_sp_242), NTAG(TAG_Nil)});
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_2412, v_sp_242}});
    }
    case TAG_EInt: {
      V v_i_2413 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EInt = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EInt, TAG_IInt, 1, (V[]){v_i_2413}), v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2414, MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      V v_x_2415 = heff_tget_v(v_x21_241, 0);
      V v_ru_24x21_241_24EFloat = heff_take_reuse_nf(v_x21_241, 0ULL, 1);
      V v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EFloat, TAG_IFloat, 1, (V[]){v_x_2415}), v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2416, MK_INT(0LL)}});
    }
    case TAG_EString: {
      V v_x_2417 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EString = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EString, TAG_IString, 1, (V[]){v_x_2417}), v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2418, MK_INT(0LL)}});
    }
    case TAG_EBinary: {
      V v_segs_2419 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EBinary = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_asBits_2420 = NTAG(TAG_False);
      V v_segs_2421 = v_segs_2419;
      V v_sp_2422 = v_sp_242;
      if ((heff_dup(v_asBits_2420) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
        return ({ V a_0 = v_segs_2421; V a_1 = v_sp_2422; V b_2 = NTAG(TAG_False); HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      } else {
        V v_t_2423 = (g_list_2eany_24s689038521x519269801(v_segs_2421));
        if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
          heff_drop(v_t_2423);
          return ({ V a_0 = v_segs_2421; V a_1 = v_sp_2422; V b_2 = NTAG(TAG_False); HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        } else {
          heff_drop(v_t_2423);
          V v_t_2424 = (g_list_2emap_24s34825065x1144190520(heff_dup(v_segs_2421)));
          HeffT2 v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = MK_INT(0LL); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(a_0, a_1)); heff_drop(v_t_2424); r_; });
          {
            V v_field_2427 = v_t_2425.f[1];
            int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
            if ((v_tag_2426 == ((int64_t)0ULL))) {
              V v_n_2428 = v_field_2427;
              if (!heff_intEq_c_lent(v_n_2428, MK_INT(0LL), 2)) {
                heff_drop_cell(v_ru_24x2_240_24At, 2);
                heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
                heff_drop(v_n_2428);
                return ({ V a_0 = v_segs_2421; V a_1 = v_sp_2422; V b_2 = NTAG(TAG_False); HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
              } else {
                heff_drop(v_n_2428);
                V v_x1_2429 = (g_list_2eany_24s689038521x519269801(v_segs_2421));
                if (!(heff_dup(v_x1_2429) == NTAG(TAG_True))) {
                  heff_drop(v_x1_2429);
                  V v_t_2430 = (g_list_2eall_24s1414119352x995333365(MK_INT(0LL), v_segs_2421));
                  if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
                    heff_drop(v_t_2430);
                    V v_segs_2431 = heff_dup(v_segs_2421);
                    V v_sp_2432 = v_sp_2422;
                    HeffT2 v_t_2433 = ({ V a_0 = v_segs_2421; V a_1 = ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str0); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ewholeBinary_24cpr(a_0, a_1)); heff_drop(v_segs_2421); r_; });
                    {
                      V v_field_2435 = v_t_2433.f[1];
                      int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
                      if ((v_tag_2434 == ((int64_t)0ULL))) {
                        heff_drop(v_segs_2431);
                        V v_s_2436 = v_field_2435;
                        V v_t_2437 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EBinary, TAG_IBytes, 1, (V[]){v_s_2436}), v_sp_2432});
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2437, MK_INT(0LL)}});
                      } else {
                        heff_drop(v_field_2435);
                        V v_xs_2438 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(v_segs_2431, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
                        V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2438));
                        V v_t_2440 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2439, heff_dup(v_sp_2432)));
                        V v_args_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
                        V v_t_2442 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EBinary, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str1)}), heff_dup(v_sp_2432)});
                        V v_t_2443 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2432), v_args_2441));
                        V v_f_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2442, v_t_2443}), v_sp_2432});
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_2444, MK_INT(0LL)}});
                      }
                    }
                  } else {
                    heff_drop_cell(v_ru_24x2_240_24At, 2);
                    heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
                    heff_drop(v_t_2430);
                    return ({ V a_0 = v_segs_2421; V a_1 = v_sp_2422; V b_2 = NTAG(TAG_True); HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
                  }
                } else {
                  heff_drop_cell(v_ru_24x2_240_24At, 2);
                  heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
                  heff_drop(v_x1_2429);
                  return ({ V a_0 = v_segs_2421; V a_1 = v_sp_2422; V b_2 = NTAG(TAG_True); HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
                }
              }
            } else {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
              heff_drop(v_field_2427);
              return ({ V a_0 = v_segs_2421; V a_1 = v_sp_2422; V b_2 = NTAG(TAG_False); HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
            }
          }
        }
      }
    }
    case TAG_ERune: {
      V v_c_2445 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ERune = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2446 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ERune, TAG_IRune, 1, (V[]){v_c_2445}), v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2446, MK_INT(0LL)}});
    }
    case TAG_EWord: {
      V v_w_2447 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(v_w_2447, v_sp_242));
    }
    case TAG_EApp: {
      V v_h_2448 = heff_field(v_x21_241, 0);
      V v_args_2449 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2450 = (g_heff_2esyntax_2epresyntax_2erunArgs(heff_dup(v_h_2448), v_args_2449));
      return (g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(v_h_2448, v_t_2450, v_sp_242));
    }
    case TAG_EProject: {
      heff_take_n(v_x21_241, 0ULL, 1);
      V v_t_2452 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str2), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2452, v_sp_242}), MK_INT(0LL)}});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_241, 0ULL, 2);
      V v_t_2455 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str3), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2455, v_sp_242}), MK_INT(0LL)}});
    }
    case TAG_EPi: {
      V v_b_2456 = heff_field(v_x21_241, 0);
      V v_cod_2457 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EPi = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_2458 = (g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(v_b_2456));
      HeffT3 v_t_2459 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_cod_2457));
      V v_t_2472;
      {
        V v_field_2461 = v_t_2459.f[1];
        V v_field_2462 = v_t_2459.f[2];
        int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
        if ((v_tag_2460 == ((int64_t)0ULL))) {
          V v_c_2463 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2461, v_field_2462});
          V v_t_2466;
          switch (heff_tag_of(v_c_2463)) {
          case TAG_At: {
            V v_s_2465 = heff_dup(heff_field(v_c_2463, 1));
            v_t_2466 = v_s_2465;
            break;
          }
          default: heff_nomatch(v_c_2463);
          }
          v_t_2472 = heff_tag_at_n(v_ru_24x21_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2463}), v_t_2466});
        } else {
          heff_drop_cell(v_ru_24x21_241_24EPi, 2);
          if ((v_tag_2460 == ((int64_t)1ULL))) {
            heff_drop(v_field_2462);
            V v_i_2467 = v_field_2461;
            V v_t_2470;
            switch (heff_tag_of(v_i_2467)) {
            case TAG_At: {
              V v_s_2469 = heff_dup(heff_field(v_i_2467, 1));
              v_t_2470 = v_s_2469;
              break;
            }
            default: heff_nomatch(v_i_2467);
            }
            v_t_2472 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2467}), v_t_2470});
          } else {
            V v_t_2471 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2461, v_field_2462});
            v_t_2472 = v_t_2471;
          }
        }
      }
      V v_f_2473 = heff_tag_n(TAG_TPi, 2, (V[]){v_t_2458, v_t_2472});
      return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), v_f_2473, v_sp_242}});
    }
    case TAG_ELam: {
      V v_x211_2474 = heff_field(v_x21_241, 0);
      V v_body_2475 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELam = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      switch (heff_tag_of(v_x211_2474)) {
      case TAG_LamName: {
        V v_x_2476 = heff_field(v_x211_2474, 0);
        V v_xsp_2477 = heff_field(v_x211_2474, 1);
        heff_take_n(v_x211_2474, 3ULL, 2);
        HeffT3 v_t_2478 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2475));
        V v_t_2491;
        {
          V v_field_2480 = v_t_2478.f[1];
          V v_field_2481 = v_t_2478.f[2];
          int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
          if ((v_tag_2479 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x21_241_24ELam, 2);
            V v_c_2482 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2480, v_field_2481});
            v_t_2491 = v_c_2482;
          } else {
            if ((v_tag_2479 == ((int64_t)1ULL))) {
              heff_drop_cell(v_ru_24x21_241_24ELam, 2);
              heff_drop(v_field_2481);
              V v_i_2483 = v_field_2480;
              V v_t_2486;
              switch (heff_tag_of(v_i_2483)) {
              case TAG_At: {
                V v_s_2485 = heff_dup(heff_field(v_i_2483, 1));
                v_t_2486 = v_s_2485;
                break;
              }
              default: heff_nomatch(v_i_2483);
              }
              v_t_2491 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2483}), v_t_2486});
            } else {
              V v_t_2487 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2480, v_field_2481});
              V v_t_2490;
              switch (heff_tag_of(v_t_2487)) {
              case TAG_At: {
                V v_s_2489 = heff_dup(heff_field(v_t_2487, 1));
                v_t_2490 = v_s_2489;
                break;
              }
              default: heff_nomatch(v_t_2487);
              }
              v_t_2491 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2487}), v_t_2490});
            }
          }
        }
        V v_f_2492 = heff_tag_n(TAG_CLam, 3, (V[]){v_x_2476, v_xsp_2477, v_t_2491});
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2492, v_sp_242}});
      }
      case TAG_LamImplicit: {
        V v_x_2493 = heff_field(v_x211_2474, 0);
        V v_xsp_2494 = heff_field(v_x211_2474, 1);
        heff_take_n(v_x211_2474, 3ULL, 2);
        HeffT3 v_t_2495 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2475));
        V v_t_24108;
        {
          V v_field_2497 = v_t_2495.f[1];
          V v_field_2498 = v_t_2495.f[2];
          int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
          if ((v_tag_2496 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x21_241_24ELam, 2);
            V v_c_2499 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2497, v_field_2498});
            v_t_24108 = v_c_2499;
          } else {
            if ((v_tag_2496 == ((int64_t)1ULL))) {
              heff_drop_cell(v_ru_24x21_241_24ELam, 2);
              heff_drop(v_field_2498);
              V v_i_24100 = v_field_2497;
              V v_t_24103;
              switch (heff_tag_of(v_i_24100)) {
              case TAG_At: {
                V v_s_24102 = heff_dup(heff_field(v_i_24100, 1));
                v_t_24103 = v_s_24102;
                break;
              }
              default: heff_nomatch(v_i_24100);
              }
              v_t_24108 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24100}), v_t_24103});
            } else {
              V v_t_24104 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2497, v_field_2498});
              V v_t_24107;
              switch (heff_tag_of(v_t_24104)) {
              case TAG_At: {
                V v_s_24106 = heff_dup(heff_field(v_t_24104, 1));
                v_t_24107 = v_s_24106;
                break;
              }
              default: heff_nomatch(v_t_24104);
              }
              v_t_24108 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24104}), v_t_24107});
            }
          }
        }
        V v_f_24109 = heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2493, v_xsp_2494, v_t_24108});
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_24109, v_sp_242}});
      }
      case TAG_LamAnn: {
        V v_x_24110 = heff_field(v_x211_2474, 0);
        V v_xsp_24111 = heff_field(v_x211_2474, 1);
        V v_t_24112 = heff_field(v_x211_2474, 2);
        heff_take_n(v_x211_2474, 7ULL, 3);
        HeffT3 v_t_24113 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_24112));
        V v_t_24126;
        {
          V v_field_24115 = v_t_24113.f[1];
          V v_field_24116 = v_t_24113.f[2];
          int64_t v_tag_24114 = ((int64_t)v_t_24113.f[0]);
          if ((v_tag_24114 == ((int64_t)0ULL))) {
            V v_c_24117 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24115, v_field_24116});
            V v_t_24120;
            switch (heff_tag_of(v_c_24117)) {
            case TAG_At: {
              V v_s_24119 = heff_dup(heff_field(v_c_24117, 1));
              v_t_24120 = v_s_24119;
              break;
            }
            default: heff_nomatch(v_c_24117);
            }
            v_t_24126 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24117}), v_t_24120});
          } else {
            heff_drop_cell(v_ru_24x21_241_24ELam, 2);
            if ((v_tag_24114 == ((int64_t)1ULL))) {
              heff_drop(v_field_24116);
              V v_i_24121 = v_field_24115;
              V v_t_24124;
              switch (heff_tag_of(v_i_24121)) {
              case TAG_At: {
                V v_s_24123 = heff_dup(heff_field(v_i_24121, 1));
                v_t_24124 = v_s_24123;
                break;
              }
              default: heff_nomatch(v_i_24121);
              }
              v_t_24126 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_24121}), v_t_24124});
            } else {
              V v_t_24125 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24115, v_field_24116});
              v_t_24126 = v_t_24125;
            }
          }
        }
        V v_t_24127 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2475));
        return (g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(v_x_24110, v_xsp_24111, v_t_24126, v_t_24127, v_sp_242));
      }
      default: return ((HeffT3){{heff_nomatch(v_x211_2474)}});
      }
    }
    case TAG_EAnn: {
      V v_a_24128 = heff_field(v_x21_241, 0);
      V v_t_24129 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EAnn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT3 v_t_24130 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_a_24128));
      V v_t_24143;
      {
        V v_field_24132 = v_t_24130.f[1];
        V v_field_24133 = v_t_24130.f[2];
        int64_t v_tag_24131 = ((int64_t)v_t_24130.f[0]);
        if ((v_tag_24131 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EAnn, 2);
          V v_c_24134 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24132, v_field_24133});
          v_t_24143 = v_c_24134;
        } else {
          if ((v_tag_24131 == ((int64_t)1ULL))) {
            heff_drop_cell(v_ru_24x21_241_24EAnn, 2);
            heff_drop(v_field_24133);
            V v_i_24135 = v_field_24132;
            V v_t_24138;
            switch (heff_tag_of(v_i_24135)) {
            case TAG_At: {
              V v_s_24137 = heff_dup(heff_field(v_i_24135, 1));
              v_t_24138 = v_s_24137;
              break;
            }
            default: heff_nomatch(v_i_24135);
            }
            v_t_24143 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24135}), v_t_24138});
          } else {
            V v_t_24139 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24132, v_field_24133});
            V v_t_24142;
            switch (heff_tag_of(v_t_24139)) {
            case TAG_At: {
              V v_s_24141 = heff_dup(heff_field(v_t_24139, 1));
              v_t_24142 = v_s_24141;
              break;
            }
            default: heff_nomatch(v_t_24139);
            }
            v_t_24143 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24139}), v_t_24142});
          }
        }
      }
      HeffT3 v_t_24144 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_24129));
      V v_t_24157;
      {
        V v_field_24146 = v_t_24144.f[1];
        V v_field_24147 = v_t_24144.f[2];
        int64_t v_tag_24145 = ((int64_t)v_t_24144.f[0]);
        if ((v_tag_24145 == ((int64_t)0ULL))) {
          V v_c_24148 = heff_tag_n(TAG_At, 2, (V[]){v_field_24146, v_field_24147});
          V v_t_24151;
          switch (heff_tag_of(v_c_24148)) {
          case TAG_At: {
            V v_s_24150 = heff_dup(heff_field(v_c_24148, 1));
            v_t_24151 = v_s_24150;
            break;
          }
          default: heff_nomatch(v_c_24148);
          }
          v_t_24157 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24148}), v_t_24151});
        } else {
          if ((v_tag_24145 == ((int64_t)1ULL))) {
            heff_drop(v_field_24147);
            V v_i_24152 = v_field_24146;
            V v_t_24155;
            switch (heff_tag_of(v_i_24152)) {
            case TAG_At: {
              V v_s_24154 = heff_dup(heff_field(v_i_24152, 1));
              v_t_24155 = v_s_24154;
              break;
            }
            default: heff_nomatch(v_i_24152);
            }
            v_t_24157 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_24152}), v_t_24155});
          } else {
            V v_t_24156 = heff_tag_n(TAG_At, 2, (V[]){v_field_24146, v_field_24147});
            v_t_24157 = v_t_24156;
          }
        }
      }
      V v_f_24158 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_24143, v_t_24157}), v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_24158, MK_INT(0LL)}});
    }
    case TAG_ESpec: {
      V v_a_24159 = heff_field(v_x21_241, 0);
      V v_x_24160 = heff_field(v_x21_241, 1);
      V v_fsp_24161 = heff_field(v_x21_241, 2);
      V v_v_24162 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24ESpec = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_t_24163 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_24159));
      V v_t_24164 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24163));
      HeffT3 v_t_24165 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_24162));
      V v_t_24178;
      {
        V v_field_24167 = v_t_24165.f[1];
        V v_field_24168 = v_t_24165.f[2];
        int64_t v_tag_24166 = ((int64_t)v_t_24165.f[0]);
        if ((v_tag_24166 == ((int64_t)0ULL))) {
          V v_c_24169 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24167, v_field_24168});
          v_t_24178 = v_c_24169;
        } else {
          if ((v_tag_24166 == ((int64_t)1ULL))) {
            heff_drop(v_field_24168);
            V v_i_24170 = v_field_24167;
            V v_t_24173;
            switch (heff_tag_of(v_i_24170)) {
            case TAG_At: {
              V v_s_24172 = heff_dup(heff_field(v_i_24170, 1));
              v_t_24173 = v_s_24172;
              break;
            }
            default: heff_nomatch(v_i_24170);
            }
            v_t_24178 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24170}), v_t_24173});
          } else {
            V v_t_24174 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24167, v_field_24168});
            V v_t_24177;
            switch (heff_tag_of(v_t_24174)) {
            case TAG_At: {
              V v_s_24176 = heff_dup(heff_field(v_t_24174, 1));
              v_t_24177 = v_s_24176;
              break;
            }
            default: heff_nomatch(v_t_24174);
            }
            v_t_24178 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24174}), v_t_24177});
          }
        }
      }
      V v_f_24179 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESpec, TAG_ISpec, 4, (V[]){v_t_24164, v_x_24160, v_fsp_24161, v_t_24178}), v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_24179, MK_INT(0LL)}});
    }
    case TAG_ESig: {
      V v_fs_24180 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ESig = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24181 = (g_list_2emap_24s205414595x1692305030(v_fs_24180));
      V v_f_24182 = heff_tag_at_n(v_ru_24x21_241_24ESig, TAG_TSig, 1, (V[]){v_t_24181});
      return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), v_f_24182, v_sp_242}});
    }
    case TAG_ESum: {
      V v_vs_24183 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ESum = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24184 = (g_list_2emap_24s1258450377x973220636(v_vs_24183));
      V v_f_24185 = heff_tag_at_n(v_ru_24x21_241_24ESum, TAG_TSum, 1, (V[]){v_t_24184});
      return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), v_f_24185, v_sp_242}});
    }
    case TAG_EStruct: {
      V v_fs_24186 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EStruct = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24187 = (g_list_2emap_24s961097229x1129443801(v_fs_24186));
      V v_f_24188 = heff_tag_at_n(v_ru_24x21_241_24EStruct, TAG_CStruct, 1, (V[]){v_t_24187});
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_24188, v_sp_242}});
    }
    case TAG_EUpdate: {
      V v_a_24189 = heff_field(v_x21_241, 0);
      V v_fs_24190 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EUpdate = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_24191 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_24189));
      V v_t_24192 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24191));
      V v_t_24193 = (g_list_2emap_24s137457135x961689574(v_fs_24190));
      V v_f_24194 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EUpdate, TAG_IUpdate, 2, (V[]){v_t_24192, v_t_24193}), v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_24194, MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      V v_s_24195 = heff_field(v_x21_241, 0);
      V v_alts_24196 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EMatch = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24197 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_s_24195));
      V v_t_24198 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24197));
      V v_t_24199 = (g_list_2emap_24s1230969749x2018313496(v_alts_24196));
      V v_f_24200 = heff_tag_at_n(v_ru_24x21_241_24EMatch, TAG_CMatch, 2, (V[]){v_t_24198, v_t_24199});
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_24200, v_sp_242}});
    }
    case TAG_ELetIn: {
      V v_rhs_24201 = heff_field(v_x21_241, 0);
      V v_a_24202 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELetIn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_24203 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_rhs_24201));
      V v_t_24204 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24203));
      V v_t_24223;
      switch (heff_tag_of(v_a_24202)) {
      case TAG_At: {
        V v_x21_24205 = heff_field(v_a_24202, 0);
        V v_sp_24206 = heff_field(v_a_24202, 1);
        V v_ru_24a_24202_24At = heff_take_reuse_n(v_a_24202, 3ULL, 2);
        switch (heff_tag_of(v_x21_24205)) {
        case TAG_MkAlt: {
          V v_p_24207 = heff_field(v_x21_24205, 0);
          V v_b_24208 = heff_field(v_x21_24205, 1);
          V v_ru_24x21_24205_24MkAlt = heff_take_reuse_n(v_x21_24205, 3ULL, 2);
          HeffT3 v_t_24209 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_b_24208));
          V v_t_24222;
          {
            V v_field_24211 = v_t_24209.f[1];
            V v_field_24212 = v_t_24209.f[2];
            int64_t v_tag_24210 = ((int64_t)v_t_24209.f[0]);
            if ((v_tag_24210 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x21_241_24ELetIn, 2);
              V v_c_24213 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24211, v_field_24212});
              v_t_24222 = v_c_24213;
            } else {
              if ((v_tag_24210 == ((int64_t)1ULL))) {
                heff_drop_cell(v_ru_24x21_241_24ELetIn, 2);
                heff_drop(v_field_24212);
                V v_i_24214 = v_field_24211;
                V v_t_24217;
                switch (heff_tag_of(v_i_24214)) {
                case TAG_At: {
                  V v_s_24216 = heff_dup(heff_field(v_i_24214, 1));
                  v_t_24217 = v_s_24216;
                  break;
                }
                default: heff_nomatch(v_i_24214);
                }
                v_t_24222 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24214}), v_t_24217});
              } else {
                V v_t_24218 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24211, v_field_24212});
                V v_t_24221;
                switch (heff_tag_of(v_t_24218)) {
                case TAG_At: {
                  V v_s_24220 = heff_dup(heff_field(v_t_24218, 1));
                  v_t_24221 = v_s_24220;
                  break;
                }
                default: heff_nomatch(v_t_24218);
                }
                v_t_24222 = heff_tag_at_n(v_ru_24x21_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24218}), v_t_24221});
              }
            }
          }
          v_t_24223 = heff_tag_at_n(v_ru_24a_24202_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_24205_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_24207, v_t_24222}), v_sp_24206});
          break;
        }
        default: heff_nomatch(v_x21_24205);
        }
        break;
      }
      default: heff_nomatch(v_a_24202);
      }
      V v_f_24224 = heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24204, v_t_24223});
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_24224, v_sp_242}});
    }
    case TAG_EDo: {
      V v_stmts_24225 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      HeffT2 v_t_24226 = (g_heff_2esyntax_2epresyntax_2edoBlock_24s1455639597x676970604_24cpr(heff_dup(v_sp_242), v_stmts_24225));
      {
        V v_field_24228 = v_t_24226.f[1];
        int64_t v_tag_24227 = ((int64_t)v_t_24226.f[0]);
        if ((v_tag_24227 == ((int64_t)0ULL))) {
          heff_drop(v_sp_242);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_e_27_24229 = v_field_24228;
          V t_0 = v_e_27_24229;
          v_x2_240 = t_0;
          goto top;
        } else {
          heff_drop(v_field_24228);
          V v_t_24230 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str4), NTAG(TAG_Nothing)});
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24230, v_sp_242}), MK_INT(0LL)}});
        }
      }
    }
    case TAG_ELocal: {
      V v_body_24231 = heff_field(v_x21_241, 0);
      V v_ds_24232 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELocal = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT3 v_t_24233 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_24231));
      V v_t_24246;
      {
        V v_field_24235 = v_t_24233.f[1];
        V v_field_24236 = v_t_24233.f[2];
        int64_t v_tag_24234 = ((int64_t)v_t_24233.f[0]);
        if ((v_tag_24234 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ELocal, 2);
          V v_c_24237 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24235, v_field_24236});
          v_t_24246 = v_c_24237;
        } else {
          if ((v_tag_24234 == ((int64_t)1ULL))) {
            heff_drop_cell(v_ru_24x21_241_24ELocal, 2);
            heff_drop(v_field_24236);
            V v_i_24238 = v_field_24235;
            V v_t_24241;
            switch (heff_tag_of(v_i_24238)) {
            case TAG_At: {
              V v_s_24240 = heff_dup(heff_field(v_i_24238, 1));
              v_t_24241 = v_s_24240;
              break;
            }
            default: heff_nomatch(v_i_24238);
            }
            v_t_24246 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24238}), v_t_24241});
          } else {
            V v_t_24242 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24235, v_field_24236});
            V v_t_24245;
            switch (heff_tag_of(v_t_24242)) {
            case TAG_At: {
              V v_s_24244 = heff_dup(heff_field(v_t_24242, 1));
              v_t_24245 = v_s_24244;
              break;
            }
            default: heff_nomatch(v_t_24242);
            }
            v_t_24246 = heff_tag_at_n(v_ru_24x21_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24242}), v_t_24245});
          }
        }
      }
      V v_t_24247 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2esyntax_2epresyntax_2eclassifier_get(), 1)), v_ds_24232));
      V v_f_24248 = heff_tag_n(TAG_CLocal, 2, (V[]){v_t_24246, v_t_24247});
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_24248, v_sp_242}});
    }
    case TAG_EInvalid: {
      V v_why_24249 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24250 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_why_24249, NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24250, v_sp_242}), MK_INT(0LL)}});
    }
    case TAG_EAssign: {
      V v_x_24251 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EAssign = heff_take_reuse_n(v_x21_241, 1ULL, 3);
      V v_t_24254 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str5), v_x_24251), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str6));
      V v_t_24255 = heff_tag_at_n(v_ru_24x21_241_24EAssign, TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_t_24254, NTAG(TAG_Nothing)});
      V v_f_24256 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24255, v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_24256, MK_INT(0LL)}});
    }
    case TAG_EWhile: {
      heff_take_n(v_x21_241, 0ULL, 2);
      V v_t_24259 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str7), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24259, v_sp_242}), MK_INT(0LL)}});
    }
    case TAG_EFor: {
      V v_ru_24x21_241_24EFor = heff_take_reuse_n(v_x21_241, 0ULL, 3);
      V v_t_24263 = heff_tag_at_n(v_ru_24x21_241_24EFor, TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str8), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24263, v_sp_242}), MK_INT(0LL)}});
    }
    case TAG_EIfThen: {
      heff_take_n(v_x21_241, 0ULL, 2);
      V v_t_24266 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str9), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24266, v_sp_242}), MK_INT(0LL)}});
    }
    case TAG_EBreak: {
      V v_t_24267 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str10), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24267, v_sp_242}), MK_INT(0LL)}});
    }
    case TAG_EContinue: {
      V v_t_24268 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str11), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24268, v_sp_242}), MK_INT(0LL)}});
    }
    case TAG_EReturn: {
      heff_take_n(v_x21_241, 0ULL, 1);
      V v_t_24270 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str12), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24270, v_sp_242}), MK_INT(0LL)}});
    }
    case TAG_ENest: {
      heff_take_n(v_x21_241, 0ULL, 1);
      V v_t_24272 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str13), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24272, v_sp_242}), MK_INT(0LL)}});
    }
    case TAG_ELazy: {
      V v_e_24273 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ELazy = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      HeffT3 v_t_24274 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_24273));
      V v_t_24287;
      {
        V v_field_24276 = v_t_24274.f[1];
        V v_field_24277 = v_t_24274.f[2];
        int64_t v_tag_24275 = ((int64_t)v_t_24274.f[0]);
        if ((v_tag_24275 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ELazy, 1);
          V v_c_24278 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24276, v_field_24277});
          v_t_24287 = v_c_24278;
        } else {
          if ((v_tag_24275 == ((int64_t)1ULL))) {
            heff_drop(v_field_24277);
            V v_i_24279 = v_field_24276;
            V v_t_24282;
            switch (heff_tag_of(v_i_24279)) {
            case TAG_At: {
              V v_s_24281 = heff_dup(heff_field(v_i_24279, 1));
              v_t_24282 = v_s_24281;
              break;
            }
            default: heff_nomatch(v_i_24279);
            }
            v_t_24287 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ELazy, TAG_CInf, 1, (V[]){v_i_24279}), v_t_24282});
          } else {
            V v_t_24283 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24276, v_field_24277});
            V v_t_24286;
            switch (heff_tag_of(v_t_24283)) {
            case TAG_At: {
              V v_s_24285 = heff_dup(heff_field(v_t_24283, 1));
              v_t_24286 = v_s_24285;
              break;
            }
            default: heff_nomatch(v_t_24283);
            }
            v_t_24287 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ELazy, TAG_CType, 1, (V[]){v_t_24283}), v_t_24286});
          }
        }
      }
      V v_f_24288 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ILazy, 1, (V[]){v_t_24287}), v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_24288, MK_INT(0LL)}});
    }
    case TAG_ETuple: {
      V v_es_24289 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ETuple = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_24290 = (g_list_2emap_24s1844509821x2028168277(v_es_24289));
      V v_f_24291 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ETuple, TAG_ITuple, 1, (V[]){v_t_24290}), v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_24291, MK_INT(0LL)}});
    }
    case TAG_ETry: {
      heff_take_n(v_x21_241, 0ULL, 1);
      V v_t_24293 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str14), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24293, v_sp_242}), MK_INT(0LL)}});
    }
    case TAG_EWith: {
      heff_take_n(v_x21_241, 0ULL, 4);
      V v_t_24298 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str15), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24298, v_sp_242}), MK_INT(0LL)}});
    }
    default: return ((HeffT3){{heff_nomatch(v_x21_241)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V v_x2_240) {
top: ;
  HeffT3 v_t_241 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x2_240));
  {
    V v_field_243 = v_t_241.f[1];
    V v_field_244 = v_t_241.f[2];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_243, v_field_244})});
    } else {
      if ((v_tag_242 == ((int64_t)1ULL))) {
        heff_drop(v_field_244);
        return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_243});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_243, v_field_244})});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1(V v_tok_240, V v_r_241, V v_asBits_242, V v_segs_243, V v_sp_244) {
top: ;
  HeffT1 v_t_245 = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(v_r_241, v_asBits_242, v_segs_243, v_sp_244));
  {
    V v_field_246 = v_t_245.f[0];
    return heff_tag_at_n(v_tok_240, TAG_IsInferable, 1, (V[]){v_field_246});
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(V v_tok_240, V v_sp_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_IAnn: {
    V v_c_243 = heff_field(v_n_242, 0);
    V v_t_244 = heff_field(v_n_242, 1);
    V v_ru_24n_242_24IAnn = heff_take_reuse_n(v_n_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_c_243)) {
    case TAG_At: {
      V v_n_245 = heff_field(v_c_243, 0);
      V v_sp_246 = heff_field(v_c_243, 1);
      heff_take_n(v_c_243, 3ULL, 2);
      v_t_247 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_246, v_n_245));
      break;
    }
    default: heff_nomatch(v_c_243);
    }
    V v_t_2410;
    switch (heff_tag_of(v_t_244)) {
    case TAG_At: {
      V v_n_248 = heff_field(v_t_244, 0);
      V v_sp_249 = heff_field(v_t_244, 1);
      V v_ru_24t_244_24At = heff_take_reuse_n(v_t_244, 3ULL, 2);
      v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_244_24At, v_sp_249, v_n_248));
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_242_24IAnn, TAG_IAnn, 2, (V[]){v_t_247, v_t_2410}), v_sp_241});
  }
  case TAG_IInvalid: {
    V v_code_2411 = heff_field(v_n_242, 0);
    V v_why_2412 = heff_field(v_n_242, 1);
    V v_note_2413 = heff_field(v_n_242, 2);
    V v_ru_24n_242_24IInvalid = heff_take_reuse_n(v_n_242, 7ULL, 3);
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_242_24IInvalid, TAG_IInvalid, 3, (V[]){v_code_2411, v_why_2412, v_note_2413}), v_sp_241});
  }
  default: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2415 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_241});
  }
  }
}
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(V v_tok_240, V v_cx_241, V v_sp_242, V v_j_243) {
top: ;
  V v_depth_244 = heff_take_field(v_j_243, 3);
  V v_head_245 = heff_take_field(v_j_243, 0);
  V v_vars_246 = heff_take_field(v_j_243, 1);
  V v_unit_247 = heff_get_n(v_j_243, 2, 4);
  V v_t_248 = heff_intSub(heff_dup(heff_rfield(v_cx_241, 4)), v_depth_244);
  V v_vars_249 = v_vars_246;
  V v_t_2413;
  if ((heff_dup(v_unit_247) == NTAG(TAG_True))) {
    heff_drop(v_unit_247);
    switch (heff_tag_of(v_vars_249)) {
    case TAG_Nil: {
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_str0)}), heff_dup(v_sp_242)});
      v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      heff_drop_cell(v_tok_240, 1);
      v_t_2413 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_249));
      break;
    }
    default: heff_nomatch(v_vars_249);
    }
  } else {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_unit_247);
    v_t_2413 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_249));
  }
  V v_t_2414 = (g_heff_2esyntax_2epresyntax_2eapp(v_head_245, v_t_2413));
  HEFF_LAST return g_heff_2esyntax_2epresyntax_2eleaving(v_cx_241, v_sp_242, v_t_248, v_t_2414);
}
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_str0, 5, "join#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_str1, 5, "join#");
Clo g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2(V v_tok_240, V v_lit_241, V v_lit_242, V v_cx_243, V v_sp_244, V v_scope_245, V v_end_246) {
top: ;
  V v_t_247 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
  V v_t_248 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_str0), v_t_247)});
  V v_t_249 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, heff_dup(v_sp_244)}), heff_dup(heff_rfield(v_cx_243, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_243, 4))});
  V v_t_2410 = heff_tr(heff_call(v_scope_245, 1, (V[]){heff_tag_n(TAG_EndJump, 1, (V[]){v_t_249})}));
  V v_t_2411 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
  V v_t_2412 = ({ V a_0 = heff_dup(v_sp_244); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_243, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2418;
  switch (heff_tag_of(v_lit_242)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_end_246)) {
    case TAG_EndValue: {
      v_t_2418 = heff_tr(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(v_cx_243, v_lit_241));
      break;
    }
    case TAG_EndJump: {
      v_t_2418 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_243, v_lit_241, v_lit_242, v_end_246));
      break;
    }
    case TAG_EndGive: {
      v_t_2418 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_243, v_lit_241, v_lit_242, v_end_246));
      break;
    }
    default: heff_nomatch(v_end_246);
    }
    break;
  }
  case TAG_Cons: {
    v_t_2418 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_243, v_lit_241, v_lit_242, v_end_246));
    break;
  }
  default: heff_nomatch(v_lit_242);
  }
  V v_t_2419 = (g_heff_2esyntax_2epresyntax_2elocalFun(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_str1), v_t_2411), heff_dup(v_sp_244), v_t_2412, v_t_2418));
  V v_t_2420 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_t_2410, v_t_2420}), v_sp_244});
}
V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}