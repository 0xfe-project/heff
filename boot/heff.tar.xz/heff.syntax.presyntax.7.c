// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfLet 62066
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWord 44207
#define TAG_EndValue 24675
#define TAG_IAnn 21211
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkTry 8097
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TPi 30745
#define TAG_TSig 38418
#define TAG_TSum 38796
#define LBL_decl 9574769
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
static uint32_t shape_names__muts__loop__sp__depth[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1107606901x1609022441_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s112965014x579570295_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1754932173x1305177089_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s2006690287x151588326_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s301034265x1732874986_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo;
V g_heff_2esyntax_2epresyntax_2eannLamOf(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eappOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2earmOn(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2earmOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmOn_clo;
V g_heff_2esyntax_2epresyntax_2earmT(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2earmT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmT_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryIn(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecoNames_get(void);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo;
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2eifLetOf(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eifLetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eifLetOf_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo;
V g_heff_2esyntax_2epresyntax_2epiBinderOf(V, V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo;
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo;
V g_heff_2esyntax_2epresyntax_2ereversedBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo;
V g_heff_2esyntax_2epresyntax_2erunArgs(V, V);
V g_heff_2esyntax_2epresyntax_2erunArgs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2erunArgs_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2estmtAcc_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo;
V g_heff_2esyntax_2epresyntax_2ewholeBinary(V, V);
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ewordOf(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_list_2eany_24s806340782x1757450604(V);
V g_list_2eany_24s806340782x1757450604_entry(V self, V *a);
extern Clo g_list_2eany_24s806340782x1757450604_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1230969749x2018313496(V);
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1258450377x973220636(V);
V g_list_2emap_24s1258450377x973220636_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_clo;
V g_list_2emap_24s137457135x961689574(V);
V g_list_2emap_24s137457135x961689574_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_clo;
V g_list_2emap_24s2016093283x1174801437(V, V);
V g_list_2emap_24s2016093283x1174801437_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_clo;
V g_list_2emap_24s2039279853x710813703(V, V);
V g_list_2emap_24s2039279853x710813703_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_clo;
V g_list_2emap_24s205414595x1692305030(V);
V g_list_2emap_24s205414595x1692305030_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_clo;
V g_list_2emap_24s961097229x1129443801(V);
V g_list_2emap_24s961097229x1129443801_entry(V self, V *a);
extern Clo g_list_2emap_24s961097229x1129443801_clo;
V g_list_2emap_24s97919758x216970748(V, V);
V g_list_2emap_24s97919758x216970748_entry(V self, V *a);
extern Clo g_list_2emap_24s97919758x216970748_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ereversedBytes_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ereversedBytes(V v_s_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return v_acc_242;
  } else {
    V v_t_244 = heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)1ULL))), 6);
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_strAppend(v_t_244, v_acc_242);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2ereversedBytes(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str0, 8, "inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str2, 4, "Unit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str3, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2eleaving_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eleaving_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2eleaving(V v_cx_240, V v_sp_241, V v_n_242, V v_call_243) {
top: ;
  if (heff_intLe_c_lent(v_n_242, MK_INT(0LL), 2)) {
    heff_drop_rec(v_cx_240, 5);
    heff_drop(v_sp_241);
    heff_drop(v_n_242);
    return v_call_243;
  } else {
    V v_e_245 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_240), heff_dup(v_sp_241), heff_intSub(v_n_242, MK_INT(1LL)), v_call_243));
    V v_sp_248;
    switch (heff_tag_of(v_e_245)) {
    case TAG_At: {
      V v_s_247 = heff_dup(heff_field(v_e_245, 1));
      v_sp_248 = v_s_247;
      break;
    }
    default: heff_nomatch(v_e_245);
    }
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str0)}), heff_dup(v_sp_248)});
    V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str1)}), v_sp_248});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_249, v_t_2411));
    V v_t_2415;
    switch (heff_tag_of(v_e_245)) {
    case TAG_At: {
      V v_s_2414 = heff_dup(heff_field(v_e_245, 1));
      v_t_2415 = v_s_2414;
      break;
    }
    default: heff_nomatch(v_e_245);
    }
    V v_e_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_e_245, v_t_2412}), v_t_2415});
    V v_t_2417 = heff_get_n(heff_get_n(v_cx_240, 0, 5), 1, 2);
    V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2417}), heff_dup(v_sp_241)});
    V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str2)}), heff_dup(v_sp_241)});
    V v_t_2420 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamAnn, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str3), heff_dup(v_sp_241), v_t_2419}), v_e_2416});
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_sp_241}), NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2418, v_t_2421));
  }
}
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eleaving(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epatNames_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2epatNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatNames_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epatNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_243, ((V)&g_heff_2esyntax_2epresyntax_2epatNames_str0), 2)) {
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        heff_drop(v_x_243);
        return NTAG(TAG_Nil);
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_247 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_247));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_248); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2411 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2411));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2412); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2418 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2418));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2419); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2421 = heff_field(v_x11_241, 0);
      V v_q_2423 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_cell_2424 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2421, heff_hole()});
      V v_u_2425 = (g_heff_2esyntax_2epresyntax_2epatNames_24dps(v_q_2423, heff_dup(v_cell_2424)));
      heff_drop(v_u_2425);
      return v_cell_2424;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatNames(a[0]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2estmtAcc_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_StmtBind: {
      V v_x_245 = heff_field(v_x31_243, 0);
      V v_xsp_246 = heff_field(v_x31_243, 1);
      V v_e_247 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_x1_248 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_247}));
      switch (heff_tag_of(v_x1_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_x1_248, 0);
        V v_y_2410 = heff_field(v_x1_248, 1);
        heff_take_n(v_x1_248, 3ULL, 2);
        V v_t_2411 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtBind, 3, (V[]){v_x_245, v_xsp_246, v_y_2410}), v_sp_244});
        return ((HeffT2){{v_x_249, v_t_2411}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_248)}});
      }
    }
    case TAG_StmtLet: {
      V v_p_2412 = heff_field(v_x31_243, 0);
      V v_e_2413 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x1_2414 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2413}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x1_2414, 0);
        V v_y_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 3ULL, 2);
        V v_t_2417 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_p_2412, v_y_2416}), v_sp_244});
        return ((HeffT2){{v_x_2415, v_t_2417}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2414)}});
      }
    }
    case TAG_StmtExpr: {
      V v_e_2418 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_x1_2419 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2418}));
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_MkPair: {
        V v_x_2420 = heff_field(v_x1_2419, 0);
        V v_y_2421 = heff_field(v_x1_2419, 1);
        heff_take_n(v_x1_2419, 3ULL, 2);
        V v_t_2422 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_y_2421}), v_sp_244});
        return ((HeffT2){{v_x_2420, v_t_2422}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2419)}});
      }
    }
    case TAG_StmtLetMut: {
      V v_x_2423 = heff_field(v_x31_243, 0);
      V v_xsp_2424 = heff_field(v_x31_243, 1);
      V v_e_2425 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_x1_2426 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2425}));
      switch (heff_tag_of(v_x1_2426)) {
      case TAG_MkPair: {
        V v_x_2427 = heff_field(v_x1_2426, 0);
        V v_y_2428 = heff_field(v_x1_2426, 1);
        heff_take_n(v_x1_2426, 3ULL, 2);
        V v_t_2429 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLetMut, 3, (V[]){v_x_2423, v_xsp_2424, v_y_2428}), v_sp_244});
        return ((HeffT2){{v_x_2427, v_t_2429}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2426)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_dup(heff_field(v_x3_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_x3_241, 1));
    switch (heff_tag_of(v_x31_242)) {
    case TAG_EVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EBinary: {
      V v_segs_2410 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EBinary = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      HeffT2 v_t_2411 = (g_heff_2esyntax_2epresyntax_2eaccList_24s2006690287x151588326_24cpr(v_st_240, v_segs_2410));
      {
        V v_field_2412 = v_t_2411.f[0];
        V v_field_2413 = v_t_2411.f[1];
        V v_x_2414 = v_field_2412;
        V v_y_2415 = v_field_2413;
        V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EBinary, TAG_EBinary, 1, (V[]){v_y_2415}), v_sp_243});
        return ((HeffT2){{v_x_2414, v_t_2416}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EApp: {
      V v_h_2419 = heff_field(v_x31_242, 0);
      V v_args_2420 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EApp = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_2421;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_2421 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_2421 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_h_2419)));
      }
      HeffT2 v_t_2422 = (g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(v_t_2421, v_args_2420));
      {
        V v_field_2423 = v_t_2422.f[0];
        V v_field_2424 = v_t_2422.f[1];
        V v_x_2425 = v_field_2423;
        V v_y_2426 = v_field_2424;
        V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EApp, TAG_EApp, 2, (V[]){v_h_2419, v_y_2426}), v_sp_243});
        return ((HeffT2){{v_x_2425, v_t_2427}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENamed: {
      V v_x_2429 = heff_field(v_x31_242, 0);
      V v_e_2430 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ENamed = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_2431;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_2431 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_2431 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_2430)));
      }
      V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENamed, TAG_ENamed, 2, (V[]){v_x_2429, v_e_2430}), v_sp_243});
      return ((HeffT2){{v_t_2431, v_t_2432}});
    }
    case TAG_EPi: {
      heff_take_n(v_x31_242, 0ULL, 2);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ELam: {
      V v_b_2435 = heff_field(v_x31_242, 0);
      V v_body_2436 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELam = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_2437;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_2437 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_2437 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_body_2436)));
      }
      V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELam, TAG_ELam, 2, (V[]){v_b_2435, v_body_2436}), v_sp_243});
      return ((HeffT2){{v_t_2437, v_t_2438}});
    }
    case TAG_EAnn: {
      V v_e_2439 = heff_field(v_x31_242, 0);
      V v_t_2440 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EAnn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_2441;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_2441 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_2441 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_2439)));
      }
      V v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAnn, TAG_EAnn, 2, (V[]){v_e_2439, v_t_2440}), v_sp_243});
      return ((HeffT2){{v_t_2441, v_t_2442}});
    }
    case TAG_ESpec: {
      V v_a_2443 = heff_field(v_x31_242, 0);
      V v_x_2444 = heff_field(v_x31_242, 1);
      V v_xsp_2445 = heff_field(v_x31_242, 2);
      V v_v_2446 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24ESpec = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      heff_drop_tag(v_x3_241, 2);
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_2443, v_x_2444, v_xsp_2445, v_v_2446}), v_sp_243});
        return ((HeffT2){{NTAG(TAG_True), v_t_2447}});
      } else {
        heff_drop(v_st_240);
        V v_t_2448 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_2443)));
        V v_t_2449;
        if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
          heff_drop(v_t_2448);
          v_t_2449 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_2448);
          v_t_2449 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_v_2446)));
        }
        V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_2443, v_x_2444, v_xsp_2445, v_v_2446}), v_sp_243});
        return ((HeffT2){{v_t_2449, v_t_2450}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EStruct: {
      V v_fs_2453 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EStruct = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      HeffT2 v_t_2454 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1754932173x1305177089_24cpr(v_st_240, v_fs_2453));
      {
        V v_field_2455 = v_t_2454.f[0];
        V v_field_2456 = v_t_2454.f[1];
        V v_x_2457 = v_field_2455;
        V v_y_2458 = v_field_2456;
        V v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EStruct, TAG_EStruct, 1, (V[]){v_y_2458}), v_sp_243});
        return ((HeffT2){{v_x_2457, v_t_2459}});
      }
    }
    case TAG_EUpdate: {
      V v_a_2460 = heff_field(v_x31_242, 0);
      V v_fs_2461 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EUpdate = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_2462;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_2462 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_2462 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_2460)));
      }
      HeffT2 v_t_2463 = (g_heff_2esyntax_2epresyntax_2eaccList_24s112965014x579570295_24cpr(v_t_2462, v_fs_2461));
      {
        V v_field_2464 = v_t_2463.f[0];
        V v_field_2465 = v_t_2463.f[1];
        V v_x_2466 = v_field_2464;
        V v_y_2467 = v_field_2465;
        V v_t_2468 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EUpdate, TAG_EUpdate, 2, (V[]){v_a_2460, v_y_2467}), v_sp_243});
        return ((HeffT2){{v_x_2466, v_t_2468}});
      }
    }
    case TAG_EMatch: {
      V v_s_2469 = heff_field(v_x31_242, 0);
      V v_alts_2470 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EMatch = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_2471;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_2471 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_2471 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_s_2469)));
      }
      HeffT2 v_t_2472 = (g_heff_2esyntax_2epresyntax_2eaccList_24s301034265x1732874986_24cpr(v_t_2471, v_alts_2470));
      {
        V v_field_2473 = v_t_2472.f[0];
        V v_field_2474 = v_t_2472.f[1];
        V v_x_2475 = v_field_2473;
        V v_y_2476 = v_field_2474;
        V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2469, v_y_2476}), v_sp_243});
        return ((HeffT2){{v_x_2475, v_t_2477}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_2478 = heff_field(v_x31_242, 0);
      V v_a_2479 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELetIn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        switch (heff_tag_of(v_a_2479)) {
        case TAG_At: {
          V v_x31_2480 = heff_field(v_a_2479, 0);
          V v_sp_2481 = heff_field(v_a_2479, 1);
          V v_ru_24a_2479_24At = heff_take_reuse_n(v_a_2479, 3ULL, 2);
          switch (heff_tag_of(v_x31_2480)) {
          case TAG_MkAlt: {
            V v_p_2482 = heff_field(v_x31_2480, 0);
            V v_e_2483 = heff_field(v_x31_2480, 1);
            V v_ru_24x31_2480_24MkAlt = heff_take_reuse_n(v_x31_2480, 3ULL, 2);
            V v_t_2484 = heff_tag_at_n(v_ru_24a_2479_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2482, v_e_2483}), v_sp_2481});
            V v_t_2485 = heff_tag_at_n(v_ru_24x31_2480_24MkAlt, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_2478, v_t_2484}), v_sp_243});
            return ((HeffT2){{NTAG(TAG_True), v_t_2485}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2480)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_a_2479)}});
        }
      } else {
        heff_drop(v_st_240);
        V v_t_2486 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_rhs_2478)));
        switch (heff_tag_of(v_a_2479)) {
        case TAG_At: {
          V v_x31_2487 = heff_field(v_a_2479, 0);
          V v_sp_2488 = heff_field(v_a_2479, 1);
          V v_ru_24a_2479_24At = heff_take_reuse_n(v_a_2479, 3ULL, 2);
          switch (heff_tag_of(v_x31_2487)) {
          case TAG_MkAlt: {
            V v_p_2489 = heff_field(v_x31_2487, 0);
            V v_e_2490 = heff_field(v_x31_2487, 1);
            V v_ru_24x31_2487_24MkAlt = heff_take_reuse_n(v_x31_2487, 3ULL, 2);
            V v_t_2491;
            if ((heff_dup(v_t_2486) == NTAG(TAG_True))) {
              heff_drop(v_t_2486);
              v_t_2491 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2486);
              v_t_2491 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_2490)));
            }
            V v_t_2492 = heff_tag_at_n(v_ru_24a_2479_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2489, v_e_2490}), v_sp_2488});
            V v_t_2493 = heff_tag_at_n(v_ru_24x31_2487_24MkAlt, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_2478, v_t_2492}), v_sp_243});
            return ((HeffT2){{v_t_2491, v_t_2493}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2487)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_a_2479)}});
        }
      }
    }
    case TAG_EDo: {
      V v_ss_2494 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EDo = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      HeffT2 v_t_2495 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1107606901x1609022441_24cpr(v_st_240, v_ss_2494));
      {
        V v_field_2496 = v_t_2495.f[0];
        V v_field_2497 = v_t_2495.f[1];
        V v_x_2498 = v_field_2496;
        V v_y_2499 = v_field_2497;
        V v_t_24100 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EDo, TAG_EDo, 1, (V[]){v_y_2499}), v_sp_243});
        return ((HeffT2){{v_x_2498, v_t_24100}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_242, 0ULL, 2);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EAssign: {
      V v_x_24104 = heff_field(v_x31_242, 0);
      V v_xsp_24105 = heff_field(v_x31_242, 1);
      V v_e_24106 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EAssign = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_tag(v_x3_241, 2);
      V v_t_24107;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_24107 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_24107 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_24106)));
      }
      V v_t_24108 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAssign, TAG_EAssign, 3, (V[]){v_x_24104, v_xsp_24105, v_e_24106}), v_sp_243});
      return ((HeffT2){{v_t_24107, v_t_24108}});
    }
    case TAG_EWhile: {
      V v_c_24109 = heff_field(v_x31_242, 0);
      V v_body_24110 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EWhile = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      V v_t_24111;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_24111 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_24111 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_c_24109)));
      }
      HeffT2 v_t_24112 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1107606901x1609022441_24cpr(v_t_24111, v_body_24110));
      {
        V v_field_24113 = v_t_24112.f[0];
        V v_field_24114 = v_t_24112.f[1];
        V v_x_24115 = v_field_24113;
        V v_y_24116 = v_field_24114;
        V v_t_24117 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWhile, TAG_EWhile, 2, (V[]){v_c_24109, v_y_24116}), v_sp_243});
        return ((HeffT2){{v_x_24115, v_t_24117}});
      }
    }
    case TAG_EFor: {
      V v_p_24118 = heff_field(v_x31_242, 0);
      V v_c_24119 = heff_field(v_x31_242, 1);
      V v_body_24120 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EFor = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_tag(v_x3_241, 2);
      V v_t_24121;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_24121 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_24121 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_c_24119)));
      }
      HeffT2 v_t_24122 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1107606901x1609022441_24cpr(v_t_24121, v_body_24120));
      {
        V v_field_24123 = v_t_24122.f[0];
        V v_field_24124 = v_t_24122.f[1];
        V v_x_24125 = v_field_24123;
        V v_y_24126 = v_field_24124;
        V v_t_24127 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EFor, TAG_EFor, 3, (V[]){v_p_24118, v_c_24119, v_y_24126}), v_sp_243});
        return ((HeffT2){{v_x_24125, v_t_24127}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24128 = heff_field(v_x31_242, 0);
      V v_a_24129 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EIfThen = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      heff_drop_tag(v_x3_241, 2);
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        V v_t_24130 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24128, v_a_24129}), v_sp_243});
        return ((HeffT2){{NTAG(TAG_True), v_t_24130}});
      } else {
        heff_drop(v_st_240);
        V v_t_24131 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_c_24128)));
        V v_t_24132;
        if ((heff_dup(v_t_24131) == NTAG(TAG_True))) {
          heff_drop(v_t_24131);
          v_t_24132 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_24131);
          v_t_24132 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_24129)));
        }
        V v_t_24133 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24128, v_a_24129}), v_sp_243});
        return ((HeffT2){{v_t_24132, v_t_24133}});
      }
    }
    case TAG_EBreak: {
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EContinue: {
      heff_drop(v_sp_243);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EReturn: {
      V v_e_24134 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EReturn = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      V v_t_24135;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_24135 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_24135 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_24134)));
      }
      V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EReturn, TAG_EReturn, 1, (V[]){v_e_24134}), v_sp_243});
      return ((HeffT2){{v_t_24135, v_t_24136}});
    }
    case TAG_ENest: {
      V v_e_24137 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ENest = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      V v_t_24138;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        v_t_24138 = NTAG(TAG_True);
      } else {
        heff_drop(v_st_240);
        v_t_24138 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_24137)));
      }
      V v_t_24139 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENest, TAG_ENest, 1, (V[]){v_e_24137}), v_sp_243});
      return ((HeffT2){{v_t_24138, v_t_24139}});
    }
    case TAG_EIfLet: {
      V v_p_24140 = heff_field(v_x31_242, 0);
      V v_s_24141 = heff_field(v_x31_242, 1);
      V v_a_24142 = heff_field(v_x31_242, 2);
      V v_b_24143 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24EIfLet = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      heff_drop_tag(v_x3_241, 2);
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        heff_drop(v_st_240);
        switch (heff_tag_of(v_b_24143)) {
        case TAG_Nothing: {
          V v_t_24144 = heff_tag_at_n(v_ru_24x31_242_24EIfLet, TAG_EIfLet, 4, (V[]){v_p_24140, v_s_24141, v_a_24142, NTAG(TAG_Nothing)});
          return ((HeffT2){{NTAG(TAG_True), heff_tag_n(TAG_At, 2, (V[]){v_t_24144, v_sp_243})}});
        }
        case TAG_Just: {
          V v_x_24145 = heff_field(v_b_24143, 0);
          heff_take_n(v_b_24143, 1ULL, 1);
          V v_t_24146 = heff_tag_at_n(v_ru_24x31_242_24EIfLet, TAG_EIfLet, 4, (V[]){v_p_24140, v_s_24141, v_a_24142, heff_tag_n(TAG_Just, 1, (V[]){v_x_24145})});
          return ((HeffT2){{NTAG(TAG_True), heff_tag_n(TAG_At, 2, (V[]){v_t_24146, v_sp_243})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_b_24143)}});
        }
      } else {
        heff_drop(v_st_240);
        V v_t_24147 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_s_24141)));
        V v_t_24148;
        if ((heff_dup(v_t_24147) == NTAG(TAG_True))) {
          heff_drop(v_t_24147);
          v_t_24148 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_24147);
          v_t_24148 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_24142)));
        }
        switch (heff_tag_of(v_b_24143)) {
        case TAG_Nothing: {
          V v_t_24149 = heff_tag_at_n(v_ru_24x31_242_24EIfLet, TAG_EIfLet, 4, (V[]){v_p_24140, v_s_24141, v_a_24142, NTAG(TAG_Nothing)});
          return ((HeffT2){{v_t_24148, heff_tag_n(TAG_At, 2, (V[]){v_t_24149, v_sp_243})}});
        }
        case TAG_Just: {
          V v_x_24150 = heff_field(v_b_24143, 0);
          heff_take_n(v_b_24143, 1ULL, 1);
          V v_t_24151;
          if ((heff_dup(v_t_24148) == NTAG(TAG_True))) {
            heff_drop(v_t_24148);
            v_t_24151 = NTAG(TAG_True);
          } else {
            heff_drop(v_t_24148);
            v_t_24151 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_x_24150)));
          }
          V v_t_24152 = heff_tag_at_n(v_ru_24x31_242_24EIfLet, TAG_EIfLet, 4, (V[]){v_p_24140, v_s_24141, v_a_24142, heff_tag_n(TAG_Just, 1, (V[]){v_x_24150})});
          return ((HeffT2){{v_t_24151, heff_tag_n(TAG_At, 2, (V[]){v_t_24152, v_sp_243})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_b_24143)}});
        }
      }
    }
    case TAG_ETry: {
      V v_tr_24153 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETry = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_tag(v_x3_241, 2);
      switch (heff_tag_of(v_tr_24153)) {
      case TAG_MkTry: {
        V v_err_24154 = heff_field(v_tr_24153, 0);
        V v_body_24155 = heff_field(v_tr_24153, 1);
        V v_c_24156 = heff_field(v_tr_24153, 2);
        V v_ru_24tr_24153_24MkTry = heff_take_reuse_n(v_tr_24153, 7ULL, 3);
        HeffT2 v_t_24157 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1107606901x1609022441_24cpr(v_st_240, v_body_24155));
        {
          V v_field_24158 = v_t_24157.f[0];
          V v_field_24159 = v_t_24157.f[1];
          V v_x_24160 = v_field_24158;
          V v_y_24161 = v_field_24159;
          switch (heff_tag_of(v_c_24156)) {
          case TAG_MkCatchArm: {
            V v_b_24162 = heff_field(v_c_24156, 0);
            V v_ss_24163 = heff_field(v_c_24156, 1);
            V v_ru_24c_24156_24MkCatchArm = heff_take_reuse_n(v_c_24156, 3ULL, 2);
            HeffT2 v_t_24164 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1107606901x1609022441_24cpr(v_x_24160, v_ss_24163));
            {
              V v_field_24165 = v_t_24164.f[0];
              V v_field_24166 = v_t_24164.f[1];
              V v_x_24167 = v_field_24165;
              V v_y_24168 = v_field_24166;
              V v_t_24169 = heff_tag_at_n(v_ru_24tr_24153_24MkTry, TAG_MkTry, 3, (V[]){v_err_24154, v_y_24161, heff_tag_n(TAG_MkCatchArm, 2, (V[]){v_b_24162, v_y_24168})});
              V v_t_24170 = heff_tag_at_n(v_ru_24c_24156_24MkCatchArm, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETry, TAG_ETry, 1, (V[]){v_t_24169}), v_sp_243});
              return ((HeffT2){{v_x_24167, v_t_24170}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_c_24156)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_tr_24153)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eisControl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eisControl_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eisControl(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_ERune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EProject: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EPi: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_ESig: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_ESum: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      V v_alts_2433 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 2ULL, 2);
      heff_drop(v_x12_242);
      return ({ V a_0 = v_alts_2433; V r_ = (g_list_2eany_24s806340782x1757450604(a_0)); heff_drop(v_alts_2433); r_; });
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EDo: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EAssign: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop(v_x12_242);
      return NTAG(TAG_True);
    }
    case TAG_EWhile: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      return NTAG(TAG_True);
    }
    case TAG_EFor: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop(v_x12_242);
      return NTAG(TAG_True);
    }
    case TAG_EIfThen: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      return NTAG(TAG_True);
    }
    case TAG_EBreak: {
      heff_drop(v_x12_242);
      return NTAG(TAG_True);
    }
    case TAG_EContinue: {
      heff_drop(v_x12_242);
      return NTAG(TAG_True);
    }
    case TAG_EReturn: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_True);
    }
    case TAG_ENest: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_False);
    }
    case TAG_EIfLet: {
      V v_x111_2452 = heff_field(v_x11_241, 0);
      V v_x112_2453 = heff_field(v_x11_241, 1);
      V v_x113_2454 = heff_field(v_x11_241, 2);
      V v_x114_2455 = heff_field(v_x11_241, 3);
      heff_take_n(v_x11_241, 15ULL, 4);
      switch (heff_tag_of(v_x114_2455)) {
      case TAG_Nothing: {
        heff_drop(v_x12_242);
        heff_drop(v_x111_2452);
        heff_drop(v_x112_2453);
        heff_drop(v_x113_2454);
        return NTAG(TAG_True);
      }
      case TAG_Just: {
        V v_b_2456 = heff_field(v_x114_2455, 0);
        heff_take_n(v_x114_2455, 1ULL, 1);
        V v_t_2457 = (g_heff_2esyntax_2epresyntax_2eifLetOf(v_x12_242, v_x111_2452, v_x112_2453, v_x113_2454, v_b_2456));
        V t_0 = v_t_2457;
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_x114_2455);
      }
    }
    case TAG_ETry: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eisControl(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2earmOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2earmOn_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2earmOn(V v_t_240, V v_cx_241, V v_rest_242, V v_end_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_p_245 = heff_field(v_x5_244, 0);
    V v_ss_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkPair = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_x1_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_246)));
    V v_t_2421;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nil: {
      v_t_2421 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      switch (heff_tag_of(v_x_248)) {
      case TAG_At: {
        V v_it11_2410 = heff_field(v_x_248, 0);
        heff_take_n(v_x_248, 1ULL, 2);
        switch (heff_tag_of(v_it11_2410)) {
        case TAG_StmtBind: {
          heff_take_n(v_it11_2410, 0ULL, 3);
          v_t_2421 = NTAG(TAG_True);
          break;
        }
        case TAG_StmtLet: {
          heff_take_n(v_it11_2410, 0ULL, 2);
          v_t_2421 = NTAG(TAG_True);
          break;
        }
        case TAG_StmtExpr: {
          V v_e_2417 = heff_field(v_it11_2410, 0);
          heff_take_n(v_it11_2410, 1ULL, 1);
          v_t_2421 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2417));
          break;
        }
        case TAG_StmtLetMut: {
          heff_take_n(v_it11_2410, 0ULL, 3);
          v_t_2421 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_it11_2410);
        }
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_t_2421);
      V v_t_2422 = (g_prelude_2e_2b_2b(v_ss_246, v_rest_242));
      return (g_heff_2esyntax_2epresyntax_2earmT(v_t_240, v_cx_241, v_end_243, heff_tag_at_n(v_ru_24x5_244_24MkPair, TAG_MkPair, 2, (V[]){v_p_245, v_t_2422})));
    } else {
      heff_drop(v_rest_242);
      heff_drop(v_t_2421);
      return (g_heff_2esyntax_2epresyntax_2earmT(v_t_240, v_cx_241, v_end_243, heff_tag_at_n(v_ru_24x5_244_24MkPair, TAG_MkPair, 2, (V[]){v_p_245, v_ss_246})));
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2epresyntax_2earmOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2earmOn(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xsp_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PiNamed = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_x1_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_244}));
    V v_t_2415;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_IsInferable: {
      V v_i_246 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsInferable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_249;
      switch (heff_tag_of(v_i_246)) {
      case TAG_At: {
        V v_s_248 = heff_dup(heff_field(v_i_246, 1));
        v_t_249 = v_s_248;
        break;
      }
      default: heff_nomatch(v_i_246);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsInferable, TAG_TInf, 1, (V[]){v_i_246}), v_t_249});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2410 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsCheckable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_dup(heff_field(v_c_2410, 1));
        v_t_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2410}), v_t_2413});
      break;
    }
    case TAG_IsType: {
      V v_t_2414 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      v_t_2415 = v_t_2414;
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_242, v_xsp_243, v_t_2415});
  }
  case TAG_PiImplicit: {
    V v_x_2416 = heff_field(v_x2_241, 0);
    V v_xsp_2417 = heff_field(v_x2_241, 1);
    V v_bsp_2418 = heff_field(v_x2_241, 2);
    V v_t_2419 = heff_field(v_x2_241, 3);
    V v_d_2420 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24PiImplicit = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_x1_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2419}));
    V v_t_2431;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_IsInferable: {
      V v_i_2422 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsInferable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2425;
      switch (heff_tag_of(v_i_2422)) {
      case TAG_At: {
        V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
        v_t_2425 = v_s_2424;
        break;
      }
      default: heff_nomatch(v_i_2422);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsInferable, TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2426 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsCheckable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2429;
      switch (heff_tag_of(v_c_2426)) {
      case TAG_At: {
        V v_s_2428 = heff_dup(heff_field(v_c_2426, 1));
        v_t_2429 = v_s_2428;
        break;
      }
      default: heff_nomatch(v_c_2426);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2426}), v_t_2429});
      break;
    }
    case TAG_IsType: {
      V v_t_2430 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 1);
      v_t_2431 = v_t_2430;
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    V v_t_2444;
    switch (heff_tag_of(v_d_2420)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 2);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2432 = heff_field(v_d_2420, 0);
      V v_ru_24d_2420_24Just = heff_take_reuse_n(v_d_2420, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsInferable = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsInferable, TAG_CInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        v_t_2443 = v_c_2438;
        break;
      }
      case TAG_IsType: {
        V v_t_2439 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsType = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2442;
        switch (heff_tag_of(v_t_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_t_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_t_2439);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsType, TAG_CType, 1, (V[]){v_t_2439}), v_t_2442});
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      v_t_2444 = heff_tag_at_n(v_ru_24d_2420_24Just, TAG_Just, 1, (V[]){v_t_2443});
      break;
    }
    default: heff_nomatch(v_d_2420);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2416, v_xsp_2417, v_bsp_2418, v_t_2431, v_t_2444});
  }
  case TAG_PiInstance: {
    V v_x_2445 = heff_field(v_x2_241, 0);
    V v_xsp_2446 = heff_field(v_x2_241, 1);
    V v_bsp_2447 = heff_field(v_x2_241, 2);
    V v_t_2448 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiInstance = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_x1_2449 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2448}));
    V v_t_2459;
    switch (heff_tag_of(v_x1_2449)) {
    case TAG_IsInferable: {
      V v_i_2450 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsInferable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2453;
      switch (heff_tag_of(v_i_2450)) {
      case TAG_At: {
        V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
        v_t_2453 = v_s_2452;
        break;
      }
      default: heff_nomatch(v_i_2450);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsInferable, TAG_TInf, 1, (V[]){v_i_2450}), v_t_2453});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2454 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsCheckable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_c_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_c_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_c_2454);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2454}), v_t_2457});
      break;
    }
    case TAG_IsType: {
      V v_t_2458 = heff_field(v_x1_2449, 0);
      heff_take_n(v_x1_2449, 1ULL, 1);
      v_t_2459 = v_t_2458;
      break;
    }
    default: heff_nomatch(v_x1_2449);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2445, v_xsp_2446, v_bsp_2447, v_t_2459});
  }
  case TAG_PiAnon: {
    V v_t_2460 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PiAnon = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2460}));
    V v_t_2471;
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_IsInferable: {
      V v_i_2462 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24IsInferable = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      V v_t_2465;
      switch (heff_tag_of(v_i_2462)) {
      case TAG_At: {
        V v_s_2464 = heff_dup(heff_field(v_i_2462, 1));
        v_t_2465 = v_s_2464;
        break;
      }
      default: heff_nomatch(v_i_2462);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsInferable, TAG_TInf, 1, (V[]){v_i_2462}), v_t_2465});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2466 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24IsCheckable = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      V v_t_2469;
      switch (heff_tag_of(v_c_2466)) {
      case TAG_At: {
        V v_s_2468 = heff_dup(heff_field(v_c_2466, 1));
        v_t_2469 = v_s_2468;
        break;
      }
      default: heff_nomatch(v_c_2466);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2466}), v_t_2469});
      break;
    }
    case TAG_IsType: {
      V v_t_2470 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      v_t_2471 = v_t_2470;
      break;
    }
    default: heff_nomatch(v_x1_2461);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2471});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_d_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclareField = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_246}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      V v_t_2431;
      switch (heff_tag_of(v_d_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 2);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2419 = heff_field(v_d_247, 0);
        V v_ru_24d_247_24Just = heff_take_reuse_n(v_d_247, 1ULL, 1);
        V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2419}));
        V v_t_2430;
        switch (heff_tag_of(v_x1_2420)) {
        case TAG_IsInferable: {
          V v_i_2421 = heff_field(v_x1_2420, 0);
          V v_ru_24x1_2420_24IsInferable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_i_2421)) {
          case TAG_At: {
            V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_i_2421);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsInferable, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2425 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          v_t_2430 = v_c_2425;
          break;
        }
        case TAG_IsType: {
          V v_t_2426 = heff_field(v_x1_2420, 0);
          V v_ru_24x1_2420_24IsType = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
          V v_t_2429;
          switch (heff_tag_of(v_t_2426)) {
          case TAG_At: {
            V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
            v_t_2429 = v_s_2428;
            break;
          }
          default: heff_nomatch(v_t_2426);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsType, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
          break;
        }
        default: heff_nomatch(v_x1_2420);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24d_247_24Just, TAG_Just, 1, (V[]){v_t_2430});
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_244, v_xsp_245, v_t_2418, v_t_2431}), v_sp_243});
    }
    case TAG_BadFieldDecl: {
      V v_e_2432 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldDecl = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2441;
        switch (heff_tag_of(v_c_2438)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_c_2438, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_c_2438);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2438}), v_t_2441});
        break;
      }
      case TAG_IsType: {
        V v_t_2442 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2443 = v_t_2442;
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2443}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eannLamOf_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2eannLamOf(V v_x_240, V v_xsp_241, V v_t_242, V v_x4_243, V v_sp_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(v_x_240, v_xsp_241, v_t_242, v_x4_243, v_sp_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_field_247});
    } else {
      if ((v_tag_246 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_247});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){v_field_247});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eannLamOf(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewholeBinary_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewholeBinary(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_seg_244 = heff_field(v_x11_242, 0);
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_244));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_s_2410 = v_field_248;
          V t_0 = v_rest_243;
          V t_1 = heff_strAppend(v_acc_241, v_s_2410);
          v_x1_240 = t_0;
          v_acc_241 = t_1;
          goto top;
        } else {
          heff_drop(v_acc_241);
          heff_drop(v_field_248);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2ewholeBinary(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str4, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str5, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str7, 67, " := e` sets a `let mut` variable: it is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str8, 45, "a `while` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str9, 43, "a `for` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str10, 78, "an `if` without `else` is a statement of a `do` block: a value's has an `else`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str11, 78, "`break` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str12, 81, "`continue` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str13, 103, "`return e` ends a `do` block as one of its statements (or an arm of its `if` or `case`), not as a value");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str14, 67, "`(<- c)`, the value of an action, is in a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str15, 82, "an `if let` without `else` is a statement of a `do` block: a value's has an `else`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str16, 72, "a `try` is a statement of a `do` block (or an arm of its `if` or `case`)");
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_244}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_IsInferable, 1, (V[]){v_t_245});
    }
    case TAG_EImplicitVar: {
      V v_x_246 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EImplicitVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_IsInferable, 1, (V[]){v_t_247});
    }
    case TAG_ETag: {
      V v_t_248 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ETag = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_249 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_248, heff_dup(v_sp_243), NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_249, v_sp_243})});
    }
    case TAG_EInt: {
      V v_i_2410 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInt = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_i_2410}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_IsInferable, 1, (V[]){v_t_2411});
    }
    case TAG_EFloat: {
      double v_x_2412 = heff_tflat_f64(v_x21_242, 0);
      V v_ru_24x21_242_24EFloat = heff_take_reuse_na(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_nf(TAG_IFloat, 1, 1u, (V[]){heff_word_f64(v_x_2412)}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_IsInferable, 1, (V[]){v_t_2413});
    }
    case TAG_EString: {
      V v_x_2414 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EString = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IString, 1, (V[]){v_x_2414}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EString, TAG_IsInferable, 1, (V[]){v_t_2415});
    }
    case TAG_EBinary: {
      V v_segs_2416 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return ({ V a_0 = v_r_240; V b_1 = NTAG(TAG_False); V a_2 = v_segs_2416; V a_3 = v_sp_243; V r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
    }
    case TAG_ERune: {
      V v_c_2417 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ERune = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IRune, 1, (V[]){v_c_2417}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_IsInferable, 1, (V[]){v_t_2418});
    }
    case TAG_EWord: {
      V v_w_2419 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2ewordOf(v_w_2419, v_sp_243);
    }
    case TAG_EApp: {
      V v_h_2420 = heff_field(v_x21_242, 0);
      V v_args_2421 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2erunArgs(heff_dup(v_h_2420), v_args_2421));
      return (g_heff_2esyntax_2epresyntax_2eappOf(v_r_240, v_h_2420, v_t_2422, v_sp_243));
    }
    case TAG_EProject: {
      V v_ru_24x21_242_24EProject = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2424 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EProject, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2424, v_sp_243})});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_2427 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2427, v_sp_243})});
    }
    case TAG_EPi: {
      V v_b_2428 = heff_field(v_x21_242, 0);
      V v_cod_2429 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2430 = (g_heff_2esyntax_2epresyntax_2epiBinderOf(heff_dup(v_r_240), v_b_2428));
      V v_x1_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_cod_2429}));
      V v_t_2441;
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_IsInferable: {
        V v_i_2432 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        V v_t_2435;
        switch (heff_tag_of(v_i_2432)) {
        case TAG_At: {
          V v_s_2434 = heff_dup(heff_field(v_i_2432, 1));
          v_t_2435 = v_s_2434;
          break;
        }
        default: heff_nomatch(v_i_2432);
        }
        v_t_2441 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2432}), v_t_2435});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2436 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        V v_t_2439;
        switch (heff_tag_of(v_c_2436)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_c_2436, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_c_2436);
        }
        v_t_2441 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2436}), v_t_2439});
        break;
      }
      case TAG_IsType: {
        V v_t_2440 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2441 = v_t_2440;
        break;
      }
      default: heff_nomatch(v_x1_2431);
      }
      V v_t_2442 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TPi, 2, (V[]){v_t_2430, v_t_2441}), v_sp_243});
      return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2442});
    }
    case TAG_ELam: {
      V v_x211_2443 = heff_field(v_x21_242, 0);
      V v_body_2444 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x211_2443)) {
      case TAG_LamName: {
        V v_x_2445 = heff_field(v_x211_2443, 0);
        V v_xsp_2446 = heff_field(v_x211_2443, 1);
        heff_take_n(v_x211_2443, 3ULL, 2);
        V v_x1_2447 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2444}));
        V v_t_2457;
        switch (heff_tag_of(v_x1_2447)) {
        case TAG_IsInferable: {
          V v_i_2448 = heff_field(v_x1_2447, 0);
          heff_take_n(v_x1_2447, 1ULL, 1);
          V v_t_2451;
          switch (heff_tag_of(v_i_2448)) {
          case TAG_At: {
            V v_s_2450 = heff_dup(heff_field(v_i_2448, 1));
            v_t_2451 = v_s_2450;
            break;
          }
          default: heff_nomatch(v_i_2448);
          }
          v_t_2457 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2448}), v_t_2451});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2452 = heff_field(v_x1_2447, 0);
          heff_take_n(v_x1_2447, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2457 = v_c_2452;
          break;
        }
        case TAG_IsType: {
          V v_t_2453 = heff_field(v_x1_2447, 0);
          heff_take_n(v_x1_2447, 1ULL, 1);
          V v_t_2456;
          switch (heff_tag_of(v_t_2453)) {
          case TAG_At: {
            V v_s_2455 = heff_dup(heff_field(v_t_2453, 1));
            v_t_2456 = v_s_2455;
            break;
          }
          default: heff_nomatch(v_t_2453);
          }
          v_t_2457 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2453}), v_t_2456});
          break;
        }
        default: heff_nomatch(v_x1_2447);
        }
        V v_t_2458 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2445, v_xsp_2446, v_t_2457}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2458});
      }
      case TAG_LamImplicit: {
        V v_x_2459 = heff_field(v_x211_2443, 0);
        V v_xsp_2460 = heff_field(v_x211_2443, 1);
        heff_take_n(v_x211_2443, 3ULL, 2);
        V v_x1_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2444}));
        V v_t_2471;
        switch (heff_tag_of(v_x1_2461)) {
        case TAG_IsInferable: {
          V v_i_2462 = heff_field(v_x1_2461, 0);
          heff_take_n(v_x1_2461, 1ULL, 1);
          V v_t_2465;
          switch (heff_tag_of(v_i_2462)) {
          case TAG_At: {
            V v_s_2464 = heff_dup(heff_field(v_i_2462, 1));
            v_t_2465 = v_s_2464;
            break;
          }
          default: heff_nomatch(v_i_2462);
          }
          v_t_2471 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2462}), v_t_2465});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2466 = heff_field(v_x1_2461, 0);
          heff_take_n(v_x1_2461, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2471 = v_c_2466;
          break;
        }
        case TAG_IsType: {
          V v_t_2467 = heff_field(v_x1_2461, 0);
          heff_take_n(v_x1_2461, 1ULL, 1);
          V v_t_2470;
          switch (heff_tag_of(v_t_2467)) {
          case TAG_At: {
            V v_s_2469 = heff_dup(heff_field(v_t_2467, 1));
            v_t_2470 = v_s_2469;
            break;
          }
          default: heff_nomatch(v_t_2467);
          }
          v_t_2471 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2467}), v_t_2470});
          break;
        }
        default: heff_nomatch(v_x1_2461);
        }
        V v_t_2472 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2459, v_xsp_2460, v_t_2471}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2472});
      }
      case TAG_LamAnn: {
        V v_x_2473 = heff_field(v_x211_2443, 0);
        V v_xsp_2474 = heff_field(v_x211_2443, 1);
        V v_t_2475 = heff_field(v_x211_2443, 2);
        heff_take_n(v_x211_2443, 7ULL, 3);
        heff_drop_cell(v_ru_24x21_242_24ELam, 2);
        V v_x1_2476 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2475}));
        V v_t_2486;
        switch (heff_tag_of(v_x1_2476)) {
        case TAG_IsInferable: {
          V v_i_2477 = heff_field(v_x1_2476, 0);
          heff_take_n(v_x1_2476, 1ULL, 1);
          V v_t_2480;
          switch (heff_tag_of(v_i_2477)) {
          case TAG_At: {
            V v_s_2479 = heff_dup(heff_field(v_i_2477, 1));
            v_t_2480 = v_s_2479;
            break;
          }
          default: heff_nomatch(v_i_2477);
          }
          v_t_2486 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2477}), v_t_2480});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2481 = heff_field(v_x1_2476, 0);
          heff_take_n(v_x1_2476, 1ULL, 1);
          V v_t_2484;
          switch (heff_tag_of(v_c_2481)) {
          case TAG_At: {
            V v_s_2483 = heff_dup(heff_field(v_c_2481, 1));
            v_t_2484 = v_s_2483;
            break;
          }
          default: heff_nomatch(v_c_2481);
          }
          v_t_2486 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2481}), v_t_2484});
          break;
        }
        case TAG_IsType: {
          V v_t_2485 = heff_field(v_x1_2476, 0);
          heff_take_n(v_x1_2476, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2486 = v_t_2485;
          break;
        }
        default: heff_nomatch(v_x1_2476);
        }
        V v_t_2487 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2444}));
        return (g_heff_2esyntax_2epresyntax_2eannLamOf(v_x_2473, v_xsp_2474, v_t_2486, v_t_2487, v_sp_243));
      }
      default: return heff_nomatch(v_x211_2443);
      }
    }
    case TAG_EAnn: {
      V v_a_2488 = heff_field(v_x21_242, 0);
      V v_t_2489 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_2490 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_2488}));
      V v_t_24100;
      switch (heff_tag_of(v_x1_2490)) {
      case TAG_IsInferable: {
        V v_i_2491 = heff_field(v_x1_2490, 0);
        heff_take_n(v_x1_2490, 1ULL, 1);
        V v_t_2494;
        switch (heff_tag_of(v_i_2491)) {
        case TAG_At: {
          V v_s_2493 = heff_dup(heff_field(v_i_2491, 1));
          v_t_2494 = v_s_2493;
          break;
        }
        default: heff_nomatch(v_i_2491);
        }
        v_t_24100 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2491}), v_t_2494});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2495 = heff_field(v_x1_2490, 0);
        heff_take_n(v_x1_2490, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24100 = v_c_2495;
        break;
      }
      case TAG_IsType: {
        V v_t_2496 = heff_field(v_x1_2490, 0);
        heff_take_n(v_x1_2490, 1ULL, 1);
        V v_t_2499;
        switch (heff_tag_of(v_t_2496)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_t_2496, 1));
          v_t_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_t_2496);
        }
        v_t_24100 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2496}), v_t_2499});
        break;
      }
      default: heff_nomatch(v_x1_2490);
      }
      V v_x1_24101 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2489}));
      V v_t_24111;
      switch (heff_tag_of(v_x1_24101)) {
      case TAG_IsInferable: {
        V v_i_24102 = heff_field(v_x1_24101, 0);
        heff_take_n(v_x1_24101, 1ULL, 1);
        V v_t_24105;
        switch (heff_tag_of(v_i_24102)) {
        case TAG_At: {
          V v_s_24104 = heff_dup(heff_field(v_i_24102, 1));
          v_t_24105 = v_s_24104;
          break;
        }
        default: heff_nomatch(v_i_24102);
        }
        v_t_24111 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_24102}), v_t_24105});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24106 = heff_field(v_x1_24101, 0);
        heff_take_n(v_x1_24101, 1ULL, 1);
        V v_t_24109;
        switch (heff_tag_of(v_c_24106)) {
        case TAG_At: {
          V v_s_24108 = heff_dup(heff_field(v_c_24106, 1));
          v_t_24109 = v_s_24108;
          break;
        }
        default: heff_nomatch(v_c_24106);
        }
        v_t_24111 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24106}), v_t_24109});
        break;
      }
      case TAG_IsType: {
        V v_t_24110 = heff_field(v_x1_24101, 0);
        heff_take_n(v_x1_24101, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EAnn, 2);
        v_t_24111 = v_t_24110;
        break;
      }
      default: heff_nomatch(v_x1_24101);
      }
      V v_t_24112 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_24100, v_t_24111}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24112});
    }
    case TAG_ESpec: {
      V v_a_24113 = heff_field(v_x21_242, 0);
      V v_x_24114 = heff_field(v_x21_242, 1);
      V v_fsp_24115 = heff_field(v_x21_242, 2);
      V v_v_24116 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24ESpec = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_24117 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24113}));
      V v_t_24118 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24117));
      V v_x1_24119 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_24116}));
      V v_t_24129;
      switch (heff_tag_of(v_x1_24119)) {
      case TAG_IsInferable: {
        V v_i_24120 = heff_field(v_x1_24119, 0);
        heff_take_n(v_x1_24119, 1ULL, 1);
        V v_t_24123;
        switch (heff_tag_of(v_i_24120)) {
        case TAG_At: {
          V v_s_24122 = heff_dup(heff_field(v_i_24120, 1));
          v_t_24123 = v_s_24122;
          break;
        }
        default: heff_nomatch(v_i_24120);
        }
        v_t_24129 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24120}), v_t_24123});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24124 = heff_field(v_x1_24119, 0);
        heff_take_n(v_x1_24119, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24129 = v_c_24124;
        break;
      }
      case TAG_IsType: {
        V v_t_24125 = heff_field(v_x1_24119, 0);
        heff_take_n(v_x1_24119, 1ULL, 1);
        V v_t_24128;
        switch (heff_tag_of(v_t_24125)) {
        case TAG_At: {
          V v_s_24127 = heff_dup(heff_field(v_t_24125, 1));
          v_t_24128 = v_s_24127;
          break;
        }
        default: heff_nomatch(v_t_24125);
        }
        v_t_24129 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24125}), v_t_24128});
        break;
      }
      default: heff_nomatch(v_x1_24119);
      }
      V v_t_24130 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESpec, TAG_ISpec, 4, (V[]){v_t_24118, v_x_24114, v_fsp_24115, v_t_24129}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24130});
    }
    case TAG_ESig: {
      V v_fs_24131 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESig = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24132 = (g_list_2emap_24s2016093283x1174801437(v_r_240, v_fs_24131));
      V v_t_24133 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSig, 1, (V[]){v_t_24132}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_IsType, 1, (V[]){v_t_24133});
    }
    case TAG_ESum: {
      V v_vs_24134 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESum = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24135 = (g_list_2emap_24s97919758x216970748(v_r_240, v_vs_24134));
      V v_t_24136 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSum, 1, (V[]){v_t_24135}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_IsType, 1, (V[]){v_t_24136});
    }
    case TAG_EStruct: {
      V v_fs_24137 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EStruct = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24138 = (g_list_2emap_24s2039279853x710813703(v_r_240, v_fs_24137));
      V v_t_24139 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CStruct, 1, (V[]){v_t_24138}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_IsCheckable, 1, (V[]){v_t_24139});
    }
    case TAG_EUpdate: {
      V v_a_24140 = heff_field(v_x21_242, 0);
      V v_fs_24141 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_24142 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24140}));
      V v_t_24143 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24142));
      V v_t_24144 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo), 1, (V[]){v_r_240}));
      V v_t_24145 = (g_list_2emap(v_t_24144, v_fs_24141));
      V v_t_24146 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IUpdate, 2, (V[]){v_t_24143, v_t_24145}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24146});
    }
    case TAG_EMatch: {
      V v_s_24147 = heff_field(v_x21_242, 0);
      V v_alts_24148 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_24149 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24147}));
      V v_t_24150 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24149));
      V v_t_24151 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ealtOf_clo), 1, (V[]){v_r_240}));
      V v_t_24152 = (g_list_2emap(v_t_24151, v_alts_24148));
      V v_t_24153 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_24150, v_t_24152}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24153});
    }
    case TAG_ELetIn: {
      V v_rhs_24154 = heff_field(v_x21_242, 0);
      V v_a_24155 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24156 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_24154}));
      V v_t_24157 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24156));
      V v_t_24173;
      switch (heff_tag_of(v_a_24155)) {
      case TAG_At: {
        V v_x21_24158 = heff_field(v_a_24155, 0);
        V v_sp_24159 = heff_field(v_a_24155, 1);
        heff_take_n(v_a_24155, 3ULL, 2);
        switch (heff_tag_of(v_x21_24158)) {
        case TAG_MkAlt: {
          V v_p_24160 = heff_field(v_x21_24158, 0);
          V v_b_24161 = heff_field(v_x21_24158, 1);
          heff_take_n(v_x21_24158, 3ULL, 2);
          V v_x1_24162 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_24161}));
          V v_t_24172;
          switch (heff_tag_of(v_x1_24162)) {
          case TAG_IsInferable: {
            V v_i_24163 = heff_field(v_x1_24162, 0);
            heff_take_n(v_x1_24162, 1ULL, 1);
            V v_t_24166;
            switch (heff_tag_of(v_i_24163)) {
            case TAG_At: {
              V v_s_24165 = heff_dup(heff_field(v_i_24163, 1));
              v_t_24166 = v_s_24165;
              break;
            }
            default: heff_nomatch(v_i_24163);
            }
            v_t_24172 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24163}), v_t_24166});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24167 = heff_field(v_x1_24162, 0);
            heff_take_n(v_x1_24162, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            v_t_24172 = v_c_24167;
            break;
          }
          case TAG_IsType: {
            V v_t_24168 = heff_field(v_x1_24162, 0);
            heff_take_n(v_x1_24162, 1ULL, 1);
            V v_t_24171;
            switch (heff_tag_of(v_t_24168)) {
            case TAG_At: {
              V v_s_24170 = heff_dup(heff_field(v_t_24168, 1));
              v_t_24171 = v_s_24170;
              break;
            }
            default: heff_nomatch(v_t_24168);
            }
            v_t_24172 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24168}), v_t_24171});
            break;
          }
          default: heff_nomatch(v_x1_24162);
          }
          v_t_24173 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24160, v_t_24172}), v_sp_24159});
          break;
        }
        default: heff_nomatch(v_x21_24158);
        }
        break;
      }
      default: heff_nomatch(v_a_24155);
      }
      V v_t_24174 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24157, v_t_24173}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24174});
    }
    case TAG_EDo: {
      V v_stmts_24175 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EDo = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_24176 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stmts_24175)));
      switch (heff_tag_of(v_x1_24176)) {
      case TAG_Nil: {
        heff_drop_rec(v_r_240, 2);
        heff_drop(v_stmts_24175);
        V v_t_24177 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2), NTAG(TAG_Nothing)});
        return heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24177, v_sp_243})});
      }
      case TAG_Cons: {
        V v_x_24178 = heff_field(v_x1_24176, 0);
        heff_take_n(v_x1_24176, 1ULL, 2);
        switch (heff_tag_of(v_x_24178)) {
        case TAG_At: {
          V v_it11_24180 = heff_field(v_x_24178, 0);
          heff_take_n(v_x_24178, 1ULL, 2);
          switch (heff_tag_of(v_it11_24180)) {
          case TAG_StmtBind: {
            V v_ru_24it11_24180_24StmtBind = heff_take_reuse_n(v_it11_24180, 0ULL, 3);
            heff_drop_rec(v_r_240, 2);
            heff_drop(v_stmts_24175);
            V v_t_24185 = heff_tag_at_n(v_ru_24it11_24180_24StmtBind, TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3), NTAG(TAG_Nothing)});
            return heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24185, v_sp_243})});
          }
          case TAG_StmtLet: {
            heff_take_n(v_it11_24180, 0ULL, 2);
            heff_drop_rec(v_r_240, 2);
            heff_drop(v_stmts_24175);
            V v_t_24188 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str4), NTAG(TAG_Nothing)});
            return heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24188, v_sp_243})});
          }
          case TAG_StmtExpr: {
            heff_take_n(v_it11_24180, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            heff_drop_cell(v_ru_24x21_242_24EDo, 1);
            V v_t_24190 = heff_rec_n(5, shape_names__muts__loop__sp__depth, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2ecoNames_get()), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_sp_243, MK_INT(0LL)});
            V v_e_27_24191 = ({ V a_0 = v_t_24190; V a_1 = v_stmts_24175; V a_2 = NTAG(TAG_EndValue); V r_ = (g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_stmts_24175); r_; });
            return heff_tail(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_27_24191});
          }
          case TAG_StmtLetMut: {
            V v_ru_24it11_24180_24StmtLetMut = heff_take_reuse_n(v_it11_24180, 0ULL, 3);
            heff_drop_rec(v_r_240, 2);
            heff_drop(v_stmts_24175);
            V v_t_24195 = heff_tag_at_n(v_ru_24it11_24180_24StmtLetMut, TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str5), NTAG(TAG_Nothing)});
            return heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24195, v_sp_243})});
          }
          default: return heff_nomatch(v_it11_24180);
          }
        }
        default: return heff_nomatch(v_x_24178);
        }
      }
      default: return heff_nomatch(v_x1_24176);
      }
    }
    case TAG_ELocal: {
      V v_body_24196 = heff_field(v_x21_242, 0);
      V v_ds_24197 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_24198 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 1, (V[]){v_body_24196}));
      V v_t_24208;
      switch (heff_tag_of(v_x1_24198)) {
      case TAG_IsInferable: {
        V v_i_24199 = heff_field(v_x1_24198, 0);
        heff_take_n(v_x1_24198, 1ULL, 1);
        V v_t_24202;
        switch (heff_tag_of(v_i_24199)) {
        case TAG_At: {
          V v_s_24201 = heff_dup(heff_field(v_i_24199, 1));
          v_t_24202 = v_s_24201;
          break;
        }
        default: heff_nomatch(v_i_24199);
        }
        v_t_24208 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24199}), v_t_24202});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24203 = heff_field(v_x1_24198, 0);
        heff_take_n(v_x1_24198, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24208 = v_c_24203;
        break;
      }
      case TAG_IsType: {
        V v_t_24204 = heff_field(v_x1_24198, 0);
        heff_take_n(v_x1_24198, 1ULL, 1);
        V v_t_24207;
        switch (heff_tag_of(v_t_24204)) {
        case TAG_At: {
          V v_s_24206 = heff_dup(heff_field(v_t_24204, 1));
          v_t_24207 = v_s_24206;
          break;
        }
        default: heff_nomatch(v_t_24204);
        }
        v_t_24208 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24204}), v_t_24207});
        break;
      }
      default: heff_nomatch(v_x1_24198);
      }
      V v_t_24209 = (g_list_2emap(heff_get_n(v_r_240, 1, 2), v_ds_24197));
      V v_t_24210 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CLocal, 2, (V[]){v_t_24208, v_t_24209}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24210});
    }
    case TAG_EInvalid: {
      V v_why_24211 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInvalid = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24212 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_why_24211, NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24212, v_sp_243})});
    }
    case TAG_EAssign: {
      V v_x_24213 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EAssign = heff_take_reuse_n(v_x21_242, 1ULL, 3);
      heff_drop_rec(v_r_240, 2);
      V v_t_24216 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str6), heff_strAppend(v_x_24213, ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str7)));
      V v_t_24217 = heff_tag_at_n(v_ru_24x21_242_24EAssign, TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_t_24216, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24217, v_sp_243})});
    }
    case TAG_EWhile: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_24220 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str8), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24220, v_sp_243})});
    }
    case TAG_EFor: {
      V v_ru_24x21_242_24EFor = heff_take_reuse_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_r_240, 2);
      V v_t_24224 = heff_tag_at_n(v_ru_24x21_242_24EFor, TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str9), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24224, v_sp_243})});
    }
    case TAG_EIfThen: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_24227 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str10), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24227, v_sp_243})});
    }
    case TAG_EBreak: {
      heff_drop_rec(v_r_240, 2);
      V v_t_24228 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str11), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24228, v_sp_243})});
    }
    case TAG_EContinue: {
      heff_drop_rec(v_r_240, 2);
      V v_t_24229 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str12), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24229, v_sp_243})});
    }
    case TAG_EReturn: {
      V v_ru_24x21_242_24EReturn = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24231 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str13), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EReturn, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24231, v_sp_243})});
    }
    case TAG_ENest: {
      V v_ru_24x21_242_24ENest = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24233 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str14), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24ENest, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24233, v_sp_243})});
    }
    case TAG_EIfLet: {
      V v_p_24234 = heff_field(v_x21_242, 0);
      V v_s_24235 = heff_field(v_x21_242, 1);
      V v_a_24236 = heff_field(v_x21_242, 2);
      V v_x214_24237 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 15ULL, 4);
      switch (heff_tag_of(v_x214_24237)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 2);
        heff_drop(v_p_24234);
        heff_drop(v_s_24235);
        heff_drop(v_a_24236);
        V v_t_24238 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str15), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24238, v_sp_243})});
      }
      case TAG_Just: {
        V v_b_24239 = heff_field(v_x214_24237, 0);
        heff_take_n(v_x214_24237, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        V v_t_24240 = (g_heff_2esyntax_2epresyntax_2eifLetOf(v_sp_243, v_p_24234, v_s_24235, v_a_24236, v_b_24239));
        return heff_tail(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_24240});
      }
      default: return heff_nomatch(v_x214_24237);
      }
    }
    case TAG_ETry: {
      V v_ru_24x21_242_24ETry = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24242 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str16), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24ETry, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24242, v_sp_243})});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr_str0, 11, "bytesConcat");

HeffT2 g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr(V v_segs_240, V v_sp_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nothing: {
    V v_xs_243 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_243));
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_244, heff_dup(v_sp_241)));
    V v_args_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr_str0)}), heff_dup(v_sp_241)});
    V v_t_248 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_246));
    V v_f_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_247, v_t_248}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_249}});
  }
  case TAG_Just: {
    V v_s_2410 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24Just = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_segs_240);
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_242_24Just, TAG_IBytes, 1, (V[]){v_s_2410}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2411}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xsp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_243));
    V v_t_2418;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_c_248 = v_field_246;
        V v_t_2411;
        switch (heff_tag_of(v_c_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_c_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_c_248);
        }
        v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_248}), v_t_2411});
      } else {
        if ((v_tag_245 == ((int64_t)1ULL))) {
          V v_i_2413 = v_field_246;
          V v_t_2416;
          switch (heff_tag_of(v_i_2413)) {
          case TAG_At: {
            V v_s_2415 = heff_dup(heff_field(v_i_2413, 1));
            v_t_2416 = v_s_2415;
            break;
          }
          default: heff_nomatch(v_i_2413);
          }
          v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2413}), v_t_2416});
        } else {
          V v_t_2417 = v_field_246;
          v_t_2418 = v_t_2417;
        }
      }
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_241, v_xsp_242, v_t_2418});
  }
  case TAG_PiImplicit: {
    V v_x_2419 = heff_field(v_x2_240, 0);
    V v_xsp_2420 = heff_field(v_x2_240, 1);
    V v_bsp_2421 = heff_field(v_x2_240, 2);
    V v_t_2422 = heff_field(v_x2_240, 3);
    V v_d_2423 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    HeffT2 v_t_2424 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2422));
    V v_t_2438;
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      if ((v_tag_2425 == ((int64_t)0ULL))) {
        V v_c_2428 = v_field_2426;
        V v_t_2431;
        switch (heff_tag_of(v_c_2428)) {
        case TAG_At: {
          V v_s_2430 = heff_dup(heff_field(v_c_2428, 1));
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_c_2428);
        }
        v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2428}), v_t_2431});
      } else {
        if ((v_tag_2425 == ((int64_t)1ULL))) {
          V v_i_2433 = v_field_2426;
          V v_t_2436;
          switch (heff_tag_of(v_i_2433)) {
          case TAG_At: {
            V v_s_2435 = heff_dup(heff_field(v_i_2433, 1));
            v_t_2436 = v_s_2435;
            break;
          }
          default: heff_nomatch(v_i_2433);
          }
          v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2433}), v_t_2436});
        } else {
          V v_t_2437 = v_field_2426;
          v_t_2438 = v_t_2437;
        }
      }
    }
    V v_t_2455;
    switch (heff_tag_of(v_d_2423)) {
    case TAG_Nothing: {
      v_t_2455 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2439 = heff_field(v_d_2423, 0);
      V v_ru_24d_2423_24Just = heff_take_reuse_n(v_d_2423, 1ULL, 1);
      HeffT2 v_t_2440 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_2439));
      V v_t_2454;
      {
        V v_field_2442 = v_t_2440.f[1];
        int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
        if ((v_tag_2441 == ((int64_t)0ULL))) {
          V v_c_2444 = v_field_2442;
          v_t_2454 = v_c_2444;
        } else {
          if ((v_tag_2441 == ((int64_t)1ULL))) {
            V v_i_2446 = v_field_2442;
            V v_t_2449;
            switch (heff_tag_of(v_i_2446)) {
            case TAG_At: {
              V v_s_2448 = heff_dup(heff_field(v_i_2446, 1));
              v_t_2449 = v_s_2448;
              break;
            }
            default: heff_nomatch(v_i_2446);
            }
            v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2446}), v_t_2449});
          } else {
            V v_t_2450 = v_field_2442;
            V v_t_2453;
            switch (heff_tag_of(v_t_2450)) {
            case TAG_At: {
              V v_s_2452 = heff_dup(heff_field(v_t_2450, 1));
              v_t_2453 = v_s_2452;
              break;
            }
            default: heff_nomatch(v_t_2450);
            }
            v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2450}), v_t_2453});
          }
        }
      }
      v_t_2455 = heff_tag_at_n(v_ru_24d_2423_24Just, TAG_Just, 1, (V[]){v_t_2454});
      break;
    }
    default: heff_nomatch(v_d_2423);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2419, v_xsp_2420, v_bsp_2421, v_t_2438, v_t_2455});
  }
  case TAG_PiInstance: {
    V v_x_2456 = heff_field(v_x2_240, 0);
    V v_xsp_2457 = heff_field(v_x2_240, 1);
    V v_bsp_2458 = heff_field(v_x2_240, 2);
    V v_t_2459 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    HeffT2 v_t_2460 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2459));
    V v_t_2474;
    {
      V v_field_2462 = v_t_2460.f[1];
      int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
      if ((v_tag_2461 == ((int64_t)0ULL))) {
        V v_c_2464 = v_field_2462;
        V v_t_2467;
        switch (heff_tag_of(v_c_2464)) {
        case TAG_At: {
          V v_s_2466 = heff_dup(heff_field(v_c_2464, 1));
          v_t_2467 = v_s_2466;
          break;
        }
        default: heff_nomatch(v_c_2464);
        }
        v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2464}), v_t_2467});
      } else {
        if ((v_tag_2461 == ((int64_t)1ULL))) {
          V v_i_2469 = v_field_2462;
          V v_t_2472;
          switch (heff_tag_of(v_i_2469)) {
          case TAG_At: {
            V v_s_2471 = heff_dup(heff_field(v_i_2469, 1));
            v_t_2472 = v_s_2471;
            break;
          }
          default: heff_nomatch(v_i_2469);
          }
          v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2469}), v_t_2472});
        } else {
          V v_t_2473 = v_field_2462;
          v_t_2474 = v_t_2473;
        }
      }
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2456, v_xsp_2457, v_bsp_2458, v_t_2474});
  }
  case TAG_PiAnon: {
    V v_t_2475 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    HeffT2 v_t_2476 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2475));
    V v_t_2490;
    {
      V v_field_2478 = v_t_2476.f[1];
      int64_t v_tag_2477 = ((int64_t)v_t_2476.f[0]);
      if ((v_tag_2477 == ((int64_t)0ULL))) {
        V v_c_2480 = v_field_2478;
        V v_t_2483;
        switch (heff_tag_of(v_c_2480)) {
        case TAG_At: {
          V v_s_2482 = heff_dup(heff_field(v_c_2480, 1));
          v_t_2483 = v_s_2482;
          break;
        }
        default: heff_nomatch(v_c_2480);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2480}), v_t_2483});
      } else {
        if ((v_tag_2477 == ((int64_t)1ULL))) {
          V v_i_2485 = v_field_2478;
          V v_t_2488;
          switch (heff_tag_of(v_i_2485)) {
          case TAG_At: {
            V v_s_2487 = heff_dup(heff_field(v_i_2485, 1));
            v_t_2488 = v_s_2487;
            break;
          }
          default: heff_nomatch(v_i_2485);
          }
          v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2485}), v_t_2488});
        } else {
          V v_t_2489 = v_field_2478;
          v_t_2490 = v_t_2489;
        }
      }
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2490});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str0, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str1, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str2, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str3, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str4, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str5, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str7, 67, " := e` sets a `let mut` variable: it is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str8, 45, "a `while` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str9, 43, "a `for` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str10, 78, "an `if` without `else` is a statement of a `do` block: a value's has an `else`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str11, 78, "`break` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str12, 81, "`continue` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str13, 103, "`return e` ends a `do` block as one of its statements (or an arm of its `if` or `case`), not as a value");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str14, 67, "`(<- c)`, the value of an action, is in a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str15, 82, "an `if let` without `else` is a statement of a `do` block: a value's has an `else`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str16, 72, "a `try` is a statement of a `do` block (or an arm of its `if` or `case`)");

HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      V v_x_243 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_243}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_244}});
    }
    case TAG_EImplicitVar: {
      V v_x_245 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_246 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_245}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_246}});
    }
    case TAG_ETag: {
      V v_t_247 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_248 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_247, heff_dup(v_sp_242), NTAG(TAG_Nil)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_248, v_sp_242})}});
    }
    case TAG_EInt: {
      V v_i_249 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_i_249}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2410}});
    }
    case TAG_EFloat: {
      double v_x_2411 = heff_tflat_f64(v_x21_241, 0);
      heff_take_na(v_x21_241, 0ULL, 1);
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_nf(TAG_IFloat, 1, 1u, (V[]){heff_word_f64(v_x_2411)}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2412}});
    }
    case TAG_EString: {
      V v_x_2413 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IString, 1, (V[]){v_x_2413}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2414}});
    }
    case TAG_EBinary: {
      V v_segs_2415 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_segs_2415; V a_2 = v_sp_242; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    }
    case TAG_ERune: {
      V v_c_2416 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IRune, 1, (V[]){v_c_2416}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2417}});
    }
    case TAG_EWord: {
      V v_w_2418 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(v_w_2418, v_sp_242));
    }
    case TAG_EApp: {
      V v_h_2419 = heff_field(v_x21_241, 0);
      V v_args_2420 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2421 = (g_heff_2esyntax_2epresyntax_2erunArgs(heff_dup(v_h_2419), v_args_2420));
      return (g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(v_h_2419, v_t_2421, v_sp_242));
    }
    case TAG_EProject: {
      heff_take_n(v_x21_241, 0ULL, 1);
      V v_t_2423 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str0), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2423, v_sp_242})}});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_241, 0ULL, 2);
      V v_t_2426 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str1), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2426, v_sp_242})}});
    }
    case TAG_EPi: {
      V v_b_2427 = heff_field(v_x21_241, 0);
      V v_cod_2428 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EPi = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_2429 = (g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(v_b_2427));
      HeffT2 v_t_2430 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_cod_2428));
      V v_t_2444;
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          V v_c_2434 = v_field_2432;
          V v_t_2437;
          switch (heff_tag_of(v_c_2434)) {
          case TAG_At: {
            V v_s_2436 = heff_dup(heff_field(v_c_2434, 1));
            v_t_2437 = v_s_2436;
            break;
          }
          default: heff_nomatch(v_c_2434);
          }
          v_t_2444 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2434}), v_t_2437});
        } else {
          if ((v_tag_2431 == ((int64_t)1ULL))) {
            V v_i_2439 = v_field_2432;
            V v_t_2442;
            switch (heff_tag_of(v_i_2439)) {
            case TAG_At: {
              V v_s_2441 = heff_dup(heff_field(v_i_2439, 1));
              v_t_2442 = v_s_2441;
              break;
            }
            default: heff_nomatch(v_i_2439);
            }
            v_t_2444 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2439}), v_t_2442});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2443 = v_field_2432;
            v_t_2444 = v_t_2443;
          }
        }
      }
      V v_f_2445 = heff_tag_at_n(v_ru_24x21_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TPi, 2, (V[]){v_t_2429, v_t_2444}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_2445}});
    }
    case TAG_ELam: {
      V v_x211_2446 = heff_field(v_x21_241, 0);
      V v_body_2447 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELam = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      switch (heff_tag_of(v_x211_2446)) {
      case TAG_LamName: {
        V v_x_2448 = heff_field(v_x211_2446, 0);
        V v_xsp_2449 = heff_field(v_x211_2446, 1);
        heff_take_n(v_x211_2446, 3ULL, 2);
        HeffT2 v_t_2450 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2447));
        V v_t_2464;
        {
          V v_field_2452 = v_t_2450.f[1];
          int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
          if ((v_tag_2451 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_c_2454 = v_field_2452;
            v_t_2464 = v_c_2454;
          } else {
            if ((v_tag_2451 == ((int64_t)1ULL))) {
              V v_i_2456 = v_field_2452;
              V v_t_2459;
              switch (heff_tag_of(v_i_2456)) {
              case TAG_At: {
                V v_s_2458 = heff_dup(heff_field(v_i_2456, 1));
                v_t_2459 = v_s_2458;
                break;
              }
              default: heff_nomatch(v_i_2456);
              }
              v_t_2464 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2456}), v_t_2459});
            } else {
              V v_t_2460 = v_field_2452;
              V v_t_2463;
              switch (heff_tag_of(v_t_2460)) {
              case TAG_At: {
                V v_s_2462 = heff_dup(heff_field(v_t_2460, 1));
                v_t_2463 = v_s_2462;
                break;
              }
              default: heff_nomatch(v_t_2460);
              }
              v_t_2464 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2460}), v_t_2463});
            }
          }
        }
        V v_f_2465 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2448, v_xsp_2449, v_t_2464}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2465}});
      }
      case TAG_LamImplicit: {
        V v_x_2466 = heff_field(v_x211_2446, 0);
        V v_xsp_2467 = heff_field(v_x211_2446, 1);
        heff_take_n(v_x211_2446, 3ULL, 2);
        HeffT2 v_t_2468 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2447));
        V v_t_2482;
        {
          V v_field_2470 = v_t_2468.f[1];
          int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
          if ((v_tag_2469 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_c_2472 = v_field_2470;
            v_t_2482 = v_c_2472;
          } else {
            if ((v_tag_2469 == ((int64_t)1ULL))) {
              V v_i_2474 = v_field_2470;
              V v_t_2477;
              switch (heff_tag_of(v_i_2474)) {
              case TAG_At: {
                V v_s_2476 = heff_dup(heff_field(v_i_2474, 1));
                v_t_2477 = v_s_2476;
                break;
              }
              default: heff_nomatch(v_i_2474);
              }
              v_t_2482 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2474}), v_t_2477});
            } else {
              V v_t_2478 = v_field_2470;
              V v_t_2481;
              switch (heff_tag_of(v_t_2478)) {
              case TAG_At: {
                V v_s_2480 = heff_dup(heff_field(v_t_2478, 1));
                v_t_2481 = v_s_2480;
                break;
              }
              default: heff_nomatch(v_t_2478);
              }
              v_t_2482 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2478}), v_t_2481});
            }
          }
        }
        V v_f_2483 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2466, v_xsp_2467, v_t_2482}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2483}});
      }
      case TAG_LamAnn: {
        V v_x_2484 = heff_field(v_x211_2446, 0);
        V v_xsp_2485 = heff_field(v_x211_2446, 1);
        V v_t_2486 = heff_field(v_x211_2446, 2);
        heff_take_n(v_x211_2446, 7ULL, 3);
        heff_drop_cell(v_ru_24x21_241_24ELam, 2);
        HeffT2 v_t_2487 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2486));
        V v_t_24101;
        {
          V v_field_2489 = v_t_2487.f[1];
          int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
          if ((v_tag_2488 == ((int64_t)0ULL))) {
            V v_c_2491 = v_field_2489;
            V v_t_2494;
            switch (heff_tag_of(v_c_2491)) {
            case TAG_At: {
              V v_s_2493 = heff_dup(heff_field(v_c_2491, 1));
              v_t_2494 = v_s_2493;
              break;
            }
            default: heff_nomatch(v_c_2491);
            }
            v_t_24101 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2491}), v_t_2494});
          } else {
            if ((v_tag_2488 == ((int64_t)1ULL))) {
              V v_i_2496 = v_field_2489;
              V v_t_2499;
              switch (heff_tag_of(v_i_2496)) {
              case TAG_At: {
                V v_s_2498 = heff_dup(heff_field(v_i_2496, 1));
                v_t_2499 = v_s_2498;
                break;
              }
              default: heff_nomatch(v_i_2496);
              }
              v_t_24101 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2496}), v_t_2499});
            } else {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_t_24100 = v_field_2489;
              v_t_24101 = v_t_24100;
            }
          }
        }
        V v_t_24102 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2447));
        return (g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(v_x_2484, v_xsp_2485, v_t_24101, v_t_24102, v_sp_242));
      }
      default: return ((HeffT2){{heff_nomatch(v_x211_2446)}});
      }
    }
    case TAG_EAnn: {
      V v_a_24103 = heff_field(v_x21_241, 0);
      V v_t_24104 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EAnn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT2 v_t_24105 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_a_24103));
      V v_t_24119;
      {
        V v_field_24107 = v_t_24105.f[1];
        int64_t v_tag_24106 = ((int64_t)v_t_24105.f[0]);
        if ((v_tag_24106 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_24109 = v_field_24107;
          v_t_24119 = v_c_24109;
        } else {
          if ((v_tag_24106 == ((int64_t)1ULL))) {
            V v_i_24111 = v_field_24107;
            V v_t_24114;
            switch (heff_tag_of(v_i_24111)) {
            case TAG_At: {
              V v_s_24113 = heff_dup(heff_field(v_i_24111, 1));
              v_t_24114 = v_s_24113;
              break;
            }
            default: heff_nomatch(v_i_24111);
            }
            v_t_24119 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24111}), v_t_24114});
          } else {
            V v_t_24115 = v_field_24107;
            V v_t_24118;
            switch (heff_tag_of(v_t_24115)) {
            case TAG_At: {
              V v_s_24117 = heff_dup(heff_field(v_t_24115, 1));
              v_t_24118 = v_s_24117;
              break;
            }
            default: heff_nomatch(v_t_24115);
            }
            v_t_24119 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24115}), v_t_24118});
          }
        }
      }
      HeffT2 v_t_24120 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_24104));
      V v_t_24134;
      {
        V v_field_24122 = v_t_24120.f[1];
        int64_t v_tag_24121 = ((int64_t)v_t_24120.f[0]);
        if ((v_tag_24121 == ((int64_t)0ULL))) {
          V v_c_24124 = v_field_24122;
          V v_t_24127;
          switch (heff_tag_of(v_c_24124)) {
          case TAG_At: {
            V v_s_24126 = heff_dup(heff_field(v_c_24124, 1));
            v_t_24127 = v_s_24126;
            break;
          }
          default: heff_nomatch(v_c_24124);
          }
          v_t_24134 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24124}), v_t_24127});
        } else {
          if ((v_tag_24121 == ((int64_t)1ULL))) {
            V v_i_24129 = v_field_24122;
            V v_t_24132;
            switch (heff_tag_of(v_i_24129)) {
            case TAG_At: {
              V v_s_24131 = heff_dup(heff_field(v_i_24129, 1));
              v_t_24132 = v_s_24131;
              break;
            }
            default: heff_nomatch(v_i_24129);
            }
            v_t_24134 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_24129}), v_t_24132});
          } else {
            heff_drop_cell(v_ru_24x21_241_24EAnn, 2);
            V v_t_24133 = v_field_24122;
            v_t_24134 = v_t_24133;
          }
        }
      }
      V v_f_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_24119, v_t_24134}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24135}});
    }
    case TAG_ESpec: {
      V v_a_24136 = heff_field(v_x21_241, 0);
      V v_x_24137 = heff_field(v_x21_241, 1);
      V v_fsp_24138 = heff_field(v_x21_241, 2);
      V v_v_24139 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24ESpec = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_t_24140 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_24136));
      V v_t_24141 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24140));
      HeffT2 v_t_24142 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_24139));
      V v_t_24156;
      {
        V v_field_24144 = v_t_24142.f[1];
        int64_t v_tag_24143 = ((int64_t)v_t_24142.f[0]);
        if ((v_tag_24143 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_24146 = v_field_24144;
          v_t_24156 = v_c_24146;
        } else {
          if ((v_tag_24143 == ((int64_t)1ULL))) {
            V v_i_24148 = v_field_24144;
            V v_t_24151;
            switch (heff_tag_of(v_i_24148)) {
            case TAG_At: {
              V v_s_24150 = heff_dup(heff_field(v_i_24148, 1));
              v_t_24151 = v_s_24150;
              break;
            }
            default: heff_nomatch(v_i_24148);
            }
            v_t_24156 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24148}), v_t_24151});
          } else {
            V v_t_24152 = v_field_24144;
            V v_t_24155;
            switch (heff_tag_of(v_t_24152)) {
            case TAG_At: {
              V v_s_24154 = heff_dup(heff_field(v_t_24152, 1));
              v_t_24155 = v_s_24154;
              break;
            }
            default: heff_nomatch(v_t_24152);
            }
            v_t_24156 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24152}), v_t_24155});
          }
        }
      }
      V v_f_24157 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESpec, TAG_ISpec, 4, (V[]){v_t_24141, v_x_24137, v_fsp_24138, v_t_24156}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24157}});
    }
    case TAG_ESig: {
      V v_fs_24158 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24159 = (g_list_2emap_24s205414595x1692305030(v_fs_24158));
      V v_f_24160 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSig, 1, (V[]){v_t_24159}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_24160}});
    }
    case TAG_ESum: {
      V v_vs_24161 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24162 = (g_list_2emap_24s1258450377x973220636(v_vs_24161));
      V v_f_24163 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSum, 1, (V[]){v_t_24162}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_24163}});
    }
    case TAG_EStruct: {
      V v_fs_24164 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24165 = (g_list_2emap_24s961097229x1129443801(v_fs_24164));
      V v_f_24166 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CStruct, 1, (V[]){v_t_24165}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24166}});
    }
    case TAG_EUpdate: {
      V v_a_24167 = heff_field(v_x21_241, 0);
      V v_fs_24168 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_t_24169 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_24167));
      V v_t_24170 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24169));
      V v_t_24171 = (g_list_2emap_24s137457135x961689574(v_fs_24168));
      V v_f_24172 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IUpdate, 2, (V[]){v_t_24170, v_t_24171}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24172}});
    }
    case TAG_EMatch: {
      V v_s_24173 = heff_field(v_x21_241, 0);
      V v_alts_24174 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_t_24175 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_s_24173));
      V v_t_24176 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24175));
      V v_t_24177 = (g_list_2emap_24s1230969749x2018313496(v_alts_24174));
      V v_f_24178 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_24176, v_t_24177}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24178}});
    }
    case TAG_ELetIn: {
      V v_rhs_24179 = heff_field(v_x21_241, 0);
      V v_a_24180 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELetIn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_24181 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_rhs_24179));
      V v_t_24182 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24181));
      V v_t_24202;
      switch (heff_tag_of(v_a_24180)) {
      case TAG_At: {
        V v_x21_24183 = heff_field(v_a_24180, 0);
        V v_sp_24184 = heff_field(v_a_24180, 1);
        heff_take_n(v_a_24180, 3ULL, 2);
        switch (heff_tag_of(v_x21_24183)) {
        case TAG_MkAlt: {
          V v_p_24185 = heff_field(v_x21_24183, 0);
          V v_b_24186 = heff_field(v_x21_24183, 1);
          heff_take_n(v_x21_24183, 3ULL, 2);
          HeffT2 v_t_24187 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_b_24186));
          V v_t_24201;
          {
            V v_field_24189 = v_t_24187.f[1];
            int64_t v_tag_24188 = ((int64_t)v_t_24187.f[0]);
            if ((v_tag_24188 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_24191 = v_field_24189;
              v_t_24201 = v_c_24191;
            } else {
              if ((v_tag_24188 == ((int64_t)1ULL))) {
                V v_i_24193 = v_field_24189;
                V v_t_24196;
                switch (heff_tag_of(v_i_24193)) {
                case TAG_At: {
                  V v_s_24195 = heff_dup(heff_field(v_i_24193, 1));
                  v_t_24196 = v_s_24195;
                  break;
                }
                default: heff_nomatch(v_i_24193);
                }
                v_t_24201 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24193}), v_t_24196});
              } else {
                V v_t_24197 = v_field_24189;
                V v_t_24200;
                switch (heff_tag_of(v_t_24197)) {
                case TAG_At: {
                  V v_s_24199 = heff_dup(heff_field(v_t_24197, 1));
                  v_t_24200 = v_s_24199;
                  break;
                }
                default: heff_nomatch(v_t_24197);
                }
                v_t_24201 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24197}), v_t_24200});
              }
            }
          }
          v_t_24202 = heff_tag_at_n(v_ru_24x21_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24185, v_t_24201}), v_sp_24184});
          break;
        }
        default: heff_nomatch(v_x21_24183);
        }
        break;
      }
      default: heff_nomatch(v_a_24180);
      }
      V v_f_24203 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24182, v_t_24202}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24203}});
    }
    case TAG_EDo: {
      V v_stmts_24204 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_x1_24205 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stmts_24204)));
      switch (heff_tag_of(v_x1_24205)) {
      case TAG_Nil: {
        heff_drop(v_stmts_24204);
        V v_t_24206 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str2), NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24206, v_sp_242})}});
      }
      case TAG_Cons: {
        V v_x_24207 = heff_field(v_x1_24205, 0);
        heff_take_n(v_x1_24205, 1ULL, 2);
        switch (heff_tag_of(v_x_24207)) {
        case TAG_At: {
          V v_it11_24209 = heff_field(v_x_24207, 0);
          heff_take_n(v_x_24207, 1ULL, 2);
          switch (heff_tag_of(v_it11_24209)) {
          case TAG_StmtBind: {
            V v_ru_24it11_24209_24StmtBind = heff_take_reuse_n(v_it11_24209, 0ULL, 3);
            heff_drop(v_stmts_24204);
            V v_t_24214 = heff_tag_at_n(v_ru_24it11_24209_24StmtBind, TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str3), NTAG(TAG_Nothing)});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24214, v_sp_242})}});
          }
          case TAG_StmtLet: {
            heff_take_n(v_it11_24209, 0ULL, 2);
            heff_drop(v_stmts_24204);
            V v_t_24217 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str4), NTAG(TAG_Nothing)});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24217, v_sp_242})}});
          }
          case TAG_StmtExpr: {
            heff_take_n(v_it11_24209, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_24219 = heff_rec_n(5, shape_names__muts__loop__sp__depth, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2ecoNames_get()), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_sp_242, MK_INT(0LL)});
            V v_e_27_24220 = ({ V a_0 = v_t_24219; V a_1 = v_stmts_24204; V a_2 = NTAG(TAG_EndValue); V r_ = (g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_stmts_24204); r_; });
            V t_0 = v_e_27_24220;
            v_x2_240 = t_0;
            goto top;
          }
          case TAG_StmtLetMut: {
            V v_ru_24it11_24209_24StmtLetMut = heff_take_reuse_n(v_it11_24209, 0ULL, 3);
            heff_drop(v_stmts_24204);
            V v_t_24224 = heff_tag_at_n(v_ru_24it11_24209_24StmtLetMut, TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str5), NTAG(TAG_Nothing)});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24224, v_sp_242})}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it11_24209)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x_24207)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24205)}});
      }
    }
    case TAG_ELocal: {
      V v_body_24225 = heff_field(v_x21_241, 0);
      V v_ds_24226 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELocal = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT2 v_t_24227 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_24225));
      V v_t_24241;
      {
        V v_field_24229 = v_t_24227.f[1];
        int64_t v_tag_24228 = ((int64_t)v_t_24227.f[0]);
        if ((v_tag_24228 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_24231 = v_field_24229;
          v_t_24241 = v_c_24231;
        } else {
          if ((v_tag_24228 == ((int64_t)1ULL))) {
            V v_i_24233 = v_field_24229;
            V v_t_24236;
            switch (heff_tag_of(v_i_24233)) {
            case TAG_At: {
              V v_s_24235 = heff_dup(heff_field(v_i_24233, 1));
              v_t_24236 = v_s_24235;
              break;
            }
            default: heff_nomatch(v_i_24233);
            }
            v_t_24241 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24233}), v_t_24236});
          } else {
            V v_t_24237 = v_field_24229;
            V v_t_24240;
            switch (heff_tag_of(v_t_24237)) {
            case TAG_At: {
              V v_s_24239 = heff_dup(heff_field(v_t_24237, 1));
              v_t_24240 = v_s_24239;
              break;
            }
            default: heff_nomatch(v_t_24237);
            }
            v_t_24241 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24237}), v_t_24240});
          }
        }
      }
      V v_t_24242 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2esyntax_2epresyntax_2eclassifier_get(), 1)), v_ds_24226));
      V v_f_24243 = heff_tag_at_n(v_ru_24x21_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CLocal, 2, (V[]){v_t_24241, v_t_24242}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24243}});
    }
    case TAG_EInvalid: {
      V v_why_24244 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24245 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_why_24244, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24245, v_sp_242})}});
    }
    case TAG_EAssign: {
      V v_x_24246 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EAssign = heff_take_reuse_n(v_x21_241, 1ULL, 3);
      V v_t_24249 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str6), heff_strAppend(v_x_24246, ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str7)));
      V v_t_24250 = heff_tag_at_n(v_ru_24x21_241_24EAssign, TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_t_24249, NTAG(TAG_Nothing)});
      V v_f_24251 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24250, v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24251}});
    }
    case TAG_EWhile: {
      heff_take_n(v_x21_241, 0ULL, 2);
      V v_t_24254 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str8), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24254, v_sp_242})}});
    }
    case TAG_EFor: {
      V v_ru_24x21_241_24EFor = heff_take_reuse_n(v_x21_241, 0ULL, 3);
      V v_t_24258 = heff_tag_at_n(v_ru_24x21_241_24EFor, TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str9), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24258, v_sp_242})}});
    }
    case TAG_EIfThen: {
      heff_take_n(v_x21_241, 0ULL, 2);
      V v_t_24261 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str10), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24261, v_sp_242})}});
    }
    case TAG_EBreak: {
      V v_t_24262 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str11), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24262, v_sp_242})}});
    }
    case TAG_EContinue: {
      V v_t_24263 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str12), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24263, v_sp_242})}});
    }
    case TAG_EReturn: {
      heff_take_n(v_x21_241, 0ULL, 1);
      V v_t_24265 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str13), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24265, v_sp_242})}});
    }
    case TAG_ENest: {
      heff_take_n(v_x21_241, 0ULL, 1);
      V v_t_24267 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str14), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24267, v_sp_242})}});
    }
    case TAG_EIfLet: {
      V v_p_24268 = heff_field(v_x21_241, 0);
      V v_s_24269 = heff_field(v_x21_241, 1);
      V v_a_24270 = heff_field(v_x21_241, 2);
      V v_x214_24271 = heff_field(v_x21_241, 3);
      heff_take_n(v_x21_241, 15ULL, 4);
      switch (heff_tag_of(v_x214_24271)) {
      case TAG_Nothing: {
        heff_drop(v_p_24268);
        heff_drop(v_s_24269);
        heff_drop(v_a_24270);
        V v_t_24272 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str15), NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24272, v_sp_242})}});
      }
      case TAG_Just: {
        V v_b_24273 = heff_field(v_x214_24271, 0);
        heff_take_n(v_x214_24271, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        V v_e_24274 = (g_heff_2esyntax_2epresyntax_2eifLetOf(v_sp_242, v_p_24268, v_s_24269, v_a_24270, v_b_24273));
        V t_0 = v_e_24274;
        v_x2_240 = t_0;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x214_24271)}});
      }
    }
    case TAG_ETry: {
      heff_take_n(v_x21_241, 0ULL, 1);
      V v_t_24276 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str16), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24276, v_sp_242})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V v_x2_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x2_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_field_243});
    } else {
      if ((v_tag_242 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_243});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){v_field_243});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(a[0]);
}