// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkTry 8097
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_end 310101
#define LBL_giving 701566649
#define LBL_guard 300063423
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_stmts 311127493
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth__giving[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s112965014x579570295_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1754932173x1305177089_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1935226754x442916785_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s2006690287x151588326_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s301034265x1732874986_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eannLamOf(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2ehasReturn(V);
V g_heff_2esyntax_2epresyntax_2ehasReturn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasReturn_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo;
V g_heff_2esyntax_2epresyntax_2ewithScopeOf(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithScopeOf_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epatNames_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2epatNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatNames_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epatNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_243, ((V)&g_heff_2esyntax_2epresyntax_2epatNames_str0), 2)) {
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        heff_drop(v_x_243);
        return NTAG(TAG_Nil);
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_246 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_246));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_247); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2410 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2411); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2417 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2417));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2418); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2420 = heff_field(v_x11_241, 0);
      V v_q_2422 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_cell_2423 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2420, heff_hole()});
      V v_u_2424 = (g_heff_2esyntax_2epresyntax_2epatNames_24dps(v_q_2422, heff_dup(v_cell_2423)));
      heff_drop(v_u_2424);
      return v_cell_2423;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatNames(a[0]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_dup(heff_field(v_x3_241, 0));
    switch (heff_tag_of(v_x31_242)) {
    case TAG_EVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EBinary: {
      V v_segs_2410 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EBinary = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2412 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eaccList_24s2006690287x151588326_24cpr(v_st_240, v_segs_2410));
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v_x_2416 = v_field_2414;
          V v_y_2417 = v_field_2415;
          V v_t_2418 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EBinary, TAG_EBinary, 1, (V[]){v_y_2417}), v_sp_2412});
          return ((HeffT2){{v_x_2416, v_t_2418}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EApp: {
      V v_h_2421 = heff_field(v_x31_242, 0);
      V v_args_2422 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EApp = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2424 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2425;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2425 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2425 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_h_2421)));
        }
        HeffT2 v_t_2426 = (g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(v_x_2425, v_args_2422));
        {
          V v_field_2427 = v_t_2426.f[0];
          V v_field_2428 = v_t_2426.f[1];
          V v_x_2429 = v_field_2427;
          V v_y_2430 = v_field_2428;
          V v_t_2431 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EApp, TAG_EApp, 2, (V[]){v_h_2421, v_y_2430}), v_sp_2424});
          return ((HeffT2){{v_x_2429, v_t_2431}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENamed: {
      V v_x_2433 = heff_field(v_x31_242, 0);
      V v_e_2434 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ENamed = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2436 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2437;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2437 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2437 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_2434)));
        }
        V v_t_2438 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENamed, TAG_ENamed, 2, (V[]){v_x_2433, v_e_2434}), v_sp_2436});
        return ((HeffT2){{v_x_2437, v_t_2438}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ELam: {
      V v_b_2441 = heff_field(v_x31_242, 0);
      V v_body_2442 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELam = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2444 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2445;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2445 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2445 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_body_2442)));
        }
        V v_t_2446 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELam, TAG_ELam, 2, (V[]){v_b_2441, v_body_2442}), v_sp_2444});
        return ((HeffT2){{v_x_2445, v_t_2446}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EAnn: {
      V v_e_2447 = heff_field(v_x31_242, 0);
      V v_t_2448 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EAnn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2450 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2451;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2451 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2451 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_2447)));
        }
        V v_t_2452 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAnn, TAG_EAnn, 2, (V[]){v_e_2447, v_t_2448}), v_sp_2450});
        return ((HeffT2){{v_x_2451, v_t_2452}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESpec: {
      V v_a_2453 = heff_field(v_x31_242, 0);
      V v_x_2454 = heff_field(v_x31_242, 1);
      V v_xsp_2455 = heff_field(v_x31_242, 2);
      V v_v_2456 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24ESpec = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2458 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_2459 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_2453, v_x_2454, v_xsp_2455, v_v_2456}), v_sp_2458});
          return ((HeffT2){{NTAG(TAG_True), v_t_2459}});
        } else {
          heff_drop(v_st_240);
          V v_x_2460 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_2453)));
          V v_x_2461;
          if ((heff_dup(v_x_2460) == NTAG(TAG_True))) {
            heff_drop(v_x_2460);
            v_x_2461 = NTAG(TAG_True);
          } else {
            heff_drop(v_x_2460);
            v_x_2461 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_v_2456)));
          }
          V v_t_2462 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_2453, v_x_2454, v_xsp_2455, v_v_2456}), v_sp_2458});
          return ((HeffT2){{v_x_2461, v_t_2462}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EStruct: {
      V v_fs_2465 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EStruct = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2467 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2468 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1754932173x1305177089_24cpr(v_st_240, v_fs_2465));
        {
          V v_field_2469 = v_t_2468.f[0];
          V v_field_2470 = v_t_2468.f[1];
          V v_x_2471 = v_field_2469;
          V v_y_2472 = v_field_2470;
          V v_t_2473 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EStruct, TAG_EStruct, 1, (V[]){v_y_2472}), v_sp_2467});
          return ((HeffT2){{v_x_2471, v_t_2473}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EUpdate: {
      V v_a_2474 = heff_field(v_x31_242, 0);
      V v_fs_2475 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EUpdate = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2477 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2478;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2478 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2478 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_2474)));
        }
        HeffT2 v_t_2479 = (g_heff_2esyntax_2epresyntax_2eaccList_24s112965014x579570295_24cpr(v_x_2478, v_fs_2475));
        {
          V v_field_2480 = v_t_2479.f[0];
          V v_field_2481 = v_t_2479.f[1];
          V v_x_2482 = v_field_2480;
          V v_y_2483 = v_field_2481;
          V v_t_2484 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EUpdate, TAG_EUpdate, 2, (V[]){v_a_2474, v_y_2483}), v_sp_2477});
          return ((HeffT2){{v_x_2482, v_t_2484}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EMatch: {
      V v_s_2485 = heff_field(v_x31_242, 0);
      V v_alts_2486 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EMatch = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2488 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2489;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2489 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2489 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_s_2485)));
        }
        HeffT2 v_t_2490 = (g_heff_2esyntax_2epresyntax_2eaccList_24s301034265x1732874986_24cpr(v_x_2489, v_alts_2486));
        {
          V v_field_2491 = v_t_2490.f[0];
          V v_field_2492 = v_t_2490.f[1];
          V v_x_2493 = v_field_2491;
          V v_y_2494 = v_field_2492;
          V v_t_2495 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2485, v_y_2494}), v_sp_2488});
          return ((HeffT2){{v_x_2493, v_t_2495}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_2496 = heff_field(v_x31_242, 0);
      V v_a_2497 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELetIn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2499 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_2497)) {
          case TAG_At: {
            V v_x31_24100 = heff_field(v_a_2497, 0);
            V v_sp_24101 = heff_field(v_a_2497, 1);
            V v_ru_24a_2497_24At = heff_take_reuse_n(v_a_2497, 3ULL, 2);
            switch (heff_tag_of(v_x31_24100)) {
            case TAG_MkAlt: {
              V v_p_24102 = heff_field(v_x31_24100, 0);
              V v_e_24103 = heff_field(v_x31_24100, 1);
              heff_take_n(v_x31_24100, 3ULL, 2);
              V v_t_24104 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24102, v_e_24103}), v_sp_24101});
              V v_t_24105 = heff_tag_at_n(v_ru_24a_2497_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_2496, v_t_24104}), v_sp_2499});
              return ((HeffT2){{NTAG(TAG_True), v_t_24105}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24100)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_2497)}});
          }
        } else {
          heff_drop(v_st_240);
          V v_x_24106 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_rhs_2496)));
          switch (heff_tag_of(v_a_2497)) {
          case TAG_At: {
            V v_x31_24107 = heff_field(v_a_2497, 0);
            V v_sp_24108 = heff_field(v_a_2497, 1);
            V v_ru_24a_2497_24At = heff_take_reuse_n(v_a_2497, 3ULL, 2);
            switch (heff_tag_of(v_x31_24107)) {
            case TAG_MkAlt: {
              V v_p_24109 = heff_field(v_x31_24107, 0);
              V v_e_24110 = heff_field(v_x31_24107, 1);
              heff_take_n(v_x31_24107, 3ULL, 2);
              V v_x_24111;
              if ((heff_dup(v_x_24106) == NTAG(TAG_True))) {
                heff_drop(v_x_24106);
                v_x_24111 = NTAG(TAG_True);
              } else {
                heff_drop(v_x_24106);
                v_x_24111 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_24110)));
              }
              V v_t_24112 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24109, v_e_24110}), v_sp_24108});
              V v_t_24113 = heff_tag_at_n(v_ru_24a_2497_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_2496, v_t_24112}), v_sp_2499});
              return ((HeffT2){{v_x_24111, v_t_24113}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24107)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_2497)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24114 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EDo = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24116 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24117 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_st_240, v_ss_24114));
        {
          V v_field_24118 = v_t_24117.f[0];
          V v_field_24119 = v_t_24117.f[1];
          V v_x_24120 = v_field_24118;
          V v_y_24121 = v_field_24119;
          V v_t_24122 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EDo, TAG_EDo, 1, (V[]){v_y_24121}), v_sp_24116});
          return ((HeffT2){{v_x_24120, v_t_24122}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EAssign: {
      V v_x_24126 = heff_field(v_x31_242, 0);
      V v_xsp_24127 = heff_field(v_x31_242, 1);
      V v_e_24128 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EAssign = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24130 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24131;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24131 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24131 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_24128)));
        }
        V v_t_24132 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAssign, TAG_EAssign, 3, (V[]){v_x_24126, v_xsp_24127, v_e_24128}), v_sp_24130});
        return ((HeffT2){{v_x_24131, v_t_24132}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24133 = heff_field(v_x31_242, 0);
      V v_body_24134 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EWhile = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24136 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24137;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24137 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24137 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_c_24133)));
        }
        HeffT2 v_t_24138 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_x_24137, v_body_24134));
        {
          V v_field_24139 = v_t_24138.f[0];
          V v_field_24140 = v_t_24138.f[1];
          V v_x_24141 = v_field_24139;
          V v_y_24142 = v_field_24140;
          V v_t_24143 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWhile, TAG_EWhile, 2, (V[]){v_c_24133, v_y_24142}), v_sp_24136});
          return ((HeffT2){{v_x_24141, v_t_24143}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EFor: {
      V v_p_24144 = heff_field(v_x31_242, 0);
      V v_c_24145 = heff_field(v_x31_242, 1);
      V v_body_24146 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EFor = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24148 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24149;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24149 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24149 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_c_24145)));
        }
        HeffT2 v_t_24150 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_x_24149, v_body_24146));
        {
          V v_field_24151 = v_t_24150.f[0];
          V v_field_24152 = v_t_24150.f[1];
          V v_x_24153 = v_field_24151;
          V v_y_24154 = v_field_24152;
          V v_t_24155 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EFor, TAG_EFor, 3, (V[]){v_p_24144, v_c_24145, v_y_24154}), v_sp_24148});
          return ((HeffT2){{v_x_24153, v_t_24155}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24156 = heff_field(v_x31_242, 0);
      V v_a_24157 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EIfThen = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24159 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_24160 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24156, v_a_24157}), v_sp_24159});
          return ((HeffT2){{NTAG(TAG_True), v_t_24160}});
        } else {
          heff_drop(v_st_240);
          V v_x_24161 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_c_24156)));
          V v_x_24162;
          if ((heff_dup(v_x_24161) == NTAG(TAG_True))) {
            heff_drop(v_x_24161);
            v_x_24162 = NTAG(TAG_True);
          } else {
            heff_drop(v_x_24161);
            v_x_24162 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_24157)));
          }
          V v_t_24163 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24156, v_a_24157}), v_sp_24159});
          return ((HeffT2){{v_x_24162, v_t_24163}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EBreak: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EReturn: {
      V v_e_24164 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EReturn = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24166 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24167;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24167 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24167 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_24164)));
        }
        V v_t_24168 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EReturn, TAG_EReturn, 1, (V[]){v_e_24164}), v_sp_24166});
        return ((HeffT2){{v_x_24167, v_t_24168}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ENest: {
      V v_e_24169 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ENest = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24171 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24172;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24172 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24172 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_24169)));
        }
        V v_t_24173 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENest, TAG_ENest, 1, (V[]){v_e_24169}), v_sp_24171});
        return ((HeffT2){{v_x_24172, v_t_24173}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24174 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ELazy = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24176 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24177;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24177 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24177 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_24174)));
        }
        V v_t_24178 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELazy, TAG_ELazy, 1, (V[]){v_e_24174}), v_sp_24176});
        return ((HeffT2){{v_x_24177, v_t_24178}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24179 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETuple = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24181 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24182 = (g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(v_st_240, v_es_24179));
        {
          V v_field_24183 = v_t_24182.f[0];
          V v_field_24184 = v_t_24182.f[1];
          V v_x_24185 = v_field_24183;
          V v_y_24186 = v_field_24184;
          V v_t_24187 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETuple, TAG_ETuple, 1, (V[]){v_y_24186}), v_sp_24181});
          return ((HeffT2){{v_x_24185, v_t_24187}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24188 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETry = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24190 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        switch (heff_tag_of(v_tr_24188)) {
        case TAG_MkTry: {
          V v_err_24191 = heff_field(v_tr_24188, 0);
          V v_body_24192 = heff_field(v_tr_24188, 1);
          V v_c_24193 = heff_field(v_tr_24188, 2);
          V v_ru_24tr_24188_24MkTry = heff_take_reuse_n(v_tr_24188, 7ULL, 3);
          HeffT2 v_t_24194 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_st_240, v_body_24192));
          {
            V v_field_24195 = v_t_24194.f[0];
            V v_field_24196 = v_t_24194.f[1];
            V v_x_24197 = v_field_24195;
            V v_y_24198 = v_field_24196;
            switch (heff_tag_of(v_c_24193)) {
            case TAG_MkCatchArm: {
              V v_b_24199 = heff_field(v_c_24193, 0);
              V v_ss_24200 = heff_field(v_c_24193, 1);
              heff_take_n(v_c_24193, 3ULL, 2);
              HeffT2 v_t_24201 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_x_24197, v_ss_24200));
              {
                V v_field_24202 = v_t_24201.f[0];
                V v_field_24203 = v_t_24201.f[1];
                V v_x_24204 = v_field_24202;
                V v_y_24205 = v_field_24203;
                V v_t_24206 = heff_tag_at_n(v_ru_24tr_24188_24MkTry, TAG_MkTry, 3, (V[]){v_err_24191, v_y_24198, heff_tag_n(TAG_MkCatchArm, 2, (V[]){v_b_24199, v_y_24205})});
                V v_t_24207 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETry, TAG_ETry, 1, (V[]){v_t_24206}), v_sp_24190});
                return ((HeffT2){{v_x_24204, v_t_24207}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_c_24193)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_tr_24188)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWith: {
      V v_w_24208 = heff_field(v_x31_242, 0);
      V v_x_24209 = heff_field(v_x31_242, 1);
      V v_xsp_24210 = heff_field(v_x31_242, 2);
      V v_body_24211 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24EWith = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24213 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24214;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24214 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24214 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_w_24208)));
        }
        HeffT2 v_t_24215 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_x_24214, v_body_24211));
        {
          V v_field_24216 = v_t_24215.f[0];
          V v_field_24217 = v_t_24215.f[1];
          V v_x_24218 = v_field_24216;
          V v_y_24219 = v_field_24217;
          V v_t_24220 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWith, TAG_EWith, 4, (V[]){v_w_24208, v_x_24209, v_xsp_24210, v_y_24219}), v_sp_24213});
          return ((HeffT2){{v_x_24218, v_t_24220}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1935226754x442916785_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_st_244;
    if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
      heff_drop(v_st_240);
      v_st_244 = NTAG(TAG_True);
    } else {
      heff_drop(v_st_240);
      v_st_244 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_x_242)));
    }
    HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1935226754x442916785_24cpr(v_st_244, v_xs_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_x_248 = v_field_246;
      V v_y_249 = v_field_247;
      return ((HeffT2){{v_x_248, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_y_249})}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithScopeOf_str0, 10, "leaveScope");
Clo g_heff_2esyntax_2epresyntax_2ewithScopeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewithScopeOf_entry, 8, 0};

V g_heff_2esyntax_2epresyntax_2ewithScopeOf(V v_t_240, V v_cx_241, V v_sp_242, V v_w_243, V v_x_244, V v_xsp_245, V v_body_246, V v_end_247) {
top: ;
  V v_t_248 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
  HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_248}), NTAG(TAG_Nil), v_w_243));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_x_2412 = v_field_2410;
    V v_y_2413 = v_field_2411;
    V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
    V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2414}), heff_dup(heff_rfield(v_cx_241, 3))});
    V v_t_2416 = heff_intAdd(heff_dup(heff_rfield(v_cx_241, 4)), MK_INT(1LL));
    V v_t_2417 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){heff_dup(heff_rfield(v_cx_241, 0)), heff_dup(heff_rfield(v_cx_241, 1)), heff_dup(heff_rfield(v_cx_241, 2)), heff_dup(heff_rfield(v_cx_241, 3)), v_t_2416, heff_dup(heff_rfield(v_cx_241, 5))});
    V v_e_2418 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_t_2417, v_body_246, v_end_247}));
    V v_t_2419 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_244, heff_dup(v_xsp_245)}), heff_dup(v_e_2418)});
    V v_t_2422;
    switch (heff_tag_of(v_e_2418)) {
    case TAG_At: {
      V v_s_2421 = heff_field(v_e_2418, 1);
      heff_take_n(v_e_2418, 2ULL, 2);
      v_t_2422 = v_s_2421;
      break;
    }
    default: heff_nomatch(v_e_2418);
    }
    V v_t_2423 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_245, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_t_2423}), NTAG(TAG_Nil)});
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2eapp(v_y_2413, v_t_2424));
    V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithScopeOf_str0)}), v_sp_242});
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
    V v_t_2428 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_t_2427})));
    return ({ V a_0 = v_cx_241; V a_1 = v_x_2412; V a_2 = v_t_2428; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
  }
}
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewithScopeOf(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eannLamOf_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2eannLamOf(V v_x_240, V v_xsp_241, V v_t_242, V v_x4_243, V v_sp_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(v_x_240, v_xsp_241, v_t_242, v_x4_243, v_sp_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_field_247});
    } else {
      if ((v_tag_246 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_247});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){v_field_247});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eannLamOf(a[0], a[1], a[2], a[3], a[4]);
}