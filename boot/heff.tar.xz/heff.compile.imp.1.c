// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DLet 13606
#define TAG_DSet 20333
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_arity 294440695
#define LBL_atom 9500184
#define LBL_bindTo 558176963
#define LBL_body 9524841
#define LBL_cond 9554921
#define LBL_count 296209705
#define LBL_full 9650006
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_op 10312
#define LBL_pred 9944808
#define LBL_setTo 310686359
#define LBL_simple 1044855005
#define LBL_sts 323756
#define LBL_tail 10047767
#define LBL_tl 10463
#define LBL_underLam 296337946
#define LBL_val 326043
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__arity[] = {LBL_key, LBL_arity};
V g_heff_2ecompile_2eimp_2eallL(V, V);
V g_heff_2ecompile_2eimp_2eallL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eallL_clo;
V g_heff_2ecompile_2eimp_2eallL_24s1889379348x1668327921(V);
V g_heff_2ecompile_2eimp_2eallL_24s1889379348x1668327921_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eallL_24s1889379348x1668327921_clo;
V g_heff_2ecompile_2eimp_2earmNamed(V, V);
V g_heff_2ecompile_2eimp_2earmNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2earmNamed_clo;
V g_heff_2ecompile_2eimp_2eatomOf(V, V);
V g_heff_2ecompile_2eimp_2eatomOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eatomOf_clo;
V g_heff_2ecompile_2eimp_2eatomsOf(V, V);
V g_heff_2ecompile_2eimp_2eatomsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eatomsOf_clo;
V g_heff_2ecompile_2eimp_2ecaseSet(V, V, V, V);
V g_heff_2ecompile_2eimp_2ecaseSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2ecaseSet_clo;
V g_heff_2ecompile_2eimp_2ecaseTail(V, V, V, V);
V g_heff_2ecompile_2eimp_2ecaseTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2ecaseTail_clo;
V g_heff_2ecompile_2eimp_2econdIf(V, V, V);
V g_heff_2ecompile_2eimp_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2econdIf_clo;
V g_heff_2ecompile_2eimp_2econdShaped(V);
V g_heff_2ecompile_2eimp_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2econdShaped_clo;
V g_heff_2ecompile_2eimp_2edeclBefore(V, V);
V g_heff_2ecompile_2eimp_2edeclBefore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2edeclBefore_clo;
V g_heff_2ecompile_2eimp_2edefOf(V, V, V);
V g_heff_2ecompile_2eimp_2edefOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2edefOf_clo;
V g_heff_2ecompile_2eimp_2efirstNamesTl(V);
V g_heff_2ecompile_2eimp_2efirstNamesTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2efirstNamesTl_clo;
V g_heff_2ecompile_2eimp_2eisRel(V);
V g_heff_2ecompile_2eimp_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eisRel_clo;
V g_heff_2ecompile_2eimp_2eisRelCall(V);
V g_heff_2ecompile_2eimp_2eisRelCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eisRelCall_clo;
V g_heff_2ecompile_2eimp_2eisSimple(V);
V g_heff_2ecompile_2eimp_2eisSimple_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eisSimple_clo;
V g_heff_2ecompile_2eimp_2ematchSet(V, V, V, V);
V g_heff_2ecompile_2eimp_2ematchSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2ematchSet_clo;
V g_heff_2ecompile_2eimp_2eopNamesTop(V);
V g_heff_2ecompile_2eimp_2eopNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eopNamesTop_clo;
V g_heff_2ecompile_2eimp_2eopOf(V, V);
V g_heff_2ecompile_2eimp_2eopOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eopOf_clo;
V g_heff_2ecompile_2eimp_2eopTail(V, V);
V g_heff_2ecompile_2eimp_2eopTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eopTail_clo;
V g_heff_2ecompile_2eimp_2epartsCond_24s361583419x1348357017(V, V);
V g_heff_2ecompile_2eimp_2epartsCond_24s361583419x1348357017_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsCond_24s361583419x1348357017_clo;
V g_heff_2ecompile_2eimp_2epartsOp(V, V, V);
V g_heff_2ecompile_2eimp_2epartsOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsOp_clo;
V g_heff_2ecompile_2eimp_2epartsOp_24s869541283x1897549890(V, V);
V g_heff_2ecompile_2eimp_2epartsOp_24s869541283x1897549890_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsOp_24s869541283x1897549890_clo;
V g_heff_2ecompile_2eimp_2epartsSt(V, V, V);
V g_heff_2ecompile_2eimp_2epartsSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsSt_clo;
V g_heff_2ecompile_2eimp_2epartsSt_24s1201326915x371226947(V, V);
V g_heff_2ecompile_2eimp_2epartsSt_24s1201326915x371226947_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsSt_24s1201326915x371226947_clo;
V g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(V, V);
V g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174_clo;
V g_heff_2ecompile_2eimp_2epartsVal(V, V, V);
V g_heff_2ecompile_2eimp_2epartsVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsVal_clo;
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990(V, V);
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_clo;
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_24dps(V, V, V);
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_24dps_clo;
V g_heff_2ecompile_2eimp_2epk_get(void);
V g_heff_2ecompile_2eimp_2epredAny(V, V);
V g_heff_2ecompile_2eimp_2epredAny_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epredAny_clo;
V g_heff_2ecompile_2eimp_2epredLets(V, V);
V g_heff_2ecompile_2eimp_2epredLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epredLets_clo;
V g_heff_2ecompile_2eimp_2epredValue(V, V);
V g_heff_2ecompile_2eimp_2epredValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epredValue_clo;
V g_heff_2ecompile_2eimp_2erelPrims_get(void);
V g_heff_2ecompile_2eimp_2esimpleOf(V, V);
V g_heff_2ecompile_2eimp_2esimpleOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2esimpleOf_clo;
V g_heff_2ecompile_2eimp_2esinkTest(V, V, V);
V g_heff_2ecompile_2eimp_2esinkTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2esinkTest_clo;
V g_heff_2ecompile_2eimp_2etailOf(V, V, V);
V g_heff_2ecompile_2eimp_2etailOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2etailOf_clo;
V g_heff_2ecompile_2eimp_2etailSelf(V, V, V);
V g_heff_2ecompile_2eimp_2etailSelf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2etailSelf_clo;
V g_heff_2ecompile_2eimp_2etestTail(V, V, V, V, V, V);
V g_heff_2ecompile_2eimp_2etestTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2etestTail_clo;
V g_heff_2ecompile_2eimp_2etimesIn(V, V);
V g_heff_2ecompile_2eimp_2etimesIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2etimesIn_clo;
V g_heff_2ecompile_2eimp_2etoDest(V, V, V);
V g_heff_2ecompile_2eimp_2etoDest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2etoDest_clo;
V g_heff_2ecompile_2eimp_2etraverseN(V, V);
V g_heff_2ecompile_2eimp_2etraverseN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2etraverseN_clo;
V g_heff_2ecompile_2eimp_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimp_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2evalNamesTop_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f1992548173x1980409276(V, V, V, V);
V g_list_2efoldl_24f1992548173x1980409276_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1992548173x1980409276_clo;
V g_list_2efoldl_24s1040186323x1541137667(V, V);
V g_list_2efoldl_24s1040186323x1541137667_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1040186323x1541137667_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1156317992x794106048(V, V);
V g_list_2efoldl_24s1156317992x794106048_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1156317992x794106048_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s141827321x1562243673(V, V);
V g_list_2efoldl_24s141827321x1562243673_entry(V self, V *a);
extern Clo g_list_2efoldl_24s141827321x1562243673_clo;
V g_list_2efoldl_24s1882202792x677718657(V, V);
V g_list_2efoldl_24s1882202792x677718657_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1882202792x677718657_clo;
V g_list_2efoldl_24s432565707x521643915(V, V);
V g_list_2efoldl_24s432565707x521643915_entry(V self, V *a);
extern Clo g_list_2efoldl_24s432565707x521643915_clo;
V g_list_2efoldl_24s71083851x23251329(V, V);
V g_list_2efoldl_24s71083851x23251329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s71083851x23251329_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2ecompile_2eimp_2eallL_24s1889379348x1668327921_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2eallL_24s1889379348x1668327921_entry, 1, 0};

V g_heff_2ecompile_2eimp_2eallL_24s1889379348x1668327921(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ecompile_2eimp_2eisSimple(a_0)); heff_drop(v_t_245); r_; });
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimp_2eallL_24s1889379348x1668327921_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimp_2eallL_24s1889379348x1668327921(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimp_2eisSimple_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2eisSimple_entry, 1, 0};

V g_heff_2ecompile_2eimp_2eisSimple(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eimp_2eallL_24s1889379348x1668327921(v_fs_2410);
  }
  case TAG_EProj: {
    V v_e_2412 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2412;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2417 = heff_field(v_x1_240, 1);
    return (g_heff_2ecompile_2eimp_2eallL(((V)&g_heff_2ecompile_2eimp_2eisSimple_clo), v_as_2417));
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2421 = heff_field(v_x1_240, 0);
    V v_as_2422 = heff_field(v_x1_240, 1);
    V v_x1_2423 = ({ V a_0 = heff_dup(v_p_2421); V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_2423) == NTAG(TAG_True))) {
      heff_drop(v_x1_2423);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_2423);
      return (g_heff_2ecompile_2eimp_2eallL(((V)&g_heff_2ecompile_2eimp_2eisSimple_clo), v_as_2422));
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eimp_2eisSimple_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimp_2eisSimple(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eimp_2erelPrims_str0, 6, "runeLe");
HEFF_LIT(g_heff_2ecompile_2eimp_2erelPrims_str1, 6, "runeEq");
HEFF_LIT(g_heff_2ecompile_2eimp_2erelPrims_str2, 6, "runeLt");
HEFF_LIT(g_heff_2ecompile_2eimp_2erelPrims_str3, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2eimp_2erelPrims_str4, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2eimp_2erelPrims_str5, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2eimp_2erelPrims_str6, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2eimp_2erelPrims_str7, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eimp_2erelPrims_str8, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2eimp_2erelPrims_str9, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eimp_2erelPrims_str10, 5, "intLt");

static V g_heff_2ecompile_2eimp_2erelPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eimp_2erelPrims_st;
static V g_heff_2ecompile_2eimp_2erelPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2erelPrims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2erelPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2erelPrims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2erelPrims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2erelPrims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2erelPrims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2erelPrims_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2erelPrims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2erelPrims_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2erelPrims_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2erelPrims_str10), v_t_244})});
}
V g_heff_2ecompile_2eimp_2erelPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eimp_2erelPrims_st)) return g_heff_2ecompile_2eimp_2erelPrims_val;
  return heff_global(&g_heff_2ecompile_2eimp_2erelPrims_val, &g_heff_2ecompile_2eimp_2erelPrims_st, g_heff_2ecompile_2eimp_2erelPrims_init);
}
Clo g_heff_2ecompile_2eimp_2earmNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2earmNamed_entry, 2, 0};

V g_heff_2ecompile_2eimp_2earmNamed(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      if (heff_strEq_c(heff_dup(v_t2_244), heff_dup(v_t_240))) {
        switch (heff_tag_of(v_vs_245)) {
        case TAG_Nil: {
          heff_drop(v_t_240);
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_b_246)});
        }
        case TAG_Cons: {
          V t_0 = v_t_240;
          V t_1 = v_rest_243;
          v_t_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_vs_245);
        }
      } else {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimp_2earmNamed_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimp_2earmNamed(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eimp_2eisRelCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2eisRelCall_entry, 1, 0};

V g_heff_2ecompile_2eimp_2eisRelCall(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2421 = heff_field(v_e_240, 0);
    V v_e2_2422 = heff_field(v_e_240, 1);
    switch (heff_tag_of(v_e2_2422)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_e22_2424 = heff_field(v_e2_2422, 1);
      switch (heff_tag_of(v_e22_2424)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e222_2426 = heff_field(v_e22_2424, 1);
        switch (heff_tag_of(v_e222_2426)) {
        case TAG_Nil: {
          HEFF_LAST return g_heff_2ecompile_2eimp_2eisRel(heff_dup(v_p_2421));
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_e222_2426);
        }
      }
      default: return heff_nomatch(v_e22_2424);
      }
    }
    default: return heff_nomatch(v_e2_2422);
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eimp_2eisRelCall_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimp_2eisRelCall(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eimp_2esinkTest_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimp_2esinkTest_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eimp_2esinkTest_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimp_2esinkTest_str3, 5, "False");
V g_heff_2ecompile_2eimp_2esinkTest_lam0(V self, V *args);
V g_heff_2ecompile_2eimp_2esinkTest_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimp_2esinkTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2esinkTest_entry, 3, 0};

V g_heff_2ecompile_2eimp_2esinkTest(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_b_242)) {
  case TAG_EVar: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    V v_z_249 = heff_field(v_b_242, 0);
    V v_b2_2410 = heff_field(v_b_242, 1);
    V v_e_2411 = heff_field(v_b_242, 2);
    V v_ru_24b_242_24ELet = heff_take_reuse_n(v_b_242, 7ULL, 3);
    switch (heff_tag_of(v_b2_2410)) {
    case TAG_EVar: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_b2_2410, 0ULL, 3);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_b2_2410, 0ULL, 4);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      V v_b21_2429 = heff_field(v_b2_2410, 0);
      V v_arms_2430 = heff_field(v_b2_2410, 1);
      V v_ru_24b2_2410_24EMatch = heff_take_reuse_n(v_b2_2410, 3ULL, 2);
      switch (heff_tag_of(v_b21_2429)) {
      case TAG_EVar: {
        V v_y_2431 = heff_field(v_b21_2429, 0);
        V v_ru_24b21_2429_24EVar = heff_take_reuse_n(v_b21_2429, 1ULL, 1);
        if (heff_strEq_c(heff_dup(v_x_240), v_y_2431)) {
          V v_t_2433 = (g_heff_2ecompile_2eimp_2eisRelCall(v_a_241));
          if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
            heff_drop(v_t_2433);
            V v_t_2434 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_2430));
            V v_x1_2440;
            if (heff_intEq_c(v_t_2434, MK_INT(2LL))) {
              V v_t_2436 = (g_heff_2ecompile_2eimp_2earmNamed(((V)&g_heff_2ecompile_2eimp_2esinkTest_str0), v_arms_2430));
              switch (heff_tag_of(v_t_2436)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
                heff_drop_cell(v_ru_24b21_2429_24EVar, 1);
                v_x1_2440 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_t_2437 = heff_field(v_t_2436, 0);
                heff_take_n(v_t_2436, 1ULL, 1);
                V v_t_2438 = (g_heff_2ecompile_2eimp_2earmNamed(((V)&g_heff_2ecompile_2eimp_2esinkTest_str1), v_arms_2430));
                switch (heff_tag_of(v_t_2438)) {
                case TAG_Nothing: {
                  heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
                  heff_drop_cell(v_ru_24b21_2429_24EVar, 1);
                  heff_drop(v_t_2437);
                  v_x1_2440 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_f_2439 = heff_field(v_t_2438, 0);
                  heff_take_n(v_t_2438, 1ULL, 1);
                  v_x1_2440 = heff_tag_at_n(v_ru_24b21_2429_24EVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24b2_2410_24EMatch, TAG_MkPair, 2, (V[]){v_t_2437, v_f_2439})});
                  break;
                }
                default: heff_nomatch(v_t_2438);
                }
                break;
              }
              default: heff_nomatch(v_t_2436);
              }
            } else {
              heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
              heff_drop_cell(v_ru_24b21_2429_24EVar, 1);
              v_x1_2440 = NTAG(TAG_Nothing);
            }
            V v_t_2442;
            switch (heff_tag_of(v_x1_2440)) {
            case TAG_Nothing: {
              v_t_2442 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              heff_take_n(v_x1_2440, 0ULL, 1);
              v_t_2442 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x1_2440);
            }
            if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
              heff_drop(v_t_2442);
              V v_x1_2453 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eimp_2esinkTest_lam0, 1, 1, (V[]){heff_dup(v_x_240)}), v_arms_2430));
              if ((heff_dup(v_x1_2453) == NTAG(TAG_True))) {
                heff_drop(v_x_240);
                heff_drop(v_a_241);
                heff_drop(v_z_249);
                heff_drop(v_e_2411);
                heff_drop_cell(v_ru_24b_242_24ELet, 3);
                heff_drop(v_arms_2430);
                heff_drop(v_x1_2453);
                return NTAG(TAG_Nothing);
              } else {
                heff_drop(v_x1_2453);
                V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2411), NTAG(TAG_Nil)});
                V v_t_2455 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), v_t_2454));
                V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2411), NTAG(TAG_Nil)});
                V v_t_2457 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_2456));
                V v_t_2458 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2455, v_t_2457}), 0, 2);
                if (heff_intEq_c(v_t_2458, MK_INT(0LL))) {
                  V v_t_2460 = heff_tag_at_n(v_ru_24b_242_24ELet, TAG_ELet, 3, (V[]){v_z_249, heff_tag_n(TAG_EMatch, 2, (V[]){v_a_241, v_arms_2430}), v_e_2411});
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2460});
                } else {
                  heff_drop(v_a_241);
                  heff_drop(v_z_249);
                  heff_drop(v_e_2411);
                  heff_drop_cell(v_ru_24b_242_24ELet, 3);
                  heff_drop(v_arms_2430);
                  return NTAG(TAG_Nothing);
                }
              }
            } else {
              heff_drop(v_x_240);
              heff_drop(v_a_241);
              heff_drop(v_z_249);
              heff_drop(v_e_2411);
              heff_drop_cell(v_ru_24b_242_24ELet, 3);
              heff_drop(v_arms_2430);
              heff_drop(v_t_2442);
              return NTAG(TAG_Nothing);
            }
          } else {
            heff_drop(v_x_240);
            heff_drop(v_a_241);
            heff_drop(v_z_249);
            heff_drop(v_e_2411);
            heff_drop_cell(v_ru_24b_242_24ELet, 3);
            heff_drop(v_arms_2430);
            heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
            heff_drop_cell(v_ru_24b21_2429_24EVar, 1);
            heff_drop(v_t_2433);
            return NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_x_240);
          heff_drop(v_a_241);
          heff_drop(v_z_249);
          heff_drop(v_e_2411);
          heff_drop_cell(v_ru_24b_242_24ELet, 3);
          heff_drop(v_arms_2430);
          heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
          heff_drop_cell(v_ru_24b21_2429_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
      }
      case TAG_EGlobal: {
        heff_take_n(v_b21_2429, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_ELam: {
        heff_take_n(v_b21_2429, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EApp: {
        heff_take_n(v_b21_2429, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_ELet: {
        heff_take_n(v_b21_2429, 0ULL, 3);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_ERecord: {
        heff_take_n(v_b21_2429, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EProj: {
        heff_take_n(v_b21_2429, 0ULL, 4);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_ETag: {
        heff_take_n(v_b21_2429, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EMatch: {
        heff_take_n(v_b21_2429, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrim: {
        heff_take_n(v_b21_2429, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_b21_2429, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_ECall: {
        heff_take_n(v_b21_2429, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EInt: {
        heff_take_n(v_b21_2429, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat: {
        heff_take_n(v_b21_2429, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EStr: {
        heff_take_n(v_b21_2429, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EBytes: {
        heff_take_n(v_b21_2429, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFixed: {
        heff_take_n(v_b21_2429, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat32: {
        heff_take_n(v_b21_2429, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EAbandon: {
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFix: {
        heff_take_n(v_b21_2429, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2430);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_b21_2429);
      }
    }
    case TAG_EPrim: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_b2_2410);
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_b_242, 0ULL, 4);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    V v_b1_24115 = heff_field(v_b_242, 0);
    V v_arms_24116 = heff_field(v_b_242, 1);
    V v_ru_24b_242_24EMatch = heff_take_reuse_n(v_b_242, 3ULL, 2);
    switch (heff_tag_of(v_b1_24115)) {
    case TAG_EVar: {
      V v_y_24117 = heff_field(v_b1_24115, 0);
      V v_ru_24b1_24115_24EVar = heff_take_reuse_n(v_b1_24115, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_x_240), v_y_24117)) {
        V v_t_24119 = (g_heff_2ecompile_2eimp_2eisRelCall(v_a_241));
        if ((heff_dup(v_t_24119) == NTAG(TAG_True))) {
          heff_drop(v_t_24119);
          V v_t_24120 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_24116));
          V v_x1_24126;
          if (heff_intEq_c(v_t_24120, MK_INT(2LL))) {
            V v_t_24122 = (g_heff_2ecompile_2eimp_2earmNamed(((V)&g_heff_2ecompile_2eimp_2esinkTest_str2), v_arms_24116));
            switch (heff_tag_of(v_t_24122)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24b_242_24EMatch, 2);
              heff_drop_cell(v_ru_24b1_24115_24EVar, 1);
              v_x1_24126 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_t_24123 = heff_field(v_t_24122, 0);
              heff_take_n(v_t_24122, 1ULL, 1);
              V v_t_24124 = (g_heff_2ecompile_2eimp_2earmNamed(((V)&g_heff_2ecompile_2eimp_2esinkTest_str3), v_arms_24116));
              switch (heff_tag_of(v_t_24124)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24b_242_24EMatch, 2);
                heff_drop_cell(v_ru_24b1_24115_24EVar, 1);
                heff_drop(v_t_24123);
                v_x1_24126 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_f_24125 = heff_field(v_t_24124, 0);
                heff_take_n(v_t_24124, 1ULL, 1);
                v_x1_24126 = heff_tag_at_n(v_ru_24b1_24115_24EVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24b_242_24EMatch, TAG_MkPair, 2, (V[]){v_t_24123, v_f_24125})});
                break;
              }
              default: heff_nomatch(v_t_24124);
              }
              break;
            }
            default: heff_nomatch(v_t_24122);
            }
          } else {
            heff_drop_cell(v_ru_24b_242_24EMatch, 2);
            heff_drop_cell(v_ru_24b1_24115_24EVar, 1);
            v_x1_24126 = NTAG(TAG_Nothing);
          }
          switch (heff_tag_of(v_x1_24126)) {
          case TAG_Nothing: {
            heff_drop(v_x_240);
            heff_drop(v_a_241);
            heff_drop(v_arms_24116);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_ru_24x1_24126_24Just = heff_take_reuse_n(v_x1_24126, 0ULL, 1);
            V v_x1_24138 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eimp_2esinkTest_lam1, 1, 1, (V[]){v_x_240}), v_arms_24116));
            if ((heff_dup(v_x1_24138) == NTAG(TAG_True))) {
              heff_drop(v_a_241);
              heff_drop(v_arms_24116);
              heff_drop_cell(v_ru_24x1_24126_24Just, 1);
              heff_drop(v_x1_24138);
              return NTAG(TAG_Nothing);
            } else {
              heff_drop(v_x1_24138);
              return heff_tag_at_n(v_ru_24x1_24126_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_a_241, v_arms_24116})});
            }
          }
          default: return heff_nomatch(v_x1_24126);
          }
        } else {
          heff_drop(v_x_240);
          heff_drop(v_a_241);
          heff_drop(v_arms_24116);
          heff_drop_cell(v_ru_24b_242_24EMatch, 2);
          heff_drop_cell(v_ru_24b1_24115_24EVar, 1);
          heff_drop(v_t_24119);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_arms_24116);
        heff_drop_cell(v_ru_24b_242_24EMatch, 2);
        heff_drop_cell(v_ru_24b1_24115_24EVar, 1);
        return NTAG(TAG_Nothing);
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_b1_24115, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_b1_24115, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_b1_24115, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_b1_24115, 0ULL, 3);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_b1_24115, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_b1_24115, 0ULL, 4);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_b1_24115, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_b1_24115, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_b1_24115, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_b1_24115, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_b1_24115, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_b1_24115, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_n(v_b1_24115, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_b1_24115, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_b1_24115, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_b1_24115, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_n(v_b1_24115, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_b1_24115, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24116);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_b1_24115);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EBytes: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_b_242);
  }
}
V g_heff_2ecompile_2eimp_2esinkTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2esinkTest(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimp_2esinkTest_lam0(V self, V *args) {
  V v_a_2443 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_2447;
  switch (heff_tag_of(v_a_2443)) {
  case TAG_MkArm: {
    V v_b_2446 = heff_field(v_a_2443, 2);
    heff_take_n(v_a_2443, 4ULL, 3);
    v_e_2447 = v_b_2446;
    break;
  }
  default: heff_nomatch(v_a_2443);
  }
  V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2447), NTAG(TAG_Nil)});
  V v_t_2449 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), v_t_2448));
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2447, NTAG(TAG_Nil)});
  V v_t_2451 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_2450));
  V v_x_2452 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2449, v_t_2451}), 0, 2);
  return heff_intLt(MK_INT(0LL), v_x_2452);
}
V g_heff_2ecompile_2eimp_2esinkTest_lam1(V self, V *args) {
  V v_a_24128 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_24132;
  switch (heff_tag_of(v_a_24128)) {
  case TAG_MkArm: {
    V v_b_24131 = heff_field(v_a_24128, 2);
    heff_take_n(v_a_24128, 4ULL, 3);
    v_e_24132 = v_b_24131;
    break;
  }
  default: heff_nomatch(v_a_24128);
  }
  V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_24132), NTAG(TAG_Nil)});
  V v_t_24134 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), v_t_24133));
  V v_t_24135 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_24132, NTAG(TAG_Nil)});
  V v_t_24136 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_24135));
  V v_x_24137 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_24134, v_t_24136}), 0, 2);
  return heff_intLt(MK_INT(0LL), v_x_24137);
}
HEFF_LIT(g_heff_2ecompile_2eimp_2epredValue_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimp_2epredValue_str1, 1, "c");
V g_heff_2ecompile_2eimp_2epredValue_lam0(V self, V *args);
V g_heff_2ecompile_2eimp_2epredValue_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimp_2epredValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epredValue_entry, 2, 0};

V g_heff_2ecompile_2eimp_2epredValue(V v_g_240, V v_e_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2eimp_2eisSimple(v_e_241));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2epredValue_lam0, 1, 1, (V[]){v_m_243});
  } else {
    heff_drop(v_t_242);
    return heff_clo_n(g_heff_2ecompile_2eimp_2epredValue_lam1, 1, 2, (V[]){v_g_240, v_e_241});
  }
}
V g_heff_2ecompile_2eimp_2epredValue_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2epredValue(a[0], a[1]);
}
V g_heff_2ecompile_2eimp_2epredValue_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_n_244}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_n_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_PBool, 1, (V[]){v_x_246})});
    return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_248, v_n_247});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2eimp_2epredValue_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eimp_2epredValue_str0), heff_intShow(heff_dup(v_n_249)));
  V v_x_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eimp_2epredValue_str1), v_t_2410);
  V v_m_2412 = heff_tr(heff_call(heff_get_n(v_g_240, 3, 8), 2, (V[]){heff_dup(v_x_2411), v_e_241}));
  V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){heff_intAdd(v_n_249, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = heff_tag_n(TAG_PBool, 1, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_x_2411})});
    V v_x_2417 = ({ V a_0 = v_x_2414; V a_1 = v_t_2416; V r_ = (g_heff_2ecompile_2eimp_2epredLets(a_0, a_1)); heff_drop(v_x_2414); r_; });
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2417, v_n_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimp_2epredAny_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimp_2epredAny_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eimp_2epredAny_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimp_2epredAny_str3, 5, "False");
V g_heff_2ecompile_2eimp_2epredAny_lam0(V self, V *args);
V g_heff_2ecompile_2eimp_2epredAny_lam1(V self, V *args); static Clo g_heff_2ecompile_2eimp_2epredAny_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epredAny_lam1, 1, 0};
V g_heff_2ecompile_2eimp_2epredAny_lam2(V self, V *args); static Clo g_heff_2ecompile_2eimp_2epredAny_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epredAny_lam2, 1, 0};
V g_heff_2ecompile_2eimp_2epredAny_lam3(V self, V *args);
V g_heff_2ecompile_2eimp_2epredAny_lam4(V self, V *args);
V g_heff_2ecompile_2eimp_2epredAny_lam5(V self, V *args);
Clo g_heff_2ecompile_2eimp_2epredAny_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epredAny_entry, 2, 0};

V g_heff_2ecompile_2eimp_2epredAny(V v_g_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_t_2411 = (g_heff_2ecompile_2eimp_2esinkTest(heff_dup(v_x_248), heff_dup(v_a_249), heff_dup(v_b_2410)));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      V v_m_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_x_248, v_a_249}));
      return heff_clo_n(g_heff_2ecompile_2eimp_2epredAny_lam0, 1, 3, (V[]){v_m_2412, v_g_240, v_b_2410});
    }
    case TAG_Just: {
      V v_e2_2423 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      heff_drop(v_x_248);
      heff_drop(v_a_249);
      heff_drop(v_b_2410);
      return heff_tail(heff_get_n(v_g_240, 7, 8), 1, (V[]){v_e2_2423});
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_ETag: {
    V v_t_2430 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_27_2431 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_27_2431)) {
    case TAG_Nil: {
      heff_drop_rec(v_g_240, 8);
      heff_drop_tag(v_e_241, 2);
      if (heff_strEq_c(heff_dup(v_t_2430), ((V)&g_heff_2ecompile_2eimp_2epredAny_str0))) {
        heff_drop(v_t_2430);
        return ((V)&g_heff_2ecompile_2eimp_2epredAny_lam1_clo);
      } else {
        if (heff_strEq_c(heff_dup(v_t_2430), ((V)&g_heff_2ecompile_2eimp_2epredAny_str1))) {
          heff_drop(v_t_2430);
          return ((V)&g_heff_2ecompile_2eimp_2epredAny_lam2_clo);
        } else {
          return heff_clo_n(g_heff_2ecompile_2eimp_2epredAny_lam3, 1, 1, (V[]){v_t_2430});
        }
      }
    }
    case TAG_Cons: {
      heff_take_n(v_e2_27_2431, 0ULL, 2);
      heff_drop(v_t_2430);
      HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
    }
    default: return heff_nomatch(v_e2_27_2431);
    }
  }
  case TAG_EMatch: {
    V v_s_2443 = heff_dup(heff_field(v_e_241, 0));
    V v_arms_2444 = heff_dup(heff_field(v_e_241, 1));
    V v_t_2445 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_2444));
    V v_it_2451;
    if (heff_intEq_c(v_t_2445, MK_INT(2LL))) {
      V v_t_2447 = (g_heff_2ecompile_2eimp_2earmNamed(((V)&g_heff_2ecompile_2eimp_2epredAny_str2), v_arms_2444));
      switch (heff_tag_of(v_t_2447)) {
      case TAG_Nothing: {
        heff_drop(v_arms_2444);
        v_it_2451 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_2448 = heff_field(v_t_2447, 0);
        V v_ru_24t_2447_24Just = heff_take_reuse_n(v_t_2447, 1ULL, 1);
        V v_t_2449 = ({ V a_0 = ((V)&g_heff_2ecompile_2eimp_2epredAny_str3); V a_1 = v_arms_2444; V r_ = (g_heff_2ecompile_2eimp_2earmNamed(a_0, a_1)); heff_drop(v_arms_2444); r_; });
        switch (heff_tag_of(v_t_2449)) {
        case TAG_Nothing: {
          heff_drop(v_t_2448);
          heff_drop_cell(v_ru_24t_2447_24Just, 1);
          v_it_2451 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_2450 = heff_field(v_t_2449, 0);
          heff_take_n(v_t_2449, 1ULL, 1);
          v_it_2451 = heff_tag_at_n(v_ru_24t_2447_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2448, v_f_2450})});
          break;
        }
        default: heff_nomatch(v_t_2449);
        }
        break;
      }
      default: heff_nomatch(v_t_2447);
      }
    } else {
      heff_drop(v_arms_2444);
      v_it_2451 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_it_2451)) {
    case TAG_Nothing: {
      heff_drop(v_s_2443);
      HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
    }
    case TAG_Just: {
      V v_it1_2452 = heff_field(v_it_2451, 0);
      heff_take_n(v_it_2451, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      switch (heff_tag_of(v_it1_2452)) {
      case TAG_MkPair: {
        V v_t_2453 = heff_field(v_it1_2452, 0);
        V v_f_2454 = heff_field(v_it1_2452, 1);
        heff_take_n(v_it1_2452, 3ULL, 2);
        V v_m_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_s_2443}));
        return heff_clo_n(g_heff_2ecompile_2eimp_2epredAny_lam4, 1, 4, (V[]){v_m_2455, v_g_240, v_t_2453, v_f_2454});
      }
      default: return heff_nomatch(v_it1_2452);
      }
    }
    default: return heff_nomatch(v_it_2451);
    }
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EPrimCall: {
    V v_p_2474 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_27_2475 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_27_2475)) {
    case TAG_Nil: {
      heff_drop(v_p_2474);
      HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
    }
    case TAG_Cons: {
      V v_a_2476 = heff_field(v_e2_27_2475, 0);
      V v_e2_272_2477 = heff_field(v_e2_27_2475, 1);
      heff_take_n(v_e2_27_2475, 3ULL, 2);
      switch (heff_tag_of(v_e2_272_2477)) {
      case TAG_Nil: {
        heff_drop(v_p_2474);
        heff_drop(v_a_2476);
        HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
      }
      case TAG_Cons: {
        V v_b_2478 = heff_field(v_e2_272_2477, 0);
        V v_e2_2722_2479 = heff_field(v_e2_272_2477, 1);
        heff_take_n(v_e2_272_2477, 3ULL, 2);
        switch (heff_tag_of(v_e2_2722_2479)) {
        case TAG_Nil: {
          V v_t_2480 = (g_heff_2ecompile_2eimp_2eisRel(heff_dup(v_p_2474)));
          if ((heff_dup(v_t_2480) == NTAG(TAG_True))) {
            heff_drop_tag(v_e_241, 2);
            heff_drop(v_t_2480);
            V v_m_2481 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 5)), 1, (V[]){v_a_2476}));
            return heff_clo_n(g_heff_2ecompile_2eimp_2epredAny_lam5, 1, 4, (V[]){v_m_2481, v_g_240, v_b_2478, v_p_2474});
          } else {
            heff_drop(v_p_2474);
            heff_drop(v_a_2476);
            heff_drop(v_b_2478);
            heff_drop(v_t_2480);
            HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_e2_2722_2479, 0ULL, 2);
          heff_drop(v_p_2474);
          heff_drop(v_a_2476);
          heff_drop(v_b_2478);
          HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
        }
        default: return heff_nomatch(v_e2_2722_2479);
        }
      }
      default: return heff_nomatch(v_e2_272_2477);
      }
    }
    default: return heff_nomatch(v_e2_27_2475);
    }
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2epredValue(v_g_240, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eimp_2epredAny_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2epredAny(a[0], a[1]);
}
V g_heff_2ecompile_2eimp_2epredAny_lam0(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_b_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_g_240, 7, 8), 1, (V[]){v_b_2410}));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2416}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_n_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      V v_x_2422;
      switch (heff_tag_of(v_x_2419)) {
      case TAG_Nothing: {
        heff_drop(v_x_2415);
        v_x_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_q_2421 = heff_field(v_x_2419, 0);
        heff_take_n(v_x_2419, 1ULL, 1);
        v_x_2422 = ({ V a_0 = v_x_2415; V a_1 = v_q_2421; V r_ = (g_heff_2ecompile_2eimp_2epredLets(a_0, a_1)); heff_drop(v_x_2415); r_; });
        break;
      }
      default: heff_nomatch(v_x_2419);
      }
      return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){v_x_2422, v_n_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2eimp_2epredAny_lam1(V self, V *args) {
  V v_n_2433 = args[0];
  V v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_PTrue)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2434, v_n_2433});
}
V g_heff_2ecompile_2eimp_2epredAny_lam2(V self, V *args) {
  V v_n_2436 = args[0];
  V v_t_2437 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_PFalse)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, v_n_2436});
}
V g_heff_2ecompile_2eimp_2epredAny_lam3(V self, V *args) {
  V v_n_2438 = args[0];
  V v_t_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2439 = heff_tag_n(TAG_STag, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  V v_t_2440 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_PBool, 1, (V[]){v_t_2439})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2440, v_n_2438});
}
V g_heff_2ecompile_2eimp_2epredAny_lam4(V self, V *args) {
  V v_n_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_t_2453 = heff_env(self)[2];
  V v_f_2454 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2457 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_n_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_n_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    V v_m_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_t_2453}));
    V v_x2_2461 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_n_2459}));
    switch (heff_tag_of(v_x2_2461)) {
    case TAG_MkPair: {
      V v_x_2462 = heff_field(v_x2_2461, 0);
      V v_n_2463 = heff_field(v_x2_2461, 1);
      heff_take_n(v_x2_2461, 3ULL, 2);
      V v_m_2464 = heff_tr(heff_call(heff_get_n(v_g_240, 7, 8), 1, (V[]){v_f_2454}));
      V v_x2_2465 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_n_2463}));
      switch (heff_tag_of(v_x2_2465)) {
      case TAG_MkPair: {
        V v_x_2466 = heff_field(v_x2_2465, 0);
        V v_n_2467 = heff_field(v_x2_2465, 1);
        heff_take_n(v_x2_2465, 3ULL, 2);
        V v_x_2472;
        switch (heff_tag_of(v_x_2458)) {
        case TAG_Nothing: {
          heff_drop(v_x_2462);
          heff_drop(v_x_2466);
          v_x_2472 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_cs_2468 = heff_field(v_x_2458, 0);
          V v_ru_24x_2458_24Just = heff_take_reuse_n(v_x_2458, 1ULL, 1);
          switch (heff_tag_of(v_x_2462)) {
          case TAG_Nothing: {
            heff_drop(v_x_2466);
            heff_drop(v_cs_2468);
            heff_drop_cell(v_ru_24x_2458_24Just, 1);
            v_x_2472 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_ct_2469 = heff_field(v_x_2462, 0);
            heff_take_n(v_x_2462, 1ULL, 1);
            switch (heff_tag_of(v_x_2466)) {
            case TAG_Nothing: {
              heff_drop(v_cs_2468);
              heff_drop_cell(v_ru_24x_2458_24Just, 1);
              heff_drop(v_ct_2469);
              v_x_2472 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_cf_2470 = heff_field(v_x_2466, 0);
              heff_take_n(v_x_2466, 1ULL, 1);
              V v_t_2471 = (g_heff_2ecompile_2eimp_2econdIf(v_cs_2468, v_ct_2469, v_cf_2470));
              v_x_2472 = heff_tag_at_n(v_ru_24x_2458_24Just, TAG_Just, 1, (V[]){v_t_2471});
              break;
            }
            default: heff_nomatch(v_x_2466);
            }
            break;
          }
          default: heff_nomatch(v_x_2462);
          }
          break;
        }
        default: heff_nomatch(v_x_2458);
        }
        return heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){v_x_2472, v_n_2467});
      }
      default: return heff_nomatch(v_x2_2465);
      }
    }
    default: return heff_nomatch(v_x2_2461);
    }
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2ecompile_2eimp_2epredAny_lam5(V self, V *args) {
  V v_n_2482 = args[0];
  V v_m_2481 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_b_2478 = heff_env(self)[2];
  V v_p_2474 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2483 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_n_2482}));
  switch (heff_tag_of(v_x2_2483)) {
  case TAG_MkPair: {
    V v_x_2484 = heff_field(v_x2_2483, 0);
    V v_n_2485 = heff_field(v_x2_2483, 1);
    V v_ru_24x2_2483_24MkPair = heff_take_reuse_n(v_x2_2483, 3ULL, 2);
    V v_m_2486 = heff_tr(heff_call(heff_get_n(v_g_240, 5, 8), 1, (V[]){v_b_2478}));
    V v_x2_2487 = heff_tr(heff_call(v_m_2486, 1, (V[]){v_n_2485}));
    switch (heff_tag_of(v_x2_2487)) {
    case TAG_MkPair: {
      V v_x_2488 = heff_field(v_x2_2487, 0);
      V v_n_2489 = heff_field(v_x2_2487, 1);
      heff_take_n(v_x2_2487, 3ULL, 2);
      V v_t_2492;
      switch (heff_tag_of(v_x_2484)) {
      case TAG_MkPair: {
        V v_x_2490 = heff_dup(heff_field(v_x_2484, 0));
        v_t_2492 = v_x_2490;
        break;
      }
      default: heff_nomatch(v_x_2484);
      }
      V v_t_2495;
      switch (heff_tag_of(v_x_2488)) {
      case TAG_MkPair: {
        V v_x_2493 = heff_dup(heff_field(v_x_2488, 0));
        v_t_2495 = v_x_2493;
        break;
      }
      default: heff_nomatch(v_x_2488);
      }
      V v_t_2496 = (g_prelude_2e_2b_2b(v_t_2492, v_t_2495));
      V v_t_2499;
      switch (heff_tag_of(v_x_2484)) {
      case TAG_MkPair: {
        V v_y_2498 = heff_field(v_x_2484, 1);
        heff_take_n(v_x_2484, 2ULL, 2);
        v_t_2499 = v_y_2498;
        break;
      }
      default: heff_nomatch(v_x_2484);
      }
      V v_t_24102;
      switch (heff_tag_of(v_x_2488)) {
      case TAG_MkPair: {
        V v_y_24101 = heff_field(v_x_2488, 1);
        heff_take_n(v_x_2488, 2ULL, 2);
        v_t_24102 = v_y_24101;
        break;
      }
      default: heff_nomatch(v_x_2488);
      }
      V v_x_24103 = ({ V a_0 = v_t_2496; V a_1 = heff_tag_n(TAG_PRel, 3, (V[]){v_p_2474, v_t_2499, v_t_24102}); V r_ = (g_heff_2ecompile_2eimp_2epredLets(a_0, a_1)); heff_drop(v_t_2496); r_; });
      return heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_MkPair, 2, (V[]){v_x_24103, v_n_2489});
    }
    default: return heff_nomatch(v_x2_2487);
    }
  }
  default: return heff_nomatch(v_x2_2483);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimp_2esimpleOf_str0, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimp_2esimpleOf_str1, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimp_2esimpleOf_str2, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimp_2esimpleOf_str3, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimp_2esimpleOf_str4, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimp_2esimpleOf_str5, 10, "$notSimple");
V g_heff_2ecompile_2eimp_2esimpleOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam2(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam3(V self, V *args); static Clo g_heff_2ecompile_2eimp_2esimpleOf_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2esimpleOf_lam3, 1, 0};
V g_heff_2ecompile_2eimp_2esimpleOf_lam4(V self, V *args); static Clo g_heff_2ecompile_2eimp_2esimpleOf_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2esimpleOf_lam4, 1, 0};
V g_heff_2ecompile_2eimp_2esimpleOf_lam5(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam6(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam7(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam8(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam9(V self, V *args); static Clo g_heff_2ecompile_2eimp_2esimpleOf_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2esimpleOf_lam9, 1, 0};
V g_heff_2ecompile_2eimp_2esimpleOf_lam10(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam11(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam12(V self, V *args); static Clo g_heff_2ecompile_2eimp_2esimpleOf_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2esimpleOf_lam12, 1, 0};
V g_heff_2ecompile_2eimp_2esimpleOf_lam13(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam14(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam15(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam16(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam17(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam18(V self, V *args);
V g_heff_2ecompile_2eimp_2esimpleOf_lam19(V self, V *args); static Clo g_heff_2ecompile_2eimp_2esimpleOf_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2esimpleOf_lam19, 1, 0};
V g_heff_2ecompile_2eimp_2esimpleOf_lam20(V self, V *args); static Clo g_heff_2ecompile_2eimp_2esimpleOf_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2esimpleOf_lam20, 1, 0};
Clo g_heff_2ecompile_2eimp_2esimpleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2esimpleOf_entry, 2, 0};

V g_heff_2ecompile_2eimp_2esimpleOf(V v_g_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam0, 1, 1, (V[]){v_x_242});
  }
  case TAG_EGlobal: {
    V v_k_244 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam1, 1, 1, (V[]){v_k_244});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_b_247}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimp_2esimpleOf_lam3_clo);
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimp_2esimpleOf_lam4_clo);
  }
  case TAG_ERecord: {
    V v_fs_2423 = heff_field(v_e_241, 0);
    V v_ts_2424 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2429 = (g_heff_2ecompile_2eimp_2etraverseN(heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam5, 1, 1, (V[]){v_g_240}), heff_dup(v_fs_2423)));
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam6, 1, 3, (V[]){v_m_2429, v_fs_2423, v_ts_2424});
  }
  case TAG_EProj: {
    V v_e1_2436 = heff_field(v_e_241, 0);
    V v_l_2437 = heff_field(v_e_241, 1);
    V v_sh_2438 = heff_field(v_e_241, 2);
    V v_t_2439 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 15ULL, 4);
    V v_m_2440 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e1_2436}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam7, 1, 4, (V[]){v_m_2440, v_l_2437, v_sh_2438, v_t_2439});
  }
  case TAG_ETag: {
    V v_t_2445 = heff_field(v_e_241, 0);
    V v_as_2446 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2447 = (g_heff_2ecompile_2eimp_2etraverseN(heff_get_n(v_g_240, 1, 8), v_as_2446));
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam8, 1, 2, (V[]){v_m_2447, v_t_2445});
  }
  case TAG_EMatch: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimp_2esimpleOf_lam9_clo);
  }
  case TAG_EPrim: {
    V v_p_2456 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam10, 1, 1, (V[]){v_p_2456});
  }
  case TAG_EPrimCall: {
    V v_p_2458 = heff_field(v_e_241, 0);
    V v_as_2459 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2460 = (g_heff_2ecompile_2eimp_2etraverseN(heff_get_n(v_g_240, 1, 8), v_as_2459));
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam11, 1, 2, (V[]){v_m_2460, v_p_2458});
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimp_2esimpleOf_lam12_clo);
  }
  case TAG_EInt: {
    V v_i_2469 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam13, 1, 1, (V[]){v_i_2469});
  }
  case TAG_EFloat: {
    V v_x_2471 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam14, 1, 1, (V[]){v_x_2471});
  }
  case TAG_EStr: {
    V v_s_2473 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam15, 1, 1, (V[]){v_s_2473});
  }
  case TAG_EBytes: {
    V v_s_2475 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam16, 1, 1, (V[]){v_s_2475});
  }
  case TAG_EFixed: {
    V v_w_2477 = heff_field(v_e_241, 0);
    V v_i_2478 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam17, 1, 2, (V[]){v_w_2477, v_i_2478});
  }
  case TAG_EFloat32: {
    V v_x_2480 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimp_2esimpleOf_lam18, 1, 1, (V[]){v_x_2480});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimp_2esimpleOf_lam19_clo);
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimp_2esimpleOf_lam20_clo);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eimp_2esimpleOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2esimpleOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_x_242}), v_n_243});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_k_244}), v_n_245});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam2(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2413 = heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_SLam, 2, (V[]){v_xs_246, heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2411})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam3(V self, V *args) {
  V v_n_2416 = args[0];
  V v_t_2417 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2esimpleOf_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_n_2416});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam4(V self, V *args) {
  V v_n_2421 = args[0];
  V v_t_2422 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2esimpleOf_str1), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_n_2421});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam5(V self, V *args) {
  V v_f_2425 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428;
  switch (heff_tag_of(v_f_2425)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_f_2425, 1);
    heff_take_n(v_f_2425, 2ULL, 2);
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_f_2425);
  }
  V f_ = heff_get_n(v_g_240, 1, 8);
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam6(V self, V *args) {
  V v_n_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_fs_2423 = heff_env(self)[1];
  V v_ts_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_n_2430}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_n_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2423, v_x_2432));
    V v_x_2435 = heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_SRec, 2, (V[]){v_t_2434, v_ts_2424});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2435, v_n_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam7(V self, V *args) {
  V v_n_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_l_2437 = heff_env(self)[1];
  V v_sh_2438 = heff_env(self)[2];
  V v_t_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_n_2444 = heff_field(v_x2_2442, 1);
    V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SProj, 4, (V[]){v_x_2443, v_l_2437, v_sh_2438, v_t_2439}), v_n_2444});
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam8(V self, V *args) {
  V v_n_2448 = args[0];
  V v_m_2447 = heff_env(self)[0];
  V v_t_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2449 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_n_2448}));
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_n_2451 = heff_field(v_x2_2449, 1);
    V v_ru_24x2_2449_24MkPair = heff_take_reuse_n(v_x2_2449, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2449_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_STag, 2, (V[]){v_t_2445, v_x_2450}), v_n_2451});
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam9(V self, V *args) {
  V v_n_2454 = args[0];
  V v_t_2455 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2esimpleOf_str2), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2455, v_n_2454});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam10(V self, V *args) {
  V v_n_2457 = args[0];
  V v_p_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrimFn, 1, (V[]){v_p_2456}), v_n_2457});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam11(V self, V *args) {
  V v_n_2461 = args[0];
  V v_m_2460 = heff_env(self)[0];
  V v_p_2458 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2462 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_n_2461}));
  switch (heff_tag_of(v_x2_2462)) {
  case TAG_MkPair: {
    V v_x_2463 = heff_field(v_x2_2462, 0);
    V v_n_2464 = heff_field(v_x2_2462, 1);
    V v_ru_24x2_2462_24MkPair = heff_take_reuse_n(v_x2_2462, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 2, (V[]){v_p_2458, v_x_2463}), v_n_2464});
  }
  default: return heff_nomatch(v_x2_2462);
  }
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam12(V self, V *args) {
  V v_n_2467 = args[0];
  V v_t_2468 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2esimpleOf_str3), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2468, v_n_2467});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam13(V self, V *args) {
  V v_n_2470 = args[0];
  V v_i_2469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SInt, 1, (V[]){v_i_2469}), v_n_2470});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam14(V self, V *args) {
  V v_n_2472 = args[0];
  V v_x_2471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFloat, 1, (V[]){v_x_2471}), v_n_2472});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam15(V self, V *args) {
  V v_n_2474 = args[0];
  V v_s_2473 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SStr, 1, (V[]){v_s_2473}), v_n_2474});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam16(V self, V *args) {
  V v_n_2476 = args[0];
  V v_s_2475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SBytes, 1, (V[]){v_s_2475}), v_n_2476});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam17(V self, V *args) {
  V v_n_2479 = args[0];
  V v_w_2477 = heff_env(self)[0];
  V v_i_2478 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 2, (V[]){v_w_2477, v_i_2478}), v_n_2479});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam18(V self, V *args) {
  V v_n_2481 = args[0];
  V v_x_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFloat32, 1, (V[]){v_x_2480}), v_n_2481});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam19(V self, V *args) {
  V v_n_2482 = args[0];
  V v_t_2483 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2esimpleOf_str4), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2483, v_n_2482});
}
V g_heff_2ecompile_2eimp_2esimpleOf_lam20(V self, V *args) {
  V v_n_2486 = args[0];
  V v_t_2487 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimp_2esimpleOf_str5), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2487, v_n_2486});
}
HEFF_LIT(g_heff_2ecompile_2eimp_2eatomOf_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimp_2eatomOf_str1, 1, "t");
V g_heff_2ecompile_2eimp_2eatomOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimp_2eatomOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimp_2eatomOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2eatomOf_entry, 2, 0};

V g_heff_2ecompile_2eimp_2eatomOf(V v_g_240, V v_e_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2eimp_2eisSimple(v_e_241));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eatomOf_lam0, 1, 1, (V[]){v_m_243});
  } else {
    heff_drop(v_t_242);
    return heff_clo_n(g_heff_2ecompile_2eimp_2eatomOf_lam1, 1, 2, (V[]){v_g_240, v_e_241});
  }
}
V g_heff_2ecompile_2eimp_2eatomOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2eatomOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimp_2eatomOf_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_n_244}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_n_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_x_246});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_n_247});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2eimp_2eatomOf_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eimp_2eatomOf_str0), heff_intShow(heff_dup(v_n_249)));
  V v_x_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eimp_2eatomOf_str1), v_t_2410);
  V v_m_2412 = heff_tr(heff_call(heff_get_n(v_g_240, 3, 8), 2, (V[]){heff_dup(v_x_2411), v_e_241}));
  V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){heff_intAdd(v_n_249, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2414, heff_tag_n(TAG_SVar, 1, (V[]){v_x_2411})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_n_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam2(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam3(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam4(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam5(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam6(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam7(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam8(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam9(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam10(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam11(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam12(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam13(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam14(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam15(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam16(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam17(V self, V *args);
V g_heff_2ecompile_2eimp_2eopOf_lam18(V self, V *args); static Clo g_heff_2ecompile_2eimp_2eopOf_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2eopOf_lam18, 1, 0};
V g_heff_2ecompile_2eimp_2eopOf_lam19(V self, V *args); static Clo g_heff_2ecompile_2eimp_2eopOf_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2eopOf_lam19, 1, 0};
Clo g_heff_2ecompile_2eimp_2eopOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2eopOf_entry, 2, 0};

V g_heff_2ecompile_2eimp_2eopOf(V v_g_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EGlobal: {
    V v_m_2410 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam1, 1, 1, (V[]){v_m_2410});
  }
  case TAG_ELam: {
    V v_m_2418 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam2, 1, 1, (V[]){v_m_2418});
  }
  case TAG_EApp: {
    V v_f_2424 = heff_field(v_e_241, 0);
    V v_as_2425 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_m_2426 = (g_heff_2ecompile_2eimp_2eatomsOf(v_g_240, heff_tag_at_n(v_ru_24e_241_24EApp, TAG_Cons, 2, (V[]){v_f_2424, v_as_2425})));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam3, 1, 1, (V[]){v_m_2426});
  }
  case TAG_ELet: {
    V v_m_2440 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam4, 1, 1, (V[]){v_m_2440});
  }
  case TAG_ERecord: {
    V v_fs_2446 = heff_field(v_e_241, 0);
    V v_ts_2447 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2448 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2446)));
    V v_m_2449 = (g_heff_2ecompile_2eimp_2eatomsOf(v_g_240, v_t_2448));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam5, 1, 3, (V[]){v_m_2449, v_fs_2446, v_ts_2447});
  }
  case TAG_EProj: {
    V v_e1_2459 = heff_field(v_e_241, 0);
    V v_l_2460 = heff_field(v_e_241, 1);
    V v_sh_2461 = heff_field(v_e_241, 2);
    V v_t_2462 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 15ULL, 4);
    V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_e1_2459, NTAG(TAG_Nil)});
    V v_m_2464 = (g_heff_2ecompile_2eimp_2eatomsOf(v_g_240, v_t_2463));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam6, 1, 4, (V[]){v_m_2464, v_l_2460, v_sh_2461, v_t_2462});
  }
  case TAG_ETag: {
    V v_t_2475 = heff_field(v_e_241, 0);
    V v_as_2476 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2477 = (g_heff_2ecompile_2eimp_2eatomsOf(v_g_240, v_as_2476));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam7, 1, 2, (V[]){v_m_2477, v_t_2475});
  }
  case TAG_EMatch: {
    V v_m_2488 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam8, 1, 1, (V[]){v_m_2488});
  }
  case TAG_EPrim: {
    V v_m_2495 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam9, 1, 1, (V[]){v_m_2495});
  }
  case TAG_EPrimCall: {
    V v_p_24101 = heff_field(v_e_241, 0);
    V v_as_24102 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24103 = (g_heff_2ecompile_2eimp_2eatomsOf(v_g_240, v_as_24102));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam10, 1, 2, (V[]){v_m_24103, v_p_24101});
  }
  case TAG_ECall: {
    V v_k_24113 = heff_field(v_e_241, 0);
    V v_as_24114 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24115 = (g_heff_2ecompile_2eimp_2eatomsOf(v_g_240, v_as_24114));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam11, 1, 2, (V[]){v_m_24115, v_k_24113});
  }
  case TAG_EInt: {
    V v_m_24124 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam12, 1, 1, (V[]){v_m_24124});
  }
  case TAG_EFloat: {
    V v_m_24131 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam13, 1, 1, (V[]){v_m_24131});
  }
  case TAG_EStr: {
    V v_m_24138 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam14, 1, 1, (V[]){v_m_24138});
  }
  case TAG_EBytes: {
    V v_m_24145 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam15, 1, 1, (V[]){v_m_24145});
  }
  case TAG_EFixed: {
    V v_m_24153 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam16, 1, 1, (V[]){v_m_24153});
  }
  case TAG_EFloat32: {
    V v_m_24160 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eopOf_lam17, 1, 1, (V[]){v_m_24160});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimp_2eopOf_lam18_clo);
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimp_2eopOf_lam19_clo);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2eopOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimp_2eopOf_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_n_244}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_n_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_246})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_n_247});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_n_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    V v_t_2415 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_2413})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_n_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam2(V self, V *args) {
  V v_n_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_2419}));
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_n_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    V v_t_2423 = heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_2421})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_n_2422});
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam3(V self, V *args) {
  V v_n_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_n_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_n_2430 = heff_field(v_x2_2428, 1);
    V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
    V v_x_2436;
    switch (heff_tag_of(v_x_2429)) {
    case TAG_MkPair: {
      V v_ss_2431 = heff_field(v_x_2429, 0);
      V v_vs_2432 = heff_field(v_x_2429, 1);
      V v_ru_24x_2429_24MkPair = heff_take_reuse_n(v_x_2429, 3ULL, 2);
      V v_t_2435;
      switch (heff_tag_of(v_vs_2432)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_2428_24MkPair, 2);
        v_t_2435 = NTAG(TAG_OAbandon);
        break;
      }
      case TAG_Cons: {
        V v_fv_2433 = heff_field(v_vs_2432, 0);
        V v_avs_2434 = heff_field(v_vs_2432, 1);
        heff_take_n(v_vs_2432, 3ULL, 2);
        v_t_2435 = heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_OApply, 2, (V[]){v_fv_2433, v_avs_2434});
        break;
      }
      default: heff_nomatch(v_vs_2432);
      }
      v_x_2436 = heff_tag_at_n(v_ru_24x_2429_24MkPair, TAG_MkPair, 2, (V[]){v_ss_2431, v_t_2435});
      break;
    }
    default: heff_nomatch(v_x_2429);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2436, v_n_2430});
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam4(V self, V *args) {
  V v_n_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_n_2444 = heff_field(v_x2_2442, 1);
    V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
    V v_t_2445 = heff_tag_at_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_2443})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2445, v_n_2444});
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam5(V self, V *args) {
  V v_n_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_fs_2446 = heff_env(self)[1];
  V v_ts_2447 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2451 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_n_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_n_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    V v_x_2458;
    switch (heff_tag_of(v_x_2452)) {
    case TAG_MkPair: {
      V v_ss_2454 = heff_field(v_x_2452, 0);
      V v_vs_2455 = heff_field(v_x_2452, 1);
      V v_ru_24x_2452_24MkPair = heff_take_reuse_n(v_x_2452, 3ULL, 2);
      V v_t_2456 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2446, v_vs_2455));
      V v_t_2457 = heff_tag_n(TAG_OSimple, 1, (V[]){heff_tag_at_n(v_ru_24x2_2451_24MkPair, TAG_SRec, 2, (V[]){v_t_2456, v_ts_2447})});
      v_x_2458 = heff_tag_at_n(v_ru_24x_2452_24MkPair, TAG_MkPair, 2, (V[]){v_ss_2454, v_t_2457});
      break;
    }
    default: heff_nomatch(v_x_2452);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2458, v_n_2453});
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam6(V self, V *args) {
  V v_n_2465 = args[0];
  V v_m_2464 = heff_env(self)[0];
  V v_l_2460 = heff_env(self)[1];
  V v_sh_2461 = heff_env(self)[2];
  V v_t_2462 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2466 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_n_2465}));
  switch (heff_tag_of(v_x2_2466)) {
  case TAG_MkPair: {
    V v_x_2467 = heff_field(v_x2_2466, 0);
    V v_n_2468 = heff_field(v_x2_2466, 1);
    V v_ru_24x2_2466_24MkPair = heff_take_reuse_n(v_x2_2466, 3ULL, 2);
    V v_x_2474;
    switch (heff_tag_of(v_x_2467)) {
    case TAG_MkPair: {
      V v_ss_2469 = heff_field(v_x_2467, 0);
      V v_vs_2470 = heff_field(v_x_2467, 1);
      heff_take_n(v_x_2467, 3ULL, 2);
      V v_t_2473;
      switch (heff_tag_of(v_vs_2470)) {
      case TAG_Nil: {
        heff_drop(v_l_2460);
        heff_drop(v_sh_2461);
        heff_drop(v_t_2462);
        v_t_2473 = NTAG(TAG_OAbandon);
        break;
      }
      case TAG_Cons: {
        V v_v_2471 = heff_field(v_vs_2470, 0);
        heff_take_n(v_vs_2470, 1ULL, 2);
        v_t_2473 = heff_tag_n(TAG_OSimple, 1, (V[]){heff_tag_n(TAG_SProj, 4, (V[]){v_v_2471, v_l_2460, v_sh_2461, v_t_2462})});
        break;
      }
      default: heff_nomatch(v_vs_2470);
      }
      v_x_2474 = heff_tag_at_n(v_ru_24x2_2466_24MkPair, TAG_MkPair, 2, (V[]){v_ss_2469, v_t_2473});
      break;
    }
    default: heff_nomatch(v_x_2467);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2474, v_n_2468});
  }
  default: return heff_nomatch(v_x2_2466);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam7(V self, V *args) {
  V v_n_2478 = args[0];
  V v_m_2477 = heff_env(self)[0];
  V v_t_2475 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2479 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_n_2478}));
  switch (heff_tag_of(v_x2_2479)) {
  case TAG_MkPair: {
    V v_x_2480 = heff_field(v_x2_2479, 0);
    V v_n_2481 = heff_field(v_x2_2479, 1);
    V v_ru_24x2_2479_24MkPair = heff_take_reuse_n(v_x2_2479, 3ULL, 2);
    V v_x_2485;
    switch (heff_tag_of(v_x_2480)) {
    case TAG_MkPair: {
      V v_ss_2482 = heff_field(v_x_2480, 0);
      V v_vs_2483 = heff_field(v_x_2480, 1);
      V v_ru_24x_2480_24MkPair = heff_take_reuse_n(v_x_2480, 3ULL, 2);
      V v_t_2484 = heff_tag_n(TAG_OSimple, 1, (V[]){heff_tag_at_n(v_ru_24x2_2479_24MkPair, TAG_STag, 2, (V[]){v_t_2475, v_vs_2483})});
      v_x_2485 = heff_tag_at_n(v_ru_24x_2480_24MkPair, TAG_MkPair, 2, (V[]){v_ss_2482, v_t_2484});
      break;
    }
    default: heff_nomatch(v_x_2480);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2485, v_n_2481});
  }
  default: return heff_nomatch(v_x2_2479);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam8(V self, V *args) {
  V v_n_2489 = args[0];
  V v_m_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2490 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_n_2489}));
  switch (heff_tag_of(v_x2_2490)) {
  case TAG_MkPair: {
    V v_x_2491 = heff_field(v_x2_2490, 0);
    V v_n_2492 = heff_field(v_x2_2490, 1);
    V v_ru_24x2_2490_24MkPair = heff_take_reuse_n(v_x2_2490, 3ULL, 2);
    V v_t_2493 = heff_tag_at_n(v_ru_24x2_2490_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_2491})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2493, v_n_2492});
  }
  default: return heff_nomatch(v_x2_2490);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam9(V self, V *args) {
  V v_n_2496 = args[0];
  V v_m_2495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2497 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_n_2496}));
  switch (heff_tag_of(v_x2_2497)) {
  case TAG_MkPair: {
    V v_x_2498 = heff_field(v_x2_2497, 0);
    V v_n_2499 = heff_field(v_x2_2497, 1);
    V v_ru_24x2_2497_24MkPair = heff_take_reuse_n(v_x2_2497, 3ULL, 2);
    V v_t_24100 = heff_tag_at_n(v_ru_24x2_2497_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_2498})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24100, v_n_2499});
  }
  default: return heff_nomatch(v_x2_2497);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam10(V self, V *args) {
  V v_n_24104 = args[0];
  V v_m_24103 = heff_env(self)[0];
  V v_p_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24105 = heff_tr(heff_call(v_m_24103, 1, (V[]){v_n_24104}));
  switch (heff_tag_of(v_x2_24105)) {
  case TAG_MkPair: {
    V v_x_24106 = heff_field(v_x2_24105, 0);
    V v_n_24107 = heff_field(v_x2_24105, 1);
    V v_ru_24x2_24105_24MkPair = heff_take_reuse_n(v_x2_24105, 3ULL, 2);
    V v_x_24112;
    switch (heff_tag_of(v_x_24106)) {
    case TAG_MkPair: {
      V v_ss_24108 = heff_field(v_x_24106, 0);
      V v_vs_24109 = heff_field(v_x_24106, 1);
      V v_ru_24x_24106_24MkPair = heff_take_reuse_n(v_x_24106, 3ULL, 2);
      V v_t_24110 = ({ V a_0 = heff_dup(v_p_24101); V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_24111;
      if ((heff_dup(v_t_24110) == NTAG(TAG_True))) {
        heff_drop(v_t_24110);
        v_t_24111 = heff_tag_at_n(v_ru_24x2_24105_24MkPair, TAG_OPrim, 2, (V[]){v_p_24101, v_vs_24109});
      } else {
        heff_drop(v_t_24110);
        v_t_24111 = heff_tag_n(TAG_OSimple, 1, (V[]){heff_tag_at_n(v_ru_24x2_24105_24MkPair, TAG_SPrim, 2, (V[]){v_p_24101, v_vs_24109})});
      }
      v_x_24112 = heff_tag_at_n(v_ru_24x_24106_24MkPair, TAG_MkPair, 2, (V[]){v_ss_24108, v_t_24111});
      break;
    }
    default: heff_nomatch(v_x_24106);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24112, v_n_24107});
  }
  default: return heff_nomatch(v_x2_24105);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam11(V self, V *args) {
  V v_n_24116 = args[0];
  V v_m_24115 = heff_env(self)[0];
  V v_k_24113 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24117 = heff_tr(heff_call(v_m_24115, 1, (V[]){v_n_24116}));
  switch (heff_tag_of(v_x2_24117)) {
  case TAG_MkPair: {
    V v_x_24118 = heff_field(v_x2_24117, 0);
    V v_n_24119 = heff_field(v_x2_24117, 1);
    V v_ru_24x2_24117_24MkPair = heff_take_reuse_n(v_x2_24117, 3ULL, 2);
    V v_x_24122;
    switch (heff_tag_of(v_x_24118)) {
    case TAG_MkPair: {
      V v_ss_24120 = heff_field(v_x_24118, 0);
      V v_vs_24121 = heff_field(v_x_24118, 1);
      heff_take_n(v_x_24118, 3ULL, 2);
      v_x_24122 = heff_tag_at_n(v_ru_24x2_24117_24MkPair, TAG_MkPair, 2, (V[]){v_ss_24120, heff_tag_n(TAG_OCall, 2, (V[]){v_k_24113, v_vs_24121})});
      break;
    }
    default: heff_nomatch(v_x_24118);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24122, v_n_24119});
  }
  default: return heff_nomatch(v_x2_24117);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam12(V self, V *args) {
  V v_n_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_n_24125}));
  switch (heff_tag_of(v_x2_24126)) {
  case TAG_MkPair: {
    V v_x_24127 = heff_field(v_x2_24126, 0);
    V v_n_24128 = heff_field(v_x2_24126, 1);
    V v_ru_24x2_24126_24MkPair = heff_take_reuse_n(v_x2_24126, 3ULL, 2);
    V v_t_24129 = heff_tag_at_n(v_ru_24x2_24126_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_24127})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24129, v_n_24128});
  }
  default: return heff_nomatch(v_x2_24126);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam13(V self, V *args) {
  V v_n_24132 = args[0];
  V v_m_24131 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24133 = heff_tr(heff_call(v_m_24131, 1, (V[]){v_n_24132}));
  switch (heff_tag_of(v_x2_24133)) {
  case TAG_MkPair: {
    V v_x_24134 = heff_field(v_x2_24133, 0);
    V v_n_24135 = heff_field(v_x2_24133, 1);
    V v_ru_24x2_24133_24MkPair = heff_take_reuse_n(v_x2_24133, 3ULL, 2);
    V v_t_24136 = heff_tag_at_n(v_ru_24x2_24133_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_24134})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24136, v_n_24135});
  }
  default: return heff_nomatch(v_x2_24133);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam14(V self, V *args) {
  V v_n_24139 = args[0];
  V v_m_24138 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24140 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_n_24139}));
  switch (heff_tag_of(v_x2_24140)) {
  case TAG_MkPair: {
    V v_x_24141 = heff_field(v_x2_24140, 0);
    V v_n_24142 = heff_field(v_x2_24140, 1);
    V v_ru_24x2_24140_24MkPair = heff_take_reuse_n(v_x2_24140, 3ULL, 2);
    V v_t_24143 = heff_tag_at_n(v_ru_24x2_24140_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_24141})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24143, v_n_24142});
  }
  default: return heff_nomatch(v_x2_24140);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam15(V self, V *args) {
  V v_n_24146 = args[0];
  V v_m_24145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24147 = heff_tr(heff_call(v_m_24145, 1, (V[]){v_n_24146}));
  switch (heff_tag_of(v_x2_24147)) {
  case TAG_MkPair: {
    V v_x_24148 = heff_field(v_x2_24147, 0);
    V v_n_24149 = heff_field(v_x2_24147, 1);
    V v_ru_24x2_24147_24MkPair = heff_take_reuse_n(v_x2_24147, 3ULL, 2);
    V v_t_24150 = heff_tag_at_n(v_ru_24x2_24147_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_24148})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24150, v_n_24149});
  }
  default: return heff_nomatch(v_x2_24147);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam16(V self, V *args) {
  V v_n_24154 = args[0];
  V v_m_24153 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24155 = heff_tr(heff_call(v_m_24153, 1, (V[]){v_n_24154}));
  switch (heff_tag_of(v_x2_24155)) {
  case TAG_MkPair: {
    V v_x_24156 = heff_field(v_x2_24155, 0);
    V v_n_24157 = heff_field(v_x2_24155, 1);
    V v_ru_24x2_24155_24MkPair = heff_take_reuse_n(v_x2_24155, 3ULL, 2);
    V v_t_24158 = heff_tag_at_n(v_ru_24x2_24155_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_24156})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24158, v_n_24157});
  }
  default: return heff_nomatch(v_x2_24155);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam17(V self, V *args) {
  V v_n_24161 = args[0];
  V v_m_24160 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24162 = heff_tr(heff_call(v_m_24160, 1, (V[]){v_n_24161}));
  switch (heff_tag_of(v_x2_24162)) {
  case TAG_MkPair: {
    V v_x_24163 = heff_field(v_x2_24162, 0);
    V v_n_24164 = heff_field(v_x2_24162, 1);
    V v_ru_24x2_24162_24MkPair = heff_take_reuse_n(v_x2_24162, 3ULL, 2);
    V v_t_24165 = heff_tag_at_n(v_ru_24x2_24162_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_24163})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24165, v_n_24164});
  }
  default: return heff_nomatch(v_x2_24162);
  }
}
V g_heff_2ecompile_2eimp_2eopOf_lam18(V self, V *args) {
  V v_n_24166 = args[0];
  V v_t_24167 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_OAbandon)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24167, v_n_24166});
}
V g_heff_2ecompile_2eimp_2eopOf_lam19(V self, V *args) {
  V v_n_24170 = args[0];
  V v_t_24171 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_OAbandon)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24171, v_n_24170});
}
HEFF_LIT(g_heff_2ecompile_2eimp_2ematchSet_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimp_2ematchSet_str1, 5, "False");
V g_heff_2ecompile_2eimp_2ematchSet_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimp_2ematchSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2ematchSet_entry, 4, 0};

V g_heff_2ecompile_2eimp_2ematchSet(V v_g_240, V v_x_241, V v_s_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_243));
  V v_it_2410;
  if (heff_intEq_c(v_t_244, MK_INT(2LL))) {
    V v_t_246 = (g_heff_2ecompile_2eimp_2earmNamed(((V)&g_heff_2ecompile_2eimp_2ematchSet_str0), v_arms_243));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      v_it_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_t_247 = heff_field(v_t_246, 0);
      V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
      V v_t_248 = (g_heff_2ecompile_2eimp_2earmNamed(((V)&g_heff_2ecompile_2eimp_2ematchSet_str1), v_arms_243));
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        heff_drop(v_t_247);
        heff_drop_cell(v_ru_24t_246_24Just, 1);
        v_it_2410 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_f_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 1);
        v_it_2410 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_f_249})});
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      break;
    }
    default: heff_nomatch(v_t_246);
    }
  } else {
    v_it_2410 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_it_2410)) {
  case TAG_Nothing: {
    HEFF_LAST return g_heff_2ecompile_2eimp_2ecaseSet(v_g_240, v_x_241, v_s_242, v_arms_243);
  }
  case TAG_Just: {
    V v_it1_2411 = heff_field(v_it_2410, 0);
    heff_take_n(v_it_2410, 1ULL, 1);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_MkPair: {
      V v_t_2412 = heff_field(v_it1_2411, 0);
      V v_f_2413 = heff_field(v_it1_2411, 1);
      heff_take_n(v_it1_2411, 3ULL, 2);
      V v_m_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){heff_dup(v_s_242)}));
      return heff_clo_n(g_heff_2ecompile_2eimp_2ematchSet_lam0, 1, 7, (V[]){v_m_2414, v_g_240, v_x_241, v_s_242, v_arms_243, v_t_2412, v_f_2413});
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  default: return heff_nomatch(v_it_2410);
  }
}
V g_heff_2ecompile_2eimp_2ematchSet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2ematchSet(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimp_2ematchSet_lam0(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_s_242 = heff_env(self)[3];
  V v_arms_243 = heff_env(self)[4];
  V v_t_2412 = heff_env(self)[5];
  V v_f_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    switch (heff_tag_of(v_x_2417)) {
    case TAG_Nothing: {
      heff_drop(v_t_2412);
      heff_drop(v_f_2413);
      heff_drop_cell(v_ru_24x2_2416_24MkPair, 2);
      V v_t_2419 = (g_heff_2ecompile_2eimp_2ecaseSet(v_g_240, v_x_241, v_s_242, v_arms_243));
      V f_ = v_t_2419;
      args[0] = v_n_2418;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2420 = heff_field(v_x_2417, 0);
      heff_take_n(v_x_2417, 1ULL, 1);
      heff_drop(v_s_242);
      heff_drop(v_arms_243);
      V v_m_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 4)), 2, (V[]){heff_dup(v_x_241), v_t_2412}));
      V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_n_2418}));
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_MkPair: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_n_2424 = heff_field(v_x2_2422, 1);
        V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
        V v_m_2425 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){v_x_241, v_f_2413}));
        V v_x2_2426 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_n_2424}));
        switch (heff_tag_of(v_x2_2426)) {
        case TAG_MkPair: {
          V v_x_2427 = heff_field(v_x2_2426, 0);
          V v_n_2428 = heff_field(v_x2_2426, 1);
          heff_take_n(v_x2_2426, 3ULL, 2);
          V v_t_2429 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SIf, 3, (V[]){v_c_2420, v_x_2423, v_x_2427}), NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){v_t_2429, v_n_2428});
        }
        default: return heff_nomatch(v_x2_2426);
        }
      }
      default: return heff_nomatch(v_x2_2422);
      }
    }
    default: return heff_nomatch(v_x_2417);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimp_2etoDest_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimp_2etoDest_str1, 5, "False");
V g_heff_2ecompile_2eimp_2etoDest_lam0(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam1(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam2(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam3(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam4(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam5(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam6(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam7(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam8(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam9(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam10(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam11(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam12(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam13(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam14(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam15(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam16(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam17(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam18(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam19(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam20(V self, V *args);
V g_heff_2ecompile_2eimp_2etoDest_lam21(V self, V *args);
Clo g_heff_2ecompile_2eimp_2etoDest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2etoDest_entry, 3, 0};

V g_heff_2ecompile_2eimp_2etoDest(V v_g_240, V v_d_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_m_244 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam0, 1, 2, (V[]){v_m_244, heff_dup(v_d_241)});
  }
  case TAG_EGlobal: {
    V v_m_2421 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam1, 1, 2, (V[]){v_m_2421, heff_dup(v_d_241)});
  }
  case TAG_ELam: {
    V v_m_2439 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam2, 1, 2, (V[]){v_m_2439, heff_dup(v_d_241)});
  }
  case TAG_EApp: {
    V v_m_2457 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam3, 1, 2, (V[]){v_m_2457, heff_dup(v_d_241)});
  }
  case TAG_ELet: {
    V v_y_2473 = heff_field(v_e_242, 0);
    V v_a_2474 = heff_field(v_e_242, 1);
    V v_b_2475 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2476 = (g_heff_2ecompile_2eimp_2esinkTest(heff_dup(v_y_2473), heff_dup(v_a_2474), heff_dup(v_b_2475)));
    switch (heff_tag_of(v_t_2476)) {
    case TAG_Nothing: {
      V v_m_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_y_2473, v_a_2474}));
      return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam4, 1, 4, (V[]){v_m_2477, v_g_240, heff_dup(v_d_241), v_b_2475});
    }
    case TAG_Just: {
      V v_e2_2487 = heff_field(v_t_2476, 0);
      heff_take_n(v_t_2476, 1ULL, 1);
      heff_drop(v_y_2473);
      heff_drop(v_a_2474);
      heff_drop(v_b_2475);
      V t_0 = v_g_240;
      V t_1 = v_d_241;
      V t_2 = v_e2_2487;
      v_g_240 = t_0;
      v_d_241 = t_1;
      v_e_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_2476);
    }
  }
  case TAG_ERecord: {
    V v_m_2490 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam5, 1, 2, (V[]){v_m_2490, heff_dup(v_d_241)});
  }
  case TAG_EProj: {
    V v_m_24110 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam6, 1, 2, (V[]){v_m_24110, heff_dup(v_d_241)});
  }
  case TAG_ETag: {
    V v_m_24128 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam7, 1, 2, (V[]){v_m_24128, heff_dup(v_d_241)});
  }
  case TAG_EMatch: {
    V v_s_24144 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_24145 = heff_dup(heff_field(v_e_242, 1));
    V v_t_24146 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_24145));
    V v_it_24152;
    if (heff_intEq_c(v_t_24146, MK_INT(2LL))) {
      V v_t_24148 = (g_heff_2ecompile_2eimp_2earmNamed(((V)&g_heff_2ecompile_2eimp_2etoDest_str0), v_arms_24145));
      switch (heff_tag_of(v_t_24148)) {
      case TAG_Nothing: {
        v_it_24152 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_24149 = heff_field(v_t_24148, 0);
        V v_ru_24t_24148_24Just = heff_take_reuse_n(v_t_24148, 1ULL, 1);
        V v_t_24150 = (g_heff_2ecompile_2eimp_2earmNamed(((V)&g_heff_2ecompile_2eimp_2etoDest_str1), v_arms_24145));
        switch (heff_tag_of(v_t_24150)) {
        case TAG_Nothing: {
          heff_drop(v_t_24149);
          heff_drop_cell(v_ru_24t_24148_24Just, 1);
          v_it_24152 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_24151 = heff_field(v_t_24150, 0);
          heff_take_n(v_t_24150, 1ULL, 1);
          v_it_24152 = heff_tag_at_n(v_ru_24t_24148_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24149, v_f_24151})});
          break;
        }
        default: heff_nomatch(v_t_24150);
        }
        break;
      }
      default: heff_nomatch(v_t_24148);
      }
    } else {
      v_it_24152 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_it_24152)) {
    case TAG_Nothing: {
      heff_drop_tag(v_e_242, 2);
      V v_t_24155;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        V v_x_24153 = heff_field(v_d_241, 0);
        v_t_24155 = heff_dup(v_x_24153);
        break;
      }
      case TAG_DLet: {
        V v_x_24154 = heff_field(v_d_241, 0);
        v_t_24155 = heff_dup(v_x_24154);
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_m_24156 = (g_heff_2ecompile_2eimp_2ematchSet(v_g_240, v_t_24155, v_s_24144, v_arms_24145));
      return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam8, 1, 2, (V[]){v_m_24156, heff_dup(v_d_241)});
    }
    case TAG_Just: {
      V v_it1_24164 = heff_field(v_it_24152, 0);
      heff_take_n(v_it_24152, 1ULL, 1);
      switch (heff_tag_of(v_it1_24164)) {
      case TAG_MkPair: {
        V v_t_24165 = heff_field(v_it1_24164, 0);
        V v_f_24166 = heff_field(v_it1_24164, 1);
        heff_take_n(v_it1_24164, 3ULL, 2);
        V v_t_24167 = heff_dup(heff_rfield(v_g_240, 0));
        V v_t_24169;
        if ((heff_dup(v_t_24167) == NTAG(TAG_True))) {
          heff_drop(v_t_24167);
          V v_t_24168 = (g_heff_2ecompile_2eimp_2econdShaped(v_t_24165));
          if ((heff_dup(v_t_24168) == NTAG(TAG_True))) {
            heff_drop(v_t_24168);
            v_t_24169 = (g_heff_2ecompile_2eimp_2econdShaped(v_f_24166));
          } else {
            heff_drop(v_f_24166);
            heff_drop(v_t_24168);
            v_t_24169 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_t_24165);
          heff_drop(v_f_24166);
          heff_drop(v_t_24167);
          v_t_24169 = NTAG(TAG_False);
        }
        if ((heff_dup(v_t_24169) == NTAG(TAG_True))) {
          heff_drop(v_t_24169);
          V v_m_24170 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_e_242}));
          return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam9, 1, 5, (V[]){v_m_24170, heff_dup(v_d_241), v_g_240, v_s_24144, v_arms_24145});
        } else {
          heff_drop_tag(v_e_242, 2);
          heff_drop(v_t_24169);
          V v_t_24197;
          switch (heff_tag_of(v_d_241)) {
          case TAG_DSet: {
            V v_x_24195 = heff_field(v_d_241, 0);
            v_t_24197 = heff_dup(v_x_24195);
            break;
          }
          case TAG_DLet: {
            V v_x_24196 = heff_field(v_d_241, 0);
            v_t_24197 = heff_dup(v_x_24196);
            break;
          }
          default: heff_nomatch(v_d_241);
          }
          V v_m_24198 = (g_heff_2ecompile_2eimp_2ematchSet(v_g_240, v_t_24197, v_s_24144, v_arms_24145));
          return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam10, 1, 2, (V[]){v_m_24198, heff_dup(v_d_241)});
        }
      }
      default: return heff_nomatch(v_it1_24164);
      }
    }
    default: return heff_nomatch(v_it_24152);
    }
  }
  case TAG_EPrim: {
    V v_m_24207 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam11, 1, 2, (V[]){v_m_24207, heff_dup(v_d_241)});
  }
  case TAG_EPrimCall: {
    V v_m_24225 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam12, 1, 2, (V[]){v_m_24225, heff_dup(v_d_241)});
  }
  case TAG_ECall: {
    V v_m_24243 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam13, 1, 2, (V[]){v_m_24243, heff_dup(v_d_241)});
  }
  case TAG_EInt: {
    V v_m_24260 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam14, 1, 2, (V[]){v_m_24260, heff_dup(v_d_241)});
  }
  case TAG_EFloat: {
    V v_m_24277 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam15, 1, 2, (V[]){v_m_24277, heff_dup(v_d_241)});
  }
  case TAG_EStr: {
    V v_m_24294 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam16, 1, 2, (V[]){v_m_24294, heff_dup(v_d_241)});
  }
  case TAG_EBytes: {
    V v_m_24311 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam17, 1, 2, (V[]){v_m_24311, heff_dup(v_d_241)});
  }
  case TAG_EFixed: {
    V v_m_24329 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam18, 1, 2, (V[]){v_m_24329, heff_dup(v_d_241)});
  }
  case TAG_EFloat32: {
    V v_m_24346 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam19, 1, 2, (V[]){v_m_24346, heff_dup(v_d_241)});
  }
  case TAG_EAbandon: {
    V v_m_24362 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam20, 1, 2, (V[]){v_m_24362, heff_dup(v_d_241)});
  }
  case TAG_EFix: {
    V v_m_24380 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etoDest_lam21, 1, 2, (V[]){v_m_24380, heff_dup(v_d_241)});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimp_2etoDest(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eimp_2etoDest_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_249 = heff_dup(heff_field(v_x_247, 0));
      v_t_2411 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_o_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_y_2413 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_o_2414 = v_y_2413;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2417;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2415 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2417 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_SSet, 2, (V[]){v_x_2415, v_o_2414});
      break;
    }
    case TAG_DLet: {
      V v_x_2416 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2417 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_SLet, 2, (V[]){v_x_2416, v_o_2414});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_x_2419 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2418));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_n_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam1(V self, V *args) {
  V v_n_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_n_2422}));
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_n_2425 = heff_field(v_x2_2423, 1);
    V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
    V v_t_2428;
    switch (heff_tag_of(v_x_2424)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_dup(heff_field(v_x_2424, 0));
      v_t_2428 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_x_2424);
    }
    V v_o_2431;
    switch (heff_tag_of(v_x_2424)) {
    case TAG_MkPair: {
      V v_y_2430 = heff_field(v_x_2424, 1);
      heff_take_n(v_x_2424, 2ULL, 2);
      v_o_2431 = v_y_2430;
      break;
    }
    default: heff_nomatch(v_x_2424);
    }
    V v_t_2434;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2432 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2434 = heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_SSet, 2, (V[]){v_x_2432, v_o_2431});
      break;
    }
    case TAG_DLet: {
      V v_x_2433 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2434 = heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_SLet, 2, (V[]){v_x_2433, v_o_2431});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
    V v_x_2436 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2435));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2436, v_n_2425});
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam2(V self, V *args) {
  V v_n_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_n_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    V v_t_2446;
    switch (heff_tag_of(v_x_2442)) {
    case TAG_MkPair: {
      V v_x_2444 = heff_dup(heff_field(v_x_2442, 0));
      v_t_2446 = v_x_2444;
      break;
    }
    default: heff_nomatch(v_x_2442);
    }
    V v_o_2449;
    switch (heff_tag_of(v_x_2442)) {
    case TAG_MkPair: {
      V v_y_2448 = heff_field(v_x_2442, 1);
      heff_take_n(v_x_2442, 2ULL, 2);
      v_o_2449 = v_y_2448;
      break;
    }
    default: heff_nomatch(v_x_2442);
    }
    V v_t_2452;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2450 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2452 = heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_SSet, 2, (V[]){v_x_2450, v_o_2449});
      break;
    }
    case TAG_DLet: {
      V v_x_2451 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2452 = heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_SLet, 2, (V[]){v_x_2451, v_o_2449});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
    V v_x_2454 = (g_prelude_2e_2b_2b(v_t_2446, v_t_2453));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2454, v_n_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam3(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    V v_t_2464;
    switch (heff_tag_of(v_x_2460)) {
    case TAG_MkPair: {
      V v_x_2462 = heff_dup(heff_field(v_x_2460, 0));
      v_t_2464 = v_x_2462;
      break;
    }
    default: heff_nomatch(v_x_2460);
    }
    V v_o_2467;
    switch (heff_tag_of(v_x_2460)) {
    case TAG_MkPair: {
      V v_y_2466 = heff_field(v_x_2460, 1);
      heff_take_n(v_x_2460, 2ULL, 2);
      v_o_2467 = v_y_2466;
      break;
    }
    default: heff_nomatch(v_x_2460);
    }
    V v_t_2470;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2468 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2470 = heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_SSet, 2, (V[]){v_x_2468, v_o_2467});
      break;
    }
    case TAG_DLet: {
      V v_x_2469 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2470 = heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_SLet, 2, (V[]){v_x_2469, v_o_2467});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
    V v_x_2472 = (g_prelude_2e_2b_2b(v_t_2464, v_t_2471));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2472, v_n_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam4(V self, V *args) {
  V v_n_2478 = args[0];
  V v_m_2477 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_b_2475 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2479 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_n_2478}));
  switch (heff_tag_of(v_x2_2479)) {
  case TAG_MkPair: {
    V v_x_2480 = heff_field(v_x2_2479, 0);
    V v_n_2481 = heff_field(v_x2_2479, 1);
    V v_ru_24x2_2479_24MkPair = heff_take_reuse_n(v_x2_2479, 3ULL, 2);
    V v_m_2482 = ({ V a_0 = v_g_240; V a_1 = v_d_241; V a_2 = v_b_2475; V r_ = (g_heff_2ecompile_2eimp_2etoDest(a_0, a_1, a_2)); heff_drop(v_d_241); r_; });
    V v_x2_2483 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_n_2481}));
    switch (heff_tag_of(v_x2_2483)) {
    case TAG_MkPair: {
      V v_x_2484 = heff_field(v_x2_2483, 0);
      V v_n_2485 = heff_field(v_x2_2483, 1);
      heff_take_n(v_x2_2483, 3ULL, 2);
      V v_x_2486 = (g_prelude_2e_2b_2b(v_x_2480, v_x_2484));
      return heff_tag_at_n(v_ru_24x2_2479_24MkPair, TAG_MkPair, 2, (V[]){v_x_2486, v_n_2485});
    }
    default: return heff_nomatch(v_x2_2483);
    }
  }
  default: return heff_nomatch(v_x2_2479);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam5(V self, V *args) {
  V v_n_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2492 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_n_2491}));
  switch (heff_tag_of(v_x2_2492)) {
  case TAG_MkPair: {
    V v_x_2493 = heff_field(v_x2_2492, 0);
    V v_n_2494 = heff_field(v_x2_2492, 1);
    V v_ru_24x2_2492_24MkPair = heff_take_reuse_n(v_x2_2492, 3ULL, 2);
    V v_t_2497;
    switch (heff_tag_of(v_x_2493)) {
    case TAG_MkPair: {
      V v_x_2495 = heff_dup(heff_field(v_x_2493, 0));
      v_t_2497 = v_x_2495;
      break;
    }
    default: heff_nomatch(v_x_2493);
    }
    V v_o_24100;
    switch (heff_tag_of(v_x_2493)) {
    case TAG_MkPair: {
      V v_y_2499 = heff_field(v_x_2493, 1);
      heff_take_n(v_x_2493, 2ULL, 2);
      v_o_24100 = v_y_2499;
      break;
    }
    default: heff_nomatch(v_x_2493);
    }
    V v_t_24103;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24101 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24103 = heff_tag_at_n(v_ru_24x2_2492_24MkPair, TAG_SSet, 2, (V[]){v_x_24101, v_o_24100});
      break;
    }
    case TAG_DLet: {
      V v_x_24102 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24103 = heff_tag_at_n(v_ru_24x2_2492_24MkPair, TAG_SLet, 2, (V[]){v_x_24102, v_o_24100});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24104 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, NTAG(TAG_Nil)});
    V v_x_24105 = (g_prelude_2e_2b_2b(v_t_2497, v_t_24104));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24105, v_n_2494});
  }
  default: return heff_nomatch(v_x2_2492);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam6(V self, V *args) {
  V v_n_24111 = args[0];
  V v_m_24110 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24112 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_n_24111}));
  switch (heff_tag_of(v_x2_24112)) {
  case TAG_MkPair: {
    V v_x_24113 = heff_field(v_x2_24112, 0);
    V v_n_24114 = heff_field(v_x2_24112, 1);
    V v_ru_24x2_24112_24MkPair = heff_take_reuse_n(v_x2_24112, 3ULL, 2);
    V v_t_24117;
    switch (heff_tag_of(v_x_24113)) {
    case TAG_MkPair: {
      V v_x_24115 = heff_dup(heff_field(v_x_24113, 0));
      v_t_24117 = v_x_24115;
      break;
    }
    default: heff_nomatch(v_x_24113);
    }
    V v_o_24120;
    switch (heff_tag_of(v_x_24113)) {
    case TAG_MkPair: {
      V v_y_24119 = heff_field(v_x_24113, 1);
      heff_take_n(v_x_24113, 2ULL, 2);
      v_o_24120 = v_y_24119;
      break;
    }
    default: heff_nomatch(v_x_24113);
    }
    V v_t_24123;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24121 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24123 = heff_tag_at_n(v_ru_24x2_24112_24MkPair, TAG_SSet, 2, (V[]){v_x_24121, v_o_24120});
      break;
    }
    case TAG_DLet: {
      V v_x_24122 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24123 = heff_tag_at_n(v_ru_24x2_24112_24MkPair, TAG_SLet, 2, (V[]){v_x_24122, v_o_24120});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24124 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24123, NTAG(TAG_Nil)});
    V v_x_24125 = (g_prelude_2e_2b_2b(v_t_24117, v_t_24124));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24125, v_n_24114});
  }
  default: return heff_nomatch(v_x2_24112);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam7(V self, V *args) {
  V v_n_24129 = args[0];
  V v_m_24128 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24130 = heff_tr(heff_call(v_m_24128, 1, (V[]){v_n_24129}));
  switch (heff_tag_of(v_x2_24130)) {
  case TAG_MkPair: {
    V v_x_24131 = heff_field(v_x2_24130, 0);
    V v_n_24132 = heff_field(v_x2_24130, 1);
    V v_ru_24x2_24130_24MkPair = heff_take_reuse_n(v_x2_24130, 3ULL, 2);
    V v_t_24135;
    switch (heff_tag_of(v_x_24131)) {
    case TAG_MkPair: {
      V v_x_24133 = heff_dup(heff_field(v_x_24131, 0));
      v_t_24135 = v_x_24133;
      break;
    }
    default: heff_nomatch(v_x_24131);
    }
    V v_o_24138;
    switch (heff_tag_of(v_x_24131)) {
    case TAG_MkPair: {
      V v_y_24137 = heff_field(v_x_24131, 1);
      heff_take_n(v_x_24131, 2ULL, 2);
      v_o_24138 = v_y_24137;
      break;
    }
    default: heff_nomatch(v_x_24131);
    }
    V v_t_24141;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24139 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24141 = heff_tag_at_n(v_ru_24x2_24130_24MkPair, TAG_SSet, 2, (V[]){v_x_24139, v_o_24138});
      break;
    }
    case TAG_DLet: {
      V v_x_24140 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24141 = heff_tag_at_n(v_ru_24x2_24130_24MkPair, TAG_SLet, 2, (V[]){v_x_24140, v_o_24138});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24142 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24141, NTAG(TAG_Nil)});
    V v_x_24143 = (g_prelude_2e_2b_2b(v_t_24135, v_t_24142));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24143, v_n_24132});
  }
  default: return heff_nomatch(v_x2_24130);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam8(V self, V *args) {
  V v_n_24157 = args[0];
  V v_m_24156 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24158 = heff_tr(heff_call(v_m_24156, 1, (V[]){v_n_24157}));
  switch (heff_tag_of(v_x2_24158)) {
  case TAG_MkPair: {
    V v_x_24159 = heff_field(v_x2_24158, 0);
    V v_n_24160 = heff_field(v_x2_24158, 1);
    V v_ru_24x2_24158_24MkPair = heff_take_reuse_n(v_x2_24158, 3ULL, 2);
    V v_x_24163;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_x_24163 = v_x_24159;
      break;
    }
    case TAG_DLet: {
      V v_x_24162 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_x_24163 = (g_heff_2ecompile_2eimp_2edeclBefore(v_x_24162, v_x_24159));
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    return heff_tag_at_n(v_ru_24x2_24158_24MkPair, TAG_MkPair, 2, (V[]){v_x_24163, v_n_24160});
  }
  default: return heff_nomatch(v_x2_24158);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam9(V self, V *args) {
  V v_n_24171 = args[0];
  V v_m_24170 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_s_24144 = heff_env(self)[3];
  V v_arms_24145 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24172 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_n_24171}));
  V v_x2_24177;
  switch (heff_tag_of(v_x2_24172)) {
  case TAG_MkPair: {
    V v_x_24173 = heff_field(v_x2_24172, 0);
    V v_n_24174 = heff_field(v_x2_24172, 1);
    V v_ru_24x2_24172_24MkPair = heff_take_reuse_n(v_x2_24172, 3ULL, 2);
    V v_x_24176;
    switch (heff_tag_of(v_x_24173)) {
    case TAG_Nothing: {
      v_x_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_c_24175 = heff_field(v_x_24173, 0);
      V v_ru_24x_24173_24Just = heff_take_reuse_n(v_x_24173, 1ULL, 1);
      v_x_24176 = heff_tag_at_n(v_ru_24x_24173_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_OBool, 1, (V[]){v_c_24175})});
      break;
    }
    default: heff_nomatch(v_x_24173);
    }
    v_x2_24177 = heff_tag_at_n(v_ru_24x2_24172_24MkPair, TAG_MkPair, 2, (V[]){v_x_24176, v_n_24174});
    break;
  }
  default: heff_nomatch(v_x2_24172);
  }
  switch (heff_tag_of(v_x2_24177)) {
  case TAG_MkPair: {
    V v_x_24178 = heff_field(v_x2_24177, 0);
    V v_n_24179 = heff_field(v_x2_24177, 1);
    V v_ru_24x2_24177_24MkPair = heff_take_reuse_n(v_x2_24177, 3ULL, 2);
    switch (heff_tag_of(v_x_24178)) {
    case TAG_Nothing: {
      V v_t_24182;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        V v_x_24180 = heff_dup(heff_field(v_d_241, 0));
        v_t_24182 = v_x_24180;
        break;
      }
      case TAG_DLet: {
        V v_x_24181 = heff_dup(heff_field(v_d_241, 0));
        v_t_24182 = v_x_24181;
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_m_24183 = (g_heff_2ecompile_2eimp_2ematchSet(v_g_240, v_t_24182, v_s_24144, v_arms_24145));
      V v_x2_24184 = heff_tr(heff_call(v_m_24183, 1, (V[]){v_n_24179}));
      switch (heff_tag_of(v_x2_24184)) {
      case TAG_MkPair: {
        V v_x_24185 = heff_field(v_x2_24184, 0);
        V v_n_24186 = heff_field(v_x2_24184, 1);
        heff_take_n(v_x2_24184, 3ULL, 2);
        V v_x_24189;
        switch (heff_tag_of(v_d_241)) {
        case TAG_DSet: {
          heff_take_n(v_d_241, 0ULL, 1);
          v_x_24189 = v_x_24185;
          break;
        }
        case TAG_DLet: {
          V v_x_24188 = heff_field(v_d_241, 0);
          heff_take_n(v_d_241, 1ULL, 1);
          v_x_24189 = (g_heff_2ecompile_2eimp_2edeclBefore(v_x_24188, v_x_24185));
          break;
        }
        default: heff_nomatch(v_d_241);
        }
        return heff_tag_at_n(v_ru_24x2_24177_24MkPair, TAG_MkPair, 2, (V[]){v_x_24189, v_n_24186});
      }
      default: return heff_nomatch(v_x2_24184);
      }
    }
    case TAG_Just: {
      V v_o_24190 = heff_field(v_x_24178, 0);
      heff_take_n(v_x_24178, 1ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_s_24144);
      heff_drop(v_arms_24145);
      V v_t_24193;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        V v_x_24191 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_24193 = heff_tag_at_n(v_ru_24x2_24177_24MkPair, TAG_SSet, 2, (V[]){v_x_24191, v_o_24190});
        break;
      }
      case TAG_DLet: {
        V v_x_24192 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_24193 = heff_tag_at_n(v_ru_24x2_24177_24MkPair, TAG_SLet, 2, (V[]){v_x_24192, v_o_24190});
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_x_24194 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24193, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24194, v_n_24179});
    }
    default: return heff_nomatch(v_x_24178);
    }
  }
  default: return heff_nomatch(v_x2_24177);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam10(V self, V *args) {
  V v_n_24199 = args[0];
  V v_m_24198 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24200 = heff_tr(heff_call(v_m_24198, 1, (V[]){v_n_24199}));
  switch (heff_tag_of(v_x2_24200)) {
  case TAG_MkPair: {
    V v_x_24201 = heff_field(v_x2_24200, 0);
    V v_n_24202 = heff_field(v_x2_24200, 1);
    V v_ru_24x2_24200_24MkPair = heff_take_reuse_n(v_x2_24200, 3ULL, 2);
    V v_x_24205;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_x_24205 = v_x_24201;
      break;
    }
    case TAG_DLet: {
      V v_x_24204 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_x_24205 = (g_heff_2ecompile_2eimp_2edeclBefore(v_x_24204, v_x_24201));
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    return heff_tag_at_n(v_ru_24x2_24200_24MkPair, TAG_MkPair, 2, (V[]){v_x_24205, v_n_24202});
  }
  default: return heff_nomatch(v_x2_24200);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam11(V self, V *args) {
  V v_n_24208 = args[0];
  V v_m_24207 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24209 = heff_tr(heff_call(v_m_24207, 1, (V[]){v_n_24208}));
  switch (heff_tag_of(v_x2_24209)) {
  case TAG_MkPair: {
    V v_x_24210 = heff_field(v_x2_24209, 0);
    V v_n_24211 = heff_field(v_x2_24209, 1);
    V v_ru_24x2_24209_24MkPair = heff_take_reuse_n(v_x2_24209, 3ULL, 2);
    V v_t_24214;
    switch (heff_tag_of(v_x_24210)) {
    case TAG_MkPair: {
      V v_x_24212 = heff_dup(heff_field(v_x_24210, 0));
      v_t_24214 = v_x_24212;
      break;
    }
    default: heff_nomatch(v_x_24210);
    }
    V v_o_24217;
    switch (heff_tag_of(v_x_24210)) {
    case TAG_MkPair: {
      V v_y_24216 = heff_field(v_x_24210, 1);
      heff_take_n(v_x_24210, 2ULL, 2);
      v_o_24217 = v_y_24216;
      break;
    }
    default: heff_nomatch(v_x_24210);
    }
    V v_t_24220;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24218 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24220 = heff_tag_at_n(v_ru_24x2_24209_24MkPair, TAG_SSet, 2, (V[]){v_x_24218, v_o_24217});
      break;
    }
    case TAG_DLet: {
      V v_x_24219 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24220 = heff_tag_at_n(v_ru_24x2_24209_24MkPair, TAG_SLet, 2, (V[]){v_x_24219, v_o_24217});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24221 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24220, NTAG(TAG_Nil)});
    V v_x_24222 = (g_prelude_2e_2b_2b(v_t_24214, v_t_24221));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24222, v_n_24211});
  }
  default: return heff_nomatch(v_x2_24209);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam12(V self, V *args) {
  V v_n_24226 = args[0];
  V v_m_24225 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24227 = heff_tr(heff_call(v_m_24225, 1, (V[]){v_n_24226}));
  switch (heff_tag_of(v_x2_24227)) {
  case TAG_MkPair: {
    V v_x_24228 = heff_field(v_x2_24227, 0);
    V v_n_24229 = heff_field(v_x2_24227, 1);
    V v_ru_24x2_24227_24MkPair = heff_take_reuse_n(v_x2_24227, 3ULL, 2);
    V v_t_24232;
    switch (heff_tag_of(v_x_24228)) {
    case TAG_MkPair: {
      V v_x_24230 = heff_dup(heff_field(v_x_24228, 0));
      v_t_24232 = v_x_24230;
      break;
    }
    default: heff_nomatch(v_x_24228);
    }
    V v_o_24235;
    switch (heff_tag_of(v_x_24228)) {
    case TAG_MkPair: {
      V v_y_24234 = heff_field(v_x_24228, 1);
      heff_take_n(v_x_24228, 2ULL, 2);
      v_o_24235 = v_y_24234;
      break;
    }
    default: heff_nomatch(v_x_24228);
    }
    V v_t_24238;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24236 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24238 = heff_tag_at_n(v_ru_24x2_24227_24MkPair, TAG_SSet, 2, (V[]){v_x_24236, v_o_24235});
      break;
    }
    case TAG_DLet: {
      V v_x_24237 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24238 = heff_tag_at_n(v_ru_24x2_24227_24MkPair, TAG_SLet, 2, (V[]){v_x_24237, v_o_24235});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24239 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24238, NTAG(TAG_Nil)});
    V v_x_24240 = (g_prelude_2e_2b_2b(v_t_24232, v_t_24239));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24240, v_n_24229});
  }
  default: return heff_nomatch(v_x2_24227);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam13(V self, V *args) {
  V v_n_24244 = args[0];
  V v_m_24243 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24245 = heff_tr(heff_call(v_m_24243, 1, (V[]){v_n_24244}));
  switch (heff_tag_of(v_x2_24245)) {
  case TAG_MkPair: {
    V v_x_24246 = heff_field(v_x2_24245, 0);
    V v_n_24247 = heff_field(v_x2_24245, 1);
    V v_ru_24x2_24245_24MkPair = heff_take_reuse_n(v_x2_24245, 3ULL, 2);
    V v_t_24250;
    switch (heff_tag_of(v_x_24246)) {
    case TAG_MkPair: {
      V v_x_24248 = heff_dup(heff_field(v_x_24246, 0));
      v_t_24250 = v_x_24248;
      break;
    }
    default: heff_nomatch(v_x_24246);
    }
    V v_o_24253;
    switch (heff_tag_of(v_x_24246)) {
    case TAG_MkPair: {
      V v_y_24252 = heff_field(v_x_24246, 1);
      heff_take_n(v_x_24246, 2ULL, 2);
      v_o_24253 = v_y_24252;
      break;
    }
    default: heff_nomatch(v_x_24246);
    }
    V v_t_24256;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24254 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24256 = heff_tag_at_n(v_ru_24x2_24245_24MkPair, TAG_SSet, 2, (V[]){v_x_24254, v_o_24253});
      break;
    }
    case TAG_DLet: {
      V v_x_24255 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24256 = heff_tag_at_n(v_ru_24x2_24245_24MkPair, TAG_SLet, 2, (V[]){v_x_24255, v_o_24253});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24257 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24256, NTAG(TAG_Nil)});
    V v_x_24258 = (g_prelude_2e_2b_2b(v_t_24250, v_t_24257));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24258, v_n_24247});
  }
  default: return heff_nomatch(v_x2_24245);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam14(V self, V *args) {
  V v_n_24261 = args[0];
  V v_m_24260 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24262 = heff_tr(heff_call(v_m_24260, 1, (V[]){v_n_24261}));
  switch (heff_tag_of(v_x2_24262)) {
  case TAG_MkPair: {
    V v_x_24263 = heff_field(v_x2_24262, 0);
    V v_n_24264 = heff_field(v_x2_24262, 1);
    V v_ru_24x2_24262_24MkPair = heff_take_reuse_n(v_x2_24262, 3ULL, 2);
    V v_t_24267;
    switch (heff_tag_of(v_x_24263)) {
    case TAG_MkPair: {
      V v_x_24265 = heff_dup(heff_field(v_x_24263, 0));
      v_t_24267 = v_x_24265;
      break;
    }
    default: heff_nomatch(v_x_24263);
    }
    V v_o_24270;
    switch (heff_tag_of(v_x_24263)) {
    case TAG_MkPair: {
      V v_y_24269 = heff_field(v_x_24263, 1);
      heff_take_n(v_x_24263, 2ULL, 2);
      v_o_24270 = v_y_24269;
      break;
    }
    default: heff_nomatch(v_x_24263);
    }
    V v_t_24273;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24271 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24273 = heff_tag_at_n(v_ru_24x2_24262_24MkPair, TAG_SSet, 2, (V[]){v_x_24271, v_o_24270});
      break;
    }
    case TAG_DLet: {
      V v_x_24272 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24273 = heff_tag_at_n(v_ru_24x2_24262_24MkPair, TAG_SLet, 2, (V[]){v_x_24272, v_o_24270});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24274 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24273, NTAG(TAG_Nil)});
    V v_x_24275 = (g_prelude_2e_2b_2b(v_t_24267, v_t_24274));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24275, v_n_24264});
  }
  default: return heff_nomatch(v_x2_24262);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam15(V self, V *args) {
  V v_n_24278 = args[0];
  V v_m_24277 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24279 = heff_tr(heff_call(v_m_24277, 1, (V[]){v_n_24278}));
  switch (heff_tag_of(v_x2_24279)) {
  case TAG_MkPair: {
    V v_x_24280 = heff_field(v_x2_24279, 0);
    V v_n_24281 = heff_field(v_x2_24279, 1);
    V v_ru_24x2_24279_24MkPair = heff_take_reuse_n(v_x2_24279, 3ULL, 2);
    V v_t_24284;
    switch (heff_tag_of(v_x_24280)) {
    case TAG_MkPair: {
      V v_x_24282 = heff_dup(heff_field(v_x_24280, 0));
      v_t_24284 = v_x_24282;
      break;
    }
    default: heff_nomatch(v_x_24280);
    }
    V v_o_24287;
    switch (heff_tag_of(v_x_24280)) {
    case TAG_MkPair: {
      V v_y_24286 = heff_field(v_x_24280, 1);
      heff_take_n(v_x_24280, 2ULL, 2);
      v_o_24287 = v_y_24286;
      break;
    }
    default: heff_nomatch(v_x_24280);
    }
    V v_t_24290;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24288 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24290 = heff_tag_at_n(v_ru_24x2_24279_24MkPair, TAG_SSet, 2, (V[]){v_x_24288, v_o_24287});
      break;
    }
    case TAG_DLet: {
      V v_x_24289 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24290 = heff_tag_at_n(v_ru_24x2_24279_24MkPair, TAG_SLet, 2, (V[]){v_x_24289, v_o_24287});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24291 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24290, NTAG(TAG_Nil)});
    V v_x_24292 = (g_prelude_2e_2b_2b(v_t_24284, v_t_24291));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24292, v_n_24281});
  }
  default: return heff_nomatch(v_x2_24279);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam16(V self, V *args) {
  V v_n_24295 = args[0];
  V v_m_24294 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24296 = heff_tr(heff_call(v_m_24294, 1, (V[]){v_n_24295}));
  switch (heff_tag_of(v_x2_24296)) {
  case TAG_MkPair: {
    V v_x_24297 = heff_field(v_x2_24296, 0);
    V v_n_24298 = heff_field(v_x2_24296, 1);
    V v_ru_24x2_24296_24MkPair = heff_take_reuse_n(v_x2_24296, 3ULL, 2);
    V v_t_24301;
    switch (heff_tag_of(v_x_24297)) {
    case TAG_MkPair: {
      V v_x_24299 = heff_dup(heff_field(v_x_24297, 0));
      v_t_24301 = v_x_24299;
      break;
    }
    default: heff_nomatch(v_x_24297);
    }
    V v_o_24304;
    switch (heff_tag_of(v_x_24297)) {
    case TAG_MkPair: {
      V v_y_24303 = heff_field(v_x_24297, 1);
      heff_take_n(v_x_24297, 2ULL, 2);
      v_o_24304 = v_y_24303;
      break;
    }
    default: heff_nomatch(v_x_24297);
    }
    V v_t_24307;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24305 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24307 = heff_tag_at_n(v_ru_24x2_24296_24MkPair, TAG_SSet, 2, (V[]){v_x_24305, v_o_24304});
      break;
    }
    case TAG_DLet: {
      V v_x_24306 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24307 = heff_tag_at_n(v_ru_24x2_24296_24MkPair, TAG_SLet, 2, (V[]){v_x_24306, v_o_24304});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24308 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24307, NTAG(TAG_Nil)});
    V v_x_24309 = (g_prelude_2e_2b_2b(v_t_24301, v_t_24308));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24309, v_n_24298});
  }
  default: return heff_nomatch(v_x2_24296);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam17(V self, V *args) {
  V v_n_24312 = args[0];
  V v_m_24311 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24313 = heff_tr(heff_call(v_m_24311, 1, (V[]){v_n_24312}));
  switch (heff_tag_of(v_x2_24313)) {
  case TAG_MkPair: {
    V v_x_24314 = heff_field(v_x2_24313, 0);
    V v_n_24315 = heff_field(v_x2_24313, 1);
    V v_ru_24x2_24313_24MkPair = heff_take_reuse_n(v_x2_24313, 3ULL, 2);
    V v_t_24318;
    switch (heff_tag_of(v_x_24314)) {
    case TAG_MkPair: {
      V v_x_24316 = heff_dup(heff_field(v_x_24314, 0));
      v_t_24318 = v_x_24316;
      break;
    }
    default: heff_nomatch(v_x_24314);
    }
    V v_o_24321;
    switch (heff_tag_of(v_x_24314)) {
    case TAG_MkPair: {
      V v_y_24320 = heff_field(v_x_24314, 1);
      heff_take_n(v_x_24314, 2ULL, 2);
      v_o_24321 = v_y_24320;
      break;
    }
    default: heff_nomatch(v_x_24314);
    }
    V v_t_24324;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24322 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24324 = heff_tag_at_n(v_ru_24x2_24313_24MkPair, TAG_SSet, 2, (V[]){v_x_24322, v_o_24321});
      break;
    }
    case TAG_DLet: {
      V v_x_24323 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24324 = heff_tag_at_n(v_ru_24x2_24313_24MkPair, TAG_SLet, 2, (V[]){v_x_24323, v_o_24321});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24325 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24324, NTAG(TAG_Nil)});
    V v_x_24326 = (g_prelude_2e_2b_2b(v_t_24318, v_t_24325));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24326, v_n_24315});
  }
  default: return heff_nomatch(v_x2_24313);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam18(V self, V *args) {
  V v_n_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24331 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_n_24330}));
  switch (heff_tag_of(v_x2_24331)) {
  case TAG_MkPair: {
    V v_x_24332 = heff_field(v_x2_24331, 0);
    V v_n_24333 = heff_field(v_x2_24331, 1);
    V v_ru_24x2_24331_24MkPair = heff_take_reuse_n(v_x2_24331, 3ULL, 2);
    V v_t_24336;
    switch (heff_tag_of(v_x_24332)) {
    case TAG_MkPair: {
      V v_x_24334 = heff_dup(heff_field(v_x_24332, 0));
      v_t_24336 = v_x_24334;
      break;
    }
    default: heff_nomatch(v_x_24332);
    }
    V v_o_24339;
    switch (heff_tag_of(v_x_24332)) {
    case TAG_MkPair: {
      V v_y_24338 = heff_field(v_x_24332, 1);
      heff_take_n(v_x_24332, 2ULL, 2);
      v_o_24339 = v_y_24338;
      break;
    }
    default: heff_nomatch(v_x_24332);
    }
    V v_t_24342;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24340 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24342 = heff_tag_at_n(v_ru_24x2_24331_24MkPair, TAG_SSet, 2, (V[]){v_x_24340, v_o_24339});
      break;
    }
    case TAG_DLet: {
      V v_x_24341 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24342 = heff_tag_at_n(v_ru_24x2_24331_24MkPair, TAG_SLet, 2, (V[]){v_x_24341, v_o_24339});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24343 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24342, NTAG(TAG_Nil)});
    V v_x_24344 = (g_prelude_2e_2b_2b(v_t_24336, v_t_24343));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24344, v_n_24333});
  }
  default: return heff_nomatch(v_x2_24331);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam19(V self, V *args) {
  V v_n_24347 = args[0];
  V v_m_24346 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24348 = heff_tr(heff_call(v_m_24346, 1, (V[]){v_n_24347}));
  switch (heff_tag_of(v_x2_24348)) {
  case TAG_MkPair: {
    V v_x_24349 = heff_field(v_x2_24348, 0);
    V v_n_24350 = heff_field(v_x2_24348, 1);
    V v_ru_24x2_24348_24MkPair = heff_take_reuse_n(v_x2_24348, 3ULL, 2);
    V v_t_24353;
    switch (heff_tag_of(v_x_24349)) {
    case TAG_MkPair: {
      V v_x_24351 = heff_dup(heff_field(v_x_24349, 0));
      v_t_24353 = v_x_24351;
      break;
    }
    default: heff_nomatch(v_x_24349);
    }
    V v_o_24356;
    switch (heff_tag_of(v_x_24349)) {
    case TAG_MkPair: {
      V v_y_24355 = heff_field(v_x_24349, 1);
      heff_take_n(v_x_24349, 2ULL, 2);
      v_o_24356 = v_y_24355;
      break;
    }
    default: heff_nomatch(v_x_24349);
    }
    V v_t_24359;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24357 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24359 = heff_tag_at_n(v_ru_24x2_24348_24MkPair, TAG_SSet, 2, (V[]){v_x_24357, v_o_24356});
      break;
    }
    case TAG_DLet: {
      V v_x_24358 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24359 = heff_tag_at_n(v_ru_24x2_24348_24MkPair, TAG_SLet, 2, (V[]){v_x_24358, v_o_24356});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24360 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24359, NTAG(TAG_Nil)});
    V v_x_24361 = (g_prelude_2e_2b_2b(v_t_24353, v_t_24360));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24361, v_n_24350});
  }
  default: return heff_nomatch(v_x2_24348);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam20(V self, V *args) {
  V v_n_24363 = args[0];
  V v_m_24362 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24364 = heff_tr(heff_call(v_m_24362, 1, (V[]){v_n_24363}));
  switch (heff_tag_of(v_x2_24364)) {
  case TAG_MkPair: {
    V v_x_24365 = heff_field(v_x2_24364, 0);
    V v_n_24366 = heff_field(v_x2_24364, 1);
    V v_ru_24x2_24364_24MkPair = heff_take_reuse_n(v_x2_24364, 3ULL, 2);
    V v_t_24369;
    switch (heff_tag_of(v_x_24365)) {
    case TAG_MkPair: {
      V v_x_24367 = heff_dup(heff_field(v_x_24365, 0));
      v_t_24369 = v_x_24367;
      break;
    }
    default: heff_nomatch(v_x_24365);
    }
    V v_o_24372;
    switch (heff_tag_of(v_x_24365)) {
    case TAG_MkPair: {
      V v_y_24371 = heff_field(v_x_24365, 1);
      heff_take_n(v_x_24365, 2ULL, 2);
      v_o_24372 = v_y_24371;
      break;
    }
    default: heff_nomatch(v_x_24365);
    }
    V v_t_24375;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24373 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24375 = heff_tag_at_n(v_ru_24x2_24364_24MkPair, TAG_SSet, 2, (V[]){v_x_24373, v_o_24372});
      break;
    }
    case TAG_DLet: {
      V v_x_24374 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24375 = heff_tag_at_n(v_ru_24x2_24364_24MkPair, TAG_SLet, 2, (V[]){v_x_24374, v_o_24372});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24376 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24375, NTAG(TAG_Nil)});
    V v_x_24377 = (g_prelude_2e_2b_2b(v_t_24369, v_t_24376));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24377, v_n_24366});
  }
  default: return heff_nomatch(v_x2_24364);
  }
}
V g_heff_2ecompile_2eimp_2etoDest_lam21(V self, V *args) {
  V v_n_24381 = args[0];
  V v_m_24380 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24382 = heff_tr(heff_call(v_m_24380, 1, (V[]){v_n_24381}));
  switch (heff_tag_of(v_x2_24382)) {
  case TAG_MkPair: {
    V v_x_24383 = heff_field(v_x2_24382, 0);
    V v_n_24384 = heff_field(v_x2_24382, 1);
    V v_ru_24x2_24382_24MkPair = heff_take_reuse_n(v_x2_24382, 3ULL, 2);
    V v_t_24387;
    switch (heff_tag_of(v_x_24383)) {
    case TAG_MkPair: {
      V v_x_24385 = heff_dup(heff_field(v_x_24383, 0));
      v_t_24387 = v_x_24385;
      break;
    }
    default: heff_nomatch(v_x_24383);
    }
    V v_o_24390;
    switch (heff_tag_of(v_x_24383)) {
    case TAG_MkPair: {
      V v_y_24389 = heff_field(v_x_24383, 1);
      heff_take_n(v_x_24383, 2ULL, 2);
      v_o_24390 = v_y_24389;
      break;
    }
    default: heff_nomatch(v_x_24383);
    }
    V v_t_24393;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24391 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24393 = heff_tag_at_n(v_ru_24x2_24382_24MkPair, TAG_SSet, 2, (V[]){v_x_24391, v_o_24390});
      break;
    }
    case TAG_DLet: {
      V v_x_24392 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24393 = heff_tag_at_n(v_ru_24x2_24382_24MkPair, TAG_SLet, 2, (V[]){v_x_24392, v_o_24390});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24394 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24393, NTAG(TAG_Nil)});
    V v_x_24395 = (g_prelude_2e_2b_2b(v_t_24387, v_t_24394));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24395, v_n_24384});
  }
  default: return heff_nomatch(v_x2_24382);
  }
}
V g_heff_2ecompile_2eimp_2eopTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimp_2eopTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2eopTail_entry, 2, 0};

V g_heff_2ecompile_2eimp_2eopTail(V v_g_240, V v_e_241) {
top: ;
  V v_m_242 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_241}));
  return heff_clo_n(g_heff_2ecompile_2eimp_2eopTail_lam0, 1, 1, (V[]){v_m_242});
}
V g_heff_2ecompile_2eimp_2eopTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2eopTail(a[0], a[1]);
}
V g_heff_2ecompile_2eimp_2eopTail_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_244 = heff_tr(heff_call(v_m_242, 1, (V[]){v_n_243}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_n_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_ss_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_dup(heff_field(v_x_245, 0));
      v_ss_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_y_2411 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 2ULL, 2);
      v_t_2412 = v_y_2411;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2413 = heff_tag_n(TAG_TReturn, 1, (V[]){v_t_2412});
    V v_x_2426;
    switch (heff_tag_of(v_ss_249)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x2_244_24MkPair, 2);
      v_x_2426 = v_t_2413;
      break;
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_t_2413)) {
      case TAG_TSeq: {
        V v_ss2_2416 = heff_field(v_t_2413, 0);
        V v_t2_2417 = heff_field(v_t_2413, 1);
        heff_take_n(v_t_2413, 3ULL, 2);
        V v_t_2418 = (g_prelude_2e_2b_2b(v_ss_249, v_ss2_2416));
        v_x_2426 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_TSeq, 2, (V[]){v_t_2418, v_t2_2417});
        break;
      }
      case TAG_TReturn: {
        v_x_2426 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_TSeq, 2, (V[]){v_ss_249, v_t_2413});
        break;
      }
      case TAG_TLoop: {
        v_x_2426 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_TSeq, 2, (V[]){v_ss_249, v_t_2413});
        break;
      }
      case TAG_TIf: {
        v_x_2426 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_TSeq, 2, (V[]){v_ss_249, v_t_2413});
        break;
      }
      case TAG_TCase: {
        v_x_2426 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_TSeq, 2, (V[]){v_ss_249, v_t_2413});
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      break;
    }
    default: heff_nomatch(v_ss_249);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2426, v_n_246});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2eimp_2ecaseTail_lam2(V self, V *args);
V g_heff_2ecompile_2eimp_2ecaseTail_lam1(V self, V *args);
V g_heff_2ecompile_2eimp_2ecaseTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimp_2ecaseTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2ecaseTail_entry, 4, 0};

V g_heff_2ecompile_2eimp_2ecaseTail(V v_g_240, V v_self_241, V v_s_242, V v_arms_243) {
top: ;
  V v_m_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 5)), 1, (V[]){v_s_242}));
  return heff_clo_n(g_heff_2ecompile_2eimp_2ecaseTail_lam0, 1, 4, (V[]){v_m_244, v_g_240, v_self_241, v_arms_243});
}
V g_heff_2ecompile_2eimp_2ecaseTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2ecaseTail(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimp_2ecaseTail_lam2(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_t_2410 = heff_env(self)[1];
  V v_vs_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_vs_2411, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eimp_2ecaseTail_lam1(V self, V *args) {
  V v_arm_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_self_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_249)) {
  case TAG_MkArm: {
    V v_t_2410 = heff_field(v_arm_249, 0);
    V v_vs_2411 = heff_field(v_arm_249, 1);
    V v_b_2412 = heff_field(v_arm_249, 2);
    heff_take_n(v_arm_249, 7ULL, 3);
    V v_m_2413 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_b_2412}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2ecaseTail_lam2, 1, 3, (V[]){v_m_2413, v_t_2410, v_vs_2411});
  }
  default: return heff_nomatch(v_arm_249);
  }
}
V g_heff_2ecompile_2eimp_2ecaseTail_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_arms_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_2418 = (g_heff_2ecompile_2eimp_2etraverseN(heff_clo_n(g_heff_2ecompile_2eimp_2ecaseTail_lam1, 1, 2, (V[]){v_g_240, v_self_241}), v_arms_243));
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_n_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      V v_ss_2424;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_x_2422 = heff_dup(heff_field(v_x_247, 0));
        v_ss_2424 = v_x_2422;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_t_2427;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_y_2426 = heff_field(v_x_247, 1);
        heff_take_n(v_x_247, 2ULL, 2);
        v_t_2427 = v_y_2426;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_t_2428 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_TCase, 2, (V[]){v_t_2427, v_x_2420});
      V v_x_2441;
      switch (heff_tag_of(v_ss_2424)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_2419_24MkPair, 2);
        v_x_2441 = v_t_2428;
        break;
      }
      case TAG_Cons: {
        switch (heff_tag_of(v_t_2428)) {
        case TAG_TSeq: {
          V v_ss2_2431 = heff_field(v_t_2428, 0);
          V v_t2_2432 = heff_field(v_t_2428, 1);
          heff_take_n(v_t_2428, 3ULL, 2);
          V v_t_2433 = (g_prelude_2e_2b_2b(v_ss_2424, v_ss2_2431));
          v_x_2441 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TSeq, 2, (V[]){v_t_2433, v_t2_2432});
          break;
        }
        case TAG_TReturn: {
          v_x_2441 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TSeq, 2, (V[]){v_ss_2424, v_t_2428});
          break;
        }
        case TAG_TLoop: {
          v_x_2441 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TSeq, 2, (V[]){v_ss_2424, v_t_2428});
          break;
        }
        case TAG_TIf: {
          v_x_2441 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TSeq, 2, (V[]){v_ss_2424, v_t_2428});
          break;
        }
        case TAG_TCase: {
          v_x_2441 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TSeq, 2, (V[]){v_ss_2424, v_t_2428});
          break;
        }
        default: heff_nomatch(v_t_2428);
        }
        break;
      }
      default: heff_nomatch(v_ss_2424);
      }
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2441, v_n_2421});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimp_2etailOf_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimp_2etailOf_str1, 5, "False");
V g_heff_2ecompile_2eimp_2etailOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimp_2etailOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimp_2etailOf_lam2(V self, V *args);
Clo g_heff_2ecompile_2eimp_2etailOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2etailOf_entry, 3, 0};

V g_heff_2ecompile_2eimp_2etailOf(V v_g_240, V v_self_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EGlobal: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ELam: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EApp: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ELet: {
    V v_y_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eimp_2esinkTest(heff_dup(v_y_249), heff_dup(v_a_2410), heff_dup(v_b_2411)));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      V v_m_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_y_249, v_a_2410}));
      return heff_clo_n(g_heff_2ecompile_2eimp_2etailOf_lam0, 1, 4, (V[]){v_m_2413, v_g_240, v_self_241, v_b_2411});
    }
    case TAG_Just: {
      V v_e2_2435 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      heff_drop(v_y_249);
      heff_drop(v_a_2410);
      heff_drop(v_b_2411);
      return heff_tail(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_e2_2435});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_ERecord: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EProj: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ETag: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EMatch: {
    V v_s_2444 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_2445 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2446 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_2445));
    V v_it_2452;
    if (heff_intEq_c(v_t_2446, MK_INT(2LL))) {
      V v_t_2448 = (g_heff_2ecompile_2eimp_2earmNamed(((V)&g_heff_2ecompile_2eimp_2etailOf_str0), v_arms_2445));
      switch (heff_tag_of(v_t_2448)) {
      case TAG_Nothing: {
        v_it_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_2449 = heff_field(v_t_2448, 0);
        V v_ru_24t_2448_24Just = heff_take_reuse_n(v_t_2448, 1ULL, 1);
        V v_t_2450 = (g_heff_2ecompile_2eimp_2earmNamed(((V)&g_heff_2ecompile_2eimp_2etailOf_str1), v_arms_2445));
        switch (heff_tag_of(v_t_2450)) {
        case TAG_Nothing: {
          heff_drop(v_t_2449);
          heff_drop_cell(v_ru_24t_2448_24Just, 1);
          v_it_2452 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_2451 = heff_field(v_t_2450, 0);
          heff_take_n(v_t_2450, 1ULL, 1);
          v_it_2452 = heff_tag_at_n(v_ru_24t_2448_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2449, v_f_2451})});
          break;
        }
        default: heff_nomatch(v_t_2450);
        }
        break;
      }
      default: heff_nomatch(v_t_2448);
      }
    } else {
      v_it_2452 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_it_2452)) {
    case TAG_Nothing: {
      heff_drop_tag(v_e_242, 2);
      return (g_heff_2ecompile_2eimp_2ecaseTail(v_g_240, v_self_241, v_s_2444, v_arms_2445));
    }
    case TAG_Just: {
      V v_it1_2453 = heff_field(v_it_2452, 0);
      heff_take_n(v_it_2452, 1ULL, 1);
      switch (heff_tag_of(v_it1_2453)) {
      case TAG_MkPair: {
        V v_t_2454 = heff_field(v_it1_2453, 0);
        V v_f_2455 = heff_field(v_it1_2453, 1);
        heff_take_n(v_it1_2453, 3ULL, 2);
        V v_t_2456 = heff_dup(heff_rfield(v_g_240, 0));
        V v_t_2459;
        if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
          heff_drop(v_t_2456);
          switch (heff_tag_of(v_self_241)) {
          case TAG_Nothing: {
            V v_t_2457 = (g_heff_2ecompile_2eimp_2econdShaped(heff_dup(v_t_2454)));
            if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
              heff_drop(v_t_2457);
              v_t_2459 = (g_heff_2ecompile_2eimp_2econdShaped(heff_dup(v_f_2455)));
            } else {
              heff_drop(v_t_2457);
              v_t_2459 = NTAG(TAG_False);
            }
            break;
          }
          case TAG_Just: {
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_self_241);
          }
        } else {
          heff_drop(v_t_2456);
          v_t_2459 = NTAG(TAG_False);
        }
        if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
          heff_drop(v_t_2459);
          V v_m_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_e_242}));
          return heff_clo_n(g_heff_2ecompile_2eimp_2etailOf_lam1, 1, 7, (V[]){v_m_2460, v_g_240, v_self_241, v_s_2444, v_t_2454, v_f_2455, v_arms_2445});
        } else {
          heff_drop_tag(v_e_242, 2);
          heff_drop(v_t_2459);
          return (g_heff_2ecompile_2eimp_2etestTail(v_g_240, v_self_241, v_s_2444, v_t_2454, v_f_2455, v_arms_2445));
        }
      }
      default: return heff_nomatch(v_it1_2453);
      }
    }
    default: return heff_nomatch(v_it_2452);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EPrimCall: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ECall: {
    V v_k_2475 = heff_dup(heff_field(v_e_242, 0));
    V v_as_2476 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2480;
    switch (heff_tag_of(v_self_241)) {
    case TAG_Nothing: {
      heff_drop(v_k_2475);
      v_t_2480 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_s_2477 = heff_field(v_self_241, 0);
      heff_take_n(v_self_241, 1ULL, 1);
      v_t_2480 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_s_2477, 0)), heff_dup(v_k_2475)) && ({ V v_t_2479 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2476)); int c_ = heff_intEq_c(heff_dup(v_t_2479), heff_dup(heff_rfield(v_s_2477, 1))); heff_drop(v_t_2479); c_; })));
      heff_drop(v_k_2475);
      heff_drop_rec(v_s_2477, 2);
      break;
    }
    default: heff_nomatch(v_self_241);
    }
    if ((heff_dup(v_t_2480) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_242, 2);
      heff_drop(v_t_2480);
      V v_m_2481 = (g_heff_2ecompile_2eimp_2eatomsOf(v_g_240, v_as_2476));
      return heff_clo_n(g_heff_2ecompile_2eimp_2etailOf_lam2, 1, 1, (V[]){v_m_2481});
    } else {
      heff_drop(v_as_2476);
      heff_drop(v_t_2480);
      return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
    }
  }
  case TAG_EInt: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFloat: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EStr: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EBytes: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFixed: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFloat32: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EAbandon: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFix: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimp_2eopTail(v_g_240, v_e_242));
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eimp_2etailOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2etailOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimp_2etailOf_lam0(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_b_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_m_2418 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_b_2411}));
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_2417}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_n_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      V v_x_2434;
      switch (heff_tag_of(v_x_2416)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_2415_24MkPair, 2);
        v_x_2434 = v_x_2420;
        break;
      }
      case TAG_Cons: {
        switch (heff_tag_of(v_x_2420)) {
        case TAG_TSeq: {
          V v_ss2_2424 = heff_field(v_x_2420, 0);
          V v_t2_2425 = heff_field(v_x_2420, 1);
          heff_take_n(v_x_2420, 3ULL, 2);
          V v_t_2426 = (g_prelude_2e_2b_2b(v_x_2416, v_ss2_2424));
          v_x_2434 = heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_TSeq, 2, (V[]){v_t_2426, v_t2_2425});
          break;
        }
        case TAG_TReturn: {
          v_x_2434 = heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_TSeq, 2, (V[]){v_x_2416, v_x_2420});
          break;
        }
        case TAG_TLoop: {
          v_x_2434 = heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_TSeq, 2, (V[]){v_x_2416, v_x_2420});
          break;
        }
        case TAG_TIf: {
          v_x_2434 = heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_TSeq, 2, (V[]){v_x_2416, v_x_2420});
          break;
        }
        case TAG_TCase: {
          v_x_2434 = heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_TSeq, 2, (V[]){v_x_2416, v_x_2420});
          break;
        }
        default: heff_nomatch(v_x_2420);
        }
        break;
      }
      default: heff_nomatch(v_x_2416);
      }
      return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2434, v_n_2421});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eimp_2etailOf_lam1(V self, V *args) {
  V v_n_2461 = args[0];
  V v_m_2460 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_s_2444 = heff_env(self)[3];
  V v_t_2454 = heff_env(self)[4];
  V v_f_2455 = heff_env(self)[5];
  V v_arms_2445 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2462 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_n_2461}));
  V v_x2_2467;
  switch (heff_tag_of(v_x2_2462)) {
  case TAG_MkPair: {
    V v_x_2463 = heff_field(v_x2_2462, 0);
    V v_n_2464 = heff_field(v_x2_2462, 1);
    V v_ru_24x2_2462_24MkPair = heff_take_reuse_n(v_x2_2462, 3ULL, 2);
    V v_x_2466;
    switch (heff_tag_of(v_x_2463)) {
    case TAG_Nothing: {
      v_x_2466 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_c_2465 = heff_field(v_x_2463, 0);
      V v_ru_24x_2463_24Just = heff_take_reuse_n(v_x_2463, 1ULL, 1);
      v_x_2466 = heff_tag_at_n(v_ru_24x_2463_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_OBool, 1, (V[]){v_c_2465})});
      break;
    }
    default: heff_nomatch(v_x_2463);
    }
    v_x2_2467 = heff_tag_at_n(v_ru_24x2_2462_24MkPair, TAG_MkPair, 2, (V[]){v_x_2466, v_n_2464});
    break;
  }
  default: heff_nomatch(v_x2_2462);
  }
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_field(v_x2_2467, 0);
    V v_n_2469 = heff_field(v_x2_2467, 1);
    V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
    switch (heff_tag_of(v_x_2468)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_2467_24MkPair, 2);
      V v_t_2470 = (g_heff_2ecompile_2eimp_2etestTail(v_g_240, v_self_241, v_s_2444, v_t_2454, v_f_2455, v_arms_2445));
      V f_ = v_t_2470;
      args[0] = v_n_2469;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_o_2471 = heff_field(v_x_2468, 0);
      heff_take_n(v_x_2468, 1ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_self_241);
      heff_drop(v_s_2444);
      heff_drop(v_t_2454);
      heff_drop(v_f_2455);
      heff_drop(v_arms_2445);
      return heff_tag_at_n(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_TReturn, 1, (V[]){v_o_2471}), v_n_2469});
    }
    default: return heff_nomatch(v_x_2468);
    }
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2ecompile_2eimp_2etailOf_lam2(V self, V *args) {
  V v_n_2482 = args[0];
  V v_m_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2483 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_n_2482}));
  switch (heff_tag_of(v_x2_2483)) {
  case TAG_MkPair: {
    V v_x_2484 = heff_field(v_x2_2483, 0);
    V v_n_2485 = heff_field(v_x2_2483, 1);
    V v_ru_24x2_2483_24MkPair = heff_take_reuse_n(v_x2_2483, 3ULL, 2);
    V v_ss_2488;
    switch (heff_tag_of(v_x_2484)) {
    case TAG_MkPair: {
      V v_x_2486 = heff_dup(heff_field(v_x_2484, 0));
      v_ss_2488 = v_x_2486;
      break;
    }
    default: heff_nomatch(v_x_2484);
    }
    V v_t_2491;
    switch (heff_tag_of(v_x_2484)) {
    case TAG_MkPair: {
      V v_y_2490 = heff_field(v_x_2484, 1);
      heff_take_n(v_x_2484, 2ULL, 2);
      v_t_2491 = v_y_2490;
      break;
    }
    default: heff_nomatch(v_x_2484);
    }
    V v_t_2492 = heff_tag_n(TAG_TLoop, 1, (V[]){v_t_2491});
    V v_x_24105;
    switch (heff_tag_of(v_ss_2488)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x2_2483_24MkPair, 2);
      v_x_24105 = v_t_2492;
      break;
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_t_2492)) {
      case TAG_TSeq: {
        V v_ss2_2495 = heff_field(v_t_2492, 0);
        V v_t2_2496 = heff_field(v_t_2492, 1);
        heff_take_n(v_t_2492, 3ULL, 2);
        V v_t_2497 = (g_prelude_2e_2b_2b(v_ss_2488, v_ss2_2495));
        v_x_24105 = heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_TSeq, 2, (V[]){v_t_2497, v_t2_2496});
        break;
      }
      case TAG_TReturn: {
        v_x_24105 = heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_TSeq, 2, (V[]){v_ss_2488, v_t_2492});
        break;
      }
      case TAG_TLoop: {
        v_x_24105 = heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_TSeq, 2, (V[]){v_ss_2488, v_t_2492});
        break;
      }
      case TAG_TIf: {
        v_x_24105 = heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_TSeq, 2, (V[]){v_ss_2488, v_t_2492});
        break;
      }
      case TAG_TCase: {
        v_x_24105 = heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_TSeq, 2, (V[]){v_ss_2488, v_t_2492});
        break;
      }
      default: heff_nomatch(v_t_2492);
      }
      break;
    }
    default: heff_nomatch(v_ss_2488);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24105, v_n_2485});
  }
  default: return heff_nomatch(v_x2_2483);
  }
}
Clo g_heff_2ecompile_2eimp_2edefOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2edefOf_entry, 3, 0};

V g_heff_2ecompile_2eimp_2edefOf(V v_g_240, V v_d_241, V v_z_242) {
top: ;
  V v_it_243 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_it_243)) {
  case TAG_EVar: {
    V v_m_245 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_n_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_247})});
      V v_t_2410 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_249});
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_2410, v_n_248});
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  case TAG_EGlobal: {
    V v_m_2412 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
      V v_t_2416 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2414})});
      V v_t_2417 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2416});
      return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2417, v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  case TAG_ELam: {
    V v_xs_2418 = heff_field(v_it_243, 0);
    V v_b_2419 = heff_field(v_it_243, 1);
    V v_ru_24it_243_24ELam = heff_take_reuse_n(v_it_243, 3ULL, 2);
    V v_key_2420 = heff_dup(heff_rfield(v_d_241, 0));
    V v_t_2421 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2418));
    V v_t_2422 = (g_heff_2ecompile_2eimp_2etailSelf(heff_dup(v_key_2420), v_t_2421, v_b_2419));
    V v_t_2424;
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_t_2422);
      V v_t_2423 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2418));
      v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_key__arity, (V[]){v_key_2420, v_t_2423})});
    } else {
      heff_drop(v_key_2420);
      heff_drop(v_t_2422);
      v_t_2424 = NTAG(TAG_Nothing);
    }
    V v_m_2425 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_t_2424, v_b_2419}));
    V v_x2_2426 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_n_2428 = heff_field(v_x2_2426, 1);
      V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
      V v_t_2429 = heff_tag_at_n(v_ru_24it_243_24ELam, TAG_DefFun, 2, (V[]){v_xs_2418, heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2427})});
      V v_t_2430 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2429});
      return heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_n_2428});
    }
    default: return heff_nomatch(v_x2_2426);
    }
  }
  case TAG_EApp: {
    V v_m_2433 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2434 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_MkPair: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      V v_n_2436 = heff_field(v_x2_2434, 1);
      V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
      V v_t_2437 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2435})});
      V v_t_2438 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2437});
      return heff_tag_at_n(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, (V[]){v_t_2438, v_n_2436});
    }
    default: return heff_nomatch(v_x2_2434);
    }
  }
  case TAG_ELet: {
    V v_m_2442 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2443 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_MkPair: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      V v_n_2445 = heff_field(v_x2_2443, 1);
      V v_ru_24x2_2443_24MkPair = heff_take_reuse_n(v_x2_2443, 3ULL, 2);
      V v_t_2446 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2444})});
      V v_t_2447 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2446});
      return heff_tag_at_n(v_ru_24x2_2443_24MkPair, TAG_MkPair, 2, (V[]){v_t_2447, v_n_2445});
    }
    default: return heff_nomatch(v_x2_2443);
    }
  }
  case TAG_ERecord: {
    V v_m_2450 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2451 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_MkPair: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_n_2453 = heff_field(v_x2_2451, 1);
      V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
      V v_t_2454 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2452})});
      V v_t_2455 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2454});
      return heff_tag_at_n(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){v_t_2455, v_n_2453});
    }
    default: return heff_nomatch(v_x2_2451);
    }
  }
  case TAG_EProj: {
    V v_m_2460 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2461 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2461)) {
    case TAG_MkPair: {
      V v_x_2462 = heff_field(v_x2_2461, 0);
      V v_n_2463 = heff_field(v_x2_2461, 1);
      V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
      V v_t_2464 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2462})});
      V v_t_2465 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2464});
      return heff_tag_at_n(v_ru_24x2_2461_24MkPair, TAG_MkPair, 2, (V[]){v_t_2465, v_n_2463});
    }
    default: return heff_nomatch(v_x2_2461);
    }
  }
  case TAG_ETag: {
    V v_m_2468 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2469 = heff_tr(heff_call(v_m_2468, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2469)) {
    case TAG_MkPair: {
      V v_x_2470 = heff_field(v_x2_2469, 0);
      V v_n_2471 = heff_field(v_x2_2469, 1);
      V v_ru_24x2_2469_24MkPair = heff_take_reuse_n(v_x2_2469, 3ULL, 2);
      V v_t_2472 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2470})});
      V v_t_2473 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2472});
      return heff_tag_at_n(v_ru_24x2_2469_24MkPair, TAG_MkPair, 2, (V[]){v_t_2473, v_n_2471});
    }
    default: return heff_nomatch(v_x2_2469);
    }
  }
  case TAG_EMatch: {
    V v_m_2476 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2477 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2477)) {
    case TAG_MkPair: {
      V v_x_2478 = heff_field(v_x2_2477, 0);
      V v_n_2479 = heff_field(v_x2_2477, 1);
      V v_ru_24x2_2477_24MkPair = heff_take_reuse_n(v_x2_2477, 3ULL, 2);
      V v_t_2480 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2478})});
      V v_t_2481 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2480});
      return heff_tag_at_n(v_ru_24x2_2477_24MkPair, TAG_MkPair, 2, (V[]){v_t_2481, v_n_2479});
    }
    default: return heff_nomatch(v_x2_2477);
    }
  }
  case TAG_EPrim: {
    V v_m_2483 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2484 = heff_tr(heff_call(v_m_2483, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2484)) {
    case TAG_MkPair: {
      V v_x_2485 = heff_field(v_x2_2484, 0);
      V v_n_2486 = heff_field(v_x2_2484, 1);
      V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
      V v_t_2487 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2485})});
      V v_t_2488 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2487});
      return heff_tag_at_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, (V[]){v_t_2488, v_n_2486});
    }
    default: return heff_nomatch(v_x2_2484);
    }
  }
  case TAG_EPrimCall: {
    V v_m_2491 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2492 = heff_tr(heff_call(v_m_2491, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2492)) {
    case TAG_MkPair: {
      V v_x_2493 = heff_field(v_x2_2492, 0);
      V v_n_2494 = heff_field(v_x2_2492, 1);
      V v_ru_24x2_2492_24MkPair = heff_take_reuse_n(v_x2_2492, 3ULL, 2);
      V v_t_2495 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2493})});
      V v_t_2496 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2495});
      return heff_tag_at_n(v_ru_24x2_2492_24MkPair, TAG_MkPair, 2, (V[]){v_t_2496, v_n_2494});
    }
    default: return heff_nomatch(v_x2_2492);
    }
  }
  case TAG_ECall: {
    V v_m_2499 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24100 = heff_tr(heff_call(v_m_2499, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24100)) {
    case TAG_MkPair: {
      V v_x_24101 = heff_field(v_x2_24100, 0);
      V v_n_24102 = heff_field(v_x2_24100, 1);
      V v_ru_24x2_24100_24MkPair = heff_take_reuse_n(v_x2_24100, 3ULL, 2);
      V v_t_24103 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24101})});
      V v_t_24104 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24103});
      return heff_tag_at_n(v_ru_24x2_24100_24MkPair, TAG_MkPair, 2, (V[]){v_t_24104, v_n_24102});
    }
    default: return heff_nomatch(v_x2_24100);
    }
  }
  case TAG_EInt: {
    V v_m_24106 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24107 = heff_tr(heff_call(v_m_24106, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24107)) {
    case TAG_MkPair: {
      V v_x_24108 = heff_field(v_x2_24107, 0);
      V v_n_24109 = heff_field(v_x2_24107, 1);
      V v_ru_24x2_24107_24MkPair = heff_take_reuse_n(v_x2_24107, 3ULL, 2);
      V v_t_24110 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24108})});
      V v_t_24111 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24110});
      return heff_tag_at_n(v_ru_24x2_24107_24MkPair, TAG_MkPair, 2, (V[]){v_t_24111, v_n_24109});
    }
    default: return heff_nomatch(v_x2_24107);
    }
  }
  case TAG_EFloat: {
    V v_m_24113 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24114 = heff_tr(heff_call(v_m_24113, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24114)) {
    case TAG_MkPair: {
      V v_x_24115 = heff_field(v_x2_24114, 0);
      V v_n_24116 = heff_field(v_x2_24114, 1);
      V v_ru_24x2_24114_24MkPair = heff_take_reuse_n(v_x2_24114, 3ULL, 2);
      V v_t_24117 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24115})});
      V v_t_24118 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24117});
      return heff_tag_at_n(v_ru_24x2_24114_24MkPair, TAG_MkPair, 2, (V[]){v_t_24118, v_n_24116});
    }
    default: return heff_nomatch(v_x2_24114);
    }
  }
  case TAG_EStr: {
    V v_m_24120 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24121 = heff_tr(heff_call(v_m_24120, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24121)) {
    case TAG_MkPair: {
      V v_x_24122 = heff_field(v_x2_24121, 0);
      V v_n_24123 = heff_field(v_x2_24121, 1);
      V v_ru_24x2_24121_24MkPair = heff_take_reuse_n(v_x2_24121, 3ULL, 2);
      V v_t_24124 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24122})});
      V v_t_24125 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24124});
      return heff_tag_at_n(v_ru_24x2_24121_24MkPair, TAG_MkPair, 2, (V[]){v_t_24125, v_n_24123});
    }
    default: return heff_nomatch(v_x2_24121);
    }
  }
  case TAG_EBytes: {
    V v_m_24127 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24128 = heff_tr(heff_call(v_m_24127, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24128)) {
    case TAG_MkPair: {
      V v_x_24129 = heff_field(v_x2_24128, 0);
      V v_n_24130 = heff_field(v_x2_24128, 1);
      V v_ru_24x2_24128_24MkPair = heff_take_reuse_n(v_x2_24128, 3ULL, 2);
      V v_t_24131 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24129})});
      V v_t_24132 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24131});
      return heff_tag_at_n(v_ru_24x2_24128_24MkPair, TAG_MkPair, 2, (V[]){v_t_24132, v_n_24130});
    }
    default: return heff_nomatch(v_x2_24128);
    }
  }
  case TAG_EFixed: {
    V v_m_24135 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24136 = heff_tr(heff_call(v_m_24135, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24136)) {
    case TAG_MkPair: {
      V v_x_24137 = heff_field(v_x2_24136, 0);
      V v_n_24138 = heff_field(v_x2_24136, 1);
      V v_ru_24x2_24136_24MkPair = heff_take_reuse_n(v_x2_24136, 3ULL, 2);
      V v_t_24139 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24137})});
      V v_t_24140 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24139});
      return heff_tag_at_n(v_ru_24x2_24136_24MkPair, TAG_MkPair, 2, (V[]){v_t_24140, v_n_24138});
    }
    default: return heff_nomatch(v_x2_24136);
    }
  }
  case TAG_EFloat32: {
    V v_m_24142 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24143 = heff_tr(heff_call(v_m_24142, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24143)) {
    case TAG_MkPair: {
      V v_x_24144 = heff_field(v_x2_24143, 0);
      V v_n_24145 = heff_field(v_x2_24143, 1);
      V v_ru_24x2_24143_24MkPair = heff_take_reuse_n(v_x2_24143, 3ULL, 2);
      V v_t_24146 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24144})});
      V v_t_24147 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24146});
      return heff_tag_at_n(v_ru_24x2_24143_24MkPair, TAG_MkPair, 2, (V[]){v_t_24147, v_n_24145});
    }
    default: return heff_nomatch(v_x2_24143);
    }
  }
  case TAG_EAbandon: {
    V v_m_24148 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24149 = heff_tr(heff_call(v_m_24148, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24149)) {
    case TAG_MkPair: {
      V v_x_24150 = heff_field(v_x2_24149, 0);
      V v_n_24151 = heff_field(v_x2_24149, 1);
      V v_ru_24x2_24149_24MkPair = heff_take_reuse_n(v_x2_24149, 3ULL, 2);
      V v_t_24152 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24150})});
      V v_t_24153 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24152});
      return heff_tag_at_n(v_ru_24x2_24149_24MkPair, TAG_MkPair, 2, (V[]){v_t_24153, v_n_24151});
    }
    default: return heff_nomatch(v_x2_24149);
    }
  }
  case TAG_EFix: {
    V v_m_24156 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24157 = heff_tr(heff_call(v_m_24156, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24157)) {
    case TAG_MkPair: {
      V v_x_24158 = heff_field(v_x2_24157, 0);
      V v_n_24159 = heff_field(v_x2_24157, 1);
      V v_ru_24x2_24157_24MkPair = heff_take_reuse_n(v_x2_24157, 3ULL, 2);
      V v_t_24160 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24158})});
      V v_t_24161 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24160});
      return heff_tag_at_n(v_ru_24x2_24157_24MkPair, TAG_MkPair, 2, (V[]){v_t_24161, v_n_24159});
    }
    default: return heff_nomatch(v_x2_24157);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2ecompile_2eimp_2edefOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2edefOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimp_2epartsVal_lam0(V self, V *args);
V g_heff_2ecompile_2eimp_2epartsVal_lam1(V self, V *args);
V g_heff_2ecompile_2eimp_2epartsVal_lam2(V self, V *args);
Clo g_heff_2ecompile_2eimp_2epartsVal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epartsVal_entry, 3, 0};

V g_heff_2ecompile_2eimp_2epartsVal(V v_r_240, V v_v_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SInt: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SFloat: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SStr: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SBytes: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SFloat32: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SPrimFn: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SLam: {
    V v_v2_2414 = heff_dup(heff_field(v_v_241, 1));
    switch (heff_tag_of(v_v2_2414)) {
    case TAG_MkBlock: {
      V v_t_2415 = heff_field(v_v2_2414, 0);
      V v_ru_24v2_2414_24MkBlock = heff_take_reuse_n(v_v2_2414, 1ULL, 1);
      V v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 2, (V[]){v_t_2415, v_acc_242}));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v2_2414_24MkBlock, TAG_PartVal, 1, (V[]){v_v_241}), v_t_2416});
    }
    default: return heff_nomatch(v_v2_2414);
    }
  }
  case TAG_STag: {
    V v_as_2418 = heff_dup(heff_field(v_v_241, 1));
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2418));
    V v_t_2422 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimp_2epartsVal_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_t_2422});
  }
  case TAG_SRec: {
    V v_fs_2423 = heff_dup(heff_field(v_v_241, 0));
    V v_t_2425 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2423));
    V v_t_2428 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimp_2epartsVal_lam1, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_2425; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2425); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_t_2428});
  }
  case TAG_SProj: {
    V v_w_2429 = heff_dup(heff_field(v_v_241, 0));
    V v_t_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 5), 2, (V[]){v_w_2429, v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_t_2433});
  }
  case TAG_SPrim: {
    V v_as_2435 = heff_dup(heff_field(v_v_241, 1));
    V v_t_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2435));
    V v_t_2439 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimp_2epartsVal_lam2, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_2436; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2436); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_t_2439});
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2eimp_2epartsVal_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2epartsVal(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimp_2epartsVal_lam0(V self, V *args) {
  V v_acc_2420 = args[0];
  V v_x_2421 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2421;
  args[1] = v_acc_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimp_2epartsVal_lam1(V self, V *args) {
  V v_acc_2426 = args[0];
  V v_x_2427 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2427;
  args[1] = v_acc_2426;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimp_2epartsVal_lam2(V self, V *args) {
  V v_acc_2437 = args[0];
  V v_x_2438 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2438;
  args[1] = v_acc_2437;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimp_2epartsOp_lam0(V self, V *args);
V g_heff_2ecompile_2eimp_2epartsOp_lam1(V self, V *args);
V g_heff_2ecompile_2eimp_2epartsOp_lam2(V self, V *args);
Clo g_heff_2ecompile_2eimp_2epartsOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epartsOp_entry, 3, 0};

V g_heff_2ecompile_2eimp_2epartsOp(V v_r_240, V v_o_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OSimple: {
    V v_v_243 = heff_dup(heff_field(v_o_241, 0));
    V v_t_244 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 5), 2, (V[]){v_v_243, v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_244});
  }
  case TAG_OCall: {
    V v_as_246 = heff_dup(heff_field(v_o_241, 1));
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_246));
    V v_t_2410 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimp_2epartsOp_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2410});
  }
  case TAG_OApply: {
    V v_f_2411 = heff_dup(heff_field(v_o_241, 0));
    V v_as_2412 = heff_dup(heff_field(v_o_241, 1));
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_2411, v_as_2412})));
    V v_t_2416 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimp_2epartsOp_lam1, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2416});
  }
  case TAG_OPrim: {
    V v_as_2418 = heff_dup(heff_field(v_o_241, 1));
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2418));
    V v_t_2422 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimp_2epartsOp_lam2, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2422});
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_acc_242});
  }
  case TAG_OBool: {
    V v_c_2423 = heff_dup(heff_field(v_o_241, 0));
    V v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 2, (V[]){v_c_2423, v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2424});
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2eimp_2epartsOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2epartsOp(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimp_2epartsOp_lam0(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x_249 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_249;
  args[1] = v_acc_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimp_2epartsOp_lam1(V self, V *args) {
  V v_acc_2414 = args[0];
  V v_x_2415 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2415;
  args[1] = v_acc_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimp_2epartsOp_lam2(V self, V *args) {
  V v_acc_2420 = args[0];
  V v_x_2421 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2421;
  args[1] = v_acc_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimp_2epartsSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimp_2epartsSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epartsSt_entry, 3, 0};

V g_heff_2ecompile_2eimp_2epartsSt(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLet: {
    V v_o_244 = heff_field(v_x2_241, 1);
    return heff_tail(heff_get_n(v_r_240, 1, 5), 2, (V[]){heff_dup(v_o_244), v_acc_242});
  }
  case TAG_SDecl: {
    heff_drop_rec(v_r_240, 5);
    return v_acc_242;
  }
  case TAG_SSet: {
    V v_o_247 = heff_field(v_x2_241, 1);
    return heff_tail(heff_get_n(v_r_240, 1, 5), 2, (V[]){heff_dup(v_o_247), v_acc_242});
  }
  case TAG_SIf: {
    V v_c_248 = heff_field(v_x2_241, 0);
    V v_ts_249 = heff_field(v_x2_241, 1);
    V v_fs_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 3)), 2, (V[]){heff_dup(v_fs_2410), v_acc_242}));
    V v_t_2412 = heff_tr(heff_call(heff_take_field(v_r_240, 3), 2, (V[]){heff_dup(v_ts_249), v_t_2411}));
    return heff_tail(heff_get_n(v_r_240, 2, 5), 2, (V[]){heff_dup(v_c_248), v_t_2412});
  }
  case TAG_SCase: {
    V v_v_2413 = heff_field(v_x2_241, 0);
    V v_arms_2414 = heff_field(v_x2_241, 1);
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2414)));
    V v_t_2421 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimp_2epartsSt_lam0, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_acc_242; V a_2 = v_t_2415; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
    return heff_tail(heff_get_n(v_r_240, 0, 5), 2, (V[]){heff_dup(v_v_2413), v_t_2421});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimp_2epartsSt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimp_2epartsSt(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eimp_2epartsSt_lam0(V self, V *args) {
  V v_acc_2416 = args[0];
  V v_x_2417 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_MkArm: {
    V v_ss_2420 = heff_field(v_x_2417, 2);
    heff_take_n(v_x_2417, 4ULL, 3);
    V f_ = heff_get_n(v_r_240, 3, 5);
    args[0] = v_ss_2420;
    args[1] = v_acc_2416;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_x_2417);
  }
}
Clo g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_entry, 2, 0};

V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990(V v_v_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_SVar: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SGlobal: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SStr: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SBytes: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SFixed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SFloat32: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SPrimFn: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SLam: {
    V v_v2_2413 = heff_dup(heff_field(v_v_240, 1));
    switch (heff_tag_of(v_v2_2413)) {
    case TAG_MkBlock: {
      V v_t_2414 = heff_field(v_v2_2413, 0);
      V v_ru_24v2_2413_24MkBlock = heff_take_reuse_n(v_v2_2413, 1ULL, 1);
      V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_acc_241; V r_ = heff_tr(g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(a_0, a_1)); heff_drop(v_t_2414); r_; });
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v2_2413_24MkBlock, TAG_PartVal, 1, (V[]){v_v_240}), v_t_2415});
    }
    default: return heff_nomatch(v_v2_2413);
    }
  }
  case TAG_STag: {
    V v_as_2417 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2417));
    V v_t_2419 = ({ V a_0 = v_acc_241; V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1040186323x1541137667(a_0, a_1)); heff_drop(v_t_2418); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2419});
  }
  case TAG_SRec: {
    V v_fs_2420 = heff_dup(heff_field(v_v_240, 0));
    V v_t_2422 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2420));
    V v_t_2423 = ({ V a_0 = v_acc_241; V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s1040186323x1541137667(a_0, a_1)); heff_drop(v_t_2422); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2423});
  }
  case TAG_SProj: {
    V v_w_2424 = heff_dup(heff_field(v_v_240, 0));
    V v_cell_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), heff_hole()});
    V v_u_2429 = (g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_24dps(v_w_2424, v_acc_241, heff_dup(v_cell_2428)));
    heff_drop(v_u_2429);
    return v_cell_2428;
  }
  case TAG_SPrim: {
    V v_as_2431 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2431));
    V v_t_2433 = ({ V a_0 = v_acc_241; V a_1 = v_t_2432; V r_ = (g_list_2efoldl_24s1040186323x1541137667(a_0, a_1)); heff_drop(v_t_2432); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2433});
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990(a[0], a[1]);
}
Clo g_heff_2ecompile_2eimp_2epartsOp_24s869541283x1897549890_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epartsOp_24s869541283x1897549890_entry, 2, 0};

V g_heff_2ecompile_2eimp_2epartsOp_24s869541283x1897549890(V v_o_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_o_240)) {
  case TAG_OSimple: {
    V v_v_242 = heff_dup(heff_field(v_o_240, 0));
    V v_t_243 = (g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990(v_v_242, v_acc_241));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_243});
  }
  case TAG_OCall: {
    V v_as_245 = heff_dup(heff_field(v_o_240, 1));
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_245));
    V v_t_247 = ({ V a_0 = v_acc_241; V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s1040186323x1541137667(a_0, a_1)); heff_drop(v_t_246); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_247});
  }
  case TAG_OApply: {
    V v_f_248 = heff_dup(heff_field(v_o_240, 0));
    V v_as_249 = heff_dup(heff_field(v_o_240, 1));
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_248, v_as_249})));
    V v_t_2411 = ({ V a_0 = v_acc_241; V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1040186323x1541137667(a_0, a_1)); heff_drop(v_t_2410); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2411});
  }
  case TAG_OPrim: {
    V v_as_2413 = heff_dup(heff_field(v_o_240, 1));
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2413));
    V v_t_2415 = ({ V a_0 = v_acc_241; V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s1040186323x1541137667(a_0, a_1)); heff_drop(v_t_2414); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2415});
  }
  case TAG_OAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_acc_241});
  }
  case TAG_OBool: {
    V v_c_2416 = heff_dup(heff_field(v_o_240, 0));
    V v_t_2417 = ({ V a_0 = v_c_2416; V a_1 = v_acc_241; V r_ = heff_tr(g_heff_2ecompile_2eimp_2epartsCond_24s361583419x1348357017(a_0, a_1)); heff_drop(v_c_2416); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2417});
  }
  default: return heff_nomatch(v_o_240);
  }
}
V g_heff_2ecompile_2eimp_2epartsOp_24s869541283x1897549890_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2epartsOp_24s869541283x1897549890(a[0], a[1]);
}
Clo g_heff_2ecompile_2eimp_2epartsSt_24s1201326915x371226947_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epartsSt_24s1201326915x371226947_entry, 2, 0};

V g_heff_2ecompile_2eimp_2epartsSt_24s1201326915x371226947(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLet: {
    V v_o_243 = heff_field(v_x2_240, 1);
    HEFF_LAST return g_heff_2ecompile_2eimp_2epartsOp_24s869541283x1897549890(heff_dup(v_o_243), v_acc_241);
  }
  case TAG_SDecl: {
    return v_acc_241;
  }
  case TAG_SSet: {
    V v_o_246 = heff_field(v_x2_240, 1);
    HEFF_LAST return g_heff_2ecompile_2eimp_2epartsOp_24s869541283x1897549890(heff_dup(v_o_246), v_acc_241);
  }
  case TAG_SIf: {
    V v_c_247 = heff_field(v_x2_240, 0);
    V v_ts_248 = heff_field(v_x2_240, 1);
    V v_fs_249 = heff_field(v_x2_240, 2);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_249)));
    V v_t_2411 = ({ V a_0 = v_acc_241; V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1156317992x794106048(a_0, a_1)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimp_2epk_get(), 3)), 2, (V[]){heff_dup(v_ts_248), v_t_2411}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimp_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_247), v_t_2412});
  }
  case TAG_SCase: {
    V v_v_2413 = heff_field(v_x2_240, 0);
    V v_arms_2414 = heff_field(v_x2_240, 1);
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2414)));
    V v_t_2416 = ({ V a_0 = v_acc_241; V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s1882202792x677718657(a_0, a_1)); heff_drop(v_t_2415); r_; });
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimp_2epk_get(), 0)), 2, (V[]){heff_dup(v_v_2413), v_t_2416});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimp_2epartsSt_24s1201326915x371226947_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimp_2epartsSt_24s1201326915x371226947(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174_entry, 2, 0};

V g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_TSeq: {
    V v_ss_242 = heff_field(v_x2_240, 0);
    V v_t_243 = heff_field(v_x2_240, 1);
    V v_acc_244 = heff_tr(g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(v_t_243, v_acc_241));
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_242)));
    return ({ V a_0 = v_acc_244; V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1156317992x794106048(a_0, a_1)); heff_drop(v_t_245); r_; });
  }
  case TAG_TReturn: {
    V v_o_246 = heff_field(v_x2_240, 0);
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimp_2epk_get(), 1)), 2, (V[]){heff_dup(v_o_246), v_acc_241});
  }
  case TAG_TLoop: {
    V v_vs_247 = heff_field(v_x2_240, 0);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_247)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s432565707x521643915(a_0, a_1)); heff_drop(v_t_248); r_; });
  }
  case TAG_TIf: {
    V v_c_249 = heff_field(v_x2_240, 0);
    V v_t_2410 = heff_field(v_x2_240, 1);
    V v_e_2411 = heff_field(v_x2_240, 2);
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimp_2epk_get(), 4)), 2, (V[]){heff_dup(v_e_2411), v_acc_241}));
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimp_2epk_get(), 4)), 2, (V[]){heff_dup(v_t_2410), v_t_2412}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimp_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_249), v_t_2413});
  }
  case TAG_TCase: {
    V v_v_2414 = heff_field(v_x2_240, 0);
    V v_arms_2415 = heff_field(v_x2_240, 1);
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2415)));
    V v_t_2417 = ({ V a_0 = v_acc_241; V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s141827321x1562243673(a_0, a_1)); heff_drop(v_t_2416); r_; });
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimp_2epk_get(), 0)), 2, (V[]){heff_dup(v_v_2414), v_t_2417});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimp_2evalNamesTop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2evalNamesTop_entry, 2, 0};

V g_heff_2ecompile_2eimp_2evalNamesTop(V v_v_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_SVar: {
    V v_x_242 = heff_field(v_v_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), v_acc_241});
  }
  case TAG_SGlobal: {
    return v_acc_241;
  }
  case TAG_SInt: {
    return v_acc_241;
  }
  case TAG_SFloat: {
    return v_acc_241;
  }
  case TAG_SStr: {
    return v_acc_241;
  }
  case TAG_SBytes: {
    return v_acc_241;
  }
  case TAG_SFixed: {
    return v_acc_241;
  }
  case TAG_SFloat32: {
    return v_acc_241;
  }
  case TAG_SPrimFn: {
    return v_acc_241;
  }
  case TAG_SLam: {
    return v_acc_241;
  }
  case TAG_STag: {
    V v_as_2415 = heff_field(v_v_240, 1);
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_as_2415)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s71083851x23251329(a_0, a_1)); heff_drop(v_t_2416); r_; });
  }
  case TAG_SRec: {
    V v_fs_2417 = heff_field(v_v_240, 0);
    V v_t_2419 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), heff_dup(v_fs_2417)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s71083851x23251329(a_0, a_1)); heff_drop(v_t_2419); r_; });
  }
  case TAG_SProj: {
    V v_v1_2420 = heff_field(v_v_240, 0);
    V t_0 = v_v1_2420;
    V t_1 = v_acc_241;
    v_v_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_SPrim: {
    V v_as_2425 = heff_field(v_v_240, 1);
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_as_2425)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_2426; V r_ = (g_list_2efoldl_24s71083851x23251329(a_0, a_1)); heff_drop(v_t_2426); r_; });
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2ecompile_2eimp_2evalNamesTop_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimp_2evalNamesTop(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimp_2eopNamesTop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2eopNamesTop_entry, 1, 0};

V g_heff_2ecompile_2eimp_2eopNamesTop(V v_o_240) {
top: ;
  switch (heff_tag_of(v_o_240)) {
  case TAG_OSimple: {
    V v_v_241 = heff_field(v_o_240, 0);
    heff_take_n(v_o_240, 1ULL, 1);
    return ({ V a_0 = v_v_241; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimp_2evalNamesTop(a_0, a_1)); heff_drop(v_v_241); r_; });
  }
  case TAG_OCall: {
    V v_as_243 = heff_field(v_o_240, 1);
    heff_take_n(v_o_240, 2ULL, 2);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_243));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s71083851x23251329(a_0, a_1)); heff_drop(v_t_244); r_; });
  }
  case TAG_OApply: {
    V v_f_245 = heff_field(v_o_240, 0);
    V v_as_246 = heff_field(v_o_240, 1);
    V v_ru_24o_240_24OApply = heff_take_reuse_n(v_o_240, 3ULL, 2);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24o_240_24OApply, TAG_Cons, 2, (V[]){v_f_245, v_as_246})));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s71083851x23251329(a_0, a_1)); heff_drop(v_t_247); r_; });
  }
  case TAG_OPrim: {
    V v_as_249 = heff_field(v_o_240, 1);
    heff_take_n(v_o_240, 2ULL, 2);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_249));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s71083851x23251329(a_0, a_1)); heff_drop(v_t_2410); r_; });
  }
  case TAG_OAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_OBool: {
    heff_take_n(v_o_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_o_240);
  }
}
V g_heff_2ecompile_2eimp_2eopNamesTop_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2eopNamesTop(a[0]);
}
Clo g_heff_2ecompile_2eimp_2efirstNamesTl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2efirstNamesTl_entry, 1, 0};

V g_heff_2ecompile_2eimp_2efirstNamesTl(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_TSeq: {
    V v_t1_241 = heff_field(v_t_240, 0);
    switch (heff_tag_of(v_t1_241)) {
    case TAG_Nil: {
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_st_243 = heff_field(v_t1_241, 0);
      switch (heff_tag_of(v_st_243)) {
      case TAG_SLet: {
        V v_o_246 = heff_field(v_st_243, 1);
        HEFF_LAST return g_heff_2ecompile_2eimp_2eopNamesTop(heff_dup(v_o_246));
      }
      case TAG_SDecl: {
        return NTAG(TAG_Nil);
      }
      case TAG_SSet: {
        V v_o_249 = heff_field(v_st_243, 1);
        HEFF_LAST return g_heff_2ecompile_2eimp_2eopNamesTop(heff_dup(v_o_249));
      }
      case TAG_SIf: {
        return NTAG(TAG_Nil);
      }
      case TAG_SCase: {
        V v_v_2413 = heff_field(v_st_243, 0);
        return (g_heff_2ecompile_2eimp_2evalNamesTop(v_v_2413, NTAG(TAG_Nil)));
      }
      default: return heff_nomatch(v_st_243);
      }
    }
    default: return heff_nomatch(v_t1_241);
    }
  }
  case TAG_TReturn: {
    V v_o_2415 = heff_field(v_t_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eimp_2eopNamesTop(heff_dup(v_o_2415));
  }
  case TAG_TLoop: {
    V v_vs_2416 = heff_field(v_t_240, 0);
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_2416)));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s71083851x23251329(a_0, a_1)); heff_drop(v_t_2417); r_; });
  }
  case TAG_TIf: {
    return NTAG(TAG_Nil);
  }
  case TAG_TCase: {
    V v_v_2421 = heff_field(v_t_240, 0);
    return (g_heff_2ecompile_2eimp_2evalNamesTop(v_v_2421, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2ecompile_2eimp_2efirstNamesTl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimp_2efirstNamesTl(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eimp_2etimesIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimp_2etimesIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2etimesIn_entry, 2, 0};

V g_heff_2ecompile_2eimp_2etimesIn(V v_x_240, V v_ps_241) {
top: ;
  return (g_list_2efoldl_24f1992548173x1980409276(MK_INT(1LL), MK_INT(0LL), heff_clo_n(g_heff_2ecompile_2eimp_2etimesIn_lam0, 1, 1, (V[]){v_x_240}), v_ps_241));
}
V g_heff_2ecompile_2eimp_2etimesIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimp_2etimesIn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eimp_2etimesIn_lam0(V self, V *args) {
  V v_p_242 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_242)) {
  case TAG_PartVal: {
    V v_it1_243 = heff_field(v_p_242, 0);
    heff_take_n(v_p_242, 1ULL, 1);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_SVar: {
      V v_y_244 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      return heff_strEq(v_x_240, v_y_244);
    }
    case TAG_SGlobal: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SInt: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SFloat: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SStr: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SBytes: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SFixed: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SFloat32: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SPrimFn: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SLam: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_STag: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SProj: {
      heff_take_n(v_it1_243, 0ULL, 4);
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SPrim: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  case TAG_PartOp: {
    heff_take_n(v_p_242, 0ULL, 1);
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_p_242);
  }
}