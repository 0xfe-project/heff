// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_absolute 325777132
#define LBL_drive 297211300
#define LBL_segments 1801007612
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_prelude_2e_2b_2b_24f227594336x1851497670(V, V, V);
V g_prelude_2e_2b_2b_24f227594336x1851497670_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f227594336x1851497670_clo;
HeffT2 g_std_2epath_2erelative_2ego_240_24cpr(V, V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameDrive(V, V, V);
V g_std_2epath_2esameDrive_entry(V self, V *a);
extern Clo g_std_2epath_2esameDrive_clo;
HeffT2 g_std_2epath_2eunshared_24cpr(V, V, V);
HEFF_LIT(g_std_2epath_2erelative_2ego_240_24cpr_str0, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_2ego_240_24cpr_str1, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_2ego_240_24cpr_str2, 0, "");
HEFF_LIT(g_std_2epath_2erelative_2ego_240_24cpr_str3, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_2ego_240_24cpr_str4, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_2ego_240_24cpr_str5, 0, "");

HeffT2 g_std_2epath_2erelative_2ego_240_24cpr(V v_st_240, V v_p_241, V v_q_242) {
top: ;
  V v_x1_243 = (g_std_2epath_2esameDrive(v_st_240, heff_rfield(v_p_241, 0), heff_rfield(v_q_242, 0)));
  if ((heff_dup(v_x1_243) == NTAG(TAG_True))) {
    heff_drop(v_x1_243);
    V v_t_244 = heff_take_field(v_p_241, 1);
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = heff_take_field(v_q_242, 1);
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        HeffT2 v_t_246 = (g_std_2epath_2eunshared_24cpr(v_st_240, heff_get_n(v_p_241, 2, 3), heff_get_n(v_q_242, 2, 3)));
        {
          V v_field_247 = v_t_246.f[0];
          V v_field_248 = v_t_246.f[1];
          V v_up_249 = v_field_247;
          V v_down_2410 = v_field_248;
          V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){((V)&g_std_2epath_2erelative_2ego_240_24cpr_str0)}));
          V v_t_2412 = (g_list_2eany(v_t_2411, v_up_249));
          if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
            heff_drop(v_up_249);
            heff_drop(v_down_2410);
            heff_drop(v_t_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          } else {
            heff_drop(v_t_2412);
            V v_t_2413 = (g_prelude_2e_2b_2b_24f227594336x1851497670(v_down_2410, ((V)&g_std_2epath_2erelative_2ego_240_24cpr_str1), v_up_249));
            V v_t_2414 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){((V)&g_std_2epath_2erelative_2ego_240_24cpr_str2), NTAG(TAG_False), v_t_2413});
            V v_f_2415 = (g_std_2epath_2erender(v_st_240, v_t_2414));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
          }
        }
      } else {
        heff_drop_rec(v_p_241, 3);
        heff_drop_rec(v_q_242, 3);
        heff_drop(v_t_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_t_244);
      V v_t_2416 = heff_take_field(v_q_242, 1);
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop_rec(v_p_241, 3);
        heff_drop_rec(v_q_242, 3);
        heff_drop(v_t_2416);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_t_2416);
        HeffT2 v_t_2417 = (g_std_2epath_2eunshared_24cpr(v_st_240, heff_get_n(v_p_241, 2, 3), heff_get_n(v_q_242, 2, 3)));
        {
          V v_field_2418 = v_t_2417.f[0];
          V v_field_2419 = v_t_2417.f[1];
          V v_up_2420 = v_field_2418;
          V v_down_2421 = v_field_2419;
          V v_t_2422 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){((V)&g_std_2epath_2erelative_2ego_240_24cpr_str3)}));
          V v_t_2423 = (g_list_2eany(v_t_2422, v_up_2420));
          if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
            heff_drop(v_up_2420);
            heff_drop(v_down_2421);
            heff_drop(v_t_2423);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          } else {
            heff_drop(v_t_2423);
            V v_t_2424 = (g_prelude_2e_2b_2b_24f227594336x1851497670(v_down_2421, ((V)&g_std_2epath_2erelative_2ego_240_24cpr_str4), v_up_2420));
            V v_t_2425 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){((V)&g_std_2epath_2erelative_2ego_240_24cpr_str5), NTAG(TAG_False), v_t_2424});
            V v_f_2426 = (g_std_2epath_2erender(v_st_240, v_t_2425));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2426}});
          }
        }
      }
    }
  } else {
    heff_drop_rec(v_p_241, 3);
    heff_drop_rec(v_q_242, 3);
    heff_drop(v_x1_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}