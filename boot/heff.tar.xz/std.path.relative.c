// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_absolute 325777132
#define LBL_drive 297211300
#define LBL_segments 1801007612
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_prelude_2eany(V, V);
V g_prelude_2eany_entry(V self, V *a);
extern Clo g_prelude_2eany_clo;
V g_prelude_2econcatList(V, V);
V g_prelude_2econcatList_entry(V self, V *a);
extern Clo g_prelude_2econcatList_clo;
V g_prelude_2emap_24s490045439x1540849353(V, V);
V g_prelude_2emap_24s490045439x1540849353_entry(V self, V *a);
extern Clo g_prelude_2emap_24s490045439x1540849353_clo;
V g_std_2epath_2erelative_2ego_240(V, V, V);
V g_std_2epath_2erelative_2ego_240_entry(V self, V *a);
extern Clo g_std_2epath_2erelative_2ego_240_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameDrive(V, V, V);
V g_std_2epath_2esameDrive_entry(V self, V *a);
extern Clo g_std_2epath_2esameDrive_clo;
V g_std_2epath_2eunshared(V, V, V);
V g_std_2epath_2eunshared_entry(V self, V *a);
extern Clo g_std_2epath_2eunshared_clo;
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2epath_2erelative_2ego_240_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2epath_2erelative_2ego_240_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erelative_2ego_240_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_std_2epath_2erelative_2ego_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2erelative_2ego_240_entry, 3, 0};

V g_std_2epath_2erelative_2ego_240(V v_st_240, V v_p_241, V v_q_242) {
top: ;
  V v_x1_243 = (g_std_2epath_2esameDrive(v_st_240, heff_get(heff_dup(v_p_241), LBL_drive), heff_get(heff_dup(v_q_242), LBL_drive)));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_True: {
    V v_t_244 = heff_get(heff_dup(v_p_241), LBL_absolute);
    V v_t_246;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_t_245 = heff_get(heff_dup(v_q_242), LBL_absolute);
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        v_t_246 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_246 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      break;
    }
    case TAG_False: {
      v_t_246 = heff_get(heff_dup(v_q_242), LBL_absolute);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_p_241);
      heff_drop(v_q_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_247 = (g_std_2epath_2eunshared(v_st_240, heff_get(v_p_241, LBL_segments), heff_get(v_q_242, LBL_segments)));
      switch (heff_tag_of(v_t_247)) {
      case TAG_MkPair: {
        V v_up_248 = heff_field(v_t_247, 0);
        V v_down_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        V v_t_2410 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){((V)&g_std_2epath_2erelative_2ego_240_str0)}));
        V v_t_2411 = (g_prelude_2eany(v_t_2410, v_up_248));
        switch (heff_tag_of(v_t_2411)) {
        case TAG_True: {
          heff_drop(v_up_248);
          heff_drop(v_down_249);
          return NTAG(TAG_Nothing);
        }
        case TAG_False: {
          V v_t_2412 = (g_prelude_2emap_24s490045439x1540849353(((V)&g_std_2epath_2erelative_2ego_240_str1), v_up_248));
          V v_t_2413 = (g_prelude_2econcatList(v_t_2412, v_down_249));
          V v_t_2414 = heff_rec(3, shape_drive__absolute__segments, (V[]){((V)&g_std_2epath_2erelative_2ego_240_str2), NTAG(TAG_False), v_t_2413});
          return heff_tag(TAG_Just, 1, (V[]){(g_std_2epath_2erender(v_st_240, v_t_2414))});
        }
        default: return heff_nomatch(v_t_2411);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_False: {
    heff_drop(v_p_241);
    heff_drop(v_q_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_std_2epath_2erelative_2ego_240_entry(V self, V *a) {
  (void)self;
  V r = g_std_2epath_2erelative_2ego_240(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}