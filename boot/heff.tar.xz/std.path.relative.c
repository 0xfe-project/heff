// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_absolute 325777132
#define LBL_drive 297211300
#define LBL_segments 1801007612
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2emap_24s1445534224x744280941(V, V);
V g_list_2emap_24s1445534224x744280941_entry(V self, V *a);
extern Clo g_list_2emap_24s1445534224x744280941_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2epath_2erelative_2ego_240(V, V, V);
V g_std_2epath_2erelative_2ego_240_entry(V self, V *a);
extern Clo g_std_2epath_2erelative_2ego_240_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameDrive(V, V, V);
V g_std_2epath_2esameDrive_entry(V self, V *a);
extern Clo g_std_2epath_2esameDrive_clo;
V g_std_2epath_2eunshared(V, V, V);
V g_std_2epath_2eunshared_entry(V self, V *a);
extern Clo g_std_2epath_2eunshared_clo;
HEFF_LIT(g_std_2epath_2erelative_2ego_240_str0, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_2ego_240_str1, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_2ego_240_str2, 0, "");
Clo g_std_2epath_2erelative_2ego_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2erelative_2ego_240_entry, 3, 0};

V g_std_2epath_2erelative_2ego_240(V v_st_240, V v_p_241, V v_q_242) {
top: ;
  V v_x1_243 = (g_std_2epath_2esameDrive(v_st_240, heff_take_field(v_p_241, 0), heff_take_field(v_q_242, 0)));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_True: {
    V v_t_244 = heff_take_field(v_p_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_t_245 = heff_dup(heff_rfield(v_q_242, 1));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        v_t_246 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_246 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      break;
    }
    case TAG_False: {
      v_t_246 = heff_dup(heff_rfield(v_q_242, 1));
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop_rec(v_p_241, 3);
      heff_drop_rec(v_q_242, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_247 = (g_std_2epath_2eunshared(v_st_240, heff_get_n(v_p_241, 2, 3), heff_get_n(v_q_242, 2, 3)));
      switch (heff_tag_of(v_t_247)) {
      case TAG_MkPair: {
        V v_up_248 = heff_field(v_t_247, 0);
        V v_down_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        V v_t_2410 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){((V)&g_std_2epath_2erelative_2ego_240_str0)}));
        V v_t_2411 = (g_list_2eany(v_t_2410, v_up_248));
        switch (heff_tag_of(v_t_2411)) {
        case TAG_True: {
          heff_drop(v_up_248);
          heff_drop(v_down_249);
          return NTAG(TAG_Nothing);
        }
        case TAG_False: {
          V v_t_2412 = (g_list_2emap_24s1445534224x744280941(((V)&g_std_2epath_2erelative_2ego_240_str1), v_up_248));
          V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_down_249));
          V v_t_2414 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){((V)&g_std_2epath_2erelative_2ego_240_str2), NTAG(TAG_False), v_t_2413});
          return heff_tag_n(TAG_Just, 1, (V[]){(g_std_2epath_2erender(v_st_240, v_t_2414))});
        }
        default: return heff_nomatch(v_t_2411);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_False: {
    heff_drop_rec(v_p_241, 3);
    heff_drop_rec(v_q_242, 3);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_std_2epath_2erelative_2ego_240_entry(V self, V *a) {
  (void)self;
  V r = g_std_2epath_2erelative_2ego_240(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}