// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_asks 9499105
#define LBL_base 9511832
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipe 1012227257
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_unrolled 706233391
#define LBL_ver 326173
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp, LBL_unrolled};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eallParts(V, V);
V g_heff_2ecompile_2eir_2eallParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallParts_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
HeffT2 g_heff_2ecompile_2eir_2earmFor_24cpr(V, V);
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478_clo;
V g_heff_2ecompile_2esimplify_2eallAsked(V, V);
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eallAsked_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallAsked_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eallPure_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eapartW(V, V);
V g_heff_2ecompile_2esimplify_2eapartW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartW_clo;
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_clo;
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2_clo;
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_clo;
V g_heff_2ecompile_2esimplify_2easkedAs(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkedAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkedAs_clo;
V g_heff_2ecompile_2esimplify_2easkedAs_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkedAs_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkedAs_24tok2_clo;
V g_heff_2ecompile_2esimplify_2eattemptBy_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_24tok2_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V, V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2eenvOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eenvOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eenvOf_clo;
V g_heff_2ecompile_2esimplify_2efieldsBound(V, V);
V g_heff_2ecompile_2esimplify_2efieldsBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldsBound_clo;
V g_heff_2ecompile_2esimplify_2efoldCond(V);
V g_heff_2ecompile_2esimplify_2efoldCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldCond_clo;
V g_heff_2ecompile_2esimplify_2efoldPrim(V, V);
V g_heff_2ecompile_2esimplify_2efoldPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldPrim_clo;
HeffT4 g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596(V, V, V, V);
V g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596_clo;
V g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2efreshNames(V, V, V);
V g_heff_2ecompile_2esimplify_2efreshNames_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshNames_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshNames_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ehandlerArg(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerArg_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652(V, V, V);
V g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eloopBack(V, V, V);
V g_heff_2ecompile_2esimplify_2eloopBack_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eloopBack_clo;
V g_heff_2ecompile_2esimplify_2emakeEach(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeEach_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emakeEach_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2emakeOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeOne_clo;
V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637(V, V);
V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2enoKeep_get(void);
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eonceEach_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_24dps_clo;
V g_heff_2ecompile_2esimplify_2eparamsAre(V, V);
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo;
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_clo;
V g_heff_2ecompile_2esimplify_2eprunedB(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedB_clo;
V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erecipesWith_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2escrutW(V, V, V);
V g_heff_2ecompile_2esimplify_2escrutW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2escrutW_clo;
V g_heff_2ecompile_2esimplify_2esettleDef(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esettleDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esettleDef_clo;
HeffT2 g_heff_2ecompile_2esimplify_2esettleDef_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2_clo;
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_clo;
V g_heff_2ecompile_2esimplify_2etagBound(V);
V g_heff_2ecompile_2esimplify_2etagBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagBound_clo;
V g_heff_2ecompile_2esimplify_2etagGo(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2etagGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagGo_clo;
V g_heff_2ecompile_2esimplify_2etagMarks(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2etagMarks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagMarks_clo;
V g_heff_2ecompile_2esimplify_2etagMatched(V, V, V);
V g_heff_2ecompile_2esimplify_2etagMatched_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagMatched_clo;
V g_heff_2ecompile_2esimplify_2etagsGiven(V, V, V);
V g_heff_2ecompile_2esimplify_2etagsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagsGiven_clo;
V g_heff_2ecompile_2esimplify_2etestsOf(V, V);
V g_heff_2ecompile_2esimplify_2etestsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etestsOf_clo;
V g_heff_2ecompile_2esimplify_2etoldTo(V, V, V);
V g_heff_2ecompile_2esimplify_2etoldTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etoldTo_clo;
V g_heff_2ecompile_2esimplify_2eunmade(V, V);
V g_heff_2ecompile_2esimplify_2eunmade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunmade_clo;
V g_heff_2ecompile_2esimplify_2eunrollOf(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eunrollOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunrollOf_clo;
V g_heff_2ecompile_2esimplify_2evaluesAt(V, V);
V g_heff_2ecompile_2esimplify_2evaluesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evaluesAt_clo;
HeffT2 g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(V, V);
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1934959195x1899752489(V, V, V, V, V, V, V, V, V, V);
V g_list_2eany_24s1934959195x1899752489_entry(V self, V *a);
extern Clo g_list_2eany_24s1934959195x1899752489_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2eany_24s949890700x388707860(V);
V g_list_2eany_24s949890700x388707860_entry(V self, V *a);
extern Clo g_list_2eany_24s949890700x388707860_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1913417976x1327308136(V, V, V);
V g_list_2efoldl_24s1913417976x1327308136_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1913417976x1327308136_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s183165982x1490920686(V);
V g_list_2ekeepIf_24s183165982x1490920686_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s183165982x1490920686_clo;
V g_list_2ekeepIf_24s423901581x541836270(V, V);
V g_list_2ekeepIf_24s423901581x541836270_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s423901581x541836270_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24s473401207x1960255357(V);
V g_list_2emap_24s473401207x1960255357_entry(V self, V *a);
extern Clo g_list_2emap_24s473401207x1960255357_clo;
V g_list_2emap_24s549405518x243689326(V);
V g_list_2emap_24s549405518x243689326_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_clo;
V g_list_2emap_24s73473062x206541869(V);
V g_list_2emap_24s73473062x206541869_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s528321443x971020870(V, V);
V g_list_2ezipWith_24s528321443x971020870_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s2104983077x351811635(V);
V g_prelude_2etraverse_24s2104983077x351811635_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2104983077x351811635_clo;
V g_prelude_2etraverse_24s962837131x1183228870(V);
V g_prelude_2etraverse_24s962837131x1183228870_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s962837131x1183228870_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;

static V g_heff_2ecompile_2esimplify_2enoKeep_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2enoKeep_st;
static V g_heff_2ecompile_2esimplify_2enoKeep_init(void) {
  return heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())});
}
V g_heff_2ecompile_2esimplify_2enoKeep_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2enoKeep_st)) return g_heff_2ecompile_2esimplify_2enoKeep_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2enoKeep_val, &g_heff_2ecompile_2esimplify_2enoKeep_st, g_heff_2ecompile_2esimplify_2enoKeep_init);
}
Clo g_heff_2ecompile_2esimplify_2evaluesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2evaluesAt_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2evaluesAt(V v_ts_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_EAbandon)});
  }
  default: {
    HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_x_245 = v_field_244;
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_245})});
      } else {
        heff_drop(v_field_244);
        return NTAG(TAG_Nothing);
      }
    }
  }
  }
}
V g_heff_2ecompile_2esimplify_2evaluesAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2evaluesAt(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2eclosedKnown_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2eclosedKnown_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eclosedKnown_lam0, 2, 0};
V g_heff_2ecompile_2esimplify_2eclosedKnown_lam1(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2eclosedKnown_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eclosedKnown_lam1, 2, 0};
Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eclosedKnown_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eclosedKnown(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
    V v_x_246 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_245));
    if (!heff_intLt_c_lent(MK_INT(60LL), v_x_246, 1)) {
      heff_drop(v_x_246);
      return (g_heff_2ecompile_2eir_2eallParts(((V)&g_heff_2ecompile_2esimplify_2eclosedKnown_lam0_clo), heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244})));
    } else {
      heff_drop(v_xs_243);
      heff_drop(v_b_244);
      heff_drop(v_x_246);
      return NTAG(TAG_False);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x1_240, 0);
    V v_ts_2416 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2417 = (g_list_2emap_24s1044393341x1523302351(heff_dup(v_fs_2415)));
    V v_t_2418 = ({ V a_0 = v_t_2417; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2417); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_ERecord, 2, (V[]){heff_dup(v_fs_2415), heff_dup(v_ts_2416)}), NTAG(TAG_Nil)});
      V v_x_2420 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_2419));
      if (!heff_intLt_c_lent(MK_INT(60LL), v_x_2420, 1)) {
        heff_drop(v_x_2420);
        return (g_heff_2ecompile_2eir_2eallParts(((V)&g_heff_2ecompile_2esimplify_2eclosedKnown_lam1_clo), heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_2415, v_ts_2416})));
      } else {
        heff_drop(v_fs_2415);
        heff_drop(v_ts_2416);
        heff_drop(v_x_2420);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_fs_2415);
      heff_drop(v_ts_2416);
      heff_drop_cell(v_ru_24x1_240_24ERecord, 2);
      heff_drop(v_t_2418);
      return NTAG(TAG_False);
    }
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eclosedKnown(a[0]);
}
V g_heff_2ecompile_2esimplify_2eclosedKnown_lam0(V self, V *args) {
  V v_xs_247 = args[0];
  V v_p_248 = args[1];
  V v_t_249 = (g_heff_2ecompile_2eir_2eappendI(v_xs_247, NTAG(TAG_Nil)));
  return (g_heff_2ecompile_2espec_2eclosedIn(v_t_249, v_p_248));
}
V g_heff_2ecompile_2esimplify_2eclosedKnown_lam1(V self, V *args) {
  V v_xs_2421 = args[0];
  V v_p_2422 = args[1];
  V v_t_2423 = (g_heff_2ecompile_2eir_2eappendI(v_xs_2421, NTAG(TAG_Nil)));
  return (g_heff_2ecompile_2espec_2eclosedIn(v_t_2423, v_p_2422));
}
Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandlerLike_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ehandlerLike(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    V v_ts_2411 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_fs_2410)) {
    case TAG_Nil: {
      heff_drop(v_ts_2411);
      heff_drop_cell(v_ru_24x1_240_24ERecord, 2);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_t_2414 = (g_list_2emap_24s549405518x243689326(heff_dup(v_fs_2410)));
      V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2414); r_; });
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_ERecord, 2, (V[]){v_fs_2410, v_ts_2411}), NTAG(TAG_Nil)});
        V v_x_2417 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_2416));
        V v_ret_24bool = heff_bool(!heff_intLt_c_lent(MK_INT(60LL), v_x_2417, 1));
        heff_drop(v_x_2417);
        return v_ret_24bool;
      } else {
        heff_drop_tag(v_fs_2410, 2);
        heff_drop(v_ts_2411);
        heff_drop_cell(v_ru_24x1_240_24ERecord, 2);
        heff_drop(v_t_2415);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_fs_2410);
    }
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ehandlerLike(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2ehandlerArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandlerArg_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ehandlerArg(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_244 = ({ V a_0 = v_kinds_240; V a_1 = v_g_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_g_243); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_245 == ((int64_t)0ULL)) && ({ V v_x_247 = heff_dup(v_field_246); int c_ = 1; heff_drop(v_x_247); c_; })));
      heff_drop(v_field_246);
      return v_ret_24bool;
    }
  }
  case TAG_ELam: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EApp: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ELet: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ERecord: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EProj: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ETag: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EMatch: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EPrim: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EPrimCall: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ECall: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EInt: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EFloat: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EStr: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EBytes: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EFixed: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EFloat32: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EAbandon: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EBool: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ESet: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EValues: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EFix: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2ehandlerArg_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ehandlerArg(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2escrutW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2escrutW_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2escrutW(V v_x_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EMatch: {
      V v_sc_245 = heff_field(v_x31_243, 0);
      V v_arms_246 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2446;
      switch (heff_tag_of(v_sc_245)) {
      case TAG_EVar: {
        V v_y_247 = heff_dup(heff_field(v_sc_245, 0));
        if (heff_strEq_c_lent(v_x_240, v_y_247, 2)) {
          v_t_2446 = heff_intAdd(v_n_241, MK_INT(1LL));
        } else {
          v_t_2446 = v_n_241;
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_ELam: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EApp: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_ELet: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_ERecord: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EProj: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_ETag: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EMatch: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EPrim: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_ECall: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EInt: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EFloat: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EStr: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EBytes: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EFixed: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EFloat32: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EAbandon: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EBool: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_ESet: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EValues: {
        v_t_2446 = v_n_241;
        break;
      }
      case TAG_EFix: {
        v_t_2446 = v_n_241;
        break;
      }
      default: heff_nomatch(v_sc_245);
      }
      V v_t_2447 = (g_heff_2ecompile_2eir_2epushArms(v_arms_246, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_t_2446;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_sc_245, v_t_2447});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2448 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2449 = (g_heff_2ecompile_2esimplify_2etestsOf(v_x_240, v_c_2448));
      V v_t_2450 = ({ V a_0 = v_c_2448; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2448); r_; });
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_n_241, v_t_2449);
      V t_2 = v_t_2450;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2451 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2451;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2escrutW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2escrutW(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2etagBound_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etagBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etagBound_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2etagBound(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_ETag: {
    V v_t_241 = heff_field(v_e_240, 0);
    V v_argv_242 = heff_field(v_e_240, 1);
    V v_ts_243 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_244 = (g_heff_2ecompile_2esimplify_2efieldsBound(((V)&g_heff_2ecompile_2esimplify_2etagBound_clo), v_argv_242));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam0, 1, 3, (V[]){v_m_244, v_t_241, v_ts_243});
  }
  default: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam1, 1, 1, (V[]){v_e_240});
  }
  }
}
V g_heff_2ecompile_2esimplify_2etagBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etagBound(a[0]);
}
V g_heff_2ecompile_2esimplify_2etagBound_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_ts_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_249 = heff_dup(heff_field(v_x_247, 0));
      v_t_2411 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_y_2413 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_t_2414 = v_y_2413;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2415 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_2411, heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_t_2414, v_ts_243})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2esimplify_2etagBound_lam1(V self, V *args) {
  V v_s_2416 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_s_2416});
}
Clo g_heff_2ecompile_2esimplify_2eprunedB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprunedB_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eprunedB(V v_lim_240, V v_known_241, V v_box_24n_242, V v_x4_243) {
  int64_t v_n_242 = heff_unbox_word(v_box_24n_242);
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_lim_240);
    heff_drop(v_known_241);
    return heff_box_word(v_n_242);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    if (heff_intLt_c_lent(v_lim_240, heff_box_word(v_n_242), 2)) {
      heff_drop(v_lim_240);
      heff_drop(v_known_241);
      heff_drop(v_e_244);
      heff_drop(v_rest_245);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      return heff_box_word(v_n_242);
    } else {
      V v_known_246 = heff_dup(v_known_241);
      V v_x2_247 = heff_dup(v_e_244);
      V v_it_24137;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_EVar: {
        heff_take_n(v_x2_247, 0ULL, 1);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x2_247, 0ULL, 1);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x2_247, 0ULL, 2);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x2_247, 0ULL, 2);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x2_247, 0ULL, 3);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x2_247, 0ULL, 2);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x2_247, 0ULL, 4);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x2_247, 0ULL, 3);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EMatch: {
        V v_sc_2426 = heff_field(v_x2_247, 0);
        V v_arms_2427 = heff_field(v_x2_247, 1);
        V v_ru_24x2_247_24EMatch = heff_take_reuse_n(v_x2_247, 3ULL, 2);
        V v_known_2428 = heff_dup(v_known_246);
        V v_arms_2429 = v_arms_2427;
        V v_x3_2469;
        switch (heff_tag_of(v_sc_2426)) {
        case TAG_EVar: {
          V v_x_2430 = heff_field(v_sc_2426, 0);
          V v_ru_24sc_2426_24EVar = heff_take_reuse_n(v_sc_2426, 1ULL, 1);
          v_x3_2469 = ({ V a_0 = v_ru_24sc_2426_24EVar; V a_1 = v_known_246; V a_2 = v_x_2430; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(a_0, a_1, a_2)); heff_drop(v_known_246); heff_drop(v_x_2430); r_; });
          break;
        }
        case TAG_EGlobal: {
          heff_take_n(v_sc_2426, 0ULL, 1);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ELam: {
          heff_take_n(v_sc_2426, 0ULL, 2);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EApp: {
          heff_take_n(v_sc_2426, 0ULL, 2);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ELet: {
          heff_take_n(v_sc_2426, 0ULL, 3);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ERecord: {
          heff_take_n(v_sc_2426, 0ULL, 2);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EProj: {
          heff_take_n(v_sc_2426, 0ULL, 4);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ETag: {
          heff_take_n(v_sc_2426, 0ULL, 3);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EMatch: {
          heff_take_n(v_sc_2426, 0ULL, 2);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EPrim: {
          heff_take_n(v_sc_2426, 0ULL, 1);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EPrimCall: {
          heff_take_n(v_sc_2426, 0ULL, 2);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ECall: {
          heff_take_n(v_sc_2426, 0ULL, 2);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EInt: {
          heff_take_n(v_sc_2426, 0ULL, 1);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EFloat: {
          heff_take_nf(v_sc_2426, 0ULL, 1);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EStr: {
          heff_take_n(v_sc_2426, 0ULL, 1);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EBytes: {
          heff_take_n(v_sc_2426, 0ULL, 1);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EFixed: {
          heff_take_n(v_sc_2426, 0ULL, 2);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EFloat32: {
          heff_take_na(v_sc_2426, 0ULL, 1);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EAbandon: {
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EBool: {
          heff_take_n(v_sc_2426, 0ULL, 1);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ESet: {
          heff_take_n(v_sc_2426, 0ULL, 3);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EValues: {
          heff_take_n(v_sc_2426, 0ULL, 1);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EFix: {
          heff_take_n(v_sc_2426, 0ULL, 2);
          heff_drop(v_known_246);
          v_x3_2469 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_sc_2426);
        }
        switch (heff_tag_of(v_x3_2469)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
          heff_drop(v_known_2428);
          heff_drop(v_arms_2429);
          v_it_24137 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x31_2470 = heff_field(v_x3_2469, 0);
          V v_ru_24x3_2469_24Just = heff_take_reuse_n(v_x3_2469, 1ULL, 1);
          switch (heff_tag_of(v_x31_2470)) {
          case TAG_EVar: {
            heff_take_n(v_x31_2470, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EGlobal: {
            heff_take_n(v_x31_2470, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ELam: {
            heff_take_n(v_x31_2470, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EApp: {
            heff_take_n(v_x31_2470, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ELet: {
            heff_take_n(v_x31_2470, 0ULL, 3);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ERecord: {
            heff_take_n(v_x31_2470, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EProj: {
            heff_take_n(v_x31_2470, 0ULL, 4);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ETag: {
            V v_t_2486 = heff_field(v_x31_2470, 0);
            V v_argv_2487 = heff_field(v_x31_2470, 1);
            heff_take_n(v_x31_2470, 3ULL, 3);
            HeffT2 v_t_2489 = ({ V a_0 = v_t_2486; V a_1 = v_arms_2429; HeffT2 r_ = (g_heff_2ecompile_2eir_2earmFor_24cpr(a_0, a_1)); heff_drop(v_t_2486); heff_drop(v_arms_2429); r_; });
            {
              V v_field_2491 = v_t_2489.f[1];
              int64_t v_tag_2490 = ((int64_t)v_t_2489.f[0]);
              if ((v_tag_2490 == ((int64_t)0ULL))) {
                V v_it1_2492 = v_field_2491;
                switch (heff_tag_of(v_it1_2492)) {
                case TAG_MkArm: {
                  V v_vs_2494 = heff_field(v_it1_2492, 1);
                  V v_b_2495 = heff_field(v_it1_2492, 2);
                  heff_take_n(v_it1_2492, 6ULL, 3);
                  V v_t_2496 = ({ V a_0 = v_vs_2494; V a_1 = v_argv_2487; V a_2 = v_known_2428; V r_ = (g_heff_2ecompile_2esimplify_2etagsGiven(a_0, a_1, a_2)); heff_drop(v_vs_2494); heff_drop(v_argv_2487); r_; });
                  v_it_24137 = heff_tag_at_n(v_ru_24x3_2469_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_247_24EMatch, TAG_MkPair, 2, (V[]){v_b_2495, v_t_2496})});
                  break;
                }
                default: heff_nomatch(v_it1_2492);
                }
              } else {
                heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
                heff_drop(v_known_2428);
                heff_drop_cell(v_ru_24x3_2469_24Just, 1);
                heff_drop(v_argv_2487);
                heff_drop(v_field_2491);
                v_it_24137 = NTAG(TAG_Nothing);
              }
            }
            break;
          }
          case TAG_EMatch: {
            heff_take_n(v_x31_2470, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EPrim: {
            heff_take_n(v_x31_2470, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EPrimCall: {
            heff_take_n(v_x31_2470, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ECall: {
            heff_take_n(v_x31_2470, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EInt: {
            heff_take_n(v_x31_2470, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EFloat: {
            heff_take_nf(v_x31_2470, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EStr: {
            heff_take_n(v_x31_2470, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EBytes: {
            heff_take_n(v_x31_2470, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EFixed: {
            heff_take_n(v_x31_2470, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EFloat32: {
            heff_take_na(v_x31_2470, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EAbandon: {
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EBool: {
            heff_take_n(v_x31_2470, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ESet: {
            heff_take_n(v_x31_2470, 0ULL, 3);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EValues: {
            heff_take_n(v_x31_2470, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_EFix: {
            heff_take_n(v_x31_2470, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_247_24EMatch, 2);
            heff_drop(v_known_2428);
            heff_drop(v_arms_2429);
            heff_drop_cell(v_ru_24x3_2469_24Just, 1);
            v_it_24137 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x31_2470);
          }
          break;
        }
        default: heff_nomatch(v_x3_2469);
        }
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x2_247, 0ULL, 1);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x2_247, 0ULL, 2);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x2_247, 0ULL, 2);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x2_247, 0ULL, 1);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_x2_247, 0ULL, 1);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x2_247, 0ULL, 1);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x2_247, 0ULL, 1);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x2_247, 0ULL, 2);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x2_247, 0ULL, 1);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EAbandon: {
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_x2_247, 0ULL, 1);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_x2_247, 0ULL, 3);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_x2_247, 0ULL, 1);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x2_247, 0ULL, 2);
        heff_drop(v_known_246);
        v_it_24137 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      switch (heff_tag_of(v_it_24137)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        V v_t_24138 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_244, v_rest_245));
        V t_0 = v_lim_240;
        V t_1 = v_known_241;
        int64_t t_2 = (v_n_242 + ((int64_t)1ULL));
        V t_3 = v_t_24138;
        v_lim_240 = t_0;
        v_known_241 = t_1;
        v_n_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_Just: {
        V v_it1_24139 = heff_field(v_it_24137, 0);
        heff_take_n(v_it_24137, 1ULL, 1);
        heff_drop(v_known_241);
        heff_drop(v_e_244);
        switch (heff_tag_of(v_it1_24139)) {
        case TAG_MkPair: {
          V v_b_24140 = heff_field(v_it1_24139, 0);
          V v_known2_24141 = heff_field(v_it1_24139, 1);
          heff_take_n(v_it1_24139, 3ULL, 2);
          V t_0 = v_lim_240;
          V t_1 = v_known2_24141;
          int64_t t_2 = (v_n_242 + ((int64_t)1ULL));
          V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_b_24140, v_rest_245});
          v_lim_240 = t_0;
          v_known_241 = t_1;
          v_n_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_it1_24139);
        }
      }
      default: return heff_nomatch(v_it_24137);
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2esimplify_2eprunedB_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprunedB(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2etoldTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etoldTo_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etoldTo(V v_b_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_b_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_b_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x3_242, 0);
      V v_argv_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_2448;
      switch (heff_tag_of(v_a_245)) {
      case TAG_EVar: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_a_245, 0ULL, 3);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_a_245, 0ULL, 2);
        V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)});
        v_t_2448 = ({ V a_0 = v_x_243; V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2esimplify_2eapartW(a_0, a_1)); heff_drop(v_x_243); r_; });
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_a_245, 0ULL, 4);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_a_245, 0ULL, 3);
        V v_t_2426 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)});
        v_t_2448 = ({ V a_0 = v_x_243; V a_1 = v_t_2426; V r_ = (g_heff_2ecompile_2esimplify_2eapartW(a_0, a_1)); heff_drop(v_x_243); r_; });
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_a_245, 0ULL, 3);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
        heff_drop(v_b_240);
        heff_drop(v_xs_244);
        heff_drop(v_argv_246);
        heff_drop(v_t_2448);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2448);
        V t_0 = v_b_240;
        V t_1 = v_xs_244;
        V t_2 = v_argv_246;
        v_b_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etoldTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etoldTo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eunrollOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eunrollOf_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eunrollOf(V v_s_240, V v_g_241, V v_argv_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_240, 10);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EVar: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_x41_244, 0);
      V v_b_248 = heff_field(v_x41_244, 1);
      V v_ru_24x41_244_24ELam = heff_take_reuse_n(v_x41_244, 3ULL, 2);
      V v_x_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
      V v_y_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_247));
      if (heff_intLe_c(v_y_2410, v_x_249)) {
        HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_s_240, 9, 10); V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2415;
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_x_2414 = v_field_2413;
            v_t_2415 = v_x_2414;
          } else {
            heff_drop(v_field_2413);
            v_t_2415 = MK_INT(0LL);
          }
        }
        if (heff_intLt_c(v_t_2415, MK_INT(8LL))) {
          V v_t_2416 = (g_heff_2ecompile_2esimplify_2etagMatched(v_b_248, v_xs_247, v_argv_242));
          if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
            heff_drop(v_t_2416);
            V v_t_2417 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_248)));
            V v_xs_2418 = (g_heff_2ecompile_2eir_2enubI(v_t_2417));
            V v_t_2419 = ({ V a_0 = v_g_241; V a_1 = v_xs_2418; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_2418); r_; });
            if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
              heff_drop(v_t_2419);
              V v_t_2420 = (g_heff_2ecompile_2esimplify_2etagsGiven(v_xs_247, v_argv_242, heff_dup(g_std_2eordmap_2eempty_get())));
              V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_247), heff_dup(v_b_248)}), NTAG(TAG_Nil)});
              V v_x_2422 = (g_heff_2ecompile_2esimplify_2eprunedB(MK_INT(40LL), v_t_2420, MK_INT(0LL), v_t_2421));
              if (!heff_intLt_c_lent(MK_INT(40LL), v_x_2422, 1)) {
                heff_drop(v_x_2422);
                return heff_tag_at_n(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_247, v_b_248})});
              } else {
                heff_drop_cell(v_ru_24x4_243_24Just, 1);
                heff_drop(v_xs_247);
                heff_drop(v_b_248);
                heff_drop(v_x_2422);
                return NTAG(TAG_Nothing);
              }
            } else {
              heff_drop_cell(v_ru_24x4_243_24Just, 1);
              heff_drop(v_xs_247);
              heff_drop(v_b_248);
              heff_drop_cell(v_ru_24x41_244_24ELam, 2);
              heff_drop(v_t_2419);
              return NTAG(TAG_Nothing);
            }
          } else {
            heff_drop_cell(v_ru_24x4_243_24Just, 1);
            heff_drop(v_xs_247);
            heff_drop(v_b_248);
            heff_drop_cell(v_ru_24x41_244_24ELam, 2);
            heff_drop(v_t_2416);
            return NTAG(TAG_Nothing);
          }
        } else {
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop(v_xs_247);
          heff_drop(v_b_248);
          heff_drop_cell(v_ru_24x41_244_24ELam, 2);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_rec(v_s_240, 10);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        heff_drop(v_xs_247);
        heff_drop(v_b_248);
        heff_drop_cell(v_ru_24x41_244_24ELam, 2);
        return NTAG(TAG_Nothing);
      }
    }
    case TAG_EApp: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x41_244, 0ULL, 3);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x41_244, 0ULL, 4);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x41_244, 0ULL, 3);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_nf(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBool: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESet: {
      heff_take_n(v_x41_244, 0ULL, 3);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EValues: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_rec(v_s_240, 10);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2esimplify_2eunrollOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2eunrollOf(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eloopBack_str0, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eloopBack_str1, 2, "$s");
Clo g_heff_2ecompile_2esimplify_2eloopBack_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eloopBack_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eloopBack(V v_all_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_x32_246 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x32_246)) {
    case TAG_EVar: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      V v_x321_2411 = heff_field(v_x32_246, 0);
      V v_argv_2412 = heff_field(v_x32_246, 1);
      switch (heff_tag_of(v_x321_2411)) {
      case TAG_EVar: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        V v_h_2414 = heff_field(v_x321_2411, 0);
        V v_t_2415 = (g_list_2emap_24s473401207x1960255357(heff_dup(v_argv_2412)));
        V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2415); r_; });
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop(v_t_2416);
          V v_t_2417 = (g_heff_2ecompile_2eir_2eappendI(heff_dup(v_argv_2412), NTAG(TAG_Nil)));
          V v_x_2418 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(3LL), v_t_2417));
          if (!heff_intLt_c_lent(MK_INT(60LL), v_x_2418, 1)) {
            heff_drop(v_x_2418);
            HeffT2 v_t_2419 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_all_240, v_h_2414));
            {
              V v_field_2421 = v_t_2419.f[1];
              int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
              if ((v_tag_2420 == ((int64_t)0ULL))) {
                V v_b_2422 = v_field_2421;
                V v_t_2423 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2422));
                V v_t_2424 = (g_heff_2ecompile_2eir_2enubI(v_t_2423));
                return ({ V b_0 = ((V)&g_heff_2ecompile_2esimplify_2eloopBack_str0); V b_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V b_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ecompile_2esimplify_2eloopBack_str1); V a_5 = v_g_241; V b_6 = MK_INT(0LL); V a_7 = MK_INT(0LL); V b_8 = MK_INT(0LL); V a_9 = v_t_2424; V r_ = (g_list_2eany_24s1934959195x1899752489(b_0, b_1, a_2, b_3, b_4, a_5, b_6, a_7, b_8, a_9)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_3); heff_drop(b_4); heff_drop(b_6); heff_drop(b_8); heff_drop(v_t_2424); r_; });
              } else {
                heff_drop(v_g_241);
                heff_drop(v_field_2421);
                return NTAG(TAG_False);
              }
            }
          } else {
            heff_drop(v_g_241);
            heff_drop(v_x_2418);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop(v_g_241);
          heff_drop(v_t_2416);
          return NTAG(TAG_False);
        }
      }
      case TAG_ELam: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop(v_g_241);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x321_2411);
      }
    }
    case TAG_ELet: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_g_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x32_246);
    }
  }
  case TAG_EApp: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eloopBack_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2eloopBack(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eshapesOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eshapesOf(V v_x1_240, V v_x2_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(v_x1_240, v_x2_241, v_p_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eshapesOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eallAsked_24cpr_str0, 0, "");
V g_heff_2ecompile_2esimplify_2eallAsked_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2eallAsked_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_True), v_p_241}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_h_244 = heff_field(v_x11_242, 0);
      V v_v_245 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24MkPair = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      V v_more_246 = ((V)&g_heff_2ecompile_2esimplify_2eallAsked_clo);
      V v_h_247 = v_h_244;
      V v_v_248 = v_v_245;
      V v_s_249 = v_p_241;
      V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_s_249, 7)), 2, 7);
      HeffT2 v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_h_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_x2_2447;
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x11_242_24MkPair, 2);
          heff_drop(v_more_246);
          heff_drop(v_h_247);
          heff_drop(v_v_248);
          V v_x_2414 = v_field_2413;
          heff_drop(v_x_2414);
          v_x2_2447 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_249});
        } else {
          heff_drop(v_field_2413);
          V v_k_2415 = heff_take_field(v_s_249, 8);
          V v_t_2416 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_k_2415, 0), heff_dup(v_h_247), v_v_248));
          V v_k_2417 = ({ V rv_0 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_k_2415, 30ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_more_2418 = v_more_246;
          V v_h_2419 = v_h_247;
          V v_s_2420 = ({ V rv_8 = v_k_2417; V rr_ = heff_rec_reuse_nf(v_s_249, 767ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 851967u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
          V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_s_2420, 8)), 0, 5);
          HeffT2 v_t_2422 = ({ V a_0 = v_t_2421; V a_1 = v_h_2419; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2421); r_; });
          {
            V v_field_2424 = v_t_2422.f[1];
            int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
            if ((v_tag_2423 == ((int64_t)0ULL))) {
              V v_v_2425 = v_field_2424;
              V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_s_2420, 8)), 1, 5);
              HeffT2 v_t_2427 = ({ V a_0 = v_t_2426; V a_1 = v_h_2419; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2426); r_; });
              {
                V v_field_2429 = v_t_2427.f[1];
                int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
                if ((v_tag_2428 == ((int64_t)0ULL))) {
                  V v_kc_2430 = v_field_2429;
                  if ((heff_strEq_c(heff_dup(heff_rfield(v_kc_2430, 0)), heff_dup(v_v_2425)) && !heff_strEq_c_lent(v_v_2425, ((V)&g_heff_2ecompile_2esimplify_2eallAsked_24cpr_str0), 2))) {
                    heff_drop(v_v_2425);
                    V v_more_2431 = v_more_2418;
                    V v_h_2432 = v_h_2419;
                    V v_kc_2433 = heff_dup(v_kc_2430);
                    V v_x4_2434 = heff_tr(heff_call(heff_get_n(v_kc_2430, 1, 6), 1, (V[]){NTAG(TAG_MkUnit)}));
                    V v_p_2435 = v_s_2420;
                    switch (heff_tag_of(v_x4_2434)) {
                    case TAG_Nothing: {
                      heff_drop_cell(v_ru_24x11_242_24MkPair, 2);
                      heff_drop(v_more_2431);
                      heff_drop(v_h_2432);
                      heff_drop_rec(v_kc_2433, 6);
                      v_x2_2447 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_p_2435});
                      break;
                    }
                    case TAG_Just: {
                      V v_b_2436 = heff_field(v_x4_2434, 0);
                      heff_take_n(v_x4_2434, 1ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
                      HeffT2 v_t_2438 = (g_heff_2ecompile_2esimplify_2erecipesWith_24cpr(heff_clo_n(g_heff_2ecompile_2esimplify_2eallAsked_24cpr_lam0, 1, 2, (V[]){heff_dup(v_h_2432), heff_dup(v_b_2436)}), v_p_2435));
                      {
                        V v_field_2439 = v_t_2438.f[0];
                        V v_field_2440 = v_t_2438.f[1];
                        V v_x_2441 = v_field_2439;
                        heff_drop(v_x_2441);
                        V v_s_2442 = v_field_2440;
                        V v_m_2443 = heff_tr(heff_call(v_more_2431, 1, (V[]){heff_dup(heff_rfield(v_kc_2433, 2))}));
                        V v_x2_2444 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_s_2442}));
                        switch (heff_tag_of(v_x2_2444)) {
                        case TAG_MkPair: {
                          V v_x_2445 = heff_field(v_x2_2444, 0);
                          V v_s_2446 = heff_field(v_x2_2444, 1);
                          heff_take_n(v_x2_2444, 3ULL, 2);
                          v_x2_2447 = ({ V a_0 = v_ru_24x11_242_24MkPair; V a_1 = v_h_2432; V a_2 = v_kc_2433; V a_3 = v_b_2436; V a_4 = v_x_2445; V a_5 = v_s_2446; V r_ = (g_heff_2ecompile_2esimplify_2easkedAs_24tok2(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2445); r_; });
                          break;
                        }
                        default: heff_nomatch(v_x2_2444);
                        }
                      }
                      break;
                    }
                    default: heff_nomatch(v_x4_2434);
                    }
                  } else {
                    heff_drop_cell(v_ru_24x11_242_24MkPair, 2);
                    heff_drop(v_more_2418);
                    heff_drop(v_h_2419);
                    heff_drop(v_v_2425);
                    heff_drop_rec(v_kc_2430, 6);
                    v_x2_2447 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2420});
                  }
                } else {
                  heff_drop_cell(v_ru_24x11_242_24MkPair, 2);
                  heff_drop(v_more_2418);
                  heff_drop(v_h_2419);
                  heff_drop(v_v_2425);
                  heff_drop(v_field_2429);
                  v_x2_2447 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2420});
                }
              }
            } else {
              heff_drop_cell(v_ru_24x11_242_24MkPair, 2);
              heff_drop(v_more_2418);
              heff_drop(v_h_2419);
              heff_drop(v_field_2424);
              v_x2_2447 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2420});
            }
          }
        }
      }
      switch (heff_tag_of(v_x2_2447)) {
      case TAG_MkPair: {
        V v_x_2448 = heff_field(v_x2_2447, 0);
        V v_s_2449 = heff_field(v_x2_2447, 1);
        heff_take_n(v_x2_2447, 3ULL, 2);
        if ((heff_dup(v_x_2448) == NTAG(TAG_True))) {
          heff_drop(v_x_2448);
          V t_0 = v_rest_243;
          V t_1 = v_s_2449;
          v_x1_240 = t_0;
          v_p_241 = t_1;
          goto top;
        } else {
          heff_drop(v_rest_243);
          heff_drop(v_x_2448);
          return ((HeffT2){{NTAG(TAG_False), v_s_2449}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2447)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2esimplify_2eallAsked_24cpr_lam0(V self, V *args) {
  V v_m_2437 = args[0];
  V v_h_2432 = heff_env(self)[0];
  V v_b_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_2437, v_h_2432, v_b_2436));
}
Clo g_heff_2ecompile_2esimplify_2etagMarks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etagMarks_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2etagMarks(V v_s_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244) {
top: ;
  V v_t_245 = (g_list_2eany_24s949890700x388707860(v_argv_244));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
    V v_x_247 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(400LL), MK_INT(0LL), v_t_246));
    if (!heff_intLt_c_lent(MK_INT(400LL), v_x_247, 1)) {
      heff_drop(v_x_247);
      V v_t_248 = (g_heff_2ecompile_2esimplify_2eenvOf(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_xs_242), heff_dup(v_argv_244)));
      V v_t_249 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
      V v_xs_2410 = (g_heff_2ecompile_2eir_2enubI(v_t_249));
      V v_t_2411 = ({ V a_0 = v_g_241; V a_1 = v_xs_2410; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_2410); r_; });
      V v_t_2413;
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_t_2412 = (g_heff_2ecompile_2espec_2eusesOf(heff_dup(v_g_241), heff_dup(v_b_243)));
        v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = heff_dup(v_xs_242); V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2estaticGo(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
      } else {
        heff_drop(v_t_2411);
        v_t_2413 = (g_list_2emap_24s73473062x206541869(heff_dup(v_xs_242)));
      }
      return (g_heff_2ecompile_2esimplify_2etagGo(v_s_240, v_g_241, v_t_248, v_b_243, v_t_2413, v_xs_242, v_argv_244, MK_INT(0LL)));
    } else {
      heff_drop(v_s_240);
      heff_drop(v_g_241);
      heff_drop(v_xs_242);
      heff_drop(v_b_243);
      heff_drop(v_argv_244);
      heff_drop(v_x_247);
      return NTAG(TAG_Nil);
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_g_241);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_argv_244);
    heff_drop(v_t_245);
    return NTAG(TAG_Nil);
  }
}
V g_heff_2ecompile_2esimplify_2etagMarks_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etagMarks(a[0], a[1], a[2], a[3], a[4]);
}

HeffT2 g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(V v_k_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    V v_e1_247 = heff_field(v_e_242, 0);
    V v_argv_248 = heff_field(v_e_242, 1);
    switch (heff_tag_of(v_e1_247)) {
    case TAG_EVar: {
      V v_k2_249 = heff_field(v_e1_247, 0);
      if ((heff_strEq_c_lent(v_k_240, v_k2_249, 0) && ({ V v_t_2481 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_248)); int c_ = heff_intEq_c_lent(v_t_2481, v_n_241, 0); heff_drop(v_t_2481); c_; }))) {
        heff_drop(v_n_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){heff_dup(v_argv_248)})}});
      } else {
        heff_drop(v_n_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EGlobal: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_e1_247)}});
    }
  }
  case TAG_ELet: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_EAbandon)}});
  }
  case TAG_EBool: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2efreshNames_24cpr(V v_base_240, V v_n_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
    heff_drop(v_base_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_Nil), v_p_242}});
  } else {
    HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(heff_dup(v_base_240), v_p_242));
    {
      V v_field_244 = v_t_243.f[0];
      V v_field_245 = v_t_243.f[1];
      V v_x_246 = v_field_244;
      V v_s_247 = v_field_245;
      V v_m_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2efreshNames_clo), 2, (V[]){v_base_240, heff_intSub(v_n_241, MK_INT(1LL))}));
      V v_x2_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_247}));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        V v_s_2411 = heff_field(v_x2_249, 1);
        V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_Cons, 2, (V[]){v_x_246, v_x_2410}), v_s_2411}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_249)}});
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314(V v_xs_240, V v_b_241, V v_argv_242) {
top: ;
  V v_a_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
  V v_b_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
  V v_t_245;
  if (heff_intLe_c_lent(v_a_243, v_b_244, 0)) {
    heff_drop(v_b_244);
    v_t_245 = v_a_243;
  } else {
    heff_drop(v_a_243);
    v_t_245 = v_b_244;
  }
  V v_t_246 = (g_list_2etake(v_t_245, heff_dup(v_xs_240)));
  V v_a_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
  V v_b_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
  V v_t_249;
  if (heff_intLe_c_lent(v_a_247, v_b_248, 0)) {
    heff_drop(v_b_248);
    v_t_249 = v_a_247;
  } else {
    heff_drop(v_a_247);
    v_t_249 = v_b_248;
  }
  V v_t_2410 = (g_list_2etake(v_t_249, heff_dup(v_argv_242)));
  V v_t_2411 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_246, v_t_2410));
  V v_x_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
  V v_a_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
  V v_b_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
  V v_t_2415;
  if (heff_intLe_c_lent(v_a_2413, v_b_2414, 0)) {
    heff_drop(v_b_2414);
    v_t_2415 = v_a_2413;
  } else {
    heff_drop(v_a_2413);
    v_t_2415 = v_b_2414;
  }
  V v_t_2420;
  if (heff_intLt_c(v_t_2415, v_x_2412)) {
    V v_a_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
    V v_b_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
    V v_t_2418;
    if (heff_intLe_c_lent(v_a_2416, v_b_2417, 0)) {
      heff_drop(v_b_2417);
      v_t_2418 = v_a_2416;
    } else {
      heff_drop(v_a_2416);
      v_t_2418 = v_b_2417;
    }
    V v_t_2419 = (g_list_2edrop(v_t_2418, v_xs_240));
    v_t_2420 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2419, v_b_241});
  } else {
    v_t_2420 = v_b_241;
  }
  V v_e_2421 = ({ V a_0 = v_t_2411; V a_1 = v_t_2420; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_m_2422 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e_2421));
  return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_lam0, 1, 3, (V[]){v_m_2422, v_xs_240, v_argv_242});
}
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_lam0(V self, V *args) {
  V v_s_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  V v_xs_240 = heff_env(self)[1];
  V v_argv_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_s_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_s_2426 = heff_field(v_x2_2424, 1);
    heff_take_n(v_x2_2424, 3ULL, 2);
    V v_a_2427 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_240; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_240); r_; });
    V v_b_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
    V v_t_2429;
    if (heff_intLe_c_lent(v_a_2427, v_b_2428, 0)) {
      heff_drop(v_b_2428);
      v_t_2429 = v_a_2427;
    } else {
      heff_drop(v_a_2427);
      v_t_2429 = v_b_2428;
    }
    V v_argv_2430 = ({ V a_0 = v_t_2429; V a_1 = v_argv_242; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_argv_242); r_; });
    V v_t_2431 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_x_2425, v_argv_2430));
    V f_ = v_t_2431;
    args[0] = v_s_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596_str0, 1, "k");
Clo g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596(V v_s_240, V v_arms_241, V v_argv_242, V v_s_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596_str0), heff_dup(v_s_243)));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_x_247 = v_field_245;
    V v_s_248 = v_field_246;
    V v_orig_249 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s_240), heff_dup(v_arms_241)}), heff_dup(v_argv_242)));
    HeffT4 v_t_2410 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(heff_dup(v_x_247), heff_dup(v_argv_242)));
    {
      V v_field_2412 = v_t_2410.f[1];
      V v_field_2413 = v_t_2410.f[2];
      V v_field_2414 = v_t_2410.f[3];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        heff_drop(v_argv_242);
        V v_argv2_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_2412, v_field_2413});
        V v_f_2416 = v_field_2414;
        V v_t_2417 = heff_get_n(heff_get_n(v_s_243, 7, 10), 1, 7);
        V v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = v_argv2_2415; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2417); r_; });
        if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
          heff_drop(v_t_2418);
          V v_argv_2419 = (g_list_2ekeepIf_24s423901581x541836270(v_x_247, heff_dup(v_argv2_2415)));
          V v_t_2420 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_argv_2419)));
          V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2420); r_; });
          if (((heff_dup(v_t_2421) == NTAG(TAG_True)) && ({ V v_t_2422 = (g_list_2efoldl_24s1913417976x1327308136(MK_INT(0LL), MK_INT(0LL), heff_dup(v_argv_2419))); int c_ = ({ V v_t_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_241)); int c_ = ({ V v_t_2441 = heff_intMul(heff_dup(v_t_2422), heff_intSub(heff_dup(v_t_2423), MK_INT(1LL))); int c_ = heff_intLe_c_lent(v_t_2441, MK_INT(120LL), 2); heff_drop(v_t_2441); c_; }); heff_drop(v_t_2423); c_; }); heff_drop(v_t_2422); c_; }))) {
            heff_drop(v_argv_2419);
            heff_drop(v_t_2421);
            return ({ V a_0 = v_orig_249; V a_1 = v_x_247; V a_2 = v_f_2416; V a_3 = v_s_240; V a_4 = v_arms_241; V a_5 = v_argv2_2415; V a_6 = v_s_248; V r_ = (g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_247); r_; });
          } else {
            heff_drop(v_s_240);
            heff_drop(v_arms_241);
            heff_drop(v_x_247);
            heff_drop_tag(v_argv2_2415, 2);
            heff_drop(v_f_2416);
            heff_drop(v_argv_2419);
            heff_drop(v_t_2421);
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_orig_249, v_s_248});
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_arms_241);
          heff_drop(v_x_247);
          heff_drop_tag(v_argv2_2415, 2);
          heff_drop(v_f_2416);
          heff_drop(v_t_2418);
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_orig_249, v_s_248});
        }
      } else {
        heff_drop_rec(v_s_243, 10);
        heff_drop(v_x_247);
        heff_drop(v_field_2412);
        heff_drop(v_field_2413);
        heff_drop(v_field_2414);
        V v_orig_2424 = v_orig_249;
        V v_s_2425 = v_s_240;
        V v_arms_2426 = v_arms_241;
        V v_argv_2427 = v_argv_242;
        V v_s_2428 = v_s_248;
        V v_t_2429 = heff_get_n(heff_dup(heff_rfield(v_s_2428, 7)), 1, 7);
        V v_t_2430 = ({ V a_0 = v_t_2429; V a_1 = v_argv_2427; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2429); r_; });
        if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
          heff_drop(v_t_2430);
          V v_argv_2431 = (g_list_2ekeepIf_24s183165982x1490920686(heff_dup(v_argv_2427)));
          V v_t_2432 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_argv_2431)));
          V v_t_2433 = ({ V a_0 = v_t_2432; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2432); r_; });
          if (((heff_dup(v_t_2433) == NTAG(TAG_True)) && ({ V v_t_2434 = (g_list_2efoldl_24s1913417976x1327308136(MK_INT(0LL), MK_INT(0LL), heff_dup(v_argv_2431))); int c_ = ({ V v_t_2435 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2426)); int c_ = ({ V v_t_2442 = heff_intMul(heff_dup(v_t_2434), heff_intSub(heff_dup(v_t_2435), MK_INT(1LL))); int c_ = heff_intLe_c_lent(v_t_2442, MK_INT(120LL), 2); heff_drop(v_t_2442); c_; }); heff_drop(v_t_2435); c_; }); heff_drop(v_t_2434); c_; }))) {
            heff_drop(v_argv_2431);
            heff_drop(v_t_2433);
            HeffT2 v_t_2436 = (g_heff_2ecompile_2esimplify_2eallPure_24cpr(v_argv_2427, v_s_2428));
            {
              V v_field_2437 = v_t_2436.f[0];
              V v_field_2438 = v_t_2436.f[1];
              V v_x_2439 = v_field_2437;
              V v_s_2440 = v_field_2438;
              if ((heff_dup(v_x_2439) == NTAG(TAG_True))) {
                heff_drop(v_orig_2424);
                heff_drop(v_x_2439);
                HEFF_LAST return g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039(v_s_2425, v_arms_2426, v_argv_2427, v_s_2440);
              } else {
                heff_drop(v_s_2425);
                heff_drop(v_arms_2426);
                heff_drop(v_argv_2427);
                heff_drop(v_x_2439);
                return heff_tag_n(TAG_MkPair, 2, (V[]){v_orig_2424, v_s_2440});
              }
            }
          } else {
            heff_drop(v_s_2425);
            heff_drop(v_arms_2426);
            heff_drop(v_argv_2427);
            heff_drop(v_argv_2431);
            heff_drop(v_t_2433);
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_orig_2424, v_s_2428});
          }
        } else {
          heff_drop(v_s_2425);
          heff_drop(v_arms_2426);
          heff_drop(v_argv_2427);
          heff_drop(v_t_2430);
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_orig_2424, v_s_2428});
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_str1, 5, "False");
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam12(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam0, 1, 1, (V[]){v_e_240});
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam1, 1, 1, (V[]){v_g_243});
  }
  case TAG_ELam: {
    V v_xs_2453 = heff_field(v_e_240, 0);
    V v_b_2454 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_m_2455 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_2454));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam2, 1, 2, (V[]){v_m_2455, v_xs_2453});
  }
  case TAG_EApp: {
    V v_e1_24234 = heff_field(v_e_240, 0);
    V v_argv_24235 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_e1_24234)) {
    case TAG_EGlobal: {
      V v_g_24236 = heff_field(v_e1_24234, 0);
      heff_take_n(v_e1_24234, 1ULL, 1);
      V v_m_24237 = (g_prelude_2etraverse_24s2104983077x351811635(v_argv_24235));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam3, 1, 2, (V[]){v_m_24237, v_g_24236});
    }
    case TAG_EApp: {
      V v_e11_24243 = heff_dup(heff_field(v_e1_24234, 0));
      switch (heff_tag_of(v_e11_24243)) {
      case TAG_EGlobal: {
        V v_g_24245 = heff_field(v_e11_24243, 0);
        heff_take_n(v_e11_24243, 1ULL, 1);
        switch (heff_tag_of(v_e1_24234)) {
        case TAG_EApp: {
          V v_bs_24247 = heff_field(v_e1_24234, 1);
          heff_take_n(v_e1_24234, 2ULL, 2);
          return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam4, 1, 3, (V[]){v_g_24245, v_bs_24247, v_argv_24235});
        }
        default: return heff_nomatch(v_e1_24234);
        }
      }
      default: {
        heff_drop(v_e11_24243);
        V v_m_24313 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e1_24234));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam5, 1, 2, (V[]){v_m_24313, v_argv_24235});
      }
      }
    }
    default: {
      V v_m_24323 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e1_24234));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam6, 1, 2, (V[]){v_m_24323, v_argv_24235});
    }
    }
  }
  case TAG_ELet: {
    V v_x_24333 = heff_field(v_e_240, 0);
    V v_e2_27_27_24334 = heff_field(v_e_240, 1);
    V v_b_24335 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_24336 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e2_27_27_24334));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam7, 1, 3, (V[]){v_m_24336, v_x_24333, v_b_24335});
  }
  case TAG_EProj: {
    V v_e2_24342 = heff_field(v_e_240, 0);
    V v_l_24343 = heff_field(v_e_240, 1);
    V v_sh_24344 = heff_field(v_e_240, 2);
    V v_t_24345 = heff_field(v_e_240, 3);
    heff_take_n(v_e_240, 15ULL, 4);
    V v_m_24346 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e2_24342));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam8, 1, 4, (V[]){v_m_24346, v_l_24343, v_sh_24344, v_t_24345});
  }
  case TAG_EMatch: {
    V v_s_24352 = heff_field(v_e_240, 0);
    V v_arms_24353 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_m_24354 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_s_24352));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam9, 1, 2, (V[]){v_m_24354, v_arms_24353});
  }
  case TAG_EPrimCall: {
    V v_p_24364 = heff_field(v_e_240, 0);
    V v_argv_24365 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_m_24366 = (g_prelude_2etraverse_24s2104983077x351811635(v_argv_24365));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam10, 1, 2, (V[]){v_m_24366, v_p_24364});
  }
  case TAG_EBool: {
    V v_c_24372 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V v_m_24373 = (g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914(v_c_24372));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam11, 1, 1, (V[]){v_m_24373});
  }
  case TAG_ESet: {
    V v_xs_24388 = heff_field(v_e_240, 0);
    V v_e2_27_27_24389 = heff_field(v_e_240, 1);
    V v_b_24390 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_24391 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e2_27_27_24389));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam12, 1, 3, (V[]){v_m_24391, v_xs_24388, v_b_24390});
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2etraversePartsM_24s1970010826x1581723478(v_e_240);
  }
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(a[0]);
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_s_242});
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam1(V self, V *args) {
  V v_s_244 = args[0];
  V v_g_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_245 = heff_dup(v_g_243);
  HeffT2 v_t_246 = ({ V a_0 = heff_rfield(v_s_244, 2); V a_1 = v_g_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_243); r_; });
  V v_x_2452;
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x21_249 = v_field_248;
      switch (heff_tag_of(v_x21_249)) {
      case TAG_EGlobal: {
        V v_h_2410 = heff_field(v_x21_249, 0);
        V v_ru_24x21_249_24EGlobal = heff_take_reuse_n(v_x21_249, 1ULL, 1);
        heff_drop(v_g_245);
        v_x_2452 = heff_tag_at_n(v_ru_24x21_249_24EGlobal, TAG_EGlobal, 1, (V[]){v_h_2410});
        break;
      }
      default: {
        V v_e_2411 = heff_dup(v_x21_249);
        V v_t_2451;
        switch (heff_tag_of(v_e_2411)) {
        case TAG_EVar: {
          heff_take_n(v_e_2411, 0ULL, 1);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_EGlobal: {
          heff_take_n(v_e_2411, 0ULL, 1);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_ELam: {
          heff_take_n(v_e_2411, 0ULL, 2);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_EApp: {
          heff_take_n(v_e_2411, 0ULL, 2);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_ELet: {
          heff_take_n(v_e_2411, 0ULL, 3);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_ERecord: {
          heff_take_n(v_e_2411, 0ULL, 2);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_EProj: {
          heff_take_n(v_e_2411, 0ULL, 4);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_ETag: {
          heff_take_n(v_e_2411, 0ULL, 3);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_EMatch: {
          heff_take_n(v_e_2411, 0ULL, 2);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrim: {
          heff_take_n(v_e_2411, 0ULL, 1);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrimCall: {
          heff_take_n(v_e_2411, 0ULL, 2);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_ECall: {
          heff_take_n(v_e_2411, 0ULL, 2);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_EInt: {
          V v_i_2437 = heff_field(v_e_2411, 0);
          heff_take_n(v_e_2411, 1ULL, 1);
          v_t_2451 = heff_bool((heff_intLt_c_lent(v_i_2437, HEFF_BIG("4611686018427387904"), 2) && heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_i_2437, 1)));
          heff_drop(v_i_2437);
          break;
        }
        case TAG_EFloat: {
          heff_take_nf(v_e_2411, 0ULL, 1);
          v_t_2451 = NTAG(TAG_True);
          break;
        }
        case TAG_EStr: {
          heff_take_n(v_e_2411, 0ULL, 1);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_EBytes: {
          heff_take_n(v_e_2411, 0ULL, 1);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_EFixed: {
          heff_take_n(v_e_2411, 0ULL, 2);
          v_t_2451 = NTAG(TAG_True);
          break;
        }
        case TAG_EFloat32: {
          heff_take_na(v_e_2411, 0ULL, 1);
          v_t_2451 = NTAG(TAG_True);
          break;
        }
        case TAG_EAbandon: {
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_EBool: {
          heff_take_n(v_e_2411, 0ULL, 1);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_ESet: {
          heff_take_n(v_e_2411, 0ULL, 3);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_EValues: {
          heff_take_n(v_e_2411, 0ULL, 1);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        case TAG_EFix: {
          heff_take_n(v_e_2411, 0ULL, 2);
          v_t_2451 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_e_2411);
        }
        if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
          heff_drop(v_g_245);
          heff_drop(v_t_2451);
          v_x_2452 = v_x21_249;
        } else {
          heff_drop(v_x21_249);
          heff_drop(v_t_2451);
          v_x_2452 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_245});
        }
        break;
      }
      }
    } else {
      heff_drop(v_field_248);
      v_x_2452 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_245});
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2452, v_s_244});
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam2(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_xs_2453 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2457 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    V v_kinds_2460 = heff_get_n(heff_dup(heff_rfield(v_s_2459, 7)), 1, 7);
    V v_xs_2461 = v_xs_2453;
    V v_e_2462 = v_x_2458;
    V v_e_24103;
    switch (heff_tag_of(v_e_2462)) {
    case TAG_EVar: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EGlobal: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_ELam: {
      V v_ys_2465 = heff_field(v_e_2462, 0);
      V v_b_2466 = heff_field(v_e_2462, 1);
      V v_ru_24e_2462_24ELam = heff_take_reuse_n(v_e_2462, 3ULL, 2);
      V v_t_2467 = (g_prelude_2e_2b_2b(v_xs_2461, v_ys_2465));
      v_e_24103 = heff_tag_at_n(v_ru_24e_2462_24ELam, TAG_ELam, 2, (V[]){v_t_2467, v_b_2466});
      break;
    }
    case TAG_EApp: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_ELet: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_ERecord: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EProj: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_ETag: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EMatch: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EPrim: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EPrimCall: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_ECall: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EInt: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EFloat: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EStr: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EBytes: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EFixed: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EFloat32: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EAbandon: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EBool: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_ESet: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EValues: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    case TAG_EFix: {
      v_e_24103 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2461, v_e_2462});
      break;
    }
    default: heff_nomatch(v_e_2462);
    }
    V v_x_24233;
    switch (heff_tag_of(v_e_24103)) {
    case TAG_EVar: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EGlobal: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_ELam: {
      V v_e2_24107 = heff_dup(heff_field(v_e_24103, 1));
      switch (heff_tag_of(v_e2_24107)) {
      case TAG_EVar: {
        heff_take_n(v_e2_24107, 0ULL, 1);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_e2_24107, 0ULL, 1);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_e2_24107, 0ULL, 2);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EApp: {
        V v_f_24112 = heff_field(v_e2_24107, 0);
        V v_argv_24113 = heff_field(v_e2_24107, 1);
        V v_ru_24e2_24107_24EApp = heff_take_reuse_n(v_e2_24107, 3ULL, 2);
        switch (heff_tag_of(v_e_24103)) {
        case TAG_ELam: {
          V v_xs_24114 = heff_field(v_e_24103, 0);
          V v_ru_24e_24103_24ELam = heff_take_reuse_n(v_e_24103, 1ULL, 2);
          V v_t_24116 = (g_heff_2ecompile_2esimplify_2eparamsAre(v_xs_24114, v_argv_24113));
          if ((heff_dup(v_t_24116) == NTAG(TAG_True))) {
            heff_drop(v_t_24116);
            V v_kinds_24117 = v_kinds_2460;
            V v_xs_24118 = heff_dup(v_xs_24114);
            V v_x3_24119 = heff_dup(v_f_24112);
            V v_t_24164;
            switch (heff_tag_of(v_x3_24119)) {
            case TAG_EVar: {
              V v_y_24120 = heff_field(v_x3_24119, 0);
              heff_take_n(v_x3_24119, 1ULL, 1);
              heff_drop(v_kinds_24117);
              V v_x1_24121 = ({ V a_0 = v_y_24120; V a_1 = v_xs_24118; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_y_24120); heff_drop(v_xs_24118); r_; });
              v_t_24164 = heff_bool(!(heff_dup(v_x1_24121) == NTAG(TAG_True)));
              heff_drop(v_x1_24121);
              break;
            }
            case TAG_EGlobal: {
              V v_g_24122 = heff_field(v_x3_24119, 0);
              heff_take_n(v_x3_24119, 1ULL, 1);
              heff_drop(v_xs_24118);
              HeffT2 v_t_24123 = ({ V a_0 = v_kinds_24117; V a_1 = v_g_24122; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_kinds_24117); heff_drop(v_g_24122); r_; });
              {
                V v_field_24125 = v_t_24123.f[1];
                int64_t v_tag_24124 = ((int64_t)v_t_24123.f[0]);
                v_t_24164 = heff_bool(((v_tag_24124 == ((int64_t)0ULL)) && ({ V v_x_24126 = heff_dup(v_field_24125); int c_ = 1; heff_drop(v_x_24126); c_; })));
                heff_drop(v_field_24125);
              }
              break;
            }
            case TAG_ELam: {
              heff_take_n(v_x3_24119, 0ULL, 2);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EApp: {
              heff_take_n(v_x3_24119, 0ULL, 2);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_ELet: {
              heff_take_n(v_x3_24119, 0ULL, 3);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_ERecord: {
              heff_take_n(v_x3_24119, 0ULL, 2);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EProj: {
              heff_take_n(v_x3_24119, 0ULL, 4);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_ETag: {
              heff_take_n(v_x3_24119, 0ULL, 3);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EMatch: {
              heff_take_n(v_x3_24119, 0ULL, 2);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EPrim: {
              heff_take_n(v_x3_24119, 0ULL, 1);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EPrimCall: {
              heff_take_n(v_x3_24119, 0ULL, 2);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_ECall: {
              heff_take_n(v_x3_24119, 0ULL, 2);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EInt: {
              heff_take_n(v_x3_24119, 0ULL, 1);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EFloat: {
              heff_take_nf(v_x3_24119, 0ULL, 1);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EStr: {
              heff_take_n(v_x3_24119, 0ULL, 1);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EBytes: {
              heff_take_n(v_x3_24119, 0ULL, 1);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EFixed: {
              heff_take_n(v_x3_24119, 0ULL, 2);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EFloat32: {
              heff_take_na(v_x3_24119, 0ULL, 1);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EAbandon: {
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EBool: {
              heff_take_n(v_x3_24119, 0ULL, 1);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_ESet: {
              heff_take_n(v_x3_24119, 0ULL, 3);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EValues: {
              heff_take_n(v_x3_24119, 0ULL, 1);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            case TAG_EFix: {
              heff_take_n(v_x3_24119, 0ULL, 2);
              heff_drop(v_kinds_24117);
              heff_drop(v_xs_24118);
              v_t_24164 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_x3_24119);
            }
            if ((heff_dup(v_t_24164) == NTAG(TAG_True))) {
              heff_drop(v_argv_24113);
              heff_drop_cell(v_ru_24e2_24107_24EApp, 2);
              heff_drop(v_xs_24114);
              heff_drop_cell(v_ru_24e_24103_24ELam, 2);
              heff_drop(v_t_24164);
              v_x_24233 = v_f_24112;
            } else {
              heff_drop(v_t_24164);
              v_x_24233 = heff_tag_at_n(v_ru_24e_24103_24ELam, TAG_ELam, 2, (V[]){v_xs_24114, heff_tag_at_n(v_ru_24e2_24107_24EApp, TAG_EApp, 2, (V[]){v_f_24112, v_argv_24113})});
            }
          } else {
            heff_drop(v_kinds_2460);
            heff_drop(v_t_24116);
            v_x_24233 = heff_tag_at_n(v_ru_24e_24103_24ELam, TAG_ELam, 2, (V[]){v_xs_24114, heff_tag_at_n(v_ru_24e2_24107_24EApp, TAG_EApp, 2, (V[]){v_f_24112, v_argv_24113})});
          }
          break;
        }
        default: heff_nomatch(v_e_24103);
        }
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_e2_24107, 0ULL, 3);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_e2_24107, 0ULL, 2);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_e2_24107, 0ULL, 4);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_e2_24107, 0ULL, 3);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_e2_24107, 0ULL, 2);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_e2_24107, 0ULL, 1);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_e2_24107, 0ULL, 2);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_e2_24107, 0ULL, 2);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_e2_24107, 0ULL, 1);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_e2_24107, 0ULL, 1);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_e2_24107, 0ULL, 1);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_e2_24107, 0ULL, 1);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_e2_24107, 0ULL, 2);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_e2_24107, 0ULL, 1);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EAbandon: {
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_e2_24107, 0ULL, 1);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_e2_24107, 0ULL, 3);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_e2_24107, 0ULL, 1);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_e2_24107, 0ULL, 2);
        heff_drop(v_kinds_2460);
        v_x_24233 = v_e_24103;
        break;
      }
      default: heff_nomatch(v_e2_24107);
      }
      break;
    }
    case TAG_EApp: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_ELet: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_ERecord: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EProj: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_ETag: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EMatch: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EPrim: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EPrimCall: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_ECall: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EInt: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EFloat: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EStr: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EBytes: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EFixed: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EFloat32: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EBool: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_ESet: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EValues: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    case TAG_EFix: {
      heff_drop(v_kinds_2460);
      v_x_24233 = v_e_24103;
      break;
    }
    default: heff_nomatch(v_e_24103);
    }
    return heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){v_x_24233, v_s_2459});
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam3(V self, V *args) {
  V v_s_24238 = args[0];
  V v_m_24237 = heff_env(self)[0];
  V v_g_24236 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24239 = heff_tr(heff_call(v_m_24237, 1, (V[]){v_s_24238}));
  switch (heff_tag_of(v_x2_24239)) {
  case TAG_MkPair: {
    V v_x_24240 = heff_field(v_x2_24239, 0);
    V v_s_24241 = heff_field(v_x2_24239, 1);
    heff_take_n(v_x2_24239, 3ULL, 2);
    V v_t_24242 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_24236}), v_x_24240));
    V f_ = v_t_24242;
    args[0] = v_s_24241;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24239);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam4(V self, V *args) {
  V v_s_24248 = args[0];
  V v_g_24245 = heff_env(self)[0];
  V v_bs_24247 = heff_env(self)[1];
  V v_argv_24235 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_s_24249 = heff_dup(v_s_24248);
  V v_g_24250 = heff_dup(v_g_24245);
  V v_n_24251 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_24247));
  HeffT2 v_t_24252 = ({ V b_0 = heff_get_n(v_s_24249, 2, 10); V a_1 = v_g_24250; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_g_24250); r_; });
  V v_t_24296;
  {
    V v_field_24254 = v_t_24252.f[1];
    int64_t v_tag_24253 = ((int64_t)v_t_24252.f[0]);
    if ((v_tag_24253 == ((int64_t)0ULL))) {
      V v_it1_24255 = v_field_24254;
      switch (heff_tag_of(v_it1_24255)) {
      case TAG_EVar: {
        heff_take_n(v_it1_24255, 0ULL, 1);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_24255, 0ULL, 1);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        V v_xs_24258 = heff_field(v_it1_24255, 0);
        heff_take_n(v_it1_24255, 1ULL, 2);
        V v_x_24260 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_24258; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_24258); r_; });
        v_t_24296 = heff_bool(heff_intLt_c_lent(v_n_24251, v_x_24260, 0));
        heff_drop(v_n_24251);
        heff_drop(v_x_24260);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_it1_24255, 0ULL, 2);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_it1_24255, 0ULL, 3);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_24255, 0ULL, 2);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_it1_24255, 0ULL, 4);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_it1_24255, 0ULL, 3);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_24255, 0ULL, 2);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_24255, 0ULL, 1);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_24255, 0ULL, 2);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_it1_24255, 0ULL, 2);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_it1_24255, 0ULL, 1);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_it1_24255, 0ULL, 1);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_it1_24255, 0ULL, 1);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_24255, 0ULL, 1);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_24255, 0ULL, 2);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_24255, 0ULL, 1);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_it1_24255, 0ULL, 1);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_it1_24255, 0ULL, 3);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_it1_24255, 0ULL, 1);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_it1_24255, 0ULL, 2);
        heff_drop(v_n_24251);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24255);
      }
    } else {
      heff_drop(v_n_24251);
      heff_drop(v_field_24254);
      v_t_24296 = NTAG(TAG_False);
    }
  }
  if ((heff_dup(v_t_24296) == NTAG(TAG_True))) {
    heff_drop(v_t_24296);
    V v_t_24297 = (g_prelude_2e_2b_2b(v_bs_24247, v_argv_24235));
    V v_e_24298 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_24245}), v_t_24297});
    V v_t_24299 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e_24298));
    V f_ = v_t_24299;
    args[0] = v_s_24248;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_24296);
    V v_m_24300 = (g_prelude_2etraverse_24s2104983077x351811635(v_bs_24247));
    V v_x2_24301 = heff_tr(heff_call(v_m_24300, 1, (V[]){v_s_24248}));
    V v_x2_24305;
    switch (heff_tag_of(v_x2_24301)) {
    case TAG_MkPair: {
      V v_x_24302 = heff_field(v_x2_24301, 0);
      V v_s_24303 = heff_field(v_x2_24301, 1);
      heff_take_n(v_x2_24301, 3ULL, 2);
      V v_t_24304 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_24245}), v_x_24302));
      v_x2_24305 = heff_tr(heff_call(v_t_24304, 1, (V[]){v_s_24303}));
      break;
    }
    default: heff_nomatch(v_x2_24301);
    }
    switch (heff_tag_of(v_x2_24305)) {
    case TAG_MkPair: {
      V v_x_24306 = heff_field(v_x2_24305, 0);
      V v_s_24307 = heff_field(v_x2_24305, 1);
      heff_take_n(v_x2_24305, 3ULL, 2);
      V v_m_24308 = (g_prelude_2etraverse_24s2104983077x351811635(v_argv_24235));
      V v_x2_24309 = heff_tr(heff_call(v_m_24308, 1, (V[]){v_s_24307}));
      switch (heff_tag_of(v_x2_24309)) {
      case TAG_MkPair: {
        V v_x_24310 = heff_field(v_x2_24309, 0);
        V v_s_24311 = heff_field(v_x2_24309, 1);
        heff_take_n(v_x2_24309, 3ULL, 2);
        V v_t_24312 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_x_24306, v_x_24310));
        V f_ = v_t_24312;
        args[0] = v_s_24311;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x2_24309);
      }
    }
    default: return heff_nomatch(v_x2_24305);
    }
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam5(V self, V *args) {
  V v_s_24314 = args[0];
  V v_m_24313 = heff_env(self)[0];
  V v_argv_24235 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24315 = heff_tr(heff_call(v_m_24313, 1, (V[]){v_s_24314}));
  switch (heff_tag_of(v_x2_24315)) {
  case TAG_MkPair: {
    V v_x_24316 = heff_field(v_x2_24315, 0);
    V v_s_24317 = heff_field(v_x2_24315, 1);
    heff_take_n(v_x2_24315, 3ULL, 2);
    V v_m_24318 = (g_prelude_2etraverse_24s2104983077x351811635(v_argv_24235));
    V v_x2_24319 = heff_tr(heff_call(v_m_24318, 1, (V[]){v_s_24317}));
    switch (heff_tag_of(v_x2_24319)) {
    case TAG_MkPair: {
      V v_x_24320 = heff_field(v_x2_24319, 0);
      V v_s_24321 = heff_field(v_x2_24319, 1);
      heff_take_n(v_x2_24319, 3ULL, 2);
      V v_t_24322 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_x_24316, v_x_24320));
      V f_ = v_t_24322;
      args[0] = v_s_24321;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x2_24319);
    }
  }
  default: return heff_nomatch(v_x2_24315);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam6(V self, V *args) {
  V v_s_24324 = args[0];
  V v_m_24323 = heff_env(self)[0];
  V v_argv_24235 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24325 = heff_tr(heff_call(v_m_24323, 1, (V[]){v_s_24324}));
  switch (heff_tag_of(v_x2_24325)) {
  case TAG_MkPair: {
    V v_x_24326 = heff_field(v_x2_24325, 0);
    V v_s_24327 = heff_field(v_x2_24325, 1);
    heff_take_n(v_x2_24325, 3ULL, 2);
    V v_m_24328 = (g_prelude_2etraverse_24s2104983077x351811635(v_argv_24235));
    V v_x2_24329 = heff_tr(heff_call(v_m_24328, 1, (V[]){v_s_24327}));
    switch (heff_tag_of(v_x2_24329)) {
    case TAG_MkPair: {
      V v_x_24330 = heff_field(v_x2_24329, 0);
      V v_s_24331 = heff_field(v_x2_24329, 1);
      heff_take_n(v_x2_24329, 3ULL, 2);
      V v_t_24332 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_x_24326, v_x_24330));
      V f_ = v_t_24332;
      args[0] = v_s_24331;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x2_24329);
    }
  }
  default: return heff_nomatch(v_x2_24325);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam7(V self, V *args) {
  V v_s_24337 = args[0];
  V v_m_24336 = heff_env(self)[0];
  V v_x_24333 = heff_env(self)[1];
  V v_b_24335 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24338 = heff_tr(heff_call(v_m_24336, 1, (V[]){v_s_24337}));
  switch (heff_tag_of(v_x2_24338)) {
  case TAG_MkPair: {
    V v_x_24339 = heff_field(v_x2_24338, 0);
    V v_s_24340 = heff_field(v_x2_24338, 1);
    heff_take_n(v_x2_24338, 3ULL, 2);
    V v_t_24341 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652(v_x_24333, v_x_24339, v_b_24335));
    V f_ = v_t_24341;
    args[0] = v_s_24340;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24338);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam8(V self, V *args) {
  V v_s_24347 = args[0];
  V v_m_24346 = heff_env(self)[0];
  V v_l_24343 = heff_env(self)[1];
  V v_sh_24344 = heff_env(self)[2];
  V v_t_24345 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24348 = heff_tr(heff_call(v_m_24346, 1, (V[]){v_s_24347}));
  switch (heff_tag_of(v_x2_24348)) {
  case TAG_MkPair: {
    V v_x_24349 = heff_field(v_x2_24348, 0);
    V v_s_24350 = heff_field(v_x2_24348, 1);
    heff_take_n(v_x2_24348, 3ULL, 2);
    V v_t_24351 = (g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995(v_l_24343, v_sh_24344, v_t_24345, v_x_24349));
    V f_ = v_t_24351;
    args[0] = v_s_24350;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24348);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam9(V self, V *args) {
  V v_s_24355 = args[0];
  V v_m_24354 = heff_env(self)[0];
  V v_arms_24353 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24356 = heff_tr(heff_call(v_m_24354, 1, (V[]){v_s_24355}));
  switch (heff_tag_of(v_x2_24356)) {
  case TAG_MkPair: {
    V v_x_24357 = heff_field(v_x2_24356, 0);
    V v_s_24358 = heff_field(v_x2_24356, 1);
    heff_take_n(v_x2_24356, 3ULL, 2);
    V v_m_24359 = (g_prelude_2etraverse_24s962837131x1183228870(v_arms_24353));
    V v_x2_24360 = heff_tr(heff_call(v_m_24359, 1, (V[]){v_s_24358}));
    switch (heff_tag_of(v_x2_24360)) {
    case TAG_MkPair: {
      V v_x_24361 = heff_field(v_x2_24360, 0);
      V v_s_24362 = heff_field(v_x2_24360, 1);
      heff_take_n(v_x2_24360, 3ULL, 2);
      V v_t_24363 = (g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637(v_x_24357, v_x_24361));
      V f_ = v_t_24363;
      args[0] = v_s_24362;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x2_24360);
    }
  }
  default: return heff_nomatch(v_x2_24356);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam10(V self, V *args) {
  V v_s_24367 = args[0];
  V v_m_24366 = heff_env(self)[0];
  V v_p_24364 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24368 = heff_tr(heff_call(v_m_24366, 1, (V[]){v_s_24367}));
  switch (heff_tag_of(v_x2_24368)) {
  case TAG_MkPair: {
    V v_x_24369 = heff_field(v_x2_24368, 0);
    V v_s_24370 = heff_field(v_x2_24368, 1);
    V v_ru_24x2_24368_24MkPair = heff_take_reuse_n(v_x2_24368, 3ULL, 2);
    V v_x_24371 = (g_heff_2ecompile_2esimplify_2efoldPrim(v_p_24364, v_x_24369));
    return heff_tag_at_n(v_ru_24x2_24368_24MkPair, TAG_MkPair, 2, (V[]){v_x_24371, v_s_24370});
  }
  default: return heff_nomatch(v_x2_24368);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam11(V self, V *args) {
  V v_s_24374 = args[0];
  V v_m_24373 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24375 = heff_tr(heff_call(v_m_24373, 1, (V[]){v_s_24374}));
  switch (heff_tag_of(v_x2_24375)) {
  case TAG_MkPair: {
    V v_x_24376 = heff_field(v_x2_24375, 0);
    V v_s_24377 = heff_field(v_x2_24375, 1);
    V v_ru_24x2_24375_24MkPair = heff_take_reuse_n(v_x2_24375, 3ULL, 2);
    V v_c_24378 = (g_heff_2ecompile_2esimplify_2efoldCond(v_x_24376));
    V v_t_24387;
    switch (heff_tag_of(v_c_24378)) {
    case TAG_CTrue: {
      v_t_24387 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_str0), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    case TAG_CFalse: {
      v_t_24387 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_str1), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    case TAG_CRel: {
      v_t_24387 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_24378});
      break;
    }
    case TAG_CTest: {
      V v_e_24382 = heff_field(v_c_24378, 0);
      heff_take_n(v_c_24378, 1ULL, 1);
      v_t_24387 = v_e_24382;
      break;
    }
    case TAG_CNot: {
      v_t_24387 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_24378});
      break;
    }
    case TAG_CIf: {
      v_t_24387 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_24378});
      break;
    }
    default: heff_nomatch(v_c_24378);
    }
    return heff_tag_at_n(v_ru_24x2_24375_24MkPair, TAG_MkPair, 2, (V[]){v_t_24387, v_s_24377});
  }
  default: return heff_nomatch(v_x2_24375);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_lam12(V self, V *args) {
  V v_s_24392 = args[0];
  V v_m_24391 = heff_env(self)[0];
  V v_xs_24388 = heff_env(self)[1];
  V v_b_24390 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24393 = heff_tr(heff_call(v_m_24391, 1, (V[]){v_s_24392}));
  switch (heff_tag_of(v_x2_24393)) {
  case TAG_MkPair: {
    V v_x_24394 = heff_field(v_x2_24393, 0);
    V v_s_24395 = heff_field(v_x2_24393, 1);
    V v_ru_24x2_24393_24MkPair = heff_take_reuse_n(v_x2_24393, 3ULL, 2);
    switch (heff_tag_of(v_x_24394)) {
    case TAG_EValues: {
      V v_es_24396 = heff_field(v_x_24394, 0);
      heff_take_n(v_x_24394, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_24393_24MkPair, 2);
      V v_t_24397 = (g_list_2ezipWith_24s1876717925x1404326288(v_xs_24388, v_es_24396));
      V v_e_24398 = ({ V a_0 = v_t_24397; V a_1 = v_b_24390; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_24397); r_; });
      V v_t_24399 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e_24398));
      V f_ = v_t_24399;
      args[0] = v_s_24395;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: {
      V v_m_24400 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_24390));
      V v_x2_24401 = heff_tr(heff_call(v_m_24400, 1, (V[]){v_s_24395}));
      switch (heff_tag_of(v_x2_24401)) {
      case TAG_MkPair: {
        V v_x_24402 = heff_field(v_x2_24401, 0);
        V v_s_24403 = heff_field(v_x2_24401, 1);
        heff_take_n(v_x2_24401, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24393_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24388, v_x_24394, v_x_24402}), v_s_24403});
      }
      default: return heff_nomatch(v_x2_24401);
      }
    }
    }
  }
  default: return heff_nomatch(v_x2_24393);
  }
}
V g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2emakeEach_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_h_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 4, 7);
    HeffT2 v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_h_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_m_2416;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_h_242);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        v_m_2416 = ((V)&g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam0_clo);
      } else {
        heff_drop(v_field_247);
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 2, 7);
        HeffT2 v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_h_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2410); r_; });
        {
          V v_field_2413 = v_t_2411.f[1];
          V v_tag_2412 = heff_box_i64(((int64_t)v_t_2411.f[0]));
          v_m_2416 = heff_clo_n(g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam1, 1, 3, (V[]){v_tag_2412, v_field_2413, v_h_242});
        }
      }
      V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_MkPair: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        V v_s_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        V v_m_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2emakeEach_clo), 1, (V[]){v_rest_243}));
        V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_s_2419}));
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_MkPair: {
          V v_x_2422 = heff_field(v_x2_2421, 0);
          V v_s_2423 = heff_field(v_x2_2421, 1);
          heff_take_n(v_x2_2421, 3ULL, 2);
          V v_x_2424 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_240_24Cons, v_x_2418, v_x_2422));
          return ((HeffT2){{v_x_2424, v_s_2423}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2421)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2417)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam0(V self, V *args) {
  V v_p_249 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_249});
}
V g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam1(V self, V *args) {
  V v_p_2414 = args[0];
  V v_tag_2412 = heff_env(self)[0];
  V v_field_2413 = heff_env(self)[1];
  V v_h_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_unbox_i64(v_tag_2412) == ((int64_t)0ULL))) {
    V v_b0_2415 = v_field_2413;
    return (g_heff_2ecompile_2esimplify_2emakeOne(((V)&g_heff_2ecompile_2esimplify_2emakeEach_clo), v_h_242, v_b0_2415, v_p_2414));
  } else {
    heff_drop(v_field_2413);
    heff_drop(v_h_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_2414});
  }
}
Clo g_heff_2ecompile_2esimplify_2eonceEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eonceEach_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eonceEach(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_seen_240, v_x_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_x_242);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        V t_0 = v_seen_240;
        V t_1 = v_xs_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_field_246);
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
        V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_seen_240, v_x_242, NTAG(TAG_MkUnit)));
        V v_u_2410 = (g_heff_2ecompile_2esimplify_2eonceEach_24dps(v_t_249, v_xs_243, heff_dup(v_cell_248)));
        heff_drop(v_u_2410);
        return v_cell_248;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eonceEach(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eunmade_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eunmade_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eunmade(V v_h_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  HeffT2 v_t_243 = ({ V a_0 = v_t_242; V a_1 = v_h_240; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_242); r_; });
  V v_t_2411;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_r_246 = v_field_245;
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_246), NTAG(TAG_Nil)});
      V v_x_248 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_247));
      if (heff_intLt_c(MK_INT(1200LL), v_x_248)) {
        heff_drop(v_r_246);
        V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
        v_t_2411 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(v_t_249, v_h_240));
      } else {
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
        v_t_2411 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_2410, heff_dup(v_h_240), v_r_246));
      }
    } else {
      heff_drop(v_field_245);
      v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
    }
  }
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 1, 7);
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 3, 7);
  V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 4, 7);
  V v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = v_h_240; V r_ = (g_std_2eordmap_2edelete_24s2135745297x1725920174(a_0, a_1)); heff_drop(v_h_240); r_; });
  V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 5, 7);
  V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 6, 7);
  V v_p_2419 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_2411, v_t_2412, v_t_2413, v_t_2414, v_t_2416, v_t_2417, v_t_2418});
  V v_t_2420 = ({ V rv_7 = v_p_2419; V rr_ = heff_rec_reuse_nf(v_s_241, 895ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 999423u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2420});
}
V g_heff_2ecompile_2esimplify_2eunmade_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eunmade(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2esettleDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esettleDef_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esettleDef(V v_n_240, V v_key_241, V v_b_242, V v_s_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2esettleDef_24cpr(v_n_240, v_key_241, v_b_242, v_s_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2ecompile_2esimplify_2esettleDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esettleDef(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecatMaybesS_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ecatMaybesS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecatMaybesS(a[0]);
}
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2(V v_tok_240, V v_xs_241, V v_b_242, V v_argv_243) {
top: ;
  V v_a_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
  V v_t_246;
  if (heff_intLe_c_lent(v_a_244, v_b_245, 0)) {
    heff_drop(v_b_245);
    v_t_246 = v_a_244;
  } else {
    heff_drop(v_a_244);
    v_t_246 = v_b_245;
  }
  V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_241)));
  V v_a_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
  V v_t_2410;
  if (heff_intLe_c_lent(v_a_248, v_b_249, 0)) {
    heff_drop(v_b_249);
    v_t_2410 = v_a_248;
  } else {
    heff_drop(v_a_248);
    v_t_2410 = v_b_249;
  }
  V v_t_2411 = (g_list_2etake(v_t_2410, heff_dup(v_argv_243)));
  V v_t_2412 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_247, v_t_2411));
  V v_x_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_a_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
  V v_t_2416;
  if (heff_intLe_c_lent(v_a_2414, v_b_2415, 0)) {
    heff_drop(v_b_2415);
    v_t_2416 = v_a_2414;
  } else {
    heff_drop(v_a_2414);
    v_t_2416 = v_b_2415;
  }
  V v_t_2421;
  if (heff_intLt_c(v_t_2416, v_x_2413)) {
    V v_a_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
    V v_b_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
    V v_t_2419;
    if (heff_intLe_c_lent(v_a_2417, v_b_2418, 0)) {
      heff_drop(v_b_2418);
      v_t_2419 = v_a_2417;
    } else {
      heff_drop(v_a_2417);
      v_t_2419 = v_b_2418;
    }
    V v_t_2420 = (g_list_2edrop(v_t_2419, v_xs_241));
    v_t_2421 = heff_tag_at_n(v_tok_240, TAG_ELam, 2, (V[]){v_t_2420, v_b_242});
  } else {
    heff_drop_cell(v_tok_240, 2);
    v_t_2421 = v_b_242;
  }
  V v_e_2422 = ({ V a_0 = v_t_2412; V a_1 = v_t_2421; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2412); r_; });
  V v_m_2423 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e_2422));
  return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2_lam0, 1, 3, (V[]){v_m_2423, v_xs_241, v_argv_243});
}
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eapplyLam_24s1037220598x261031314_24tok2_lam0(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  V v_argv_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    heff_take_n(v_x2_2425, 3ULL, 2);
    V v_a_2428 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
    V v_b_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
    V v_t_2430;
    if (heff_intLe_c_lent(v_a_2428, v_b_2429, 0)) {
      heff_drop(v_b_2429);
      v_t_2430 = v_a_2428;
    } else {
      heff_drop(v_a_2428);
      v_t_2430 = v_b_2429;
    }
    V v_argv_2431 = ({ V a_0 = v_t_2430; V a_1 = v_argv_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_argv_243); r_; });
    V v_t_2432 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_x_2426, v_argv_2431));
    V f_ = v_t_2432;
    args[0] = v_s_2427;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
Clo g_heff_2ecompile_2esimplify_2eattemptBy_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eattemptBy_24tok2_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eattemptBy_24tok2(V v_tok_240, V v_more_241, V v_orig_242, V v_m_243, V v_s_244) {
top: ;
  V v_x2_245 = heff_tr(heff_call(v_m_243, 1, (V[]){heff_dup(v_s_244)}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_s_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_dup(v_orig_242), NTAG(TAG_Nil)});
    V v_t_249 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_248));
    V v_lim_2410 = heff_intAdd(v_t_249, v_more_241);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
    V v_x_2412 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2410), MK_INT(0LL), v_t_2411));
    if (!heff_intLt_c_lent(v_lim_2410, v_x_2412, 0)) {
      heff_drop(v_orig_242);
      heff_drop_rec(v_s_244, 10);
      heff_drop(v_lim_2410);
      heff_drop(v_x_2412);
      return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_246, v_s_247});
    } else {
      heff_drop(v_x_246);
      heff_drop(v_lim_2410);
      heff_drop(v_x_2412);
      V v_t_2413 = ({ V rv_2 = heff_take_field(v_s_244, 2); V rv_5 = heff_get_n(v_s_244, 5, 10); V rr_ = heff_rec_reuse_nf(v_s_247, 987ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1045455u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_orig_242, v_t_2413});
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2esimplify_2eattemptBy_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eattemptBy_24tok2(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2(V v_tok_240, V v_g_241, V v_xs_242, V v_b_243, V v_as0_244, V v_x6_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_MkPair: {
    V v_bds_247 = heff_field(v_x6_245, 0);
    V v_argv_248 = heff_field(v_x6_245, 1);
    heff_take_n(v_x6_245, 3ULL, 2);
    V v_made_249 = (g_list_2ezipWith_24s528321443x971020870(v_as0_244, heff_dup(v_argv_248)));
    V v_t_2410 = (g_heff_2ecompile_2esimplify_2etagMarks(heff_dup(v_z_246), heff_dup(v_g_241), heff_dup(v_xs_242), heff_dup(v_b_243), heff_dup(v_argv_248)));
    V v_x2_2411 = heff_tr(g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645(v_g_241, v_xs_242, v_b_243, v_argv_248, v_made_249, v_t_2410, v_z_246));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      V v_x_2414 = ({ V a_0 = v_bds_247; V a_1 = v_x_2412; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_bds_247); r_; });
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_x_2414, v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}