// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_Kept 49931
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depth 296830685
#define LBL_depths 611816763
#define LBL_e 319
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_kept 9783717
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipe 1012227257
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_vars 10107635
#define LBL_ver 326173
#define LBL_vers 10111479
static uint32_t shape_args__vars__holes[] = {LBL_args, LBL_vars, LBL_holes};
static uint32_t shape_name__ver__recipe__depth__safe__made[] = {LBL_name, LBL_ver, LBL_recipe, LBL_depth, LBL_safe, LBL_made};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2esimplify_2eafresh(V, V);
V g_heff_2ecompile_2esimplify_2eafresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eafresh_clo;
V g_heff_2ecompile_2esimplify_2eallPure(V, V);
V g_heff_2ecompile_2esimplify_2eallPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eallPure_clo;
V g_heff_2ecompile_2esimplify_2eapartW(V, V);
V g_heff_2ecompile_2esimplify_2eapartW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartW_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2eattempt(V, V, V);
V g_heff_2ecompile_2esimplify_2eattempt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattempt_clo;
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V, V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo;
V g_heff_2ecompile_2esimplify_2echeap(V, V, V);
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2echeap_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2ecopyCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyCall_clo;
V g_heff_2ecompile_2esimplify_2ecopyWith(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eetaLoop(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLoop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLoop_clo;
V g_heff_2ecompile_2esimplify_2eetaWanted(V, V);
V g_heff_2ecompile_2esimplify_2eetaWanted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaWanted_clo;
V g_heff_2ecompile_2esimplify_2efindField(V, V);
V g_heff_2ecompile_2esimplify_2efindField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efindField_clo;
V g_heff_2ecompile_2esimplify_2efreshName(V, V);
V g_heff_2ecompile_2esimplify_2efreshName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshName_clo;
V g_heff_2ecompile_2esimplify_2efueled(V, V);
V g_heff_2ecompile_2esimplify_2efueled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efueled_clo;
V g_heff_2ecompile_2esimplify_2eknownCopy(V, V);
V g_heff_2ecompile_2esimplify_2eknownCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownCopy_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2emadeOf(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOf_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2enoKeep_get(void);
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eonceEach_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_24dps_clo;
V g_heff_2ecompile_2esimplify_2eoneDef(V, V);
V g_heff_2ecompile_2esimplify_2eoneDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneDef_clo;
V g_heff_2ecompile_2esimplify_2eoneItem(V, V);
V g_heff_2ecompile_2esimplify_2eoneItem_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneItem_clo;
V g_heff_2ecompile_2esimplify_2epartialMore(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epartialMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialMore_clo;
V g_heff_2ecompile_2esimplify_2eprimAppN(V, V, V);
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo;
V g_heff_2ecompile_2esimplify_2ereplayed(V, V, V);
V g_heff_2ecompile_2esimplify_2ereplayed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ereplayed_clo;
V g_heff_2ecompile_2esimplify_2escrutW(V, V, V);
V g_heff_2ecompile_2esimplify_2escrutW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2escrutW_clo;
V g_heff_2ecompile_2esimplify_2eshapeOne(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapeOne_clo;
V g_heff_2ecompile_2esimplify_2eshapesOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo;
V g_heff_2ecompile_2esimplify_2especKnown(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKnown_clo;
V g_heff_2ecompile_2esimplify_2especLam(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especLam_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etoldTo(V, V, V);
V g_heff_2ecompile_2esimplify_2etoldTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etoldTo_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_clo;
V g_heff_2ecompile_2esimplify_2eunOp(V, V);
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunOp_clo;
V g_heff_2ecompile_2esimplify_2eworthIt(V, V);
V g_heff_2ecompile_2esimplify_2eworthIt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eworthIt_clo;
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;

static V g_heff_2ecompile_2esimplify_2enoKeep_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2enoKeep_st;
static V g_heff_2ecompile_2esimplify_2enoKeep_init(void) {
  return heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())});
}
V g_heff_2ecompile_2esimplify_2enoKeep_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2enoKeep_st)) return g_heff_2ecompile_2esimplify_2enoKeep_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2enoKeep_val, &g_heff_2ecompile_2esimplify_2enoKeep_st, g_heff_2ecompile_2esimplify_2enoKeep_init);
}
Clo g_heff_2ecompile_2esimplify_2eelemStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eelemStr_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eelemStr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eelemStr(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eattempt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eattempt_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eattempt(V v_orig_240, V v_m_241, V v_s_242) {
top: ;
  V v_x2_243 = heff_tr(heff_call(v_m_241, 1, (V[]){heff_dup(v_s_242)}));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_s_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24MkPair = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_orig_240), NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_246));
    V v_lim_248 = heff_intAdd(v_t_247, MK_INT(24LL));
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_244), NTAG(TAG_Nil)});
    V v_x_2410 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_248), MK_INT(0LL), v_t_249));
    if (heff_intLt_c(v_lim_248, v_x_2410)) {
      heff_drop(v_x_244);
      V v_t_2412 = ({ V rv_2 = heff_take_field(v_s_242, 2); V rv_5 = heff_get_n(v_s_242, 5, 9); V rr_ = heff_rec_reuse_nf(v_s_245, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 259023u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_at_n(v_ru_24x2_243_24MkPair, TAG_MkPair, 2, (V[]){v_orig_240, v_t_2412});
    } else {
      heff_drop(v_orig_240);
      heff_drop_rec(v_s_242, 9);
      return heff_tag_at_n(v_ru_24x2_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_244, v_s_245});
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2esimplify_2eattempt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eattempt(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprimAppN_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eprimAppN(V v_p_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_p_240}), v_as_241});
  }
  case TAG_Just: {
    V v_n_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_241));
    if (heff_intEq_c(v_t_244, heff_dup(v_n_243))) {
      heff_drop(v_n_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      V v_x2_2412;
      switch (heff_tag_of(v_as_241)) {
      case TAG_Nil: {
        v_x2_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_a_246 = heff_dup(heff_field(v_as_241, 0));
        V v_x22_247 = heff_dup(heff_field(v_as_241, 1));
        switch (heff_tag_of(v_x22_247)) {
        case TAG_Nil: {
          v_x2_2412 = (g_heff_2ecompile_2esimplify_2eunOp(heff_dup(v_p_240), v_a_246));
          break;
        }
        case TAG_Cons: {
          V v_b_248 = heff_field(v_x22_247, 0);
          V v_x222_249 = heff_field(v_x22_247, 1);
          heff_take_n(v_x22_247, 3ULL, 2);
          switch (heff_tag_of(v_x222_249)) {
          case TAG_Nil: {
            v_x2_2412 = (g_heff_2ecompile_2esimplify_2ebinOp(heff_dup(v_p_240), v_a_246, v_b_248));
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x222_249, 0ULL, 2);
            heff_drop(v_a_246);
            heff_drop(v_b_248);
            v_x2_2412 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x222_249);
          }
          break;
        }
        default: heff_nomatch(v_x22_247);
        }
        break;
      }
      default: heff_nomatch(v_as_241);
      }
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nothing: {
        return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_as_241});
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        heff_take_n(v_x2_2412, 1ULL, 1);
        heff_drop(v_p_240);
        heff_drop(v_as_241);
        return v_x_2413;
      }
      default: return heff_nomatch(v_x2_2412);
      }
    } else {
      V v_x_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_241));
      if (heff_intLt_c(heff_dup(v_n_243), v_x_2414)) {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        V v_as_2416 = (g_heff_2ecompile_2esimplify_2etakeL(heff_dup(v_n_243), heff_dup(v_as_241)));
        V v_x2_2423;
        switch (heff_tag_of(v_as_2416)) {
        case TAG_Nil: {
          v_x2_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_a_2417 = heff_dup(heff_field(v_as_2416, 0));
          V v_x22_2418 = heff_dup(heff_field(v_as_2416, 1));
          switch (heff_tag_of(v_x22_2418)) {
          case TAG_Nil: {
            v_x2_2423 = (g_heff_2ecompile_2esimplify_2eunOp(heff_dup(v_p_240), v_a_2417));
            break;
          }
          case TAG_Cons: {
            V v_b_2419 = heff_field(v_x22_2418, 0);
            V v_x222_2420 = heff_field(v_x22_2418, 1);
            heff_take_n(v_x22_2418, 3ULL, 2);
            switch (heff_tag_of(v_x222_2420)) {
            case TAG_Nil: {
              v_x2_2423 = (g_heff_2ecompile_2esimplify_2ebinOp(heff_dup(v_p_240), v_a_2417, v_b_2419));
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2420, 0ULL, 2);
              heff_drop(v_a_2417);
              heff_drop(v_b_2419);
              v_x2_2423 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_x222_2420);
            }
            break;
          }
          default: heff_nomatch(v_x22_2418);
          }
          break;
        }
        default: heff_nomatch(v_as_2416);
        }
        V v_t_2425;
        switch (heff_tag_of(v_x2_2423)) {
        case TAG_Nothing: {
          v_t_2425 = heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_as_2416});
          break;
        }
        case TAG_Just: {
          V v_x_2424 = heff_field(v_x2_2423, 0);
          heff_take_n(v_x2_2423, 1ULL, 1);
          heff_drop(v_p_240);
          heff_drop(v_as_2416);
          v_t_2425 = v_x_2424;
          break;
        }
        default: heff_nomatch(v_x2_2423);
        }
        V v_t_2426 = (g_heff_2ecompile_2esimplify_2edropL(v_n_243, v_as_241));
        return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2425, v_t_2426});
      } else {
        heff_drop(v_n_243);
        return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Just, TAG_EPrim, 1, (V[]){v_p_240}), v_as_241});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprimAppN(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eclosedKnown_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eclosedKnown(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
    V v_x_246 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_245));
    if (heff_intLt_c(MK_INT(60LL), v_x_246)) {
      heff_drop(v_xs_243);
      heff_drop(v_b_244);
      return NTAG(TAG_False);
    } else {
      return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244}); V r_ = (g_heff_2ecompile_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x1_240, 0);
    V v_ts_2414 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_ERecord, 2, (V[]){heff_dup(v_fs_2413), heff_dup(v_ts_2414)}), NTAG(TAG_Nil)});
    V v_x_2416 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_2415));
    if (heff_intLt_c(MK_INT(60LL), v_x_2416)) {
      heff_drop(v_fs_2413);
      heff_drop(v_ts_2414);
      return NTAG(TAG_False);
    } else {
      return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_2413, v_ts_2414}); V r_ = (g_heff_2ecompile_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
    }
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eclosedKnown(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshName_str0, 1, "$");
Clo g_heff_2ecompile_2esimplify_2efreshName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efreshName_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efreshName(V v_base_240, V v_s_241) {
top: ;
  V v_n_242 = heff_take_field(v_s_241, 0);
  V v_t_243 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2efreshName_str0), heff_intShow(heff_dup(v_n_242)));
  V v_t_244 = ({ V rv_0 = heff_intAdd(v_n_242, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_s_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_base_240, v_t_243), v_t_244});
}
V g_heff_2ecompile_2esimplify_2efreshName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efreshName(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2escrutW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2escrutW_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2escrutW(V v_x_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_249 = heff_field(v_x31_243, 0);
      V v_as_2410 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI(v_as_2410, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_249, v_t_2411});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2413 = heff_field(v_x31_243, 1);
      V v_b_2414 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2414, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2415;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2416 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2418 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2416, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2418;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2419 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2419, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2424 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2426 = (g_heff_2ecompile_2eir_2eappendI(v_as_2424, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2426;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_sc_2427 = heff_field(v_x31_243, 0);
      V v_arms_2428 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2463;
      switch (heff_tag_of(v_sc_2427)) {
      case TAG_EVar: {
        V v_y_2429 = heff_dup(heff_field(v_sc_2427, 0));
        v_t_2463 = heff_strEq(heff_dup(v_x_240), v_y_2429);
        break;
      }
      case TAG_EGlobal: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_sc_2427);
      }
      V v_t_2464;
      if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
        heff_drop(v_t_2463);
        v_t_2464 = heff_intAdd(v_n_241, MK_INT(1LL));
      } else {
        heff_drop(v_t_2463);
        v_t_2464 = v_n_241;
      }
      V v_t_2465 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2428, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_t_2464;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_sc_2427, v_t_2465});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2468 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2469 = (g_heff_2ecompile_2eir_2eappendI(v_as_2468, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2469;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2471 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2472 = (g_heff_2ecompile_2eir_2eappendI(v_as_2471, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2472;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2escrutW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2escrutW(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2etoldTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etoldTo_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etoldTo(V v_b_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_b_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_b_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x3_242, 0);
      V v_as_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_2441;
      switch (heff_tag_of(v_a_245)) {
      case TAG_EVar: {
        heff_take_n(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_a_245, 0ULL, 3);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_a_245, 0ULL, 4);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_a_245, 0ULL, 3);
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_na(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
        heff_drop(v_t_2441);
        V v_t_2442 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)});
        V v_t_2443 = (g_heff_2ecompile_2esimplify_2eapartW(v_x_243, v_t_2442));
        if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
          heff_drop(v_b_240);
          heff_drop(v_xs_244);
          heff_drop(v_as_246);
          heff_drop(v_t_2443);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2443);
          V t_0 = v_b_240;
          V t_1 = v_xs_244;
          V t_2 = v_as_246;
          v_b_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2441);
        V t_0 = v_b_240;
        V t_1 = v_xs_244;
        V t_2 = v_as_246;
        v_b_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etoldTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etoldTo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ecopyCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyCall_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecopyCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2esimplify_2eknownCopy(heff_dup(v_s_244), v_g_242));
  V v_t_246 = (g_heff_2ecompile_2esimplify_2eworthIt(heff_dup(v_as_243), v_t_245));
  V v_x2_247 = (g_heff_2ecompile_2esimplify_2efueled(v_t_246, v_s_244));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x_248)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      V v_x_2410 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_2410, v_s_249});
    }
    case TAG_Just: {
      V v_b_2411 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_247_24MkPair, 2);
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_243)));
      V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2411, v_as_243}));
      return (g_heff_2ecompile_2esimplify_2eattempt(v_t_2412, v_t_2413, v_s_249));
    }
    default: return heff_nomatch(v_x_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2esimplify_2ecopyCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecopyCall(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eshapesOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eshapesOf(V v_x1_240, V v_as_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_as_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_p_242});
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_ms_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      heff_drop(v_m_244);
      heff_drop(v_ms_245);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_246 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_as_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_p_242});
    }
    case TAG_Cons: {
      V v_a_247 = heff_field(v_as_241, 0);
      V v_as2_248 = heff_field(v_as_241, 1);
      V v_ru_24as_241_24Cons = heff_take_reuse_n(v_as_241, 3ULL, 2);
      V v_x2_249 = ({ V a_0 = v_m_244; V a_1 = v_a_247; V a_2 = v_p_242; V r_ = (g_heff_2ecompile_2esimplify_2eshapeOne(a_0, a_1, a_2)); heff_drop(v_m_244); r_; });
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        V v_s_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 3ULL, 2);
        V v_m_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eshapesOf_clo), 2, (V[]){v_ms_245, v_as2_248}));
        V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
        switch (heff_tag_of(v_x2_2413)) {
        case TAG_MkPair: {
          V v_x_2414 = heff_field(v_x2_2413, 0);
          V v_s_2415 = heff_field(v_x2_2413, 1);
          heff_take_n(v_x2_2413, 3ULL, 2);
          V v_t_2416 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2410, 0)), heff_dup(heff_rfield(v_x_2414, 0))});
          V v_t_2417 = (g_heff_2ecompile_2esimplify_2eappendL(heff_take_field(v_x_2410, 1), heff_take_field(v_x_2414, 1)));
          V v_t_2418 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_x_2410, 2, 4), heff_get_n(v_x_2414, 2, 3)));
          V v_x_2419 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_t_2416, v_t_2417, v_t_2418});
          return heff_tag_at_n(v_ru_24as_241_24Cons, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2415});
        }
        default: return heff_nomatch(v_x2_2413);
        }
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_as_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eshapesOf(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2epartialMore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialMore_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2epartialMore(V v_safe_240, V v_all_241, V v_g_242, V v_as_243) {
top: ;
  V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, heff_dup(v_all_241)}));
  V v_t_245 = (g_list_2emap(v_t_244, heff_dup(v_as_243)));
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_245); r_; });
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_x_247 = (g_heff_2ecompile_2esimplify_2earityIn(v_all_241, heff_dup(v_g_242)));
    V v_y_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
    if (heff_intLt_c(v_y_248, v_x_247)) {
      V v_t_2410 = ({ V a_0 = v_all_241; V a_1 = v_g_242; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_all_241); r_; });
      V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_as_243); r_; });
      return heff_intSub(v_t_2410, v_t_2411);
    } else {
      heff_drop(v_all_241);
      heff_drop(v_g_242);
      heff_drop(v_as_243);
      return MK_INT(0LL);
    }
  } else {
    heff_drop(v_all_241);
    heff_drop(v_g_242);
    heff_drop(v_as_243);
    heff_drop(v_t_246);
    return MK_INT(0LL);
  }
}
V g_heff_2ecompile_2esimplify_2epartialMore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epartialMore(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2especLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especLam_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2especLam(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_s_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 6, 7);
  V v_t_248 = heff_bool(((heff_dup(v_t_246) == NTAG(TAG_True)) || ({ V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 5, 7); int c_ = heff_intLe_c(MK_INT(50000LL), heff_dup(v_t_247)); heff_drop(v_t_247); c_; })));
  heff_drop(v_t_246);
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_t_248);
    V v_x_249 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_245});
  } else {
    heff_drop(v_t_248);
    V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eetaWanted_clo), 1, (V[]){heff_dup(v_s_245)}));
    V v_t_2411 = (g_list_2eany(v_t_2410, v_as_244));
    V v_x2_2416;
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_x2_2412 = (g_heff_2ecompile_2esimplify_2eallPure(heff_dup(v_as_244), v_s_245));
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_MkPair: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_s_2414 = heff_field(v_x2_2412, 1);
        heff_take_n(v_x2_2412, 3ULL, 2);
        v_x2_2416 = ({ V a_0 = heff_dup(v_r_240); V a_1 = heff_dup(v_g_241); V a_2 = heff_dup(v_xs_242); V a_3 = heff_dup(v_b_243); V a_4 = v_as_244; V a_5 = v_x_2413; V a_6 = v_s_2414; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2eetaLoop(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2413); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2412);
      }
    } else {
      heff_drop(v_t_2411);
      V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_as_244});
      v_x2_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_s_245});
    }
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_s_2418 = heff_field(v_x2_2416, 1);
      V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
      switch (heff_tag_of(v_x_2417)) {
      case TAG_MkPair: {
        V v_bds_2419 = heff_field(v_x_2417, 0);
        V v_as_2420 = heff_field(v_x_2417, 1);
        heff_take_n(v_x_2417, 3ULL, 2);
        V v_x2_2421 = heff_tr(g_heff_2ecompile_2esimplify_2especKnown(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_2420, v_s_2418));
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_MkPair: {
          V v_x_2422 = heff_field(v_x2_2421, 0);
          V v_s_2423 = heff_field(v_x2_2421, 1);
          heff_take_n(v_x2_2421, 3ULL, 2);
          V v_x_2424 = ({ V a_0 = v_bds_2419; V a_1 = v_x_2422; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_bds_2419); r_; });
          return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){v_x_2424, v_s_2423});
        }
        default: return heff_nomatch(v_x2_2421);
        }
      }
      default: return heff_nomatch(v_x_2417);
      }
    }
    default: return heff_nomatch(v_x2_2416);
    }
  }
}
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especLam(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2esimplify_2efindField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efindField_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efindField(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c(heff_dup(v_k_244), heff_dup(v_l_240))) {
        heff_drop(v_l_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      } else {
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efindField_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efindField(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eonceEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eonceEach_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eonceEach(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), v_seen_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(v_x_242, NTAG(TAG_MkUnit), v_seen_240));
      V v_u_247 = (g_heff_2ecompile_2esimplify_2eonceEach_24dps(v_t_246, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_247);
      return v_cell_245;
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_xs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eonceEach(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eoneItem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eoneItem_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eoneItem(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Fresh: {
    V v_d_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eoneDef(v_d_242, v_p_241);
  }
  case TAG_Kept: {
    V v_k_243 = heff_field(v_x1_240, 0);
    V v_redo_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Kept = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_243, 2)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_x2_246 = (g_heff_2ecompile_2esimplify_2ereplayed(v_k_243, v_t_245, heff_dup(v_p_241)));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_s_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      switch (heff_tag_of(v_x_247)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Kept, 2);
        heff_drop(v_s_248);
        heff_drop_cell(v_ru_24x2_246_24MkPair, 2);
        V v_t_249 = heff_tr(heff_call(v_redo_244, 1, (V[]){heff_dup(heff_rfield(v_p_241, 0))}));
        HEFF_LAST return g_heff_2ecompile_2esimplify_2eafresh(v_t_249, v_p_241);
      }
      case TAG_Just: {
        V v_ds_2410 = heff_field(v_x_247, 0);
        heff_take_n(v_x_247, 1ULL, 1);
        heff_drop_rec(v_p_241, 9);
        heff_drop(v_redo_244);
        V v_t_2411 = heff_tag_at_n(v_ru_24x1_240_24Kept, TAG_MkPair, 2, (V[]){v_ds_2410, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_2411, v_s_248});
      }
      default: return heff_nomatch(v_x_247);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eoneItem_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eoneItem(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyWith_str0, 0, "");
Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyWith_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecopyWith(V v_st_240, V v_bodies_241, V v_h_242, V v_v_243, V v_r_244) {
top: ;
  if (heff_strEq_c(heff_dup(v_v_243), ((V)&g_heff_2ecompile_2esimplify_2ecopyWith_str0))) {
    heff_drop_rec(v_st_240, 9);
    heff_drop(v_h_242);
    heff_drop(v_v_243);
    heff_drop(v_r_244);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_st_240, 7)), 3, 7);
    V v_x2_247 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_246; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_t_249;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_t_249 = MK_INT(0LL);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_x3_2410 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_h_242), heff_rfield(v_st_240, 4)));
    V v_t_2412;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nothing: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2410, 0ULL, 1);
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    V v_t_2413 = (g_heff_2ecompile_2esimplify_2emadeOf(v_st_240, v_bodies_241, heff_dup(v_h_242)));
    return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(6, shape_name__ver__recipe__depth__safe__made, (V[]){v_h_242, v_v_243, v_r_244, v_t_249, v_t_2412, v_t_2413})});
  }
}
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ecopyWith(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecatMaybesS_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ecatMaybesS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecatMaybesS(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = (g_heff_2ecompile_2esimplify_2eoneItem(v_x_242, v_p_241));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      V v_x2_247 = (g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(v_xs_243, v_s_246));
      switch (heff_tag_of(v_x2_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_s_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_x_248}), v_s_249});
      }
      default: return heff_nomatch(v_x2_247);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(a[0], a[1]);
}