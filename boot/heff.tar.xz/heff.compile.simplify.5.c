// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_fuel 9649789
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2esimplify_2eapartW(V, V);
V g_heff_2ecompile_2esimplify_2eapartW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartW_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
HeffT2 g_heff_2ecompile_2esimplify_2earmChosen_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2earmsPushable(V, V, V);
V g_heff_2ecompile_2esimplify_2earmsPushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earmsPushable_clo;
V g_heff_2ecompile_2esimplify_2eattemptBy(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ebackTo_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eboundPushed(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eboundPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eboundPushed_clo;
V g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_clo;
V g_heff_2ecompile_2esimplify_2echeap(V, V, V);
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2echeap_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ecopyCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyCall_clo;
V g_heff_2ecompile_2esimplify_2efieldsBound(V, V);
V g_heff_2ecompile_2esimplify_2efieldsBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldsBound_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efindArm_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2efollowOver_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2efollowOver_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowOver_24tok2_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2efollowerPushed(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2efollowerPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerPushed_clo;
V g_heff_2ecompile_2esimplify_2efollowerSet(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2efollowerSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerSet_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2efreshNames(V, V, V);
V g_heff_2ecompile_2esimplify_2efreshNames_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshNames_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshNames_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2egivenSet_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedPast(V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedPast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedPast_clo;
V g_heff_2ecompile_2esimplify_2einOrder(V, V);
V g_heff_2ecompile_2esimplify_2einOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einOrder_clo;
V g_heff_2ecompile_2esimplify_2eknownCopy(V, V, V);
V g_heff_2ecompile_2esimplify_2eknownCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownCopy_clo;
V g_heff_2ecompile_2esimplify_2eloopBack(V, V, V);
V g_heff_2ecompile_2esimplify_2eloopBack_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eloopBack_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emadeOne_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeEach_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emakeEach_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2emakeOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeOne_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eonceEach_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_24dps_clo;
V g_heff_2ecompile_2esimplify_2epartialMore(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epartialMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialMore_clo;
V g_heff_2ecompile_2esimplify_2eprunedMax(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedMax_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedMax_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erecordDef_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2ereplayBody_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2esafeAs_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2etagBound(V);
V g_heff_2ecompile_2esimplify_2etagBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagBound_clo;
V g_heff_2ecompile_2esimplify_2etagsGiven(V, V, V);
V g_heff_2ecompile_2esimplify_2etagsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagsGiven_clo;
V g_heff_2ecompile_2esimplify_2etoldTo(V, V, V);
V g_heff_2ecompile_2esimplify_2etoldTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etoldTo_clo;
V g_heff_2ecompile_2esimplify_2eunmade(V, V);
V g_heff_2ecompile_2esimplify_2eunmade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunmade_clo;
V g_heff_2ecompile_2esimplify_2ewaysOut(V);
V g_heff_2ecompile_2esimplify_2ewaysOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewaysOut_clo;
V g_heff_2ecompile_2esimplify_2eworthIt(V, V, V);
V g_heff_2ecompile_2esimplify_2eworthIt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eworthIt_clo;
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
V g_list_2eany_24s1934959195x1899752489(V, V, V, V, V, V, V, V, V, V);
V g_list_2eany_24s1934959195x1899752489_entry(V self, V *a);
extern Clo g_list_2eany_24s1934959195x1899752489_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2efoldl_24s1810151735x2071939409(V, V);
V g_list_2efoldl_24s1810151735x2071939409_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1810151735x2071939409_clo;
V g_list_2efoldl_24s1913417976x1327308136(V, V, V);
V g_list_2efoldl_24s1913417976x1327308136_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1913417976x1327308136_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s423901581x541836270(V, V);
V g_list_2ekeepIf_24s423901581x541836270_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s423901581x541836270_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24s473401207x1960255357(V);
V g_list_2emap_24s473401207x1960255357_entry(V self, V *a);
extern Clo g_list_2emap_24s473401207x1960255357_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s504671899x323346652_24cpr(V, V, V, V);
V g_std_2emap_2edelete_24s1614046289x1611773644(V, V);
V g_std_2emap_2edelete_24s1614046289x1611773644_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s1614046289x1611773644_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eclosedKnown_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eclosedKnown(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
    V v_x_246 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_245));
    if (!heff_intLt_c_lent(MK_INT(60LL), v_x_246, 1)) {
      heff_drop(v_x_246);
      return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244}); V r_ = (g_heff_2ecompile_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
    } else {
      heff_drop(v_xs_243);
      heff_drop(v_b_244);
      heff_drop(v_x_246);
      return NTAG(TAG_False);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2412 = heff_field(v_x1_240, 0);
    V v_ts_2413 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2414 = (g_list_2emap_24s1044393341x1523302351(heff_dup(v_fs_2412)));
    V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2414); r_; });
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_ERecord, 2, (V[]){heff_dup(v_fs_2412), heff_dup(v_ts_2413)}), NTAG(TAG_Nil)});
      V v_x_2417 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_2416));
      if (!heff_intLt_c_lent(MK_INT(60LL), v_x_2417, 1)) {
        heff_drop(v_x_2417);
        return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_2412, v_ts_2413}); V r_ = (g_heff_2ecompile_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
      } else {
        heff_drop(v_fs_2412);
        heff_drop(v_ts_2413);
        heff_drop(v_x_2417);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_fs_2412);
      heff_drop(v_ts_2413);
      heff_drop_cell(v_ru_24x1_240_24ERecord, 2);
      heff_drop(v_t_2415);
      return NTAG(TAG_False);
    }
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eclosedKnown(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2ewaysOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ewaysOut_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ewaysOut(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_ELam: {
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EApp: {
    V v_ru_24e_240_24EApp = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    V v_ru_24e_240_24ERecord = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_ETag: {
    V v_t_2416 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 3);
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, MK_INT(0LL)});
  }
  case TAG_EMatch: {
    V v_arms_2421 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EMatch = heff_take_reuse_n(v_e_240, 2ULL, 2);
    V v_t_2422 = heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    return (g_list_2efoldl_24s1810151735x2071939409(v_t_2422, v_arms_2421));
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EPrimCall: {
    V v_ru_24e_240_24EPrimCall = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_ECall: {
    V v_ru_24e_240_24ECall = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EFixed: {
    V v_ru_24e_240_24EFixed = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  }
  case TAG_EBool: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_ESet: {
    V v_b_2438 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_2438;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_EValues: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EFix: {
    V v_ru_24e_240_24EFix = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2ewaysOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ewaysOut(a[0]);
}
V g_heff_2ecompile_2esimplify_2etagBound_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam22(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etagBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etagBound_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2etagBound(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam0, 1, 1, (V[]){v_e_240});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam1, 1, 1, (V[]){v_e_240});
  }
  case TAG_ELam: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam2, 1, 1, (V[]){v_e_240});
  }
  case TAG_EApp: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam3, 1, 1, (V[]){v_e_240});
  }
  case TAG_ELet: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam4, 1, 1, (V[]){v_e_240});
  }
  case TAG_ERecord: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam5, 1, 1, (V[]){v_e_240});
  }
  case TAG_EProj: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam6, 1, 1, (V[]){v_e_240});
  }
  case TAG_ETag: {
    V v_t_2430 = heff_field(v_e_240, 0);
    V v_argv_2431 = heff_field(v_e_240, 1);
    V v_ts_2432 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2433 = (g_heff_2ecompile_2esimplify_2efieldsBound(((V)&g_heff_2ecompile_2esimplify_2etagBound_clo), v_argv_2431));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam7, 1, 3, (V[]){v_m_2433, v_t_2430, v_ts_2432});
  }
  case TAG_EMatch: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam8, 1, 1, (V[]){v_e_240});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam9, 1, 1, (V[]){v_e_240});
  }
  case TAG_EPrimCall: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam10, 1, 1, (V[]){v_e_240});
  }
  case TAG_ECall: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam11, 1, 1, (V[]){v_e_240});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam12, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam13, 1, 1, (V[]){v_e_240});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam14, 1, 1, (V[]){v_e_240});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam15, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam16, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam17, 1, 1, (V[]){v_e_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam18, 1, 1, (V[]){v_e_240});
  }
  case TAG_EBool: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam19, 1, 1, (V[]){v_e_240});
  }
  case TAG_ESet: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam20, 1, 1, (V[]){v_e_240});
  }
  case TAG_EValues: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam21, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFix: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam22, 1, 1, (V[]){v_e_240});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2etagBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etagBound(a[0]);
}
V g_heff_2ecompile_2esimplify_2etagBound_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_s_242});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_s_245});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_s_249});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam3(V self, V *args) {
  V v_s_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_s_2413});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam4(V self, V *args) {
  V v_s_2418 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_s_2418});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam5(V self, V *args) {
  V v_s_2422 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_s_2422});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam6(V self, V *args) {
  V v_s_2428 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_s_2428});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam7(V self, V *args) {
  V v_s_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_t_2430 = heff_env(self)[1];
  V v_ts_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_s_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_s_2437 = heff_field(v_x2_2435, 1);
    V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
    V v_t_2440;
    switch (heff_tag_of(v_x_2436)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_dup(heff_field(v_x_2436, 0));
      v_t_2440 = v_x_2438;
      break;
    }
    default: heff_nomatch(v_x_2436);
    }
    V v_t_2443;
    switch (heff_tag_of(v_x_2436)) {
    case TAG_MkPair: {
      V v_y_2442 = heff_field(v_x_2436, 1);
      heff_take_n(v_x_2436, 2ULL, 2);
      v_t_2443 = v_y_2442;
      break;
    }
    default: heff_nomatch(v_x_2436);
    }
    V v_t_2444 = heff_tag_at_n(v_ru_24x2_2435_24MkPair, TAG_MkPair, 2, (V[]){v_t_2440, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2430, v_t_2443, v_ts_2432})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2444, v_s_2437});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ecompile_2esimplify_2etagBound_lam8(V self, V *args) {
  V v_s_2447 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2448, v_s_2447});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam9(V self, V *args) {
  V v_s_2450 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2451, v_s_2450});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam10(V self, V *args) {
  V v_s_2454 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2455 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2455, v_s_2454});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam11(V self, V *args) {
  V v_s_2458 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2459, v_s_2458});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam12(V self, V *args) {
  V v_s_2461 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2462 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2462, v_s_2461});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam13(V self, V *args) {
  V v_s_2464 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2465, v_s_2464});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam14(V self, V *args) {
  V v_s_2467 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2468 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2468, v_s_2467});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam15(V self, V *args) {
  V v_s_2470 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2471 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2471, v_s_2470});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam16(V self, V *args) {
  V v_s_2474 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2475 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2475, v_s_2474});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam17(V self, V *args) {
  V v_s_2477 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2478 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2478, v_s_2477});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam18(V self, V *args) {
  V v_s_2479 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2480 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2480, v_s_2479});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam19(V self, V *args) {
  V v_s_2482 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2483 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2483, v_s_2482});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam20(V self, V *args) {
  V v_s_2487 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2488 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2488, v_s_2487});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam21(V self, V *args) {
  V v_s_2490 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2491 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2491, v_s_2490});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam22(V self, V *args) {
  V v_s_2494 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2495 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2495, v_s_2494});
}

HeffT2 g_heff_2ecompile_2esimplify_2earmChosen_24cpr(V v_known_240, V v_arms_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_known_240);
    heff_drop(v_arms_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      V v_t_2419 = heff_field(v_x31_243, 0);
      V v_argv_2420 = heff_field(v_x31_243, 1);
      HeffT2 v_t_2422 = (g_heff_2ecompile_2esimplify_2efindArm_24cpr(v_t_2419, v_arms_241));
      {
        V v_field_2424 = v_t_2422.f[1];
        int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
        if ((v_tag_2423 == ((int64_t)0ULL))) {
          V v_it1_2425 = v_field_2424;
          switch (heff_tag_of(v_it1_2425)) {
          case TAG_MkArm: {
            V v_vs_2427 = heff_field(v_it1_2425, 1);
            V v_b_2428 = heff_field(v_it1_2425, 2);
            heff_take_n(v_it1_2425, 6ULL, 3);
            V v_t_2429 = ({ V a_0 = v_vs_2427; V a_1 = v_argv_2420; V a_2 = v_known_240; V r_ = (g_heff_2ecompile_2esimplify_2etagsGiven(a_0, a_1, a_2)); heff_drop(v_vs_2427); r_; });
            V v_f_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2428, v_t_2429});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2430}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2425)}});
          }
        } else {
          heff_drop(v_known_240);
          heff_drop(v_field_2424);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_EMatch: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_drop(v_known_240);
      heff_drop(v_arms_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2eprunedMax_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprunedMax_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eprunedMax(V v_kinds_240, V v_g_241, V v_b_242, V v_argv_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2esimplify_2ehandedPast(v_kinds_240, v_b_242, heff_dup(v_argv_243)));
  V v_x_245;
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    v_x_245 = MK_INT(160LL);
  } else {
    heff_drop(v_t_244);
    v_x_245 = MK_INT(50LL);
  }
  V v_t_246 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), heff_dup(v_argv_243)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_247));
  V v_t_249 = (g_heff_2ecompile_2esimplify_2ehandedPast(v_kinds_240, v_b_242, v_argv_243));
  V v_t_2410;
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    v_t_2410 = MK_INT(160LL);
  } else {
    heff_drop(v_t_249);
    v_t_2410 = MK_INT(24LL);
  }
  V v_y_2411 = heff_intAdd(v_t_248, v_t_2410);
  if (heff_intLe_c_lent(v_x_245, v_y_2411, 0)) {
    heff_drop(v_y_2411);
    return v_x_245;
  } else {
    heff_drop(v_x_245);
    return v_y_2411;
  }
}
V g_heff_2ecompile_2esimplify_2eprunedMax_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2eprunedMax(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2etoldTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etoldTo_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etoldTo(V v_b_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_b_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_b_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x3_242, 0);
      V v_argv_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_2448;
      switch (heff_tag_of(v_a_245)) {
      case TAG_EVar: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_a_245, 0ULL, 3);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_a_245, 0ULL, 2);
        V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)});
        v_t_2448 = ({ V a_0 = v_x_243; V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2esimplify_2eapartW(a_0, a_1)); heff_drop(v_x_243); r_; });
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_a_245, 0ULL, 4);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_a_245, 0ULL, 3);
        V v_t_2426 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)});
        v_t_2448 = ({ V a_0 = v_x_243; V a_1 = v_t_2426; V r_ = (g_heff_2ecompile_2esimplify_2eapartW(a_0, a_1)); heff_drop(v_x_243); r_; });
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_na(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_a_245, 0ULL, 3);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
        heff_drop(v_b_240);
        heff_drop(v_xs_244);
        heff_drop(v_argv_246);
        heff_drop(v_t_2448);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2448);
        V t_0 = v_b_240;
        V t_1 = v_xs_244;
        V t_2 = v_argv_246;
        v_b_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etoldTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etoldTo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ecopyCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyCall_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecopyCall(V v_r_240, V v_f_241, V v_g_242, V v_argv_243, V v_s_244) {
top: ;
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_244, 7)), 1, 7);
  V v_t_246 = (g_heff_2ecompile_2esimplify_2eknownCopy(heff_dup(v_s_244), v_g_242, heff_dup(v_argv_243)));
  V v_t_247 = ({ V a_0 = v_t_245; V a_1 = heff_dup(v_argv_243); V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2esimplify_2eworthIt(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_247, heff_dup(v_s_244)));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_x_2411 = v_field_249;
    V v_s_2412 = v_field_2410;
    V v_more_2416;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Nothing: {
      heff_drop_rec(v_s_244, 9);
      v_more_2416 = MK_INT(24LL);
      break;
    }
    case TAG_Just: {
      V v_b_2413 = heff_dup(heff_field(v_x_2411, 0));
      V v_t_2414 = heff_get_n(heff_get_n(v_s_244, 7, 9), 1, 7);
      V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_b_2413; V a_2 = heff_dup(v_argv_243); V r_ = (g_heff_2ecompile_2esimplify_2ehandedPast(a_0, a_1, a_2)); heff_drop(v_t_2414); heff_drop(v_b_2413); r_; });
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        v_more_2416 = MK_INT(160LL);
      } else {
        heff_drop(v_t_2415);
        v_more_2416 = MK_INT(24LL);
      }
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      heff_drop(v_more_2416);
      V v_x_2417 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_s_2412});
    }
    case TAG_Just: {
      V v_b_2418 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 1);
      V v_t_2419 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_argv_243)));
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2418, v_argv_243}));
      return (g_heff_2ecompile_2esimplify_2eattemptBy(v_more_2416, v_t_2419, v_t_2420, v_s_2412));
    }
    default: return heff_nomatch(v_x_2411);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ecopyCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecopyCall(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eloopBack_str0, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eloopBack_str1, 2, "$s");
Clo g_heff_2ecompile_2esimplify_2eloopBack_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eloopBack_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eloopBack(V v_all_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x3_242, 0);
    V v_x32_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24ELam = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x32_246)) {
    case TAG_EVar: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      V v_x321_2411 = heff_field(v_x32_246, 0);
      V v_argv_2412 = heff_field(v_x32_246, 1);
      V v_ru_24x32_246_24EApp = heff_take_reuse_n(v_x32_246, 3ULL, 2);
      switch (heff_tag_of(v_x321_2411)) {
      case TAG_EVar: {
        heff_take_n(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        V v_h_2414 = heff_field(v_x321_2411, 0);
        heff_take_n(v_x321_2411, 1ULL, 1);
        V v_t_2415 = (g_list_2emap_24s473401207x1960255357(heff_dup(v_argv_2412)));
        V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2415); r_; });
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop(v_t_2416);
          V v_t_2417 = heff_tag_at_n(v_ru_24x32_246_24EApp, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){heff_dup(v_h_2414)}), v_argv_2412});
          V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24ELam, TAG_ELam, 2, (V[]){v_xs_245, v_t_2417}), NTAG(TAG_Nil)});
          V v_x_2419 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_2418));
          if (!heff_intLt_c_lent(MK_INT(60LL), v_x_2419, 1)) {
            heff_drop(v_x_2419);
            HeffT2 v_t_2420 = ({ V a_0 = v_all_240; V a_1 = v_h_2414; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_h_2414); r_; });
            {
              V v_field_2422 = v_t_2420.f[1];
              int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
              if ((v_tag_2421 == ((int64_t)0ULL))) {
                V v_b_2423 = v_field_2422;
                V v_t_2424 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2423));
                V v_t_2425 = (g_heff_2ecompile_2eir_2enubI(v_t_2424));
                return ({ V b_0 = ((V)&g_heff_2ecompile_2esimplify_2eloopBack_str0); V b_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V b_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ecompile_2esimplify_2eloopBack_str1); V a_5 = v_g_241; V b_6 = MK_INT(0LL); V a_7 = MK_INT(0LL); V b_8 = MK_INT(0LL); V a_9 = v_t_2425; V r_ = (g_list_2eany_24s1934959195x1899752489(b_0, b_1, a_2, b_3, b_4, a_5, b_6, a_7, b_8, a_9)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_3); heff_drop(b_4); heff_drop(b_6); heff_drop(b_8); heff_drop(v_t_2425); r_; });
              } else {
                heff_drop(v_g_241);
                heff_drop(v_field_2422);
                return NTAG(TAG_False);
              }
            }
          } else {
            heff_drop(v_g_241);
            heff_drop(v_h_2414);
            heff_drop(v_x_2419);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop(v_g_241);
          heff_drop(v_xs_245);
          heff_drop_cell(v_ru_24x3_242_24ELam, 2);
          heff_drop(v_argv_2412);
          heff_drop_cell(v_ru_24x32_246_24EApp, 2);
          heff_drop(v_h_2414);
          heff_drop(v_t_2416);
          return NTAG(TAG_False);
        }
      }
      case TAG_ELam: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        heff_take_n(v_x321_2411, 0ULL, 3);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_take_n(v_x321_2411, 0ULL, 4);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_take_n(v_x321_2411, 0ULL, 3);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_take_n(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_take_n(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_take_na(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_take_n(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_take_n(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_take_na(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        heff_take_n(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        heff_take_n(v_x321_2411, 0ULL, 3);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        heff_take_n(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_argv_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x321_2411);
      }
    }
    case TAG_ELet: {
      heff_take_n(v_x32_246, 0ULL, 3);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_x32_246, 0ULL, 4);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_x32_246, 0ULL, 3);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_na(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_take_n(v_x32_246, 0ULL, 3);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x32_246);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x3_242, 0ULL, 4);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eloopBack_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eloopBack(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2epartialMore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialMore_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2epartialMore(V v_safe_240, V v_all_241, V v_g_242, V v_argv_243) {
top: ;
  V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, heff_dup(v_all_241)}));
  V v_t_245 = (g_list_2emap(v_t_244, heff_dup(v_argv_243)));
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_245); r_; });
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_x_247 = (g_heff_2ecompile_2esimplify_2earityIn(v_all_241, v_g_242));
    V v_y_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
    if (heff_intLt_c(v_y_248, v_x_247)) {
      V v_t_249 = ({ V a_0 = v_all_241; V a_1 = v_g_242; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_all_241); r_; });
      V v_t_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_argv_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_argv_243); r_; });
      return heff_intSub(v_t_249, v_t_2410);
    } else {
      heff_drop(v_all_241);
      heff_drop(v_argv_243);
      return MK_INT(0LL);
    }
  } else {
    heff_drop(v_all_241);
    heff_drop(v_argv_243);
    heff_drop(v_t_246);
    return MK_INT(0LL);
  }
}
V g_heff_2ecompile_2esimplify_2epartialMore_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epartialMore(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2ebackTo_24cpr(V v_saved_240, V v_s_241) {
top: ;
  V v_supply_242 = heff_take_field(v_s_241, 0);
  V v_defs_243 = heff_take_field(v_s_241, 2);
  V v_safe_244 = heff_take_field(v_s_241, 3);
  V v_base_245 = heff_take_field(v_s_241, 4);
  V v_total_246 = heff_take_field(v_s_241, 5);
  V v_sp_247 = heff_take_field(v_s_241, 7);
  V v_kp_248 = heff_get_n(v_s_241, 8, 9);
  V v_fuel_249 = heff_take_field(v_saved_240, 1);
  V v_plain_2410 = heff_take_field(v_saved_240, 6);
  V v_sp_2411 = heff_get_n(v_saved_240, 7, 9);
  V v_t_2412 = ({ V rv_5 = heff_take_field(v_sp_2411, 5); V rv_6 = heff_get_n(v_sp_2411, 6, 7); V rr_ = heff_rec_reuse_nf(v_sp_247, 31ULL, 7, shape_all__kinds__recipes__depths__made__count__off, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V v_f_2413 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_242, v_fuel_249, v_defs_243, v_safe_244, v_base_245, v_total_246, v_plain_2410, v_t_2412, v_kp_248});
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2413}});
}

HeffT2 g_heff_2ecompile_2esimplify_2efreshNames_24cpr(V v_base_240, V v_n_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
    heff_drop(v_base_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_Nil), v_p_242}});
  } else {
    HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(heff_dup(v_base_240), v_p_242));
    {
      V v_field_244 = v_t_243.f[0];
      V v_field_245 = v_t_243.f[1];
      V v_x_246 = v_field_244;
      V v_s_247 = v_field_245;
      V v_m_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2efreshNames_clo), 2, (V[]){v_base_240, heff_intSub(v_n_241, MK_INT(1LL))}));
      V v_x2_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_247}));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        V v_s_2411 = heff_field(v_x2_249, 1);
        V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_Cons, 2, (V[]){v_x_246, v_x_2410}), v_s_2411}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_249)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efollowerPushed_str0, 1, "k");
Clo g_heff_2ecompile_2esimplify_2efollowerPushed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efollowerPushed_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2efollowerPushed(V v_r_240, V v_s_241, V v_arms_242, V v_argv_243, V v_s_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efollowerPushed_str0), heff_dup(v_s_244)));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_x_248 = v_field_246;
    V v_s_249 = v_field_247;
    V v_orig_2410 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s_241), heff_dup(v_arms_242)}), heff_dup(v_argv_243)));
    HeffT2 v_t_2411 = (g_heff_2ecompile_2esimplify_2efollowerNamed_24cpr(heff_dup(v_x_248), heff_dup(v_argv_243)));
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        heff_drop(v_argv_243);
        V v_it1_2414 = v_field_2413;
        switch (heff_tag_of(v_it1_2414)) {
        case TAG_MkPair: {
          V v_argv2_2415 = heff_field(v_it1_2414, 0);
          V v_f_2416 = heff_field(v_it1_2414, 1);
          V v_ru_24it1_2414_24MkPair = heff_take_reuse_n(v_it1_2414, 3ULL, 2);
          V v_t_2417 = heff_get_n(heff_get_n(v_s_244, 7, 9), 1, 7);
          V v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = v_argv2_2415; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2417); r_; });
          if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
            heff_drop(v_t_2418);
            V v_argv_2419 = (g_list_2ekeepIf_24s423901581x541836270(v_x_248, heff_dup(v_argv2_2415)));
            V v_t_2420 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_argv_2419)));
            V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2420); r_; });
            if (((heff_dup(v_t_2421) == NTAG(TAG_True)) && ({ V v_t_2422 = (g_list_2efoldl_24s1913417976x1327308136(MK_INT(0LL), MK_INT(0LL), heff_dup(v_argv_2419))); int c_ = ({ V v_t_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_242)); int c_ = ({ V v_t_2424 = heff_intMul(heff_dup(v_t_2422), heff_intSub(heff_dup(v_t_2423), MK_INT(1LL))); int c_ = heff_intLe_c_lent(v_t_2424, MK_INT(120LL), 2); heff_drop(v_t_2424); c_; }); heff_drop(v_t_2423); c_; }); heff_drop(v_t_2422); c_; }))) {
              heff_drop_cell(v_ru_24it1_2414_24MkPair, 2);
              heff_drop(v_argv_2419);
              heff_drop(v_t_2421);
              return ({ V a_0 = v_r_240; V a_1 = v_orig_2410; V a_2 = v_x_248; V a_3 = v_f_2416; V a_4 = v_s_241; V a_5 = v_arms_242; V a_6 = v_argv2_2415; V a_7 = v_s_249; V r_ = (g_heff_2ecompile_2esimplify_2efollowerSet(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_248); r_; });
            } else {
              heff_drop(v_r_240);
              heff_drop(v_s_241);
              heff_drop(v_arms_242);
              heff_drop(v_x_248);
              heff_drop(v_argv2_2415);
              heff_drop(v_f_2416);
              heff_drop(v_argv_2419);
              heff_drop(v_t_2421);
              return heff_tag_at_n(v_ru_24it1_2414_24MkPair, TAG_MkPair, 2, (V[]){v_orig_2410, v_s_249});
            }
          } else {
            heff_drop(v_r_240);
            heff_drop(v_s_241);
            heff_drop(v_arms_242);
            heff_drop(v_x_248);
            heff_drop(v_argv2_2415);
            heff_drop(v_f_2416);
            heff_drop(v_t_2418);
            return heff_tag_at_n(v_ru_24it1_2414_24MkPair, TAG_MkPair, 2, (V[]){v_orig_2410, v_s_249});
          }
        }
        default: return heff_nomatch(v_it1_2414);
        }
      } else {
        heff_drop_rec(v_s_244, 9);
        heff_drop(v_x_248);
        heff_drop(v_field_2413);
        return (g_heff_2ecompile_2esimplify_2eboundPushed(v_r_240, v_orig_2410, v_s_241, v_arms_242, v_argv_243, v_s_249));
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2efollowerPushed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efollowerPushed(a[0], a[1], a[2], a[3], a[4]);
}

HeffT2 g_heff_2ecompile_2esimplify_2emadeOne_24cpr(V v_h_240, V v_s_241) {
top: ;
  V v_sp_242 = heff_take_field(v_s_241, 7);
  V v_supply_243 = heff_take_field(v_s_241, 0);
  V v_fuel_244 = heff_take_field(v_s_241, 1);
  V v_defs_245 = heff_take_field(v_s_241, 2);
  V v_safe_246 = heff_take_field(v_s_241, 3);
  V v_base_247 = heff_take_field(v_s_241, 4);
  V v_total_248 = heff_take_field(v_s_241, 5);
  V v_plain_249 = heff_take_field(v_s_241, 6);
  V v_kp_2410 = heff_get_n(v_s_241, 8, 9);
  V v_t_2411 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_sp_242, 4), v_h_240, NTAG(TAG_MkUnit)));
  V v_p_2412 = ({ V rv_4 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_sp_242, 111ULL, 7, shape_all__kinds__recipes__depths__made__count__off, 15615u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_f_2413 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_243, v_fuel_244, v_defs_245, v_safe_246, v_base_247, v_total_248, v_plain_249, v_p_2412, v_kp_2410});
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2413}});
}
V g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2emakeEach_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_h_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 4, 7);
    HeffT2 v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_h_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_m_2416;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_h_242);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        v_m_2416 = ((V)&g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam0_clo);
      } else {
        heff_drop(v_field_247);
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 2, 7);
        HeffT2 v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_h_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_2410); r_; });
        {
          V v_field_2413 = v_t_2411.f[1];
          V v_tag_2412 = heff_box_i64(((int64_t)v_t_2411.f[0]));
          v_m_2416 = heff_clo_n(g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam1, 1, 3, (V[]){v_tag_2412, v_field_2413, v_h_242});
        }
      }
      V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_MkPair: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        V v_s_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        V v_m_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2emakeEach_clo), 1, (V[]){v_rest_243}));
        V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_s_2419}));
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_MkPair: {
          V v_x_2422 = heff_field(v_x2_2421, 0);
          V v_s_2423 = heff_field(v_x2_2421, 1);
          heff_take_n(v_x2_2421, 3ULL, 2);
          V v_x_2424 = (g_heff_2ecompile_2esimplify_2eappendL_24tok2(v_ru_24x1_240_24Cons, v_x_2418, v_x_2422));
          return ((HeffT2){{v_x_2424, v_s_2423}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2421)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2417)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam0(V self, V *args) {
  V v_p_249 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_249});
}
V g_heff_2ecompile_2esimplify_2emakeEach_24cpr_lam1(V self, V *args) {
  V v_p_2414 = args[0];
  V v_tag_2412 = heff_env(self)[0];
  V v_field_2413 = heff_env(self)[1];
  V v_h_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_unbox_i64(v_tag_2412) == ((int64_t)0ULL))) {
    V v_b0_2415 = v_field_2413;
    return (g_heff_2ecompile_2esimplify_2emakeOne(((V)&g_heff_2ecompile_2esimplify_2emakeEach_clo), v_h_242, v_b0_2415, v_p_2414));
  } else {
    heff_drop(v_field_2413);
    heff_drop(v_h_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_2414});
  }
}
Clo g_heff_2ecompile_2esimplify_2eonceEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eonceEach_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eonceEach(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_seen_240, v_x_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_x_242);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        V t_0 = v_seen_240;
        V t_1 = v_xs_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_field_246);
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
        V v_t_249 = (g_std_2emap_2einsert_24s93785294x875597928(v_seen_240, v_x_242, NTAG(TAG_MkUnit)));
        V v_u_2410 = (g_heff_2ecompile_2esimplify_2eonceEach_24dps(v_t_249, v_xs_243, heff_dup(v_cell_248)));
        heff_drop(v_u_2410);
        return v_cell_248;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eonceEach(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eunmade_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eunmade_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eunmade(V v_h_240, V v_s_241) {
top: ;
  V v_sp_242 = heff_take_field(v_s_241, 7);
  V v_supply_243 = heff_take_field(v_s_241, 0);
  V v_fuel_244 = heff_take_field(v_s_241, 1);
  V v_defs_245 = heff_take_field(v_s_241, 2);
  V v_safe_246 = heff_take_field(v_s_241, 3);
  V v_base_247 = heff_take_field(v_s_241, 4);
  V v_total_248 = heff_take_field(v_s_241, 5);
  V v_plain_249 = heff_take_field(v_s_241, 6);
  V v_kp_2410 = heff_get_n(v_s_241, 8, 9);
  HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_sp_242, 2), v_h_240));
  V v_t_2417;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_r_2414 = v_field_2413;
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_2414), NTAG(TAG_Nil)});
      V v_x_2416 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_2415));
      if (heff_intLt_c(MK_INT(1200LL), v_x_2416)) {
        heff_drop(v_r_2414);
        v_t_2417 = (g_std_2emap_2edelete_24s1614046289x1611773644(heff_dup(heff_rfield(v_sp_242, 0)), v_h_240));
      } else {
        v_t_2417 = (g_std_2emap_2einsert_24s93785294x875597928(heff_dup(heff_rfield(v_sp_242, 0)), heff_dup(v_h_240), v_r_2414));
      }
    } else {
      heff_drop(v_field_2413);
      v_t_2417 = heff_dup(heff_rfield(v_sp_242, 0));
    }
  }
  V v_t_2418 = ({ V a_0 = heff_take_field(v_sp_242, 4); V a_1 = v_h_240; V r_ = (g_std_2emap_2edelete_24s1614046289x1611773644(a_0, a_1)); heff_drop(v_h_240); r_; });
  V v_p_2419 = ({ V rv_0 = v_t_2417; V rv_4 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_sp_242, 110ULL, 7, shape_all__kinds__recipes__depths__made__count__off, 15612u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_243, v_fuel_244, v_defs_245, v_safe_246, v_base_247, v_total_248, v_plain_249, v_p_2419, v_kp_2410})});
}
V g_heff_2ecompile_2esimplify_2eunmade_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eunmade(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2esimplify_2ereplayBody_24cpr(V v_k_240, V v_b0_241, V v_s_242) {
top: ;
  V v_key_243 = heff_take_field(v_k_240, 0);
  V v_safe_244 = heff_take_field(v_k_240, 3);
  V v_name_245 = heff_get_n(v_k_240, 1, 7);
  HeffT2 v_t_246 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b0_241, v_s_242));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_x_249 = v_field_247;
    V v_s_2410 = v_field_248;
    HeffT2 v_t_2411 = (g_heff_2ecompile_2esimplify_2erecordDef_24cpr(heff_dup(v_key_243), heff_dup(v_x_249), v_s_2410));
    {
      V v_field_2412 = v_t_2411.f[0];
      V v_field_2413 = v_t_2411.f[1];
      V v_x_2414 = v_field_2412;
      heff_drop(v_x_2414);
      V v_s_2415 = v_field_2413;
      HeffT2 v_t_2416 = ({ V a_0 = v_safe_244; V a_1 = heff_dup(v_key_243); V a_2 = v_s_2415; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2esafeAs_24cpr(a_0, a_1, a_2)); heff_drop(v_safe_244); r_; });
      {
        V v_field_2417 = v_t_2416.f[0];
        V v_field_2418 = v_t_2416.f[1];
        V v_x_2419 = v_field_2417;
        heff_drop(v_x_2419);
        V v_s_2420 = v_field_2418;
        V v_t_2421 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_249)));
        V v_t_2422 = (g_heff_2ecompile_2eir_2enubI(v_t_2421));
        HeffT2 v_t_2423 = (g_heff_2ecompile_2esimplify_2emakeEach_24cpr(v_t_2422, v_s_2420));
        {
          V v_field_2424 = v_t_2423.f[0];
          V v_field_2425 = v_t_2423.f[1];
          V v_x_2426 = v_field_2424;
          V v_s_2427 = v_field_2425;
          V v_m_2428 = (g_heff_2ecompile_2esimplify_2einOrder(heff_dup(v_x_249), v_x_2426));
          V v_x2_2429 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2427}));
          switch (heff_tag_of(v_x2_2429)) {
          case TAG_MkPair: {
            V v_x_2430 = heff_field(v_x2_2429, 0);
            V v_s_2431 = heff_field(v_x2_2429, 1);
            V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
            V v_t_2432 = heff_tag_at_n(v_ru_24x2_2429_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){v_key_243, v_name_245, v_x_249}), NTAG(TAG_Nil)});
            V v_x_2433 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2430, v_t_2432));
            return ((HeffT2){{v_x_2433, v_s_2431}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x2_2429)}});
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_str0, 5, "given");
V g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2(V v_tok_240, V v_r_241, V v_s2_242, V v_arms2_243, V v_arms_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2esimplify_2earmsPushable(MK_INT(40LL), heff_tag_at_n(v_tok_240, TAG_EMatch, 2, (V[]){heff_dup(v_s2_242), heff_dup(v_arms2_243)}), v_arms_244));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_lam0, 1, 4, (V[]){v_r_241, v_arms_244, v_arms2_243, v_s2_242});
  } else {
    heff_drop(v_r_241);
    heff_drop(v_t_245);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_lam1, 1, 3, (V[]){v_arms_244, v_s2_242, v_arms2_243});
  }
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_r_241 = heff_env(self)[0];
  V v_arms_244 = heff_env(self)[1];
  V v_arms2_243 = heff_env(self)[2];
  V v_s2_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_247 = (g_prelude_2etraverse_24s504671899x323346652_24cpr(v_r_241, v_arms_244, v_arms2_243, v_s_246));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x_2410 = v_field_248;
    V v_s_2411 = v_field_249;
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_242, v_x_2410}), v_s_2411});
  }
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_arms_244 = heff_env(self)[0];
  V v_s2_242 = heff_env(self)[1];
  V v_arms2_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_str0), v_s_2412));
  {
    V v_field_2414 = v_t_2413.f[0];
    V v_field_2415 = v_t_2413.f[1];
    V v_x_2416 = v_field_2414;
    V v_s_2417 = v_field_2415;
    V v_t_2418 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2416)}), heff_dup(v_arms_244)});
    HeffT2 v_t_2419 = (g_heff_2ecompile_2esimplify_2egivenSet_24cpr(v_x_2416, heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s2_242), heff_dup(v_arms2_243)}), v_t_2418));
    {
      V v_field_2421 = v_t_2419.f[1];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      V v_t_2423;
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        heff_drop(v_arms_244);
        heff_drop(v_s2_242);
        heff_drop(v_arms2_243);
        V v_x_2422 = v_field_2421;
        v_t_2423 = v_x_2422;
      } else {
        heff_drop(v_field_2421);
        v_t_2423 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_242, v_arms2_243}), v_arms_244});
      }
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_s_2417});
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2efollowOver_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efollowOver_24tok2_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2efollowOver_24tok2(V v_tok_240, V v_a_241, V v_b_242) {
top: ;
  V v_x1_243 = (g_heff_2ecompile_2esimplify_2ewaysOut(heff_dup(v_a_241)));
  V v_x_247;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_ts_244 = heff_field(v_x1_243, 0);
    V v_n_245 = heff_field(v_x1_243, 1);
    heff_take_n(v_x1_243, 3ULL, 2);
    V v_t_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_244; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_244); r_; });
    v_x_247 = heff_intAdd(v_t_246, v_n_245);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  if (heff_intLt_c(MK_INT(1LL), v_x_247)) {
    V v_x1_248 = (g_heff_2ecompile_2esimplify_2ewaysOut(v_a_241));
    V v_t_2412;
    switch (heff_tag_of(v_x1_248)) {
    case TAG_MkPair: {
      V v_ts_249 = heff_field(v_x1_248, 0);
      V v_n_2410 = heff_field(v_x1_248, 1);
      heff_take_n(v_x1_248, 3ULL, 2);
      V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_249; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_249); r_; });
      v_t_2412 = heff_intAdd(v_t_2411, v_n_2410);
      break;
    }
    default: heff_nomatch(v_x1_248);
    }
    V v_lim_2413 = heff_intDiv(MK_INT(100LL), heff_intSub(v_t_2412, MK_INT(1LL)));
    V v_t_2414 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_b_242, NTAG(TAG_Nil)});
    V v_x_2415 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2413), MK_INT(0LL), v_t_2414));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(v_lim_2413, v_x_2415, 0));
    heff_drop(v_lim_2413);
    heff_drop(v_x_2415);
    return v_ret_24bool;
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2esimplify_2efollowOver_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efollowOver_24tok2(a[0], a[1], a[2]);
}