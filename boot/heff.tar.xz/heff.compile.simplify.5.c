// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_Kept 49931
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depth 296830685
#define LBL_depths 611816763
#define LBL_e 319
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipe 1012227257
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_vars 10107635
#define LBL_ver 326173
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_args__vars__holes[] = {LBL_args, LBL_vars, LBL_holes};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_name__ver__recipe__depth__safe__made[] = {LBL_name, LBL_ver, LBL_recipe, LBL_depth, LBL_safe, LBL_made};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2esimplify_2eafresh(V, V);
V g_heff_2ecompile_2esimplify_2eafresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eafresh_clo;
V g_heff_2ecompile_2esimplify_2eallPure(V, V);
V g_heff_2ecompile_2esimplify_2eallPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eallPure_clo;
V g_heff_2ecompile_2esimplify_2eapartW(V, V);
V g_heff_2ecompile_2esimplify_2eapartW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartW_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2eattemptBy(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved(V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_clo;
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V, V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo;
V g_heff_2ecompile_2esimplify_2echeap(V, V, V);
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2echeap_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2ecopyCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyCall_clo;
V g_heff_2ecompile_2esimplify_2ecopyWith(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eetaLoop(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLoop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLoop_clo;
V g_heff_2ecompile_2esimplify_2efieldsBound(V, V);
V g_heff_2ecompile_2esimplify_2efieldsBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldsBound_clo;
V g_heff_2ecompile_2esimplify_2efindField(V, V);
V g_heff_2ecompile_2esimplify_2efindField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efindField_clo;
V g_heff_2ecompile_2esimplify_2efreshName(V, V);
V g_heff_2ecompile_2esimplify_2efreshName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshName_clo;
V g_heff_2ecompile_2esimplify_2efueled(V, V);
V g_heff_2ecompile_2esimplify_2efueled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efueled_clo;
V g_heff_2ecompile_2esimplify_2egrewIn(V, V, V);
V g_heff_2ecompile_2esimplify_2egrewIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrewIn_clo;
V g_heff_2ecompile_2esimplify_2ehandedPast(V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedPast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedPast_clo;
V g_heff_2ecompile_2esimplify_2ehandlerArg(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerArg_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2esimplify_2eknownCopy(V, V, V);
V g_heff_2ecompile_2esimplify_2eknownCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownCopy_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eloopBack(V, V, V);
V g_heff_2ecompile_2esimplify_2eloopBack_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eloopBack_clo;
V g_heff_2ecompile_2esimplify_2emadeOf(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOf_clo;
V g_heff_2ecompile_2esimplify_2emakeEach(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeEach_clo;
V g_heff_2ecompile_2esimplify_2emarkSafe(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkSafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkSafe_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2enoKeep_get(void);
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eonceEach_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_24dps_clo;
V g_heff_2ecompile_2esimplify_2eoneDef(V, V);
V g_heff_2ecompile_2esimplify_2eoneDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneDef_clo;
V g_heff_2ecompile_2esimplify_2eoneItem(V, V);
V g_heff_2ecompile_2esimplify_2eoneItem_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneItem_clo;
V g_heff_2ecompile_2esimplify_2eownSt(V);
V g_heff_2ecompile_2esimplify_2eownSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eownSt_clo;
V g_heff_2ecompile_2esimplify_2epartialMore(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epartialMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialMore_clo;
V g_heff_2ecompile_2esimplify_2eprimAppN(V, V, V);
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo;
V g_heff_2ecompile_2esimplify_2eraise(V, V);
V g_heff_2ecompile_2esimplify_2eraise_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eraise_clo;
V g_heff_2ecompile_2esimplify_2erecordDef(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordDef_clo;
V g_heff_2ecompile_2esimplify_2erefsRetied(V, V, V);
V g_heff_2ecompile_2esimplify_2erefsRetied_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erefsRetied_clo;
V g_heff_2ecompile_2esimplify_2ereplayed(V, V, V);
V g_heff_2ecompile_2esimplify_2ereplayed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ereplayed_clo;
V g_heff_2ecompile_2esimplify_2escrutW(V, V, V);
V g_heff_2ecompile_2esimplify_2escrutW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2escrutW_clo;
V g_heff_2ecompile_2esimplify_2esettleDef(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esettleDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esettleDef_clo;
V g_heff_2ecompile_2esimplify_2eshapeOne(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapeOne_clo;
V g_heff_2ecompile_2esimplify_2eshapesOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo;
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2especKnown(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKnown_clo;
V g_heff_2ecompile_2esimplify_2especLam(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especLam_clo;
V g_heff_2ecompile_2esimplify_2etagBound(V);
V g_heff_2ecompile_2esimplify_2etagBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagBound_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etieDeps(V, V, V);
V g_heff_2ecompile_2esimplify_2etieDeps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieDeps_clo;
V g_heff_2ecompile_2esimplify_2etieGo(V, V, V);
V g_heff_2ecompile_2esimplify_2etieGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieGo_clo;
V g_heff_2ecompile_2esimplify_2etieOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etieOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieOne_clo;
V g_heff_2ecompile_2esimplify_2etoldTo(V, V, V);
V g_heff_2ecompile_2esimplify_2etoldTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etoldTo_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s1726616719x1656908561(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s1726616719x1656908561_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s1726616719x1656908561_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_clo;
V g_heff_2ecompile_2esimplify_2eunOp(V, V);
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunOp_clo;
V g_heff_2ecompile_2esimplify_2eunmade(V, V);
V g_heff_2ecompile_2esimplify_2eunmade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunmade_clo;
V g_heff_2ecompile_2esimplify_2eworthIt(V, V, V);
V g_heff_2ecompile_2esimplify_2eworthIt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eworthIt_clo;
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
V g_list_2eany_24s2090773808x345684111(V, V, V, V, V, V, V, V, V, V);
V g_list_2eany_24s2090773808x345684111_entry(V self, V *a);
extern Clo g_list_2eany_24s2090773808x345684111_clo;
V g_list_2eany_24s392952474x1351014279(V, V);
V g_list_2eany_24s392952474x1351014279_entry(V self, V *a);
extern Clo g_list_2eany_24s392952474x1351014279_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s473401207x1960255357(V);
V g_list_2emap_24s473401207x1960255357_entry(V self, V *a);
extern Clo g_list_2emap_24s473401207x1960255357_clo;
V g_list_2emap_24s549405518x243689326(V);
V g_list_2emap_24s549405518x243689326_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_clo;
V g_list_2ezipWith_24s528321443x971020870(V, V);
V g_list_2ezipWith_24s528321443x971020870_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_clo;
V g_map_2edelete_24s805420727x38051515(V, V);
V g_map_2edelete_24s805420727x38051515_entry(V self, V *a);
extern Clo g_map_2edelete_24s805420727x38051515_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;

static V g_heff_2ecompile_2esimplify_2enoKeep_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2enoKeep_st;
static V g_heff_2ecompile_2esimplify_2enoKeep_init(void) {
  return heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())});
}
V g_heff_2ecompile_2esimplify_2enoKeep_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2enoKeep_st)) return g_heff_2ecompile_2esimplify_2enoKeep_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2enoKeep_val, &g_heff_2ecompile_2esimplify_2enoKeep_st, g_heff_2ecompile_2esimplify_2enoKeep_init);
}
Clo g_heff_2ecompile_2esimplify_2eelemStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eelemStr_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eelemStr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eelemStr(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprimAppN_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eprimAppN(V v_p_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_p_240}), v_as_241});
  }
  case TAG_Just: {
    V v_n_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_241));
    if (heff_intEq_c(v_t_244, heff_dup(v_n_243))) {
      heff_drop(v_n_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      V v_x2_2412;
      switch (heff_tag_of(v_as_241)) {
      case TAG_Nil: {
        v_x2_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_a_246 = heff_dup(heff_field(v_as_241, 0));
        V v_x22_247 = heff_dup(heff_field(v_as_241, 1));
        switch (heff_tag_of(v_x22_247)) {
        case TAG_Nil: {
          v_x2_2412 = (g_heff_2ecompile_2esimplify_2eunOp(heff_dup(v_p_240), v_a_246));
          break;
        }
        case TAG_Cons: {
          V v_b_248 = heff_field(v_x22_247, 0);
          V v_x222_249 = heff_field(v_x22_247, 1);
          heff_take_n(v_x22_247, 3ULL, 2);
          switch (heff_tag_of(v_x222_249)) {
          case TAG_Nil: {
            v_x2_2412 = (g_heff_2ecompile_2esimplify_2ebinOp(heff_dup(v_p_240), v_a_246, v_b_248));
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x222_249, 0ULL, 2);
            heff_drop(v_a_246);
            heff_drop(v_b_248);
            v_x2_2412 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x222_249);
          }
          break;
        }
        default: heff_nomatch(v_x22_247);
        }
        break;
      }
      default: heff_nomatch(v_as_241);
      }
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nothing: {
        return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_as_241});
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        heff_take_n(v_x2_2412, 1ULL, 1);
        heff_drop(v_p_240);
        heff_drop(v_as_241);
        return v_x_2413;
      }
      default: return heff_nomatch(v_x2_2412);
      }
    } else {
      V v_x_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_241));
      if (heff_intLt_c(heff_dup(v_n_243), v_x_2414)) {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        V v_as_2416 = (g_heff_2ecompile_2esimplify_2etakeL(heff_dup(v_n_243), heff_dup(v_as_241)));
        V v_x2_2423;
        switch (heff_tag_of(v_as_2416)) {
        case TAG_Nil: {
          v_x2_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_a_2417 = heff_dup(heff_field(v_as_2416, 0));
          V v_x22_2418 = heff_dup(heff_field(v_as_2416, 1));
          switch (heff_tag_of(v_x22_2418)) {
          case TAG_Nil: {
            v_x2_2423 = (g_heff_2ecompile_2esimplify_2eunOp(heff_dup(v_p_240), v_a_2417));
            break;
          }
          case TAG_Cons: {
            V v_b_2419 = heff_field(v_x22_2418, 0);
            V v_x222_2420 = heff_field(v_x22_2418, 1);
            heff_take_n(v_x22_2418, 3ULL, 2);
            switch (heff_tag_of(v_x222_2420)) {
            case TAG_Nil: {
              v_x2_2423 = (g_heff_2ecompile_2esimplify_2ebinOp(heff_dup(v_p_240), v_a_2417, v_b_2419));
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2420, 0ULL, 2);
              heff_drop(v_a_2417);
              heff_drop(v_b_2419);
              v_x2_2423 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_x222_2420);
            }
            break;
          }
          default: heff_nomatch(v_x22_2418);
          }
          break;
        }
        default: heff_nomatch(v_as_2416);
        }
        V v_t_2425;
        switch (heff_tag_of(v_x2_2423)) {
        case TAG_Nothing: {
          v_t_2425 = heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_as_2416});
          break;
        }
        case TAG_Just: {
          V v_x_2424 = heff_field(v_x2_2423, 0);
          heff_take_n(v_x2_2423, 1ULL, 1);
          heff_drop(v_p_240);
          heff_drop(v_as_2416);
          v_t_2425 = v_x_2424;
          break;
        }
        default: heff_nomatch(v_x2_2423);
        }
        V v_t_2426 = (g_heff_2ecompile_2esimplify_2edropL(v_n_243, v_as_241));
        return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2425, v_t_2426});
      } else {
        heff_drop(v_n_243);
        return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Just, TAG_EPrim, 1, (V[]){v_p_240}), v_as_241});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprimAppN(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eclosedKnown_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eclosedKnown(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
    V v_x_246 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_245));
    if (heff_intLt_c(MK_INT(60LL), v_x_246)) {
      heff_drop(v_xs_243);
      heff_drop(v_b_244);
      return NTAG(TAG_False);
    } else {
      return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244}); V r_ = (g_heff_2ecompile_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x1_240, 0);
    V v_ts_2414 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_ERecord, 2, (V[]){heff_dup(v_fs_2413), heff_dup(v_ts_2414)}), NTAG(TAG_Nil)});
    V v_x_2416 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_2415));
    if (heff_intLt_c(MK_INT(60LL), v_x_2416)) {
      heff_drop(v_fs_2413);
      heff_drop(v_ts_2414);
      return NTAG(TAG_False);
    } else {
      return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_2413, v_ts_2414}); V r_ = (g_heff_2ecompile_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
    }
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eclosedKnown(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandlerLike_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ehandlerLike(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    V v_ts_2411 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_fs_2410)) {
    case TAG_Nil: {
      heff_drop(v_ts_2411);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_t_2414 = (g_list_2emap_24s549405518x243689326(heff_dup(v_fs_2410)));
      V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2414); r_; });
      V v_ret_24bool = heff_bool(((heff_dup(v_t_2415) == NTAG(TAG_True)) && ({ V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){heff_dup(v_fs_2410), heff_dup(v_ts_2411)}), NTAG(TAG_Nil)}); int c_ = ({ V v_x_2417 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), heff_dup(v_t_2416))); int c_ = !heff_intLt_c(MK_INT(60LL), heff_dup(v_x_2417)); heff_drop(v_x_2417); c_; }); heff_drop(v_t_2416); c_; })));
      heff_drop_tag(v_fs_2410, 2);
      heff_drop(v_ts_2411);
      heff_drop(v_t_2415);
      return v_ret_24bool;
    }
    default: return heff_nomatch(v_fs_2410);
    }
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ehandlerLike(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2ehandlerArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandlerArg_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ehandlerArg(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(v_g_243, v_kinds_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_ELam: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EApp: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ELet: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ERecord: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EProj: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ETag: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EMatch: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EPrim: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EPrimCall: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ECall: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EInt: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EFloat: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EStr: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EBytes: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EFixed: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EFloat32: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EAbandon: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EFix: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2ehandlerArg_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ehandlerArg(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshName_str0, 1, "$");
Clo g_heff_2ecompile_2esimplify_2efreshName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efreshName_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efreshName(V v_base_240, V v_s_241) {
top: ;
  V v_n_242 = heff_take_field(v_s_241, 0);
  V v_t_243 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2efreshName_str0), heff_intShow(heff_dup(v_n_242)));
  V v_t_244 = ({ V rv_0 = heff_intAdd(v_n_242, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_s_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_base_240, v_t_243), v_t_244});
}
V g_heff_2ecompile_2esimplify_2efreshName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efreshName(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2escrutW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2escrutW_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2escrutW(V v_x_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_249 = heff_field(v_x31_243, 0);
      V v_as_2410 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI(v_as_2410, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_249, v_t_2411});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2413 = heff_field(v_x31_243, 1);
      V v_b_2414 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2414, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2415;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2416 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2418 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2416, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2418;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2419 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2419, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2424 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2426 = (g_heff_2ecompile_2eir_2eappendI(v_as_2424, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2426;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_sc_2427 = heff_field(v_x31_243, 0);
      V v_arms_2428 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2463;
      switch (heff_tag_of(v_sc_2427)) {
      case TAG_EVar: {
        V v_y_2429 = heff_dup(heff_field(v_sc_2427, 0));
        v_t_2463 = heff_strEq_lent(v_x_240, v_y_2429, 2);
        break;
      }
      case TAG_EGlobal: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_sc_2427);
      }
      V v_t_2464;
      if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
        heff_drop(v_t_2463);
        v_t_2464 = heff_intAdd(v_n_241, MK_INT(1LL));
      } else {
        heff_drop(v_t_2463);
        v_t_2464 = v_n_241;
      }
      V v_t_2465 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2428, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_t_2464;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_sc_2427, v_t_2465});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2468 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2469 = (g_heff_2ecompile_2eir_2eappendI(v_as_2468, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2469;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2471 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2472 = (g_heff_2ecompile_2eir_2eappendI(v_as_2471, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2472;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2escrutW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2escrutW(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2etagBound_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2etagBound_lam19(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etagBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etagBound_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2etagBound(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam0, 1, 1, (V[]){v_e_240});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam1, 1, 1, (V[]){v_e_240});
  }
  case TAG_ELam: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam2, 1, 1, (V[]){v_e_240});
  }
  case TAG_EApp: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam3, 1, 1, (V[]){v_e_240});
  }
  case TAG_ELet: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam4, 1, 1, (V[]){v_e_240});
  }
  case TAG_ERecord: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam5, 1, 1, (V[]){v_e_240});
  }
  case TAG_EProj: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam6, 1, 1, (V[]){v_e_240});
  }
  case TAG_ETag: {
    V v_t_2430 = heff_field(v_e_240, 0);
    V v_as_2431 = heff_field(v_e_240, 1);
    V v_ts_2432 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2433 = (g_heff_2ecompile_2esimplify_2efieldsBound(((V)&g_heff_2ecompile_2esimplify_2etagBound_clo), v_as_2431));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam7, 1, 3, (V[]){v_m_2433, v_t_2430, v_ts_2432});
  }
  case TAG_EMatch: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam8, 1, 1, (V[]){v_e_240});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam9, 1, 1, (V[]){v_e_240});
  }
  case TAG_EPrimCall: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam10, 1, 1, (V[]){v_e_240});
  }
  case TAG_ECall: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam11, 1, 1, (V[]){v_e_240});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam12, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam13, 1, 1, (V[]){v_e_240});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam14, 1, 1, (V[]){v_e_240});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam15, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam16, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam17, 1, 1, (V[]){v_e_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam18, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFix: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etagBound_lam19, 1, 1, (V[]){v_e_240});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2etagBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etagBound(a[0]);
}
V g_heff_2ecompile_2esimplify_2etagBound_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_s_242});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_s_245});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_s_249});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam3(V self, V *args) {
  V v_s_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_s_2413});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam4(V self, V *args) {
  V v_s_2418 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_s_2418});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam5(V self, V *args) {
  V v_s_2422 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_s_2422});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam6(V self, V *args) {
  V v_s_2428 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_s_2428});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam7(V self, V *args) {
  V v_s_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_t_2430 = heff_env(self)[1];
  V v_ts_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_s_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_s_2437 = heff_field(v_x2_2435, 1);
    V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
    V v_t_2440;
    switch (heff_tag_of(v_x_2436)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_dup(heff_field(v_x_2436, 0));
      v_t_2440 = v_x_2438;
      break;
    }
    default: heff_nomatch(v_x_2436);
    }
    V v_t_2443;
    switch (heff_tag_of(v_x_2436)) {
    case TAG_MkPair: {
      V v_y_2442 = heff_field(v_x_2436, 1);
      heff_take_n(v_x_2436, 2ULL, 2);
      v_t_2443 = v_y_2442;
      break;
    }
    default: heff_nomatch(v_x_2436);
    }
    V v_t_2444 = heff_tag_at_n(v_ru_24x2_2435_24MkPair, TAG_MkPair, 2, (V[]){v_t_2440, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2430, v_t_2443, v_ts_2432})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2444, v_s_2437});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ecompile_2esimplify_2etagBound_lam8(V self, V *args) {
  V v_s_2447 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2448, v_s_2447});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam9(V self, V *args) {
  V v_s_2450 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2451, v_s_2450});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam10(V self, V *args) {
  V v_s_2454 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2455 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2455, v_s_2454});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam11(V self, V *args) {
  V v_s_2458 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2459, v_s_2458});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam12(V self, V *args) {
  V v_s_2461 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2462 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2462, v_s_2461});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam13(V self, V *args) {
  V v_s_2464 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2465, v_s_2464});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam14(V self, V *args) {
  V v_s_2467 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2468 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2468, v_s_2467});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam15(V self, V *args) {
  V v_s_2470 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2471 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2471, v_s_2470});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam16(V self, V *args) {
  V v_s_2474 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2475 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2475, v_s_2474});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam17(V self, V *args) {
  V v_s_2477 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2478 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2478, v_s_2477});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam18(V self, V *args) {
  V v_s_2479 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2480 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2480, v_s_2479});
}
V g_heff_2ecompile_2esimplify_2etagBound_lam19(V self, V *args) {
  V v_s_2483 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2484 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2484, v_s_2483});
}
Clo g_heff_2ecompile_2esimplify_2etoldTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etoldTo_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etoldTo(V v_b_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_b_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_b_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x3_242, 0);
      V v_as_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_2441;
      switch (heff_tag_of(v_a_245)) {
      case TAG_EVar: {
        heff_take_n(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_a_245, 0ULL, 3);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_a_245, 0ULL, 4);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_a_245, 0ULL, 3);
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_na(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_a_245, 0ULL, 1);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_a_245, 0ULL, 2);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
        heff_drop(v_t_2441);
        V v_t_2442 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)});
        V v_t_2443 = (g_heff_2ecompile_2esimplify_2eapartW(v_x_243, v_t_2442));
        if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
          heff_drop(v_b_240);
          heff_drop(v_xs_244);
          heff_drop(v_as_246);
          heff_drop(v_t_2443);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2443);
          V t_0 = v_b_240;
          V t_1 = v_xs_244;
          V t_2 = v_as_246;
          v_b_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2441);
        V t_0 = v_b_240;
        V t_1 = v_xs_244;
        V t_2 = v_as_246;
        v_b_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etoldTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etoldTo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ecopyCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyCall_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecopyCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_244, 7)), 1, 7);
  V v_t_246 = (g_heff_2ecompile_2esimplify_2eknownCopy(heff_dup(v_s_244), v_g_242, heff_dup(v_as_243)));
  V v_t_247 = ({ V a_0 = v_t_245; V a_1 = heff_dup(v_as_243); V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2esimplify_2eworthIt(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  V v_x2_248 = (g_heff_2ecompile_2esimplify_2efueled(v_t_247, heff_dup(v_s_244)));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_more_2414;
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nothing: {
      heff_drop_rec(v_s_244, 9);
      v_more_2414 = MK_INT(24LL);
      break;
    }
    case TAG_Just: {
      V v_b_2411 = heff_dup(heff_field(v_x_249, 0));
      V v_t_2412 = heff_get_n(heff_get_n(v_s_244, 7, 9), 1, 7);
      V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_b_2411; V a_2 = heff_dup(v_as_243); V r_ = (g_heff_2ecompile_2esimplify_2ehandedPast(a_0, a_1, a_2)); heff_drop(v_t_2412); heff_drop(v_b_2411); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        v_more_2414 = MK_INT(160LL);
      } else {
        heff_drop(v_t_2413);
        v_more_2414 = MK_INT(24LL);
      }
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      heff_drop(v_more_2414);
      V v_x_2415 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_s_2410});
    }
    case TAG_Just: {
      V v_b_2416 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_248_24MkPair, 2);
      V v_t_2417 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_243)));
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2416, v_as_243}));
      return (g_heff_2ecompile_2esimplify_2eattemptBy(v_more_2414, v_t_2417, v_t_2418, v_s_2410));
    }
    default: return heff_nomatch(v_x_249);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2esimplify_2ecopyCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecopyCall(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eloopBack_str0, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eloopBack_str1, 2, "$s");
Clo g_heff_2ecompile_2esimplify_2eloopBack_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eloopBack_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eloopBack(V v_all_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x3_242, 0);
    V v_x32_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24ELam = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x32_246)) {
    case TAG_EVar: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      V v_x321_2411 = heff_field(v_x32_246, 0);
      V v_as_2412 = heff_field(v_x32_246, 1);
      V v_ru_24x32_246_24EApp = heff_take_reuse_n(v_x32_246, 3ULL, 2);
      switch (heff_tag_of(v_x321_2411)) {
      case TAG_EVar: {
        heff_take_n(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        V v_h_2414 = heff_field(v_x321_2411, 0);
        heff_take_n(v_x321_2411, 1ULL, 1);
        V v_t_2415 = (g_list_2emap_24s473401207x1960255357(heff_dup(v_as_2412)));
        V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2415); r_; });
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop(v_t_2416);
          V v_t_2417 = heff_tag_at_n(v_ru_24x32_246_24EApp, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){heff_dup(v_h_2414)}), v_as_2412});
          V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24ELam, TAG_ELam, 2, (V[]){v_xs_245, v_t_2417}), NTAG(TAG_Nil)});
          V v_x_2419 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_2418));
          if (heff_intLt_c(MK_INT(60LL), v_x_2419)) {
            heff_drop(v_g_241);
            heff_drop(v_h_2414);
            return NTAG(TAG_False);
          } else {
            V v_t_2421 = (g_map_2elookup_24s1546226666x2146984184(v_h_2414, v_all_240));
            switch (heff_tag_of(v_t_2421)) {
            case TAG_Nothing: {
              heff_drop(v_g_241);
              return NTAG(TAG_False);
            }
            case TAG_Just: {
              V v_b_2422 = heff_field(v_t_2421, 0);
              heff_take_n(v_t_2421, 1ULL, 1);
              V v_t_2423 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2422));
              V v_t_2424 = (g_heff_2ecompile_2eir_2enubI(v_t_2423));
              return ({ V a_0 = ((V)&g_heff_2ecompile_2esimplify_2eloopBack_str0); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ecompile_2esimplify_2eloopBack_str1); V a_5 = v_g_241; V a_6 = MK_INT(0LL); V a_7 = MK_INT(0LL); V a_8 = MK_INT(0LL); V a_9 = v_t_2424; V r_ = (g_list_2eany_24s2090773808x345684111(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_t_2424); r_; });
            }
            default: return heff_nomatch(v_t_2421);
            }
          }
        } else {
          heff_drop(v_g_241);
          heff_drop(v_xs_245);
          heff_drop_cell(v_ru_24x3_242_24ELam, 2);
          heff_drop(v_as_2412);
          heff_drop_cell(v_ru_24x32_246_24EApp, 2);
          heff_drop(v_h_2414);
          heff_drop(v_t_2416);
          return NTAG(TAG_False);
        }
      }
      case TAG_ELam: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        heff_take_n(v_x321_2411, 0ULL, 3);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_take_n(v_x321_2411, 0ULL, 4);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_take_n(v_x321_2411, 0ULL, 3);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_take_n(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_take_n(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_take_na(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_take_n(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_take_n(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_take_na(v_x321_2411, 0ULL, 1);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_take_n(v_x321_2411, 0ULL, 2);
        heff_drop(v_g_241);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x3_242_24ELam, 2);
        heff_drop(v_as_2412);
        heff_drop_cell(v_ru_24x32_246_24EApp, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x321_2411);
      }
    }
    case TAG_ELet: {
      heff_take_n(v_x32_246, 0ULL, 3);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_x32_246, 0ULL, 4);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_x32_246, 0ULL, 3);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_na(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_take_n(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x32_246, 0ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_x32_246, 0ULL, 2);
      heff_drop(v_g_241);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x32_246);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x3_242, 0ULL, 4);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eloopBack_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eloopBack(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eshapesOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eshapesOf(V v_x1_240, V v_as_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_as_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_p_242});
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_ms_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      heff_drop(v_m_244);
      heff_drop(v_ms_245);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_246 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_as_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_p_242});
    }
    case TAG_Cons: {
      V v_a_247 = heff_field(v_as_241, 0);
      V v_as2_248 = heff_field(v_as_241, 1);
      V v_ru_24as_241_24Cons = heff_take_reuse_n(v_as_241, 3ULL, 2);
      V v_x2_249 = ({ V a_0 = v_m_244; V a_1 = v_a_247; V a_2 = v_p_242; V r_ = (g_heff_2ecompile_2esimplify_2eshapeOne(a_0, a_1, a_2)); heff_drop(v_m_244); r_; });
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        V v_s_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 3ULL, 2);
        V v_m_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eshapesOf_clo), 2, (V[]){v_ms_245, v_as2_248}));
        V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
        switch (heff_tag_of(v_x2_2413)) {
        case TAG_MkPair: {
          V v_x_2414 = heff_field(v_x2_2413, 0);
          V v_s_2415 = heff_field(v_x2_2413, 1);
          heff_take_n(v_x2_2413, 3ULL, 2);
          V v_t_2416 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2410, 0)), heff_dup(heff_rfield(v_x_2414, 0))});
          V v_t_2417 = (g_heff_2ecompile_2esimplify_2eappendL(heff_take_field(v_x_2410, 1), heff_take_field(v_x_2414, 1)));
          V v_t_2418 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_x_2410, 2, 4), heff_get_n(v_x_2414, 2, 3)));
          V v_x_2419 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_t_2416, v_t_2417, v_t_2418});
          return heff_tag_at_n(v_ru_24as_241_24Cons, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2415});
        }
        default: return heff_nomatch(v_x2_2413);
        }
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_as_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eshapesOf(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2epartialMore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialMore_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2epartialMore(V v_safe_240, V v_all_241, V v_g_242, V v_as_243) {
top: ;
  V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, heff_dup(v_all_241)}));
  V v_t_245 = (g_list_2emap(v_t_244, heff_dup(v_as_243)));
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_245); r_; });
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_x_247 = (g_heff_2ecompile_2esimplify_2earityIn(v_all_241, heff_dup(v_g_242)));
    V v_y_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
    if (heff_intLt_c(v_y_248, v_x_247)) {
      V v_t_2410 = ({ V a_0 = v_all_241; V a_1 = v_g_242; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_all_241); r_; });
      V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_as_243); r_; });
      return heff_intSub(v_t_2410, v_t_2411);
    } else {
      heff_drop(v_all_241);
      heff_drop(v_g_242);
      heff_drop(v_as_243);
      return MK_INT(0LL);
    }
  } else {
    heff_drop(v_all_241);
    heff_drop(v_g_242);
    heff_drop(v_as_243);
    heff_drop(v_t_246);
    return MK_INT(0LL);
  }
}
V g_heff_2ecompile_2esimplify_2epartialMore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epartialMore(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2especLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especLam_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2especLam(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_s_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 6, 7);
  V v_t_248 = heff_bool(((heff_dup(v_t_246) == NTAG(TAG_True)) || ({ V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 5, 7); int c_ = heff_intLe_c(MK_INT(50000LL), heff_dup(v_t_247)); heff_drop(v_t_247); c_; })));
  heff_drop(v_t_246);
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_t_248);
    V v_x_249 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_245});
  } else {
    heff_drop(v_t_248);
    V v_t_2410 = (g_list_2eany_24s392952474x1351014279(heff_dup(v_s_245), v_as_244));
    V v_x2_2416;
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V v_t_2411 = (g_heff_2ecompile_2esimplify_2ebeforeMoved(heff_dup(v_s_245), heff_dup(v_as_244)));
      V v_x2_2412 = (g_heff_2ecompile_2esimplify_2eallPure(v_t_2411, v_s_245));
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_MkPair: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_s_2414 = heff_field(v_x2_2412, 1);
        heff_take_n(v_x2_2412, 3ULL, 2);
        v_x2_2416 = ({ V a_0 = heff_dup(v_r_240); V a_1 = heff_dup(v_g_241); V a_2 = heff_dup(v_xs_242); V a_3 = heff_dup(v_b_243); V a_4 = heff_dup(v_as_244); V a_5 = v_x_2413; V a_6 = v_s_2414; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2eetaLoop(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2413); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2412);
      }
    } else {
      heff_drop(v_t_2410);
      V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_as_244)});
      v_x2_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_s_245});
    }
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_s_2418 = heff_field(v_x2_2416, 1);
      V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
      switch (heff_tag_of(v_x_2417)) {
      case TAG_MkPair: {
        V v_bds_2419 = heff_field(v_x_2417, 0);
        V v_as_2420 = heff_field(v_x_2417, 1);
        heff_take_n(v_x_2417, 3ULL, 2);
        V v_t_2421 = (g_list_2ezipWith_24s528321443x971020870(v_as_244, heff_dup(v_as_2420)));
        V v_x2_2422 = heff_tr(g_heff_2ecompile_2esimplify_2especKnown(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_2420, v_t_2421, v_s_2418));
        switch (heff_tag_of(v_x2_2422)) {
        case TAG_MkPair: {
          V v_x_2423 = heff_field(v_x2_2422, 0);
          V v_s_2424 = heff_field(v_x2_2422, 1);
          heff_take_n(v_x2_2422, 3ULL, 2);
          V v_x_2425 = ({ V a_0 = v_bds_2419; V a_1 = v_x_2423; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_bds_2419); r_; });
          return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){v_x_2425, v_s_2424});
        }
        default: return heff_nomatch(v_x2_2422);
        }
      }
      default: return heff_nomatch(v_x_2417);
      }
    }
    default: return heff_nomatch(v_x2_2416);
    }
  }
}
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especLam(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2esimplify_2efindField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efindField_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efindField(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c_lent(v_k_244, v_l_240, 0)) {
        heff_drop(v_l_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      } else {
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efindField_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efindField(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2etieOne_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieOne_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieOne_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etieOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etieOne_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2etieOne(V v_h_240, V v_calls_241, V v_hb_242, V v_d_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2esimplify_2eelemStr(heff_dup(heff_rfield(v_d_243, 0)), v_calls_241));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_243, 2))));
    V v_t_246 = (g_heff_2ecompile_2eir_2enubI(v_t_245));
    V v_t_247 = ({ V a_0 = heff_dup(v_h_240); V a_1 = v_t_246; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_246); r_; });
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_m_248 = (g_heff_2ecompile_2esimplify_2etieGo(v_h_240, v_hb_242, heff_dup(heff_rfield(v_d_243, 2))));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieOne_lam0, 1, 2, (V[]){v_m_248, v_d_243});
    } else {
      heff_drop(v_h_240);
      heff_drop(v_hb_242);
      heff_drop(v_t_247);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieOne_lam1, 1, 1, (V[]){v_d_243});
    }
  } else {
    heff_drop(v_h_240);
    heff_drop(v_hb_242);
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieOne_lam2, 1, 1, (V[]){v_d_243});
  }
}
V g_heff_2ecompile_2esimplify_2etieOne_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2etieOne(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2etieOne_lam0(V self, V *args) {
  V v_s_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_x2_2413 = (g_heff_2ecompile_2esimplify_2erefsRetied(heff_dup(heff_rfield(v_d_243, 0)), heff_dup(v_x_2411), v_s_2412));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_s_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 2ULL, 2);
      V v_t_2416 = ({ V rv_2 = v_x_2411; V rr_ = heff_rec_reuse_nf(v_d_243, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2416, v_s_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2esimplify_2etieOne_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_243, v_s_2417});
}
V g_heff_2ecompile_2esimplify_2etieOne_lam2(V self, V *args) {
  V v_s_2418 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_243, v_s_2418});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam21(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etieDeps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etieDeps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etieDeps(V v_h_240, V v_hb_241, V v_deps_242) {
top: ;
  switch (heff_tag_of(v_hb_241)) {
  case TAG_EVar: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam0, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EGlobal: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam1, 1, 1, (V[]){v_deps_242});
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_hb_241, 0);
    V v_b_248 = heff_field(v_hb_241, 1);
    V v_ru_24hb_241_24ELam = heff_take_reuse_n(v_hb_241, 3ULL, 2);
    switch (heff_tag_of(v_deps_242)) {
    case TAG_Nil: {
      heff_drop(v_h_240);
      heff_drop(v_xs_247);
      heff_drop(v_b_248);
      heff_drop_cell(v_ru_24hb_241_24ELam, 2);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam2, 1, 1, (V[]){v_deps_242});
    }
    case TAG_Cons: {
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24hb_241_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_247), heff_dup(v_b_248)}), NTAG(TAG_Nil)});
      V v_x_2413 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(50LL), MK_INT(0LL), v_t_2412));
      if (heff_intLt_c(MK_INT(50LL), v_x_2413)) {
        heff_drop(v_h_240);
        heff_drop(v_xs_247);
        heff_drop(v_b_248);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam3, 1, 1, (V[]){v_deps_242});
      } else {
        V v_t_2416 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_248)));
        V v_t_2417 = (g_heff_2ecompile_2eir_2enubI(v_t_2416));
        V v_x1_2418 = ({ V a_0 = heff_dup(v_h_240); V a_1 = v_t_2417; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2417); r_; });
        if ((heff_dup(v_x1_2418) == NTAG(TAG_True))) {
          heff_drop(v_h_240);
          heff_drop(v_xs_247);
          heff_drop(v_b_248);
          heff_drop(v_x1_2418);
          return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam4, 1, 1, (V[]){v_deps_242});
        } else {
          heff_drop(v_x1_2418);
          V v_t_2420 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_248)));
          V v_t_2421 = (g_heff_2ecompile_2eir_2enubI(v_t_2420));
          return ({ V a_0 = v_h_240; V a_1 = v_t_2421; V a_2 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_247, v_b_248}); V a_3 = v_deps_242; V r_ = (g_heff_2ecompile_2esimplify_2etraverseS_24s1726616719x1656908561(a_0, a_1, a_2, a_3)); heff_drop(v_t_2421); r_; });
        }
      }
    }
    default: return heff_nomatch(v_deps_242);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam5, 1, 1, (V[]){v_deps_242});
  }
  case TAG_ELet: {
    heff_take_n(v_hb_241, 0ULL, 3);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam6, 1, 1, (V[]){v_deps_242});
  }
  case TAG_ERecord: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam7, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EProj: {
    heff_take_n(v_hb_241, 0ULL, 4);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam8, 1, 1, (V[]){v_deps_242});
  }
  case TAG_ETag: {
    heff_take_n(v_hb_241, 0ULL, 3);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam9, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EMatch: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam10, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EPrim: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam11, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam12, 1, 1, (V[]){v_deps_242});
  }
  case TAG_ECall: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam13, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EInt: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam14, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EFloat: {
    heff_take_na(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam15, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EStr: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam16, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EBytes: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam17, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EFixed: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam18, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EFloat32: {
    heff_take_na(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam19, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam20, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EFix: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam21, 1, 1, (V[]){v_deps_242});
  }
  default: return heff_nomatch(v_hb_241);
  }
}
V g_heff_2ecompile_2esimplify_2etieDeps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etieDeps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_244});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_246});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_249});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam3(V self, V *args) {
  V v_s_2415 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2415});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam4(V self, V *args) {
  V v_s_2419 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2419});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam5(V self, V *args) {
  V v_s_2424 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2424});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam6(V self, V *args) {
  V v_s_2428 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2428});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam7(V self, V *args) {
  V v_s_2431 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2431});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam8(V self, V *args) {
  V v_s_2436 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2436});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam9(V self, V *args) {
  V v_s_2440 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2440});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam10(V self, V *args) {
  V v_s_2443 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2443});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam11(V self, V *args) {
  V v_s_2445 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2445});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam12(V self, V *args) {
  V v_s_2448 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2448});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam13(V self, V *args) {
  V v_s_2451 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2451});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam14(V self, V *args) {
  V v_s_2453 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2453});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam15(V self, V *args) {
  V v_s_2455 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2455});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam16(V self, V *args) {
  V v_s_2457 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2457});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam17(V self, V *args) {
  V v_s_2459 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2459});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam18(V self, V *args) {
  V v_s_2462 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2462});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam19(V self, V *args) {
  V v_s_2464 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2464});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam20(V self, V *args) {
  V v_s_2465 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2465});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam21(V self, V *args) {
  V v_s_2468 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2468});
}
Clo g_heff_2ecompile_2esimplify_2eonceEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eonceEach_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eonceEach(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), v_seen_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(v_x_242, NTAG(TAG_MkUnit), v_seen_240));
      V v_u_247 = (g_heff_2ecompile_2esimplify_2eonceEach_24dps(v_t_246, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_247);
      return v_cell_245;
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_xs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eonceEach(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eunmade_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eunmade_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eunmade(V v_h_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_243 = ({ V a_0 = heff_dup(v_h_240); V a_1 = v_t_242; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_242); r_; });
  V v_t_2410;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
    break;
  }
  case TAG_Just: {
    V v_r_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_244), NTAG(TAG_Nil)});
    V v_x_246 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_245));
    if (heff_intLt_c(MK_INT(1200LL), v_x_246)) {
      heff_drop(v_r_244);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
      v_t_2410 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_h_240), v_t_248));
    } else {
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
      v_t_2410 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), v_r_244, v_t_249));
    }
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 1, 7);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 3, 7);
  V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 4, 7);
  V v_t_2415 = (g_map_2edelete_24s805420727x38051515(v_h_240, v_t_2414));
  V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 5, 7);
  V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 6, 7);
  V v_p_2418 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_2410, v_t_2411, v_t_2412, v_t_2413, v_t_2415, v_t_2416, v_t_2417});
  V v_t_2419 = ({ V rv_7 = v_p_2418; V rr_ = heff_rec_reuse_nf(v_s_241, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2419});
}
V g_heff_2ecompile_2esimplify_2eunmade_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eunmade(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2esettleDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esettleDef_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esettleDef(V v_n_240, V v_key_241, V v_b_242, V v_s_243) {
top: ;
  V v_x2_244 = (g_heff_2ecompile_2esimplify_2erecordDef(heff_dup(v_key_241), heff_dup(v_b_242), v_s_243));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_s_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 2ULL, 2);
    V v_x2_247 = (g_heff_2ecompile_2esimplify_2emarkSafe(heff_dup(v_key_241), v_b_242, v_s_246));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_s_249 = heff_field(v_x2_247, 1);
      V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 2ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_242)));
      V v_t_2411 = (g_heff_2ecompile_2eir_2enubI(v_t_2410));
      V v_x2_2412 = (g_heff_2ecompile_2esimplify_2emakeEach(v_t_2411, heff_dup(v_s_249)));
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_MkPair: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_s_2414 = heff_field(v_x2_2412, 1);
        heff_take_n(v_x2_2412, 3ULL, 2);
        V v_t_2416;
        if (heff_intLt_c(MK_INT(0LL), heff_dup(v_n_240))) {
          v_t_2416 = (g_heff_2ecompile_2esimplify_2egrewIn(v_s_249, heff_dup(v_s_2414), heff_dup(v_b_242)));
        } else {
          heff_drop(v_s_249);
          v_t_2416 = NTAG(TAG_False);
        }
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop(v_t_2416);
          V v_t_2417 = (g_heff_2ecompile_2esimplify_2eownSt(v_s_2414));
          switch (heff_tag_of(v_t_2417)) {
          case TAG_MkPair: {
            V v_s_2419 = heff_field(v_t_2417, 1);
            heff_take_n(v_t_2417, 2ULL, 2);
            V v_m_2420 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_b_242));
            V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_s_2419}));
            switch (heff_tag_of(v_x2_2421)) {
            case TAG_MkPair: {
              V v_x_2422 = heff_field(v_x2_2421, 0);
              V v_s_2423 = heff_field(v_x2_2421, 1);
              heff_take_n(v_x2_2421, 3ULL, 2);
              V v_x2_2424 = (g_heff_2ecompile_2esimplify_2eraise(v_x_2422, v_s_2423));
              switch (heff_tag_of(v_x2_2424)) {
              case TAG_MkPair: {
                V v_x_2425 = heff_field(v_x2_2424, 0);
                V v_s_2426 = heff_field(v_x2_2424, 1);
                heff_take_n(v_x2_2424, 3ULL, 2);
                V v_m_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esettleDef_clo), 3, (V[]){heff_intSub(v_n_240, MK_INT(1LL)), v_key_241, v_x_2425}));
                V v_x2_2428 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_s_2426}));
                switch (heff_tag_of(v_x2_2428)) {
                case TAG_MkPair: {
                  V v_x_2429 = heff_field(v_x2_2428, 0);
                  V v_s_2430 = heff_field(v_x2_2428, 1);
                  heff_take_n(v_x2_2428, 3ULL, 2);
                  V v_t_2433;
                  switch (heff_tag_of(v_x_2429)) {
                  case TAG_MkPair: {
                    V v_x_2431 = heff_dup(heff_field(v_x_2429, 0));
                    v_t_2433 = v_x_2431;
                    break;
                  }
                  default: heff_nomatch(v_x_2429);
                  }
                  V v_t_2436;
                  switch (heff_tag_of(v_x_2429)) {
                  case TAG_MkPair: {
                    V v_y_2435 = heff_field(v_x_2429, 1);
                    heff_take_n(v_x_2429, 2ULL, 2);
                    v_t_2436 = v_y_2435;
                    break;
                  }
                  default: heff_nomatch(v_x_2429);
                  }
                  V v_t_2437 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2413, v_t_2436));
                  V v_x_2438 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_t_2433, v_t_2437});
                  return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_2438, v_s_2430});
                }
                default: return heff_nomatch(v_x2_2428);
                }
              }
              default: return heff_nomatch(v_x2_2424);
              }
            }
            default: return heff_nomatch(v_x2_2421);
            }
          }
          default: return heff_nomatch(v_t_2417);
          }
        } else {
          heff_drop(v_n_240);
          heff_drop(v_key_241);
          heff_drop_cell(v_ru_24x2_247_24MkPair, 2);
          heff_drop(v_t_2416);
          return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b_242, v_x_2413}), v_s_2414});
        }
      }
      default: return heff_nomatch(v_x2_2412);
      }
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2esimplify_2esettleDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esettleDef(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2eoneItem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eoneItem_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eoneItem(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Fresh: {
    V v_d_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eoneDef(v_d_242, v_p_241);
  }
  case TAG_Kept: {
    V v_k_243 = heff_field(v_x1_240, 0);
    V v_redo_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Kept = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_243, 2)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_x2_246 = (g_heff_2ecompile_2esimplify_2ereplayed(v_k_243, v_t_245, heff_dup(v_p_241)));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_s_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      switch (heff_tag_of(v_x_247)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Kept, 2);
        heff_drop(v_s_248);
        heff_drop_cell(v_ru_24x2_246_24MkPair, 2);
        V v_t_249 = heff_tr(heff_call(v_redo_244, 1, (V[]){heff_dup(heff_rfield(v_p_241, 0))}));
        HEFF_LAST return g_heff_2ecompile_2esimplify_2eafresh(v_t_249, v_p_241);
      }
      case TAG_Just: {
        V v_ds_2410 = heff_field(v_x_247, 0);
        heff_take_n(v_x_247, 1ULL, 1);
        heff_drop_rec(v_p_241, 9);
        heff_drop(v_redo_244);
        V v_t_2411 = heff_tag_at_n(v_ru_24x1_240_24Kept, TAG_MkPair, 2, (V[]){v_ds_2410, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_2411, v_s_248});
      }
      default: return heff_nomatch(v_x_247);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eoneItem_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eoneItem(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyWith_str0, 0, "");
Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyWith_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecopyWith(V v_st_240, V v_bodies_241, V v_h_242, V v_v_243, V v_r_244) {
top: ;
  if (heff_strEq_c_lent(v_v_243, ((V)&g_heff_2ecompile_2esimplify_2ecopyWith_str0), 2)) {
    heff_drop_rec(v_st_240, 9);
    heff_drop(v_h_242);
    heff_drop(v_v_243);
    heff_drop(v_r_244);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_st_240, 7)), 3, 7);
    V v_x2_247 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_246; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_t_249;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_t_249 = MK_INT(0LL);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_x3_2410 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_h_242), heff_rfield(v_st_240, 4)));
    V v_t_2412;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nothing: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2410, 0ULL, 1);
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    V v_t_2413 = (g_heff_2ecompile_2esimplify_2emadeOf(v_st_240, v_bodies_241, heff_dup(v_h_242)));
    return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(6, shape_name__ver__recipe__depth__safe__made, (V[]){v_h_242, v_v_243, v_r_244, v_t_249, v_t_2412, v_t_2413})});
  }
}
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ecopyWith(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecatMaybesS_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ecatMaybesS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecatMaybesS(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = (g_heff_2ecompile_2esimplify_2eoneItem(v_x_242, v_p_241));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      V v_x2_247 = (g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(v_xs_243, v_s_246));
      switch (heff_tag_of(v_x2_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_s_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_x_248}), v_s_249});
      }
      default: return heff_nomatch(v_x2_247);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(a[0], a[1]);
}