// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_DeclareField 57313
#define TAG_EMatch 41631
#define TAG_EQ 8989
#define TAG_EVar 52881
#define TAG_GT 9054
#define TAG_LT 9209
#define TAG_Lam0_24prelude_2etraverse_24s1310917876x950458632_24apply2 1348
#define TAG_Lam1_24prelude_2etraverse_24s1310917876x950458632_24apply2 9167
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_OfRecords 55355
#define TAG_OfTags 60669
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_RLocal 34280
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_SetField 47531
#define TAG_Throw 56084
#define TAG_Tip 31527
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_compare 1182341923
#define LBL_consumers 1203455020
#define LBL_count 296209705
#define LBL_def 308863
#define LBL_dflt 9576017
#define LBL_end 310101
#define LBL_eq 10003
#define LBL_equal 298115918
#define LBL_exp 310423
#define LBL_fixed 298804110
#define LBL_fresh 299054408
#define LBL_key 315609
#define LBL_le 10208
#define LBL_left 9813198
#define LBL_lt 10223
#define LBL_made 9839068
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nameSpan 438211216
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_owner 307523277
#define LBL_pats 9928951
#define LBL_producers 572620898
#define LBL_rhs 322423
#define LBL_severity 75955546
#define LBL_slots 310891087
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_supply 1056026650
#define LBL_typ 324869
#define LBL_underLam 296337946
static uint32_t shape_chk__span[] = {LBL_chk, LBL_span};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_def__slots[] = {LBL_def, LBL_slots};
static uint32_t shape_eq__compare__lt__le[] = {LBL_eq, LBL_compare, LBL_lt, LBL_le};
static uint32_t shape_equal[] = {LBL_equal};
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_name__chk__span__nameSpan[] = {LBL_name, LBL_chk, LBL_span, LBL_nameSpan};
static uint32_t shape_name__typ__dflt[] = {LBL_name, LBL_typ, LBL_dflt};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_supply__consumers__producers__made__fresh__left[] = {LBL_supply, LBL_consumers, LBL_producers, LBL_made, LBL_fresh, LBL_left};
V g_co_2ebind_24s196996678x1811735276(V, V, V);
V g_co_2ebind_24s196996678x1811735276_entry(V self, V *a);
extern Clo g_co_2ebind_24s196996678x1811735276_clo;
V g_heff_2ebuild_2edriver_2elineStart(V, V);
V g_heff_2ebuild_2edriver_2elineStart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elineStart_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2efields_2egoLate(V, V);
V g_heff_2ecompile_2efields_2egoLate_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2egoLate_clo;
V g_heff_2ecompile_2efields_2enumbersW(V, V);
V g_heff_2ecompile_2efields_2enumbersW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2enumbersW_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_clo;
V g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(V);
V g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905_clo;
V g_heff_2ecompile_2erematch_2ematchOf(V, V);
V g_heff_2ecompile_2erematch_2ematchOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_clo;
V g_heff_2ecompile_2erematch_2ematchOf_24tok2(V, V, V);
V g_heff_2ecompile_2erematch_2ematchOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_24tok2_clo;
V g_heff_2ecompile_2erunes_2edefOf(V);
V g_heff_2ecompile_2erunes_2edefOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2edefOf_clo;
V g_heff_2ecompile_2escalars_2edefWith(V, V, V);
V g_heff_2ecompile_2escalars_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2edefWith_clo;
V g_heff_2ecompile_2escalars_2efoundWith(V, V, V);
V g_heff_2ecompile_2escalars_2efoundWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2efoundWith_clo;
V g_heff_2ecompile_2escalars_2eslotsOf(V, V);
V g_heff_2ecompile_2escalars_2eslotsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotsOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eoneDef_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
HeffT2 g_heff_2ecompile_2espec_2eshapeGo_24cpr(V, V);
V g_heff_2ecompile_2etrmc_2edefT(V);
V g_heff_2ecompile_2etrmc_2edefT_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2edefT_clo;
HeffT2 g_heff_2eelab_2eclauses_2epat_24cpr(V);
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2ezipWith_24s1928181476x241816070(V, V);
V g_list_2ezipWith_24s1928181476x241816070_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1057423371x1101358195(V, V);
V g_prelude_2e_2b_2b_24f1057423371x1101358195_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_clo;
V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716(V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_clo;
V g_prelude_2e_2b_2b_24f1206589350x791019229(V, V, V);
V g_prelude_2e_2b_2b_24f1206589350x791019229_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1206589350x791019229_clo;
V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_clo;
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054(V, V, V);
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_clo;
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps_clo;
V g_prelude_2e_2b_2b_24f1960751014x547354513(V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1960751014x547354513_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1960751014x547354513_clo;
V g_prelude_2e_2b_2b_24f1960751014x547354513_24dps(V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1960751014x547354513_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1960751014x547354513_24dps_clo;
V g_prelude_2e_2b_2b_24f292729551x60683815(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f292729551x60683815_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f292729551x60683815_clo;
V g_prelude_2e_2b_2b_24f292729551x60683815_24dps(V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f292729551x60683815_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f292729551x60683815_24dps_clo;
V g_prelude_2e_2b_2b_24f427551988x255400191(V, V);
V g_prelude_2e_2b_2b_24f427551988x255400191_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f427551988x255400191_clo;
V g_prelude_2e_2b_2b_24f427551988x255400191_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f427551988x255400191_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f427551988x255400191_24dps_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_clo;
V g_prelude_2e_2b_2b_24f543054808x1503188303(V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f543054808x1503188303_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f543054808x1503188303_clo;
V g_prelude_2e_2b_2b_24f543054808x1503188303_24dps(V, V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_clo;
V g_prelude_2e_2b_2b_24f603353378x1069129212_24dps(V, V, V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f603353378x1069129212_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f603353378x1069129212_24dps_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250(V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636(V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_24dps_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2einstanceOrderPair_24s757960770x1263704829_get(void);
V g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036(V, V);
V g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036_entry(V self, V *a);
extern Clo g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036_clo;
V g_prelude_2eorderByCompare_24s1329979559x1043691411_get(void);
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
HeffT2 g_prelude_2etraverse_24s1144925704x1514729383_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1144925704x1514729383_24dps_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s1159166259x948777116_24dps_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s1206798274x929612205_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1206798274x929612205_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s1212489961x1573143196(V, V, V);
V g_prelude_2etraverse_24s1212489961x1573143196_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1212489961x1573143196_clo;
HeffT2 g_prelude_2etraverse_24s1252393826x821382319_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1252393826x821382319_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s130657301x1556233528(V);
V g_prelude_2etraverse_24s130657301x1556233528_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s130657301x1556233528_clo;
V g_prelude_2etraverse_24s1310917876x950458632_24apply2(V, V);
V g_prelude_2etraverse_24s1310917876x950458632_24apply2_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1310917876x950458632_24apply2_clo;
HeffT2 g_prelude_2etraverse_24s1442653311x1678194035_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s1476489890x1981265179(V);
V g_prelude_2etraverse_24s1476489890x1981265179_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1476489890x1981265179_clo;
HeffT2 g_prelude_2etraverse_24s1617808025x638052145_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s1736110006x954168809(V);
V g_prelude_2etraverse_24s1736110006x954168809_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1736110006x954168809_clo;
HeffT2 g_prelude_2etraverse_24s1776038734x825611929_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s1796722286x1908752336(V, V);
V g_prelude_2etraverse_24s1796722286x1908752336_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1796722286x1908752336_clo;
V g_prelude_2etraverse_24s1797919465x75214466(V);
V g_prelude_2etraverse_24s1797919465x75214466_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1797919465x75214466_clo;
HeffT2 g_prelude_2etraverse_24s1882351740x242225671_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1882351740x242225671_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s1887447647x928396251(V, V);
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1887447647x928396251_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_prelude_2etraverse_24s2094958103x549422471(V);
V g_prelude_2etraverse_24s2094958103x549422471_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2094958103x549422471_clo;
V g_prelude_2etraverse_24s2126788141x1913216601(V);
V g_prelude_2etraverse_24s2126788141x1913216601_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2126788141x1913216601_clo;
HeffT2 g_prelude_2etraverse_24s24931311x762276985_24cpr(V);
V g_prelude_2etraverse_24s259655739x790043950(V);
V g_prelude_2etraverse_24s259655739x790043950_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s259655739x790043950_clo;
V g_prelude_2etraverse_24s277604616x578020818(V);
V g_prelude_2etraverse_24s277604616x578020818_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s277604616x578020818_clo;
V g_prelude_2etraverse_24s302418249x620314678(V, V, V, V, V);
V g_prelude_2etraverse_24s302418249x620314678_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s302418249x620314678_clo;
HeffT2 g_prelude_2etraverse_24s322261189x1827875354_24dps_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s379292819x1163591097_24dps_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s76089383x258265534_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s76089383x258265534_24dps_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s801310267x475583082_24dps_24scalars_24cpr(V, V, V, V, V, V, V, V);
V g_prelude_2etraverse_24s812820150x374715993(V, V);
V g_prelude_2etraverse_24s812820150x374715993_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s812820150x374715993_clo;
HeffT2 g_prelude_2etraverse_24s812820150x374715993_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s924094738x742129811(V);
V g_prelude_2etraverse_24s924094738x742129811_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s924094738x742129811_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_prelude_2etraverse_24s1887447647x928396251_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1887447647x928396251_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1887447647x928396251_lam0, 1, 0};
V g_prelude_2etraverse_24s1887447647x928396251_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1887447647x928396251_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1887447647x928396251_entry, 2, 0};

V g_prelude_2etraverse_24s1887447647x928396251(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s1887447647x928396251_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s1887447647x928396251_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1887447647x928396251(a[0], a[1]);
}
V g_prelude_2etraverse_24s1887447647x928396251_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_prelude_2etraverse_24s1887447647x928396251_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = (g_prelude_2etraverse_24s1887447647x928396251(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_t_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}

HeffT2 g_prelude_2etraverse_24s1159166259x948777116_24dps_24cpr(V v_x2_240, V v_p_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_p_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_247 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_x_245, v_p_241));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_x_2410 = v_field_248;
      V v_st_2411 = v_field_249;
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2410, heff_hole()});
      V v_u_2413 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2412);
      V t_0 = v_xs_246;
      V t_1 = v_st_2411;
      V t_2 = v_u_2413;
      v_x2_240 = t_0;
      v_p_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s76089383x258265534_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      V v_ru_24x_242_24MkArm = heff_take_reuse_n(v_x_242, 7ULL, 3);
      HeffT2 v_t_247 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_a_246, v_p_241));
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        V v_a_2410 = v_field_248;
        V v_a_2411 = v_field_249;
        V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_re_n(v_ru_24x_242_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_a_244, v_a_245, v_a_2410}), heff_hole()});
        HeffT2 v_t_2413 = (g_prelude_2etraverse_24s76089383x258265534_24dps_24cpr(v_xs_243, v_a_2411, v_cell_2412));
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v__5f_2416 = v_field_2414;
          heff_drop(v__5f_2416);
          V v_st_2417 = v_field_2415;
          return ((HeffT2){{v_cell_2412, v_st_2417}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s2126788141x1913216601_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s2126788141x1913216601_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2126788141x1913216601_lam0, 1, 0};
V g_prelude_2etraverse_24s2126788141x1913216601_lam1(V self, V *args);
V g_prelude_2etraverse_24s2126788141x1913216601_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s2126788141x1913216601_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2126788141x1913216601_entry, 1, 0};

V g_prelude_2etraverse_24s2126788141x1913216601(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s2126788141x1913216601_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_a_246 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_a_245));
      v_m_2411 = heff_clo_n(g_prelude_2etraverse_24s2126788141x1913216601_lam1, 1, 2, (V[]){v_a_246, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_prelude_2etraverse_24s2126788141x1913216601_lam2, 1, 2, (V[]){v_m_2411, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s2126788141x1913216601_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s2126788141x1913216601(a[0]);
}
V g_prelude_2etraverse_24s2126788141x1913216601_lam0(V self, V *args) {
  V v_s_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_241});
}
V g_prelude_2etraverse_24s2126788141x1913216601_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_248 = heff_tr(heff_call(v_a_246, 1, (V[]){v_a_247}));
  switch (heff_tag_of(v_a_248)) {
  case TAG_MkPair: {
    V v_a_249 = heff_field(v_a_248, 0);
    V v_a_2410 = heff_field(v_a_248, 1);
    V v_ru_24a_248_24MkPair = heff_take_reuse_n(v_a_248, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_248_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_249}), v_a_2410});
  }
  default: return heff_nomatch(v_a_248);
  }
}
V g_prelude_2etraverse_24s2126788141x1913216601_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_prelude_2etraverse_24s2126788141x1913216601(v_xs_243));
    V v_x2_2417 = heff_tr(heff_call(v_t_2416, 1, (V[]){v_s_2415}));
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_s_2419 = heff_field(v_x2_2417, 1);
      V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_Cons, 2, (V[]){v_x_2414, v_x_2418}), v_s_2419});
    }
    default: return heff_nomatch(v_x2_2417);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_prelude_2etraverse_24s1144925704x1514729383_24cpr_lam0(V self, V *args);

HeffT2 g_prelude_2etraverse_24s1144925704x1514729383_24cpr(V v_x2_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_z_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      V v_a_247 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_a_246));
      v_m_2412 = heff_clo_n(g_prelude_2etraverse_24s1144925704x1514729383_24cpr_lam0, 1, 3, (V[]){v_a_247, v_a_244, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_s_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2414, heff_hole()});
      HeffT2 v_t_2417 = (g_prelude_2etraverse_24s1144925704x1514729383_24dps_24cpr(v_xs_243, v_s_2415, v_cell_2416));
      {
        V v_field_2418 = v_t_2417.f[0];
        V v_field_2419 = v_t_2417.f[1];
        V v__5f_2420 = v_field_2418;
        heff_drop(v__5f_2420);
        V v_s_2421 = v_field_2419;
        return ((HeffT2){{v_cell_2416, v_s_2421}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2413)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1144925704x1514729383_24cpr_lam0(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_a_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = heff_tr(heff_call(v_a_247, 1, (V[]){v_a_248}));
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkPair: {
    V v_a_2410 = heff_field(v_a_249, 0);
    V v_a_2411 = heff_field(v_a_249, 1);
    V v_ru_24a_249_24MkPair = heff_take_reuse_n(v_a_249, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_249_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_244, v_a_245, v_a_2410}), v_a_2411});
  }
  default: return heff_nomatch(v_a_249);
  }
}

HeffT2 g_prelude_2etraverse_24s1252393826x821382319_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eoneDef_24cpr(v_x_242, v_p_241));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_s_248 = v_field_246;
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
      HeffT2 v_t_2410 = (g_prelude_2etraverse_24s1252393826x821382319_24dps_24cpr(v_xs_243, v_s_248, v_cell_249));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v__5f_2413 = v_field_2411;
        heff_drop(v__5f_2413);
        V v_s_2414 = v_field_2412;
        return ((HeffT2){{v_cell_249, v_s_2414}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1252393826x821382319_24dps_24cpr(V v_x2_240, V v_p_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_p_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_247 = (g_heff_2ecompile_2esimplify_2eoneDef_24cpr(v_x_245, v_p_241));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_x_2410 = v_field_248;
      V v_s_2411 = v_field_249;
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2410, heff_hole()});
      V v_u_2413 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2412);
      V t_0 = v_xs_246;
      V t_1 = v_s_2411;
      V t_2 = v_u_2413;
      v_x2_240 = t_0;
      v_p_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1934076392x614790049_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1934076392x614790049_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1934076392x614790049_lam0, 2, 0};
V g_prelude_2etraverse_24s1934076392x614790049_lam3(V self, V *args);
V g_prelude_2etraverse_24s1934076392x614790049_lam2(V self, V *args);
V g_prelude_2etraverse_24s1934076392x614790049_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1934076392x614790049_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1934076392x614790049_entry, 2, 0};

V g_prelude_2etraverse_24s1934076392x614790049(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s1934076392x614790049_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_a_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_prelude_2etraverse_24s1934076392x614790049_lam1, 2, 3, (V[]){v_a_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1934076392x614790049(a[0], a[1]);
}
V g_prelude_2etraverse_24s1934076392x614790049_lam0(V self, V *args) {
  V v_a_242 = args[0];
  V v_a_243 = args[1];
  heff_drop(v_a_242);
  V f_ = v_a_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1934076392x614790049_lam3(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_248 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_249, v_a_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1934076392x614790049_lam2(V self, V *args) {
  V v_a_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  V v_a_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = (g_prelude_2etraverse_24s1934076392x614790049(v_f_240, v_xs_245));
  V f_ = v_t_2410;
  heff_room[0] = v_a_247;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s1934076392x614790049_lam3, 1, 2, (V[]){v_a_248, v_a_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s1934076392x614790049_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_a_248 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_246;
  args[0] = heff_dup(v_a_247);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s1934076392x614790049_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_a_247, v_a_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s924094738x742129811_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s924094738x742129811_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s924094738x742129811_lam0, 1, 0};
V g_prelude_2etraverse_24s924094738x742129811_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s924094738x742129811_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s924094738x742129811_entry, 1, 0};

V g_prelude_2etraverse_24s924094738x742129811(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s924094738x742129811_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_244 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s924094738x742129811_lam1, 1, 2, (V[]){v_a_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s924094738x742129811_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s924094738x742129811(a[0]);
}
V g_prelude_2etraverse_24s924094738x742129811_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s924094738x742129811_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_246 = heff_tr(heff_call(v_a_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_a_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_a_246, 0);
    V v_n_248 = heff_field(v_a_246, 1);
    V v_ru_24a_246_24MkPair = heff_take_reuse_n(v_a_246, 3ULL, 2);
    V v_t_249 = (g_prelude_2etraverse_24s924094738x742129811(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_t_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24a_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_a_246);
  }
}
V g_prelude_2etraverse_24s1736110006x954168809_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1736110006x954168809_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1736110006x954168809_lam0, 1, 0};
V g_prelude_2etraverse_24s1736110006x954168809_lam1(V self, V *args);
V g_prelude_2etraverse_24s1736110006x954168809_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s1736110006x954168809_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1736110006x954168809_entry, 1, 0};

V g_prelude_2etraverse_24s1736110006x954168809(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1736110006x954168809_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_a_246 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_a_245));
      v_m_2411 = heff_clo_n(g_prelude_2etraverse_24s1736110006x954168809_lam1, 1, 2, (V[]){v_a_246, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_prelude_2etraverse_24s1736110006x954168809_lam2, 1, 2, (V[]){v_m_2411, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1736110006x954168809_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1736110006x954168809(a[0]);
}
V g_prelude_2etraverse_24s1736110006x954168809_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1736110006x954168809_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_248 = heff_tr(heff_call(v_a_246, 1, (V[]){v_a_247}));
  switch (heff_tag_of(v_a_248)) {
  case TAG_MkPair: {
    V v_a_249 = heff_field(v_a_248, 0);
    V v_a_2410 = heff_field(v_a_248, 1);
    V v_ru_24a_248_24MkPair = heff_take_reuse_n(v_a_248, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_248_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_249}), v_a_2410});
  }
  default: return heff_nomatch(v_a_248);
  }
}
V g_prelude_2etraverse_24s1736110006x954168809_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_prelude_2etraverse_24s1736110006x954168809(v_xs_243));
    V v_x2_2417 = heff_tr(heff_call(v_t_2416, 1, (V[]){v_n_2415}));
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_n_2419 = heff_field(v_x2_2417, 1);
      V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_Cons, 2, (V[]){v_x_2414, v_x_2418}), v_n_2419});
    }
    default: return heff_nomatch(v_x2_2417);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_prelude_2etraverse_24s812820150x374715993_lam1(V self, V *args);
V g_prelude_2etraverse_24s812820150x374715993_lam0(V self, V *args);
Clo g_prelude_2etraverse_24s812820150x374715993_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s812820150x374715993_entry, 2, 0};

V g_prelude_2etraverse_24s812820150x374715993(V v_x2_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_z_241});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_d_244 = v_x_242;
    V v_m_245 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(heff_dup(heff_rfield(v_d_244, 2))));
    V v_m_2420 = heff_clo_n(g_prelude_2etraverse_24s812820150x374715993_lam0, 1, 2, (V[]){v_m_245, v_d_244});
    V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_n_2423 = heff_field(v_x2_2421, 1);
      V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
      V v_cell_2424 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2422, heff_hole()});
      HeffT2 v_t_2425 = (g_prelude_2etraverse_24s812820150x374715993_24dps_24cpr(v_xs_243, v_n_2423, v_cell_2424));
      {
        V v_field_2426 = v_t_2425.f[0];
        V v_field_2427 = v_t_2425.f[1];
        V v__5f_2428 = v_field_2426;
        heff_drop(v__5f_2428);
        V v_n_2429 = v_field_2427;
        return heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_MkPair, 2, (V[]){v_cell_2424, v_n_2429});
      }
    }
    default: return heff_nomatch(v_x2_2421);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s812820150x374715993_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s812820150x374715993(a[0], a[1]);
}
V g_prelude_2etraverse_24s812820150x374715993_lam1(V self, V *args) {
  V v_n_2412 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_248, v_n_2412});
}
V g_prelude_2etraverse_24s812820150x374715993_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_d_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_248), NTAG(TAG_Nil)});
    V v_ns_2411 = (g_heff_2ecompile_2efields_2enumbersW(NTAG(TAG_Nil), v_t_2410));
    V v_m_2415;
    switch (heff_tag_of(v_ns_2411)) {
    case TAG_Nil: {
      v_m_2415 = heff_clo_n(g_prelude_2etraverse_24s812820150x374715993_lam1, 1, 1, (V[]){v_x_248});
      break;
    }
    case TAG_Cons: {
      v_m_2415 = (g_heff_2ecompile_2efields_2egoLate(v_ns_2411, v_x_248));
      break;
    }
    default: heff_nomatch(v_ns_2411);
    }
    V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_n_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      V v_t_2419 = ({ V rv_2 = v_x_2417; V rr_ = heff_rec_reuse_nf(v_d_244, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_n_2418});
    }
    default: return heff_nomatch(v_x2_2416);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}

HeffT2 g_prelude_2etraverse_24s801310267x475583082_24dps_24scalars_24cpr(V v_x2_240, V v_supply_241, V v_consumers_242, V v_producers_243, V v_made_244, V v_fresh_245, V v_left_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_248 = heff_setFieldPeek(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_249 = heff_hole();
    return ((HeffT2){{v_f_249, heff_rec_n(6, shape_supply__consumers__producers__made__fresh__left, (V[]){v_supply_241, v_consumers_242, v_producers_243, v_made_244, v_fresh_245, v_left_246})}});
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_240, 0);
    V v_xs_2411 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_2412 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), v_supply_241, v_x_2410));
    {
      V v_field_2413 = v_t_2412.f[0];
      V v_field_2414 = v_t_2412.f[1];
      V v_e_2415 = v_field_2413;
      V v_n_2416 = v_field_2414;
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_e_2415, heff_hole()});
      V v_u_2418 = heff_setFieldPeek(v_d_247, MK_INT(1LL), v_cell_2417);
      V t_0 = v_xs_2411;
      V t_1 = v_n_2416;
      V t_2 = v_consumers_242;
      V t_3 = v_producers_243;
      V t_4 = v_made_244;
      V t_5 = v_fresh_245;
      V t_6 = v_left_246;
      V t_7 = v_u_2418;
      v_x2_240 = t_0;
      v_supply_241 = t_1;
      v_consumers_242 = t_2;
      v_producers_243 = t_3;
      v_made_244 = t_4;
      v_fresh_245 = t_5;
      v_left_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1476489890x1981265179_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1476489890x1981265179_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1476489890x1981265179_lam0, 1, 0};
V g_prelude_2etraverse_24s1476489890x1981265179_lam1(V self, V *args);
V g_prelude_2etraverse_24s1476489890x1981265179_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s1476489890x1981265179_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1476489890x1981265179_entry, 1, 0};

V g_prelude_2etraverse_24s1476489890x1981265179(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1476489890x1981265179_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      V v_a_247 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_a_246));
      v_m_2412 = heff_clo_n(g_prelude_2etraverse_24s1476489890x1981265179_lam1, 1, 3, (V[]){v_a_247, v_a_244, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_prelude_2etraverse_24s1476489890x1981265179_lam2, 1, 2, (V[]){v_m_2412, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1476489890x1981265179_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1476489890x1981265179(a[0]);
}
V g_prelude_2etraverse_24s1476489890x1981265179_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1476489890x1981265179_lam1(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_a_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = heff_tr(heff_call(v_a_247, 1, (V[]){v_a_248}));
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkPair: {
    V v_a_2410 = heff_field(v_a_249, 0);
    V v_a_2411 = heff_field(v_a_249, 1);
    V v_ru_24a_249_24MkPair = heff_take_reuse_n(v_a_249, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_249_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_244, v_a_245, v_a_2410}), v_a_2411});
  }
  default: return heff_nomatch(v_a_249);
  }
}
V g_prelude_2etraverse_24s1476489890x1981265179_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_t_2417 = (g_prelude_2etraverse_24s1476489890x1981265179(v_xs_243));
    V v_x2_2418 = heff_tr(heff_call(v_t_2417, 1, (V[]){v_n_2416}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_n_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_Cons, 2, (V[]){v_x_2415, v_x_2419}), v_n_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_prelude_2etraverse_24s259655739x790043950_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s259655739x790043950_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s259655739x790043950_lam0, 1, 0};
V g_prelude_2etraverse_24s259655739x790043950_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s259655739x790043950_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s259655739x790043950_entry, 1, 0};

V g_prelude_2etraverse_24s259655739x790043950(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s259655739x790043950_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s259655739x790043950_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s259655739x790043950_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s259655739x790043950(a[0]);
}
V g_prelude_2etraverse_24s259655739x790043950_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s259655739x790043950_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = (g_prelude_2etraverse_24s259655739x790043950(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_t_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2etraverse_24s1776038734x825611929_24dps_24cpr_lam0(V self, V *args);

HeffT2 g_prelude_2etraverse_24s1776038734x825611929_24dps_24cpr(V v_x2_240, V v_z_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_2415;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkArm: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_a_249 = heff_field(v_x_245, 2);
      heff_take_n(v_x_245, 7ULL, 3);
      V v_a_2410 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_a_249));
      v_m_2415 = heff_clo_n(g_prelude_2etraverse_24s1776038734x825611929_24dps_24cpr_lam0, 1, 3, (V[]){v_a_2410, v_a_247, v_a_248});
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_n_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      V v_cell_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2417, heff_hole()});
      V v_u_2420 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2419);
      V t_0 = v_xs_246;
      V t_1 = v_n_2418;
      V t_2 = v_u_2420;
      v_x2_240 = t_0;
      v_z_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2416)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1776038734x825611929_24dps_24cpr_lam0(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2410 = heff_env(self)[0];
  V v_a_247 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2412 = heff_tr(heff_call(v_a_2410, 1, (V[]){v_a_2411}));
  switch (heff_tag_of(v_a_2412)) {
  case TAG_MkPair: {
    V v_a_2413 = heff_field(v_a_2412, 0);
    V v_a_2414 = heff_field(v_a_2412, 1);
    V v_ru_24a_2412_24MkPair = heff_take_reuse_n(v_a_2412, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_2412_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_247, v_a_248, v_a_2413}), v_a_2414});
  }
  default: return heff_nomatch(v_a_2412);
  }
}
HEFF_LIT(g_prelude_2etraverse_24s302418249x620314678_str0, 1, "_");
V g_prelude_2etraverse_24s302418249x620314678_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s302418249x620314678_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s302418249x620314678_lam0, 1, 0};
V g_prelude_2etraverse_24s302418249x620314678_lam1(V self, V *args);
V g_prelude_2etraverse_24s302418249x620314678_lam2(V self, V *args);
V g_prelude_2etraverse_24s302418249x620314678_lam3(V self, V *args);
V g_prelude_2etraverse_24s302418249x620314678_lam4(V self, V *args);
Clo g_prelude_2etraverse_24s302418249x620314678_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s302418249x620314678_entry, 5, 0};

V g_prelude_2etraverse_24s302418249x620314678(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return ((V)&g_prelude_2etraverse_24s302418249x620314678_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_x_248 = heff_dup(v_lit_240);
    V v_t_249 = heff_dup(v_lit_241);
    V v_vs_2410 = heff_dup(v_lit_242);
    V v_f_2411 = heff_dup(v_lit_243);
    V v_x5_2412 = v_x_246;
    V v_m_2446;
    switch (heff_tag_of(v_x5_2412)) {
    case TAG_MkArm: {
      V v_t2_2413 = heff_field(v_x5_2412, 0);
      V v_ws_2414 = heff_field(v_x5_2412, 1);
      V v_c_2415 = heff_field(v_x5_2412, 2);
      heff_take_n(v_x5_2412, 7ULL, 3);
      V v_x_2416 = heff_dup(v_x_248);
      V v_vs_2417 = heff_dup(v_vs_2410);
      V v_f_2418 = v_f_2411;
      V v_c_2419 = heff_dup(v_c_2415);
      V v_t_2420 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_2419), NTAG(TAG_Nil)});
      V v_t_2421 = (g_heff_2ecompile_2eir_2ecountW(v_x_2416, MK_INT(0LL), v_t_2420));
      V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_2419), NTAG(TAG_Nil)});
      V v_t_2423 = ({ V a_0 = v_x_2416; V a_1 = v_t_2422; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2416); r_; });
      V v_x_2424 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2421, v_t_2423}), 0, 2);
      V v_t_2432;
      if (heff_intLt_c(MK_INT(0LL), v_x_2424)) {
        V v_x1_2431 = ({ V a_0 = heff_clo_n(g_prelude_2etraverse_24s302418249x620314678_lam1, 1, 2, (V[]){v_f_2418, v_c_2419}); V a_1 = v_vs_2417; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_vs_2417); r_; });
        v_t_2432 = heff_bool(!(heff_dup(v_x1_2431) == NTAG(TAG_True)));
        heff_drop(v_x1_2431);
      } else {
        heff_drop(v_vs_2417);
        heff_drop(v_f_2418);
        heff_drop(v_c_2419);
        v_t_2432 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
        heff_drop(v_x_248);
        heff_drop(v_t_249);
        heff_drop(v_vs_2410);
        heff_drop(v_t_2432);
        v_m_2446 = heff_clo_n(g_prelude_2etraverse_24s302418249x620314678_lam2, 1, 3, (V[]){v_t2_2413, v_ws_2414, v_c_2415});
      } else {
        heff_drop(v_t_2432);
        V v_m_2434 = (g_prelude_2etraverse_24s277604616x578020818(heff_dup(v_vs_2410)));
        v_m_2446 = heff_clo_n(g_prelude_2etraverse_24s302418249x620314678_lam3, 1, 7, (V[]){v_m_2434, v_vs_2410, v_c_2415, v_t_249, v_x_248, v_t2_2413, v_ws_2414});
      }
      break;
    }
    default: heff_nomatch(v_x5_2412);
    }
    return heff_clo_n(g_prelude_2etraverse_24s302418249x620314678_lam4, 1, 6, (V[]){v_m_2446, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_247});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_prelude_2etraverse_24s302418249x620314678_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s302418249x620314678(a[0], a[1], a[2], a[3], a[4]);
}
V g_prelude_2etraverse_24s302418249x620314678_lam0(V self, V *args) {
  V v_n_245 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_245});
}
V g_prelude_2etraverse_24s302418249x620314678_lam1(V self, V *args) {
  V v_v_2425 = args[0];
  V v_f_2418 = heff_env(self)[0];
  V v_c_2419 = heff_env(self)[1];
  if (!heff_strEq_c_lent(v_v_2425, v_f_2418, 0)) {
    heff_clo_take(self, 2);
    heff_drop(v_f_2418);
    if (!heff_strEq_c_lent(v_v_2425, ((V)&g_prelude_2etraverse_24s302418249x620314678_str0), 2)) {
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_2419), NTAG(TAG_Nil)});
      V v_t_2427 = (g_heff_2ecompile_2eir_2ecountW(v_v_2425, MK_INT(0LL), v_t_2426));
      V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_2419, NTAG(TAG_Nil)});
      V v_t_2429 = ({ V a_0 = v_v_2425; V a_1 = v_t_2428; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_v_2425); r_; });
      V v_x_2430 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2427, v_t_2429}), 0, 2);
      V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2430, 1));
      heff_drop(v_x_2430);
      return v_ret_24bool;
    } else {
      heff_drop(v_v_2425);
      heff_drop(v_c_2419);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_v_2425);
    heff_drop(self);
    return NTAG(TAG_False);
  }
}
V g_prelude_2etraverse_24s302418249x620314678_lam2(V self, V *args) {
  V v_n_2433 = args[0];
  V v_t2_2413 = heff_env(self)[0];
  V v_ws_2414 = heff_env(self)[1];
  V v_c_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t2_2413, v_ws_2414, v_c_2415}), v_n_2433});
}
V g_prelude_2etraverse_24s302418249x620314678_lam3(V self, V *args) {
  V v_n_2435 = args[0];
  V v_m_2434 = heff_env(self)[0];
  V v_vs_2410 = heff_env(self)[1];
  V v_c_2415 = heff_env(self)[2];
  V v_t_249 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_t2_2413 = heff_env(self)[5];
  V v_ws_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2436 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_n_2435}));
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkPair: {
    V v_x_2437 = heff_field(v_x2_2436, 0);
    V v_n_2438 = heff_field(v_x2_2436, 1);
    V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 3ULL, 2);
    V v_ps_2439 = (g_list_2ezipWith_24s1928181476x241816070(v_vs_2410, heff_dup(v_x_2437)));
    V v_m_2440 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2439; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2439); r_; });
    V v_t_2441 = (g_std_2eordmap_2esize(v_m_2440));
    V v_t_2442;
    if (heff_intEq_c(v_t_2441, MK_INT(0LL))) {
      heff_drop(v_m_2440);
      v_t_2442 = v_c_2415;
    } else {
      v_t_2442 = ({ V a_0 = v_m_2440; V a_1 = v_c_2415; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2440); r_; });
    }
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_249, v_x_2437, v_t_2442}), NTAG(TAG_Nil)});
    V v_t_2444 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_248}), v_t_2443});
    V v_x_2445 = heff_tag_n(TAG_MkArm, 3, (V[]){v_t2_2413, v_ws_2414, v_t_2444});
    return heff_tag_re_n(v_ru_24x2_2436_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2445, v_n_2438});
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_prelude_2etraverse_24s302418249x620314678_lam4(V self, V *args) {
  V v_n_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  V v_xs_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_n_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    V v_t_2451 = (g_prelude_2etraverse_24s302418249x620314678(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_247));
    V v_x2_2452 = heff_tr(heff_call(v_t_2451, 1, (V[]){v_n_2450}));
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_MkPair: {
      V v_x_2453 = heff_field(v_x2_2452, 0);
      V v_n_2454 = heff_field(v_x2_2452, 1);
      V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_Cons, 2, (V[]){v_x_2449, v_x_2453}), v_n_2454});
    }
    default: return heff_nomatch(v_x2_2452);
    }
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1796722286x1908752336_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1796722286x1908752336_lam0, 1, 0};
V g_prelude_2etraverse_24s1796722286x1908752336_lam1(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam2(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam3(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam4(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam5(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam6(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam7(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam8(V self, V *args);
Clo g_prelude_2etraverse_24s1796722286x1908752336_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1796722286x1908752336_entry, 2, 0};

V g_prelude_2etraverse_24s1796722286x1908752336(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((V)&g_prelude_2etraverse_24s1796722286x1908752336_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_dup(v_lit_240);
    V v_a_246 = v_x_243;
    V v_m_2450;
    switch (heff_tag_of(v_a_246)) {
    case TAG_MkArm: {
      V v_t_247 = heff_dup(heff_field(v_a_246, 0));
      V v_vs_248 = heff_dup(heff_field(v_a_246, 1));
      V v_a3_249 = heff_dup(heff_field(v_a_246, 2));
      switch (heff_tag_of(v_a3_249)) {
      case TAG_EMatch: {
        V v_a31_2410 = heff_field(v_a3_249, 0);
        V v_inner_2411 = heff_field(v_a3_249, 1);
        heff_take_n(v_a3_249, 3ULL, 2);
        switch (heff_tag_of(v_a31_2410)) {
        case TAG_EVar: {
          V v_f_2412 = heff_field(v_a31_2410, 0);
          heff_take_n(v_a31_2410, 1ULL, 1);
          heff_drop_tag(v_a_246, 3);
          V v_t_2413 = (g_list_2eany_24s1006624359x760861690(v_f_2412, v_vs_248));
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_t_2413);
            V v_x_2414 = heff_dup(v_x_245);
            V v_inner_2415 = heff_dup(v_inner_2411);
            V v_t_2426 = (g_list_2eany(heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam1, 1, 1, (V[]){heff_dup(v_x_2414)}), v_inner_2415));
            V v_t_2437;
            if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
              heff_drop(v_t_2426);
              v_t_2437 = ({ V a_0 = heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam2, 1, 1, (V[]){v_x_2414}); V a_1 = v_inner_2415; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_inner_2415); r_; });
            } else {
              heff_drop(v_x_2414);
              heff_drop(v_inner_2415);
              heff_drop(v_t_2426);
              v_t_2437 = NTAG(TAG_False);
            }
            if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
              heff_drop(v_t_2437);
              V v_m_2438 = (g_prelude_2etraverse_24s302418249x620314678(v_x_245, heff_dup(v_t_247), heff_dup(v_vs_248), heff_dup(v_f_2412), v_inner_2411));
              v_m_2450 = heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam3, 1, 4, (V[]){v_m_2438, v_f_2412, v_t_247, v_vs_248});
            } else {
              heff_drop(v_x_245);
              heff_drop(v_t_2437);
              v_m_2450 = heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam4, 1, 4, (V[]){v_f_2412, v_inner_2411, v_t_247, v_vs_248});
            }
          } else {
            heff_drop(v_x_245);
            heff_drop(v_t_2413);
            v_m_2450 = heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam5, 1, 4, (V[]){v_f_2412, v_inner_2411, v_t_247, v_vs_248});
          }
          break;
        }
        default: {
          heff_drop(v_x_245);
          heff_drop(v_t_247);
          heff_drop(v_vs_248);
          heff_drop(v_a31_2410);
          heff_drop(v_inner_2411);
          v_m_2450 = heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam6, 1, 1, (V[]){v_a_246});
          break;
        }
        }
        break;
      }
      default: {
        heff_drop(v_x_245);
        heff_drop(v_t_247);
        heff_drop(v_vs_248);
        heff_drop(v_a3_249);
        v_m_2450 = heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam7, 1, 1, (V[]){v_a_246});
        break;
      }
      }
      break;
    }
    default: heff_nomatch(v_a_246);
    }
    return heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam8, 1, 3, (V[]){v_m_2450, v_lit_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1796722286x1908752336_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1796722286x1908752336(a[0], a[1]);
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam1(V self, V *args) {
  V v_a_2416 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_e_2420;
  switch (heff_tag_of(v_a_2416)) {
  case TAG_MkArm: {
    V v_b_2419 = heff_field(v_a_2416, 2);
    heff_take_n(v_a_2416, 4ULL, 3);
    v_e_2420 = v_b_2419;
    break;
  }
  default: heff_nomatch(v_a_2416);
  }
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2420), NTAG(TAG_Nil)});
  V v_t_2422 = (g_heff_2ecompile_2eir_2ecountW(v_x_2414, MK_INT(0LL), v_t_2421));
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2420, NTAG(TAG_Nil)});
  heff_clo_take(self, 1);
  V v_t_2424 = ({ V a_0 = v_x_2414; V a_1 = v_t_2423; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2414); r_; });
  V v_x_2425 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2422, v_t_2424}), 0, 2);
  V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2425, 1));
  heff_drop(v_x_2425);
  return v_ret_24bool;
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam2(V self, V *args) {
  V v_a_2427 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_e_2431;
  switch (heff_tag_of(v_a_2427)) {
  case TAG_MkArm: {
    V v_b_2430 = heff_field(v_a_2427, 2);
    heff_take_n(v_a_2427, 4ULL, 3);
    v_e_2431 = v_b_2430;
    break;
  }
  default: heff_nomatch(v_a_2427);
  }
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2431), NTAG(TAG_Nil)});
  V v_t_2433 = (g_heff_2ecompile_2eir_2ecountW(v_x_2414, MK_INT(0LL), v_t_2432));
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2431, NTAG(TAG_Nil)});
  heff_clo_take(self, 1);
  V v_t_2435 = ({ V a_0 = v_x_2414; V a_1 = v_t_2434; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2414); r_; });
  V v_x_2436 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2433, v_t_2435}), 0, 2);
  V v_ret_24bool = heff_bool(!heff_intLt_c_lent(MK_INT(0LL), v_x_2436, 1));
  heff_drop(v_x_2436);
  return v_ret_24bool;
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam3(V self, V *args) {
  V v_n_2439 = args[0];
  V v_m_2438 = heff_env(self)[0];
  V v_f_2412 = heff_env(self)[1];
  V v_t_247 = heff_env(self)[2];
  V v_vs_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2440 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_n_2439}));
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_x_2441 = heff_field(v_x2_2440, 0);
    V v_n_2442 = heff_field(v_x2_2440, 1);
    V v_ru_24x2_2440_24MkPair = heff_take_reuse_n(v_x2_2440, 3ULL, 2);
    V v_t_2443 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_f_2412}), v_x_2441});
    return heff_tag_re_n(v_ru_24x2_2440_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_247, v_vs_248, v_t_2443}), v_n_2442});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam4(V self, V *args) {
  V v_n_2444 = args[0];
  V v_f_2412 = heff_env(self)[0];
  V v_inner_2411 = heff_env(self)[1];
  V v_t_247 = heff_env(self)[2];
  V v_vs_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2445 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_f_2412}), v_inner_2411});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_247, v_vs_248, v_t_2445}), v_n_2444});
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam5(V self, V *args) {
  V v_n_2446 = args[0];
  V v_f_2412 = heff_env(self)[0];
  V v_inner_2411 = heff_env(self)[1];
  V v_t_247 = heff_env(self)[2];
  V v_vs_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2447 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_f_2412}), v_inner_2411});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_247, v_vs_248, v_t_2447}), v_n_2446});
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam6(V self, V *args) {
  V v_n_2448 = args[0];
  V v_a_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_246, v_n_2448});
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam7(V self, V *args) {
  V v_n_2449 = args[0];
  V v_a_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_246, v_n_2449});
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam8(V self, V *args) {
  V v_n_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_n_2451}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_n_2454 = heff_field(v_x2_2452, 1);
    V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
    V v_t_2455 = (g_prelude_2etraverse_24s1796722286x1908752336(v_lit_240, v_xs_244));
    V v_x2_2456 = heff_tr(heff_call(v_t_2455, 1, (V[]){v_n_2454}));
    switch (heff_tag_of(v_x2_2456)) {
    case TAG_MkPair: {
      V v_x_2457 = heff_field(v_x2_2456, 0);
      V v_n_2458 = heff_field(v_x2_2456, 1);
      V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2456_24MkPair, TAG_Cons, 2, (V[]){v_x_2453, v_x_2457}), v_n_2458});
    }
    default: return heff_nomatch(v_x2_2456);
    }
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_prelude_2etraverse_24s130657301x1556233528_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s130657301x1556233528_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s130657301x1556233528_lam0, 1, 0};
V g_prelude_2etraverse_24s130657301x1556233528_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s130657301x1556233528_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s130657301x1556233528_entry, 1, 0};

V g_prelude_2etraverse_24s130657301x1556233528(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s130657301x1556233528_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_244 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s130657301x1556233528_lam1, 1, 2, (V[]){v_a_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s130657301x1556233528_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s130657301x1556233528(a[0]);
}
V g_prelude_2etraverse_24s130657301x1556233528_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s130657301x1556233528_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_246 = heff_tr(heff_call(v_a_244, 1, (V[]){v_n_245}));
  V v_x2_249;
  switch (heff_tag_of(v_a_246)) {
  case TAG_MkPair: {
    V v_a_247 = heff_field(v_a_246, 0);
    V v_a_248 = heff_field(v_a_246, 1);
    V v_ru_24a_246_24MkPair = heff_take_reuse_n(v_a_246, 3ULL, 2);
    v_x2_249 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24a_246_24MkPair, v_a_247, v_a_248));
    break;
  }
  default: heff_nomatch(v_a_246);
  }
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412 = (g_prelude_2etraverse_24s130657301x1556233528(v_xs_243));
    V v_x2_2413 = heff_tr(heff_call(v_t_2412, 1, (V[]){v_n_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_Cons, 2, (V[]){v_x_2410, v_x_2414}), v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}

HeffT2 g_prelude_2etraverse_24s1617808025x638052145_24dps_24cpr(V v_x2_240, V v_z_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_247 = (g_heff_2ecompile_2erunes_2edefOf(v_x_245));
    V v_x2_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_n_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_249, heff_hole()});
      V v_u_2412 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2411);
      V t_0 = v_xs_246;
      V t_1 = v_n_2410;
      V t_2 = v_u_2412;
      v_x2_240 = t_0;
      v_z_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_prelude_2etraverse_24s1206798274x929612205_24cpr_str0, 1, "$");

HeffT2 g_prelude_2etraverse_24s1206798274x929612205_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x_244 = heff_strAppend(heff_strAppend(v_x_242, ((V)&g_prelude_2etraverse_24s1206798274x929612205_24cpr_str0)), heff_intShow(heff_dup(v_p_241)));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    HeffT2 v_t_246 = (g_prelude_2etraverse_24s1206798274x929612205_24dps_24cpr(v_xs_243, heff_intAdd(v_p_241, MK_INT(1LL)), v_cell_245));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      V v__5f_249 = v_field_247;
      heff_drop(v__5f_249);
      V v_n_2410 = v_field_248;
      return ((HeffT2){{v_cell_245, v_n_2410}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_prelude_2etraverse_24s1206798274x929612205_24dps_24cpr_str0, 1, "$");

HeffT2 g_prelude_2etraverse_24s1206798274x929612205_24dps_24cpr(V v_x2_240, V v_p_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_p_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x_247 = heff_strAppend(heff_strAppend(v_x_245, ((V)&g_prelude_2etraverse_24s1206798274x929612205_24dps_24cpr_str0)), heff_intShow(heff_dup(v_p_241)));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
    V t_0 = v_xs_246;
    V t_1 = heff_intAdd(v_p_241, MK_INT(1LL));
    V t_2 = v_u_249;
    v_x2_240 = t_0;
    v_p_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1442653311x1678194035_24dps_24cpr(V v_x2_240, V v_z_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2escalars_2eslotsOf(NTAG(TAG_OfRecords), heff_dup(v_x_245)));
    V v_m_248 = (g_heff_2ecompile_2escalars_2efoundWith(NTAG(TAG_OfRecords), heff_dup(v_x_245), heff_rec_n(2, shape_def__slots, (V[]){v_x_245, v_t_247})));
    V v_x2_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_n_2411 = heff_field(v_x2_249, 1);
      heff_take_n(v_x2_249, 3ULL, 2);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2410, heff_hole()});
      V v_u_2413 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2412);
      V t_0 = v_xs_246;
      V t_1 = v_n_2411;
      V t_2 = v_u_2413;
      v_x2_240 = t_0;
      v_z_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_249)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s379292819x1163591097_24dps_24cpr(V v_x2_240, V v_z_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_def_247 = heff_take_field(v_x_245, 0);
    V v_slots_248 = heff_get_n(v_x_245, 1, 2);
    V v_m_249 = ({ V b_0 = NTAG(TAG_OfRecords); V a_1 = v_def_247; V a_2 = v_slots_248; V r_ = (g_heff_2ecompile_2escalars_2edefWith(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
      V v_u_2414 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2413);
      V t_0 = v_xs_246;
      V t_1 = v_n_2412;
      V t_2 = v_u_2414;
      v_x2_240 = t_0;
      v_z_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2410)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s322261189x1827875354_24dps_24cpr(V v_x2_240, V v_z_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2escalars_2eslotsOf(NTAG(TAG_OfTags), heff_dup(v_x_245)));
    V v_m_248 = (g_heff_2ecompile_2escalars_2efoundWith(NTAG(TAG_OfTags), heff_dup(v_x_245), heff_rec_n(2, shape_def__slots, (V[]){v_x_245, v_t_247})));
    V v_x2_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_n_2411 = heff_field(v_x2_249, 1);
      heff_take_n(v_x2_249, 3ULL, 2);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2410, heff_hole()});
      V v_u_2413 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2412);
      V t_0 = v_xs_246;
      V t_1 = v_n_2411;
      V t_2 = v_u_2413;
      v_x2_240 = t_0;
      v_z_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_249)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1882351740x242225671_24cpr(V v_x2_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_z_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2etrmc_2edefT(v_x_242));
    V v_x2_245 = heff_tr(heff_call(v_m_244, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_n_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
      HeffT2 v_t_249 = (g_prelude_2etraverse_24s1882351740x242225671_24dps_24cpr(v_xs_243, v_n_247, v_cell_248));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v__5f_2412 = v_field_2410;
        heff_drop(v__5f_2412);
        V v_n_2413 = v_field_2411;
        return ((HeffT2){{v_cell_248, v_n_2413}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_prelude_2etraverse_24s1212489961x1573143196_str0, 0, "");
HEFF_LIT(g_prelude_2etraverse_24s1212489961x1573143196_str1, 5, "((V)&");
HEFF_LIT(g_prelude_2etraverse_24s1212489961x1573143196_str2, 5, "_lit_");
HEFF_LIT(g_prelude_2etraverse_24s1212489961x1573143196_str3, 2, "v_");
HEFF_LIT(g_prelude_2etraverse_24s1212489961x1573143196_str4, 1, "V");
HEFF_LIT(g_prelude_2etraverse_24s1212489961x1573143196_str5, 1, ")");
HEFF_LIT(g_prelude_2etraverse_24s1212489961x1573143196_str6, 1, "V");
HEFF_LIT(g_prelude_2etraverse_24s1212489961x1573143196_str7, 6, "double");
HEFF_LIT(g_prelude_2etraverse_24s1212489961x1573143196_str8, 7, "int64_t");
HEFF_LIT(g_prelude_2etraverse_24s1212489961x1573143196_str9, 1, "V");
V g_prelude_2etraverse_24s1212489961x1573143196_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1212489961x1573143196_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1212489961x1573143196_lam0, 1, 0};
V g_prelude_2etraverse_24s1212489961x1573143196_lam1(V self, V *args);
V g_prelude_2etraverse_24s1212489961x1573143196_lam2(V self, V *args);
V g_prelude_2etraverse_24s1212489961x1573143196_lam3(V self, V *args);
V g_prelude_2etraverse_24s1212489961x1573143196_lam4(V self, V *args);
Clo g_prelude_2etraverse_24s1212489961x1573143196_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1212489961x1573143196_entry, 3, 0};

V g_prelude_2etraverse_24s1212489961x1573143196(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return ((V)&g_prelude_2etraverse_24s1212489961x1573143196_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_go_246 = heff_dup(v_lit_240);
    V v_k_247 = heff_dup(v_lit_241);
    V v_x3_248 = v_x_244;
    V v_m_2430;
    switch (heff_tag_of(v_x3_248)) {
    case TAG_RLocal: {
      V v_x_249 = heff_field(v_x3_248, 0);
      heff_take_n(v_x3_248, 1ULL, 1);
      heff_drop(v_go_246);
      heff_drop_rec(v_k_247, 6);
      v_m_2430 = heff_clo_n(g_prelude_2etraverse_24s1212489961x1573143196_lam1, 1, 1, (V[]){v_x_249});
      break;
    }
    case TAG_RWord: {
      V v_r_2415 = heff_field(v_x3_248, 0);
      V v_e_2416 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      heff_drop(v_go_246);
      V v_m_2417 = heff_tr(heff_call(heff_get_n(v_k_247, 0, 6), 1, (V[]){v_e_2416}));
      v_m_2430 = heff_clo_n(g_prelude_2etraverse_24s1212489961x1573143196_lam2, 1, 2, (V[]){v_m_2417, v_r_2415});
      break;
    }
    default: {
      heff_drop_rec(v_k_247, 6);
      V v_m_2425 = heff_tr(heff_call(v_go_246, 1, (V[]){v_x3_248}));
      v_m_2430 = heff_clo_n(g_prelude_2etraverse_24s1212489961x1573143196_lam3, 1, 1, (V[]){v_m_2425});
      break;
    }
    }
    return heff_clo_n(g_prelude_2etraverse_24s1212489961x1573143196_lam4, 1, 4, (V[]){v_m_2430, v_lit_240, v_lit_241, v_xs_245});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2etraverse_24s1212489961x1573143196_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1212489961x1573143196(a[0], a[1], a[2]);
}
V g_prelude_2etraverse_24s1212489961x1573143196_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_243});
}
V g_prelude_2etraverse_24s1212489961x1573143196_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = ({ V a_0 = v_x_249; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_prelude_2etraverse_24s1212489961x1573143196_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_249); r_; });
  V v_t_2412 = heff_strAppend(((V)&g_prelude_2etraverse_24s1212489961x1573143196_str1), heff_dup(heff_rfield(v_s_2410, 0)));
  V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_prelude_2etraverse_24s1212489961x1573143196_str2)), heff_strAppend(((V)&g_prelude_2etraverse_24s1212489961x1573143196_str3), v_t_2411));
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_prelude_2etraverse_24s1212489961x1573143196_str4), heff_strAppend(v_t_2413, ((V)&g_prelude_2etraverse_24s1212489961x1573143196_str5))});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_s_2410});
}
V g_prelude_2etraverse_24s1212489961x1573143196_lam2(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_r_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    V v_t_2423;
    switch (heff_tag_of(v_r_2415)) {
    case TAG_RepV: {
      v_t_2423 = ((V)&g_prelude_2etraverse_24s1212489961x1573143196_str6);
      break;
    }
    case TAG_RepFix: {
      V v_w_2422 = heff_field(v_r_2415, 0);
      heff_take_n(v_r_2415, 1ULL, 1);
      v_t_2423 = ({ V a_0 = v_w_2422; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2422); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_2423 = ((V)&g_prelude_2etraverse_24s1212489961x1573143196_str7);
      break;
    }
    case TAG_RepInt: {
      v_t_2423 = ((V)&g_prelude_2etraverse_24s1212489961x1573143196_str8);
      break;
    }
    default: heff_nomatch(v_r_2415);
    }
    V v_x_2424 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_t_2423, v_x_2420});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2424, v_s_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_prelude_2etraverse_24s1212489961x1573143196_lam3(V self, V *args) {
  V v_s_2426 = args[0];
  V v_m_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2427 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_s_2426}));
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    V v_s_2429 = heff_field(v_x2_2427, 1);
    V v_ru_24x2_2427_24MkPair = heff_take_reuse_n(v_x2_2427, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2427_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_prelude_2etraverse_24s1212489961x1573143196_str9), v_x_2428}), v_s_2429});
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_prelude_2etraverse_24s1212489961x1573143196_lam4(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_xs_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_t_2435 = (g_prelude_2etraverse_24s1212489961x1573143196(v_lit_240, v_lit_241, v_xs_245));
    V v_x2_2436 = heff_tr(heff_call(v_t_2435, 1, (V[]){v_s_2434}));
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_MkPair: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_s_2438 = heff_field(v_x2_2436, 1);
      V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2436_24MkPair, TAG_Cons, 2, (V[]){v_x_2433, v_x_2437}), v_s_2438});
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}

HeffT2 g_prelude_2etraverse_24s24931311x762276985_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 3ULL, 2);
        HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_a_245));
        {
          V v_field_249 = v_t_247.f[1];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          if ((v_tag_248 == ((int64_t)0ULL))) {
            heff_drop(v_xs_242);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop_cell(v_ru_24x_241_24At, 2);
            heff_drop(v_a_246);
            V v_a_2410 = v_field_249;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_a_2410}});
          } else {
            V v_a_2411 = v_field_249;
            HeffT2 v_t_2412 = (g_prelude_2etraverse_24s24931311x762276985_24cpr(v_xs_242));
            {
              V v_field_2414 = v_t_2412.f[1];
              int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
              if ((v_tag_2413 == ((int64_t)0ULL))) {
                heff_drop_cell(v_ru_24x2_240_24Cons, 2);
                heff_drop_cell(v_ru_24x_241_24At, 2);
                heff_drop(v_a_246);
                heff_drop(v_a_2411);
                V v_err_2415 = v_field_2414;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2415}});
              } else {
                V v_x_2416 = v_field_2414;
                V v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_2411, NTAG(TAG_Nil)});
                V v_t_2418 = heff_tag_at_n(v_ru_24x_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_t_2417, v_a_246}), v_x_2416});
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2418}});
              }
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_243)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_prelude_2etraverse_24s1797919465x75214466_str0, 44, "expected a field setting of the form `x = v`");
V g_prelude_2etraverse_24s1797919465x75214466_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1797919465x75214466_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1797919465x75214466_lam0, 2, 0};
V g_prelude_2etraverse_24s1797919465x75214466_lam2(V self, V *args);
V g_prelude_2etraverse_24s1797919465x75214466_lam1(V self, V *args);
V g_prelude_2etraverse_24s1797919465x75214466_lam3(V self, V *args);
V g_prelude_2etraverse_24s1797919465x75214466_lam6(V self, V *args);
V g_prelude_2etraverse_24s1797919465x75214466_lam5(V self, V *args);
V g_prelude_2etraverse_24s1797919465x75214466_lam4(V self, V *args);
Clo g_prelude_2etraverse_24s1797919465x75214466_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1797919465x75214466_entry, 1, 0};

V g_prelude_2etraverse_24s1797919465x75214466(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1797919465x75214466_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_x2_245 = v_x_243;
    V v_a_2428;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_x22_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_SetField: {
        V v_x_248 = heff_field(v_x21_246, 0);
        V v_xsp_249 = heff_field(v_x21_246, 1);
        V v_e_2410 = heff_field(v_x21_246, 2);
        heff_take_n(v_x21_246, 7ULL, 3);
        heff_drop(v_x22_247);
        V v_m_2411 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_e_2410)));
        v_a_2428 = heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam1, 2, 4, (V[]){v_m_2411, v_e_2410, v_x_248, v_xsp_249});
        break;
      }
      case TAG_BadFieldSet: {
        heff_take_n(v_x21_246, 0ULL, 1);
        v_a_2428 = heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam3, 2, 1, (V[]){v_x22_247});
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    return heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam4, 2, 2, (V[]){v_a_2428, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1797919465x75214466_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1797919465x75214466(a[0]);
}
V g_prelude_2etraverse_24s1797919465x75214466_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1797919465x75214466_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_2410 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_xsp_249 = heff_env(self)[3];
  V v_t_2418;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_e_2410)) {
  case TAG_At: {
    V v_s_2417 = heff_field(v_e_2410, 1);
    heff_take_n(v_e_2410, 2ULL, 2);
    v_t_2418 = v_s_2417;
    break;
  }
  default: heff_nomatch(v_e_2410);
  }
  V f_ = v_k_2413;
  args[0] = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){v_x_248, v_x_2415, v_t_2418, v_xsp_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1797919465x75214466_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_m_2411 = heff_env(self)[0];
  V v_e_2410 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_xsp_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_2411}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_2414, v_hd_2412, heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam2, 1, 4, (V[]){v_e_2410, v_k_2413, v_x_248, v_xsp_249})));
}
V g_prelude_2etraverse_24s1797919465x75214466_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k2_2421 = args[1];
  V v_x22_247 = heff_env(self)[0];
  V v_malg_2422 = heff_take_field(v_hd_2420, 2);
  V v_bind_2423 = heff_get_n(v_hd_2420, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2424 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(202LL), NTAG(TAG_SError), ((V)&g_prelude_2etraverse_24s1797919465x75214466_str0), v_x22_247, NTAG(TAG_Nothing)});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_call(v_malg_2422, 1, (V[]){v_t_2426}));
  V f_ = v_bind_2423;
  args[0] = v_t_2427;
  args[1] = v_k2_2421;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s1797919465x75214466_lam6(V self, V *args) {
  V v_a_2433 = args[0];
  V v_a_2430 = heff_env(self)[0];
  V v_a_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2430;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2431, v_a_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1797919465x75214466_lam5(V self, V *args) {
  V v_a_2431 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_2429 = heff_env(self)[1];
  V v_a_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432 = (g_prelude_2etraverse_24s1797919465x75214466(v_xs_244));
  V f_ = v_t_2432;
  heff_room[0] = v_a_2429;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam6, 1, 2, (V[]){v_a_2430, v_a_2431});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s1797919465x75214466_lam4(V self, V *args) {
  V v_a_2429 = args[0];
  V v_a_2430 = args[1];
  V v_a_2428 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2428;
  args[0] = heff_dup(v_a_2429);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam5, 1, 3, (V[]){v_xs_244, v_a_2429, v_a_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_prelude_2etraverse_24s2094958103x549422471_str0, 48, "expected a field declaration of the form `x : A`");
V g_prelude_2etraverse_24s2094958103x549422471_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s2094958103x549422471_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2094958103x549422471_lam0, 2, 0};
V g_prelude_2etraverse_24s2094958103x549422471_lam3(V self, V *args); static Clo g_prelude_2etraverse_24s2094958103x549422471_lam3_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2094958103x549422471_lam3, 2, 0};
V g_prelude_2etraverse_24s2094958103x549422471_lam5(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam4(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam6(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam2(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam1(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam7(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam10(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam9(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam8(V self, V *args);
Clo g_prelude_2etraverse_24s2094958103x549422471_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2094958103x549422471_entry, 1, 0};

V g_prelude_2etraverse_24s2094958103x549422471(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s2094958103x549422471_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_x2_245 = v_x_243;
    V v_a_2439;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_x22_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_DeclareField: {
        V v_x_248 = heff_field(v_x21_246, 0);
        V v_t_2410 = heff_field(v_x21_246, 2);
        V v_d_2411 = heff_field(v_x21_246, 3);
        heff_take_n(v_x21_246, 13ULL, 4);
        heff_drop(v_x22_247);
        V v_c_2412 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2410));
        v_a_2439 = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam1, 2, 3, (V[]){v_c_2412, v_d_2411, v_x_248});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x21_246, 0ULL, 1);
        v_a_2439 = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam7, 2, 1, (V[]){v_x22_247});
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    return heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam8, 2, 2, (V[]){v_a_2439, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s2094958103x549422471_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s2094958103x549422471(a[0]);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_c_2418 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  V v_t_2426;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_c_2418)) {
  case TAG_At: {
    V v_s_2425 = heff_field(v_c_2418, 1);
    heff_take_n(v_c_2418, 2ULL, 2);
    v_t_2426 = v_s_2425;
    break;
  }
  default: heff_nomatch(v_c_2418);
  }
  V v_t_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2423, v_t_2426})});
  V f_ = v_k_2421;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam4(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_m_2419 = heff_env(self)[0];
  V v_c_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_2419}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_2422, v_hd_2420, heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam5, 1, 2, (V[]){v_c_2418, v_k_2421})));
}
V g_prelude_2etraverse_24s2094958103x549422471_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2414;
  args[0] = heff_rec_n(3, shape_name__typ__dflt, (V[]){v_x_248, v_x_2415, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_d_2411 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_c_2428;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_d_2411)) {
  case TAG_Nothing: {
    v_c_2428 = ((V)&g_prelude_2etraverse_24s2094958103x549422471_lam3_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2418 = heff_field(v_d_2411, 0);
    heff_take_n(v_d_2411, 1ULL, 1);
    V v_m_2419 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2418)));
    v_c_2428 = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam4, 2, 2, (V[]){v_m_2419, v_c_2418});
    break;
  }
  default: heff_nomatch(v_d_2411);
  }
  V f_ = v_c_2428;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam6, 1, 3, (V[]){v_k_2414, v_x_248, v_x_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s2094958103x549422471_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_d_2411 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam2, 1, 4, (V[]){v_d_2411, v_hd_2413, v_k_2414, v_x_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam7(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k2_2432 = args[1];
  V v_x22_247 = heff_env(self)[0];
  V v_malg_2433 = heff_take_field(v_hd_2431, 2);
  V v_bind_2434 = heff_get_n(v_hd_2431, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(201LL), NTAG(TAG_SError), ((V)&g_prelude_2etraverse_24s2094958103x549422471_str0), v_x22_247, NTAG(TAG_Nothing)});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(v_malg_2433, 1, (V[]){v_t_2437}));
  V f_ = v_bind_2434;
  args[0] = v_t_2438;
  args[1] = v_k2_2432;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam10(V self, V *args) {
  V v_a_2444 = args[0];
  V v_a_2441 = heff_env(self)[0];
  V v_a_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2441;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2442, v_a_2444});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam9(V self, V *args) {
  V v_a_2442 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_2440 = heff_env(self)[1];
  V v_a_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2443 = (g_prelude_2etraverse_24s2094958103x549422471(v_xs_244));
  V f_ = v_t_2443;
  heff_room[0] = v_a_2440;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam10, 1, 2, (V[]){v_a_2441, v_a_2442});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s2094958103x549422471_lam8(V self, V *args) {
  V v_a_2440 = args[0];
  V v_a_2441 = args[1];
  V v_a_2439 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2439;
  args[0] = heff_dup(v_a_2440);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam9, 1, 3, (V[]){v_xs_244, v_a_2440, v_a_2441});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_prelude_2etraverse_24s1310917876x950458632_24apply2_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1310917876x950458632_24apply2_entry, 2, 0};

V g_prelude_2etraverse_24s1310917876x950458632_24apply2(V v_k_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Lam0_24prelude_2etraverse_24s1310917876x950458632_24apply2: {
    V v_p_242 = heff_field(v_k_240, 0);
    V v_a_243 = heff_field(v_k_240, 1);
    heff_take_n(v_k_240, 3ULL, 2);
    return heff_tail(v_p_242, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_a_243, v_z_241})});
  }
  case TAG_Lam1_24prelude_2etraverse_24s1310917876x950458632_24apply2: {
    V v_p_244 = heff_field(v_k_240, 0);
    V v_a_245 = heff_field(v_k_240, 1);
    V v_ru_24k_240_24Lam1_24prelude_2etraverse_24s1310917876x950458632_24apply2 = heff_take_reuse_n(v_k_240, 3ULL, 2);
    V t_0 = v_p_244;
    V t_1 = heff_tag_at_n(v_ru_24k_240_24Lam1_24prelude_2etraverse_24s1310917876x950458632_24apply2, TAG_Cons, 2, (V[]){v_a_245, v_z_241});
    v_k_240 = t_0;
    v_z_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_prelude_2etraverse_24s1310917876x950458632_24apply2_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1310917876x950458632_24apply2(a[0], a[1]);
}
V g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam0(V self, V *args); static Clo g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam0, 2, 0};
V g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam1(V self, V *args); static Clo g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam1_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam1, 2, 0};
V g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam2(V self, V *args); static Clo g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam2_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam2, 2, 0};

static V g_prelude_2einstanceOrderPair_24s757960770x1263704829_val;
static HEFF_ONCE g_prelude_2einstanceOrderPair_24s757960770x1263704829_st;
static V g_prelude_2einstanceOrderPair_24s757960770x1263704829_init(void) {
  return heff_rec_n(4, shape_eq__compare__lt__le, (V[]){heff_rec_n(1, shape_equal, (V[]){((V)&g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam0_clo)}), ((V)&g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036_clo), ((V)&g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam1_clo), ((V)&g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam2_clo)});
}
V g_prelude_2einstanceOrderPair_24s757960770x1263704829_get(void) {
  if (HEFF_DONE(g_prelude_2einstanceOrderPair_24s757960770x1263704829_st)) return g_prelude_2einstanceOrderPair_24s757960770x1263704829_val;
  return heff_global(&g_prelude_2einstanceOrderPair_24s757960770x1263704829_val, &g_prelude_2einstanceOrderPair_24s757960770x1263704829_st, g_prelude_2einstanceOrderPair_24s757960770x1263704829_init);
}
V g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam0(V self, V *args) {
  V v_x1_27_240 = args[0];
  V v_x2_27_241 = args[1];
  switch (heff_tag_of(v_x1_27_240)) {
  case TAG_MkPair: {
    V v_x1_242 = heff_field(v_x1_27_240, 0);
    V v_y1_243 = heff_field(v_x1_27_240, 1);
    heff_take_n(v_x1_27_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_27_241)) {
    case TAG_MkPair: {
      V v_x2_244 = heff_field(v_x2_27_241, 0);
      V v_y2_245 = heff_field(v_x2_27_241, 1);
      heff_take_n(v_x2_27_241, 3ULL, 2);
      if (((heff_dup(v_x1_242) == NTAG(TAG_True)) ? (heff_dup(v_x2_244) == NTAG(TAG_True)) : !(heff_dup(v_x2_244) == NTAG(TAG_True)))) {
        heff_drop(v_x1_242);
        heff_drop(v_x2_244);
        V v_t_246 = heff_get_n(heff_dup(heff_rfield(g_prelude_2eorderByCompare_24s1329979559x1043691411_get(), 0)), 0, 1);
        V f_ = v_t_246;
        args[0] = v_y1_243;
        args[1] = v_y2_245;
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      } else {
        heff_drop(v_x1_242);
        heff_drop(v_y1_243);
        heff_drop(v_x2_244);
        heff_drop(v_y2_245);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_27_241);
    }
  }
  default: return heff_nomatch(v_x1_27_240);
  }
}
V g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_y_248 = args[1];
  V v_x1_249 = ({ V a_0 = v_x_247; V a_1 = v_y_248; V r_ = (g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036(a_0, a_1)); heff_drop(v_x_247); heff_drop(v_y_248); r_; });
  switch (heff_tag_of(v_x1_249)) {
  case TAG_LT: {
    return NTAG(TAG_True);
  }
  case TAG_EQ: {
    return NTAG(TAG_False);
  }
  case TAG_GT: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_prelude_2einstanceOrderPair_24s757960770x1263704829_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_y_2411 = args[1];
  V v_x1_2412 = ({ V a_0 = v_x_2410; V a_1 = v_y_2411; V r_ = (g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036(a_0, a_1)); heff_drop(v_x_2410); heff_drop(v_y_2411); r_; });
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_LT: {
    return NTAG(TAG_True);
  }
  case TAG_EQ: {
    return NTAG(TAG_True);
  }
  case TAG_GT: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_2412);
  }
}
Clo g_prelude_2e_2b_2b_24f1206589350x791019229_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1206589350x791019229_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1206589350x791019229(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_rec_n(2, shape_fixed__op, (V[]){heff_dup(v_lit_241), v_x_243});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(v_ys_240, v_lit_241, v_xs_244, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1206589350x791019229_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1206589350x791019229(a[0], a[1], a[2]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1057423371x1101358195_str0, 1, "_");
Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1057423371x1101358195_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1057423371x1101358195(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24At = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_prelude_2e_2b_2b_24f1057423371x1101358195_str0), 2)) {
        heff_drop_cell(v_ru_24x1_241_24At, 2);
        heff_drop(v_x_244);
        return v_ys_240;
      } else {
        V v_t_245 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_ys_240));
        return heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_244, v_t_245});
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_249); r_; });
      return (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_241_24At, v_t_2410, v_ys_240));
    }
    case TAG_PatOp: {
      V v_ps_2413 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2413));
      V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2414); r_; });
      return (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_241_24At, v_t_2415, v_ys_240));
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatFloat: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatRecord: {
      V v_fs_2421 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2421));
      V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2422); r_; });
      return (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_241_24At, v_t_2423, v_ys_240));
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatAs: {
      V v_x_2425 = heff_field(v_x11_242, 0);
      V v_q_2427 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 5ULL, 3);
      V v_cell_2428 = heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_2425, heff_hole()});
      V v_u_2429 = (g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps(v_ys_240, v_q_2427, v_cell_2428));
      heff_drop(v_u_2429);
      return v_cell_2428;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f1057423371x1101358195_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1057423371x1101358195(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (!heff_strEq_c_lent(v_x_243, v_lit_241, 0)) {
      V v_x_245 = heff_tag_n(TAG_EVar, 1, (V[]){v_x_243});
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_247 = (g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps(v_ys_240, v_lit_241, v_xs_244, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(V v_ys_240, V v_x1_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    V v_t_244 = (g_prelude_2e_2b_2b(v_ys_242, v_ys_240));
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), v_t_244);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_241, 0);
    V v_xs_246 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_247 = heff_tag_re_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_245, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_247);
    V t_0 = v_ys_240;
    V t_1 = v_xs_246;
    V t_2 = v_ys_242;
    V t_3 = v_u_248;
    v_ys_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f677743828x1026746250_entry, 3, 0};

V g_prelude_2e_2b_2b_24f677743828x1026746250(V v_ys_240, V v_i_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_x_243);
      HEFF_LAST return g_prelude_2e_2b_2b_24tok2(v_ru_24x2_242_24Cons, v_xs_244, v_ys_240);
    } else {
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_246 = (g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(v_ys_240, heff_intSub(v_i_241, MK_INT(1LL)), v_xs_244, v_cell_245));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f677743828x1026746250(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f709746438x971999636_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f709746438x971999636_entry, 2, 0};

V g_prelude_2e_2b_2b_24f709746438x971999636(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_x12_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_re_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_247 = (g_prelude_2e_2b_2b_24f709746438x971999636_24dps(v_ys_240, v_x12_243, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f709746438x971999636_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f709746438x971999636(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f292729551x60683815_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f292729551x60683815_entry, 5, 0};

V g_prelude_2e_2b_2b_24f292729551x60683815(V v_ys_240, V v_box_24lit_241, V v_lit_242, V v_box_24lit_243, V v_x2_244) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    if (((v_lit_241 < heff_unbox_word(heff_strLength_lent(v_x_245, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_x_245, v_lit_242, 0)) == v_lit_243) : 1)) {
      V v_cell_247 = heff_tag_re_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_245, heff_hole()});
      V v_u_248 = (g_prelude_2e_2b_2b_24f292729551x60683815_24dps(v_ys_240, heff_box_word(v_lit_241), v_lit_242, heff_box_word(v_lit_243), v_xs_246, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_244_24Cons, 2);
      V t_0 = v_ys_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_xs_246;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_prelude_2e_2b_2b_24f292729551x60683815_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_prelude_2e_2b_2b_24f292729551x60683815(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_prelude_2e_2b_2b_24f543054808x1503188303_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f543054808x1503188303_entry, 9, 0};

V g_prelude_2e_2b_2b_24f543054808x1503188303(V v_ys_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_x3_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_x3_248);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_249);
      heff_drop(v_xs_2410);
      heff_drop_cell(v_ru_24x2_247_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_y_2411 = heff_field(v_x3_248, 0);
      V v_ys_2412 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      V v_t_2413 = ({ V a_0 = v_x_249; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_249); r_; });
      V v_t_2414 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2413), heff_dup(v_lit_245));
      V v_t_2415 = heff_strAppend(v_t_2414, heff_intShow(v_y_2411));
      V v_x_2416 = heff_strAppend(v_t_2415, heff_dup(v_lit_246));
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_x_2416, heff_hole()});
      V v_u_2418 = (g_prelude_2e_2b_2b_24f543054808x1503188303_24dps(v_ys_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_2410, v_ys_2412, v_cell_2417));
      heff_drop(v_u_2418);
      return v_cell_2417;
    }
    default: return heff_nomatch(v_x3_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2e_2b_2b_24f543054808x1503188303_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f543054808x1503188303(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_prelude_2e_2b_2b_24f603353378x1069129212_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f603353378x1069129212_24dps_entry, 11, 0};

V g_prelude_2e_2b_2b_24f603353378x1069129212_24dps(V v_ys_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_x2_248, V v_x3_249, V v_d_2410) {
top: ;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    heff_drop(v_lit_247);
    heff_drop(v_x3_249);
    return heff_setField(heff_dup(v_d_2410), MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_248, 0);
    V v_xs_2412 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24Cons = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_244);
      heff_drop(v_lit_247);
      heff_drop(v_x_2411);
      heff_drop(v_xs_2412);
      heff_drop_cell(v_ru_24x2_248_24Cons, 2);
      return heff_setField(heff_dup(v_d_2410), MK_INT(1LL), v_ys_240);
    }
    case TAG_Cons: {
      V v_y_2413 = heff_field(v_x3_249, 0);
      V v_ys_2414 = heff_field(v_x3_249, 1);
      heff_take_n(v_x3_249, 3ULL, 2);
      V v_t_2415 = (g_prelude_2esplit_2esplitFrom_240(v_y_2413, v_lit_243, heff_dup(v_lit_244), heff_strFind_lent(v_lit_245, v_y_2413, v_lit_246, 0), NTAG(TAG_Nil)));
      V v_t_2416 = ({ V a_0 = v_y_2413; V a_1 = v_t_2415; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2415); r_; });
      V v_t_2417 = heff_strAppend(heff_dup(v_lit_241), heff_intShow(v_x_2411));
      V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2417, heff_dup(v_lit_242)), v_t_2416);
      V v_x_2419 = heff_strAppend(v_t_2418, heff_dup(v_lit_247));
      V v_cell_2420 = heff_tag_at_n(v_ru_24x2_248_24Cons, TAG_Cons, 2, (V[]){v_x_2419, heff_hole()});
      V v_u_2421 = heff_setFieldPeek(v_d_2410, MK_INT(1LL), v_cell_2420);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_xs_2412;
      V t_9 = v_ys_2414;
      V t_10 = v_u_2421;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_x2_248 = t_8;
      v_x3_249 = t_9;
      v_d_2410 = t_10;
      goto top;
    }
    default: return heff_nomatch(v_x3_249);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_prelude_2e_2b_2b_24f603353378x1069129212_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V a6 = a[6]; V a10 = a[10]; V r = g_prelude_2e_2b_2b_24f603353378x1069129212_24dps(a[0], a[1], a[2], a3, a[4], a5, a6, a[7], a[8], a[9], a10); heff_drop(a3); heff_drop(a5); heff_drop(a6); heff_drop(a10); return r;
}
Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1085359736x1262841716_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1085359736x1262841716(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_x_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = (g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(v_ys_240, v_xs_243, v_cell_247));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1085359736x1262841716(a[0], a[1]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1960751014x547354513_str0, 2, "--");
HEFF_LIT(g_prelude_2e_2b_2b_24f1960751014x547354513_str1, 2, "--");
Clo g_prelude_2e_2b_2b_24f1960751014x547354513_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1960751014x547354513_entry, 8, 0};

V g_prelude_2e_2b_2b_24f1960751014x547354513(V v_ys_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_src_245, V v_name_246, V v_i_247) {
top: ;
  V v_j_248 = heff_strFind_lent(v_name_246, v_src_245, v_i_247, 4);
  if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    heff_drop(v_j_248);
    return v_ys_240;
  } else {
    V v_t_2410;
    if (heff_intEq_c_lent(v_j_248, MK_INT(0LL), 2)) {
      v_t_2410 = NTAG(TAG_True);
    } else {
      V v_c_249 = heff_strByteAt_lent(v_src_245, heff_intSub_lent(v_j_248, MK_INT(1LL), 2), 2);
      v_t_2410 = heff_bool(((heff_peek_word(v_c_249) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_249) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_249) == ((int64_t)46ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_249)) && (heff_peek_word(v_c_249) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_249)) && (heff_peek_word(v_c_249) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_249)) ? !(heff_peek_word(v_c_249) <= ((int64_t)57ULL)) : 1)))))));
      heff_drop(v_c_249);
    }
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V v_t_2411 = heff_intAdd_lent(v_j_248, heff_strLength_lent(v_name_246, 0), 2);
      if (heff_intLe_c(heff_strLength_lent(v_src_245, 0), v_t_2411)) {
        V v_t_2412 = (g_heff_2ebuild_2edriver_2elineStart(v_src_245, heff_dup(v_j_248)));
        V v_s_2413 = heff_strSlice_lent(v_src_245, v_t_2412, v_j_248, 2);
        if (!heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_prelude_2e_2b_2b_24f1960751014x547354513_str0), v_s_2413, MK_INT(0LL), 5))) {
          heff_drop(v_s_2413);
          V v_t_2414 = heff_intAdd_lent(v_j_248, heff_strLength_lent(v_lit_243, 0), 2);
          V v_x_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_241), NTAG(TAG_SWarning), heff_dup(v_lit_242), heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_j_248), v_t_2414}), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_lit_244)})});
          V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, heff_hole()});
          V v_t_2417 = heff_intAdd(v_j_248, heff_strLength_lent(v_name_246, 0));
          V v_u_2418 = (g_prelude_2e_2b_2b_24f1960751014x547354513_24dps(v_ys_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_src_245, v_name_246, v_t_2417, v_cell_2416));
          heff_drop(v_u_2418);
          return v_cell_2416;
        } else {
          heff_drop(v_s_2413);
          V t_0 = v_ys_240;
          V t_1 = v_lit_241;
          V t_2 = v_lit_242;
          V t_3 = v_lit_243;
          V t_4 = v_lit_244;
          V t_5 = v_src_245;
          V t_6 = v_name_246;
          V t_7 = heff_intAdd(v_j_248, MK_INT(1LL));
          v_ys_240 = t_0;
          v_lit_241 = t_1;
          v_lit_242 = t_2;
          v_lit_243 = t_3;
          v_lit_244 = t_4;
          v_src_245 = t_5;
          v_name_246 = t_6;
          v_i_247 = t_7;
          goto top;
        }
      } else {
        V v_t_2419 = heff_intAdd_lent(v_j_248, heff_strLength_lent(v_name_246, 0), 2);
        V v_c_2420 = heff_strByteAt_lent(v_src_245, v_t_2419, 2);
        if (((heff_peek_word(v_c_2420) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_2420) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_2420) == ((int64_t)46ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_2420)) && (heff_peek_word(v_c_2420) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_2420)) && (heff_peek_word(v_c_2420) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_2420)) ? !(heff_peek_word(v_c_2420) <= ((int64_t)57ULL)) : 1))))))) {
          heff_drop(v_c_2420);
          V v_t_2421 = (g_heff_2ebuild_2edriver_2elineStart(v_src_245, heff_dup(v_j_248)));
          V v_s_2422 = heff_strSlice_lent(v_src_245, v_t_2421, v_j_248, 2);
          if (!heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_prelude_2e_2b_2b_24f1960751014x547354513_str1), v_s_2422, MK_INT(0LL), 5))) {
            heff_drop(v_s_2422);
            V v_t_2423 = heff_intAdd_lent(v_j_248, heff_strLength_lent(v_lit_243, 0), 2);
            V v_x_2424 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_241), NTAG(TAG_SWarning), heff_dup(v_lit_242), heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_j_248), v_t_2423}), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_lit_244)})});
            V v_cell_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2424, heff_hole()});
            V v_t_2426 = heff_intAdd(v_j_248, heff_strLength_lent(v_name_246, 0));
            V v_u_2427 = (g_prelude_2e_2b_2b_24f1960751014x547354513_24dps(v_ys_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_src_245, v_name_246, v_t_2426, v_cell_2425));
            heff_drop(v_u_2427);
            return v_cell_2425;
          } else {
            heff_drop(v_s_2422);
            V t_0 = v_ys_240;
            V t_1 = v_lit_241;
            V t_2 = v_lit_242;
            V t_3 = v_lit_243;
            V t_4 = v_lit_244;
            V t_5 = v_src_245;
            V t_6 = v_name_246;
            V t_7 = heff_intAdd(v_j_248, MK_INT(1LL));
            v_ys_240 = t_0;
            v_lit_241 = t_1;
            v_lit_242 = t_2;
            v_lit_243 = t_3;
            v_lit_244 = t_4;
            v_src_245 = t_5;
            v_name_246 = t_6;
            v_i_247 = t_7;
            goto top;
          }
        } else {
          heff_drop(v_c_2420);
          V t_0 = v_ys_240;
          V t_1 = v_lit_241;
          V t_2 = v_lit_242;
          V t_3 = v_lit_243;
          V t_4 = v_lit_244;
          V t_5 = v_src_245;
          V t_6 = v_name_246;
          V t_7 = heff_intAdd(v_j_248, MK_INT(1LL));
          v_ys_240 = t_0;
          v_lit_241 = t_1;
          v_lit_242 = t_2;
          v_lit_243 = t_3;
          v_lit_244 = t_4;
          v_src_245 = t_5;
          v_name_246 = t_6;
          v_i_247 = t_7;
          goto top;
        }
      }
    } else {
      heff_drop(v_t_2410);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_src_245;
      V t_6 = v_name_246;
      V t_7 = heff_intAdd(v_j_248, MK_INT(1LL));
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_src_245 = t_5;
      v_name_246 = t_6;
      v_i_247 = t_7;
      goto top;
    }
  }
}
V g_prelude_2e_2b_2b_24f1960751014x547354513_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V a6 = a[6]; V r = g_prelude_2e_2b_2b_24f1960751014x547354513(a[0], a[1], a[2], a3, a[4], a5, a6, a[7]); heff_drop(a3); heff_drop(a5); heff_drop(a6); return r;
}
Clo g_prelude_2e_2b_2b_24f427551988x255400191_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f427551988x255400191_entry, 2, 0};

V g_prelude_2e_2b_2b_24f427551988x255400191(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_get_n(v_x_242, 0, 14);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f427551988x255400191_24dps(v_ys_240, v_xs_243, v_cell_245));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f427551988x255400191_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f427551988x255400191(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f427551988x255400191_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f427551988x255400191_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f427551988x255400191_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_get_n(v_x_243, 0, 14);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_247;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f427551988x255400191_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_prelude_2e_2b_2b_24f427551988x255400191_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}