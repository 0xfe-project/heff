// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_DeclareField 57313
#define TAG_EMatch 41631
#define TAG_EVar 52881
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkTF 48839
#define TAG_OfRecords 55355
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SetField 47531
#define TAG_Throw 56084
#define TAG_Tip 31527
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_count 296209705
#define LBL_def 308863
#define LBL_dflt 9576017
#define LBL_fixed 298804110
#define LBL_key 315609
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nameSpan 438211216
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_severity 75955546
#define LBL_slots 310891087
#define LBL_span 10032145
#define LBL_typ 324869
#define LBL_underLam 296337946
static uint32_t shape_chk__span[] = {LBL_chk, LBL_span};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_def__slots[] = {LBL_def, LBL_slots};
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_name__chk__span__nameSpan[] = {LBL_name, LBL_chk, LBL_span, LBL_nameSpan};
static uint32_t shape_name__typ__dflt[] = {LBL_name, LBL_typ, LBL_dflt};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2ebind_24s196996678x1811735276(V, V, V);
V g_co_2ebind_24s196996678x1811735276_entry(V self, V *a);
extern Clo g_co_2ebind_24s196996678x1811735276_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2efields_2egoLate(V, V);
V g_heff_2ecompile_2efields_2egoLate_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2egoLate_clo;
V g_heff_2ecompile_2efields_2enumbersW(V, V);
V g_heff_2ecompile_2efields_2enumbersW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2enumbersW_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_clo;
V g_heff_2ecompile_2emonadic_2enorm(V);
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enorm_clo;
V g_heff_2ecompile_2erematch_2ematchOf(V, V);
V g_heff_2ecompile_2erematch_2ematchOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_clo;
V g_heff_2ecompile_2erematch_2ematchOf_24tok2(V, V, V);
V g_heff_2ecompile_2erematch_2ematchOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_24tok2_clo;
V g_heff_2ecompile_2escalars_2efoundWith(V, V, V);
V g_heff_2ecompile_2escalars_2efoundWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2efoundWith_clo;
V g_heff_2ecompile_2escalars_2eslotsOf(V, V);
V g_heff_2ecompile_2escalars_2eslotsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotsOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eoneDef_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
HeffT2 g_heff_2ecompile_2espec_2eshapeGo_24cpr(V, V);
HeffT2 g_heff_2eelab_2eclauses_2epat_24cpr(V);
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
HeffT2 g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2emap_24s146946949x1862800301(V);
V g_list_2emap_24s146946949x1862800301_entry(V self, V *a);
extern Clo g_list_2emap_24s146946949x1862800301_clo;
V g_list_2ezipWith_24s1928181476x241816070(V, V);
V g_list_2ezipWith_24s1928181476x241816070_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1057423371x1101358195(V, V);
V g_prelude_2e_2b_2b_24f1057423371x1101358195_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_clo;
V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716(V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_clo;
V g_prelude_2e_2b_2b_24f1206589350x791019229(V, V, V);
V g_prelude_2e_2b_2b_24f1206589350x791019229_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1206589350x791019229_clo;
V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_clo;
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054(V, V, V);
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_clo;
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps_clo;
V g_prelude_2e_2b_2b_24f292729551x60683815(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f292729551x60683815_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f292729551x60683815_clo;
V g_prelude_2e_2b_2b_24f292729551x60683815_24dps(V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f292729551x60683815_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f292729551x60683815_24dps_clo;
V g_prelude_2e_2b_2b_24f427551988x255400191(V, V);
V g_prelude_2e_2b_2b_24f427551988x255400191_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f427551988x255400191_clo;
V g_prelude_2e_2b_2b_24f427551988x255400191_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f427551988x255400191_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f427551988x255400191_24dps_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_clo;
V g_prelude_2e_2b_2b_24f543054808x1503188303(V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f543054808x1503188303_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f543054808x1503188303_clo;
V g_prelude_2e_2b_2b_24f543054808x1503188303_24dps(V, V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250(V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636(V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_24dps_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_prelude_2edigitsFrom_24cpr(V, V, V);
V g_prelude_2etraverse_24s1024607077x497796552(V);
V g_prelude_2etraverse_24s1024607077x497796552_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1024607077x497796552_clo;
V g_prelude_2etraverse_24s1048254938x1609755296(V, V, V, V);
V g_prelude_2etraverse_24s1048254938x1609755296_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1048254938x1609755296_clo;
HeffT2 g_prelude_2etraverse_24s1206798274x929612205_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1252393826x821382319_24cpr(V, V);
V g_prelude_2etraverse_24s130657301x1556233528(V);
V g_prelude_2etraverse_24s130657301x1556233528_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s130657301x1556233528_clo;
V g_prelude_2etraverse_24s1442653311x1678194035(V);
V g_prelude_2etraverse_24s1442653311x1678194035_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1442653311x1678194035_clo;
V g_prelude_2etraverse_24s1736110006x954168809(V);
V g_prelude_2etraverse_24s1736110006x954168809_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1736110006x954168809_clo;
V g_prelude_2etraverse_24s1796722286x1908752336(V, V);
V g_prelude_2etraverse_24s1796722286x1908752336_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1796722286x1908752336_clo;
V g_prelude_2etraverse_24s1797919465x75214466(V);
V g_prelude_2etraverse_24s1797919465x75214466_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1797919465x75214466_clo;
V g_prelude_2etraverse_24s1887447647x928396251(V, V);
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1887447647x928396251_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_prelude_2etraverse_24s2094958103x549422471(V);
V g_prelude_2etraverse_24s2094958103x549422471_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2094958103x549422471_clo;
V g_prelude_2etraverse_24s2126788141x1913216601(V);
V g_prelude_2etraverse_24s2126788141x1913216601_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2126788141x1913216601_clo;
V g_prelude_2etraverse_24s248425057x1995322387(V);
V g_prelude_2etraverse_24s248425057x1995322387_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s248425057x1995322387_clo;
HeffT2 g_prelude_2etraverse_24s24931311x762276985_24cpr(V);
V g_prelude_2etraverse_24s277604616x578020818(V);
V g_prelude_2etraverse_24s277604616x578020818_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s277604616x578020818_clo;
V g_prelude_2etraverse_24s302418249x620314678(V, V, V, V, V);
V g_prelude_2etraverse_24s302418249x620314678_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s302418249x620314678_clo;
HeffT2 g_prelude_2etraverse_24s76089383x258265534_24cpr(V, V);
V g_prelude_2etraverse_24s812820150x374715993(V);
V g_prelude_2etraverse_24s812820150x374715993_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s812820150x374715993_clo;
V g_prelude_2etraverse_24s924094738x742129811(V);
V g_prelude_2etraverse_24s924094738x742129811_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s924094738x742129811_clo;
V g_prelude_2etraverse_24s956608878x365908798(V);
V g_prelude_2etraverse_24s956608878x365908798_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s956608878x365908798_clo;
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;

HeffT2 g_prelude_2edigitsFrom_24cpr(V v_s_240, V v_i_241, V v_n_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_n_242}});
  } else {
    if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) <= ((int64_t)57ULL)))) {
      int64_t v_t_243 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) - ((int64_t)48ULL));
      V v_t_244 = heff_intAdd(heff_intMul(v_n_242, MK_INT(10LL)), heff_box_word(v_t_243));
      V t_0 = v_s_240;
      V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
      V t_2 = v_t_244;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_n_242 = t_2;
      goto top;
    } else {
      heff_drop(v_i_241);
      heff_drop(v_n_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_prelude_2etraverse_24s1887447647x928396251_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1887447647x928396251_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1887447647x928396251_lam0, 1, 0};
V g_prelude_2etraverse_24s1887447647x928396251_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1887447647x928396251_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1887447647x928396251_entry, 2, 0};

V g_prelude_2etraverse_24s1887447647x928396251(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s1887447647x928396251_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s1887447647x928396251_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1887447647x928396251(a[0], a[1]);
}
V g_prelude_2etraverse_24s1887447647x928396251_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_prelude_2etraverse_24s1887447647x928396251_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s1887447647x928396251(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2etraverse_24s956608878x365908798_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s956608878x365908798_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s956608878x365908798_lam0, 1, 0};
V g_prelude_2etraverse_24s956608878x365908798_lam1(V self, V *args);
V g_prelude_2etraverse_24s956608878x365908798_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s956608878x365908798_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s956608878x365908798_entry, 1, 0};

V g_prelude_2etraverse_24s956608878x365908798(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s956608878x365908798_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2416;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_248 = heff_field(v_x_243, 3);
      V v_a_249 = heff_field(v_x_243, 4);
      heff_take_n(v_x_243, 25ULL, 5);
      V v_t_2410 = (g_list_2emap_24s146946949x1862800301(heff_dup(v_a_245)));
      HeffT2 v_t_2411 = (g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(NTAG(TAG_Nil), v_t_2410));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          heff_drop(v_a_245);
          heff_drop(v_a_248);
          heff_drop(v_a_249);
          V v_a_2414 = v_field_2413;
          v_m_2416 = heff_clo_n(g_prelude_2etraverse_24s956608878x365908798_lam1, 1, 1, (V[]){v_a_2414});
        } else {
          heff_drop(v_field_2413);
          v_m_2416 = heff_tr(heff_call(((V)&g_prelude_2etraverse_24s1048254938x1609755296_clo), 3, (V[]){v_a_248, v_a_249, v_a_245}));
        }
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_clo_n(g_prelude_2etraverse_24s956608878x365908798_lam2, 1, 2, (V[]){v_m_2416, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s956608878x365908798_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s956608878x365908798(a[0]);
}
V g_prelude_2etraverse_24s956608878x365908798_lam0(V self, V *args) {
  V v_st_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_st_241});
}
V g_prelude_2etraverse_24s956608878x365908798_lam1(V self, V *args) {
  V v_a_2415 = args[0];
  V v_a_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_a_2414}), v_a_2415});
}
V g_prelude_2etraverse_24s956608878x365908798_lam2(V self, V *args) {
  V v_st_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2417}));
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_MkPair: {
    V v_x11_2419 = heff_field(v_x1_2418, 0);
    V v_st_2420 = heff_field(v_x1_2418, 1);
    V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
    switch (heff_tag_of(v_x11_2419)) {
    case TAG_Left: {
      V v_e_2421 = heff_field(v_x11_2419, 0);
      V v_ru_24x11_2419_24Left = heff_take_reuse_n(v_x11_2419, 1ULL, 1);
      heff_drop(v_xs_244);
      return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2419_24Left, TAG_Left, 1, (V[]){v_e_2421}), v_st_2420});
    }
    case TAG_Right: {
      V v_x_2422 = heff_field(v_x11_2419, 0);
      V v_ru_24x11_2419_24Right = heff_take_reuse_n(v_x11_2419, 1ULL, 1);
      V v_m_2423 = (g_prelude_2etraverse_24s956608878x365908798(v_xs_244));
      V v_x1_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_st_2420}));
      switch (heff_tag_of(v_x1_2424)) {
      case TAG_MkPair: {
        V v_x11_2425 = heff_field(v_x1_2424, 0);
        V v_st_2426 = heff_field(v_x1_2424, 1);
        V v_ru_24x1_2424_24MkPair = heff_take_reuse_n(v_x1_2424, 3ULL, 2);
        switch (heff_tag_of(v_x11_2425)) {
        case TAG_Left: {
          V v_e_2427 = heff_field(v_x11_2425, 0);
          V v_ru_24x11_2425_24Left = heff_take_reuse_n(v_x11_2425, 1ULL, 1);
          heff_drop(v_x_2422);
          heff_drop_cell(v_ru_24x11_2419_24Right, 1);
          heff_drop_cell(v_ru_24x1_2424_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2425_24Left, TAG_Left, 1, (V[]){v_e_2427}), v_st_2426});
        }
        case TAG_Right: {
          V v_x_2428 = heff_field(v_x11_2425, 0);
          heff_take_n(v_x11_2425, 1ULL, 1);
          V v_t_2429 = heff_tag_at_n(v_ru_24x11_2419_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_2424_24MkPair, TAG_Cons, 2, (V[]){v_x_2422, v_x_2428})});
          return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){v_t_2429, v_st_2426});
        }
        default: return heff_nomatch(v_x11_2425);
        }
      }
      default: return heff_nomatch(v_x1_2424);
      }
    }
    default: return heff_nomatch(v_x11_2419);
    }
  }
  default: return heff_nomatch(v_x1_2418);
  }
}

HeffT2 g_prelude_2etraverse_24s76089383x258265534_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      V v_ru_24x_242_24MkArm = heff_take_reuse_n(v_x_242, 7ULL, 3);
      HeffT2 v_t_247 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_a_246, v_p_241));
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        V v_a_2410 = v_field_248;
        V v_a_2411 = v_field_249;
        HeffT2 v_t_2412 = (g_prelude_2etraverse_24s76089383x258265534_24cpr(v_xs_243, v_a_2411));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_x_2415 = v_field_2413;
          V v_st_2416 = v_field_2414;
          V v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x_242_24MkArm, TAG_MkArm, 3, (V[]){v_a_244, v_a_245, v_a_2410}), v_x_2415});
          return ((HeffT2){{v_t_2417, v_st_2416}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s2126788141x1913216601_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s2126788141x1913216601_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2126788141x1913216601_lam0, 1, 0};
V g_prelude_2etraverse_24s2126788141x1913216601_lam1(V self, V *args);
V g_prelude_2etraverse_24s2126788141x1913216601_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s2126788141x1913216601_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2126788141x1913216601_entry, 1, 0};

V g_prelude_2etraverse_24s2126788141x1913216601(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s2126788141x1913216601_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_a_246 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_a_245));
      v_m_2411 = heff_clo_n(g_prelude_2etraverse_24s2126788141x1913216601_lam1, 1, 2, (V[]){v_a_246, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_prelude_2etraverse_24s2126788141x1913216601_lam2, 1, 2, (V[]){v_m_2411, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s2126788141x1913216601_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s2126788141x1913216601(a[0]);
}
V g_prelude_2etraverse_24s2126788141x1913216601_lam0(V self, V *args) {
  V v_s_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_241});
}
V g_prelude_2etraverse_24s2126788141x1913216601_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_248 = heff_tr(heff_call(v_a_246, 1, (V[]){v_a_247}));
  switch (heff_tag_of(v_a_248)) {
  case TAG_MkPair: {
    V v_a_249 = heff_field(v_a_248, 0);
    V v_a_2410 = heff_field(v_a_248, 1);
    V v_ru_24a_248_24MkPair = heff_take_reuse_n(v_a_248, 3ULL, 2);
    return heff_tag_at_n(v_ru_24a_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_249}), v_a_2410});
  }
  default: return heff_nomatch(v_a_248);
  }
}
V g_prelude_2etraverse_24s2126788141x1913216601_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_m_2416 = (g_prelude_2etraverse_24s2126788141x1913216601(v_xs_243));
    V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2415}));
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_s_2419 = heff_field(v_x2_2417, 1);
      V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_Cons, 2, (V[]){v_x_2414, v_x_2418}), v_s_2419});
    }
    default: return heff_nomatch(v_x2_2417);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}

HeffT2 g_prelude_2etraverse_24s1252393826x821382319_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eoneDef_24cpr(v_x_242, v_p_241));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_s_248 = v_field_246;
      HeffT2 v_t_249 = (g_prelude_2etraverse_24s1252393826x821382319_24cpr(v_xs_243, v_s_248));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        V v_s_2413 = v_field_2411;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_x_2412}), v_s_2413}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1934076392x614790049_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1934076392x614790049_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1934076392x614790049_lam0, 2, 0};
V g_prelude_2etraverse_24s1934076392x614790049_lam3(V self, V *args);
V g_prelude_2etraverse_24s1934076392x614790049_lam2(V self, V *args);
V g_prelude_2etraverse_24s1934076392x614790049_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1934076392x614790049_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1934076392x614790049_entry, 2, 0};

V g_prelude_2etraverse_24s1934076392x614790049(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s1934076392x614790049_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_a_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_prelude_2etraverse_24s1934076392x614790049_lam1, 2, 3, (V[]){v_a_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1934076392x614790049(a[0], a[1]);
}
V g_prelude_2etraverse_24s1934076392x614790049_lam0(V self, V *args) {
  V v_a_242 = args[0];
  V v_a_243 = args[1];
  heff_drop(v_a_242);
  V f_ = v_a_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1934076392x614790049_lam3(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_248 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_249, v_a_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1934076392x614790049_lam2(V self, V *args) {
  V v_a_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  V v_a_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_a_2410 = (g_prelude_2etraverse_24s1934076392x614790049(v_f_240, v_xs_245));
  V f_ = v_a_2410;
  heff_room[0] = v_a_247;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s1934076392x614790049_lam3, 1, 2, (V[]){v_a_248, v_a_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s1934076392x614790049_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_a_248 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_246;
  args[0] = heff_dup(v_a_247);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s1934076392x614790049_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_a_247, v_a_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s924094738x742129811_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s924094738x742129811_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s924094738x742129811_lam0, 1, 0};
V g_prelude_2etraverse_24s924094738x742129811_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s924094738x742129811_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s924094738x742129811_entry, 1, 0};

V g_prelude_2etraverse_24s924094738x742129811(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s924094738x742129811_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_244 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s924094738x742129811_lam1, 1, 2, (V[]){v_a_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s924094738x742129811_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s924094738x742129811(a[0]);
}
V g_prelude_2etraverse_24s924094738x742129811_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s924094738x742129811_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_246 = heff_tr(heff_call(v_a_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_a_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_a_246, 0);
    V v_n_248 = heff_field(v_a_246, 1);
    V v_ru_24a_246_24MkPair = heff_take_reuse_n(v_a_246, 3ULL, 2);
    V v_m_249 = (g_prelude_2etraverse_24s924094738x742129811(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24a_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_a_246);
  }
}
V g_prelude_2etraverse_24s1736110006x954168809_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1736110006x954168809_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1736110006x954168809_lam0, 1, 0};
V g_prelude_2etraverse_24s1736110006x954168809_lam1(V self, V *args);
V g_prelude_2etraverse_24s1736110006x954168809_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s1736110006x954168809_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1736110006x954168809_entry, 1, 0};

V g_prelude_2etraverse_24s1736110006x954168809(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1736110006x954168809_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_a_246 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_a_245));
      v_m_2411 = heff_clo_n(g_prelude_2etraverse_24s1736110006x954168809_lam1, 1, 2, (V[]){v_a_246, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_prelude_2etraverse_24s1736110006x954168809_lam2, 1, 2, (V[]){v_m_2411, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1736110006x954168809_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1736110006x954168809(a[0]);
}
V g_prelude_2etraverse_24s1736110006x954168809_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1736110006x954168809_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_248 = heff_tr(heff_call(v_a_246, 1, (V[]){v_a_247}));
  switch (heff_tag_of(v_a_248)) {
  case TAG_MkPair: {
    V v_a_249 = heff_field(v_a_248, 0);
    V v_a_2410 = heff_field(v_a_248, 1);
    V v_ru_24a_248_24MkPair = heff_take_reuse_n(v_a_248, 3ULL, 2);
    return heff_tag_at_n(v_ru_24a_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_249}), v_a_2410});
  }
  default: return heff_nomatch(v_a_248);
  }
}
V g_prelude_2etraverse_24s1736110006x954168809_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_m_2416 = (g_prelude_2etraverse_24s1736110006x954168809(v_xs_243));
    V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_n_2415}));
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_n_2419 = heff_field(v_x2_2417, 1);
      V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_Cons, 2, (V[]){v_x_2414, v_x_2418}), v_n_2419});
    }
    default: return heff_nomatch(v_x2_2417);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_prelude_2etraverse_24s812820150x374715993_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s812820150x374715993_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s812820150x374715993_lam0, 1, 0};
V g_prelude_2etraverse_24s812820150x374715993_lam2(V self, V *args);
V g_prelude_2etraverse_24s812820150x374715993_lam1(V self, V *args);
V g_prelude_2etraverse_24s812820150x374715993_lam3(V self, V *args);
Clo g_prelude_2etraverse_24s812820150x374715993_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s812820150x374715993_entry, 1, 0};

V g_prelude_2etraverse_24s812820150x374715993(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s812820150x374715993_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_d_244 = v_x_242;
    V v_m_245 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(heff_dup(heff_rfield(v_d_244, 2))));
    V v_m_2420 = heff_clo_n(g_prelude_2etraverse_24s812820150x374715993_lam1, 1, 2, (V[]){v_m_245, v_d_244});
    return heff_clo_n(g_prelude_2etraverse_24s812820150x374715993_lam3, 1, 2, (V[]){v_m_2420, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s812820150x374715993_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s812820150x374715993(a[0]);
}
V g_prelude_2etraverse_24s812820150x374715993_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s812820150x374715993_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_248, v_n_2412});
}
V g_prelude_2etraverse_24s812820150x374715993_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_d_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_248), NTAG(TAG_Nil)});
    V v_ns_2411 = (g_heff_2ecompile_2efields_2enumbersW(NTAG(TAG_Nil), v_t_2410));
    V v_m_2415;
    switch (heff_tag_of(v_ns_2411)) {
    case TAG_Nil: {
      v_m_2415 = heff_clo_n(g_prelude_2etraverse_24s812820150x374715993_lam2, 1, 1, (V[]){v_x_248});
      break;
    }
    case TAG_Cons: {
      v_m_2415 = (g_heff_2ecompile_2efields_2egoLate(v_ns_2411, v_x_248));
      break;
    }
    default: heff_nomatch(v_ns_2411);
    }
    V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_n_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      V v_t_2419 = ({ V rv_2 = v_x_2417; V rr_ = heff_rec_reuse_nf(v_d_244, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_n_2418});
    }
    default: return heff_nomatch(v_x2_2416);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2etraverse_24s812820150x374715993_lam3(V self, V *args) {
  V v_n_2421 = args[0];
  V v_m_2420 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2422 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_n_2421}));
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    V v_n_2424 = heff_field(v_x2_2422, 1);
    V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
    V v_m_2425 = (g_prelude_2etraverse_24s812820150x374715993(v_xs_243));
    V v_x2_2426 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_n_2424}));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_n_2428 = heff_field(v_x2_2426, 1);
      V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_Cons, 2, (V[]){v_x_2423, v_x_2427}), v_n_2428});
    }
    default: return heff_nomatch(v_x2_2426);
    }
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_prelude_2etraverse_24s1024607077x497796552_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1024607077x497796552_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1024607077x497796552_lam0, 1, 0};
V g_prelude_2etraverse_24s1024607077x497796552_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1024607077x497796552_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1024607077x497796552_entry, 1, 0};

V g_prelude_2etraverse_24s1024607077x497796552(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1024607077x497796552_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s1024607077x497796552_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1024607077x497796552_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1024607077x497796552(a[0]);
}
V g_prelude_2etraverse_24s1024607077x497796552_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1024607077x497796552_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_prelude_2etraverse_24s1024607077x497796552(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2etraverse_24s248425057x1995322387_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s248425057x1995322387_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s248425057x1995322387_lam0, 1, 0};
V g_prelude_2etraverse_24s248425057x1995322387_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s248425057x1995322387_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s248425057x1995322387_entry, 1, 0};

V g_prelude_2etraverse_24s248425057x1995322387(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s248425057x1995322387_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(heff_dup(heff_rfield(v_x_242, 2))));
    return heff_clo_n(g_prelude_2etraverse_24s248425057x1995322387_lam1, 1, 3, (V[]){v_m_244, v_xs_243, v_x_242});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s248425057x1995322387_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s248425057x1995322387(a[0]);
}
V g_prelude_2etraverse_24s248425057x1995322387_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s248425057x1995322387_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_prelude_2etraverse_24s248425057x1995322387(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      V v_t_2413 = ({ V rv_2 = v_x_247; V rr_ = heff_rec_reuse_nf(v_x_242, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_t_2413, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_prelude_2etraverse_24s302418249x620314678_str0, 1, "_");
V g_prelude_2etraverse_24s302418249x620314678_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s302418249x620314678_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s302418249x620314678_lam0, 1, 0};
V g_prelude_2etraverse_24s302418249x620314678_lam1(V self, V *args);
V g_prelude_2etraverse_24s302418249x620314678_lam2(V self, V *args);
V g_prelude_2etraverse_24s302418249x620314678_lam3(V self, V *args);
V g_prelude_2etraverse_24s302418249x620314678_lam4(V self, V *args);
Clo g_prelude_2etraverse_24s302418249x620314678_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s302418249x620314678_entry, 5, 0};

V g_prelude_2etraverse_24s302418249x620314678(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return ((V)&g_prelude_2etraverse_24s302418249x620314678_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_x_248 = heff_dup(v_lit_240);
    V v_t_249 = heff_dup(v_lit_241);
    V v_vs_2410 = heff_dup(v_lit_242);
    V v_f_2411 = heff_dup(v_lit_243);
    V v_x5_2412 = v_x_246;
    V v_m_2446;
    switch (heff_tag_of(v_x5_2412)) {
    case TAG_MkArm: {
      V v_t2_2413 = heff_field(v_x5_2412, 0);
      V v_ws_2414 = heff_field(v_x5_2412, 1);
      V v_c_2415 = heff_field(v_x5_2412, 2);
      heff_take_n(v_x5_2412, 7ULL, 3);
      V v_x_2416 = heff_dup(v_x_248);
      V v_vs_2417 = heff_dup(v_vs_2410);
      V v_f_2418 = v_f_2411;
      V v_c_2419 = heff_dup(v_c_2415);
      V v_t_2420 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_2419), NTAG(TAG_Nil)});
      V v_t_2421 = (g_heff_2ecompile_2eir_2ecountW(v_x_2416, MK_INT(0LL), v_t_2420));
      V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_2419), NTAG(TAG_Nil)});
      V v_t_2423 = ({ V a_0 = v_x_2416; V a_1 = v_t_2422; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2416); r_; });
      V v_x_2424 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2421, v_t_2423}), 0, 2);
      V v_t_2432;
      if (heff_intLt_c(MK_INT(0LL), v_x_2424)) {
        V v_x1_2431 = ({ V a_0 = heff_clo_n(g_prelude_2etraverse_24s302418249x620314678_lam1, 1, 2, (V[]){v_f_2418, v_c_2419}); V a_1 = v_vs_2417; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_vs_2417); r_; });
        v_t_2432 = heff_bool(!(heff_dup(v_x1_2431) == NTAG(TAG_True)));
        heff_drop(v_x1_2431);
      } else {
        heff_drop(v_vs_2417);
        heff_drop(v_f_2418);
        heff_drop(v_c_2419);
        v_t_2432 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
        heff_drop(v_x_248);
        heff_drop(v_t_249);
        heff_drop(v_vs_2410);
        heff_drop(v_t_2432);
        v_m_2446 = heff_clo_n(g_prelude_2etraverse_24s302418249x620314678_lam2, 1, 3, (V[]){v_t2_2413, v_ws_2414, v_c_2415});
      } else {
        heff_drop(v_t_2432);
        V v_m_2434 = (g_prelude_2etraverse_24s277604616x578020818(heff_dup(v_vs_2410)));
        v_m_2446 = heff_clo_n(g_prelude_2etraverse_24s302418249x620314678_lam3, 1, 7, (V[]){v_m_2434, v_vs_2410, v_c_2415, v_t_249, v_x_248, v_t2_2413, v_ws_2414});
      }
      break;
    }
    default: heff_nomatch(v_x5_2412);
    }
    return heff_clo_n(g_prelude_2etraverse_24s302418249x620314678_lam4, 1, 6, (V[]){v_m_2446, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_247});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_prelude_2etraverse_24s302418249x620314678_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s302418249x620314678(a[0], a[1], a[2], a[3], a[4]);
}
V g_prelude_2etraverse_24s302418249x620314678_lam0(V self, V *args) {
  V v_n_245 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_245});
}
V g_prelude_2etraverse_24s302418249x620314678_lam1(V self, V *args) {
  V v_v_2425 = args[0];
  V v_f_2418 = heff_env(self)[0];
  V v_c_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (!heff_strEq_c_lent(v_v_2425, v_f_2418, 0)) {
    heff_drop(v_f_2418);
    if (!heff_strEq_c_lent(v_v_2425, ((V)&g_prelude_2etraverse_24s302418249x620314678_str0), 2)) {
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_2419), NTAG(TAG_Nil)});
      V v_t_2427 = (g_heff_2ecompile_2eir_2ecountW(v_v_2425, MK_INT(0LL), v_t_2426));
      V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_2419, NTAG(TAG_Nil)});
      V v_t_2429 = ({ V a_0 = v_v_2425; V a_1 = v_t_2428; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_v_2425); r_; });
      V v_x_2430 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2427, v_t_2429}), 0, 2);
      V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2430, 1));
      heff_drop(v_x_2430);
      return v_ret_24bool;
    } else {
      heff_drop(v_v_2425);
      heff_drop(v_c_2419);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_v_2425);
    heff_drop(v_f_2418);
    heff_drop(v_c_2419);
    return NTAG(TAG_False);
  }
}
V g_prelude_2etraverse_24s302418249x620314678_lam2(V self, V *args) {
  V v_n_2433 = args[0];
  V v_t2_2413 = heff_env(self)[0];
  V v_ws_2414 = heff_env(self)[1];
  V v_c_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t2_2413, v_ws_2414, v_c_2415}), v_n_2433});
}
V g_prelude_2etraverse_24s302418249x620314678_lam3(V self, V *args) {
  V v_n_2435 = args[0];
  V v_m_2434 = heff_env(self)[0];
  V v_vs_2410 = heff_env(self)[1];
  V v_c_2415 = heff_env(self)[2];
  V v_t_249 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_t2_2413 = heff_env(self)[5];
  V v_ws_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2436 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_n_2435}));
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkPair: {
    V v_x_2437 = heff_field(v_x2_2436, 0);
    V v_n_2438 = heff_field(v_x2_2436, 1);
    V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 3ULL, 2);
    V v_ps_2439 = (g_list_2ezipWith_24s1928181476x241816070(v_vs_2410, heff_dup(v_x_2437)));
    V v_m_2440 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2439; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2439); r_; });
    V v_t_2441 = (g_std_2eordmap_2esize(v_m_2440));
    V v_t_2442;
    if (heff_intEq_c(v_t_2441, MK_INT(0LL))) {
      heff_drop(v_m_2440);
      v_t_2442 = v_c_2415;
    } else {
      v_t_2442 = ({ V a_0 = v_m_2440; V a_1 = v_c_2415; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2440); r_; });
    }
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_249, v_x_2437, v_t_2442}), NTAG(TAG_Nil)});
    V v_t_2444 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_248}), v_t_2443});
    V v_x_2445 = heff_tag_n(TAG_MkArm, 3, (V[]){v_t2_2413, v_ws_2414, v_t_2444});
    return heff_tag_at_n(v_ru_24x2_2436_24MkPair, TAG_MkPair, 2, (V[]){v_x_2445, v_n_2438});
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_prelude_2etraverse_24s302418249x620314678_lam4(V self, V *args) {
  V v_n_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  V v_xs_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_n_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    V v_m_2451 = (g_prelude_2etraverse_24s302418249x620314678(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_247));
    V v_x2_2452 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_n_2450}));
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_MkPair: {
      V v_x_2453 = heff_field(v_x2_2452, 0);
      V v_n_2454 = heff_field(v_x2_2452, 1);
      V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_Cons, 2, (V[]){v_x_2449, v_x_2453}), v_n_2454});
    }
    default: return heff_nomatch(v_x2_2452);
    }
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1796722286x1908752336_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1796722286x1908752336_lam0, 1, 0};
V g_prelude_2etraverse_24s1796722286x1908752336_lam1(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam2(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam3(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam4(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam5(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam6(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam7(V self, V *args);
V g_prelude_2etraverse_24s1796722286x1908752336_lam8(V self, V *args);
Clo g_prelude_2etraverse_24s1796722286x1908752336_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1796722286x1908752336_entry, 2, 0};

V g_prelude_2etraverse_24s1796722286x1908752336(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((V)&g_prelude_2etraverse_24s1796722286x1908752336_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_dup(v_lit_240);
    V v_a_246 = v_x_243;
    V v_m_2451;
    switch (heff_tag_of(v_a_246)) {
    case TAG_MkArm: {
      V v_t_247 = heff_dup(heff_field(v_a_246, 0));
      V v_vs_248 = heff_dup(heff_field(v_a_246, 1));
      V v_a3_249 = heff_dup(heff_field(v_a_246, 2));
      switch (heff_tag_of(v_a3_249)) {
      case TAG_EMatch: {
        V v_a31_2410 = heff_field(v_a3_249, 0);
        V v_inner_2411 = heff_field(v_a3_249, 1);
        heff_take_n(v_a3_249, 3ULL, 2);
        switch (heff_tag_of(v_a31_2410)) {
        case TAG_EVar: {
          V v_f_2412 = heff_field(v_a31_2410, 0);
          heff_take_n(v_a31_2410, 1ULL, 1);
          heff_drop_tag(v_a_246, 3);
          V v_t_2413 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_f_2412)}));
          V v_t_2414 = (g_list_2eany(v_t_2413, v_vs_248));
          if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
            heff_drop(v_t_2414);
            V v_x_2415 = heff_dup(v_x_245);
            V v_inner_2416 = heff_dup(v_inner_2411);
            V v_t_2427 = (g_list_2eany(heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam1, 1, 1, (V[]){heff_dup(v_x_2415)}), v_inner_2416));
            V v_t_2438;
            if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
              heff_drop(v_t_2427);
              v_t_2438 = ({ V a_0 = heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam2, 1, 1, (V[]){v_x_2415}); V a_1 = v_inner_2416; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_inner_2416); r_; });
            } else {
              heff_drop(v_x_2415);
              heff_drop(v_inner_2416);
              heff_drop(v_t_2427);
              v_t_2438 = NTAG(TAG_False);
            }
            if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
              heff_drop(v_t_2438);
              V v_m_2439 = (g_prelude_2etraverse_24s302418249x620314678(v_x_245, heff_dup(v_t_247), heff_dup(v_vs_248), heff_dup(v_f_2412), v_inner_2411));
              v_m_2451 = heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam3, 1, 4, (V[]){v_m_2439, v_f_2412, v_t_247, v_vs_248});
            } else {
              heff_drop(v_x_245);
              heff_drop(v_t_2438);
              v_m_2451 = heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam4, 1, 4, (V[]){v_f_2412, v_inner_2411, v_t_247, v_vs_248});
            }
          } else {
            heff_drop(v_x_245);
            heff_drop(v_t_2414);
            v_m_2451 = heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam5, 1, 4, (V[]){v_f_2412, v_inner_2411, v_t_247, v_vs_248});
          }
          break;
        }
        default: {
          heff_drop(v_x_245);
          heff_drop(v_t_247);
          heff_drop(v_vs_248);
          heff_drop(v_a31_2410);
          heff_drop(v_inner_2411);
          v_m_2451 = heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam6, 1, 1, (V[]){v_a_246});
          break;
        }
        }
        break;
      }
      default: {
        heff_drop(v_x_245);
        heff_drop(v_t_247);
        heff_drop(v_vs_248);
        heff_drop(v_a3_249);
        v_m_2451 = heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam7, 1, 1, (V[]){v_a_246});
        break;
      }
      }
      break;
    }
    default: heff_nomatch(v_a_246);
    }
    return heff_clo_n(g_prelude_2etraverse_24s1796722286x1908752336_lam8, 1, 3, (V[]){v_m_2451, v_lit_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1796722286x1908752336_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1796722286x1908752336(a[0], a[1]);
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam1(V self, V *args) {
  V v_a_2417 = args[0];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_2421;
  switch (heff_tag_of(v_a_2417)) {
  case TAG_MkArm: {
    V v_b_2420 = heff_field(v_a_2417, 2);
    heff_take_n(v_a_2417, 4ULL, 3);
    v_e_2421 = v_b_2420;
    break;
  }
  default: heff_nomatch(v_a_2417);
  }
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2421), NTAG(TAG_Nil)});
  V v_t_2423 = (g_heff_2ecompile_2eir_2ecountW(v_x_2415, MK_INT(0LL), v_t_2422));
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2421, NTAG(TAG_Nil)});
  V v_t_2425 = ({ V a_0 = v_x_2415; V a_1 = v_t_2424; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2415); r_; });
  V v_x_2426 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2423, v_t_2425}), 0, 2);
  V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2426, 1));
  heff_drop(v_x_2426);
  return v_ret_24bool;
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam2(V self, V *args) {
  V v_a_2428 = args[0];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_2432;
  switch (heff_tag_of(v_a_2428)) {
  case TAG_MkArm: {
    V v_b_2431 = heff_field(v_a_2428, 2);
    heff_take_n(v_a_2428, 4ULL, 3);
    v_e_2432 = v_b_2431;
    break;
  }
  default: heff_nomatch(v_a_2428);
  }
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2432), NTAG(TAG_Nil)});
  V v_t_2434 = (g_heff_2ecompile_2eir_2ecountW(v_x_2415, MK_INT(0LL), v_t_2433));
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2432, NTAG(TAG_Nil)});
  V v_t_2436 = ({ V a_0 = v_x_2415; V a_1 = v_t_2435; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2415); r_; });
  V v_x_2437 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2434, v_t_2436}), 0, 2);
  V v_ret_24bool = heff_bool(!heff_intLt_c_lent(MK_INT(0LL), v_x_2437, 1));
  heff_drop(v_x_2437);
  return v_ret_24bool;
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam3(V self, V *args) {
  V v_n_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_f_2412 = heff_env(self)[1];
  V v_t_247 = heff_env(self)[2];
  V v_vs_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_n_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    V v_t_2444 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_f_2412}), v_x_2442});
    return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_247, v_vs_248, v_t_2444}), v_n_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam4(V self, V *args) {
  V v_n_2445 = args[0];
  V v_f_2412 = heff_env(self)[0];
  V v_inner_2411 = heff_env(self)[1];
  V v_t_247 = heff_env(self)[2];
  V v_vs_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2446 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_f_2412}), v_inner_2411});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_247, v_vs_248, v_t_2446}), v_n_2445});
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam5(V self, V *args) {
  V v_n_2447 = args[0];
  V v_f_2412 = heff_env(self)[0];
  V v_inner_2411 = heff_env(self)[1];
  V v_t_247 = heff_env(self)[2];
  V v_vs_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2448 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_f_2412}), v_inner_2411});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_247, v_vs_248, v_t_2448}), v_n_2447});
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam6(V self, V *args) {
  V v_n_2449 = args[0];
  V v_a_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_246, v_n_2449});
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam7(V self, V *args) {
  V v_n_2450 = args[0];
  V v_a_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_246, v_n_2450});
}
V g_prelude_2etraverse_24s1796722286x1908752336_lam8(V self, V *args) {
  V v_n_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2453 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_n_2452}));
  switch (heff_tag_of(v_x2_2453)) {
  case TAG_MkPair: {
    V v_x_2454 = heff_field(v_x2_2453, 0);
    V v_n_2455 = heff_field(v_x2_2453, 1);
    V v_ru_24x2_2453_24MkPair = heff_take_reuse_n(v_x2_2453, 3ULL, 2);
    V v_m_2456 = (g_prelude_2etraverse_24s1796722286x1908752336(v_lit_240, v_xs_244));
    V v_x2_2457 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_n_2455}));
    switch (heff_tag_of(v_x2_2457)) {
    case TAG_MkPair: {
      V v_x_2458 = heff_field(v_x2_2457, 0);
      V v_n_2459 = heff_field(v_x2_2457, 1);
      V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_Cons, 2, (V[]){v_x_2454, v_x_2458}), v_n_2459});
    }
    default: return heff_nomatch(v_x2_2457);
    }
  }
  default: return heff_nomatch(v_x2_2453);
  }
}
V g_prelude_2etraverse_24s130657301x1556233528_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s130657301x1556233528_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s130657301x1556233528_lam0, 1, 0};
V g_prelude_2etraverse_24s130657301x1556233528_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s130657301x1556233528_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s130657301x1556233528_entry, 1, 0};

V g_prelude_2etraverse_24s130657301x1556233528(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s130657301x1556233528_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_244 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s130657301x1556233528_lam1, 1, 2, (V[]){v_a_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s130657301x1556233528_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s130657301x1556233528(a[0]);
}
V g_prelude_2etraverse_24s130657301x1556233528_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s130657301x1556233528_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_246 = heff_tr(heff_call(v_a_244, 1, (V[]){v_n_245}));
  V v_x2_249;
  switch (heff_tag_of(v_a_246)) {
  case TAG_MkPair: {
    V v_a_247 = heff_field(v_a_246, 0);
    V v_a_248 = heff_field(v_a_246, 1);
    V v_ru_24a_246_24MkPair = heff_take_reuse_n(v_a_246, 3ULL, 2);
    v_x2_249 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24a_246_24MkPair, v_a_247, v_a_248));
    break;
  }
  default: heff_nomatch(v_a_246);
  }
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = (g_prelude_2etraverse_24s130657301x1556233528(v_xs_243));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_Cons, 2, (V[]){v_x_2410, v_x_2414}), v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
HEFF_LIT(g_prelude_2etraverse_24s1206798274x929612205_24cpr_str0, 1, "$");

HeffT2 g_prelude_2etraverse_24s1206798274x929612205_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x_244 = heff_strAppend(heff_strAppend(v_x_242, ((V)&g_prelude_2etraverse_24s1206798274x929612205_24cpr_str0)), heff_intShow(heff_dup(v_p_241)));
    HeffT2 v_t_245 = (g_prelude_2etraverse_24s1206798274x929612205_24cpr(v_xs_243, heff_intAdd(v_p_241, MK_INT(1LL))));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_x_248 = v_field_246;
      V v_n_249 = v_field_247;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_x_248}), v_n_249}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1442653311x1678194035_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1442653311x1678194035_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1442653311x1678194035_lam0, 1, 0};
V g_prelude_2etraverse_24s1442653311x1678194035_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1442653311x1678194035_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1442653311x1678194035_entry, 1, 0};

V g_prelude_2etraverse_24s1442653311x1678194035(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1442653311x1678194035_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2escalars_2eslotsOf(NTAG(TAG_OfRecords), heff_dup(v_x_242)));
    V v_m_245 = (g_heff_2ecompile_2escalars_2efoundWith(NTAG(TAG_OfRecords), heff_dup(v_x_242), heff_rec_n(2, shape_def__slots, (V[]){v_x_242, v_t_244})));
    return heff_clo_n(g_prelude_2etraverse_24s1442653311x1678194035_lam1, 1, 2, (V[]){v_m_245, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1442653311x1678194035_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1442653311x1678194035(a[0]);
}
V g_prelude_2etraverse_24s1442653311x1678194035_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1442653311x1678194035_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s1442653311x1678194035(v_xs_243));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}

HeffT2 g_prelude_2etraverse_24s24931311x762276985_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 3ULL, 2);
        HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_a_245));
        {
          V v_field_249 = v_t_247.f[1];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          if ((v_tag_248 == ((int64_t)0ULL))) {
            heff_drop(v_xs_242);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop_cell(v_ru_24x_241_24At, 2);
            heff_drop(v_a_246);
            V v_a_2410 = v_field_249;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_a_2410}});
          } else {
            V v_a_2411 = v_field_249;
            HeffT2 v_t_2412 = (g_prelude_2etraverse_24s24931311x762276985_24cpr(v_xs_242));
            {
              V v_field_2414 = v_t_2412.f[1];
              int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
              if ((v_tag_2413 == ((int64_t)0ULL))) {
                heff_drop_cell(v_ru_24x2_240_24Cons, 2);
                heff_drop_cell(v_ru_24x_241_24At, 2);
                heff_drop(v_a_246);
                heff_drop(v_a_2411);
                V v_err_2415 = v_field_2414;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2415}});
              } else {
                V v_x_2416 = v_field_2414;
                V v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_2411, NTAG(TAG_Nil)});
                V v_t_2418 = heff_tag_at_n(v_ru_24x_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_t_2417, v_a_246}), v_x_2416});
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2418}});
              }
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_243)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_prelude_2etraverse_24s1797919465x75214466_str0, 44, "expected a field setting of the form `x = v`");
V g_prelude_2etraverse_24s1797919465x75214466_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1797919465x75214466_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1797919465x75214466_lam0, 2, 0};
V g_prelude_2etraverse_24s1797919465x75214466_lam2(V self, V *args);
V g_prelude_2etraverse_24s1797919465x75214466_lam1(V self, V *args);
V g_prelude_2etraverse_24s1797919465x75214466_lam3(V self, V *args);
V g_prelude_2etraverse_24s1797919465x75214466_lam6(V self, V *args);
V g_prelude_2etraverse_24s1797919465x75214466_lam5(V self, V *args);
V g_prelude_2etraverse_24s1797919465x75214466_lam4(V self, V *args);
Clo g_prelude_2etraverse_24s1797919465x75214466_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1797919465x75214466_entry, 1, 0};

V g_prelude_2etraverse_24s1797919465x75214466(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1797919465x75214466_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_x2_245 = v_x_243;
    V v_a_2428;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_x22_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_SetField: {
        V v_x_248 = heff_field(v_x21_246, 0);
        V v_xsp_249 = heff_field(v_x21_246, 1);
        V v_e_2410 = heff_field(v_x21_246, 2);
        heff_take_n(v_x21_246, 7ULL, 3);
        heff_drop(v_x22_247);
        V v_m_2411 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_e_2410)));
        v_a_2428 = heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam1, 2, 4, (V[]){v_m_2411, v_e_2410, v_x_248, v_xsp_249});
        break;
      }
      case TAG_BadFieldSet: {
        heff_take_n(v_x21_246, 0ULL, 1);
        v_a_2428 = heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam3, 2, 1, (V[]){v_x22_247});
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    return heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam4, 2, 2, (V[]){v_a_2428, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1797919465x75214466_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1797919465x75214466(a[0]);
}
V g_prelude_2etraverse_24s1797919465x75214466_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1797919465x75214466_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_2410 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_xsp_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2418;
  switch (heff_tag_of(v_e_2410)) {
  case TAG_At: {
    V v_s_2417 = heff_field(v_e_2410, 1);
    heff_take_n(v_e_2410, 2ULL, 2);
    v_t_2418 = v_s_2417;
    break;
  }
  default: heff_nomatch(v_e_2410);
  }
  V f_ = v_k_2413;
  args[0] = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){v_x_248, v_x_2415, v_t_2418, v_xsp_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1797919465x75214466_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_m_2411 = heff_env(self)[0];
  V v_e_2410 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_xsp_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_2411}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_2414, v_hd_2412, heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam2, 1, 4, (V[]){v_e_2410, v_k_2413, v_x_248, v_xsp_249})));
}
V g_prelude_2etraverse_24s1797919465x75214466_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k2_2421 = args[1];
  V v_x22_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2422 = heff_take_field(v_hd_2420, 1);
  V v_malg_2423 = heff_get_n(v_hd_2420, 2, 3);
  V v_t_2424 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(202LL), NTAG(TAG_SError), ((V)&g_prelude_2etraverse_24s1797919465x75214466_str0), v_x22_247, NTAG(TAG_Nothing)});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_call(v_malg_2423, 1, (V[]){v_t_2426}));
  V f_ = v_bind_2422;
  args[0] = v_t_2427;
  args[1] = v_k2_2421;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s1797919465x75214466_lam6(V self, V *args) {
  V v_a_2433 = args[0];
  V v_a_2430 = heff_env(self)[0];
  V v_a_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2430;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2431, v_a_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1797919465x75214466_lam5(V self, V *args) {
  V v_a_2431 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_2429 = heff_env(self)[1];
  V v_a_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2432 = (g_prelude_2etraverse_24s1797919465x75214466(v_xs_244));
  V f_ = v_a_2432;
  heff_room[0] = v_a_2429;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam6, 1, 2, (V[]){v_a_2430, v_a_2431});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s1797919465x75214466_lam4(V self, V *args) {
  V v_a_2429 = args[0];
  V v_a_2430 = args[1];
  V v_a_2428 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2428;
  args[0] = heff_dup(v_a_2429);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam5, 1, 3, (V[]){v_xs_244, v_a_2429, v_a_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_prelude_2etraverse_24s2094958103x549422471_str0, 48, "expected a field declaration of the form `x : A`");
V g_prelude_2etraverse_24s2094958103x549422471_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s2094958103x549422471_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2094958103x549422471_lam0, 2, 0};
V g_prelude_2etraverse_24s2094958103x549422471_lam3(V self, V *args); static Clo g_prelude_2etraverse_24s2094958103x549422471_lam3_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2094958103x549422471_lam3, 2, 0};
V g_prelude_2etraverse_24s2094958103x549422471_lam5(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam4(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam6(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam2(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam1(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam7(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam10(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam9(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam8(V self, V *args);
Clo g_prelude_2etraverse_24s2094958103x549422471_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2094958103x549422471_entry, 1, 0};

V g_prelude_2etraverse_24s2094958103x549422471(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s2094958103x549422471_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_x2_245 = v_x_243;
    V v_a_2439;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_x22_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_DeclareField: {
        V v_x_248 = heff_field(v_x21_246, 0);
        V v_t_2410 = heff_field(v_x21_246, 2);
        V v_d_2411 = heff_field(v_x21_246, 3);
        heff_take_n(v_x21_246, 13ULL, 4);
        heff_drop(v_x22_247);
        V v_c_2412 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2410));
        v_a_2439 = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam1, 2, 3, (V[]){v_c_2412, v_d_2411, v_x_248});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x21_246, 0ULL, 1);
        v_a_2439 = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam7, 2, 1, (V[]){v_x22_247});
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    return heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam8, 2, 2, (V[]){v_a_2439, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s2094958103x549422471_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s2094958103x549422471(a[0]);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_c_2418 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426;
  switch (heff_tag_of(v_c_2418)) {
  case TAG_At: {
    V v_s_2425 = heff_field(v_c_2418, 1);
    heff_take_n(v_c_2418, 2ULL, 2);
    v_t_2426 = v_s_2425;
    break;
  }
  default: heff_nomatch(v_c_2418);
  }
  V v_t_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2423, v_t_2426})});
  V f_ = v_k_2421;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam4(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_m_2419 = heff_env(self)[0];
  V v_c_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_2419}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_2422, v_hd_2420, heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam5, 1, 2, (V[]){v_c_2418, v_k_2421})));
}
V g_prelude_2etraverse_24s2094958103x549422471_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2414;
  args[0] = heff_rec_n(3, shape_name__typ__dflt, (V[]){v_x_248, v_x_2415, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_d_2411 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2428;
  switch (heff_tag_of(v_d_2411)) {
  case TAG_Nothing: {
    v_c_2428 = ((V)&g_prelude_2etraverse_24s2094958103x549422471_lam3_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2418 = heff_field(v_d_2411, 0);
    heff_take_n(v_d_2411, 1ULL, 1);
    V v_m_2419 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2418)));
    v_c_2428 = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam4, 2, 2, (V[]){v_m_2419, v_c_2418});
    break;
  }
  default: heff_nomatch(v_d_2411);
  }
  V f_ = v_c_2428;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam6, 1, 3, (V[]){v_k_2414, v_x_248, v_x_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s2094958103x549422471_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_d_2411 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam2, 1, 4, (V[]){v_d_2411, v_hd_2413, v_k_2414, v_x_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam7(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k2_2432 = args[1];
  V v_x22_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2433 = heff_take_field(v_hd_2431, 1);
  V v_malg_2434 = heff_get_n(v_hd_2431, 2, 3);
  V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(201LL), NTAG(TAG_SError), ((V)&g_prelude_2etraverse_24s2094958103x549422471_str0), v_x22_247, NTAG(TAG_Nothing)});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(v_malg_2434, 1, (V[]){v_t_2437}));
  V f_ = v_bind_2433;
  args[0] = v_t_2438;
  args[1] = v_k2_2432;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam10(V self, V *args) {
  V v_a_2444 = args[0];
  V v_a_2441 = heff_env(self)[0];
  V v_a_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2441;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2442, v_a_2444});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam9(V self, V *args) {
  V v_a_2442 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_2440 = heff_env(self)[1];
  V v_a_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2443 = (g_prelude_2etraverse_24s2094958103x549422471(v_xs_244));
  V f_ = v_a_2443;
  heff_room[0] = v_a_2440;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam10, 1, 2, (V[]){v_a_2441, v_a_2442});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s2094958103x549422471_lam8(V self, V *args) {
  V v_a_2440 = args[0];
  V v_a_2441 = args[1];
  V v_a_2439 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2439;
  args[0] = heff_dup(v_a_2440);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam9, 1, 3, (V[]){v_xs_244, v_a_2440, v_a_2441});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_prelude_2e_2b_2b_24f1206589350x791019229_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1206589350x791019229_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1206589350x791019229(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_rec_n(2, shape_fixed__op, (V[]){heff_dup(v_lit_241), v_x_243});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(v_ys_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1206589350x791019229_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1206589350x791019229(a[0], a[1], a[2]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1057423371x1101358195_str0, 1, "_");
Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1057423371x1101358195_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1057423371x1101358195(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24At = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_prelude_2e_2b_2b_24f1057423371x1101358195_str0), 2)) {
        heff_drop_cell(v_ru_24x1_241_24At, 2);
        heff_drop(v_x_244);
        return v_ys_240;
      } else {
        V v_t_245 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_ys_240));
        return heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_244, v_t_245});
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_249); r_; });
      return (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_241_24At, v_t_2410, v_ys_240));
    }
    case TAG_PatOp: {
      V v_ps_2413 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2413));
      V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2414); r_; });
      return (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_241_24At, v_t_2415, v_ys_240));
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatFloat: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatRecord: {
      V v_fs_2421 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2421));
      V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2422); r_; });
      return (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_241_24At, v_t_2423, v_ys_240));
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatAs: {
      V v_x_2425 = heff_field(v_x11_242, 0);
      V v_q_2427 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 5ULL, 3);
      V v_cell_2428 = heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_2425, heff_hole()});
      V v_u_2429 = (g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps(v_ys_240, v_q_2427, heff_dup(v_cell_2428)));
      heff_drop(v_u_2429);
      return v_cell_2428;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f1057423371x1101358195_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1057423371x1101358195(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (!heff_strEq_c_lent(v_x_243, v_lit_241, 0)) {
      V v_x_245 = heff_tag_n(TAG_EVar, 1, (V[]){v_x_243});
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_247 = (g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps(v_ys_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(V v_ys_240, V v_x1_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    V v_t_244 = (g_prelude_2e_2b_2b(v_ys_242, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_244);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_241, 0);
    V v_xs_246 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_xs_246;
    V t_2 = v_ys_242;
    V t_3 = v_cell_247;
    v_ys_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f677743828x1026746250_entry, 3, 0};

V g_prelude_2e_2b_2b_24f677743828x1026746250(V v_ys_240, V v_i_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_x_243);
      HEFF_LAST return g_prelude_2e_2b_2b_24tok2(v_ru_24x2_242_24Cons, v_xs_244, v_ys_240);
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = (g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(v_ys_240, heff_intSub(v_i_241, MK_INT(1LL)), v_xs_244, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f677743828x1026746250(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f709746438x971999636_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f709746438x971999636_entry, 2, 0};

V g_prelude_2e_2b_2b_24f709746438x971999636(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_x12_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_247 = (g_prelude_2e_2b_2b_24f709746438x971999636_24dps(v_ys_240, v_x12_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f709746438x971999636_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f709746438x971999636(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f292729551x60683815_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f292729551x60683815_entry, 5, 0};

V g_prelude_2e_2b_2b_24f292729551x60683815(V v_ys_240, V v_box_24lit_241, V v_lit_242, V v_box_24lit_243, V v_x2_244) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    if (((v_lit_241 < heff_unbox_word(heff_strLength_lent(v_x_245, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_x_245, v_lit_242, 0)) == v_lit_243) : 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_248 = (g_prelude_2e_2b_2b_24f292729551x60683815_24dps(v_ys_240, heff_box_word(v_lit_241), v_lit_242, heff_box_word(v_lit_243), v_xs_246, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_244_24Cons, 2);
      V t_0 = v_ys_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_xs_246;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_prelude_2e_2b_2b_24f292729551x60683815_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_prelude_2e_2b_2b_24f292729551x60683815(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_prelude_2e_2b_2b_24f543054808x1503188303_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f543054808x1503188303_entry, 9, 0};

V g_prelude_2e_2b_2b_24f543054808x1503188303(V v_ys_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_x3_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_x3_248);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_249);
      heff_drop(v_xs_2410);
      heff_drop_cell(v_ru_24x2_247_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_y_2411 = heff_field(v_x3_248, 0);
      V v_ys_2412 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      V v_t_2413 = ({ V a_0 = v_x_249; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_249); r_; });
      V v_t_2414 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2413), heff_dup(v_lit_245));
      V v_t_2415 = heff_strAppend(v_t_2414, heff_intShow(v_y_2411));
      V v_x_2416 = heff_strAppend(v_t_2415, heff_dup(v_lit_246));
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_x_2416, heff_hole()});
      V v_u_2418 = (g_prelude_2e_2b_2b_24f543054808x1503188303_24dps(v_ys_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_2410, v_ys_2412, heff_dup(v_cell_2417)));
      heff_drop(v_u_2418);
      return v_cell_2417;
    }
    default: return heff_nomatch(v_x3_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2e_2b_2b_24f543054808x1503188303_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f543054808x1503188303(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1085359736x1262841716_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1085359736x1262841716(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_x_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = (g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1085359736x1262841716(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f427551988x255400191_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f427551988x255400191_entry, 2, 0};

V g_prelude_2e_2b_2b_24f427551988x255400191(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_get_n(v_x_242, 0, 14);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f427551988x255400191_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f427551988x255400191_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f427551988x255400191(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f427551988x255400191_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f427551988x255400191_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f427551988x255400191_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_get_n(v_x_243, 0, 14);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f427551988x255400191_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f427551988x255400191_24dps(a[0], a[1], a[2]);
}