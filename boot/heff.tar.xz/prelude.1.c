// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CDrop 58400
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkTF 48839
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define LBL_body 9524841
#define LBL_consumers 1203455020
#define LBL_field 298786068
#define LBL_fixed 298804110
#define LBL_fresh 299054408
#define LBL_key 315609
#define LBL_l 326
#define LBL_launch 837298910
#define LBL_left 9813198
#define LBL_limit 304334805
#define LBL_made 9839068
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_numbered 1006183371
#define LBL_op 10312
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_pats 9928951
#define LBL_place 308106529
#define LBL_producers 572620898
#define LBL_r 332
#define LBL_rhs 322423
#define LBL_span 10032145
#define LBL_supply 1056026650
#define LBL_top 324559
#define LBL_x 338
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
static uint32_t shape_owner__launch__place__top__path__limit[] = {LBL_owner, LBL_launch, LBL_place, LBL_top, LBL_path, LBL_limit};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_r__x[] = {LBL_r, LBL_x};
static uint32_t shape_supply__consumers__producers__made__fresh__left[] = {LBL_supply, LBL_consumers, LBL_producers, LBL_made, LBL_fresh, LBL_left};
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ecompile_2eemitc_2edefOwn(V, V);
V g_heff_2ecompile_2eemitc_2edefOwn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefOwn_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2estmtF(V, V);
V g_heff_2ecompile_2eemitc_2estmtF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estmtF_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2emonadic_2enorm(V);
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enorm_clo;
V g_heff_2ecompile_2esimplify_2ehandedField(V, V);
V g_heff_2ecompile_2esimplify_2ehandedField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedField_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eoneDef_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eoneItem_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2epushArm_24cpr(V, V, V, V);
V g_heff_2ecompile_2etrmc_2edefT(V);
V g_heff_2ecompile_2etrmc_2edefT_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2edefT_clo;
V g_heff_2ecompile_2eunbox_2ewithVars(V);
V g_heff_2ecompile_2eunbox_2ewithVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ewithVars_clo;
HeffT2 g_heff_2eelab_2eclauses_2epat_24cpr(V);
V g_heff_2eelab_2etoplevel_2eargBinding(V);
V g_heff_2eelab_2etoplevel_2eargBinding_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eargBinding_clo;
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo;
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(V);
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_clo;
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(V);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_clo;
HeffT2 g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(V);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2emap_24s146946949x1862800301(V);
V g_list_2emap_24s146946949x1862800301_entry(V self, V *a);
extern Clo g_list_2emap_24s146946949x1862800301_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24dps(V, V, V);
V g_prelude_2e_2b_2b_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24dps_clo;
V g_prelude_2e_2b_2b_24f1057423371x1101358195(V, V);
V g_prelude_2e_2b_2b_24f1057423371x1101358195_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_clo;
V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716(V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_clo;
V g_prelude_2e_2b_2b_24f1206589350x791019229(V, V, V);
V g_prelude_2e_2b_2b_24f1206589350x791019229_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1206589350x791019229_clo;
V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_clo;
V g_prelude_2e_2b_2b_24f144264237x1558451749(V, V, V);
V g_prelude_2e_2b_2b_24f144264237x1558451749_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f144264237x1558451749_clo;
V g_prelude_2e_2b_2b_24f144264237x1558451749_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f144264237x1558451749_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f144264237x1558451749_24dps_clo;
V g_prelude_2e_2b_2b_24f1537904782x516751275(V, V);
V g_prelude_2e_2b_2b_24f1537904782x516751275_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1537904782x516751275_clo;
V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_clo;
V g_prelude_2e_2b_2b_24f1572068627x1632985590(V, V);
V g_prelude_2e_2b_2b_24f1572068627x1632985590_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1572068627x1632985590_clo;
V g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps_clo;
V g_prelude_2e_2b_2b_24f1678011228x1831833404_24dps(V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1678011228x1831833404_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1678011228x1831833404_24dps_clo;
V g_prelude_2e_2b_2b_24f1727312714x1365290191(V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1727312714x1365290191_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1727312714x1365290191_clo;
V g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps(V, V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_clo;
V g_prelude_2e_2b_2b_24f427551988x255400191(V, V);
V g_prelude_2e_2b_2b_24f427551988x255400191_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f427551988x255400191_clo;
V g_prelude_2e_2b_2b_24f427551988x255400191_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f427551988x255400191_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f427551988x255400191_24dps_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250(V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_clo;
V g_prelude_2e_2b_2b_24f686409757x475266571(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f686409757x475266571_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f686409757x475266571_clo;
V g_prelude_2e_2b_2b_24f686409757x475266571_24dps(V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f686409757x475266571_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f686409757x475266571_24dps_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636(V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_24dps_clo;
V g_prelude_2e_2b_2b_24f738852651x284559611(V, V);
V g_prelude_2e_2b_2b_24f738852651x284559611_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f738852651x284559611_clo;
V g_prelude_2e_2b_2b_24f738852651x284559611_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f738852651x284559611_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f738852651x284559611_24dps_clo;
HeffT2 g_prelude_2edigitsFrom_24cpr(V, V, V);
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2etraverse_24s1048254938x1609755296(V, V, V, V);
V g_prelude_2etraverse_24s1048254938x1609755296_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1048254938x1609755296_clo;
HeffT2 g_prelude_2etraverse_24s1182736556x1844399207_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1252393826x821382319_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1267794550x535874087_24cpr(V, V, V, V, V, V, V, V, V);
V g_prelude_2etraverse_24s1370495575x1780346529(V, V);
V g_prelude_2etraverse_24s1370495575x1780346529_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1370495575x1780346529_clo;
V g_prelude_2etraverse_24s1488190221x1768542206(V);
V g_prelude_2etraverse_24s1488190221x1768542206_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1488190221x1768542206_clo;
V g_prelude_2etraverse_24s1489978019x401411722(V);
V g_prelude_2etraverse_24s1489978019x401411722_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1489978019x401411722_clo;
HeffT2 g_prelude_2etraverse_24s1512790070x1159539918_24cpr(V, V);
V g_prelude_2etraverse_24s1566634931x762466996(V);
V g_prelude_2etraverse_24s1566634931x762466996_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1566634931x762466996_clo;
V g_prelude_2etraverse_24s1726903169x1952011622(V);
V g_prelude_2etraverse_24s1726903169x1952011622_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1726903169x1952011622_clo;
V g_prelude_2etraverse_24s1790182665x771782021(V);
V g_prelude_2etraverse_24s1790182665x771782021_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1790182665x771782021_clo;
V g_prelude_2etraverse_24s1797919465x75214466(V);
V g_prelude_2etraverse_24s1797919465x75214466_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1797919465x75214466_clo;
HeffT2 g_prelude_2etraverse_24s1915868469x1980534124_24cpr(V, V);
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_prelude_2etraverse_24s2094958103x549422471(V);
V g_prelude_2etraverse_24s2094958103x549422471_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2094958103x549422471_clo;
HeffT2 g_prelude_2etraverse_24s24931311x762276985_24cpr(V);
V g_prelude_2etraverse_24s286231231x60067418(V, V);
V g_prelude_2etraverse_24s286231231x60067418_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s286231231x60067418_clo;
V g_prelude_2etraverse_24s350379375x322835164(V);
V g_prelude_2etraverse_24s350379375x322835164_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s350379375x322835164_clo;
HeffT2 g_prelude_2etraverse_24s366524614x1308602553_24cpr(V);
V g_prelude_2etraverse_24s390133767x1613463851(V);
V g_prelude_2etraverse_24s390133767x1613463851_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s390133767x1613463851_clo;
V g_prelude_2etraverse_24s428640578x580976168(V, V);
V g_prelude_2etraverse_24s428640578x580976168_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s428640578x580976168_clo;
HeffT2 g_prelude_2etraverse_24s504671899x323346652_24cpr(V, V, V, V);
V g_prelude_2etraverse_24s545943161x1483966866(V, V);
V g_prelude_2etraverse_24s545943161x1483966866_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s545943161x1483966866_clo;
HeffT2 g_prelude_2etraverse_24s577758486x2142661336_24cpr(V, V);
V g_prelude_2etraverse_24s672366786x467588702(V, V);
V g_prelude_2etraverse_24s672366786x467588702_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s672366786x467588702_clo;
V g_prelude_2etraverse_24s740446701x774604387(V, V);
V g_prelude_2etraverse_24s740446701x774604387_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s740446701x774604387_clo;
HeffT2 g_prelude_2etraverse_24s801310267x475583082_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s890471069x803991723_24cpr(V);
V g_prelude_2etraverse_24s956608878x365908798(V);
V g_prelude_2etraverse_24s956608878x365908798_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s956608878x365908798_clo;
V g_std_2emap_2eempty_get(void);
Clo g_prelude_2e_2b_2b_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_entry, 2, 0};

V g_prelude_2e_2b_2b(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_prelude_2e_2b_2b_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2e_2b_2b_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b(a[0], a[1]);
}
Clo g_prelude_2eskipSpaces_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eskipSpaces_entry, 3, 0};

V g_prelude_2eskipSpaces(V v_s_240, V v_box_24i_241, V v_box_24step_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  int64_t v_step_242 = heff_unbox_word(v_box_24step_242);
top: ;
  if ((((int64_t)0ULL) <= v_i_241)) {
    if ((v_i_241 < heff_unbox_word(heff_strLength_lent(v_s_240, 0)))) {
      V v_c_245 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2);
      if ((heff_peek_word(v_c_245) == ((int64_t)32ULL))) {
        heff_drop(v_c_245);
        V t_0 = v_s_240;
        int64_t t_1 = (v_i_241 + v_step_242);
        int64_t t_2 = v_step_242;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_step_242 = t_2;
        goto top;
      } else {
        if ((heff_peek_word(v_c_245) == ((int64_t)9ULL))) {
          heff_drop(v_c_245);
          V t_0 = v_s_240;
          int64_t t_1 = (v_i_241 + v_step_242);
          int64_t t_2 = v_step_242;
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_step_242 = t_2;
          goto top;
        } else {
          if ((heff_peek_word(v_c_245) == ((int64_t)10ULL))) {
            heff_drop(v_c_245);
            V t_0 = v_s_240;
            int64_t t_1 = (v_i_241 + v_step_242);
            int64_t t_2 = v_step_242;
            v_s_240 = t_0;
            v_i_241 = t_1;
            v_step_242 = t_2;
            goto top;
          } else {
            if ((heff_unbox_word(v_c_245) == ((int64_t)13ULL))) {
              V t_0 = v_s_240;
              int64_t t_1 = (v_i_241 + v_step_242);
              int64_t t_2 = v_step_242;
              v_s_240 = t_0;
              v_i_241 = t_1;
              v_step_242 = t_2;
              goto top;
            } else {
              return heff_box_word(v_i_241);
            }
          }
        }
      }
    } else {
      return heff_box_word(v_i_241);
    }
  } else {
    return heff_box_word(v_i_241);
  }
}
V g_prelude_2eskipSpaces_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_prelude_2eskipSpaces(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_prelude_2edigitsFrom_24cpr(V v_s_240, V v_i_241, V v_n_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_n_242}});
  } else {
    if ((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) <= ((int64_t)57ULL))) {
        int64_t v_t_246 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) - ((int64_t)48ULL));
        V v_t_247 = heff_intAdd(heff_intMul(v_n_242, MK_INT(10LL)), heff_box_word(v_t_246));
        V t_0 = v_s_240;
        V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
        V t_2 = v_t_247;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_n_242 = t_2;
        goto top;
      } else {
        heff_drop(v_i_241);
        heff_drop(v_n_242);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_i_241);
      heff_drop(v_n_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
Clo g_prelude_2eparseInt_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eparseInt_entry, 1, 0};

V g_prelude_2eparseInt(V v_s_240) {
top: ;
  HeffT2 v_t_241 = (g_prelude_2eparseInt_24cpr(v_s_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_prelude_2eparseInt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_prelude_2eparseInt(a0); heff_drop(a0); return r;
}
V g_prelude_2etraverse_24s1726903169x1952011622_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1726903169x1952011622_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1726903169x1952011622_lam0, 1, 0};
V g_prelude_2etraverse_24s1726903169x1952011622_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1726903169x1952011622_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1726903169x1952011622_entry, 1, 0};

V g_prelude_2etraverse_24s1726903169x1952011622(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1726903169x1952011622_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_245 = (g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(v_x_243));
    return heff_clo_n(g_prelude_2etraverse_24s1726903169x1952011622_lam1, 1, 2, (V[]){v_m_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1726903169x1952011622_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1726903169x1952011622(a[0]);
}
V g_prelude_2etraverse_24s1726903169x1952011622_lam0(V self, V *args) {
  V v_st_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_st_241});
}
V g_prelude_2etraverse_24s1726903169x1952011622_lam1(V self, V *args) {
  V v_st_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_246}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_xs_244);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_m_2412 = (g_prelude_2etraverse_24s1726903169x1952011622(v_xs_244));
      V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_st_249}));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkPair: {
        V v_x11_2414 = heff_field(v_x1_2413, 0);
        V v_st_2415 = heff_field(v_x1_2413, 1);
        heff_take_n(v_x1_2413, 3ULL, 2);
        switch (heff_tag_of(v_x11_2414)) {
        case TAG_Left: {
          V v_e_2416 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          heff_drop(v_x_2411);
          heff_drop_cell(v_ru_24x11_248_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
        }
        case TAG_Right: {
          V v_x_2417 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2417})});
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){v_t_2418, v_st_2415});
        }
        default: return heff_nomatch(v_x11_2414);
        }
      }
      default: return heff_nomatch(v_x1_2413);
      }
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_prelude_2etraverse_24s956608878x365908798_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s956608878x365908798_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s956608878x365908798_lam0, 1, 0};
V g_prelude_2etraverse_24s956608878x365908798_lam1(V self, V *args);
V g_prelude_2etraverse_24s956608878x365908798_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s956608878x365908798_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s956608878x365908798_entry, 1, 0};

V g_prelude_2etraverse_24s956608878x365908798(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s956608878x365908798_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2417;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_248 = heff_field(v_x_243, 3);
      V v_a_249 = heff_field(v_x_243, 4);
      heff_take_n(v_x_243, 25ULL, 5);
      V v_t_2410 = (g_list_2emap_24s146946949x1862800301(heff_dup(v_a_245)));
      HeffT2 v_t_2411 = (g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(NTAG(TAG_Nil), v_t_2410));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          heff_drop(v_a_245);
          heff_drop(v_a_248);
          heff_drop(v_a_249);
          V v_a_2415 = v_field_2413;
          v_m_2417 = heff_clo_n(g_prelude_2etraverse_24s956608878x365908798_lam1, 1, 1, (V[]){v_a_2415});
        } else {
          heff_drop(v_field_2413);
          v_m_2417 = heff_tr(heff_call(((V)&g_prelude_2etraverse_24s1048254938x1609755296_clo), 3, (V[]){v_a_248, v_a_249, v_a_245}));
        }
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_clo_n(g_prelude_2etraverse_24s956608878x365908798_lam2, 1, 2, (V[]){v_m_2417, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s956608878x365908798_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s956608878x365908798(a[0]);
}
V g_prelude_2etraverse_24s956608878x365908798_lam0(V self, V *args) {
  V v_st_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_st_241});
}
V g_prelude_2etraverse_24s956608878x365908798_lam1(V self, V *args) {
  V v_a_2416 = args[0];
  V v_a_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_a_2415}), v_a_2416});
}
V g_prelude_2etraverse_24s956608878x365908798_lam2(V self, V *args) {
  V v_st_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2418}));
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkPair: {
    V v_x11_2420 = heff_field(v_x1_2419, 0);
    V v_st_2421 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x11_2420, 0);
      heff_take_n(v_x11_2420, 1ULL, 1);
      heff_drop(v_xs_244);
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Right = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      V v_m_2424 = (g_prelude_2etraverse_24s956608878x365908798(v_xs_244));
      V v_x1_2425 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_st_2421}));
      switch (heff_tag_of(v_x1_2425)) {
      case TAG_MkPair: {
        V v_x11_2426 = heff_field(v_x1_2425, 0);
        V v_st_2427 = heff_field(v_x1_2425, 1);
        heff_take_n(v_x1_2425, 3ULL, 2);
        switch (heff_tag_of(v_x11_2426)) {
        case TAG_Left: {
          V v_e_2428 = heff_field(v_x11_2426, 0);
          heff_take_n(v_x11_2426, 1ULL, 1);
          heff_drop(v_x_2423);
          heff_drop_cell(v_ru_24x11_2420_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2428}), v_st_2427});
        }
        case TAG_Right: {
          V v_x_2429 = heff_field(v_x11_2426, 0);
          heff_take_n(v_x11_2426, 1ULL, 1);
          V v_t_2430 = heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2423, v_x_2429})});
          return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_st_2427});
        }
        default: return heff_nomatch(v_x11_2426);
        }
      }
      default: return heff_nomatch(v_x1_2425);
      }
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_prelude_2etraverse_24s672366786x467588702_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s672366786x467588702_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s672366786x467588702_lam0, 1, 0};
V g_prelude_2etraverse_24s672366786x467588702_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s672366786x467588702_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s672366786x467588702_entry, 2, 0};

V g_prelude_2etraverse_24s672366786x467588702(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((V)&g_prelude_2etraverse_24s672366786x467588702_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = (g_heff_2ecompile_2esimplify_2ehandedField(heff_dup(v_lit_240), v_x_243));
    return heff_clo_n(g_prelude_2etraverse_24s672366786x467588702_lam1, 1, 3, (V[]){v_m_245, v_lit_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s672366786x467588702_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s672366786x467588702(a[0], a[1]);
}
V g_prelude_2etraverse_24s672366786x467588702_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s672366786x467588702_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s672366786x467588702(v_lit_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}

HeffT2 g_prelude_2etraverse_24s504671899x323346652_24cpr(V v_lit_240, V v_lit_241, V v_x2_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return ((HeffT2){{NTAG(TAG_Nil), v_p_243}});
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    HeffT2 v_t_246 = (g_heff_2ecompile_2esimplify_2epushArm_24cpr(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_244, v_p_243));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      V v_x_249 = v_field_247;
      V v_s_2410 = v_field_248;
      HeffT2 v_t_2411 = (g_prelude_2etraverse_24s504671899x323346652_24cpr(v_lit_240, v_lit_241, v_xs_245, v_s_2410));
      {
        V v_field_2412 = v_t_2411.f[0];
        V v_field_2413 = v_t_2411.f[1];
        V v_x_2414 = v_field_2412;
        V v_s_2415 = v_field_2413;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_249, v_x_2414}), v_s_2415}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_242)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1252393826x821382319_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eoneDef_24cpr(v_x_242, v_p_241));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_s_248 = v_field_246;
      HeffT2 v_t_249 = (g_prelude_2etraverse_24s1252393826x821382319_24cpr(v_xs_243, v_s_248));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        V v_s_2413 = v_field_2411;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_x_2412}), v_s_2413}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1182736556x1844399207_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eoneItem_24cpr(v_x_242, v_p_241));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_s_248 = v_field_246;
      HeffT2 v_t_249 = (g_prelude_2etraverse_24s1182736556x1844399207_24cpr(v_xs_243, v_s_248));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        V v_s_2413 = v_field_2411;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_x_2412}), v_s_2413}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1267794550x535874087_24cpr(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_p_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 7);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return ((HeffT2){{NTAG(TAG_Nil), v_p_248}});
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    HeffT2 v_t_2411 = (g_prelude_2etraverse_24s1267794550x535874087_24cpr(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), heff_dup(v_lit_245), heff_dup(v_lit_246), v_xs_2410, heff_intAdd(heff_dup(v_p_248), v_lit_246)));
    {
      V v_field_2412 = v_t_2411.f[0];
      V v_field_2413 = v_t_2411.f[1];
      V v_x_2414 = v_field_2412;
      V v_n_2415 = v_field_2413;
      V v_t_2416 = heff_get_n(v_lit_240, 1, 7);
      V v_t_2418;
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_lit_244);
        heff_drop(v_t_2416);
        if (heff_intEq_c(v_x_249, v_lit_241)) {
          heff_drop(v_lit_243);
          v_t_2418 = v_lit_242;
        } else {
          heff_drop(v_lit_242);
          v_t_2418 = v_lit_243;
        }
      } else {
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        heff_drop(v_lit_243);
        heff_drop(v_x_249);
        heff_drop(v_t_2416);
        v_t_2418 = v_lit_244;
      }
      V v_t_2419 = heff_strAppend(v_lit_245, heff_intShow(v_p_248));
      V v_f_2420 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2418, v_t_2419), v_x_2414});
      return ((HeffT2){{v_f_2420, v_n_2415}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_247)}});
  }
}
V g_prelude_2etraverse_24s740446701x774604387_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s740446701x774604387_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s740446701x774604387_lam0, 1, 0};
V g_prelude_2etraverse_24s740446701x774604387_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s740446701x774604387_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s740446701x774604387_entry, 2, 0};

V g_prelude_2etraverse_24s740446701x774604387(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s740446701x774604387_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s740446701x774604387_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s740446701x774604387_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s740446701x774604387(a[0], a[1]);
}
V g_prelude_2etraverse_24s740446701x774604387_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_prelude_2etraverse_24s740446701x774604387_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s740446701x774604387(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2etraverse_24s286231231x60067418_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s286231231x60067418_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s286231231x60067418_lam0, 1, 0};
V g_prelude_2etraverse_24s286231231x60067418_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s286231231x60067418_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s286231231x60067418_entry, 2, 0};

V g_prelude_2etraverse_24s286231231x60067418(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s286231231x60067418_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s286231231x60067418_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s286231231x60067418_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s286231231x60067418(a[0], a[1]);
}
V g_prelude_2etraverse_24s286231231x60067418_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_prelude_2etraverse_24s286231231x60067418_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s286231231x60067418(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
HEFF_LIT(g_prelude_2etraverse_24s1915868469x1980534124_24cpr_str0, 1, "$");

HeffT2 g_prelude_2etraverse_24s1915868469x1980534124_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_prelude_2etraverse_24s1915868469x1980534124_24cpr(v_xs_243, heff_intAdd(heff_dup(v_p_241), MK_INT(1LL))));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_n_248 = v_field_246;
      V v_t_249 = heff_strAppend(((V)&g_prelude_2etraverse_24s1915868469x1980534124_24cpr_str0), heff_intShow(v_p_241));
      V v_t_2410 = heff_strAppend(heff_dup(heff_rfield(v_x_242, 1)), v_t_249);
      V v_f_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_r__x, (V[]){v_x_242, v_t_2410}), v_x_247});
      return ((HeffT2){{v_f_2411, v_n_248}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1934076392x614790049_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1934076392x614790049_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1934076392x614790049_lam0, 2, 0};
V g_prelude_2etraverse_24s1934076392x614790049_lam3(V self, V *args);
V g_prelude_2etraverse_24s1934076392x614790049_lam2(V self, V *args);
V g_prelude_2etraverse_24s1934076392x614790049_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1934076392x614790049_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1934076392x614790049_entry, 2, 0};

V g_prelude_2etraverse_24s1934076392x614790049(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s1934076392x614790049_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_a_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_prelude_2etraverse_24s1934076392x614790049_lam1, 2, 3, (V[]){v_a_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1934076392x614790049(a[0], a[1]);
}
V g_prelude_2etraverse_24s1934076392x614790049_lam0(V self, V *args) {
  V v_a_242 = args[0];
  V v_a_243 = args[1];
  heff_drop(v_a_242);
  V f_ = v_a_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1934076392x614790049_lam3(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_248 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_249, v_a_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1934076392x614790049_lam2(V self, V *args) {
  V v_a_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  V v_a_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_a_2410 = (g_prelude_2etraverse_24s1934076392x614790049(v_f_240, v_xs_245));
  V f_ = v_a_2410;
  heff_room[0] = v_a_247;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s1934076392x614790049_lam3, 1, 2, (V[]){v_a_248, v_a_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s1934076392x614790049_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_a_248 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_246;
  args[0] = heff_dup(v_a_247);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s1934076392x614790049_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_a_247, v_a_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s545943161x1483966866_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s545943161x1483966866_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s545943161x1483966866_lam0, 1, 0};
V g_prelude_2etraverse_24s545943161x1483966866_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s545943161x1483966866_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s545943161x1483966866_entry, 2, 0};

V g_prelude_2etraverse_24s545943161x1483966866(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s545943161x1483966866_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s545943161x1483966866_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s545943161x1483966866_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s545943161x1483966866(a[0], a[1]);
}
V g_prelude_2etraverse_24s545943161x1483966866_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s545943161x1483966866_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s545943161x1483966866(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}

HeffT2 g_prelude_2etraverse_24s801310267x475583082_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2emap_2eempty_get()), heff_take_field(v_p_241, 0), v_x_242));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_e_247 = v_field_245;
      V v_n_248 = v_field_246;
      V v_t_249 = ({ V rv_0 = v_n_248; V rr_ = heff_rec_reuse_nf(v_p_241, 62ULL, 6, shape_supply__consumers__producers__made__fresh__left, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      HeffT2 v_t_2410 = (g_prelude_2etraverse_24s801310267x475583082_24cpr(v_xs_243, v_t_249));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        V v_s_2414 = v_field_2412;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_e_247, v_x_2413}), v_s_2414}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1566634931x762466996_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1566634931x762466996_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1566634931x762466996_lam0, 1, 0};
V g_prelude_2etraverse_24s1566634931x762466996_lam1(V self, V *args);
V g_prelude_2etraverse_24s1566634931x762466996_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s1566634931x762466996_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1566634931x762466996_entry, 1, 0};

V g_prelude_2etraverse_24s1566634931x762466996(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1566634931x762466996_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      V v_a_247 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_a_246));
      v_m_2412 = heff_clo_n(g_prelude_2etraverse_24s1566634931x762466996_lam1, 1, 3, (V[]){v_a_247, v_a_244, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_prelude_2etraverse_24s1566634931x762466996_lam2, 1, 2, (V[]){v_m_2412, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1566634931x762466996_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1566634931x762466996(a[0]);
}
V g_prelude_2etraverse_24s1566634931x762466996_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1566634931x762466996_lam1(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_a_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = heff_tr(heff_call(v_a_247, 1, (V[]){v_a_248}));
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkPair: {
    V v_a_2410 = heff_field(v_a_249, 0);
    V v_a_2411 = heff_field(v_a_249, 1);
    V v_ru_24a_249_24MkPair = heff_take_reuse_n(v_a_249, 3ULL, 2);
    return heff_tag_at_n(v_ru_24a_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_244, v_a_245, v_a_2410}), v_a_2411});
  }
  default: return heff_nomatch(v_a_249);
  }
}
V g_prelude_2etraverse_24s1566634931x762466996_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_m_2417 = (g_prelude_2etraverse_24s1566634931x762466996(v_xs_243));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2416}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_n_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_x_2419}), v_n_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_prelude_2etraverse_24s1489978019x401411722_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1489978019x401411722_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1489978019x401411722_lam0, 1, 0};
V g_prelude_2etraverse_24s1489978019x401411722_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1489978019x401411722_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1489978019x401411722_entry, 1, 0};

V g_prelude_2etraverse_24s1489978019x401411722(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1489978019x401411722_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(heff_dup(heff_rfield(v_x_242, 2))));
    return heff_clo_n(g_prelude_2etraverse_24s1489978019x401411722_lam1, 1, 3, (V[]){v_m_244, v_xs_243, v_x_242});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1489978019x401411722_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1489978019x401411722(a[0]);
}
V g_prelude_2etraverse_24s1489978019x401411722_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1489978019x401411722_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_prelude_2etraverse_24s1489978019x401411722(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      V v_t_2413 = ({ V rv_2 = v_x_247; V rr_ = heff_rec_reuse_nf(v_x_242, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_prelude_2etraverse_24s577758486x2142661336_24cpr_str0, 1, "$");

HeffT2 g_prelude_2etraverse_24s577758486x2142661336_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_prelude_2etraverse_24s577758486x2142661336_24cpr(v_xs_243, heff_intAdd(heff_dup(v_p_241), MK_INT(1LL))));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_n_248 = v_field_246;
      V v_t_249 = heff_strAppend(((V)&g_prelude_2etraverse_24s577758486x2142661336_24cpr_str0), heff_intShow(v_p_241));
      V v_f_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_242, v_t_249), v_x_247});
      return ((HeffT2){{v_f_2410, v_n_248}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1790182665x771782021_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1790182665x771782021_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1790182665x771782021_lam0, 1, 0};
V g_prelude_2etraverse_24s1790182665x771782021_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1790182665x771782021_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1790182665x771782021_entry, 1, 0};

V g_prelude_2etraverse_24s1790182665x771782021(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1790182665x771782021_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2etrmc_2edefT(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s1790182665x771782021_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1790182665x771782021_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1790182665x771782021(a[0]);
}
V g_prelude_2etraverse_24s1790182665x771782021_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1790182665x771782021_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_prelude_2etraverse_24s1790182665x771782021(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_prelude_2etraverse_24s1512790070x1159539918_24cpr_str0, 1, "$");

HeffT2 g_prelude_2etraverse_24s1512790070x1159539918_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_prelude_2etraverse_24s1512790070x1159539918_24cpr(v_xs_243, heff_intAdd(heff_dup(v_p_241), MK_INT(1LL))));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_n_248 = v_field_246;
      V v_t_249 = heff_strAppend(((V)&g_prelude_2etraverse_24s1512790070x1159539918_24cpr_str0), heff_intShow(v_p_241));
      V v_f_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_242, v_t_249), v_x_247});
      return ((HeffT2){{v_f_2410, v_n_248}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s350379375x322835164_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s350379375x322835164_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s350379375x322835164_lam0, 1, 0};
V g_prelude_2etraverse_24s350379375x322835164_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s350379375x322835164_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s350379375x322835164_entry, 1, 0};

V g_prelude_2etraverse_24s350379375x322835164(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s350379375x322835164_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2eunbox_2ewithVars(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s350379375x322835164_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s350379375x322835164_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s350379375x322835164(a[0]);
}
V g_prelude_2etraverse_24s350379375x322835164_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s350379375x322835164_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_prelude_2etraverse_24s350379375x322835164(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2etraverse_24s428640578x580976168_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s428640578x580976168_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s428640578x580976168_lam0, 1, 0};
V g_prelude_2etraverse_24s428640578x580976168_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s428640578x580976168_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s428640578x580976168_entry, 2, 0};

V g_prelude_2etraverse_24s428640578x580976168(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((V)&g_prelude_2etraverse_24s428640578x580976168_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = (g_heff_2ecompile_2eemitc_2estmtF(heff_dup(v_lit_240), v_x_243));
    return heff_clo_n(g_prelude_2etraverse_24s428640578x580976168_lam1, 1, 3, (V[]){v_m_245, v_lit_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s428640578x580976168_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s428640578x580976168(a[0], a[1]);
}
V g_prelude_2etraverse_24s428640578x580976168_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s428640578x580976168_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s428640578x580976168(v_lit_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2etraverse_24s1370495575x1780346529_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1370495575x1780346529_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1370495575x1780346529_lam0, 1, 0};
V g_prelude_2etraverse_24s1370495575x1780346529_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1370495575x1780346529_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1370495575x1780346529_entry, 2, 0};

V g_prelude_2etraverse_24s1370495575x1780346529(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((V)&g_prelude_2etraverse_24s1370495575x1780346529_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = (g_heff_2ecompile_2eemitc_2edefOwn(heff_dup(v_lit_240), v_x_243));
    return heff_clo_n(g_prelude_2etraverse_24s1370495575x1780346529_lam1, 1, 3, (V[]){v_m_245, v_lit_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1370495575x1780346529_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1370495575x1780346529(a[0], a[1]);
}
V g_prelude_2etraverse_24s1370495575x1780346529_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s1370495575x1780346529_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s1370495575x1780346529(v_lit_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}

HeffT2 g_prelude_2etraverse_24s890471069x803991723_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_x_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_xs_242);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        V v_err_247 = v_field_245;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_247}});
      } else {
        V v_x_248 = v_field_245;
        HeffT2 v_t_249 = (g_prelude_2etraverse_24s890471069x803991723_24cpr(v_xs_242));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_x_248);
            V v_err_2413 = v_field_2411;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2413}});
          } else {
            V v_x_2414 = v_field_2411;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_248, v_x_2414})}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s366524614x1308602553_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_x_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_xs_242);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        V v_err_247 = v_field_245;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_247}});
      } else {
        V v_x_248 = v_field_245;
        HeffT2 v_t_249 = (g_prelude_2etraverse_24s366524614x1308602553_24cpr(v_xs_242));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_x_248);
            V v_err_2413 = v_field_2411;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2413}});
          } else {
            V v_x_2414 = v_field_2411;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_248, v_x_2414})}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s24931311x762276985_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 3ULL, 2);
        HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_a_245));
        {
          V v_field_249 = v_t_247.f[1];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          if ((v_tag_248 == ((int64_t)0ULL))) {
            heff_drop(v_xs_242);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop_cell(v_ru_24x_241_24At, 2);
            heff_drop(v_a_246);
            V v_a_2411 = v_field_249;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_a_2411}});
          } else {
            V v_a_2412 = v_field_249;
            HeffT2 v_t_2413 = (g_prelude_2etraverse_24s24931311x762276985_24cpr(v_xs_242));
            {
              V v_field_2415 = v_t_2413.f[1];
              int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
              if ((v_tag_2414 == ((int64_t)0ULL))) {
                heff_drop_cell(v_ru_24x2_240_24Cons, 2);
                heff_drop_cell(v_ru_24x_241_24At, 2);
                heff_drop(v_a_246);
                heff_drop(v_a_2412);
                V v_err_2417 = v_field_2415;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2417}});
              } else {
                V v_x_2418 = v_field_2415;
                V v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_2412, NTAG(TAG_Nil)});
                V v_t_2420 = heff_tag_at_n(v_ru_24x_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_t_2419, v_a_246}), v_x_2418});
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2420}});
              }
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_243)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1797919465x75214466_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1797919465x75214466_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1797919465x75214466_lam0, 2, 0};
V g_prelude_2etraverse_24s1797919465x75214466_lam3(V self, V *args);
V g_prelude_2etraverse_24s1797919465x75214466_lam2(V self, V *args);
V g_prelude_2etraverse_24s1797919465x75214466_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1797919465x75214466_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1797919465x75214466_entry, 1, 0};

V g_prelude_2etraverse_24s1797919465x75214466(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1797919465x75214466_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam1, 2, 2, (V[]){v_a_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1797919465x75214466_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1797919465x75214466(a[0]);
}
V g_prelude_2etraverse_24s1797919465x75214466_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1797919465x75214466_lam3(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_248, v_a_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1797919465x75214466_lam2(V self, V *args) {
  V v_a_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = (g_prelude_2etraverse_24s1797919465x75214466(v_xs_244));
  V f_ = v_a_249;
  heff_room[0] = v_a_246;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam3, 1, 2, (V[]){v_a_247, v_a_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s1797919465x75214466_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_245;
  args[0] = heff_dup(v_a_246);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s1797919465x75214466_lam2, 1, 3, (V[]){v_xs_244, v_a_246, v_a_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s2094958103x549422471_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2094958103x549422471_lam0, 2, 0};
V g_prelude_2etraverse_24s2094958103x549422471_lam3(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam2(V self, V *args);
V g_prelude_2etraverse_24s2094958103x549422471_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s2094958103x549422471_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2094958103x549422471_entry, 1, 0};

V g_prelude_2etraverse_24s2094958103x549422471(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s2094958103x549422471_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam1, 2, 2, (V[]){v_a_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s2094958103x549422471_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s2094958103x549422471(a[0]);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam3(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_248, v_a_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s2094958103x549422471_lam2(V self, V *args) {
  V v_a_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = (g_prelude_2etraverse_24s2094958103x549422471(v_xs_244));
  V f_ = v_a_249;
  heff_room[0] = v_a_246;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam3, 1, 2, (V[]){v_a_247, v_a_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s2094958103x549422471_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_245;
  args[0] = heff_dup(v_a_246);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s2094958103x549422471_lam2, 1, 3, (V[]){v_xs_244, v_a_246, v_a_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s390133767x1613463851_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s390133767x1613463851_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s390133767x1613463851_lam0, 2, 0};
V g_prelude_2etraverse_24s390133767x1613463851_lam3(V self, V *args);
V g_prelude_2etraverse_24s390133767x1613463851_lam2(V self, V *args);
V g_prelude_2etraverse_24s390133767x1613463851_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s390133767x1613463851_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s390133767x1613463851_entry, 1, 0};

V g_prelude_2etraverse_24s390133767x1613463851(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s390133767x1613463851_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = (g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(v_x_243));
    return heff_clo_n(g_prelude_2etraverse_24s390133767x1613463851_lam1, 2, 2, (V[]){v_a_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s390133767x1613463851_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s390133767x1613463851(a[0]);
}
V g_prelude_2etraverse_24s390133767x1613463851_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s390133767x1613463851_lam3(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_248, v_a_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s390133767x1613463851_lam2(V self, V *args) {
  V v_a_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = (g_prelude_2etraverse_24s390133767x1613463851(v_xs_244));
  V f_ = v_a_249;
  heff_room[0] = v_a_246;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s390133767x1613463851_lam3, 1, 2, (V[]){v_a_247, v_a_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s390133767x1613463851_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_245;
  args[0] = heff_dup(v_a_246);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s390133767x1613463851_lam2, 1, 3, (V[]){v_xs_244, v_a_246, v_a_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s1488190221x1768542206_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1488190221x1768542206_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1488190221x1768542206_lam0, 2, 0};
V g_prelude_2etraverse_24s1488190221x1768542206_lam3(V self, V *args);
V g_prelude_2etraverse_24s1488190221x1768542206_lam2(V self, V *args);
V g_prelude_2etraverse_24s1488190221x1768542206_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1488190221x1768542206_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1488190221x1768542206_entry, 1, 0};

V g_prelude_2etraverse_24s1488190221x1768542206(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1488190221x1768542206_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2eargBinding(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_prelude_2etraverse_24s1488190221x1768542206_lam1, 2, 2, (V[]){v_a_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1488190221x1768542206_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1488190221x1768542206(a[0]);
}
V g_prelude_2etraverse_24s1488190221x1768542206_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1488190221x1768542206_lam3(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_248, v_a_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1488190221x1768542206_lam2(V self, V *args) {
  V v_a_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = (g_prelude_2etraverse_24s1488190221x1768542206(v_xs_244));
  V f_ = v_a_249;
  heff_room[0] = v_a_246;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s1488190221x1768542206_lam3, 1, 2, (V[]){v_a_247, v_a_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s1488190221x1768542206_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_245;
  args[0] = heff_dup(v_a_246);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s1488190221x1768542206_lam2, 1, 3, (V[]){v_xs_244, v_a_246, v_a_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_prelude_2e_2b_2b_24f1206589350x791019229_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1206589350x791019229_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1206589350x791019229(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_rec_n(2, shape_fixed__op, (V[]){heff_dup(v_lit_241), v_x_243});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(v_ys_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1206589350x791019229_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1206589350x791019229(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_rec_n(2, shape_fixed__op, (V[]){heff_dup(v_lit_241), v_x_244});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1057423371x1101358195_str0, 1, "_");
Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1057423371x1101358195_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1057423371x1101358195(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24At = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_prelude_2e_2b_2b_24f1057423371x1101358195_str0), 2)) {
        heff_drop_cell(v_ru_24x1_241_24At, 2);
        heff_drop(v_x_244);
        return v_ys_240;
      } else {
        V v_t_246 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_ys_240));
        return heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_244, v_t_246});
      }
    }
    case TAG_PatTag: {
      V v_ps_249 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_249));
      V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2410); r_; });
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2411, v_ys_240);
    }
    case TAG_PatOp: {
      V v_ps_2414 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2414));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2415); r_; });
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2416, v_ys_240);
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatRecord: {
      V v_fs_2422 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2422));
      V v_t_2424 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2423; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2423); r_; });
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2424, v_ys_240);
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatAs: {
      V v_x_2426 = heff_field(v_x11_242, 0);
      V v_q_2428 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 5ULL, 3);
      V v_cell_2429 = heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_2426, heff_hole()});
      V v_u_2430 = (g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps(v_ys_240, v_q_2428, heff_dup(v_cell_2429)));
      heff_drop(v_u_2430);
      return v_cell_2429;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f1057423371x1101358195_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1057423371x1101358195(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(V v_ys_240, V v_x1_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    V v_t_244 = (g_prelude_2e_2b_2b(v_ys_242, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_244);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_241, 0);
    V v_xs_246 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_xs_246;
    V t_2 = v_ys_242;
    V t_3 = v_cell_247;
    v_ys_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f1572068627x1632985590_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1572068627x1632985590_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1572068627x1632985590(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_tag_n(TAG_CDrop, 1, (V[]){v_x_242});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1572068627x1632985590_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1572068627x1632985590(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_tag_n(TAG_CDrop, 1, (V[]){v_x_243});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1572068627x1632985590_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1085359736x1262841716_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1085359736x1262841716(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_x_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = (g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1085359736x1262841716(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_y_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_x_247 = v_y_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_248;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f677743828x1026746250_entry, 3, 0};

V g_prelude_2e_2b_2b_24f677743828x1026746250(V v_ys_240, V v_i_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return (g_prelude_2e_2b_2b(v_xs_244, v_ys_240));
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = (g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(v_ys_240, heff_intSub(v_i_241, MK_INT(1LL)), v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f677743828x1026746250(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(V v_ys_240, V v_i_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V v_t_247 = (g_prelude_2e_2b_2b(v_xs_245, v_ys_240));
      return heff_setField(v_d_243, MK_INT(1LL), v_t_247);
    } else {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_ys_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      V t_2 = v_xs_245;
      V t_3 = v_cell_248;
      v_ys_240 = t_0;
      v_i_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f709746438x971999636_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f709746438x971999636_entry, 2, 0};

V g_prelude_2e_2b_2b_24f709746438x971999636(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_x12_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_247 = (g_prelude_2e_2b_2b_24f709746438x971999636_24dps(v_ys_240, v_x12_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f709746438x971999636_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f709746438x971999636(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f1678011228x1831833404_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1678011228x1831833404_24dps_entry, 6, 0};

V g_prelude_2e_2b_2b_24f1678011228x1831833404_24dps(V v_ys_240, V v_box_24lit_241, V v_lit_242, V v_box_24lit_243, V v_x2_244, V v_d_245) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    return heff_setField(v_d_245, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    if ((v_lit_241 < heff_unbox_word(heff_strLength_lent(v_x_246, 0)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_x_246, v_lit_242, 0)) == v_lit_243)) {
        heff_drop(v_x_246);
        heff_drop_cell(v_ru_24x2_244_24Cons, 2);
        V t_0 = v_ys_240;
        int64_t t_1 = v_lit_241;
        V t_2 = v_lit_242;
        int64_t t_3 = v_lit_243;
        V t_4 = v_xs_247;
        V t_5 = v_d_245;
        v_ys_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_x2_244 = t_4;
        v_d_245 = t_5;
        goto top;
      } else {
        V v_cell_2410 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
        V v_u_2411 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = v_ys_240;
        int64_t t_1 = v_lit_241;
        V t_2 = v_lit_242;
        int64_t t_3 = v_lit_243;
        V t_4 = v_xs_247;
        V t_5 = v_cell_2410;
        v_ys_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_x2_244 = t_4;
        v_d_245 = t_5;
        goto top;
      }
    } else {
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
      V v_u_2413 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_ys_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_xs_247;
      V t_5 = v_cell_2412;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_x2_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_prelude_2e_2b_2b_24f1678011228x1831833404_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_prelude_2e_2b_2b_24f1678011228x1831833404_24dps(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
Clo g_prelude_2e_2b_2b_24f1727312714x1365290191_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1727312714x1365290191_entry, 9, 0};

V g_prelude_2e_2b_2b_24f1727312714x1365290191(V v_ys_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_x3_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_x3_248);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_249);
      heff_drop(v_xs_2410);
      heff_drop_cell(v_ru_24x2_247_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_y_2411 = heff_field(v_x3_248, 0);
      V v_ys_2412 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      V v_t_2413 = ({ V a_0 = v_x_249; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_249); r_; });
      V v_t_2414 = heff_strAppend(heff_intShow(v_y_2411), heff_dup(v_lit_246));
      V v_x_2415 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2413), heff_strAppend(heff_dup(v_lit_245), v_t_2414));
      V v_cell_2416 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_x_2415, heff_hole()});
      V v_u_2417 = (g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps(v_ys_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_2410, v_ys_2412, heff_dup(v_cell_2416)));
      heff_drop(v_u_2417);
      return v_cell_2416;
    }
    default: return heff_nomatch(v_x3_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2e_2b_2b_24f1727312714x1365290191_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1727312714x1365290191(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_str0, 1, ":");
Clo g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_x_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_str0), v_x_243));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_247;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1537904782x516751275_str0, 1, "_");
Clo g_prelude_2e_2b_2b_24f1537904782x516751275_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1537904782x516751275_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1537904782x516751275(V v_ys_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_241, 0);
    V v_p2_243 = heff_field(v_p_241, 1);
    V v_ru_24p_241_24At = heff_take_reuse_n(v_p_241, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_prelude_2e_2b_2b_24f1537904782x516751275_str0), 2)) {
        heff_drop(v_p2_243);
        heff_drop_cell(v_ru_24p_241_24At, 2);
        heff_drop(v_x_244);
        return v_ys_240;
      } else {
        V v_x_246 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_p2_243, NTAG(TAG_False)});
        V v_t_247 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_ys_240));
        return heff_tag_at_n(v_ru_24p_241_24At, TAG_Cons, 2, (V[]){v_x_246, v_t_247});
      }
    }
    case TAG_PatTag: {
      V v_ps_2410 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
      V v_t_2412 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2411); r_; });
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2412, v_ys_240);
    }
    case TAG_PatOp: {
      V v_ps_2415 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2415));
      V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2416); r_; });
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2417, v_ys_240);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatBinary: {
      V v_segs_2421 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2421));
      V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2422); r_; });
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2423, v_ys_240);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatRecord: {
      V v_fs_2425 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2425));
      V v_t_2427 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2426; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2426); r_; });
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2427, v_ys_240);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatAs: {
      V v_x_2429 = heff_field(v_p1_242, 0);
      V v_sp_2430 = heff_field(v_p1_242, 1);
      V v_q_2431 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_p2_243);
      V v_x_2432 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2429, v_sp_2430, NTAG(TAG_False)});
      V v_cell_2433 = heff_tag_at_n(v_ru_24p_241_24At, TAG_Cons, 2, (V[]){v_x_2432, heff_hole()});
      V v_u_2434 = (g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(v_ys_240, v_q_2431, heff_dup(v_cell_2433)));
      heff_drop(v_u_2434);
      return v_cell_2433;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_prelude_2e_2b_2b_24f1537904782x516751275_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1537904782x516751275(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f686409757x475266571_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f686409757x475266571_entry, 5, 0};

V g_prelude_2e_2b_2b_24f686409757x475266571(V v_ys_240, V v_owner_241, V v_launch_242, V v_i_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_owner_241);
    heff_drop(v_launch_242);
    heff_drop(v_i_243);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x41_245 = heff_field(v_x4_244, 0);
    V v_rest_246 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_name_247 = heff_field(v_x41_245, 0);
      V v_limit_248 = heff_field(v_x41_245, 1);
      V v_ru_24x41_245_24MkPair = heff_take_reuse_n(v_x41_245, 3ULL, 2);
      V v_t_249 = heff_tag_at_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_i_243), NTAG(TAG_Nil)});
      V v_x_2410 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(v_owner_241), heff_dup(v_launch_242), v_t_249, v_name_247, NTAG(TAG_Nil), v_limit_248});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x41_245_24MkPair, TAG_Cons, 2, (V[]){v_x_2410, heff_hole()});
      V v_u_2412 = (g_prelude_2e_2b_2b_24f686409757x475266571_24dps(v_ys_240, v_owner_241, v_launch_242, heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL))), v_rest_246, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_prelude_2e_2b_2b_24f686409757x475266571_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f686409757x475266571(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_prelude_2e_2b_2b_24f686409757x475266571_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f686409757x475266571_24dps_entry, 6, 0};

V g_prelude_2e_2b_2b_24f686409757x475266571_24dps(V v_ys_240, V v_owner_241, V v_launch_242, V v_i_243, V v_x4_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_owner_241);
    heff_drop(v_launch_242);
    heff_drop(v_i_243);
    return heff_setField(v_d_245, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x41_246 = heff_field(v_x4_244, 0);
    V v_rest_247 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    switch (heff_tag_of(v_x41_246)) {
    case TAG_MkPair: {
      V v_name_248 = heff_field(v_x41_246, 0);
      V v_limit_249 = heff_field(v_x41_246, 1);
      V v_ru_24x41_246_24MkPair = heff_take_reuse_n(v_x41_246, 3ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_i_243), NTAG(TAG_Nil)});
      V v_x_2411 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(v_owner_241), heff_dup(v_launch_242), v_t_2410, v_name_248, NTAG(TAG_Nil), v_limit_249});
      V v_cell_2412 = heff_tag_at_n(v_ru_24x41_246_24MkPair, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
      V v_u_2413 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_ys_240;
      V t_1 = v_owner_241;
      V t_2 = v_launch_242;
      V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
      V t_4 = v_rest_247;
      V t_5 = v_cell_2412;
      v_ys_240 = t_0;
      v_owner_241 = t_1;
      v_launch_242 = t_2;
      v_i_243 = t_3;
      v_x4_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x41_246);
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_prelude_2e_2b_2b_24f686409757x475266571_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f686409757x475266571_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_prelude_2e_2b_2b_24f738852651x284559611_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f738852651x284559611_entry, 2, 0};

V g_prelude_2e_2b_2b_24f738852651x284559611(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = (g_heff_2ebuild_2edriver_2elean(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f738852651x284559611_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f738852651x284559611_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f738852651x284559611(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f144264237x1558451749_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f144264237x1558451749_entry, 3, 0};

V g_prelude_2e_2b_2b_24f144264237x1558451749(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_241))) {
      heff_drop_rec(v_x_243, 14);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = (g_prelude_2e_2b_2b_24f144264237x1558451749_24dps(v_ys_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f144264237x1558451749_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_prelude_2e_2b_2b_24f144264237x1558451749(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_prelude_2e_2b_2b_24f144264237x1558451749_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f144264237x1558451749_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f144264237x1558451749_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_241))) {
      heff_drop_rec(v_x_244, 14);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f144264237x1558451749_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_prelude_2e_2b_2b_24f144264237x1558451749_24dps(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_prelude_2e_2b_2b_24f427551988x255400191_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f427551988x255400191_entry, 2, 0};

V g_prelude_2e_2b_2b_24f427551988x255400191(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_get_n(v_x_242, 0, 14);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f427551988x255400191_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f427551988x255400191_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f427551988x255400191(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f427551988x255400191_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f427551988x255400191_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f427551988x255400191_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_get_n(v_x_243, 0, 14);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f427551988x255400191_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f427551988x255400191_24dps(a[0], a[1], a[2]);
}