// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_PerformAt 64592
#define LBL_directArms 1189396761
#define LBL_directCond 1189453476
#define LBL_directE 1902362554
#define LBL_directFields 683579375
#define LBL_directList 1189716000
static uint32_t shape_directList__directCond__directFields__directArms__directE[] = {LBL_directList, LBL_directCond, LBL_directFields, LBL_directArms, LBL_directE};
V g_heff_2ecompile_2edirect_2edirectArms_23mutual(V, V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectArms_23mutual_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2edirectArms_23mutual_clo;
HeffT2 g_heff_2ecompile_2edirect_2edirectBoc_24cpr(V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectCond_23mutual(V, V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectCond_23mutual_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2edirectCond_23mutual_clo;
HeffT2 g_heff_2ecompile_2edirect_2edirectDefs_24cpr(V, V, V);
V g_heff_2ecompile_2edirect_2edirectDefs_24tok2(V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectDefs_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2edirectDefs_24tok2_clo;
V g_heff_2ecompile_2edirect_2edirectE_23mutual(V, V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectE_23mutual_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2edirectE_23mutual_clo;
HeffT2 g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24dps_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectFields_23mutual(V, V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectFields_23mutual_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2edirectFields_23mutual_clo;
V g_heff_2ecompile_2edirect_2edirectList_23mutual(V, V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectList_23mutual_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2edirectList_23mutual_clo;
HeffT2 g_heff_2ecompile_2edirect_2edirectList_23mutual_24s2100653597x1754463521_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2edirect_2edirectList_23mutual_24s2100653597x1754463521_24dps_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2edirect_2emoduleAt(V, V);
V g_heff_2ecompile_2edirect_2emoduleAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2emoduleAt_clo;
V g_heff_2ecompile_2edirect_2emutual_23directList_get(void);
V g_heff_2ecompile_2edirect_2evalueOf(V, V);
V g_heff_2ecompile_2edirect_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2evalueOf_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2edirect_2emoduleAt_str0, 0, "");
Clo g_heff_2ecompile_2edirect_2emoduleAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2emoduleAt_entry, 2, 0};

V g_heff_2ecompile_2edirect_2emoduleAt(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((V)&g_heff_2ecompile_2edirect_2emoduleAt_str0);
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      return heff_dup(v_m_242);
    } else {
      V t_0 = v_rest_243;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2edirect_2emoduleAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2edirect_2emoduleAt(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2edirect_2evalueOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2evalueOf_entry, 2, 0};

V g_heff_2ecompile_2edirect_2evalueOf(V v_kn_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EVar = heff_take_reuse_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_kn_240, v_x_242));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_x_242);
        heff_drop_cell(v_ru_24e_241_24EVar, 1);
        V v_x_246 = v_field_245;
        return v_x_246;
      } else {
        heff_drop(v_field_245);
        return heff_tag_re_n(v_ru_24e_241_24EVar, TAG_EVar, 1, 1ULL, (V[]){v_x_242});
      }
    }
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    return v_e_241;
  }
  case TAG_EApp: {
    return v_e_241;
  }
  case TAG_ELet: {
    return v_e_241;
  }
  case TAG_ERecord: {
    return v_e_241;
  }
  case TAG_EProj: {
    return v_e_241;
  }
  case TAG_ETag: {
    return v_e_241;
  }
  case TAG_EMatch: {
    return v_e_241;
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    return v_e_241;
  }
  case TAG_ECall: {
    return v_e_241;
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EBytes: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EBool: {
    return v_e_241;
  }
  case TAG_ESet: {
    return v_e_241;
  }
  case TAG_EValues: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2edirect_2evalueOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2edirect_2evalueOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2edirect_2edirectCond_23mutual_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2edirectCond_23mutual_entry, 5, 0};

V g_heff_2ecompile_2edirect_2edirectCond_23mutual(V v_mutual_23directList_240, V v_ls_241, V v_kn_242, V v_x4_243, V v_n_244) {
top: ;
  V v_directE_245 = heff_take_field(v_mutual_23directList_240, 4);
  V v_directCond_246 = heff_get_n(v_mutual_23directList_240, 1, 5);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_CTrue: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directCond_246);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_244});
  }
  case TAG_CFalse: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directCond_246);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_244});
  }
  case TAG_CRel: {
    V v_p_247 = heff_field(v_x4_243, 0);
    V v_x_248 = heff_field(v_x4_243, 1);
    V v_y_249 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24CRel = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    heff_drop(v_directCond_246);
    V v_t_2410 = heff_tr(heff_call(heff_dup(v_directE_245), 4, (V[]){heff_dup(v_ls_241), heff_dup(v_kn_242), v_x_248, v_n_244}));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkPair: {
      V v_x2_2411 = heff_field(v_t_2410, 0);
      V v_n2_2412 = heff_field(v_t_2410, 1);
      V v_ru_24t_2410_24MkPair = heff_take_reuse_n(v_t_2410, 3ULL, 2);
      V v_t_2413 = heff_tr(heff_call(v_directE_245, 4, (V[]){v_ls_241, v_kn_242, v_y_249, v_n2_2412}));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_MkPair: {
        V v_y2_2414 = heff_field(v_t_2413, 0);
        V v_n3_2415 = heff_field(v_t_2413, 1);
        heff_take_n(v_t_2413, 3ULL, 2);
        return heff_tag_at_n(v_ru_24t_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x4_243_24CRel, TAG_CRel, 3, 1ULL, (V[]){v_p_247, v_x2_2411, v_y2_2414}), v_n3_2415});
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24CTest = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_directCond_246);
    V v_t_2417 = heff_tr(heff_call(v_directE_245, 4, (V[]){v_ls_241, v_kn_242, v_x_2416, v_n_244}));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_MkPair: {
      V v_x2_2418 = heff_field(v_t_2417, 0);
      V v_n2_2419 = heff_field(v_t_2417, 1);
      V v_ru_24t_2417_24MkPair = heff_take_reuse_n(v_t_2417, 3ULL, 2);
      return heff_tag_re_n(v_ru_24t_2417_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x4_243_24CTest, TAG_CTest, 1, (V[]){v_x2_2418}), v_n2_2419});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  case TAG_CNot: {
    V v_c_2420 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24CNot = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_directE_245);
    V v_t_2421 = heff_tr(heff_call(v_directCond_246, 4, (V[]){v_ls_241, v_kn_242, v_c_2420, v_n_244}));
    switch (heff_tag_of(v_t_2421)) {
    case TAG_MkPair: {
      V v_c2_2422 = heff_field(v_t_2421, 0);
      V v_n2_2423 = heff_field(v_t_2421, 1);
      V v_ru_24t_2421_24MkPair = heff_take_reuse_n(v_t_2421, 3ULL, 2);
      return heff_tag_re_n(v_ru_24t_2421_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x4_243_24CNot, TAG_CNot, 1, (V[]){v_c2_2422}), v_n2_2423});
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  case TAG_CIf: {
    V v_a_2424 = heff_field(v_x4_243, 0);
    V v_b_2425 = heff_field(v_x4_243, 1);
    V v_c_2426 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24CIf = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    heff_drop(v_directE_245);
    V v_t_2427 = heff_tr(heff_call(heff_dup(v_directCond_246), 4, (V[]){heff_dup(v_ls_241), heff_dup(v_kn_242), v_a_2424, v_n_244}));
    switch (heff_tag_of(v_t_2427)) {
    case TAG_MkPair: {
      V v_a2_2428 = heff_field(v_t_2427, 0);
      V v_n2_2429 = heff_field(v_t_2427, 1);
      V v_ru_24t_2427_24MkPair = heff_take_reuse_n(v_t_2427, 3ULL, 2);
      V v_t_2430 = heff_tr(heff_call(heff_dup(v_directCond_246), 4, (V[]){heff_dup(v_ls_241), heff_dup(v_kn_242), v_b_2425, v_n2_2429}));
      switch (heff_tag_of(v_t_2430)) {
      case TAG_MkPair: {
        V v_b2_2431 = heff_field(v_t_2430, 0);
        V v_n3_2432 = heff_field(v_t_2430, 1);
        heff_take_n(v_t_2430, 3ULL, 2);
        V v_t_2433 = heff_tr(heff_call(v_directCond_246, 4, (V[]){v_ls_241, v_kn_242, v_c_2426, v_n3_2432}));
        switch (heff_tag_of(v_t_2433)) {
        case TAG_MkPair: {
          V v_c2_2434 = heff_field(v_t_2433, 0);
          V v_n4_2435 = heff_field(v_t_2433, 1);
          heff_take_n(v_t_2433, 3ULL, 2);
          return heff_tag_at_n(v_ru_24t_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24CIf, TAG_CIf, 3, (V[]){v_a2_2428, v_b2_2431, v_c2_2434}), v_n4_2435});
        }
        default: return heff_nomatch(v_t_2433);
        }
      }
      default: return heff_nomatch(v_t_2430);
      }
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2edirect_2edirectCond_23mutual_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edirect_2edirectCond_23mutual(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2edirect_2edirectFields_23mutual_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2edirectFields_23mutual_entry, 5, 0};

V g_heff_2ecompile_2edirect_2edirectFields_23mutual(V v_mutual_23directList_240, V v_ls_241, V v_kn_242, V v_x4_243, V v_n_244) {
top: ;
  V v_directE_245 = heff_take_field(v_mutual_23directList_240, 4);
  V v_directFields_246 = heff_get_n(v_mutual_23directList_240, 2, 5);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directFields_246);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_244});
  }
  case TAG_Cons: {
    V v_x41_247 = heff_field(v_x4_243, 0);
    V v_fs_248 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_247)) {
    case TAG_MkPair: {
      V v_l_249 = heff_field(v_x41_247, 0);
      V v_e_2410 = heff_field(v_x41_247, 1);
      V v_ru_24x41_247_24MkPair = heff_take_reuse_n(v_x41_247, 3ULL, 2);
      V v_t_2411 = heff_tr(heff_call(v_directE_245, 4, (V[]){heff_dup(v_ls_241), heff_dup(v_kn_242), v_e_2410, v_n_244}));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_MkPair: {
        V v_e2_2412 = heff_field(v_t_2411, 0);
        V v_n2_2413 = heff_field(v_t_2411, 1);
        V v_ru_24t_2411_24MkPair = heff_take_reuse_n(v_t_2411, 3ULL, 2);
        V v_t_2414 = heff_tr(heff_call(v_directFields_246, 4, (V[]){v_ls_241, v_kn_242, v_fs_248, v_n2_2413}));
        switch (heff_tag_of(v_t_2414)) {
        case TAG_MkPair: {
          V v_fs2_2415 = heff_field(v_t_2414, 0);
          V v_n3_2416 = heff_field(v_t_2414, 1);
          heff_take_n(v_t_2414, 3ULL, 2);
          V v_t_2417 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_re_n(v_ru_24x41_247_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_l_249, v_e2_2412}), v_fs2_2415});
          return heff_tag_at_n(v_ru_24t_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2417, v_n3_2416});
        }
        default: return heff_nomatch(v_t_2414);
        }
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_x41_247);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2edirect_2edirectFields_23mutual_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edirect_2edirectFields_23mutual(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2edirect_2emutual_23directList_lam0(V self, V *args); static Clo g_heff_2ecompile_2edirect_2emutual_23directList_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2emutual_23directList_lam0, 1, 0};
V g_heff_2ecompile_2edirect_2emutual_23directList_lam1(V self, V *args); static Clo g_heff_2ecompile_2edirect_2emutual_23directList_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2emutual_23directList_lam1, 1, 0};
V g_heff_2ecompile_2edirect_2emutual_23directList_lam2(V self, V *args); static Clo g_heff_2ecompile_2edirect_2emutual_23directList_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2emutual_23directList_lam2, 1, 0};
V g_heff_2ecompile_2edirect_2emutual_23directList_lam3(V self, V *args); static Clo g_heff_2ecompile_2edirect_2emutual_23directList_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2emutual_23directList_lam3, 1, 0};
V g_heff_2ecompile_2edirect_2emutual_23directList_lam4(V self, V *args); static Clo g_heff_2ecompile_2edirect_2emutual_23directList_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2emutual_23directList_lam4, 1, 0};

static V g_heff_2ecompile_2edirect_2emutual_23directList_val;
static HEFF_ONCE g_heff_2ecompile_2edirect_2emutual_23directList_st;
static V g_heff_2ecompile_2edirect_2emutual_23directList_init(void) {
  return heff_rec_n(5, shape_directList__directCond__directFields__directArms__directE, (V[]){((V)&g_heff_2ecompile_2edirect_2emutual_23directList_lam0_clo), ((V)&g_heff_2ecompile_2edirect_2emutual_23directList_lam1_clo), ((V)&g_heff_2ecompile_2edirect_2emutual_23directList_lam2_clo), ((V)&g_heff_2ecompile_2edirect_2emutual_23directList_lam3_clo), ((V)&g_heff_2ecompile_2edirect_2emutual_23directList_lam4_clo)});
}
V g_heff_2ecompile_2edirect_2emutual_23directList_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2edirect_2emutual_23directList_st)) return g_heff_2ecompile_2edirect_2emutual_23directList_val;
  return heff_global(&g_heff_2ecompile_2edirect_2emutual_23directList_val, &g_heff_2ecompile_2edirect_2emutual_23directList_st, g_heff_2ecompile_2edirect_2emutual_23directList_init);
}
V g_heff_2ecompile_2edirect_2emutual_23directList_lam0(V self, V *args) {
  V v_directList_23arg_240 = args[0];
  V f_ = ((V)&g_heff_2ecompile_2edirect_2edirectList_23mutual_clo);
  heff_room[0] = heff_dup(g_heff_2ecompile_2edirect_2emutual_23directList_get());
  heff_room[1] = v_directList_23arg_240;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ecompile_2edirect_2emutual_23directList_lam1(V self, V *args) {
  V v_directCond_23arg_241 = args[0];
  V f_ = ((V)&g_heff_2ecompile_2edirect_2edirectCond_23mutual_clo);
  heff_room[0] = heff_dup(g_heff_2ecompile_2edirect_2emutual_23directList_get());
  heff_room[1] = v_directCond_23arg_241;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ecompile_2edirect_2emutual_23directList_lam2(V self, V *args) {
  V v_directFields_23arg_242 = args[0];
  V f_ = ((V)&g_heff_2ecompile_2edirect_2edirectFields_23mutual_clo);
  heff_room[0] = heff_dup(g_heff_2ecompile_2edirect_2emutual_23directList_get());
  heff_room[1] = v_directFields_23arg_242;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ecompile_2edirect_2emutual_23directList_lam3(V self, V *args) {
  V v_directArms_23arg_243 = args[0];
  V f_ = ((V)&g_heff_2ecompile_2edirect_2edirectArms_23mutual_clo);
  heff_room[0] = heff_dup(g_heff_2ecompile_2edirect_2emutual_23directList_get());
  heff_room[1] = v_directArms_23arg_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ecompile_2edirect_2emutual_23directList_lam4(V self, V *args) {
  V v_directE_23arg_244 = args[0];
  V f_ = ((V)&g_heff_2ecompile_2edirect_2edirectE_23mutual_clo);
  heff_room[0] = heff_dup(g_heff_2ecompile_2edirect_2emutual_23directList_get());
  heff_room[1] = v_directE_23arg_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}

HeffT2 g_heff_2ecompile_2edirect_2edirectList_23mutual_24s2100653597x1754463521_24cpr(V v_ls_240, V v_kn_241, V v_x4_242, V v_n_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{NTAG(TAG_Nil), v_n_243}});
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_242, 0);
    V v_es_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_246 = (g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(heff_dup(v_ls_240), heff_dup(v_kn_241), v_e_244, v_n_243));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      V v_e2_249 = v_field_247;
      V v_n2_2410 = v_field_248;
      switch (heff_tag_of(v_es_245)) {
      case TAG_Nil: {
        heff_drop(v_ls_240);
        heff_drop(v_kn_241);
        V v_t_2411 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
        return ((HeffT2){{v_t_2411, v_n2_2410}});
      }
      case TAG_Cons: {
        V v_e_2412 = heff_field(v_es_245, 0);
        V v_es_2413 = heff_field(v_es_245, 1);
        V v_ru_24es_245_24Cons = heff_take_reuse_n(v_es_245, 3ULL, 2);
        HeffT2 v_t_2414 = (g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(heff_dup(v_ls_240), heff_dup(v_kn_241), v_e_2412, v_n2_2410));
        {
          V v_field_2415 = v_t_2414.f[0];
          V v_field_2416 = v_t_2414.f[1];
          V v_e2_2417 = v_field_2415;
          V v_n2_2418 = v_field_2416;
          V v_cell_2419 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_e2_249, heff_hole()});
          V v_cell_2420 = heff_tag_at_n(v_ru_24es_245_24Cons, TAG_Cons, 2, (V[]){v_e2_2417, heff_hole()});
          V v_u_2421 = heff_setField(heff_dup(v_cell_2419), MK_INT(1LL), v_cell_2420);
          HeffT2 v_t_2422 = ({ V a_0 = v_ls_240; V a_1 = v_kn_241; V a_2 = v_es_2413; V a_3 = v_n2_2418; V a_4 = v_u_2421; HeffT2 r_ = (g_heff_2ecompile_2edirect_2edirectList_23mutual_24s2100653597x1754463521_24dps_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_u_2421); r_; });
          {
            V v_field_2423 = v_t_2422.f[0];
            V v_field_2424 = v_t_2422.f[1];
            V v__5f_2425 = v_field_2423;
            heff_drop(v__5f_2425);
            V v_n3_2426 = v_field_2424;
            return ((HeffT2){{v_cell_2419, v_n3_2426}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_es_245)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr_str0, 3, "boc");
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr_str1, 8, "direct#u");

HeffT2 g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(V v_ls_240, V v_kn_241, V v_x4_242, V v_n_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_EVar: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EGlobal: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x4_242, 0);
    V v_b_247 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24ELam = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_cell_248 = heff_tag_re_n(v_ru_24x4_242_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_xs_246, heff_hole()});
    HeffT2 v_t_249 = (g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24dps_24cpr(v_ls_240, v_kn_241, v_b_247, v_n_243, v_cell_248));
    {
      V v_field_2410 = v_t_249.f[0];
      V v_field_2411 = v_t_249.f[1];
      V v__5f_2412 = v_field_2410;
      heff_drop(v__5f_2412);
      V v_n2_2413 = v_field_2411;
      return ((HeffT2){{v_cell_248, v_n2_2413}});
    }
  }
  case TAG_EApp: {
    V v_f_2414 = heff_field(v_x4_242, 0);
    V v_args_2415 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24EApp = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_2416 = (g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(heff_dup(v_ls_240), heff_dup(v_kn_241), v_f_2414, v_n_243));
    {
      V v_field_2417 = v_t_2416.f[0];
      V v_field_2418 = v_t_2416.f[1];
      V v_f2_2419 = v_field_2417;
      V v_n2_2420 = v_field_2418;
      switch (heff_tag_of(v_args_2415)) {
      case TAG_Nil: {
        heff_drop(v_ls_240);
        heff_drop(v_kn_241);
        V v_t_2421 = heff_tag_at_n(v_ru_24x4_242_24EApp, TAG_EApp, 2, (V[]){v_f2_2419, NTAG(TAG_Nil)});
        return ((HeffT2){{v_t_2421, v_n2_2420}});
      }
      case TAG_Cons: {
        V v_e_2422 = heff_field(v_args_2415, 0);
        V v_es_2423 = heff_field(v_args_2415, 1);
        V v_ru_24args_2415_24Cons = heff_take_reuse_n(v_args_2415, 3ULL, 2);
        HeffT2 v_t_2424 = (g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(heff_dup(v_ls_240), heff_dup(v_kn_241), v_e_2422, v_n2_2420));
        {
          V v_field_2425 = v_t_2424.f[0];
          V v_field_2426 = v_t_2424.f[1];
          V v_e2_2427 = v_field_2425;
          V v_n2_2428 = v_field_2426;
          HeffT2 v_t_2429 = (g_heff_2ecompile_2edirect_2edirectList_23mutual_24s2100653597x1754463521_24cpr(v_ls_240, v_kn_241, v_es_2423, v_n2_2428));
          {
            V v_field_2430 = v_t_2429.f[0];
            V v_field_2431 = v_t_2429.f[1];
            V v_es2_2432 = v_field_2430;
            V v_n3_2433 = v_field_2431;
            V v_t_2434 = heff_tag_at_n(v_ru_24x4_242_24EApp, TAG_EApp, 2, (V[]){v_f2_2419, heff_tag_at_n(v_ru_24args_2415_24Cons, TAG_Cons, 2, (V[]){v_e2_2427, v_es2_2432})});
            return ((HeffT2){{v_t_2434, v_n3_2433}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_args_2415)}});
      }
    }
  }
  case TAG_ELet: {
    V v_x_2435 = heff_field(v_x4_242, 0);
    V v_a_2436 = heff_field(v_x4_242, 1);
    V v_b_2437 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24ELet = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){heff_dup(v_ls_240), heff_dup(v_kn_241), v_a_2436, v_n_243}));
    switch (heff_tag_of(v_t_2438)) {
    case TAG_MkPair: {
      V v_a2_2439 = heff_field(v_t_2438, 0);
      V v_n2_2440 = heff_field(v_t_2438, 1);
      heff_take_n(v_t_2438, 3ULL, 2);
      V v_t_2441 = (g_heff_2ecompile_2eir_2eisValue(v_a2_2439));
      V v_kn2_2442;
      if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
        heff_drop(v_t_2441);
        v_kn2_2442 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_kn_241, heff_dup(v_x_2435), heff_dup(v_a2_2439)));
      } else {
        heff_drop(v_t_2441);
        v_kn2_2442 = v_kn_241;
      }
      V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){v_ls_240, v_kn2_2442, v_b_2437, v_n2_2440}));
      switch (heff_tag_of(v_t_2443)) {
      case TAG_MkPair: {
        V v_b2_2444 = heff_field(v_t_2443, 0);
        V v_n3_2445 = heff_field(v_t_2443, 1);
        heff_take_n(v_t_2443, 3ULL, 2);
        V v_t_2446 = (g_heff_2ecompile_2eir_2eisValue(v_a2_2439));
        if (((heff_dup(v_t_2446) == NTAG(TAG_True)) && ({ V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b2_2444), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24155 = (g_heff_2ecompile_2eir_2ecountW(v_x_2435, MK_INT(0LL), heff_dup(v_t_2447))); int c_ = heff_intEq_c_lent(v_t_24155, MK_INT(0LL), 2); heff_drop(v_t_24155); c_; }); heff_drop(v_t_2447); c_; }))) {
          heff_drop(v_x_2435);
          heff_drop_cell(v_ru_24x4_242_24ELet, 3);
          heff_drop(v_a2_2439);
          heff_drop(v_t_2446);
          return ((HeffT2){{v_b2_2444, v_n3_2445}});
        } else {
          heff_drop(v_t_2446);
          return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2435, v_a2_2439, v_b2_2444}), v_n3_2445}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2443)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2438)}});
    }
  }
  case TAG_ERecord: {
    V v_fs_2448 = heff_field(v_x4_242, 0);
    V v_tys_2449 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24ERecord = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 2)), 4, (V[]){v_ls_240, v_kn_241, v_fs_2448, v_n_243}));
    switch (heff_tag_of(v_t_2450)) {
    case TAG_MkPair: {
      V v_fs2_2451 = heff_field(v_t_2450, 0);
      V v_n2_2452 = heff_field(v_t_2450, 1);
      heff_take_n(v_t_2450, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24ERecord, TAG_ERecord, 2, 2ULL, (V[]){v_fs2_2451, v_tys_2449}), v_n2_2452}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2450)}});
    }
  }
  case TAG_EProj: {
    V v_e_2453 = heff_field(v_x4_242, 0);
    V v_l_2454 = heff_field(v_x4_242, 1);
    V v_lbls_2455 = heff_field(v_x4_242, 2);
    V v_ty_2456 = heff_field(v_x4_242, 3);
    V v_ru_24x4_242_24EProj = heff_take_reuse_n(v_x4_242, 15ULL, 4);
    V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){v_ls_240, v_kn_241, v_e_2453, v_n_243}));
    switch (heff_tag_of(v_t_2457)) {
    case TAG_MkPair: {
      V v_e2_2458 = heff_field(v_t_2457, 0);
      V v_n2_2459 = heff_field(v_t_2457, 1);
      heff_take_n(v_t_2457, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24EProj, TAG_EProj, 4, 14ULL, (V[]){v_e2_2458, v_l_2454, v_lbls_2455, v_ty_2456}), v_n2_2459}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2457)}});
    }
  }
  case TAG_ETag: {
    V v_t_2460 = heff_field(v_x4_242, 0);
    V v_args_2461 = heff_field(v_x4_242, 1);
    V v_tys_2462 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24ETag = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2463 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_args_2461, v_n_243}));
    switch (heff_tag_of(v_t_2463)) {
    case TAG_MkPair: {
      V v_args2_2464 = heff_field(v_t_2463, 0);
      V v_n2_2465 = heff_field(v_t_2463, 1);
      heff_take_n(v_t_2463, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24ETag, TAG_ETag, 3, 5ULL, (V[]){v_t_2460, v_args2_2464, v_tys_2462}), v_n2_2465}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2463)}});
    }
  }
  case TAG_EMatch: {
    V v_sc_2466 = heff_field(v_x4_242, 0);
    V v_arms_2467 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24EMatch = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2468 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){heff_dup(v_ls_240), heff_dup(v_kn_241), v_sc_2466, v_n_243}));
    switch (heff_tag_of(v_t_2468)) {
    case TAG_MkPair: {
      V v_sc2_2469 = heff_field(v_t_2468, 0);
      V v_n2_2470 = heff_field(v_t_2468, 1);
      heff_take_n(v_t_2468, 3ULL, 2);
      V v_t_2471 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 3)), 4, (V[]){v_ls_240, v_kn_241, v_arms_2467, v_n2_2470}));
      switch (heff_tag_of(v_t_2471)) {
      case TAG_MkPair: {
        V v_arms2_2472 = heff_field(v_t_2471, 0);
        V v_n3_2473 = heff_field(v_t_2471, 1);
        heff_take_n(v_t_2471, 3ULL, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24EMatch, TAG_EMatch, 2, (V[]){v_sc2_2469, v_arms2_2472}), v_n3_2473}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2471)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2468)}});
    }
  }
  case TAG_EPrim: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EPrimCall: {
    V v_x41_2475 = heff_field(v_x4_242, 0);
    V v_x42_2476 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24EPrimCall = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_2475)) {
    case TAG_PerformAt: {
      V v_i_2477 = heff_dup(heff_field(v_x41_2475, 0));
      switch (heff_tag_of(v_x42_2476)) {
      case TAG_Nil: {
        heff_drop(v_i_2477);
        V v_t_2478 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_x42_2476, v_n_243}));
        switch (heff_tag_of(v_t_2478)) {
        case TAG_MkPair: {
          V v_args2_2479 = heff_field(v_t_2478, 0);
          V v_n2_2480 = heff_field(v_t_2478, 1);
          heff_take_n(v_t_2478, 3ULL, 2);
          return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_x41_2475, v_args2_2479}), v_n2_2480}});
        }
        default: return ((HeffT2){{heff_nomatch(v_t_2478)}});
        }
      }
      case TAG_Cons: {
        V v_p_2481 = heff_dup(heff_field(v_x42_2476, 0));
        V v_x422_2482 = heff_dup(heff_field(v_x42_2476, 1));
        switch (heff_tag_of(v_x422_2482)) {
        case TAG_Nil: {
          heff_drop(v_i_2477);
          heff_drop(v_p_2481);
          V v_t_2483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_x42_2476, v_n_243}));
          switch (heff_tag_of(v_t_2483)) {
          case TAG_MkPair: {
            V v_args2_2484 = heff_field(v_t_2483, 0);
            V v_n2_2485 = heff_field(v_t_2483, 1);
            heff_take_n(v_t_2483, 3ULL, 2);
            return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_x41_2475, v_args2_2484}), v_n2_2485}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2483)}});
          }
        }
        case TAG_Cons: {
          V v_k_2486 = heff_field(v_x422_2482, 0);
          V v_x4222_2487 = heff_field(v_x422_2482, 1);
          V v_ru_24x422_2482_24Cons = heff_take_reuse_n(v_x422_2482, 3ULL, 2);
          switch (heff_tag_of(v_x4222_2487)) {
          case TAG_Nil: {
            heff_drop_tag(v_x41_2475, 1);
            heff_drop_tag(v_x42_2476, 2);
            V v_t_2488 = heff_tag_re_n(v_ru_24x422_2482_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_k_2486, NTAG(TAG_Nil)});
            V v_t_2489 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){heff_dup(v_ls_240), heff_dup(v_kn_241), heff_tag_n(TAG_Cons, 2, (V[]){v_p_2481, v_t_2488}), v_n_243}));
            switch (heff_tag_of(v_t_2489)) {
            case TAG_MkPair: {
              V v_args_2490 = heff_field(v_t_2489, 0);
              V v_n2_2491 = heff_field(v_t_2489, 1);
              V v_ru_24t_2489_24MkPair = heff_take_reuse_n(v_t_2489, 3ULL, 2);
              switch (heff_tag_of(v_args_2490)) {
              case TAG_Nil: {
                heff_drop(v_ls_240);
                heff_drop(v_kn_241);
                heff_drop_cell(v_ru_24t_2489_24MkPair, 2);
                V v_t_2492 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2477}), v_args_2490});
                return ((HeffT2){{v_t_2492, v_n2_2491}});
              }
              case TAG_Cons: {
                V v_p2_2493 = heff_dup(heff_field(v_args_2490, 0));
                V v_it2_2494 = heff_dup(heff_field(v_args_2490, 1));
                switch (heff_tag_of(v_it2_2494)) {
                case TAG_Nil: {
                  heff_drop(v_ls_240);
                  heff_drop(v_kn_241);
                  heff_drop_cell(v_ru_24t_2489_24MkPair, 2);
                  heff_drop(v_p2_2493);
                  V v_t_2495 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2477}), v_args_2490});
                  return ((HeffT2){{v_t_2495, v_n2_2491}});
                }
                case TAG_Cons: {
                  V v_k2_2496 = heff_field(v_it2_2494, 0);
                  V v_it22_2497 = heff_field(v_it2_2494, 1);
                  V v_ru_24it2_2494_24Cons = heff_take_reuse_n(v_it2_2494, 3ULL, 2);
                  switch (heff_tag_of(v_it22_2497)) {
                  case TAG_Nil: {
                    heff_drop_tag(v_args_2490, 2);
                    V v_m_2498 = ({ V a_0 = v_ls_240; V a_1 = heff_dup(v_i_2477); V r_ = (g_heff_2ecompile_2edirect_2emoduleAt(a_0, a_1)); heff_drop(v_ls_240); r_; });
                    V v_p_2499 = (g_heff_2ecompile_2edirect_2evalueOf(v_kn_241, heff_dup(v_p2_2493)));
                    if (heff_strEq_c(v_m_2498, ((V)&g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr_str0))) {
                      V v_t_24100 = heff_strAppend(((V)&g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr_str1), heff_intShow(heff_dup(v_n2_2491)));
                      HeffT2 v_t_24101 = ({ V a_0 = v_kn_241; V a_1 = v_t_24100; V a_2 = v_p_2499; V a_3 = heff_dup(v_k2_2496); HeffT2 r_ = (g_heff_2ecompile_2edirect_2edirectBoc_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_kn_241); r_; });
                      {
                        V v_field_24103 = v_t_24101.f[1];
                        int64_t v_tag_24102 = ((int64_t)v_t_24101.f[0]);
                        if ((v_tag_24102 == ((int64_t)0ULL))) {
                          heff_drop_cell(v_ru_24x4_242_24EPrimCall, 2);
                          heff_drop(v_i_2477);
                          heff_drop_cell(v_ru_24t_2489_24MkPair, 2);
                          heff_drop(v_p2_2493);
                          heff_drop(v_k2_2496);
                          heff_drop_cell(v_ru_24it2_2494_24Cons, 2);
                          V v_e_24104 = v_field_24103;
                          V v_f_24105 = heff_intAdd(v_n2_2491, MK_INT(1LL));
                          return ((HeffT2){{v_e_24104, v_f_24105}});
                        } else {
                          heff_drop(v_field_24103);
                          V v_t_24106 = heff_tag_at_n(v_ru_24t_2489_24MkPair, TAG_Cons, 2, (V[]){v_k2_2496, NTAG(TAG_Nil)});
                          V v_t_24107 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2477}), heff_tag_at_n(v_ru_24it2_2494_24Cons, TAG_Cons, 2, (V[]){v_p2_2493, v_t_24106})});
                          return ((HeffT2){{v_t_24107, v_n2_2491}});
                        }
                      }
                    } else {
                      heff_drop(v_kn_241);
                      heff_drop(v_p_2499);
                      V v_t_24108 = heff_tag_at_n(v_ru_24t_2489_24MkPair, TAG_Cons, 2, (V[]){v_k2_2496, NTAG(TAG_Nil)});
                      V v_t_24109 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2477}), heff_tag_at_n(v_ru_24it2_2494_24Cons, TAG_Cons, 2, (V[]){v_p2_2493, v_t_24108})});
                      return ((HeffT2){{v_t_24109, v_n2_2491}});
                    }
                  }
                  case TAG_Cons: {
                    heff_take_n(v_it22_2497, 0ULL, 2);
                    heff_drop(v_ls_240);
                    heff_drop(v_kn_241);
                    heff_drop_cell(v_ru_24t_2489_24MkPair, 2);
                    heff_drop(v_p2_2493);
                    heff_drop(v_k2_2496);
                    heff_drop_cell(v_ru_24it2_2494_24Cons, 2);
                    V v_t_24112 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2477}), v_args_2490});
                    return ((HeffT2){{v_t_24112, v_n2_2491}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_it22_2497)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_it2_2494)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_args_2490)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_t_2489)}});
            }
          }
          case TAG_Cons: {
            heff_take_n(v_x4222_2487, 0ULL, 2);
            heff_drop(v_i_2477);
            heff_drop(v_p_2481);
            heff_drop(v_k_2486);
            heff_drop_cell(v_ru_24x422_2482_24Cons, 2);
            V v_t_24115 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_x42_2476, v_n_243}));
            switch (heff_tag_of(v_t_24115)) {
            case TAG_MkPair: {
              V v_args2_24116 = heff_field(v_t_24115, 0);
              V v_n2_24117 = heff_field(v_t_24115, 1);
              heff_take_n(v_t_24115, 3ULL, 2);
              return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_x41_2475, v_args2_24116}), v_n2_24117}});
            }
            default: return ((HeffT2){{heff_nomatch(v_t_24115)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x4222_2487)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x422_2482)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x42_2476)}});
      }
    }
    default: {
      V v_t_24118 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_x42_2476, v_n_243}));
      switch (heff_tag_of(v_t_24118)) {
      case TAG_MkPair: {
        V v_args2_24119 = heff_field(v_t_24118, 0);
        V v_n2_24120 = heff_field(v_t_24118, 1);
        heff_take_n(v_t_24118, 3ULL, 2);
        return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_x41_2475, v_args2_24119}), v_n2_24120}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_24118)}});
      }
    }
    }
  }
  case TAG_ECall: {
    V v_g_24121 = heff_field(v_x4_242, 0);
    V v_args_24122 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24ECall = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_24123 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_args_24122, v_n_243}));
    switch (heff_tag_of(v_t_24123)) {
    case TAG_MkPair: {
      V v_args2_24124 = heff_field(v_t_24123, 0);
      V v_n2_24125 = heff_field(v_t_24123, 1);
      heff_take_n(v_t_24123, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24ECall, TAG_ECall, 2, 1ULL, (V[]){v_g_24121, v_args2_24124}), v_n2_24125}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24123)}});
    }
  }
  case TAG_EInt: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EFloat: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EStr: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EBytes: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EFixed: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EFloat32: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EAbandon: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EBool: {
    V v_c_24133 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24EBool = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_t_24134 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 1)), 4, (V[]){v_ls_240, v_kn_241, v_c_24133, v_n_243}));
    switch (heff_tag_of(v_t_24134)) {
    case TAG_MkPair: {
      V v_c2_24135 = heff_field(v_t_24134, 0);
      V v_n2_24136 = heff_field(v_t_24134, 1);
      heff_take_n(v_t_24134, 3ULL, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24EBool, TAG_EBool, 1, (V[]){v_c2_24135}), v_n2_24136}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24134)}});
    }
  }
  case TAG_ESet: {
    V v_xs_24137 = heff_field(v_x4_242, 0);
    V v_a_24138 = heff_field(v_x4_242, 1);
    V v_b_24139 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24ESet = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_24140 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){heff_dup(v_ls_240), heff_dup(v_kn_241), v_a_24138, v_n_243}));
    switch (heff_tag_of(v_t_24140)) {
    case TAG_MkPair: {
      V v_a2_24141 = heff_field(v_t_24140, 0);
      V v_n2_24142 = heff_field(v_t_24140, 1);
      heff_take_n(v_t_24140, 3ULL, 2);
      V v_t_24143 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){v_ls_240, v_kn_241, v_b_24139, v_n2_24142}));
      switch (heff_tag_of(v_t_24143)) {
      case TAG_MkPair: {
        V v_b2_24144 = heff_field(v_t_24143, 0);
        V v_n3_24145 = heff_field(v_t_24143, 1);
        heff_take_n(v_t_24143, 3ULL, 2);
        return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24ESet, TAG_ESet, 3, 1ULL, (V[]){v_xs_24137, v_a2_24141, v_b2_24144}), v_n3_24145}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_24143)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24140)}});
    }
  }
  case TAG_EValues: {
    V v_es_24146 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24EValues = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_t_24147 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_es_24146, v_n_243}));
    switch (heff_tag_of(v_t_24147)) {
    case TAG_MkPair: {
      V v_es2_24148 = heff_field(v_t_24147, 0);
      V v_n2_24149 = heff_field(v_t_24147, 1);
      heff_take_n(v_t_24147, 3ULL, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24EValues, TAG_EValues, 1, (V[]){v_es2_24148}), v_n2_24149}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24147)}});
    }
  }
  case TAG_EFix: {
    V v_x_24150 = heff_field(v_x4_242, 0);
    V v_e_24151 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24EFix = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_24152 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){v_ls_240, v_kn_241, v_e_24151, v_n_243}));
    switch (heff_tag_of(v_t_24152)) {
    case TAG_MkPair: {
      V v_e2_24153 = heff_field(v_t_24152, 0);
      V v_n2_24154 = heff_field(v_t_24152, 1);
      heff_take_n(v_t_24152, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24EFix, TAG_EFix, 2, 1ULL, (V[]){v_x_24150, v_e2_24153}), v_n2_24154}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24152)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24dps_24cpr_str0, 3, "boc");
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24dps_24cpr_str1, 8, "direct#u");

HeffT2 g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24dps_24cpr(V v_ls_240, V v_kn_241, V v_x4_242, V v_n_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_EVar: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    V v_u_246 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_x4_242);
    V v_f_247 = heff_hole();
    return ((HeffT2){{v_f_247, v_n_243}});
  }
  case TAG_EGlobal: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    V v_u_249 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_x4_242);
    V v_f_2410 = heff_hole();
    return ((HeffT2){{v_f_2410, v_n_243}});
  }
  case TAG_ELam: {
    V v_xs_2411 = heff_field(v_x4_242, 0);
    V v_b_2412 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24ELam = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_cell_2413 = heff_tag_re_n(v_ru_24x4_242_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_xs_2411, heff_hole()});
    V v_u_2414 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2413);
    V t_0 = v_ls_240;
    V t_1 = v_kn_241;
    V t_2 = v_b_2412;
    V t_3 = v_n_243;
    V t_4 = v_u_2414;
    v_ls_240 = t_0;
    v_kn_241 = t_1;
    v_x4_242 = t_2;
    v_n_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2415 = heff_field(v_x4_242, 0);
    V v_args_2416 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24EApp = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_2417 = (g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(heff_dup(v_ls_240), heff_dup(v_kn_241), v_f_2415, v_n_243));
    {
      V v_field_2418 = v_t_2417.f[0];
      V v_field_2419 = v_t_2417.f[1];
      V v_f2_2420 = v_field_2418;
      V v_n2_2421 = v_field_2419;
      switch (heff_tag_of(v_args_2416)) {
      case TAG_Nil: {
        heff_drop(v_ls_240);
        heff_drop(v_kn_241);
        V v_t_2422 = heff_tag_at_n(v_ru_24x4_242_24EApp, TAG_EApp, 2, (V[]){v_f2_2420, NTAG(TAG_Nil)});
        V v_u_2423 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_t_2422);
        V v_f_2424 = heff_hole();
        return ((HeffT2){{v_f_2424, v_n2_2421}});
      }
      case TAG_Cons: {
        V v_e_2425 = heff_field(v_args_2416, 0);
        V v_es_2426 = heff_field(v_args_2416, 1);
        V v_ru_24args_2416_24Cons = heff_take_reuse_n(v_args_2416, 3ULL, 2);
        HeffT2 v_t_2427 = (g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(heff_dup(v_ls_240), heff_dup(v_kn_241), v_e_2425, v_n2_2421));
        {
          V v_field_2428 = v_t_2427.f[0];
          V v_field_2429 = v_t_2427.f[1];
          V v_e2_2430 = v_field_2428;
          V v_n2_2431 = v_field_2429;
          HeffT2 v_t_2432 = (g_heff_2ecompile_2edirect_2edirectList_23mutual_24s2100653597x1754463521_24cpr(v_ls_240, v_kn_241, v_es_2426, v_n2_2431));
          {
            V v_field_2433 = v_t_2432.f[0];
            V v_field_2434 = v_t_2432.f[1];
            V v_es2_2435 = v_field_2433;
            V v_n3_2436 = v_field_2434;
            V v_t_2437 = heff_tag_at_n(v_ru_24x4_242_24EApp, TAG_EApp, 2, (V[]){v_f2_2420, heff_tag_at_n(v_ru_24args_2416_24Cons, TAG_Cons, 2, (V[]){v_e2_2430, v_es2_2435})});
            V v_u_2438 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_t_2437);
            V v_f_2439 = heff_hole();
            return ((HeffT2){{v_f_2439, v_n3_2436}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_args_2416)}});
      }
    }
  }
  case TAG_ELet: {
    V v_x_2440 = heff_field(v_x4_242, 0);
    V v_a_2441 = heff_field(v_x4_242, 1);
    V v_b_2442 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){heff_dup(v_ls_240), heff_dup(v_kn_241), v_a_2441, v_n_243}));
    switch (heff_tag_of(v_t_2443)) {
    case TAG_MkPair: {
      V v_a2_2444 = heff_field(v_t_2443, 0);
      V v_n2_2445 = heff_field(v_t_2443, 1);
      heff_take_n(v_t_2443, 3ULL, 2);
      V v_t_2446 = (g_heff_2ecompile_2eir_2eisValue(v_a2_2444));
      V v_kn2_2447;
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_t_2446);
        v_kn2_2447 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_kn_241, heff_dup(v_x_2440), heff_dup(v_a2_2444)));
      } else {
        heff_drop(v_t_2446);
        v_kn2_2447 = v_kn_241;
      }
      V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){v_ls_240, v_kn2_2447, v_b_2442, v_n2_2445}));
      switch (heff_tag_of(v_t_2448)) {
      case TAG_MkPair: {
        V v_b2_2449 = heff_field(v_t_2448, 0);
        V v_n3_2450 = heff_field(v_t_2448, 1);
        heff_take_n(v_t_2448, 3ULL, 2);
        V v_t_2451 = (g_heff_2ecompile_2eir_2eisValue(v_a2_2444));
        if (((heff_dup(v_t_2451) == NTAG(TAG_True)) && ({ V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b2_2449), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24218 = (g_heff_2ecompile_2eir_2ecountW(v_x_2440, MK_INT(0LL), heff_dup(v_t_2452))); int c_ = heff_intEq_c_lent(v_t_24218, MK_INT(0LL), 2); heff_drop(v_t_24218); c_; }); heff_drop(v_t_2452); c_; }))) {
          heff_drop(v_x_2440);
          heff_drop(v_a2_2444);
          heff_drop(v_t_2451);
          V v_u_2453 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_b2_2449);
          V v_f_2454 = heff_hole();
          return ((HeffT2){{v_f_2454, v_n3_2450}});
        } else {
          heff_drop(v_t_2451);
          V v_u_2455 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_2440, v_a2_2444, v_b2_2449}));
          V v_f_2456 = heff_hole();
          return ((HeffT2){{v_f_2456, v_n3_2450}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2448)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2443)}});
    }
  }
  case TAG_ERecord: {
    V v_fs_2457 = heff_field(v_x4_242, 0);
    V v_tys_2458 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_t_2459 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 2)), 4, (V[]){v_ls_240, v_kn_241, v_fs_2457, v_n_243}));
    switch (heff_tag_of(v_t_2459)) {
    case TAG_MkPair: {
      V v_fs2_2460 = heff_field(v_t_2459, 0);
      V v_n2_2461 = heff_field(v_t_2459, 1);
      heff_take_n(v_t_2459, 3ULL, 2);
      V v_u_2462 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_ERecord, 2, (V[]){v_fs2_2460, v_tys_2458}));
      V v_f_2463 = heff_hole();
      return ((HeffT2){{v_f_2463, v_n2_2461}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2459)}});
    }
  }
  case TAG_EProj: {
    V v_e_2464 = heff_field(v_x4_242, 0);
    V v_l_2465 = heff_field(v_x4_242, 1);
    V v_lbls_2466 = heff_field(v_x4_242, 2);
    V v_ty_2467 = heff_field(v_x4_242, 3);
    heff_take_n(v_x4_242, 15ULL, 4);
    V v_t_2468 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){v_ls_240, v_kn_241, v_e_2464, v_n_243}));
    switch (heff_tag_of(v_t_2468)) {
    case TAG_MkPair: {
      V v_e2_2469 = heff_field(v_t_2468, 0);
      V v_n2_2470 = heff_field(v_t_2468, 1);
      heff_take_n(v_t_2468, 3ULL, 2);
      V v_u_2471 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_e2_2469, v_l_2465, v_lbls_2466, v_ty_2467}));
      V v_f_2472 = heff_hole();
      return ((HeffT2){{v_f_2472, v_n2_2470}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2468)}});
    }
  }
  case TAG_ETag: {
    V v_t_2473 = heff_field(v_x4_242, 0);
    V v_args_2474 = heff_field(v_x4_242, 1);
    V v_tys_2475 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_t_2476 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_args_2474, v_n_243}));
    switch (heff_tag_of(v_t_2476)) {
    case TAG_MkPair: {
      V v_args2_2477 = heff_field(v_t_2476, 0);
      V v_n2_2478 = heff_field(v_t_2476, 1);
      heff_take_n(v_t_2476, 3ULL, 2);
      V v_u_2479 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_ETag, 3, (V[]){v_t_2473, v_args2_2477, v_tys_2475}));
      V v_f_2480 = heff_hole();
      return ((HeffT2){{v_f_2480, v_n2_2478}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2476)}});
    }
  }
  case TAG_EMatch: {
    V v_sc_2481 = heff_field(v_x4_242, 0);
    V v_arms_2482 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_t_2483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){heff_dup(v_ls_240), heff_dup(v_kn_241), v_sc_2481, v_n_243}));
    switch (heff_tag_of(v_t_2483)) {
    case TAG_MkPair: {
      V v_sc2_2484 = heff_field(v_t_2483, 0);
      V v_n2_2485 = heff_field(v_t_2483, 1);
      heff_take_n(v_t_2483, 3ULL, 2);
      V v_t_2486 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 3)), 4, (V[]){v_ls_240, v_kn_241, v_arms_2482, v_n2_2485}));
      switch (heff_tag_of(v_t_2486)) {
      case TAG_MkPair: {
        V v_arms2_2487 = heff_field(v_t_2486, 0);
        V v_n3_2488 = heff_field(v_t_2486, 1);
        heff_take_n(v_t_2486, 3ULL, 2);
        V v_u_2489 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_sc2_2484, v_arms2_2487}));
        V v_f_2490 = heff_hole();
        return ((HeffT2){{v_f_2490, v_n3_2488}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2486)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2483)}});
    }
  }
  case TAG_EPrim: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    V v_u_2492 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_x4_242);
    V v_f_2493 = heff_hole();
    return ((HeffT2){{v_f_2493, v_n_243}});
  }
  case TAG_EPrimCall: {
    V v_x41_2494 = heff_field(v_x4_242, 0);
    V v_x42_2495 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24EPrimCall = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_2494)) {
    case TAG_PerformAt: {
      V v_i_2496 = heff_dup(heff_field(v_x41_2494, 0));
      switch (heff_tag_of(v_x42_2495)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x4_242_24EPrimCall, 2);
        heff_drop(v_i_2496);
        V v_t_2497 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_x42_2495, v_n_243}));
        switch (heff_tag_of(v_t_2497)) {
        case TAG_MkPair: {
          V v_args2_2498 = heff_field(v_t_2497, 0);
          V v_n2_2499 = heff_field(v_t_2497, 1);
          heff_take_n(v_t_2497, 3ULL, 2);
          V v_u_24100 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_EPrimCall, 2, (V[]){v_x41_2494, v_args2_2498}));
          V v_f_24101 = heff_hole();
          return ((HeffT2){{v_f_24101, v_n2_2499}});
        }
        default: return ((HeffT2){{heff_nomatch(v_t_2497)}});
        }
      }
      case TAG_Cons: {
        V v_p_24102 = heff_dup(heff_field(v_x42_2495, 0));
        V v_x422_24103 = heff_dup(heff_field(v_x42_2495, 1));
        switch (heff_tag_of(v_x422_24103)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x4_242_24EPrimCall, 2);
          heff_drop(v_i_2496);
          heff_drop(v_p_24102);
          V v_t_24104 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_x42_2495, v_n_243}));
          switch (heff_tag_of(v_t_24104)) {
          case TAG_MkPair: {
            V v_args2_24105 = heff_field(v_t_24104, 0);
            V v_n2_24106 = heff_field(v_t_24104, 1);
            heff_take_n(v_t_24104, 3ULL, 2);
            V v_u_24107 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_EPrimCall, 2, (V[]){v_x41_2494, v_args2_24105}));
            V v_f_24108 = heff_hole();
            return ((HeffT2){{v_f_24108, v_n2_24106}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_24104)}});
          }
        }
        case TAG_Cons: {
          V v_k_24109 = heff_field(v_x422_24103, 0);
          V v_x4222_24110 = heff_field(v_x422_24103, 1);
          V v_ru_24x422_24103_24Cons = heff_take_reuse_n(v_x422_24103, 3ULL, 2);
          switch (heff_tag_of(v_x4222_24110)) {
          case TAG_Nil: {
            heff_drop_tag(v_x41_2494, 1);
            heff_drop_tag(v_x42_2495, 2);
            V v_t_24111 = heff_tag_re_n(v_ru_24x422_24103_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_k_24109, NTAG(TAG_Nil)});
            V v_t_24112 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){heff_dup(v_ls_240), heff_dup(v_kn_241), heff_tag_n(TAG_Cons, 2, (V[]){v_p_24102, v_t_24111}), v_n_243}));
            switch (heff_tag_of(v_t_24112)) {
            case TAG_MkPair: {
              V v_args_24113 = heff_field(v_t_24112, 0);
              V v_n2_24114 = heff_field(v_t_24112, 1);
              V v_ru_24t_24112_24MkPair = heff_take_reuse_n(v_t_24112, 3ULL, 2);
              switch (heff_tag_of(v_args_24113)) {
              case TAG_Nil: {
                heff_drop(v_ls_240);
                heff_drop(v_kn_241);
                heff_drop_cell(v_ru_24t_24112_24MkPair, 2);
                V v_t_24115 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2496}), v_args_24113});
                V v_u_24116 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_t_24115);
                V v_f_24117 = heff_hole();
                return ((HeffT2){{v_f_24117, v_n2_24114}});
              }
              case TAG_Cons: {
                V v_p2_24118 = heff_dup(heff_field(v_args_24113, 0));
                V v_it2_24119 = heff_dup(heff_field(v_args_24113, 1));
                switch (heff_tag_of(v_it2_24119)) {
                case TAG_Nil: {
                  heff_drop(v_ls_240);
                  heff_drop(v_kn_241);
                  heff_drop_cell(v_ru_24t_24112_24MkPair, 2);
                  heff_drop(v_p2_24118);
                  V v_t_24120 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2496}), v_args_24113});
                  V v_u_24121 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_t_24120);
                  V v_f_24122 = heff_hole();
                  return ((HeffT2){{v_f_24122, v_n2_24114}});
                }
                case TAG_Cons: {
                  V v_k2_24123 = heff_field(v_it2_24119, 0);
                  V v_it22_24124 = heff_field(v_it2_24119, 1);
                  V v_ru_24it2_24119_24Cons = heff_take_reuse_n(v_it2_24119, 3ULL, 2);
                  switch (heff_tag_of(v_it22_24124)) {
                  case TAG_Nil: {
                    heff_drop_tag(v_args_24113, 2);
                    V v_m_24125 = ({ V a_0 = v_ls_240; V a_1 = heff_dup(v_i_2496); V r_ = (g_heff_2ecompile_2edirect_2emoduleAt(a_0, a_1)); heff_drop(v_ls_240); r_; });
                    V v_p_24126 = (g_heff_2ecompile_2edirect_2evalueOf(v_kn_241, heff_dup(v_p2_24118)));
                    if (heff_strEq_c(v_m_24125, ((V)&g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24dps_24cpr_str0))) {
                      V v_t_24127 = heff_strAppend(((V)&g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24dps_24cpr_str1), heff_intShow(heff_dup(v_n2_24114)));
                      HeffT2 v_t_24128 = ({ V a_0 = v_kn_241; V a_1 = v_t_24127; V a_2 = v_p_24126; V a_3 = heff_dup(v_k2_24123); HeffT2 r_ = (g_heff_2ecompile_2edirect_2edirectBoc_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_kn_241); r_; });
                      {
                        V v_field_24130 = v_t_24128.f[1];
                        int64_t v_tag_24129 = ((int64_t)v_t_24128.f[0]);
                        if ((v_tag_24129 == ((int64_t)0ULL))) {
                          heff_drop_cell(v_ru_24x4_242_24EPrimCall, 2);
                          heff_drop(v_i_2496);
                          heff_drop_cell(v_ru_24t_24112_24MkPair, 2);
                          heff_drop(v_p2_24118);
                          heff_drop(v_k2_24123);
                          heff_drop_cell(v_ru_24it2_24119_24Cons, 2);
                          V v_e_24131 = v_field_24130;
                          V v_f_24132 = heff_intAdd(v_n2_24114, MK_INT(1LL));
                          V v_u_24133 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_e_24131);
                          V v_f_24134 = heff_hole();
                          return ((HeffT2){{v_f_24134, v_f_24132}});
                        } else {
                          heff_drop(v_field_24130);
                          V v_t_24135 = heff_tag_at_n(v_ru_24t_24112_24MkPair, TAG_Cons, 2, (V[]){v_k2_24123, NTAG(TAG_Nil)});
                          V v_t_24136 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2496}), heff_tag_at_n(v_ru_24it2_24119_24Cons, TAG_Cons, 2, (V[]){v_p2_24118, v_t_24135})});
                          V v_u_24137 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_t_24136);
                          V v_f_24138 = heff_hole();
                          return ((HeffT2){{v_f_24138, v_n2_24114}});
                        }
                      }
                    } else {
                      heff_drop(v_kn_241);
                      heff_drop(v_p_24126);
                      V v_t_24139 = heff_tag_at_n(v_ru_24t_24112_24MkPair, TAG_Cons, 2, (V[]){v_k2_24123, NTAG(TAG_Nil)});
                      V v_t_24140 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2496}), heff_tag_at_n(v_ru_24it2_24119_24Cons, TAG_Cons, 2, (V[]){v_p2_24118, v_t_24139})});
                      V v_u_24141 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_t_24140);
                      V v_f_24142 = heff_hole();
                      return ((HeffT2){{v_f_24142, v_n2_24114}});
                    }
                  }
                  case TAG_Cons: {
                    heff_take_n(v_it22_24124, 0ULL, 2);
                    heff_drop(v_ls_240);
                    heff_drop(v_kn_241);
                    heff_drop_cell(v_ru_24t_24112_24MkPair, 2);
                    heff_drop(v_p2_24118);
                    heff_drop(v_k2_24123);
                    heff_drop_cell(v_ru_24it2_24119_24Cons, 2);
                    V v_t_24145 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2496}), v_args_24113});
                    V v_u_24146 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_t_24145);
                    V v_f_24147 = heff_hole();
                    return ((HeffT2){{v_f_24147, v_n2_24114}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_it22_24124)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_it2_24119)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_args_24113)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_t_24112)}});
            }
          }
          case TAG_Cons: {
            heff_take_n(v_x4222_24110, 0ULL, 2);
            heff_drop_cell(v_ru_24x4_242_24EPrimCall, 2);
            heff_drop(v_i_2496);
            heff_drop(v_p_24102);
            heff_drop(v_k_24109);
            heff_drop_cell(v_ru_24x422_24103_24Cons, 2);
            V v_t_24150 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_x42_2495, v_n_243}));
            switch (heff_tag_of(v_t_24150)) {
            case TAG_MkPair: {
              V v_args2_24151 = heff_field(v_t_24150, 0);
              V v_n2_24152 = heff_field(v_t_24150, 1);
              heff_take_n(v_t_24150, 3ULL, 2);
              V v_u_24153 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_EPrimCall, 2, (V[]){v_x41_2494, v_args2_24151}));
              V v_f_24154 = heff_hole();
              return ((HeffT2){{v_f_24154, v_n2_24152}});
            }
            default: return ((HeffT2){{heff_nomatch(v_t_24150)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x4222_24110)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x422_24103)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x42_2495)}});
      }
    }
    default: {
      heff_drop_cell(v_ru_24x4_242_24EPrimCall, 2);
      V v_t_24155 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_x42_2495, v_n_243}));
      switch (heff_tag_of(v_t_24155)) {
      case TAG_MkPair: {
        V v_args2_24156 = heff_field(v_t_24155, 0);
        V v_n2_24157 = heff_field(v_t_24155, 1);
        heff_take_n(v_t_24155, 3ULL, 2);
        V v_u_24158 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_EPrimCall, 2, (V[]){v_x41_2494, v_args2_24156}));
        V v_f_24159 = heff_hole();
        return ((HeffT2){{v_f_24159, v_n2_24157}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_24155)}});
      }
    }
    }
  }
  case TAG_ECall: {
    V v_g_24160 = heff_field(v_x4_242, 0);
    V v_args_24161 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_t_24162 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_args_24161, v_n_243}));
    switch (heff_tag_of(v_t_24162)) {
    case TAG_MkPair: {
      V v_args2_24163 = heff_field(v_t_24162, 0);
      V v_n2_24164 = heff_field(v_t_24162, 1);
      heff_take_n(v_t_24162, 3ULL, 2);
      V v_u_24165 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_ECall, 2, (V[]){v_g_24160, v_args2_24163}));
      V v_f_24166 = heff_hole();
      return ((HeffT2){{v_f_24166, v_n2_24164}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24162)}});
    }
  }
  case TAG_EInt: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    V v_u_24168 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_x4_242);
    V v_f_24169 = heff_hole();
    return ((HeffT2){{v_f_24169, v_n_243}});
  }
  case TAG_EFloat: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    V v_u_24171 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_x4_242);
    V v_f_24172 = heff_hole();
    return ((HeffT2){{v_f_24172, v_n_243}});
  }
  case TAG_EStr: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    V v_u_24174 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_x4_242);
    V v_f_24175 = heff_hole();
    return ((HeffT2){{v_f_24175, v_n_243}});
  }
  case TAG_EBytes: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    V v_u_24177 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_x4_242);
    V v_f_24178 = heff_hole();
    return ((HeffT2){{v_f_24178, v_n_243}});
  }
  case TAG_EFixed: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    V v_u_24181 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_x4_242);
    V v_f_24182 = heff_hole();
    return ((HeffT2){{v_f_24182, v_n_243}});
  }
  case TAG_EFloat32: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    V v_u_24184 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_x4_242);
    V v_f_24185 = heff_hole();
    return ((HeffT2){{v_f_24185, v_n_243}});
  }
  case TAG_EAbandon: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    V v_u_24186 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_x4_242);
    V v_f_24187 = heff_hole();
    return ((HeffT2){{v_f_24187, v_n_243}});
  }
  case TAG_EBool: {
    V v_c_24188 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    V v_t_24189 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 1)), 4, (V[]){v_ls_240, v_kn_241, v_c_24188, v_n_243}));
    switch (heff_tag_of(v_t_24189)) {
    case TAG_MkPair: {
      V v_c2_24190 = heff_field(v_t_24189, 0);
      V v_n2_24191 = heff_field(v_t_24189, 1);
      heff_take_n(v_t_24189, 3ULL, 2);
      V v_u_24192 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_EBool, 1, (V[]){v_c2_24190}));
      V v_f_24193 = heff_hole();
      return ((HeffT2){{v_f_24193, v_n2_24191}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24189)}});
    }
  }
  case TAG_ESet: {
    V v_xs_24194 = heff_field(v_x4_242, 0);
    V v_a_24195 = heff_field(v_x4_242, 1);
    V v_b_24196 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_t_24197 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){heff_dup(v_ls_240), heff_dup(v_kn_241), v_a_24195, v_n_243}));
    switch (heff_tag_of(v_t_24197)) {
    case TAG_MkPair: {
      V v_a2_24198 = heff_field(v_t_24197, 0);
      V v_n2_24199 = heff_field(v_t_24197, 1);
      heff_take_n(v_t_24197, 3ULL, 2);
      V v_t_24200 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){v_ls_240, v_kn_241, v_b_24196, v_n2_24199}));
      switch (heff_tag_of(v_t_24200)) {
      case TAG_MkPair: {
        V v_b2_24201 = heff_field(v_t_24200, 0);
        V v_n3_24202 = heff_field(v_t_24200, 1);
        heff_take_n(v_t_24200, 3ULL, 2);
        V v_u_24203 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24194, v_a2_24198, v_b2_24201}));
        V v_f_24204 = heff_hole();
        return ((HeffT2){{v_f_24204, v_n3_24202}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_24200)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24197)}});
    }
  }
  case TAG_EValues: {
    V v_es_24205 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    V v_t_24206 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_es_24205, v_n_243}));
    switch (heff_tag_of(v_t_24206)) {
    case TAG_MkPair: {
      V v_es2_24207 = heff_field(v_t_24206, 0);
      V v_n2_24208 = heff_field(v_t_24206, 1);
      heff_take_n(v_t_24206, 3ULL, 2);
      V v_u_24209 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_EValues, 1, (V[]){v_es2_24207}));
      V v_f_24210 = heff_hole();
      return ((HeffT2){{v_f_24210, v_n2_24208}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24206)}});
    }
  }
  case TAG_EFix: {
    V v_x_24211 = heff_field(v_x4_242, 0);
    V v_e_24212 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_t_24213 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){v_ls_240, v_kn_241, v_e_24212, v_n_243}));
    switch (heff_tag_of(v_t_24213)) {
    case TAG_MkPair: {
      V v_e2_24214 = heff_field(v_t_24213, 0);
      V v_n2_24215 = heff_field(v_t_24213, 1);
      heff_take_n(v_t_24213, 3ULL, 2);
      V v_u_24216 = heff_setFieldPeek(v_d_244, MK_INT(1LL), heff_tag_n(TAG_EFix, 2, (V[]){v_x_24211, v_e2_24214}));
      V v_f_24217 = heff_hole();
      return ((HeffT2){{v_f_24217, v_n2_24215}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24213)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
Clo g_heff_2ecompile_2edirect_2edirectDefs_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2edirectDefs_24tok2_entry, 4, 0};

V g_heff_2ecompile_2edirect_2edirectDefs_24tok2(V v_tok_240, V v_ls_241, V v_x2_242, V v_n_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2edirect_2edirectDefs_24cpr(v_ls_241, v_x2_242, v_n_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2ecompile_2edirect_2edirectDefs_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edirect_2edirectDefs_24tok2(a[0], a[1], a[2], a[3]);
}