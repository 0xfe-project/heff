// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_CInf 46723
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENotationVar 51927
#define TAG_ETag 50948
#define TAG_ETuple 21722
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_EndJump 17665
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_PatTag 47430
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TInf 28962
#define LBL_bind 9519364
#define LBL_bound 295286168
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_giveBack 2038160732
#define LBL_giving 701566649
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_part 9928890
#define LBL_pure 9948095
#define LBL_run 322821
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth__giving__bound[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving, LBL_bound};
static uint32_t shape_part__run[] = {LBL_part, LBL_run};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s122821685x1786755984_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s423413976x1387178348_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s967883893x662417176_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s967883893x662417176_24dps_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eappOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_clo;
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(V, V, V);
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_clo;
V g_heff_2esyntax_2epresyntax_2easAction(V, V, V);
V g_heff_2esyntax_2epresyntax_2easAction_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2easAction_clo;
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(V, V);
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo;
V g_heff_2esyntax_2epresyntax_2eboolOf(V);
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(V, V, V);
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_clo;
V g_heff_2esyntax_2epresyntax_2eifOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eifOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eifOf_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ereturnOf(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereturnOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereturnOf_clo;
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_clo;
V g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_clo;
V g_heff_2esyntax_2epresyntax_2ewordOf(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1276400643x126214923(V);
V g_list_2emap_24s1276400643x126214923_entry(V self, V *a);
extern Clo g_list_2emap_24s1276400643x126214923_clo;
V g_list_2emap_24s2051429168x672290949(V);
V g_list_2emap_24s2051429168x672290949_entry(V self, V *a);
extern Clo g_list_2emap_24s2051429168x672290949_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24s942566919x1152393003(V, V);
V g_list_2emap_24s942566919x1152393003_entry(V self, V *a);
extern Clo g_list_2emap_24s942566919x1152393003_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eifOf_str0, 4, "True");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eifOf_str1, 5, "False");
Clo g_heff_2esyntax_2epresyntax_2eifOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eifOf_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2eifOf(V v_sp_240, V v_c_241, V v_a_242, V v_b_243) {
top: ;
  V v_s_244 = (g_heff_2esyntax_2epresyntax_2eboolOf(v_c_241));
  V v_t_245 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_240, 0)), heff_dup(heff_rfield(v_sp_240, 1))});
  V v_t_248;
  switch (heff_tag_of(v_a_242)) {
  case TAG_At: {
    V v_s_247 = heff_dup(heff_field(v_a_242, 1));
    v_t_248 = v_s_247;
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_240, 0)), heff_dup(heff_rfield(v_sp_240, 1))});
  V v_t_2412;
  switch (heff_tag_of(v_b_243)) {
  case TAG_At: {
    V v_s_2411 = heff_dup(heff_field(v_b_243, 1));
    v_t_2412 = v_s_2411;
    break;
  }
  default: heff_nomatch(v_b_243);
  }
  V v_t_2413 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eifOf_str0), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_t_245)}), v_a_242});
  V v_t_2415 = ({ V rv_1 = heff_get_n(v_t_248, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_245, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2416 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eifOf_str1), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2416, heff_dup(v_t_249)}), v_b_243});
  V v_t_2418 = ({ V rv_1 = heff_get_n(v_t_2412, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_249, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_t_2418}), NTAG(TAG_Nil)});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_t_2415}), v_t_2419});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_244, v_t_2420}), v_sp_240});
}
V g_heff_2esyntax_2epresyntax_2eifOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eifOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epresyntax_2ewrapBinds_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewrapBinds_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewrapBinds(V v_cx_240, V v_binds_241, V v_inner_242) {
top: ;
  V v_names_243 = heff_take_field(v_cx_240, 0);
  V v_sp_244 = heff_get_n(v_cx_240, 3, 7);
  HEFF_LAST return g_list_2efoldl(heff_clo_n(g_heff_2esyntax_2epresyntax_2ewrapBinds_lam0, 2, 2, (V[]){v_names_243, v_sp_244}), v_inner_242, v_binds_241);
}
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2ewrapBinds(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2epresyntax_2ewrapBinds_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_b_246 = args[1];
  V v_names_243 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_x_249;
  switch (heff_tag_of(v_b_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_dup(heff_field(v_b_246, 0));
    v_x_249 = v_x_247;
    break;
  }
  default: heff_nomatch(v_b_246);
  }
  V v_t_2412;
  switch (heff_tag_of(v_b_246)) {
  case TAG_MkPair: {
    V v_y_2411 = heff_dup(heff_field(v_b_246, 1));
    v_t_2412 = v_y_2411;
    break;
  }
  default: heff_nomatch(v_b_246);
  }
  V v_xsp_2415;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_At: {
    V v_s_2414 = heff_field(v_t_2412, 1);
    heff_take_n(v_t_2412, 2ULL, 2);
    v_xsp_2415 = v_s_2414;
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_t_2418;
  switch (heff_tag_of(v_b_246)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_b_246, 1);
    heff_take_n(v_b_246, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_b_246);
  }
  V v_t_2421;
  switch (heff_tag_of(v_acc_245)) {
  case TAG_At: {
    V v_s_2420 = heff_dup(heff_field(v_acc_245, 1));
    v_t_2421 = v_s_2420;
    break;
  }
  default: heff_nomatch(v_acc_245);
  }
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tag_n(TAG_EVar, 1, (V[]){heff_get_n(v_names_243, 0, 3)});
  V v_t_2423 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_249, heff_dup(v_xsp_2415)}), v_acc_245});
  V v_t_2424 = ({ V rv_1 = heff_get_n(v_t_2421, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2415, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_t_2424}), NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_244}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2425})));
}
Clo g_heff_2esyntax_2epresyntax_2easAction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2easAction_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2easAction(V v_lift_240, V v_cx_241, V v_b_242) {
top: ;
  V v_x1_243 = heff_tr(heff_call(v_lift_240, 2, (V[]){NTAG(TAG_Nil), v_b_242}));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x1_243, 0);
    V v_y_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24MkPair = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_y_245)) {
    case TAG_At: {
      V v_s_247 = heff_dup(heff_field(v_y_245, 1));
      v_t_248 = v_s_247;
      break;
    }
    default: heff_nomatch(v_y_245);
    }
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 1, 3);
    V v_t_2410 = heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_249}), v_t_248});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, NTAG(TAG_Nil)});
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2410, v_t_2411));
    return ({ V a_0 = v_cx_241; V a_1 = v_x_244; V a_2 = v_t_2412; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_244); r_; });
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2esyntax_2epresyntax_2easAction_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2easAction(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s122821685x1786755984_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_MkAlt: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_ru_24a_247_24MkAlt = heff_take_reuse_n(v_a_247, 3ULL, 2);
        V v_a_2411;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2411 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_2411 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_2410)));
        }
        V v_t_2412 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_a_249, v_a_2410}), v_a_248});
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
        V v_u_2414 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2413);
        V t_0 = v_a_2411;
        V t_1 = v_xs_246;
        V t_2 = v_u_2414;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ereturnOf_str0, 4, "Left");
Clo g_heff_2esyntax_2epresyntax_2ereturnOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ereturnOf_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ereturnOf(V v_cx_240, V v_sp_241, V v_v_242) {
top: ;
  V v_giving_243 = heff_take_field(v_cx_240, 5);
  V v_bound_244 = heff_take_field(v_cx_240, 6);
  V v_names_245 = heff_get_n(v_cx_240, 0, 7);
  V v_t_246 = v_giving_243;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    V v_t_247 = v_bound_244;
    V v_v_2411;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_v_2411 = v_v_242;
      break;
    }
    case TAG_Just: {
      V v_names_248 = heff_field(v_t_247, 0);
      V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_names_248, NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_at_n(v_ru_24t_247_24Just, TAG_ETuple, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_v_242, v_t_249})});
      v_v_2411 = heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_241)});
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2412 = heff_tag_n(TAG_EVar, 1, (V[]){heff_get_n(v_names_245, 1, 3)});
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2411, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_241}), v_t_2413));
  }
  case TAG_Just: {
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 0ULL, 1);
    heff_drop(v_bound_244);
    V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24t_246_24Just, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ereturnOf_str0)}), heff_dup(v_sp_241)});
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_242, NTAG(TAG_Nil)});
    V v_v_2417 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2415, v_t_2416));
    V v_t_2418 = heff_tag_n(TAG_EVar, 1, (V[]){heff_get_n(v_names_245, 1, 3)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2417, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_sp_241}), v_t_2419));
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2esyntax_2epresyntax_2ereturnOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ereturnOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_str1, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_str2, 7, " := e`)");
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(V v_cx_240, V v_end_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_p_243 = heff_field(v_x4_242, 0);
    V v_ss_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24MkPair = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_xs_245 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_243)));
    HeffT2 v_t_247 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_lam0, 1, 1, (V[]){heff_dup(v_cx_240)}); V a_1 = v_xs_245; HeffT2 r_ = (g_list_2efind_24cpr(a_0, a_1)); heff_drop(v_xs_245); r_; });
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        heff_drop_rec(v_cx_240, 7);
        heff_drop(v_end_241);
        heff_drop(v_ss_244);
        V v_x_2410 = v_field_249;
        V v_t_2413;
        switch (heff_tag_of(v_p_243)) {
        case TAG_At: {
          V v_s_2412 = heff_dup(heff_field(v_p_243, 1));
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_p_243);
        }
        V v_t_2416;
        switch (heff_tag_of(v_p_243)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_p_243, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_p_243);
        }
        V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_str0), heff_dup(v_x_2410)), ((V)&g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_str1));
        V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2417, v_x_2410), ((V)&g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_str2));
        V v_t_2419 = heff_tag_at_n(v_ru_24x4_242_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2418}), heff_dup(v_t_2413)});
        V v_t_2420 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2416, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_243, v_t_2419}), v_t_2420});
      } else {
        heff_drop(v_field_249);
        V v_e_2421 = ({ V a_0 = v_cx_240; V a_1 = v_ss_244; V a_2 = v_end_241; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_ss_244); r_; });
        V v_t_2424;
        switch (heff_tag_of(v_p_243)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_p_243, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_p_243);
        }
        V v_t_2427;
        switch (heff_tag_of(v_e_2421)) {
        case TAG_At: {
          V v_s_2426 = heff_dup(heff_field(v_e_2421, 1));
          v_t_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_e_2421);
        }
        V v_t_2428 = ({ V rv_1 = heff_get_n(v_t_2427, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2424, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x4_242_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_243, v_e_2421}), v_t_2428});
      }
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_246; V b_1 = heff_get_n(v_cx_240, 1, 7); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_246); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str1, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str2, 6, "after#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str3, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str4, 6, "after#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str5, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str6, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str7, 6, "after#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str8, 5, "loop#");
Clo g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735(V v_cx_240, V v_sp_241, V v_c_242, V v_body_243, V v_rest_244, V v_end_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 2, 3);
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    HEFF_LAST return g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167(v_cx_240, v_sp_241, v_c_242, v_body_243, v_rest_244, v_end_245);
  } else {
    heff_drop(v_t_246);
    V v_t_247 = heff_dup(heff_rfield(v_cx_240, 1));
    V v_t_2411;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nil: {
      V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str0)}), heff_dup(v_sp_241)});
      v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      v_t_2411 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_t_247));
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2412 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
    V v_t_2413 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str1), v_t_2412)});
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_241)}), v_t_2411));
    V v_t_2415 = ({ V a_0 = heff_dup(v_sp_241); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_240, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    V v_t_2416 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(heff_dup(v_cx_240), v_rest_244, v_end_245));
    V v_t_2417 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2elocalFun(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str2), v_t_2417), heff_dup(v_sp_241), v_t_2415, v_t_2416));
    V v_t_2419 = ({ V a_0 = heff_dup(v_sp_241); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_240, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    V v_t_2420 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
    HeffT2 v_t_2421 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2420}), NTAG(TAG_Nil), v_c_242));
    {
      V v_field_2422 = v_t_2421.f[0];
      V v_field_2423 = v_t_2421.f[1];
      V v_x_2424 = v_field_2422;
      V v_y_2425 = v_field_2423;
      V v_t_2426 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_2427 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str3), v_t_2426)});
      V v_t_2428 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2427, heff_dup(v_sp_241)}), heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_240, 4))});
      V v_t_2429 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_2430 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str4), v_t_2429)});
      V v_t_2431 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2430, heff_dup(v_sp_241)}), heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_240, 4))});
      V v_t_2432 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2428, v_t_2431})});
      V v_cx_2433 = heff_rec_n(7, shape_names__muts__loop__sp__depth__giving__bound, (V[]){heff_dup(heff_rfield(v_cx_240, 0)), heff_dup(heff_rfield(v_cx_240, 1)), v_t_2432, heff_dup(heff_rfield(v_cx_240, 3)), heff_dup(heff_rfield(v_cx_240, 4)), heff_dup(heff_rfield(v_cx_240, 5)), heff_dup(heff_rfield(v_cx_240, 6))});
      V v_t_2434 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_2435 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str5), v_t_2434)});
      V v_t_2436 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2435, heff_dup(v_sp_241)}), heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_240, 4))});
      V v_t_2441;
      switch (heff_tag_of(v_body_243)) {
      case TAG_Nil: {
        v_t_2441 = (g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(v_t_2436, heff_dup(v_cx_2433), heff_get_n(v_cx_2433, 3, 7)));
        break;
      }
      case TAG_Cons: {
        V v_s_2437 = heff_field(v_body_243, 0);
        V v_x32_2438 = heff_field(v_body_243, 1);
        heff_take_n(v_body_243, 3ULL, 2);
        switch (heff_tag_of(v_x32_2438)) {
        case TAG_Nil: {
          v_t_2441 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_2433, v_s_2437, v_x32_2438, heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2436})));
          break;
        }
        case TAG_Cons: {
          v_t_2441 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_2433, v_s_2437, v_x32_2438, heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2436})));
          break;
        }
        default: heff_nomatch(v_x32_2438);
        }
        break;
      }
      default: heff_nomatch(v_body_243);
      }
      V v_t_2442 = heff_dup(heff_rfield(v_cx_240, 1));
      V v_t_2446;
      switch (heff_tag_of(v_t_2442)) {
      case TAG_Nil: {
        V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str6)}), heff_dup(v_sp_241)});
        v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        v_t_2446 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_t_2442));
        break;
      }
      default: heff_nomatch(v_t_2442);
      }
      V v_t_2447 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_2448 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str7), v_t_2447)});
      V v_t_2449 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2448, heff_dup(v_sp_241)}), v_t_2446));
      V v_t_2450 = (g_heff_2esyntax_2epresyntax_2eifOf(heff_dup(v_sp_241), v_y_2425, v_t_2441, v_t_2449));
      V v_t_2451 = ({ V a_0 = v_cx_240; V a_1 = v_x_2424; V a_2 = v_t_2450; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2424); r_; });
      V v_t_2452 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_2453 = (g_heff_2esyntax_2epresyntax_2elocalFun(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str8), v_t_2452), heff_dup(v_sp_241), v_t_2419, v_t_2451));
      V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
      V v_t_2455 = heff_tag_n(TAG_ELocal, 2, (V[]){v_t_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2454})});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2455, v_sp_241});
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str0, 3, "err");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str1, 7, "recover");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str2, 64, "`try` needs the exception module's `recover`: `import exception`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str3, 10, "leaveScope");
Clo g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814(V v_cx_240, V v_sp_241, V v_x4_242, V v_end_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkTry: {
    V v_err_244 = heff_field(v_x4_242, 0);
    V v_body_245 = heff_field(v_x4_242, 1);
    V v_h_246 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24MkTry = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2412;
    switch (heff_tag_of(v_err_244)) {
    case TAG_Nothing: {
      v_t_2412 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_ty_247 = heff_field(v_err_244, 0);
      heff_take_n(v_err_244, 1ULL, 1);
      V v_t_2410;
      switch (heff_tag_of(v_ty_247)) {
      case TAG_At: {
        V v_s_249 = heff_dup(heff_field(v_ty_247, 1));
        v_t_2410 = v_s_249;
        break;
      }
      default: heff_nomatch(v_ty_247);
      }
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ENamed, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str0), v_ty_247}), v_t_2410});
      v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_err_244);
    }
    V v_t_2413 = heff_intAdd(heff_dup(heff_rfield(v_cx_240, 4)), MK_INT(1LL));
    V v_t_2414 = heff_rec_n(7, shape_names__muts__loop__sp__depth__giving__bound, (V[]){heff_dup(heff_rfield(v_cx_240, 0)), heff_dup(heff_rfield(v_cx_240, 1)), heff_dup(heff_rfield(v_cx_240, 2)), heff_dup(heff_rfield(v_cx_240, 3)), v_t_2413, heff_dup(heff_rfield(v_cx_240, 5)), heff_dup(heff_rfield(v_cx_240, 6))});
    V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_body_245; V a_2 = heff_dup(v_end_243); V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_body_245); r_; });
    V v_t_2421;
    switch (heff_tag_of(v_h_246)) {
    case TAG_MkCatchArm: {
      V v_b_2416 = heff_field(v_h_246, 0);
      V v_ss_2417 = heff_field(v_h_246, 1);
      V v_ru_24h_246_24MkCatchArm = heff_take_reuse_n(v_h_246, 3ULL, 2);
      V v_t_2418 = heff_intAdd(heff_dup(heff_rfield(v_cx_240, 4)), MK_INT(1LL));
      V v_t_2419 = heff_rec_n(7, shape_names__muts__loop__sp__depth__giving__bound, (V[]){heff_dup(heff_rfield(v_cx_240, 0)), heff_dup(heff_rfield(v_cx_240, 1)), heff_dup(heff_rfield(v_cx_240, 2)), heff_dup(heff_rfield(v_cx_240, 3)), v_t_2418, heff_dup(heff_rfield(v_cx_240, 5)), heff_dup(heff_rfield(v_cx_240, 6))});
      V v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = v_ss_2417; V a_2 = v_end_243; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_ss_2417); r_; });
      v_t_2421 = heff_tag_at_n(v_ru_24h_246_24MkCatchArm, TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_b_2416, v_t_2420}), heff_dup(v_sp_241)});
      break;
    }
    default: heff_nomatch(v_h_246);
    }
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
    V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2422})));
    V v_t_2424 = heff_intAdd(heff_dup(heff_rfield(v_sp_241, 0)), MK_INT(3LL));
    V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_241, 0)), v_t_2424});
    V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_242_24MkTry, TAG_ENotationVar, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str1), v_t_2425, ((V)&g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str2)}), heff_dup(v_sp_241)});
    V v_t_2427 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2426, v_t_2423));
    V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 0, 3);
    V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2428}), heff_get_n(v_cx_240, 3, 7)});
    V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str3)}), v_sp_241});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2429, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2431})));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s967883893x662417176_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_a_2410 = heff_field(v_a_244, 4);
        V v_ru_24a_244_24MkSegment = heff_take_reuse_n(v_a_244, 31ULL, 5);
        V v_a_2411 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_a_246), v_st_240));
        V v_t_2412 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24MkSegment, TAG_MkSegment, 5, 31ULL, (V[]){v_a_246, v_a_247, v_a_248, v_a_249, v_a_2410}), v_a_245});
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
        HeffT2 v_t_2414 = (g_heff_2esyntax_2epresyntax_2eaccList_24s967883893x662417176_24dps_24cpr(v_a_2411, v_xs_243, v_cell_2413));
        {
          V v_field_2415 = v_t_2414.f[0];
          V v_field_2416 = v_t_2414.f[1];
          V v_x_2417 = v_field_2415;
          V v__5f_2418 = v_field_2416;
          heff_drop(v__5f_2418);
          return ((HeffT2){{v_x_2417, v_cell_2413}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s423413976x1387178348_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_MkAlt: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_ru_24a_247_24MkAlt = heff_take_reuse_n(v_a_247, 3ULL, 2);
        V v_a_2411 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_a_2410), v_st_240));
        V v_t_2412 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_a_249, v_a_2410}), v_a_248});
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
        V v_u_2414 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2413);
        V t_0 = v_a_2411;
        V t_1 = v_xs_246;
        V t_2 = v_u_2414;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewordOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewordOf(V v_x1_240, V v_sp_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(v_x1_240, v_sp_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_244, v_field_245})});
    } else {
      if ((v_tag_243 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_244, v_field_245})});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_244, v_field_245})});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewordOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_str1, 22, "`Array` takes one type");
V g_heff_2esyntax_2epresyntax_2eappOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eappOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eappOf_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2eappOf(V v_r_240, V v_h_241, V v_args_242, V v_sp_243) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_At: {
    V v_h1_244 = heff_dup(heff_field(v_h_241, 0));
    switch (heff_tag_of(v_h1_244)) {
    case TAG_ETag: {
      V v_t_246 = heff_field(v_h1_244, 0);
      V v_ru_24h1_244_24ETag = heff_take_reuse_n(v_h1_244, 1ULL, 1);
      switch (heff_tag_of(v_h_241)) {
      case TAG_At: {
        V v_tsp_248 = heff_field(v_h_241, 1);
        V v_ru_24h_241_24At = heff_take_reuse_n(v_h_241, 2ULL, 2);
        V v_t_2420 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2eappOf_lam0, 1, 1, (V[]){v_r_240}), v_args_242));
        V v_t_2421 = heff_tag_at_n(v_ru_24h_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CTag, 3, (V[]){v_t_246, v_tsp_248, v_t_2420}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24ETag, TAG_IsCheckable, 1, (V[]){v_t_2421});
      }
      default: return heff_nomatch(v_h_241);
      }
    }
    case TAG_EWord: {
      V v_h11_2422 = heff_field(v_h1_244, 0);
      V v_ru_24h1_244_24EWord = heff_take_reuse_n(v_h1_244, 1ULL, 1);
      switch (heff_tag_of(v_h11_2422)) {
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_241, 2);
        switch (heff_tag_of(v_args_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_r_240, 2);
          V v_t_2423 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_str0), NTAG(TAG_Nothing)});
          V v_t_2424 = heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, heff_dup(v_sp_243)})});
          return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_sp_243})});
        }
        case TAG_Cons: {
          V v_a_2425 = heff_field(v_args_242, 0);
          V v_args2_2426 = heff_field(v_args_242, 1);
          V v_ru_24args_242_24Cons = heff_take_reuse_n(v_args_242, 3ULL, 2);
          switch (heff_tag_of(v_args2_2426)) {
          case TAG_Nil: {
            V v_x1_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_a_2425}));
            V v_t_2437;
            switch (heff_tag_of(v_x1_2427)) {
            case TAG_IsInferable: {
              V v_i_2428 = heff_field(v_x1_2427, 0);
              heff_take_n(v_x1_2427, 1ULL, 1);
              V v_t_2431;
              switch (heff_tag_of(v_i_2428)) {
              case TAG_At: {
                V v_s_2430 = heff_dup(heff_field(v_i_2428, 1));
                v_t_2431 = v_s_2430;
                break;
              }
              default: heff_nomatch(v_i_2428);
              }
              v_t_2437 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){v_i_2428}), v_t_2431});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_2432 = heff_field(v_x1_2427, 0);
              heff_take_n(v_x1_2427, 1ULL, 1);
              V v_t_2435;
              switch (heff_tag_of(v_c_2432)) {
              case TAG_At: {
                V v_s_2434 = heff_dup(heff_field(v_c_2432, 1));
                v_t_2435 = v_s_2434;
                break;
              }
              default: heff_nomatch(v_c_2432);
              }
              v_t_2437 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TChk, 1, (V[]){v_c_2432}), v_t_2435});
              break;
            }
            case TAG_IsType: {
              V v_t_2436 = heff_field(v_x1_2427, 0);
              heff_take_n(v_x1_2427, 1ULL, 1);
              heff_drop_cell(v_ru_24h1_244_24EWord, 1);
              heff_drop_cell(v_ru_24args_242_24Cons, 2);
              v_t_2437 = v_t_2436;
              break;
            }
            default: heff_nomatch(v_x1_2427);
            }
            V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TArray, 1, (V[]){v_t_2437}), v_sp_243});
            return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2438});
          }
          case TAG_Cons: {
            V v_ru_24args2_2426_24Cons = heff_take_reuse_n(v_args2_2426, 0ULL, 2);
            heff_drop_rec(v_r_240, 2);
            heff_drop(v_a_2425);
            V v_t_2441 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_str1), NTAG(TAG_Nothing)});
            V v_t_2442 = heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){v_t_2441, heff_dup(v_sp_243)})});
            return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_at_n(v_ru_24args2_2426_24Cons, TAG_At, 2, (V[]){v_t_2442, v_sp_243})});
          }
          default: return heff_nomatch(v_args2_2426);
          }
        }
        default: return heff_nomatch(v_args_242);
        }
      }
      default: {
        heff_drop(v_h11_2422);
        V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2444 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2443));
        V v_t_2445 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2444, v_t_2445}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2446});
      }
      }
    }
    default: {
      heff_drop(v_h1_244);
      V v_t_2447 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2448 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2447));
      V v_t_2449 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2448, v_t_2449}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2450});
    }
    }
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eappOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epresyntax_2eappOf_lam0(V self, V *args) {
  V v_e_249 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_IsInferable: {
    V v_i_2411 = heff_field(v_x1_2410, 0);
    V v_ru_24x1_2410_24IsInferable = heff_take_reuse_n(v_x1_2410, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_i_2411)) {
    case TAG_At: {
      V v_s_2413 = heff_dup(heff_field(v_i_2411, 1));
      v_t_2414 = v_s_2413;
      break;
    }
    default: heff_nomatch(v_i_2411);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2410_24IsInferable, TAG_CInf, 1, (V[]){v_i_2411}), v_t_2414});
  }
  case TAG_IsCheckable: {
    V v_c_2415 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    return v_c_2415;
  }
  case TAG_IsType: {
    V v_t_2416 = heff_field(v_x1_2410, 0);
    V v_ru_24x1_2410_24IsType = heff_take_reuse_n(v_x1_2410, 1ULL, 1);
    V v_t_2419;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_At: {
      V v_s_2418 = heff_dup(heff_field(v_t_2416, 1));
      v_t_2419 = v_s_2418;
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2410_24IsType, TAG_CType, 1, (V[]){v_t_2416}), v_t_2419});
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str0, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str1, 10, "bitsConcat");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str2, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str3, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str4, 10, "bitsConcat");
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0, 2, 0};
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1, 2, 0};

HeffT2 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(V v_lit_240, V v_r_241, V v_segs_242, V v_sp_243, V v_x5_244) {
top: ;
  if ((heff_dup(v_x5_244) == NTAG(TAG_True))) {
    V v_t_245 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo), 2, (V[]){v_lit_240, v_r_241}));
    V v_m_2414 = heff_rec_n(2, shape_part__run, (V[]){v_t_245, ((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0_clo)});
    V v_xs_2415 = (g_heff_2esyntax_2epresyntax_2ebinaryParts(v_m_2414, v_segs_242, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2415));
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2416, heff_dup(v_sp_243)));
    V v_args_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2418));
    V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str1)}), heff_dup(v_sp_243)});
    V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2420, v_t_2419}), heff_dup(v_sp_243)});
    V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2421}), heff_dup(v_sp_243)});
    V v_args_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    V v_t_2424 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2423));
    V v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str2)}), heff_dup(v_sp_243)});
    return ((HeffT2){{heff_tag_n(TAG_IApp, 2, (V[]){v_t_2425, v_t_2424}), v_sp_243}});
  } else {
    V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo), 2, (V[]){v_lit_240, v_r_241}));
    V v_m_2435 = heff_rec_n(2, shape_part__run, (V[]){v_t_2426, ((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1_clo)});
    V v_xs_2436 = (g_heff_2esyntax_2epresyntax_2ebinaryParts(v_m_2435, v_segs_242, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2436));
    V v_t_2438 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2437, heff_dup(v_sp_243)));
    V v_args_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
    V v_t_2440 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2439));
    V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str4)}), heff_dup(v_sp_243)});
    return ((HeffT2){{heff_tag_n(TAG_IApp, 2, (V[]){v_t_2441, v_t_2440}), v_sp_243}});
  }
}
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_sp_247 = args[1];
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str0)}), heff_dup(v_sp_247)});
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_246}), heff_dup(v_sp_247)});
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), heff_dup(v_sp_247)});
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2410}), heff_dup(v_sp_247)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_2412}), heff_dup(v_sp_247)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2413}), v_sp_247});
}
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1(V self, V *args) {
  V v_s_2427 = args[0];
  V v_sp_2428 = args[1];
  V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str3)}), heff_dup(v_sp_2428)});
  V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_2427}), heff_dup(v_sp_2428)});
  V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2430}), heff_dup(v_sp_2428)});
  V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2431}), heff_dup(v_sp_2428)});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
  V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2429, v_t_2433}), heff_dup(v_sp_2428)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2434}), v_sp_2428});
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_str0, 19, "prelude.codePointOf");
Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V v_v_240, V v_sp_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_240));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_t_2415;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_c_246 = heff_tag_n(TAG_At, 2, (V[]){v_field_244, v_field_245});
      v_t_2415 = v_c_246;
    } else {
      if ((v_tag_243 == ((int64_t)1ULL))) {
        V v_i_247 = heff_tag_n(TAG_At, 2, (V[]){v_field_244, v_field_245});
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
      } else {
        V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){v_field_244, v_field_245});
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_t_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2411}), v_t_2414});
      }
    }
    V v_args_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
    V v_t_2417 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2416));
    V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_str0)}), heff_dup(v_sp_241)});
    V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2418, v_t_2417}), heff_dup(v_sp_241)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2419}), v_sp_241});
  }
}
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclEquations: {
      V v_f_243 = heff_field(v_x21_241, 0);
      V v_fsp_244 = heff_field(v_x21_241, 1);
      V v_declared_245 = heff_field(v_x21_241, 2);
      V v_ty_246 = heff_field(v_x21_241, 3);
      V v_eqs_247 = heff_field(v_x21_241, 4);
      V v_ru_24x21_241_24DeclEquations = heff_take_reuse_n(v_x21_241, 31ULL, 5);
      HeffT3 v_t_248 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_ty_246));
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        V v_t_2421;
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_c_2412 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2410, v_field_2411});
          V v_t_2415;
          switch (heff_tag_of(v_c_2412)) {
          case TAG_At: {
            V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
            v_t_2415 = v_s_2414;
            break;
          }
          default: heff_nomatch(v_c_2412);
          }
          v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        } else {
          if ((v_tag_249 == ((int64_t)1ULL))) {
            V v_i_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2410, v_field_2411});
            V v_t_2419;
            switch (heff_tag_of(v_i_2416)) {
            case TAG_At: {
              V v_s_2418 = heff_dup(heff_field(v_i_2416, 1));
              v_t_2419 = v_s_2418;
              break;
            }
            default: heff_nomatch(v_i_2416);
            }
            v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2416}), v_t_2419});
          } else {
            V v_t_2420 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2410, v_field_2411});
            v_t_2421 = v_t_2420;
          }
        }
        V v_t_2422 = (g_list_2emap_24s1276400643x126214923(v_eqs_247));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_241_24DeclEquations, TAG_DeclEquations, 5, 7ULL, (V[]){v_f_243, v_fsp_244, v_declared_245, v_t_2421, v_t_2422}), v_sp_242});
      }
    }
    case TAG_DeclDefine: {
      V v_x_2423 = heff_field(v_x21_241, 0);
      V v_xsp_2424 = heff_field(v_x21_241, 1);
      V v_ps_2425 = heff_field(v_x21_241, 2);
      V v_u_2426 = heff_field(v_x21_241, 3);
      V v_body_2427 = heff_field(v_x21_241, 4);
      V v_ru_24x21_241_24DeclDefine = heff_take_reuse_n(v_x21_241, 31ULL, 5);
      V v_t_2428 = (g_list_2emap_24s2051429168x672290949(v_ps_2425));
      HeffT3 v_t_2429 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_u_2426));
      {
        V v_field_2431 = v_t_2429.f[1];
        V v_field_2432 = v_t_2429.f[2];
        int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
        V v_t_2442;
        if ((v_tag_2430 == ((int64_t)0ULL))) {
          V v_c_2433 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2431, v_field_2432});
          V v_t_2436;
          switch (heff_tag_of(v_c_2433)) {
          case TAG_At: {
            V v_s_2435 = heff_dup(heff_field(v_c_2433, 1));
            v_t_2436 = v_s_2435;
            break;
          }
          default: heff_nomatch(v_c_2433);
          }
          v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2433}), v_t_2436});
        } else {
          if ((v_tag_2430 == ((int64_t)1ULL))) {
            V v_i_2437 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2431, v_field_2432});
            V v_t_2440;
            switch (heff_tag_of(v_i_2437)) {
            case TAG_At: {
              V v_s_2439 = heff_dup(heff_field(v_i_2437, 1));
              v_t_2440 = v_s_2439;
              break;
            }
            default: heff_nomatch(v_i_2437);
            }
            v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2437}), v_t_2440});
          } else {
            V v_t_2441 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2431, v_field_2432});
            v_t_2442 = v_t_2441;
          }
        }
        HeffT3 v_t_2443 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2427));
        {
          V v_field_2445 = v_t_2443.f[1];
          V v_field_2446 = v_t_2443.f[2];
          int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
          V v_t_2456;
          if ((v_tag_2444 == ((int64_t)0ULL))) {
            V v_c_2447 = heff_tag_n(TAG_At, 2, (V[]){v_field_2445, v_field_2446});
            v_t_2456 = v_c_2447;
          } else {
            if ((v_tag_2444 == ((int64_t)1ULL))) {
              V v_i_2448 = heff_tag_n(TAG_At, 2, (V[]){v_field_2445, v_field_2446});
              V v_t_2451;
              switch (heff_tag_of(v_i_2448)) {
              case TAG_At: {
                V v_s_2450 = heff_dup(heff_field(v_i_2448, 1));
                v_t_2451 = v_s_2450;
                break;
              }
              default: heff_nomatch(v_i_2448);
              }
              v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2448}), v_t_2451});
            } else {
              V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){v_field_2445, v_field_2446});
              V v_t_2455;
              switch (heff_tag_of(v_t_2452)) {
              case TAG_At: {
                V v_s_2454 = heff_dup(heff_field(v_t_2452, 1));
                v_t_2455 = v_s_2454;
                break;
              }
              default: heff_nomatch(v_t_2452);
              }
              v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2452}), v_t_2455});
            }
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_241_24DeclDefine, TAG_DeclDefine, 5, 3ULL, (V[]){v_x_2423, v_xsp_2424, v_t_2428, v_t_2442, v_t_2456}), v_sp_242});
        }
      }
    }
    case TAG_DeclTheory: {
      V v_x_2457 = heff_field(v_x21_241, 0);
      V v_xsp_2458 = heff_field(v_x21_241, 1);
      V v_ps_2459 = heff_field(v_x21_241, 2);
      V v_body_2460 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24DeclTheory = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_t_2461 = (g_list_2emap_24s2051429168x672290949(v_ps_2459));
      HeffT3 v_t_2462 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2460));
      {
        V v_field_2464 = v_t_2462.f[1];
        V v_field_2465 = v_t_2462.f[2];
        int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
        V v_t_2475;
        if ((v_tag_2463 == ((int64_t)0ULL))) {
          V v_c_2466 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2464, v_field_2465});
          v_t_2475 = v_c_2466;
        } else {
          if ((v_tag_2463 == ((int64_t)1ULL))) {
            V v_i_2467 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2464, v_field_2465});
            V v_t_2470;
            switch (heff_tag_of(v_i_2467)) {
            case TAG_At: {
              V v_s_2469 = heff_dup(heff_field(v_i_2467, 1));
              v_t_2470 = v_s_2469;
              break;
            }
            default: heff_nomatch(v_i_2467);
            }
            v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2467}), v_t_2470});
          } else {
            V v_t_2471 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2464, v_field_2465});
            V v_t_2474;
            switch (heff_tag_of(v_t_2471)) {
            case TAG_At: {
              V v_s_2473 = heff_dup(heff_field(v_t_2471, 1));
              v_t_2474 = v_s_2473;
              break;
            }
            default: heff_nomatch(v_t_2471);
            }
            v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2471}), v_t_2474});
          }
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_241_24DeclTheory, TAG_DeclTheory, 4, 3ULL, (V[]){v_x_2457, v_xsp_2458, v_t_2461, v_t_2475}), v_sp_242});
      }
    }
    case TAG_DeclPrimitive: {
      V v_x_2476 = heff_field(v_x21_241, 0);
      V v_xsp_2477 = heff_field(v_x21_241, 1);
      V v_t_2478 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24DeclPrimitive = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      HeffT3 v_t_2479 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2478));
      {
        V v_field_2481 = v_t_2479.f[1];
        V v_field_2482 = v_t_2479.f[2];
        int64_t v_tag_2480 = ((int64_t)v_t_2479.f[0]);
        V v_t_2492;
        if ((v_tag_2480 == ((int64_t)0ULL))) {
          V v_c_2483 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2481, v_field_2482});
          V v_t_2486;
          switch (heff_tag_of(v_c_2483)) {
          case TAG_At: {
            V v_s_2485 = heff_dup(heff_field(v_c_2483, 1));
            v_t_2486 = v_s_2485;
            break;
          }
          default: heff_nomatch(v_c_2483);
          }
          v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2483}), v_t_2486});
        } else {
          if ((v_tag_2480 == ((int64_t)1ULL))) {
            V v_i_2487 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2481, v_field_2482});
            V v_t_2490;
            switch (heff_tag_of(v_i_2487)) {
            case TAG_At: {
              V v_s_2489 = heff_dup(heff_field(v_i_2487, 1));
              v_t_2490 = v_s_2489;
              break;
            }
            default: heff_nomatch(v_i_2487);
            }
            v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2487}), v_t_2490});
          } else {
            V v_t_2491 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2481, v_field_2482});
            v_t_2492 = v_t_2491;
          }
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_241_24DeclPrimitive, TAG_DeclPrimitive, 3, 3ULL, (V[]){v_x_2476, v_xsp_2477, v_t_2492}), v_sp_242});
      }
    }
    case TAG_DeclTest: {
      V v_x_2493 = heff_field(v_x21_241, 0);
      V v_xsp_2494 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24DeclTest = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      return heff_tag_re_n(v_ru_24x2_240_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_241_24DeclTest, TAG_DeclTest, 2, 3ULL, (V[]){v_x_2493, v_xsp_2494}), v_sp_242});
    }
    case TAG_DeclWatch: {
      V v_e_2495 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24DeclWatch = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2496 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_2495));
      V v_t_2497 = (g_heff_2esyntax_2epresyntax_2ewatchOf(v_t_2496));
      return heff_tag_re_n(v_ru_24x2_240_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_2497}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(a[0]);
}