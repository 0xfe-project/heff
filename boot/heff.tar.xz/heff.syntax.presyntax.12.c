// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_CInf 46723
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkTry 8097
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_RuneWord 42901
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_StringWord 15530
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TypeWord 10401
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_e 319
#define LBL_end 310101
#define LBL_giving 701566649
#define LBL_head 9693863
#define LBL_names 305943394
#define LBL_part 9928890
#define LBL_pure 9948095
#define LBL_run 322821
#define LBL_sp 10436
#define LBL_start 311115900
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_part__run[] = {LBL_part, LBL_run};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eappOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_clo;
V g_heff_2esyntax_2epresyntax_2earmsGive(V);
V g_heff_2esyntax_2epresyntax_2earmsGive_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmsGive_clo;
V g_heff_2esyntax_2epresyntax_2easAction(V, V, V);
V g_heff_2esyntax_2epresyntax_2easAction_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2easAction_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo;
V g_heff_2esyntax_2epresyntax_2eboolOf(V);
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2ehasReturn(V);
V g_heff_2esyntax_2epresyntax_2ehasReturn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasReturn_clo;
V g_heff_2esyntax_2epresyntax_2eifOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eifOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eifOf_clo;
V g_heff_2esyntax_2epresyntax_2einfSpineOf(V);
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2ereturnOf(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereturnOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereturnOf_clo;
V g_heff_2esyntax_2epresyntax_2estmtAcc(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtAcc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtAcc_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2estmtAcc_24s153905797x297886855_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2etryAcc_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
V g_heff_2esyntax_2epresyntax_2ewordOf(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany_24s750144226x405092487(V);
V g_list_2eany_24s750144226x405092487_entry(V self, V *a);
extern Clo g_list_2eany_24s750144226x405092487_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1276400643x126214923(V);
V g_list_2emap_24s1276400643x126214923_entry(V self, V *a);
extern Clo g_list_2emap_24s1276400643x126214923_clo;
V g_list_2emap_24s2051429168x672290949(V);
V g_list_2emap_24s2051429168x672290949_entry(V self, V *a);
extern Clo g_list_2emap_24s2051429168x672290949_clo;
V g_list_2emap_24s942566919x1152393003(V, V);
V g_list_2emap_24s942566919x1152393003_entry(V self, V *a);
extern Clo g_list_2emap_24s942566919x1152393003_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfSpineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2einfSpineOf(V v_i_240) {
top: ;
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_i1_241 = heff_dup(heff_field(v_i_240, 0));
    switch (heff_tag_of(v_i1_241)) {
    case TAG_IVar: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IInt: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IFloat: {
      heff_take_na(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IString: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IBytes: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IPrim: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IRune: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IApp: {
      V v_h_2410 = heff_field(v_i1_241, 0);
      V v_xs_2411 = heff_field(v_i1_241, 1);
      heff_take_n(v_i1_241, 3ULL, 2);
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        heff_take_n(v_i_240, 0ULL, 2);
        return heff_rec_n(2, shape_head__args, (V[]){v_h_2410, v_xs_2411});
      }
      default: return heff_nomatch(v_i_240);
      }
    }
    case TAG_IAnn: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ISpec: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IUpdate: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IAnnLam: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IInvalid: {
      heff_take_n(v_i1_241, 0ULL, 3);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_INominal: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ILitEq: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ILazy: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ITuple: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_i1_241);
    }
  }
  default: return heff_nomatch(v_i_240);
  }
}
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfSpineOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eifOf_str0, 4, "True");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eifOf_str1, 4, "True");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eifOf_str2, 5, "False");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eifOf_str3, 5, "False");
Clo g_heff_2esyntax_2epresyntax_2eifOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eifOf_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2eifOf(V v_sp_240, V v_c_241, V v_a_242, V v_b_243) {
top: ;
  V v_s_244 = (g_heff_2esyntax_2epresyntax_2eboolOf(v_c_241));
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eifOf_str0)}), heff_dup(v_sp_240)});
  V v_x1_246 = ({ V a_0 = v_t_245; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_249;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_At: {
    V v_s_248 = heff_field(v_x1_246, 1);
    heff_take_n(v_x1_246, 2ULL, 2);
    v_t_249 = v_s_248;
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  V v_t_2410 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_249, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2411 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eifOf_str1), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_t_2410)}), heff_dup(v_a_242)});
  V v_t_2415;
  switch (heff_tag_of(v_a_242)) {
  case TAG_At: {
    V v_s_2414 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 2ULL, 2);
    v_t_2415 = v_s_2414;
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_t_2416 = ({ V rv_1 = heff_get_n(v_t_2415, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2410, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eifOf_str2)}), heff_dup(v_sp_240)});
  V v_x1_2418 = ({ V a_0 = v_t_2417; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2421;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_At: {
    V v_s_2420 = heff_field(v_x1_2418, 1);
    heff_take_n(v_x1_2418, 2ULL, 2);
    v_t_2421 = v_s_2420;
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  V v_t_2422 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2421, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2423 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eifOf_str3), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, heff_dup(v_t_2422)}), heff_dup(v_b_243)});
  V v_t_2427;
  switch (heff_tag_of(v_b_243)) {
  case TAG_At: {
    V v_s_2426 = heff_field(v_b_243, 1);
    heff_take_n(v_b_243, 2ULL, 2);
    v_t_2427 = v_s_2426;
    break;
  }
  default: heff_nomatch(v_b_243);
  }
  V v_t_2428 = ({ V rv_1 = heff_get_n(v_t_2427, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2422, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_t_2428}), NTAG(TAG_Nil)});
  V v_alts_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_t_2416}), v_t_2429});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_244, v_alts_2430}), v_sp_240});
}
V g_heff_2esyntax_2epresyntax_2eifOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eifOf(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2etryAcc_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkTry: {
    V v_err_243 = heff_field(v_x3_242, 0);
    V v_body_244 = heff_field(v_x3_242, 1);
    V v_c_245 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24MkTry = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_246 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){heff_dup(v_f_240)}));
    HeffT2 v_t_247 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_246, v_st_241, v_body_244));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_x_2410 = v_field_248;
      V v_y_2411 = v_field_249;
      switch (heff_tag_of(v_c_245)) {
      case TAG_MkCatchArm: {
        V v_b_2412 = heff_field(v_c_245, 0);
        V v_ss_2413 = heff_field(v_c_245, 1);
        heff_take_n(v_c_245, 3ULL, 2);
        V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
        HeffT2 v_t_2415 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_2414, v_x_2410, v_ss_2413));
        {
          V v_field_2416 = v_t_2415.f[0];
          V v_field_2417 = v_t_2415.f[1];
          V v_x_2418 = v_field_2416;
          V v_y_2419 = v_field_2417;
          V v_t_2420 = heff_tag_at_n(v_ru_24x3_242_24MkTry, TAG_MkTry, 3, (V[]){v_err_243, v_y_2411, heff_tag_n(TAG_MkCatchArm, 2, (V[]){v_b_2412, v_y_2419})});
          return ((HeffT2){{v_x_2418, v_t_2420}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_c_245)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2estmtAcc_24s153905797x297886855_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_StmtBind: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_e_246 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_x_247;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_247 = NTAG(TAG_True);
      } else {
        v_x_247 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_246)));
      }
      V v_t_248 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtBind, 3, (V[]){v_x_244, v_xsp_245, v_e_246}), v_sp_243});
      return ((HeffT2){{v_x_247, v_t_248}});
    }
    case TAG_StmtLet: {
      V v_p_249 = heff_field(v_x31_242, 0);
      V v_e_2410 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      V v_x_2411;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2411 = NTAG(TAG_True);
      } else {
        v_x_2411 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_2410)));
      }
      V v_t_2412 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_p_249, v_e_2410}), v_sp_243});
      return ((HeffT2){{v_x_2411, v_t_2412}});
    }
    case TAG_StmtExpr: {
      V v_e_2413 = heff_field(v_x31_242, 0);
      heff_take_n(v_x31_242, 1ULL, 1);
      V v_x_2414;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2414 = NTAG(TAG_True);
      } else {
        v_x_2414 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_2413)));
      }
      V v_t_2415 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_2413}), v_sp_243});
      return ((HeffT2){{v_x_2414, v_t_2415}});
    }
    case TAG_StmtLetMut: {
      V v_x_2416 = heff_field(v_x31_242, 0);
      V v_xsp_2417 = heff_field(v_x31_242, 1);
      V v_e_2418 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_x_2419;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2419 = NTAG(TAG_True);
      } else {
        v_x_2419 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_2418)));
      }
      V v_t_2420 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLetMut, 3, (V[]){v_x_2416, v_xsp_2417, v_e_2418}), v_sp_243});
      return ((HeffT2){{v_x_2419, v_t_2420}});
    }
    case TAG_StmtLetElse: {
      V v_p_2421 = heff_field(v_x31_242, 0);
      V v_e_2422 = heff_field(v_x31_242, 1);
      V v_ss_2423 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_x_2424;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2424 = NTAG(TAG_True);
      } else {
        v_x_2424 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_2422)));
      }
      HeffT2 v_t_2425 = (g_heff_2esyntax_2epresyntax_2eaccList_24s894244726x1692032334_24cpr(v_x_2424, v_ss_2423));
      {
        V v_field_2426 = v_t_2425.f[0];
        V v_field_2427 = v_t_2425.f[1];
        V v_x_2428 = v_field_2426;
        V v_y_2429 = v_field_2427;
        V v_t_2430 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLetElse, 3, (V[]){v_p_2421, v_e_2422, v_y_2429}), v_sp_243});
        return ((HeffT2){{v_x_2428, v_t_2430}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
V g_heff_2esyntax_2epresyntax_2ewrapBinds_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewrapBinds_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewrapBinds(V v_cx_240, V v_binds_241, V v_inner_242) {
top: ;
  V v_names_243 = heff_take_field(v_cx_240, 0);
  V v_sp_244 = heff_get_n(v_cx_240, 3, 6);
  HEFF_LAST return g_list_2efoldl(heff_clo_n(g_heff_2esyntax_2epresyntax_2ewrapBinds_lam0, 2, 2, (V[]){v_names_243, v_sp_244}), v_inner_242, v_binds_241);
}
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2ewrapBinds(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2epresyntax_2ewrapBinds_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_b_246 = args[1];
  V v_names_243 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249;
  switch (heff_tag_of(v_b_246)) {
  case TAG_MkPair: {
    V v_y_248 = heff_dup(heff_field(v_b_246, 1));
    v_t_249 = v_y_248;
    break;
  }
  default: heff_nomatch(v_b_246);
  }
  V v_xsp_2412;
  switch (heff_tag_of(v_t_249)) {
  case TAG_At: {
    V v_s_2411 = heff_field(v_t_249, 1);
    heff_take_n(v_t_249, 2ULL, 2);
    v_xsp_2412 = v_s_2411;
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_t_2413 = heff_tag_n(TAG_EVar, 1, (V[]){heff_get_n(v_names_243, 0, 3)});
  V v_t_2416;
  switch (heff_tag_of(v_b_246)) {
  case TAG_MkPair: {
    V v_y_2415 = heff_dup(heff_field(v_b_246, 1));
    v_t_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_b_246);
  }
  V v_t_2419;
  switch (heff_tag_of(v_b_246)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_b_246, 0);
    heff_take_n(v_b_246, 1ULL, 2);
    v_t_2419 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_b_246);
  }
  V v_t_2420 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_t_2419, heff_dup(v_xsp_2412)}), heff_dup(v_acc_245)});
  V v_t_2423;
  switch (heff_tag_of(v_acc_245)) {
  case TAG_At: {
    V v_s_2422 = heff_field(v_acc_245, 1);
    heff_take_n(v_acc_245, 2ULL, 2);
    v_t_2423 = v_s_2422;
    break;
  }
  default: heff_nomatch(v_acc_245);
  }
  V v_t_2424 = ({ V rv_1 = heff_get_n(v_t_2423, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2412, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_t_2424}), NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_244}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2425})));
}
Clo g_heff_2esyntax_2epresyntax_2easAction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2easAction_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2easAction(V v_lift_240, V v_cx_241, V v_b_242) {
top: ;
  V v_x1_243 = heff_tr(heff_call(v_lift_240, 2, (V[]){NTAG(TAG_Nil), v_b_242}));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x1_243, 0);
    V v_y_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24MkPair = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 1, 3);
    V v_t_249;
    switch (heff_tag_of(v_y_245)) {
    case TAG_At: {
      V v_s_248 = heff_dup(heff_field(v_y_245, 1));
      v_t_249 = v_s_248;
      break;
    }
    default: heff_nomatch(v_y_245);
    }
    V v_t_2410 = heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_246}), v_t_249});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, NTAG(TAG_Nil)});
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2410, v_t_2411));
    return ({ V a_0 = v_cx_241; V a_1 = v_x_244; V a_2 = v_t_2412; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_244); r_; });
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2esyntax_2epresyntax_2easAction_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2easAction(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2ehasReturn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ehasReturn_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ehasReturn(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_245 = v_t_244.f[0];
        V v_field_246 = v_t_244.f[1];
        V v_x_247 = v_field_245;
        V v_y_248 = v_field_246;
        heff_drop(v_y_248);
        return v_x_247;
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        V v_y_2414 = v_field_2412;
        heff_drop(v_y_2414);
        return v_x_2413;
      }
    }
    case TAG_ETag: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2416 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2417 = v_t_2416.f[0];
        V v_field_2418 = v_t_2416.f[1];
        V v_x_2419 = v_field_2417;
        V v_y_2420 = v_field_2418;
        heff_drop(v_y_2420);
        return v_x_2419;
      }
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2422 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2423 = v_t_2422.f[0];
        V v_field_2424 = v_t_2422.f[1];
        V v_x_2425 = v_field_2423;
        V v_y_2426 = v_field_2424;
        heff_drop(v_y_2426);
        return v_x_2425;
      }
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2428 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2429 = v_t_2428.f[0];
        V v_field_2430 = v_t_2428.f[1];
        V v_x_2431 = v_field_2429;
        V v_y_2432 = v_field_2430;
        heff_drop(v_y_2432);
        return v_x_2431;
      }
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2434 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2435 = v_t_2434.f[0];
        V v_field_2436 = v_t_2434.f[1];
        V v_x_2437 = v_field_2435;
        V v_y_2438 = v_field_2436;
        heff_drop(v_y_2438);
        return v_x_2437;
      }
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2440 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2441 = v_t_2440.f[0];
        V v_field_2442 = v_t_2440.f[1];
        V v_x_2443 = v_field_2441;
        V v_y_2444 = v_field_2442;
        heff_drop(v_y_2444);
        return v_x_2443;
      }
    }
    case TAG_ERune: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2446 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2447 = v_t_2446.f[0];
        V v_field_2448 = v_t_2446.f[1];
        V v_x_2449 = v_field_2447;
        V v_y_2450 = v_field_2448;
        heff_drop(v_y_2450);
        return v_x_2449;
      }
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2452 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2453 = v_t_2452.f[0];
        V v_field_2454 = v_t_2452.f[1];
        V v_x_2455 = v_field_2453;
        V v_y_2456 = v_field_2454;
        heff_drop(v_y_2456);
        return v_x_2455;
      }
    }
    case TAG_EApp: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2459 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2460 = v_t_2459.f[0];
        V v_field_2461 = v_t_2459.f[1];
        V v_x_2462 = v_field_2460;
        V v_y_2463 = v_field_2461;
        heff_drop(v_y_2463);
        return v_x_2462;
      }
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2465 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2466 = v_t_2465.f[0];
        V v_field_2467 = v_t_2465.f[1];
        V v_x_2468 = v_field_2466;
        V v_y_2469 = v_field_2467;
        heff_drop(v_y_2469);
        return v_x_2468;
      }
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2472 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2473 = v_t_2472.f[0];
        V v_field_2474 = v_t_2472.f[1];
        V v_x_2475 = v_field_2473;
        V v_y_2476 = v_field_2474;
        heff_drop(v_y_2476);
        return v_x_2475;
      }
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2479 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2480 = v_t_2479.f[0];
        V v_field_2481 = v_t_2479.f[1];
        V v_x_2482 = v_field_2480;
        V v_y_2483 = v_field_2481;
        heff_drop(v_y_2483);
        return v_x_2482;
      }
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2490 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2491 = v_t_2490.f[0];
        V v_field_2492 = v_t_2490.f[1];
        V v_x_2493 = v_field_2491;
        V v_y_2494 = v_field_2492;
        heff_drop(v_y_2494);
        return v_x_2493;
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      HeffT2 v_t_2499 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24100 = v_t_2499.f[0];
        V v_field_24101 = v_t_2499.f[1];
        V v_x_24102 = v_field_24100;
        V v_y_24103 = v_field_24101;
        heff_drop(v_y_24103);
        return v_x_24102;
      }
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24105 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24106 = v_t_24105.f[0];
        V v_field_24107 = v_t_24105.f[1];
        V v_x_24108 = v_field_24106;
        V v_y_24109 = v_field_24107;
        heff_drop(v_y_24109);
        return v_x_24108;
      }
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24111 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24112 = v_t_24111.f[0];
        V v_field_24113 = v_t_24111.f[1];
        V v_x_24114 = v_field_24112;
        V v_y_24115 = v_field_24113;
        heff_drop(v_y_24115);
        return v_x_24114;
      }
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24117 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24118 = v_t_24117.f[0];
        V v_field_24119 = v_t_24117.f[1];
        V v_x_24120 = v_field_24118;
        V v_y_24121 = v_field_24119;
        heff_drop(v_y_24121);
        return v_x_24120;
      }
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24124 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24125 = v_t_24124.f[0];
        V v_field_24126 = v_t_24124.f[1];
        V v_x_24127 = v_field_24125;
        V v_y_24128 = v_field_24126;
        heff_drop(v_y_24128);
        return v_x_24127;
      }
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24131 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24132 = v_t_24131.f[0];
        V v_field_24133 = v_t_24131.f[1];
        V v_x_24134 = v_field_24132;
        V v_y_24135 = v_field_24133;
        heff_drop(v_y_24135);
        return v_x_24134;
      }
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24138 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24139 = v_t_24138.f[0];
        V v_field_24140 = v_t_24138.f[1];
        V v_x_24141 = v_field_24139;
        V v_y_24142 = v_field_24140;
        heff_drop(v_y_24142);
        return v_x_24141;
      }
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24144 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24145 = v_t_24144.f[0];
        V v_field_24146 = v_t_24144.f[1];
        V v_x_24147 = v_field_24145;
        V v_y_24148 = v_field_24146;
        heff_drop(v_y_24148);
        return v_x_24147;
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24151 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24152 = v_t_24151.f[0];
        V v_field_24153 = v_t_24151.f[1];
        V v_x_24154 = v_field_24152;
        V v_y_24155 = v_field_24153;
        heff_drop(v_y_24155);
        return v_x_24154;
      }
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24157 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24158 = v_t_24157.f[0];
        V v_field_24159 = v_t_24157.f[1];
        V v_x_24160 = v_field_24158;
        V v_y_24161 = v_field_24159;
        heff_drop(v_y_24161);
        return v_x_24160;
      }
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_241, 0ULL, 3);
      HeffT2 v_t_24165 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24166 = v_t_24165.f[0];
        V v_field_24167 = v_t_24165.f[1];
        V v_x_24168 = v_field_24166;
        V v_y_24169 = v_field_24167;
        heff_drop(v_y_24169);
        return v_x_24168;
      }
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24172 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24173 = v_t_24172.f[0];
        V v_field_24174 = v_t_24172.f[1];
        V v_x_24175 = v_field_24173;
        V v_y_24176 = v_field_24174;
        heff_drop(v_y_24176);
        return v_x_24175;
      }
    }
    case TAG_EFor: {
      heff_take_n(v_e1_241, 0ULL, 3);
      HeffT2 v_t_24180 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24181 = v_t_24180.f[0];
        V v_field_24182 = v_t_24180.f[1];
        V v_x_24183 = v_field_24181;
        V v_y_24184 = v_field_24182;
        heff_drop(v_y_24184);
        return v_x_24183;
      }
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24187 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24188 = v_t_24187.f[0];
        V v_field_24189 = v_t_24187.f[1];
        V v_x_24190 = v_field_24188;
        V v_y_24191 = v_field_24189;
        heff_drop(v_y_24191);
        return v_x_24190;
      }
    }
    case TAG_EBreak: {
      HeffT2 v_t_24192 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24193 = v_t_24192.f[0];
        V v_field_24194 = v_t_24192.f[1];
        V v_x_24195 = v_field_24193;
        V v_y_24196 = v_field_24194;
        heff_drop(v_y_24196);
        return v_x_24195;
      }
    }
    case TAG_EContinue: {
      HeffT2 v_t_24197 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24198 = v_t_24197.f[0];
        V v_field_24199 = v_t_24197.f[1];
        V v_x_24200 = v_field_24198;
        V v_y_24201 = v_field_24199;
        heff_drop(v_y_24201);
        return v_x_24200;
      }
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_241, 0ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_ENest: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24206 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24207 = v_t_24206.f[0];
        V v_field_24208 = v_t_24206.f[1];
        V v_x_24209 = v_field_24207;
        V v_y_24210 = v_field_24208;
        heff_drop(v_y_24210);
        return v_x_24209;
      }
    }
    case TAG_ELazy: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24212 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24213 = v_t_24212.f[0];
        V v_field_24214 = v_t_24212.f[1];
        V v_x_24215 = v_field_24213;
        V v_y_24216 = v_field_24214;
        heff_drop(v_y_24216);
        return v_x_24215;
      }
    }
    case TAG_ETuple: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24218 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24219 = v_t_24218.f[0];
        V v_field_24220 = v_t_24218.f[1];
        V v_x_24221 = v_field_24219;
        V v_y_24222 = v_field_24220;
        heff_drop(v_y_24222);
        return v_x_24221;
      }
    }
    case TAG_ETry: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24224 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24225 = v_t_24224.f[0];
        V v_field_24226 = v_t_24224.f[1];
        V v_x_24227 = v_field_24225;
        V v_y_24228 = v_field_24226;
        heff_drop(v_y_24228);
        return v_x_24227;
      }
    }
    case TAG_EWith: {
      heff_take_n(v_e1_241, 0ULL, 4);
      HeffT2 v_t_24233 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24234 = v_t_24233.f[0];
        V v_field_24235 = v_t_24233.f[1];
        V v_x_24236 = v_field_24234;
        V v_y_24237 = v_field_24235;
        heff_drop(v_y_24237);
        return v_x_24236;
      }
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ehasReturn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ehasReturn(a[0]);
}
V g_heff_2esyntax_2epresyntax_2earmsGive_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2earmsGive_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2earmsGive_lam0, 1, 0};
Clo g_heff_2esyntax_2epresyntax_2earmsGive_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2earmsGive_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2earmsGive(V v_arms_240) {
top: ;
  return (g_list_2eall(((V)&g_heff_2esyntax_2epresyntax_2earmsGive_lam0_clo), v_arms_240));
}
V g_heff_2esyntax_2epresyntax_2earmsGive_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2earmsGive(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2epresyntax_2earmsGive_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_t_244;
  switch (heff_tag_of(v_a_241)) {
  case TAG_MkPair: {
    V v_y_243 = heff_dup(heff_field(v_a_241, 1));
    v_t_244 = v_y_243;
    break;
  }
  default: heff_nomatch(v_a_241);
  }
  V v_x1_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_244));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nil: {
    V v_t_248;
    switch (heff_tag_of(v_a_241)) {
    case TAG_MkPair: {
      V v_y_247 = heff_field(v_a_241, 1);
      heff_take_n(v_a_241, 2ULL, 2);
      v_t_248 = v_y_247;
      break;
    }
    default: heff_nomatch(v_a_241);
    }
    V v_x1_249 = ({ V a_0 = v_t_248; V r_ = (g_list_2eany_24s750144226x405092487(a_0)); heff_drop(v_t_248); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
    heff_drop(v_x1_249);
    return v_ret_24bool;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 2);
    switch (heff_tag_of(v_x_2410)) {
    case TAG_At: {
      V v_it11_2412 = heff_field(v_x_2410, 0);
      heff_take_n(v_x_2410, 1ULL, 2);
      switch (heff_tag_of(v_it11_2412)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_2412, 0ULL, 3);
        V v_t_2419;
        switch (heff_tag_of(v_a_241)) {
        case TAG_MkPair: {
          V v_y_2418 = heff_field(v_a_241, 1);
          heff_take_n(v_a_241, 2ULL, 2);
          v_t_2419 = v_y_2418;
          break;
        }
        default: heff_nomatch(v_a_241);
        }
        V v_x1_2420 = ({ V a_0 = v_t_2419; V r_ = (g_list_2eany_24s750144226x405092487(a_0)); heff_drop(v_t_2419); r_; });
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2420) == NTAG(TAG_True)));
        heff_drop(v_x1_2420);
        return v_ret_24bool;
      }
      case TAG_StmtLet: {
        heff_take_n(v_it11_2412, 0ULL, 2);
        V v_t_2425;
        switch (heff_tag_of(v_a_241)) {
        case TAG_MkPair: {
          V v_y_2424 = heff_field(v_a_241, 1);
          heff_take_n(v_a_241, 2ULL, 2);
          v_t_2425 = v_y_2424;
          break;
        }
        default: heff_nomatch(v_a_241);
        }
        V v_x1_2426 = ({ V a_0 = v_t_2425; V r_ = (g_list_2eany_24s750144226x405092487(a_0)); heff_drop(v_t_2425); r_; });
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2426) == NTAG(TAG_True)));
        heff_drop(v_x1_2426);
        return v_ret_24bool;
      }
      case TAG_StmtExpr: {
        V v_e_2427 = heff_field(v_it11_2412, 0);
        heff_take_n(v_it11_2412, 1ULL, 1);
        V v_t_2428 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2427));
        if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
          heff_drop(v_t_2428);
          V v_t_2431;
          switch (heff_tag_of(v_a_241)) {
          case TAG_MkPair: {
            V v_y_2430 = heff_field(v_a_241, 1);
            heff_take_n(v_a_241, 2ULL, 2);
            v_t_2431 = v_y_2430;
            break;
          }
          default: heff_nomatch(v_a_241);
          }
          V v_x1_2432 = ({ V a_0 = v_t_2431; V r_ = (g_list_2eany_24s750144226x405092487(a_0)); heff_drop(v_t_2431); r_; });
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2432) == NTAG(TAG_True)));
          heff_drop(v_x1_2432);
          return v_ret_24bool;
        } else {
          heff_drop(v_a_241);
          heff_drop(v_t_2428);
          return NTAG(TAG_False);
        }
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_2412, 0ULL, 3);
        V v_t_2438;
        switch (heff_tag_of(v_a_241)) {
        case TAG_MkPair: {
          V v_y_2437 = heff_field(v_a_241, 1);
          heff_take_n(v_a_241, 2ULL, 2);
          v_t_2438 = v_y_2437;
          break;
        }
        default: heff_nomatch(v_a_241);
        }
        V v_x1_2439 = ({ V a_0 = v_t_2438; V r_ = (g_list_2eany_24s750144226x405092487(a_0)); heff_drop(v_t_2438); r_; });
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2439) == NTAG(TAG_True)));
        heff_drop(v_x1_2439);
        return v_ret_24bool;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_2412, 0ULL, 3);
        V v_t_2445;
        switch (heff_tag_of(v_a_241)) {
        case TAG_MkPair: {
          V v_y_2444 = heff_field(v_a_241, 1);
          heff_take_n(v_a_241, 2ULL, 2);
          v_t_2445 = v_y_2444;
          break;
        }
        default: heff_nomatch(v_a_241);
        }
        V v_x1_2446 = ({ V a_0 = v_t_2445; V r_ = (g_list_2eany_24s750144226x405092487(a_0)); heff_drop(v_t_2445); r_; });
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2446) == NTAG(TAG_True)));
        heff_drop(v_x1_2446);
        return v_ret_24bool;
      }
      default: return heff_nomatch(v_it11_2412);
      }
    }
    default: return heff_nomatch(v_x_2410);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ereturnOf_str0, 4, "Left");
Clo g_heff_2esyntax_2epresyntax_2ereturnOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ereturnOf_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ereturnOf(V v_cx_240, V v_sp_241, V v_v_242) {
top: ;
  V v_giving_243 = heff_take_field(v_cx_240, 5);
  V v_names_244 = heff_get_n(v_cx_240, 0, 6);
  switch (heff_tag_of(v_giving_243)) {
  case TAG_Nothing: {
    V v_t_245 = heff_tag_n(TAG_EVar, 1, (V[]){heff_get_n(v_names_244, 1, 3)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_242, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_241}), v_t_246));
  }
  case TAG_Just: {
    V v_ru_24giving_243_24Just = heff_take_reuse_n(v_giving_243, 0ULL, 1);
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24giving_243_24Just, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ereturnOf_str0)}), heff_dup(v_sp_241)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_242, NTAG(TAG_Nil)});
    V v_v_2410 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_248, v_t_249));
    V v_t_2411 = heff_tag_n(TAG_EVar, 1, (V[]){heff_get_n(v_names_244, 1, 3)});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2410, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_241}), v_t_2412));
  }
  default: return heff_nomatch(v_giving_243);
  }
}
V g_heff_2esyntax_2epresyntax_2ereturnOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ereturnOf(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewordOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewordOf(V v_x1_240, V v_sp_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(v_x1_240, v_sp_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_field_244});
    } else {
      if ((v_tag_243 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_244});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){v_field_244});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewordOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_str1, 22, "`Array` takes one type");
V g_heff_2esyntax_2epresyntax_2eappOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eappOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eappOf_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2eappOf(V v_r_240, V v_h_241, V v_args_242, V v_sp_243) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_At: {
    V v_h1_244 = heff_dup(heff_field(v_h_241, 0));
    switch (heff_tag_of(v_h1_244)) {
    case TAG_EVar: {
      V v_ru_24h1_244_24EVar = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_248 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_247));
      V v_t_249 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_249}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EVar, TAG_IsInferable, 1, (V[]){v_t_2410});
    }
    case TAG_EImplicitVar: {
      V v_ru_24h1_244_24EImplicitVar = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2412));
      V v_t_2414 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2413, v_t_2414}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EImplicitVar, TAG_IsInferable, 1, (V[]){v_t_2415});
    }
    case TAG_ETag: {
      V v_t_2416 = heff_field(v_h1_244, 0);
      V v_ru_24h1_244_24ETag = heff_take_reuse_n(v_h1_244, 1ULL, 1);
      switch (heff_tag_of(v_h_241)) {
      case TAG_At: {
        V v_tsp_2418 = heff_field(v_h_241, 1);
        V v_ru_24h_241_24At = heff_take_reuse_n(v_h_241, 2ULL, 2);
        V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2eappOf_lam0, 1, 1, (V[]){v_r_240}), v_args_242));
        V v_t_2431 = heff_tag_at_n(v_ru_24h_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CTag, 3, (V[]){v_t_2416, v_tsp_2418, v_t_2430}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24ETag, TAG_IsCheckable, 1, (V[]){v_t_2431});
      }
      default: return heff_nomatch(v_h_241);
      }
    }
    case TAG_EInt: {
      V v_ru_24h1_244_24EInt = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2434 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2433));
      V v_t_2435 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2434, v_t_2435}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EInt, TAG_IsInferable, 1, (V[]){v_t_2436});
    }
    case TAG_EFloat: {
      V v_ru_24h1_244_24EFloat = heff_take_reuse_na(v_h1_244, 0ULL, 1);
      V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2439 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2438));
      V v_t_2440 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2439, v_t_2440}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EFloat, TAG_IsInferable, 1, (V[]){v_t_2441});
    }
    case TAG_EString: {
      V v_ru_24h1_244_24EString = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2444 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2443));
      V v_t_2445 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2444, v_t_2445}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EString, TAG_IsInferable, 1, (V[]){v_t_2446});
    }
    case TAG_EBinary: {
      V v_ru_24h1_244_24EBinary = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2449 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2448));
      V v_t_2450 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2449, v_t_2450}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EBinary, TAG_IsInferable, 1, (V[]){v_t_2451});
    }
    case TAG_ERune: {
      V v_ru_24h1_244_24ERune = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2454 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2453));
      V v_t_2455 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2454, v_t_2455}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ERune, TAG_IsInferable, 1, (V[]){v_t_2456});
    }
    case TAG_EWord: {
      V v_h11_2457 = heff_field(v_h1_244, 0);
      V v_ru_24h1_244_24EWord = heff_take_reuse_n(v_h1_244, 1ULL, 1);
      switch (heff_tag_of(v_h11_2457)) {
      case TAG_TypeWord: {
        V v_t_2458 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2459 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2458));
        V v_t_2460 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2459, v_t_2460}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2461});
      }
      case TAG_IntWord: {
        V v_t_2462 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2463 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2462));
        V v_t_2464 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_2465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2463, v_t_2464}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2465});
      }
      case TAG_FloatWord: {
        V v_t_2466 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2467 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2466));
        V v_t_2468 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2467, v_t_2468}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2469});
      }
      case TAG_StringWord: {
        V v_t_2470 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2471 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2470));
        V v_t_2472 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_2473 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2471, v_t_2472}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2473});
      }
      case TAG_RuneWord: {
        V v_t_2474 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2475 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2474));
        V v_t_2476 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2475, v_t_2476}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2477});
      }
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_241, 2);
        switch (heff_tag_of(v_args_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_r_240, 2);
          V v_t_2478 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_str0), NTAG(TAG_Nothing)});
          V v_t_2479 = heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2478, heff_dup(v_sp_243)})});
          return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2479, v_sp_243})});
        }
        case TAG_Cons: {
          V v_a_2480 = heff_field(v_args_242, 0);
          V v_args2_2481 = heff_field(v_args_242, 1);
          V v_ru_24args_242_24Cons = heff_take_reuse_n(v_args_242, 3ULL, 2);
          switch (heff_tag_of(v_args2_2481)) {
          case TAG_Nil: {
            V v_x1_2482 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_a_2480}));
            V v_t_2492;
            switch (heff_tag_of(v_x1_2482)) {
            case TAG_IsInferable: {
              V v_i_2483 = heff_field(v_x1_2482, 0);
              heff_take_n(v_x1_2482, 1ULL, 1);
              V v_t_2486;
              switch (heff_tag_of(v_i_2483)) {
              case TAG_At: {
                V v_s_2485 = heff_dup(heff_field(v_i_2483, 1));
                v_t_2486 = v_s_2485;
                break;
              }
              default: heff_nomatch(v_i_2483);
              }
              v_t_2492 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){v_i_2483}), v_t_2486});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_2487 = heff_field(v_x1_2482, 0);
              heff_take_n(v_x1_2482, 1ULL, 1);
              V v_t_2490;
              switch (heff_tag_of(v_c_2487)) {
              case TAG_At: {
                V v_s_2489 = heff_dup(heff_field(v_c_2487, 1));
                v_t_2490 = v_s_2489;
                break;
              }
              default: heff_nomatch(v_c_2487);
              }
              v_t_2492 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TChk, 1, (V[]){v_c_2487}), v_t_2490});
              break;
            }
            case TAG_IsType: {
              V v_t_2491 = heff_field(v_x1_2482, 0);
              heff_take_n(v_x1_2482, 1ULL, 1);
              heff_drop_cell(v_ru_24h1_244_24EWord, 1);
              heff_drop_cell(v_ru_24args_242_24Cons, 2);
              v_t_2492 = v_t_2491;
              break;
            }
            default: heff_nomatch(v_x1_2482);
            }
            V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TArray, 1, (V[]){v_t_2492}), v_sp_243});
            return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2493});
          }
          case TAG_Cons: {
            heff_take_n(v_args2_2481, 0ULL, 2);
            heff_drop_rec(v_r_240, 2);
            heff_drop(v_a_2480);
            V v_t_2496 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_str1), NTAG(TAG_Nothing)});
            V v_t_2497 = heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2496, heff_dup(v_sp_243)})});
            return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){v_t_2497, v_sp_243})});
          }
          default: return heff_nomatch(v_args2_2481);
          }
        }
        default: return heff_nomatch(v_args_242);
        }
      }
      case TAG_AbandonWord: {
        V v_t_2498 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2499 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2498));
        V v_t_24100 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_24101 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2499, v_t_24100}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_24101});
      }
      case TAG_FixedWord: {
        heff_take_n(v_h11_2457, 0ULL, 1);
        V v_t_24103 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_24104 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24103));
        V v_t_24105 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_24106 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24104, v_t_24105}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_24106});
      }
      default: return heff_nomatch(v_h11_2457);
      }
    }
    case TAG_EApp: {
      V v_ru_24h1_244_24EApp = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      V v_t_24109 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24110 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24109));
      V v_t_24111 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24112 = heff_tag_at_n(v_ru_24h1_244_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24110, v_t_24111}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24112});
    }
    case TAG_EProject: {
      V v_ru_24h1_244_24EProject = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_24114 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24115 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24114));
      V v_t_24116 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24117 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24115, v_t_24116}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EProject, TAG_IsInferable, 1, (V[]){v_t_24117});
    }
    case TAG_ENamed: {
      V v_ru_24h1_244_24ENamed = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      V v_t_24120 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24121 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24120));
      V v_t_24122 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24123 = heff_tag_at_n(v_ru_24h1_244_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24121, v_t_24122}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24123});
    }
    case TAG_EPi: {
      V v_ru_24h1_244_24EPi = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      V v_t_24126 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24127 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24126));
      V v_t_24128 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24129 = heff_tag_at_n(v_ru_24h1_244_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24127, v_t_24128}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24129});
    }
    case TAG_ELam: {
      V v_ru_24h1_244_24ELam = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      V v_t_24132 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24133 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24132));
      V v_t_24134 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24135 = heff_tag_at_n(v_ru_24h1_244_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24133, v_t_24134}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24135});
    }
    case TAG_EAnn: {
      V v_ru_24h1_244_24EAnn = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      V v_t_24138 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24139 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24138));
      V v_t_24140 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24141 = heff_tag_at_n(v_ru_24h1_244_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24139, v_t_24140}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24141});
    }
    case TAG_ESpec: {
      heff_take_n(v_h1_244, 0ULL, 4);
      V v_t_24146 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24147 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24146));
      V v_t_24148 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24149 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24147, v_t_24148}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24149});
    }
    case TAG_ESig: {
      V v_ru_24h1_244_24ESig = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_24151 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24152 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24151));
      V v_t_24153 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24154 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24152, v_t_24153}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ESig, TAG_IsInferable, 1, (V[]){v_t_24154});
    }
    case TAG_ESum: {
      V v_ru_24h1_244_24ESum = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_24156 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24157 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24156));
      V v_t_24158 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24159 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24157, v_t_24158}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ESum, TAG_IsInferable, 1, (V[]){v_t_24159});
    }
    case TAG_EStruct: {
      V v_ru_24h1_244_24EStruct = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_24161 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24162 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24161));
      V v_t_24163 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24164 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24162, v_t_24163}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EStruct, TAG_IsInferable, 1, (V[]){v_t_24164});
    }
    case TAG_EUpdate: {
      V v_ru_24h1_244_24EUpdate = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      V v_t_24167 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24168 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24167));
      V v_t_24169 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24170 = heff_tag_at_n(v_ru_24h1_244_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24168, v_t_24169}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24170});
    }
    case TAG_EMatch: {
      V v_ru_24h1_244_24EMatch = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      V v_t_24173 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24174 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24173));
      V v_t_24175 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24176 = heff_tag_at_n(v_ru_24h1_244_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24174, v_t_24175}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24176});
    }
    case TAG_ELetIn: {
      V v_ru_24h1_244_24ELetIn = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      V v_t_24179 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24180 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24179));
      V v_t_24181 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24182 = heff_tag_at_n(v_ru_24h1_244_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24180, v_t_24181}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24182});
    }
    case TAG_EDo: {
      V v_ru_24h1_244_24EDo = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_24184 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24185 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24184));
      V v_t_24186 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24187 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24185, v_t_24186}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EDo, TAG_IsInferable, 1, (V[]){v_t_24187});
    }
    case TAG_ELocal: {
      V v_ru_24h1_244_24ELocal = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      V v_t_24190 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24191 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24190));
      V v_t_24192 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24193 = heff_tag_at_n(v_ru_24h1_244_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24191, v_t_24192}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24193});
    }
    case TAG_EInvalid: {
      V v_ru_24h1_244_24EInvalid = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_24195 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24196 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24195));
      V v_t_24197 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24198 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24196, v_t_24197}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EInvalid, TAG_IsInferable, 1, (V[]){v_t_24198});
    }
    case TAG_EAssign: {
      heff_take_n(v_h1_244, 0ULL, 3);
      V v_t_24202 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24203 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24202));
      V v_t_24204 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24205 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24203, v_t_24204}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24205});
    }
    case TAG_EWhile: {
      V v_ru_24h1_244_24EWhile = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      V v_t_24208 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24209 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24208));
      V v_t_24210 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24211 = heff_tag_at_n(v_ru_24h1_244_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24209, v_t_24210}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24211});
    }
    case TAG_EFor: {
      heff_take_n(v_h1_244, 0ULL, 3);
      V v_t_24215 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24216 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24215));
      V v_t_24217 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24218 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24216, v_t_24217}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24218});
    }
    case TAG_EIfThen: {
      V v_ru_24h1_244_24EIfThen = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      V v_t_24221 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24222 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24221));
      V v_t_24223 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24224 = heff_tag_at_n(v_ru_24h1_244_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24222, v_t_24223}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24224});
    }
    case TAG_EBreak: {
      V v_t_24225 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24226 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24225));
      V v_t_24227 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24228 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24226, v_t_24227}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24228});
    }
    case TAG_EContinue: {
      V v_t_24229 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24230 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24229));
      V v_t_24231 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24232 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24230, v_t_24231}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24232});
    }
    case TAG_EReturn: {
      V v_ru_24h1_244_24EReturn = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_24234 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24235 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24234));
      V v_t_24236 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24237 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24235, v_t_24236}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24EReturn, TAG_IsInferable, 1, (V[]){v_t_24237});
    }
    case TAG_ENest: {
      V v_ru_24h1_244_24ENest = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_24239 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24240 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24239));
      V v_t_24241 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24242 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24240, v_t_24241}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ENest, TAG_IsInferable, 1, (V[]){v_t_24242});
    }
    case TAG_ELazy: {
      V v_ru_24h1_244_24ELazy = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_24244 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24245 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24244));
      V v_t_24246 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24245, v_t_24246}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ELazy, TAG_IsInferable, 1, (V[]){v_t_24247});
    }
    case TAG_ETuple: {
      V v_ru_24h1_244_24ETuple = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_24249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24250 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24249));
      V v_t_24251 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24252 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24250, v_t_24251}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ETuple, TAG_IsInferable, 1, (V[]){v_t_24252});
    }
    case TAG_ETry: {
      V v_ru_24h1_244_24ETry = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      V v_t_24254 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24255 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24254));
      V v_t_24256 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24257 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24255, v_t_24256}), v_sp_243});
      return heff_tag_at_n(v_ru_24h1_244_24ETry, TAG_IsInferable, 1, (V[]){v_t_24257});
    }
    case TAG_EWith: {
      heff_take_n(v_h1_244, 0ULL, 4);
      V v_t_24262 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24263 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24262));
      V v_t_24264 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_24265 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24263, v_t_24264}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24265});
    }
    default: return heff_nomatch(v_h1_244);
    }
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eappOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epresyntax_2eappOf_lam0(V self, V *args) {
  V v_e_2419 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2419}));
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_IsInferable: {
    V v_i_2421 = heff_field(v_x1_2420, 0);
    V v_ru_24x1_2420_24IsInferable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
    V v_t_2424;
    switch (heff_tag_of(v_i_2421)) {
    case TAG_At: {
      V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
      v_t_2424 = v_s_2423;
      break;
    }
    default: heff_nomatch(v_i_2421);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsInferable, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
  }
  case TAG_IsCheckable: {
    V v_c_2425 = heff_field(v_x1_2420, 0);
    heff_take_n(v_x1_2420, 1ULL, 1);
    return v_c_2425;
  }
  case TAG_IsType: {
    V v_t_2426 = heff_field(v_x1_2420, 0);
    V v_ru_24x1_2420_24IsType = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
    V v_t_2429;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_At: {
      V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
      v_t_2429 = v_s_2428;
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsType, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
  }
  default: return heff_nomatch(v_x1_2420);
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str0, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str1, 10, "bitsConcat");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str2, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str3, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str4, 10, "bitsConcat");
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0, 2, 0};
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1, 2, 0};

HeffT1 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(V v_lit_240, V v_r_241, V v_segs_242, V v_sp_243, V v_x5_244) {
top: ;
  if ((heff_dup(v_x5_244) == NTAG(TAG_True))) {
    V v_t_245 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo), 2, (V[]){v_lit_240, v_r_241}));
    V v_m_2414 = heff_rec_n(2, shape_part__run, (V[]){v_t_245, ((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0_clo)});
    V v_xs_2415 = (g_heff_2esyntax_2epresyntax_2ebinaryParts(v_m_2414, v_segs_242, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2415));
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2416, heff_dup(v_sp_243)));
    V v_args_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2418));
    V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str1)}), heff_dup(v_sp_243)});
    V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2420, v_t_2419}), heff_dup(v_sp_243)});
    V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2421}), heff_dup(v_sp_243)});
    V v_args_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str2)}), heff_dup(v_sp_243)});
    V v_t_2425 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2423));
    V v_f_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2424, v_t_2425}), v_sp_243});
    return ((HeffT1){{v_f_2426}});
  } else {
    V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo), 2, (V[]){v_lit_240, v_r_241}));
    V v_m_2436 = heff_rec_n(2, shape_part__run, (V[]){v_t_2427, ((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1_clo)});
    V v_xs_2437 = (g_heff_2esyntax_2epresyntax_2ebinaryParts(v_m_2436, v_segs_242, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2437));
    V v_t_2439 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2438, heff_dup(v_sp_243)));
    V v_args_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
    V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str4)}), heff_dup(v_sp_243)});
    V v_t_2442 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2440));
    V v_f_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2441, v_t_2442}), v_sp_243});
    return ((HeffT1){{v_f_2443}});
  }
}
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_sp_247 = args[1];
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_246}), heff_dup(v_sp_247)});
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_248}), heff_dup(v_sp_247)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_t_2411 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_247), v_t_2410));
  V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str0)}), heff_dup(v_sp_247)});
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2412, v_t_2411}), heff_dup(v_sp_247)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2413}), v_sp_247});
}
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1(V self, V *args) {
  V v_s_2428 = args[0];
  V v_sp_2429 = args[1];
  V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_2428}), heff_dup(v_sp_2429)});
  V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2430}), heff_dup(v_sp_2429)});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
  V v_t_2433 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2429), v_t_2432));
  V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str3)}), heff_dup(v_sp_2429)});
  V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2434, v_t_2433}), heff_dup(v_sp_2429)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2435}), v_sp_2429});
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_str0, 19, "prelude.codePointOf");
Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V v_v_240, V v_sp_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_240));
  V v_t_2414;
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_c_245 = v_field_244;
      v_t_2414 = v_c_245;
    } else {
      if ((v_tag_243 == ((int64_t)1ULL))) {
        V v_i_246 = v_field_244;
        V v_t_249;
        switch (heff_tag_of(v_i_246)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_i_246, 1));
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_i_246);
        }
        v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_246}), v_t_249});
      } else {
        V v_t_2410 = v_field_244;
        V v_t_2413;
        switch (heff_tag_of(v_t_2410)) {
        case TAG_At: {
          V v_s_2412 = heff_dup(heff_field(v_t_2410, 1));
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
        v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2410}), v_t_2413});
      }
    }
  }
  V v_args_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2415));
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_str0)}), heff_dup(v_sp_241)});
  V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2417, v_t_2416}), heff_dup(v_sp_241)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2418}), v_sp_241});
}
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclEquations: {
      V v_f_243 = heff_field(v_x21_241, 0);
      V v_fsp_244 = heff_field(v_x21_241, 1);
      V v_declared_245 = heff_field(v_x21_241, 2);
      V v_ty_246 = heff_field(v_x21_241, 3);
      V v_eqs_247 = heff_field(v_x21_241, 4);
      V v_ru_24x21_241_24DeclEquations = heff_take_reuse_n(v_x21_241, 31ULL, 5);
      HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_ty_246));
      V v_t_2420;
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_c_2411 = v_field_2410;
          V v_t_2414;
          switch (heff_tag_of(v_c_2411)) {
          case TAG_At: {
            V v_s_2413 = heff_dup(heff_field(v_c_2411, 1));
            v_t_2414 = v_s_2413;
            break;
          }
          default: heff_nomatch(v_c_2411);
          }
          v_t_2420 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2411}), v_t_2414});
        } else {
          if ((v_tag_249 == ((int64_t)1ULL))) {
            V v_i_2415 = v_field_2410;
            V v_t_2418;
            switch (heff_tag_of(v_i_2415)) {
            case TAG_At: {
              V v_s_2417 = heff_dup(heff_field(v_i_2415, 1));
              v_t_2418 = v_s_2417;
              break;
            }
            default: heff_nomatch(v_i_2415);
            }
            v_t_2420 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2415}), v_t_2418});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2419 = v_field_2410;
            v_t_2420 = v_t_2419;
          }
        }
      }
      V v_t_2421 = (g_list_2emap_24s1276400643x126214923(v_eqs_247));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_243, v_fsp_244, v_declared_245, v_t_2420, v_t_2421}), v_sp_242});
    }
    case TAG_DeclDefine: {
      V v_x_2422 = heff_field(v_x21_241, 0);
      V v_xsp_2423 = heff_field(v_x21_241, 1);
      V v_ps_2424 = heff_field(v_x21_241, 2);
      V v_u_2425 = heff_field(v_x21_241, 3);
      V v_body_2426 = heff_field(v_x21_241, 4);
      V v_ru_24x21_241_24DeclDefine = heff_take_reuse_n(v_x21_241, 31ULL, 5);
      V v_t_2427 = (g_list_2emap_24s2051429168x672290949(v_ps_2424));
      HeffT2 v_t_2428 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_u_2425));
      V v_t_2440;
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        if ((v_tag_2429 == ((int64_t)0ULL))) {
          V v_c_2431 = v_field_2430;
          V v_t_2434;
          switch (heff_tag_of(v_c_2431)) {
          case TAG_At: {
            V v_s_2433 = heff_dup(heff_field(v_c_2431, 1));
            v_t_2434 = v_s_2433;
            break;
          }
          default: heff_nomatch(v_c_2431);
          }
          v_t_2440 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2431}), v_t_2434});
        } else {
          if ((v_tag_2429 == ((int64_t)1ULL))) {
            V v_i_2435 = v_field_2430;
            V v_t_2438;
            switch (heff_tag_of(v_i_2435)) {
            case TAG_At: {
              V v_s_2437 = heff_dup(heff_field(v_i_2435, 1));
              v_t_2438 = v_s_2437;
              break;
            }
            default: heff_nomatch(v_i_2435);
            }
            v_t_2440 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2435}), v_t_2438});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2439 = v_field_2430;
            v_t_2440 = v_t_2439;
          }
        }
      }
      HeffT2 v_t_2441 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2426));
      V v_t_2453;
      {
        V v_field_2443 = v_t_2441.f[1];
        int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
        if ((v_tag_2442 == ((int64_t)0ULL))) {
          V v_c_2444 = v_field_2443;
          v_t_2453 = v_c_2444;
        } else {
          if ((v_tag_2442 == ((int64_t)1ULL))) {
            V v_i_2445 = v_field_2443;
            V v_t_2448;
            switch (heff_tag_of(v_i_2445)) {
            case TAG_At: {
              V v_s_2447 = heff_dup(heff_field(v_i_2445, 1));
              v_t_2448 = v_s_2447;
              break;
            }
            default: heff_nomatch(v_i_2445);
            }
            v_t_2453 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2445}), v_t_2448});
          } else {
            V v_t_2449 = v_field_2443;
            V v_t_2452;
            switch (heff_tag_of(v_t_2449)) {
            case TAG_At: {
              V v_s_2451 = heff_dup(heff_field(v_t_2449, 1));
              v_t_2452 = v_s_2451;
              break;
            }
            default: heff_nomatch(v_t_2449);
            }
            v_t_2453 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2449}), v_t_2452});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2422, v_xsp_2423, v_t_2427, v_t_2440, v_t_2453}), v_sp_242});
    }
    case TAG_DeclTheory: {
      V v_x_2454 = heff_field(v_x21_241, 0);
      V v_xsp_2455 = heff_field(v_x21_241, 1);
      V v_ps_2456 = heff_field(v_x21_241, 2);
      V v_body_2457 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24DeclTheory = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_t_2458 = (g_list_2emap_24s2051429168x672290949(v_ps_2456));
      HeffT2 v_t_2459 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2457));
      V v_t_2471;
      {
        V v_field_2461 = v_t_2459.f[1];
        int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
        if ((v_tag_2460 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_2462 = v_field_2461;
          v_t_2471 = v_c_2462;
        } else {
          if ((v_tag_2460 == ((int64_t)1ULL))) {
            V v_i_2463 = v_field_2461;
            V v_t_2466;
            switch (heff_tag_of(v_i_2463)) {
            case TAG_At: {
              V v_s_2465 = heff_dup(heff_field(v_i_2463, 1));
              v_t_2466 = v_s_2465;
              break;
            }
            default: heff_nomatch(v_i_2463);
            }
            v_t_2471 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2463}), v_t_2466});
          } else {
            V v_t_2467 = v_field_2461;
            V v_t_2470;
            switch (heff_tag_of(v_t_2467)) {
            case TAG_At: {
              V v_s_2469 = heff_dup(heff_field(v_t_2467, 1));
              v_t_2470 = v_s_2469;
              break;
            }
            default: heff_nomatch(v_t_2467);
            }
            v_t_2471 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2467}), v_t_2470});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2454, v_xsp_2455, v_t_2458, v_t_2471}), v_sp_242});
    }
    case TAG_DeclPrimitive: {
      V v_x_2472 = heff_field(v_x21_241, 0);
      V v_xsp_2473 = heff_field(v_x21_241, 1);
      V v_t_2474 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24DeclPrimitive = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      HeffT2 v_t_2475 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2474));
      V v_t_2487;
      {
        V v_field_2477 = v_t_2475.f[1];
        int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
        if ((v_tag_2476 == ((int64_t)0ULL))) {
          V v_c_2478 = v_field_2477;
          V v_t_2481;
          switch (heff_tag_of(v_c_2478)) {
          case TAG_At: {
            V v_s_2480 = heff_dup(heff_field(v_c_2478, 1));
            v_t_2481 = v_s_2480;
            break;
          }
          default: heff_nomatch(v_c_2478);
          }
          v_t_2487 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2478}), v_t_2481});
        } else {
          if ((v_tag_2476 == ((int64_t)1ULL))) {
            V v_i_2482 = v_field_2477;
            V v_t_2485;
            switch (heff_tag_of(v_i_2482)) {
            case TAG_At: {
              V v_s_2484 = heff_dup(heff_field(v_i_2482, 1));
              v_t_2485 = v_s_2484;
              break;
            }
            default: heff_nomatch(v_i_2482);
            }
            v_t_2487 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2482}), v_t_2485});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2486 = v_field_2477;
            v_t_2487 = v_t_2486;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2472, v_xsp_2473, v_t_2487}), v_sp_242});
    }
    case TAG_DeclTest: {
      V v_x_2488 = heff_field(v_x21_241, 0);
      V v_xsp_2489 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclTest, 2, (V[]){v_x_2488, v_xsp_2489}), v_sp_242});
    }
    case TAG_DeclWatch: {
      V v_e_2490 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_2491 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_2490));
      V v_t_2492 = (g_heff_2esyntax_2epresyntax_2ewatchOf(v_t_2491));
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_t_2492}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(a[0]);
}