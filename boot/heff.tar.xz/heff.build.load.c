// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Posix 44191
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Windows 49101
#define LBL_absolute 325777132
#define LBL_at 9882
#define LBL_base 9511832
#define LBL_by 9918
#define LBL_col 308218
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_drive 297211300
#define LBL_errors 652506774
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_own 320000
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pkg 320582
#define LBL_place 308106529
#define LBL_renames 1324191545
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_segments 1801007612
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_version 583465758
static uint32_t shape_by__path__version[] = {LBL_by, LBL_path, LBL_version};
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_module__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
static uint32_t shape_path__source__place__module[] = {LBL_path, LBL_source, LBL_place, LBL_module};
static uint32_t shape_path__version__pkg[] = {LBL_path, LBL_version, LBL_pkg};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_clo;
V g_heff_2ebuild_2eload_2ecasesIn(V, V, V, V);
V g_heff_2ebuild_2eload_2ecasesIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecasesIn_clo;
V g_heff_2ebuild_2eload_2ecycleAmong(V, V, V);
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecycleAmong_clo;
V g_heff_2ebuild_2eload_2eemptySt_get(void);
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2efromCwd(V, V);
V g_heff_2ebuild_2eload_2efromCwd_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efromCwd_clo;
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019(V, V);
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291(V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2enamedGo(V, V);
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_clo;
V g_heff_2ebuild_2eload_2eofLibrary(V, V);
V g_heff_2ebuild_2eload_2eofLibrary_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eofLibrary_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(V, V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101(V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_clo;
V g_heff_2ebuild_2eload_2epkgByPath(V, V);
V g_heff_2ebuild_2eload_2epkgByPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgByPath_clo;
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_clo;
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407(V, V);
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688(V, V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738(V);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_clo;
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_clo;
V g_heff_2ebuild_2eload_2esameButCase(V, V);
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameButCase_clo;
V g_heff_2ebuild_2eload_2eshownOf(V, V);
V g_heff_2ebuild_2eload_2eshownOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eshownOf_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2eunder(V, V, V);
V g_heff_2ebuild_2eload_2eunder_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eunder_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_clo;
V g_heff_2ebuild_2eproject_2eisName(V);
V g_heff_2ebuild_2eproject_2eisName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisName_clo;
V g_heff_2ebuild_2eproject_2ereadPackage(V);
V g_heff_2ebuild_2eproject_2ereadPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ereadPackage_clo;
V g_heff_2ebuild_2eproject_2esumGo(V, V);
V g_heff_2ebuild_2eproject_2esumGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2esumGo_clo;
V g_heff_2elsp_2erender_2elineColGo(V, V, V, V);
V g_heff_2elsp_2erender_2elineColGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColGo_clo;
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s230517345x1163337657(V, V);
V g_list_2efoldl_24s230517345x1163337657_entry(V self, V *a);
extern Clo g_list_2efoldl_24s230517345x1163337657_clo;
V g_list_2efoldl_24s9956384x694087549(V, V);
V g_list_2efoldl_24s9956384x694087549_entry(V self, V *a);
extern Clo g_list_2efoldl_24s9956384x694087549_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1462590149x1582455373(V);
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_clo;
V g_list_2emap_24s1900047848x1273517071(V);
V g_list_2emap_24s1900047848x1273517071_entry(V self, V *a);
extern Clo g_list_2emap_24s1900047848x1273517071_clo;
V g_list_2emap_24s201309086x301344224(V);
V g_list_2emap_24s201309086x301344224_entry(V self, V *a);
extern Clo g_list_2emap_24s201309086x301344224_clo;
V g_list_2emap_24s424270175x1918189508(V);
V g_list_2emap_24s424270175x1918189508_entry(V self, V *a);
extern Clo g_list_2emap_24s424270175x1918189508_clo;
V g_list_2emap_24s871082722x1690249882(V);
V g_list_2emap_24s871082722x1690249882_entry(V self, V *a);
extern Clo g_list_2emap_24s871082722x1690249882_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecollapse(V, V);
V g_std_2epath_2ecollapse_entry(V self, V *a);
extern Clo g_std_2epath_2ecollapse_clo;
V g_std_2epath_2eisUnder(V, V, V);
V g_std_2epath_2eisUnder_entry(V self, V *a);
extern Clo g_std_2epath_2eisUnder_clo;
V g_std_2epath_2ejoin_2eonto_240(V, V);
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_2eonto_240_clo;
V g_std_2epath_2elower_2elow_240(V, V);
V g_std_2epath_2elower_2elow_240_entry(V self, V *a);
extern Clo g_std_2epath_2elower_2elow_240_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erelative(V, V, V);
V g_std_2epath_2erelative_entry(V self, V *a);
extern Clo g_std_2epath_2erelative_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
Clo g_heff_2ebuild_2eload_2eunder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eunder_entry, 3, 0};

V g_heff_2ebuild_2eload_2eunder(V v_ps_240, V v_d_241, V v_p_242) {
top: ;
  V v_st_243 = heff_get_n(v_ps_240, 5, 6);
  V v_t_244 = (g_std_2epath_2eparse(v_st_243, v_d_241));
  V v_t_245 = (g_std_2epath_2eparse(v_st_243, v_p_242));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_246, 1)), heff_rfield(v_p_246, 2)));
  V v_t_248 = ({ V rv_2 = v_t_247; V rr_ = heff_rec_reuse_n(v_p_246, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  return ({ V a_0 = v_st_243; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); r_; });
}
V g_heff_2ebuild_2eload_2eunder_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eunder(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2efromCwd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2efromCwd_entry, 2, 0};

V g_heff_2ebuild_2eload_2efromCwd(V v_ps_240, V v_p_241) {
top: ;
  V v_st_242 = heff_take_field(v_ps_240, 5);
  V v_t_243 = (g_std_2epath_2eparse(v_st_242, heff_get_n(v_ps_240, 4, 6)));
  V v_t_244 = (g_std_2epath_2eparse(v_st_242, v_p_241));
  V v_p_245 = (g_std_2epath_2ejoin_2eonto_240(v_t_243, v_t_244));
  V v_t_246 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_245, 1)), heff_rfield(v_p_245, 2)));
  V v_t_247 = ({ V rv_2 = v_t_246; V rr_ = heff_rec_reuse_n(v_p_245, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  return ({ V a_0 = v_st_242; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); r_; });
}
V g_heff_2ebuild_2eload_2efromCwd_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2efromCwd(a[0], a[1]);
}
HEFF_STRA(g_heff_2ebuild_2eload_2emoduleOf_str0, 3, (46, 104, 102));
HEFF_STRA(g_heff_2ebuild_2eload_2emoduleOf_str1, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2emoduleOf_str2, 1, (46));
Clo g_heff_2ebuild_2eload_2emoduleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emoduleOf_entry, 2, 0};

V g_heff_2ebuild_2eload_2emoduleOf(V v_ps_240, V v_path_241) {
top: ;
  V v_d_242 = heff_dup(heff_rfield(v_ps_240, 2));
  V v_t_243 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_d_242)));
  V v_t_244 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_path_241)));
  V v_t_245 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_243, v_t_244));
  V v_t_248;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    V v_t_246 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), v_d_242));
    V v_t_247 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_path_241)));
    v_t_248 = (g_std_2epath_2erelative(heff_rfield(v_ps_240, 5), v_t_246, v_t_247));
    break;
  }
  case TAG_False: {
    heff_drop(v_d_242);
    v_t_248 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_p_2434;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    V v_d_249 = heff_dup(heff_rfield(v_ps_240, 1));
    V v_t_2410 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_d_249)));
    V v_t_2411 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_path_241)));
    V v_t_2412 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_2410, v_t_2411));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      V v_t_2413 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), v_d_249));
      V v_t_2414 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_path_241)));
      V v_t_2415 = (g_std_2epath_2erelative(heff_rfield(v_ps_240, 5), v_t_2413, v_t_2414));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nothing: {
        V v_d_2416 = heff_dup(heff_rfield(v_ps_240, 0));
        V v_t_2417 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_d_2416)));
        V v_t_2418 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_path_241)));
        V v_t_2419 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_2417, v_t_2418));
        switch (heff_tag_of(v_t_2419)) {
        case TAG_True: {
          V v_t_2420 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), v_d_2416));
          V v_t_2421 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_path_241)));
          V v_t_2422 = (g_std_2epath_2erelative(heff_rfield(v_ps_240, 5), v_t_2420, v_t_2421));
          switch (heff_tag_of(v_t_2422)) {
          case TAG_Nothing: {
            v_p_2434 = v_path_241;
            break;
          }
          case TAG_Just: {
            V v_rel_2423 = heff_field(v_t_2422, 0);
            heff_take_n(v_t_2422, 1ULL, 1);
            heff_drop(v_path_241);
            v_p_2434 = v_rel_2423;
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          break;
        }
        case TAG_False: {
          heff_drop(v_d_2416);
          v_p_2434 = v_path_241;
          break;
        }
        default: heff_nomatch(v_t_2419);
        }
        break;
      }
      case TAG_Just: {
        V v_rel_2424 = heff_field(v_t_2415, 0);
        heff_take_n(v_t_2415, 1ULL, 1);
        heff_drop(v_path_241);
        v_p_2434 = v_rel_2424;
        break;
      }
      default: heff_nomatch(v_t_2415);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_d_249);
      V v_d_2425 = heff_dup(heff_rfield(v_ps_240, 0));
      V v_t_2426 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_d_2425)));
      V v_t_2427 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_path_241)));
      V v_t_2428 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_2426, v_t_2427));
      switch (heff_tag_of(v_t_2428)) {
      case TAG_True: {
        V v_t_2429 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), v_d_2425));
        V v_t_2430 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_path_241)));
        V v_t_2431 = (g_std_2epath_2erelative(heff_rfield(v_ps_240, 5), v_t_2429, v_t_2430));
        switch (heff_tag_of(v_t_2431)) {
        case TAG_Nothing: {
          v_p_2434 = v_path_241;
          break;
        }
        case TAG_Just: {
          V v_rel_2432 = heff_field(v_t_2431, 0);
          heff_take_n(v_t_2431, 1ULL, 1);
          heff_drop(v_path_241);
          v_p_2434 = v_rel_2432;
          break;
        }
        default: heff_nomatch(v_t_2431);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_d_2425);
        v_p_2434 = v_path_241;
        break;
      }
      default: heff_nomatch(v_t_2428);
      }
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    break;
  }
  case TAG_Just: {
    V v_rel_2433 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    heff_drop(v_path_241);
    v_p_2434 = v_rel_2433;
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2435 = heff_intSub(heff_strLength(heff_dup(v_p_2434)), MK_INT(3LL));
  V v_t_2436 = heff_strSlice(heff_dup(v_p_2434), v_t_2435, heff_strLength(heff_dup(v_p_2434)));
  V v_s_2439;
  if (heff_strEq_c(v_t_2436, ((V)&g_heff_2ebuild_2eload_2emoduleOf_str0))) {
    V v_t_2438 = heff_intSub(heff_strLength(heff_dup(v_p_2434)), MK_INT(3LL));
    v_s_2439 = heff_strSlice(v_p_2434, MK_INT(0LL), v_t_2438);
  } else {
    v_s_2439 = v_p_2434;
  }
  V v_p_2440 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_s_2439; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2441 = ({ V a_0 = heff_take_field(v_p_2440, 1); V b_1 = heff_get_n(v_p_2440, 2, 3); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2eload_2emoduleOf_str1);
  }
  case TAG_Cons: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_xs_2443 = heff_field(v_x2_2441, 1);
    heff_take_n(v_x2_2441, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str2); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emoduleOf(a[0], a[1]);
}
HEFF_STRA(g_heff_2ebuild_2eload_2eproblemMsg_str0, 1, (58));
HEFF_STRA(g_heff_2ebuild_2eload_2eproblemMsg_str1, 1, (58));
HEFF_STRA(g_heff_2ebuild_2eload_2eproblemMsg_str2, 2, (58, 32));
Clo g_heff_2ebuild_2eload_2eproblemMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eproblemMsg_entry, 3, 0};

V g_heff_2ebuild_2eload_2eproblemMsg(V v_path_240, V v_src_241, V v_p_242) {
top: ;
  V v_t_243 = (g_heff_2elsp_2erender_2elineColGo(heff_dup(v_src_241), heff_dup(heff_rfield(v_p_242, 0)), MK_INT(0LL), MK_INT(0LL)));
  V v_t_244 = heff_intAdd(heff_get_n(v_t_243, 0, 2), MK_INT(1LL));
  V v_t_245 = (g_heff_2elsp_2erender_2elineColGo(v_src_241, heff_take_field(v_p_242, 0), MK_INT(0LL), MK_INT(0LL)));
  V v_t_246 = heff_intAdd(heff_get_n(v_t_245, 1, 2), MK_INT(1LL));
  return heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str0), heff_strAppend(heff_intShow(v_t_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str1), heff_strAppend(heff_intShow(v_t_246), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str2), heff_get_n(v_p_242, 1, 2)))))));
}
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eproblemMsg(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2epkgByPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgByPath_entry, 2, 0};

V g_heff_2ebuild_2eload_2epkgByPath(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_k_242, 0)), heff_dup(v_p_241))) {
      heff_drop(v_p_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_242)});
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eload_2epkgByPath_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eload_2epkgByPath(a[0], a[1]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedDir_str0, 1, (47));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedDir_str1, 1, (92));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedDir_str2, 1, (64));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedDir_str3, 1, (47));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedDir_str4, 0, (0));
Clo g_heff_2ebuild_2eload_2ecachedDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedDir_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecachedDir(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_sep_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Posix: {
    v_sep_244 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str0);
    break;
  }
  case TAG_Windows: {
    v_sep_244 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str1);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedDir_str2), v_v_242));
  V v_x2_246 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2ecachedDir_str3), v_t_245, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_sep_244);
    v_t_249 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = v_sep_244; V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  HEFF_LAST return g_heff_2ebuild_2eload_2eunder(heff_dup(v_ps_240), heff_get_n(v_ps_240, 3, 6), v_t_249);
}
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedDir(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2etakeUntil_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_entry, 2, 0};

V g_heff_2ebuild_2eload_2etakeUntil(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      heff_drop(v_rest_243);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, NTAG(TAG_Nil)});
    } else {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, (g_heff_2ebuild_2eload_2etakeUntil(v_x_240, v_rest_243))});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2etakeUntil(a[0], a[1]);
}
Clo g_heff_2ebuild_2eload_2ecycleAmong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecycleAmong_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecycleAmong(V v_pkgs_240, V v_stack_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_stack_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_path_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_path_243)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_stack_241));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_rest_244);
      V v_xs_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_path_243), (g_heff_2ebuild_2eload_2etakeUntil(v_path_243, v_stack_241))});
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_247));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
    }
    case TAG_False: {
      V v_t_249 = (g_heff_2ebuild_2eload_2epkgByPath(v_pkgs_240, heff_dup(v_path_243)));
      V v_t_2411;
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        v_t_2411 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_k_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        v_t_2411 = (g_list_2emap_24s1173914895x100384474(heff_get_n(v_k_2410, 6, 7)));
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      V v_x1_2412 = (g_heff_2ebuild_2eload_2ecycleAmong(v_pkgs_240, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, heff_dup(v_stack_241)}), v_t_2411));
      V v_x2_2413 = (g_heff_2ebuild_2eload_2ecycleAmong(v_pkgs_240, v_stack_241, v_rest_244));
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_Nothing: {
        return v_x2_2413;
      }
      case TAG_Just: {
        V v_x_2414 = heff_field(v_x1_2412, 0);
        V v_ru_24x1_2412_24Just = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
        heff_drop(v_x2_2413);
        return heff_tag_at_n(v_ru_24x1_2412_24Just, TAG_Just, 1, (V[]){v_x_2414});
      }
      default: return heff_nomatch(v_x1_2412);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eload_2ecycleAmong(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2ebuild_2eload_2efreeName_str0, 1, (95));
HEFF_STRA(g_heff_2ebuild_2eload_2efreeName_str1, 1, (95));
Clo g_heff_2ebuild_2eload_2efreeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2efreeName_entry, 3, 0};

V g_heff_2ebuild_2eload_2efreeName(V v_taken_240, V v_x_241, V v_n_242) {
top: ;
  V v_x_244;
  if (heff_intLt_c(heff_dup(v_n_242), MK_INT(2LL))) {
    v_x_244 = heff_dup(v_x_241);
  } else {
    v_x_244 = heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2ebuild_2eload_2efreeName_str0), heff_intShow(heff_dup(v_n_242))));
  }
  V v_t_245 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){v_x_244}));
  V v_x1_246 = (g_list_2eany(v_t_245, v_taken_240));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_True: {
    V t_0 = v_taken_240;
    V t_1 = v_x_241;
    V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
    v_taken_240 = t_0;
    v_x_241 = t_1;
    v_n_242 = t_2;
    goto top;
  }
  case TAG_False: {
    if (heff_intLt_c(heff_dup(v_n_242), MK_INT(2LL))) {
      heff_drop(v_n_242);
      return v_x_241;
    } else {
      return heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2ebuild_2eload_2efreeName_str1), heff_intShow(v_n_242)));
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eload_2efreeName(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2ebuild_2eload_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_entry, 2, 0};

V g_heff_2ebuild_2eload_2enamedGo(V v_taken_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_242, 3)), MK_INT(1LL)));
    V v_t_245 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_take_field(v_k_242, 0), heff_take_field(v_k_242, 1), heff_take_field(v_k_242, 2), heff_dup(heff_rfield(v_k_242, 3)), v_t_244, heff_take_field(v_k_242, 5), heff_take_field(v_k_242, 6)});
    V v_t_246 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_get_n(v_k_242, 3, 7), MK_INT(1LL)));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_heff_2ebuild_2eload_2enamedGo(heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_taken_240}), v_rest_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo(a[0], a[1]);
}
HEFF_STRA(g_heff_2ebuild_2eload_2epkgOfGo_str0, 1, (46));
Clo g_heff_2ebuild_2eload_2epkgOfGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOfGo_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOfGo(V v_ps_240, V v_x2_241, V v_project_242, V v_from_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_from_243);
    return v_project_242;
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_d_246 = heff_dup(heff_rfield(v_k_244, 1));
    if (heff_strEq_c(heff_dup(v_d_246), ((V)&g_heff_2ebuild_2eload_2epkgOfGo_str0))) {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_project_242);
      heff_drop(v_from_243);
      heff_drop(v_d_246);
      return heff_dup(v_k_244);
    } else {
      V v_t_248 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), v_d_246));
      V v_t_249 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_from_243)));
      V v_t_2410 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_248, v_t_249));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_project_242);
        heff_drop(v_from_243);
        return heff_dup(v_k_244);
      }
      case TAG_False: {
        V t_0 = v_ps_240;
        V t_1 = v_rest_245;
        V t_2 = v_project_242;
        V t_3 = v_from_243;
        v_ps_240 = t_0;
        v_x2_241 = t_1;
        v_project_242 = t_2;
        v_from_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eload_2epkgOfGo(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2ebuild_2eload_2erequiredPlace_str0, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2erequiredPlace_str1, 3, (46, 104, 102));
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2erequiredPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erequiredPlace_entry, 5, 0};

V g_heff_2ebuild_2eload_2erequiredPlace(V v_ps_240, V v_pkgs_241, V v_k_242, V v_h_243, V v_rest_244) {
top: ;
  V v_it_249 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2eload_2erequiredPlace_lam0, 1, 1, (V[]){v_h_243}), heff_get_n(v_k_242, 6, 7)));
  switch (heff_tag_of(v_it_249)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_rest_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_it1_2410 = heff_field(v_it_249, 0);
    V v_ru_24it_249_24Cons = heff_take_reuse_n(v_it_249, 1ULL, 2);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_MkPair: {
      V v_p_2413 = heff_field(v_it1_2410, 1);
      V v_ru_24it1_2410_24MkPair = heff_take_reuse_n(v_it1_2410, 2ULL, 2);
      V v_t_2414 = (g_heff_2ebuild_2eload_2epkgByPath(v_pkgs_241, v_p_2413));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        heff_drop(v_ps_240);
        heff_drop(v_rest_244);
        heff_drop_cell(v_ru_24it_249_24Cons, 2);
        heff_drop_cell(v_ru_24it1_2410_24MkPair, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_Just: {
        V v_q_2415 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 1);
        V v_base_2416 = heff_take_field(v_q_2415, 2);
        V v_t_2417 = heff_strAppend(heff_take_field(v_q_2415, 3), heff_dup(v_rest_244));
        V v_xs_2418 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2erequiredPlace_str0), v_t_2417, MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
        V v_parts_2423;
        switch (heff_tag_of(v_t_2419)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24it_249_24Cons, 2);
          v_parts_2423 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2420 = heff_field(v_t_2419, 0);
          V v_before_2421 = heff_field(v_t_2419, 1);
          heff_take_n(v_t_2419, 3ULL, 2);
          V v_t_2422 = heff_tag_at_n(v_ru_24it_249_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2420, ((V)&g_heff_2ebuild_2eload_2erequiredPlace_str1)), v_before_2421});
          v_parts_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2422));
          break;
        }
        default: heff_nomatch(v_t_2419);
        }
        V v_t_2424 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2eload_2eunder_clo), 1, (V[]){v_ps_240}));
        V v_t_2425 = (g_list_2efoldl(v_t_2424, heff_dup(v_base_2416), v_parts_2423));
        V v_t_2426 = heff_strAppend(heff_get_n(v_q_2415, 4, 7), v_rest_244);
        return heff_tag_at_n(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2425, v_base_2416, v_parts_2423, v_t_2426}), NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  default: return heff_nomatch(v_it_249);
  }
}
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eload_2erequiredPlace(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_h_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248;
  switch (heff_tag_of(v_x_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 2);
    v_t_248 = v_x_246;
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  return heff_strEq(v_t_248, v_h_243);
}
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str0, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str1, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str2, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str3, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str4, 3, (46, 104, 102));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str5, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str6, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str7, 3, (46, 104, 102));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str8, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str9, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str10, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str11, 3, (46, 104, 102));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str12, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str13, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str14, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str15, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str16, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str17, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str18, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str19, 3, (46, 104, 102));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str20, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str21, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str22, 1, (46));
HEFF_STRA(g_heff_2ebuild_2eload_2eplacesOf_str23, 3, (46, 104, 102));
Clo g_heff_2ebuild_2eload_2eplacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eplacesOf_entry, 4, 0};

V g_heff_2ebuild_2eload_2eplacesOf(V v_ps_240, V v_pkgs_241, V v_from_242, V v_w_243) {
top: ;
  V v_d_244 = heff_dup(heff_rfield(v_ps_240, 2));
  V v_t_2411;
  if (heff_strEq_c(heff_dup(v_d_244), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str0))) {
    heff_drop(v_d_244);
    if (heff_strEq_c(heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str1))) {
      v_t_2411 = NTAG(TAG_False);
    } else {
      v_t_2411 = NTAG(TAG_True);
    }
  } else {
    V v_t_247 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), v_d_244));
    V v_t_248 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_from_242)));
    V v_t_249 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_247, v_t_248));
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      if (heff_strEq_c(heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str2))) {
        v_t_2411 = NTAG(TAG_False);
      } else {
        v_t_2411 = NTAG(TAG_True);
      }
      break;
    }
    case TAG_False: {
      v_t_2411 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
  }
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    V v_base_2412 = heff_dup(heff_rfield(v_ps_240, 2));
    V v_xs_2413 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str3), heff_dup(v_w_243), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2413));
    V v_parts_2418;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      v_parts_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_last_2415 = heff_field(v_t_2414, 0);
      V v_before_2416 = heff_field(v_t_2414, 1);
      V v_ru_24t_2414_24Cons = heff_take_reuse_n(v_t_2414, 3ULL, 2);
      V v_t_2417 = heff_tag_at_n(v_ru_24t_2414_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2415, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str4)), v_before_2416});
      v_parts_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2417));
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2419 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2eload_2eunder_clo), 1, (V[]){v_ps_240}));
    V v_t_2420 = (g_list_2efoldl(v_t_2419, heff_dup(v_base_2412), v_parts_2418));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2420, v_base_2412, v_parts_2418, v_w_243}), NTAG(TAG_Nil)});
  }
  case TAG_False: {
    switch (heff_tag_of(v_pkgs_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_from_242);
      heff_drop(v_w_243);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_project_2421 = heff_dup(heff_field(v_pkgs_241, 0));
      V v_deps_2422 = heff_dup(heff_field(v_pkgs_241, 1));
      V v_k_2423 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_deps_2422; V a_2 = v_project_2421; V a_3 = heff_dup(v_from_242); V r_ = (g_heff_2ebuild_2eload_2epkgOfGo(a_0, a_1, a_2, a_3)); heff_drop(v_deps_2422); r_; });
      V v_t_2459;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2423, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str5))) {
        V v_base_2425 = heff_dup(heff_rfield(v_k_2423, 2));
        V v_xs_2426 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str6), heff_dup(v_w_243), MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2426));
        V v_parts_2431;
        switch (heff_tag_of(v_t_2427)) {
        case TAG_Nil: {
          v_parts_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2428 = heff_field(v_t_2427, 0);
          V v_before_2429 = heff_field(v_t_2427, 1);
          V v_ru_24t_2427_24Cons = heff_take_reuse_n(v_t_2427, 3ULL, 2);
          V v_t_2430 = heff_tag_at_n(v_ru_24t_2427_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2428, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str7)), v_before_2429});
          v_parts_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2430));
          break;
        }
        default: heff_nomatch(v_t_2427);
        }
        V v_t_2432 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2eload_2eunder_clo), 1, (V[]){heff_dup(v_ps_240)}));
        V v_t_2433 = (g_list_2efoldl(v_t_2432, heff_dup(v_base_2425), v_parts_2431));
        v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2433, v_base_2425, v_parts_2431, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      } else {
        V v_t_2434 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str8), heff_dup(v_w_243), MK_INT(0LL)));
        V v_x1_2437;
        switch (heff_tag_of(v_t_2434)) {
        case TAG_Nothing: {
          v_x1_2437 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_w_243), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str9)});
          break;
        }
        case TAG_Just: {
          V v_i_2435 = heff_field(v_t_2434, 0);
          heff_take_n(v_t_2434, 1ULL, 1);
          V v_t_2436 = heff_strSlice(heff_dup(v_w_243), heff_dup(v_i_2435), heff_strLength(heff_dup(v_w_243)));
          v_x1_2437 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strSlice(heff_dup(v_w_243), MK_INT(0LL), v_i_2435), v_t_2436});
          break;
        }
        default: heff_nomatch(v_t_2434);
        }
        V v_t_2440;
        switch (heff_tag_of(v_x1_2437)) {
        case TAG_MkPair: {
          V v_x_2438 = heff_field(v_x1_2437, 0);
          heff_take_n(v_x1_2437, 1ULL, 2);
          v_t_2440 = v_x_2438;
          break;
        }
        default: heff_nomatch(v_x1_2437);
        }
        if (heff_strEq_c(v_t_2440, heff_dup(heff_rfield(v_k_2423, 3)))) {
          V v_base_2442 = heff_dup(heff_rfield(v_k_2423, 2));
          V v_xs_2443 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str10), heff_dup(v_w_243), MK_INT(0LL), NTAG(TAG_Nil)));
          V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2443));
          V v_parts_2448;
          switch (heff_tag_of(v_t_2444)) {
          case TAG_Nil: {
            v_parts_2448 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2445 = heff_field(v_t_2444, 0);
            V v_before_2446 = heff_field(v_t_2444, 1);
            V v_ru_24t_2444_24Cons = heff_take_reuse_n(v_t_2444, 3ULL, 2);
            V v_t_2447 = heff_tag_at_n(v_ru_24t_2444_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2445, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str11)), v_before_2446});
            v_parts_2448 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2447));
            break;
          }
          default: heff_nomatch(v_t_2444);
          }
          V v_t_2449 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str12), heff_dup(v_w_243), MK_INT(0LL)));
          V v_x1_2452;
          switch (heff_tag_of(v_t_2449)) {
          case TAG_Nothing: {
            v_x1_2452 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_w_243), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str13)});
            break;
          }
          case TAG_Just: {
            V v_i_2450 = heff_field(v_t_2449, 0);
            heff_take_n(v_t_2449, 1ULL, 1);
            V v_t_2451 = heff_strSlice(heff_dup(v_w_243), heff_dup(v_i_2450), heff_strLength(heff_dup(v_w_243)));
            v_x1_2452 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strSlice(heff_dup(v_w_243), MK_INT(0LL), v_i_2450), v_t_2451});
            break;
          }
          default: heff_nomatch(v_t_2449);
          }
          V v_t_2455;
          switch (heff_tag_of(v_x1_2452)) {
          case TAG_MkPair: {
            V v_y_2454 = heff_field(v_x1_2452, 1);
            heff_take_n(v_x1_2452, 2ULL, 2);
            v_t_2455 = v_y_2454;
            break;
          }
          default: heff_nomatch(v_x1_2452);
          }
          V v_m_2456 = heff_strAppend(heff_dup(heff_rfield(v_k_2423, 4)), v_t_2455);
          V v_t_2457 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2eload_2eunder_clo), 1, (V[]){heff_dup(v_ps_240)}));
          V v_t_2458 = (g_list_2efoldl(v_t_2457, heff_dup(v_base_2442), v_parts_2448));
          v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2458, v_base_2442, v_parts_2448, v_m_2456}), NTAG(TAG_Nil)});
        } else {
          v_t_2459 = NTAG(TAG_Nil);
        }
      }
      V v_t_2460 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str14), heff_dup(v_w_243), MK_INT(0LL)));
      V v_x1_2463;
      switch (heff_tag_of(v_t_2460)) {
      case TAG_Nothing: {
        v_x1_2463 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_w_243), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str15)});
        break;
      }
      case TAG_Just: {
        V v_i_2461 = heff_field(v_t_2460, 0);
        heff_take_n(v_t_2460, 1ULL, 1);
        V v_t_2462 = heff_strSlice(heff_dup(v_w_243), heff_dup(v_i_2461), heff_strLength(heff_dup(v_w_243)));
        v_x1_2463 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strSlice(heff_dup(v_w_243), MK_INT(0LL), v_i_2461), v_t_2462});
        break;
      }
      default: heff_nomatch(v_t_2460);
      }
      V v_t_2466;
      switch (heff_tag_of(v_x1_2463)) {
      case TAG_MkPair: {
        V v_x_2464 = heff_field(v_x1_2463, 0);
        heff_take_n(v_x1_2463, 1ULL, 2);
        v_t_2466 = v_x_2464;
        break;
      }
      default: heff_nomatch(v_x1_2463);
      }
      V v_t_2467 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str16), heff_dup(v_w_243), MK_INT(0LL)));
      V v_x1_2470;
      switch (heff_tag_of(v_t_2467)) {
      case TAG_Nothing: {
        v_x1_2470 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_w_243), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str17)});
        break;
      }
      case TAG_Just: {
        V v_i_2468 = heff_field(v_t_2467, 0);
        heff_take_n(v_t_2467, 1ULL, 1);
        V v_t_2469 = heff_strSlice(heff_dup(v_w_243), heff_dup(v_i_2468), heff_strLength(heff_dup(v_w_243)));
        v_x1_2470 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strSlice(heff_dup(v_w_243), MK_INT(0LL), v_i_2468), v_t_2469});
        break;
      }
      default: heff_nomatch(v_t_2467);
      }
      V v_t_2473;
      switch (heff_tag_of(v_x1_2470)) {
      case TAG_MkPair: {
        V v_y_2472 = heff_field(v_x1_2470, 1);
        heff_take_n(v_x1_2470, 2ULL, 2);
        v_t_2473 = v_y_2472;
        break;
      }
      default: heff_nomatch(v_x1_2470);
      }
      V v_t_2474 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_pkgs_241; V a_2 = heff_dup(v_k_2423); V a_3 = v_t_2466; V a_4 = v_t_2473; V r_ = (g_heff_2ebuild_2eload_2erequiredPlace(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_pkgs_241, 2); r_; });
      V v_base_2475 = heff_dup(heff_rfield(v_ps_240, 2));
      V v_xs_2476 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str18), heff_dup(v_w_243), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2477 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2476));
      V v_parts_2481;
      switch (heff_tag_of(v_t_2477)) {
      case TAG_Nil: {
        v_parts_2481 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_last_2478 = heff_field(v_t_2477, 0);
        V v_before_2479 = heff_field(v_t_2477, 1);
        V v_ru_24t_2477_24Cons = heff_take_reuse_n(v_t_2477, 3ULL, 2);
        V v_t_2480 = heff_tag_at_n(v_ru_24t_2477_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2478, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str19)), v_before_2479});
        v_parts_2481 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2480));
        break;
      }
      default: heff_nomatch(v_t_2477);
      }
      V v_t_2482 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2eload_2eunder_clo), 1, (V[]){heff_dup(v_ps_240)}));
      V v_t_2483 = (g_list_2efoldl(v_t_2482, heff_dup(v_base_2475), v_parts_2481));
      V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2483, v_base_2475, v_parts_2481, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      V v_t_2491;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2423, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str20))) {
        V v_d_2486 = heff_dup(heff_rfield(v_k_2423, 2));
        V v_x1_2490;
        if (heff_strEq_c(heff_dup(v_d_2486), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str21))) {
          heff_drop(v_from_242);
          heff_drop(v_d_2486);
          v_x1_2490 = NTAG(TAG_True);
        } else {
          V v_t_2488 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), v_d_2486));
          V v_t_2489 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), v_from_242));
          v_x1_2490 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_2488, v_t_2489));
        }
        switch (heff_tag_of(v_x1_2490)) {
        case TAG_True: {
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_t_2491 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x1_2490);
        }
      } else {
        heff_drop(v_from_242);
        v_t_2491 = NTAG(TAG_False);
      }
      V v_t_24101;
      switch (heff_tag_of(v_t_2491)) {
      case TAG_True: {
        V v_base_2492 = heff_get_n(v_k_2423, 1, 7);
        V v_xs_2493 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str22), heff_dup(v_w_243), MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2494 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2493));
        V v_parts_2498;
        switch (heff_tag_of(v_t_2494)) {
        case TAG_Nil: {
          v_parts_2498 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2495 = heff_field(v_t_2494, 0);
          V v_before_2496 = heff_field(v_t_2494, 1);
          V v_ru_24t_2494_24Cons = heff_take_reuse_n(v_t_2494, 3ULL, 2);
          V v_t_2497 = heff_tag_at_n(v_ru_24t_2494_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2495, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str23)), v_before_2496});
          v_parts_2498 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2497));
          break;
        }
        default: heff_nomatch(v_t_2494);
        }
        V v_t_2499 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2eload_2eunder_clo), 1, (V[]){v_ps_240}));
        V v_t_24100 = (g_list_2efoldl(v_t_2499, heff_dup(v_base_2492), v_parts_2498));
        v_t_24101 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_24100, v_base_2492, v_parts_2498, v_w_243}), NTAG(TAG_Nil)});
        break;
      }
      case TAG_False: {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_w_243);
        heff_drop_rec(v_k_2423, 7);
        v_t_24101 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_t_2491);
      }
      V v_t_24102 = (g_prelude_2e_2b_2b(v_t_2484, v_t_24101));
      V v_t_24103 = (g_prelude_2e_2b_2b(v_t_2474, v_t_24102));
      return (g_prelude_2e_2b_2b(v_t_2459, v_t_24103));
    }
    default: return heff_nomatch(v_pkgs_241);
    }
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eplacesOf(a[0], a[1], a[2], a[3]);
}
HEFF_STRA(g_heff_2ebuild_2eload_2esameButCase_str0, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2esameButCase_str1, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2esameButCase_str2, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2esameButCase_str3, 0, (0));
Clo g_heff_2ebuild_2eload_2esameButCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2esameButCase_entry, 2, 0};

V g_heff_2ebuild_2eload_2esameButCase(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = heff_tr(heff_apply(((V)&g_std_2epath_2elower_2elow_240_clo), 1, (V[]){heff_dup(v_a_240)}));
  V v_t_243 = (g_list_2erange(MK_INT(0LL), heff_strLength(v_a_240)));
  V v_x2_244 = (g_list_2emap(v_t_242, v_t_243));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_tr(heff_apply(((V)&g_std_2epath_2elower_2elow_240_clo), 1, (V[]){heff_dup(v_b_241)}));
  V v_t_249 = (g_list_2erange(MK_INT(0LL), heff_strLength(v_b_241)));
  V v_x2_2410 = (g_list_2emap(v_t_248, v_t_249));
  V v_t_2413;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    v_t_2413 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take_n(v_x2_2410, 3ULL, 2);
    v_t_2413 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str3); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  return heff_strEq(v_t_247, v_t_2413);
}
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2esameButCase(a[0], a[1]);
}
HEFF_STRA(g_heff_2ebuild_2eload_2ecasesIn_str0, 10, (32, 105, 115, 32, 110, 97, 109, 101, 100, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2ecasesIn_str1, 59, (32, 111, 110, 32, 116, 104, 101, 32, 100, 105, 115, 107, 58, 32, 97, 32, 102, 105, 108, 101, 32, 115, 121, 115, 116, 101, 109, 32, 116, 104, 97, 116, 32, 116, 101, 108, 108, 115, 32, 99, 97, 115, 101, 32, 97, 112, 97, 114, 116, 32, 102, 105, 110, 100, 115, 32, 110, 111, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2ecasesIn_str2, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2ecasesIn_str3, 2, (44, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2ecasesIn_str4, 7, (32, 104, 111, 108, 100, 115, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2ecasesIn_str5, 74, (58, 32, 110, 97, 109, 101, 115, 32, 116, 104, 97, 116, 32, 100, 105, 102, 102, 101, 114, 32, 111, 110, 108, 121, 32, 105, 110, 32, 99, 97, 115, 101, 32, 97, 114, 101, 32, 111, 110, 101, 32, 102, 105, 108, 101, 32, 119, 104, 101, 114, 101, 32, 99, 97, 115, 101, 32, 105, 115, 32, 110, 111, 116, 32, 116, 111, 108, 100, 32, 97, 112, 97, 114, 116));
Clo g_heff_2ebuild_2eload_2ecasesIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecasesIn_entry, 4, 0};

V g_heff_2ebuild_2eload_2ecasesIn(V v_ps_240, V v_d_241, V v_x_242, V v_ns_243) {
top: ;
  switch (heff_tag_of(v_ns_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_n_244 = heff_field(v_ns_243, 0);
    V v_ns2_245 = heff_field(v_ns_243, 1);
    switch (heff_tag_of(v_ns2_245)) {
    case TAG_Nil: {
      if (heff_strEq_c(heff_dup(v_n_244), heff_dup(v_x_242))) {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_d_241);
        heff_drop(v_x_242);
        return NTAG(TAG_Nothing);
      } else {
        V v_st_247 = heff_get_n(v_ps_240, 5, 6);
        V v_t_248 = (g_std_2epath_2eparse(v_st_247, v_d_241));
        V v_t_249 = (g_std_2epath_2eparse(v_st_247, heff_dup(v_x_242)));
        V v_p_2410 = (g_std_2epath_2ejoin_2eonto_240(v_t_248, v_t_249));
        V v_t_2411 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2410, 1)), heff_rfield(v_p_2410, 2)));
        V v_t_2412 = ({ V rv_2 = v_t_2411; V rr_ = heff_rec_reuse_n(v_p_2410, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2413 = ({ V a_0 = v_st_247; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); r_; });
        V v_t_2414 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_str0), heff_strAppend(heff_dup(v_n_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_str1), v_x_242))));
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
      }
    }
    case TAG_Cons: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_x_242);
      V v_t_2419;
      switch (heff_tag_of(v_ns_243)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2ebuild_2eload_2ecasesIn_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_ns_243, 0);
        V v_xs_2418 = heff_field(v_ns_243, 1);
        v_t_2419 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2eload_2ecasesIn_str3), heff_dup(v_x_2417), v_xs_2418));
        break;
      }
      default: heff_nomatch(v_ns_243);
      }
      V v_t_2420 = heff_strAppend(v_d_241, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_str4), heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2eload_2ecasesIn_str5))));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
    }
    default: return heff_nomatch(v_ns2_245);
    }
  }
  default: return heff_nomatch(v_ns_243);
  }
}
V g_heff_2ebuild_2eload_2ecasesIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eload_2ecasesIn(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}

static V g_heff_2ebuild_2eload_2eemptySt_val;
static int g_heff_2ebuild_2eload_2eemptySt_st;
static V g_heff_2ebuild_2eload_2eemptySt_init(void) {
  return heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2eload_2eemptySt_get(void) {
  if (g_heff_2ebuild_2eload_2eemptySt_st == 2) return g_heff_2ebuild_2eload_2eemptySt_val;
  if (g_heff_2ebuild_2eload_2eemptySt_st == 1) heff_fail("defined by itself");
  g_heff_2ebuild_2eload_2eemptySt_st = 1;
  g_heff_2ebuild_2eload_2eemptySt_val = heff_tr(g_heff_2ebuild_2eload_2eemptySt_init());
  g_heff_2ebuild_2eload_2eemptySt_st = 2;
  return g_heff_2ebuild_2eload_2eemptySt_val;
}
HEFF_STRA(g_heff_2ebuild_2eload_2eshownOf_str0, 3, (108, 105, 98));
Clo g_heff_2ebuild_2eload_2eshownOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eshownOf_entry, 2, 0};

V g_heff_2ebuild_2eload_2eshownOf(V v_ps_240, V v_path_241) {
top: ;
  V v_d_242 = heff_dup(heff_rfield(v_ps_240, 2));
  V v_t_243 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_d_242)));
  V v_t_244 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_path_241)));
  V v_t_245 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_243, v_t_244));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    V v_t_246 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), v_d_242));
    V v_t_247 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_path_241)));
    V v_t_248 = (g_std_2epath_2erelative(heff_rfield(v_ps_240, 5), v_t_246, v_t_247));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop_rec(v_ps_240, 6);
      return v_path_241;
    }
    case TAG_Just: {
      V v_rel_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      heff_drop(v_path_241);
      V v_st_2410 = heff_get_n(v_ps_240, 5, 6);
      V v_t_2411 = (g_std_2epath_2eparse(v_st_2410, ((V)&g_heff_2ebuild_2eload_2eshownOf_str0)));
      V v_t_2412 = (g_std_2epath_2eparse(v_st_2410, v_rel_249));
      V v_p_2413 = (g_std_2epath_2ejoin_2eonto_240(v_t_2411, v_t_2412));
      V v_t_2414 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2413, 1)), heff_rfield(v_p_2413, 2)));
      V v_t_2415 = ({ V rv_2 = v_t_2414; V rr_ = heff_rec_reuse_n(v_p_2413, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
      return ({ V a_0 = v_st_2410; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); r_; });
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_False: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_242);
    return v_path_241;
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ebuild_2eload_2eshownOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eshownOf(a[0], a[1]);
}
Clo g_heff_2ebuild_2eload_2eofLibrary_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eofLibrary_entry, 2, 0};

V g_heff_2ebuild_2eload_2eofLibrary(V v_ps_240, V v_path_241) {
top: ;
  V v_d_242 = heff_dup(heff_rfield(v_ps_240, 2));
  V v_t_243 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_d_242)));
  V v_t_244 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_path_241)));
  V v_t_245 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_243, v_t_244));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    V v_t_246 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), v_d_242));
    V v_t_247 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), v_path_241));
    V v_t_248 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_t_246; V a_2 = v_t_247; V r_ = (g_std_2epath_2erelative(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_t_248, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_False: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_path_241);
    heff_drop(v_d_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ebuild_2eload_2eofLibrary_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eofLibrary(a[0], a[1]);
}
Clo g_heff_2ebuild_2eload_2epushDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epushDone_entry, 7, 0};

V g_heff_2ebuild_2eload_2epushDone(V v_st_240, V v_ps_241, V v_m_242, V v_path_243, V v_src_244, V v_implicit_245, V v_renames_246) {
top: ;
  V v_t_247 = (g_heff_2ebuild_2eload_2eshownOf(heff_dup(v_ps_241), heff_dup(v_path_243)));
  V v_t_248 = (g_heff_2ebuild_2eload_2eofLibrary(v_ps_241, heff_dup(v_path_243)));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(7, shape_module__path__shown__source__renames__implicit__library, (V[]){heff_dup(v_m_242), v_path_243, v_t_247, v_src_244, v_renames_246, v_implicit_245, v_t_248}), NTAG(TAG_Nil)});
  V v_t_2410 = (g_prelude_2e_2b_2b(heff_take_field(v_st_240, 0), v_t_249));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_242, heff_take_field(v_st_240, 1)});
  return ({ V rv_0 = v_t_2410; V rv_1 = v_t_2411; V rr_ = heff_rec_reuse_n(v_st_240, 4ULL, 3, shape_done__doneMods__errors); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epushDone(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ebuild_2eload_2eloadDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadDone_entry, 4, 0};

V g_heff_2ebuild_2eload_2eloadDone(V v_ps_240, V v_pk_241, V v_pkgs_242, V v_st_243) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_247 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x11_244 = heff_dup(heff_field(v_pk_241, 0));
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Left: {
      V v_why_245 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_245, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Right: {
      heff_take_n(v_x11_244, 0ULL, 1);
      v_t_247 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x11_244);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2410;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_y_249 = heff_field(v_pkgs_242, 1);
    v_t_2410 = heff_dup(v_y_249);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, heff_take_field(v_st_243, 2)));
  V v_t_2412 = (g_prelude_2e_2b_2b(v_t_247, v_t_2411));
  V v_t_2416;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_2416 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_2413 = heff_field(v_pk_241, 0);
    V v_ru_24pk_241_24Just = heff_take_reuse_n(v_pk_241, 1ULL, 1);
    switch (heff_tag_of(v_x11_2413)) {
    case TAG_Left: {
      heff_take_n(v_x11_2413, 0ULL, 1);
      heff_drop_cell(v_ru_24pk_241_24Just, 1);
      v_t_2416 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2415 = heff_field(v_x11_2413, 0);
      heff_take_n(v_x11_2413, 1ULL, 1);
      v_t_2416 = heff_tag_at_n(v_ru_24pk_241_24Just, TAG_Just, 1, (V[]){v_p_2415});
      break;
    }
    default: heff_nomatch(v_x11_2413);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2419;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_pkgs_242, 0);
    v_t_2419 = heff_dup(v_x_2417);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  return heff_rec_n(5, shape_sources__errors__paths__package__packages, (V[]){heff_get_n(v_st_243, 0, 3), v_t_2412, v_ps_240, v_t_2416, v_t_2419});
}
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eload_2eloadDone(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
HEFF_STRA(g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_str0, 10, (112, 97, 99, 107, 97, 103, 101, 46, 104, 102));
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam0, 1, 0};
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_entry, 2, 0};

V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019(V v_st_240, V v_d_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(v_st_240, v_d_241));
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_244, 1)), heff_rfield(v_p_244, 2)));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_n(v_p_244, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_247 = (g_std_2epath_2erender(v_st_240, v_t_246));
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_247, ((V)&g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_c_2412 = heff_tr(heff_apply(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2411}));
  return heff_clo_n(g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam1, 2, 1, (V[]){v_c_2412});
}
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2417;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    v_x_2417 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2415, 0ULL, 1);
    v_x_2417 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V f_ = v_k_2414;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam2, 1, 1, (V[]){v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_str0, 3, (115, 114, 99));
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_entry, 3, 0};

V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(V v_h_240, V v_start_241, V v_d_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019(heff_rfield(v_h_240, 3), heff_dup(v_d_242)));
  return heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam0, 2, 4, (V[]){v_c_243, v_h_240, v_d_242, v_start_241});
}
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_start_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_246)) {
  case TAG_True: {
    heff_drop(v_start_241);
    heff_drop(v_hd_244);
    V v_st_247 = heff_dup(heff_rfield(v_h_240, 3));
    V v_t_248 = (g_std_2epath_2eparse(v_st_247, heff_dup(v_d_242)));
    V v_t_249 = (g_std_2epath_2eparse(v_st_247, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_str0)));
    V v_p_2410 = (g_std_2epath_2ejoin_2eonto_240(v_t_248, v_t_249));
    V v_t_2411 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2410, 1)), heff_rfield(v_p_2410, 2)));
    V v_t_2412 = ({ V rv_2 = v_t_2411; V rr_ = heff_rec_reuse_n(v_p_2410, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2413 = ({ V a_0 = v_st_247; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); r_; });
    V v_x_2414 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){v_d_242, v_t_2413, heff_take_field(v_h_240, 0), heff_take_field(v_h_240, 1), heff_take_field(v_h_240, 2), heff_get_n(v_h_240, 3, 4)});
    V f_ = v_k_245;
    args[0] = v_x_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_st_2415 = heff_dup(heff_rfield(v_h_240, 3));
    V v_p_2416 = (g_std_2epath_2eparse(v_st_2415, heff_dup(v_d_242)));
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2416, 2)));
    V v_xs_2418 = (g_list_2edrop(MK_INT(1LL), v_t_2417));
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
    V v_t_2420 = ({ V rv_2 = v_t_2419; V rr_ = heff_rec_reuse_n(v_p_2416, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2421 = ({ V a_0 = v_st_2415; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2415); r_; });
    if (heff_strEq_c(v_t_2421, heff_dup(v_d_242))) {
      heff_drop(v_d_242);
      heff_drop(v_hd_244);
      V v_t_2423 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){heff_dup(v_start_241), v_start_241, heff_take_field(v_h_240, 0), heff_take_field(v_h_240, 1), heff_take_field(v_h_240, 2), heff_get_n(v_h_240, 3, 4)});
      V f_ = v_k_245;
      args[0] = v_t_2423;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      V v_st_2424 = heff_dup(heff_rfield(v_h_240, 3));
      V v_p_2425 = (g_std_2epath_2eparse(v_st_2424, v_d_242));
      V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2425, 2)));
      V v_xs_2427 = (g_list_2edrop(MK_INT(1LL), v_t_2426));
      V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2427));
      V v_t_2429 = ({ V rv_2 = v_t_2428; V rr_ = heff_rec_reuse_n(v_p_2425, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2430 = ({ V a_0 = v_st_2424; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2424); r_; });
      V v_t_2431 = (g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(v_h_240, v_start_241, v_t_2430));
      return heff_tail(v_t_2431, 2, (V[]){v_hd_244, v_k_245});
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_start_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam1, 1, 5, (V[]){v_h_240, v_d_242, v_k_245, v_start_241, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_entry, 2, 0};

V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(V v_h_240, V v_file_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_h_240, 3));
  V v_p_243 = (g_std_2epath_2eparse(v_st_242, heff_dup(v_file_241)));
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_243, 2)));
  V v_xs_245 = (g_list_2edrop(MK_INT(1LL), v_t_244));
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
  V v_t_247 = ({ V rv_2 = v_t_246; V rr_ = heff_rec_reuse_n(v_p_243, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_248 = ({ V a_0 = v_st_242; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); r_; });
  V v_st_249 = heff_dup(heff_rfield(v_h_240, 3));
  V v_p_2410 = (g_std_2epath_2eparse(v_st_249, v_file_241));
  V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2410, 2)));
  V v_xs_2412 = (g_list_2edrop(MK_INT(1LL), v_t_2411));
  V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
  V v_t_2414 = ({ V rv_2 = v_t_2413; V rr_ = heff_rec_reuse_n(v_p_2410, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2415 = ({ V a_0 = v_st_249; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_249); r_; });
  return (g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(v_h_240, v_t_248, v_t_2415));
}
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(a[0], a[1]);
}
HEFF_STRA(g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_str0, 10, (112, 97, 99, 107, 97, 103, 101, 46, 104, 102));
HEFF_STRA(g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_str1, 10, (112, 97, 99, 107, 97, 103, 101, 46, 104, 102));
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_entry, 1, 0};

V g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738(V v_ps_240) {
top: ;
  V v_st_241 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_dup(heff_rfield(v_ps_240, 0))));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_244, 1)), heff_rfield(v_p_244, 2)));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_n(v_p_244, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_247 = ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_247, ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_c_2412 = heff_tr(heff_apply(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2411}));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_lam1, 2, 2, (V[]){v_c_2412, v_ps_240});
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738(a[0]);
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2428;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    v_x_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Just = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    V v_t_2417 = (g_heff_2ebuild_2eproject_2ereadPackage(heff_dup(v_src_2416)));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Left: {
      V v_p_2418 = heff_field(v_t_2417, 0);
      V v_ru_24t_2417_24Left = heff_take_reuse_n(v_t_2417, 1ULL, 1);
      V v_st_2419 = heff_take_field(v_ps_240, 5);
      V v_t_2420 = (g_std_2epath_2eparse(v_st_2419, heff_get_n(v_ps_240, 0, 6)));
      V v_t_2421 = (g_std_2epath_2eparse(v_st_2419, ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_str1)));
      V v_p_2422 = (g_std_2epath_2ejoin_2eonto_240(v_t_2420, v_t_2421));
      V v_t_2423 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2422, 1)), heff_rfield(v_p_2422, 2)));
      V v_t_2424 = ({ V rv_2 = v_t_2423; V rr_ = heff_rec_reuse_n(v_p_2422, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2425 = ({ V a_0 = v_st_2419; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2419); r_; });
      V v_t_2426 = heff_tag_at_n(v_ru_24x_2415_24Just, TAG_Left, 1, (V[]){(g_heff_2ebuild_2eload_2eproblemMsg(v_t_2425, v_src_2416, v_p_2418))});
      v_x_2428 = heff_tag_at_n(v_ru_24t_2417_24Left, TAG_Just, 1, (V[]){v_t_2426});
      break;
    }
    case TAG_Right: {
      V v_pk_2427 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_src_2416);
      v_x_2428 = heff_tag_at_n(v_ru_24x_2415_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_pk_2427})});
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V f_ = v_k_2414;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738_lam2, 1, 2, (V[]){v_ps_240, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str0, 8, (104, 101, 102, 102, 46, 115, 117, 109));
HEFF_STRA(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str1, 1, (10));
HEFF_STRA(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str2, 8, (104, 101, 102, 102, 46, 115, 117, 109));
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_entry, 1, 0};

V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(V v_ps_240) {
top: ;
  V v_st_241 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_dup(heff_rfield(v_ps_240, 0))));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_244, 1)), heff_rfield(v_p_244, 2)));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_n(v_p_244, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_247 = ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_247, ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_c_2412 = heff_tr(heff_apply(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2411}));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam1, 2, 2, (V[]){v_c_2412, v_ps_240});
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(a[0]);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2428;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    v_x_2428 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_t_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Just = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    V v_t_2417 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str1), heff_dup(v_t_2416), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2418 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2417; V r_ = (g_heff_2ebuild_2eproject_2esumGo(a_0, a_1)); heff_drop(v_t_2417); r_; });
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Left: {
      V v_p_2419 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      V v_st_2420 = heff_take_field(v_ps_240, 5);
      V v_t_2421 = (g_std_2epath_2eparse(v_st_2420, heff_get_n(v_ps_240, 0, 6)));
      V v_t_2422 = (g_std_2epath_2eparse(v_st_2420, ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str2)));
      V v_p_2423 = (g_std_2epath_2ejoin_2eonto_240(v_t_2421, v_t_2422));
      V v_t_2424 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2423, 1)), heff_rfield(v_p_2423, 2)));
      V v_t_2425 = ({ V rv_2 = v_t_2424; V rr_ = heff_rec_reuse_n(v_p_2423, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2426 = ({ V a_0 = v_st_2420; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2420); r_; });
      v_x_2428 = heff_tag_at_n(v_ru_24x_2415_24Just, TAG_Left, 1, (V[]){(g_heff_2ebuild_2eload_2eproblemMsg(v_t_2426, v_t_2416, v_p_2419))});
      break;
    }
    case TAG_Right: {
      V v_sums_2427 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_t_2416);
      v_x_2428 = heff_tag_at_n(v_ru_24x_2415_24Just, TAG_Right, 1, (V[]){v_sums_2427});
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V f_ = v_k_2414;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam2, 1, 2, (V[]){v_ps_240, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str0, 10, (112, 97, 99, 107, 97, 103, 101, 46, 104, 102));
HEFF_STRA(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str1, 10, (112, 97, 99, 107, 97, 103, 101, 46, 104, 102));
HEFF_STRA(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str2, 15, (32, 99, 97, 110, 110, 111, 116, 32, 98, 101, 32, 114, 101, 97, 100));
HEFF_STRA(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str3, 10, (112, 97, 99, 107, 97, 103, 101, 46, 104, 102));
HEFF_STRA(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str4, 10, (112, 97, 99, 107, 97, 103, 101, 46, 104, 102));
HEFF_STRA(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str5, 16, (32, 105, 115, 32, 116, 104, 101, 32, 112, 97, 99, 107, 97, 103, 101, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str6, 6, (44, 32, 110, 111, 116, 32));
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_entry, 3, 0};

V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(V v_ps_240, V v_dir_241, V v_path_242) {
top: ;
  V v_st_243 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_244 = (g_std_2epath_2eparse(v_st_243, heff_dup(v_dir_241)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_243, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str0)));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_246, 1)), heff_rfield(v_p_246, 2)));
  V v_t_248 = ({ V rv_2 = v_t_247; V rr_ = heff_rec_reuse_n(v_p_246, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_249 = ({ V a_0 = v_st_243; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); r_; });
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_249, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam0_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_c_2414 = heff_tr(heff_apply(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2413}));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam1, 2, 4, (V[]){v_c_2414, v_ps_240, v_dir_241, v_path_242});
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam0(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2445;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nothing: {
    heff_drop(v_path_242);
    V v_st_2418 = heff_get_n(v_ps_240, 5, 6);
    V v_t_2419 = (g_std_2epath_2eparse(v_st_2418, v_dir_241));
    V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str1)));
    V v_p_2421 = (g_std_2epath_2ejoin_2eonto_240(v_t_2419, v_t_2420));
    V v_t_2422 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2421, 1)), heff_rfield(v_p_2421, 2)));
    V v_t_2423 = ({ V rv_2 = v_t_2422; V rr_ = heff_rec_reuse_n(v_p_2421, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2424 = ({ V a_0 = v_st_2418; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); r_; });
    v_x_2445 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str2))});
    break;
  }
  case TAG_Just: {
    V v_t_2425 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Just = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    V v_t_2426 = (g_heff_2ebuild_2eproject_2ereadPackage(heff_dup(v_t_2425)));
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Left: {
      V v_p_2427 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 1);
      heff_drop(v_path_242);
      V v_st_2428 = heff_get_n(v_ps_240, 5, 6);
      V v_t_2429 = (g_std_2epath_2eparse(v_st_2428, v_dir_241));
      V v_t_2430 = (g_std_2epath_2eparse(v_st_2428, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str3)));
      V v_p_2431 = (g_std_2epath_2ejoin_2eonto_240(v_t_2429, v_t_2430));
      V v_t_2432 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2431, 1)), heff_rfield(v_p_2431, 2)));
      V v_t_2433 = ({ V rv_2 = v_t_2432; V rr_ = heff_rec_reuse_n(v_p_2431, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2434 = ({ V a_0 = v_st_2428; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2428); r_; });
      v_x_2445 = heff_tag_at_n(v_ru_24x_2417_24Just, TAG_Left, 1, (V[]){(g_heff_2ebuild_2eload_2eproblemMsg(v_t_2434, v_t_2425, v_p_2427))});
      break;
    }
    case TAG_Right: {
      V v_pk_2435 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 1);
      heff_drop(v_t_2425);
      if (heff_strEq_c(heff_dup(heff_rfield(v_pk_2435, 0)), heff_dup(v_path_242))) {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_dir_241);
        heff_drop(v_path_242);
        v_x_2445 = heff_tag_at_n(v_ru_24x_2417_24Just, TAG_Right, 1, (V[]){v_pk_2435});
      } else {
        V v_st_2437 = heff_get_n(v_ps_240, 5, 6);
        V v_t_2438 = (g_std_2epath_2eparse(v_st_2437, v_dir_241));
        V v_t_2439 = (g_std_2epath_2eparse(v_st_2437, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str4)));
        V v_p_2440 = (g_std_2epath_2ejoin_2eonto_240(v_t_2438, v_t_2439));
        V v_t_2441 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2440, 1)), heff_rfield(v_p_2440, 2)));
        V v_t_2442 = ({ V rv_2 = v_t_2441; V rr_ = heff_rec_reuse_n(v_p_2440, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2443 = ({ V a_0 = v_st_2437; V a_1 = v_t_2442; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2437); r_; });
        V v_t_2444 = heff_strAppend(v_t_2443, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str5), heff_strAppend(heff_get_n(v_pk_2435, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str6), v_path_242))));
        v_x_2445 = heff_tag_at_n(v_ru_24x_2417_24Just, TAG_Left, 1, (V[]){v_t_2444});
      }
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V f_ = v_k_2416;
  args[0] = v_x_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2414;
  args[0] = v_hd_2415;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam2, 1, 4, (V[]){v_ps_240, v_dir_241, v_path_242, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str0, 5, (46, 104, 97, 115, 104));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str1, 10, (32, 114, 101, 113, 117, 105, 114, 101, 115, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str2, 1, (32));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str3, 38, (44, 32, 119, 104, 105, 99, 104, 32, 105, 115, 32, 110, 111, 116, 32, 102, 101, 116, 99, 104, 101, 100, 58, 32, 114, 117, 110, 32, 96, 104, 101, 102, 102, 32, 103, 101, 116, 96));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str4, 25, (104, 101, 102, 102, 46, 115, 117, 109, 32, 115, 97, 121, 115, 32, 110, 111, 116, 104, 105, 110, 103, 32, 111, 102, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str5, 1, (32));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str6, 16, (58, 32, 114, 117, 110, 32, 96, 104, 101, 102, 102, 32, 103, 101, 116, 96));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str7, 1, (32));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str8, 4, (32, 105, 110, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str9, 4, (32, 105, 115, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str10, 20, (44, 32, 97, 110, 100, 32, 104, 101, 102, 102, 46, 115, 117, 109, 32, 115, 97, 121, 115, 32));
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam2(V self, V *args); static Clo g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam2, 1, 0};
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam3(V self, V *args);
Clo g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_entry, 6, 0};

V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_t_247 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam0, 1, 1, (V[]){heff_dup(v_path_244)}), heff_take_field(v_root_241, 2)));
  V v_t_2414;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    v_t_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 2);
    V v_t_2411 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam1, 1, 1, (V[]){v_r_248}), heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nil: {
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 2);
      v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2412, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    V v_t_2415 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    V v_path_2416 = heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str0));
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2416, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam2_clo)})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_c_2421 = heff_tr(heff_apply(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2420}));
    return heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam3, 2, 6, (V[]){v_c_2421, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2449 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_st_2450 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_2451 = (g_std_2epath_2eparse(v_st_2450, heff_dup(heff_rfield(v_ps_240, 0))));
    V v_t_2452 = (g_std_2epath_2eparse(v_st_2450, v_d_2449));
    V v_p_2453 = (g_std_2epath_2ejoin_2eonto_240(v_t_2451, v_t_2452));
    V v_t_2454 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2453, 1)), heff_rfield(v_p_2453, 2)));
    V v_t_2455 = ({ V rv_2 = v_t_2454; V rr_ = heff_rec_reuse_n(v_p_2453, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2456 = ({ V a_0 = v_st_2450; V a_1 = v_t_2455; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2450); r_; });
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(v_ps_240, v_t_2456, v_path_244));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam0(V self, V *args) {
  V v_r_246 = args[0];
  V v_path_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_r_246, 1, 3), v_path_244);
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam1(V self, V *args) {
  V v_p_2410 = args[0];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_p_2410, 0, 2), heff_get_n(v_r_248, 0, 3));
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam2(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam5(V self, V *args) {
  V v_s_2427 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_s_2427, 0)), v_path_244)) {
    return heff_strEq(heff_get_n(v_s_2427, 1, 3), v_v_245);
  } else {
    heff_drop_rec(v_s_2427, 3);
    heff_drop(v_v_245);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_by_243 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_v_245 = heff_env(self)[2];
  V v_k_2423 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2422 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    heff_drop(v_sums_242);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_2422);
    V v_t_2425 = heff_strAppend(v_by_243, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str1), heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str2), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str3))))));
    V f_ = v_k_2423;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2425});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_h_2426 = heff_field(v_x_2424, 0);
    V v_ru_24x_2424_24Just = heff_take_reuse_n(v_x_2424, 1ULL, 1);
    heff_drop(v_by_243);
    V v_t_2429 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam5, 1, 2, (V[]){heff_dup(v_path_244), heff_dup(v_v_245)}), v_sums_242));
    V v_t_2432;
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x_2424_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_s_2430 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 2);
      v_t_2432 = heff_tag_at_n(v_ru_24x_2424_24Just, TAG_Just, 1, (V[]){heff_get_n(v_s_2430, 2, 3)});
      break;
    }
    default: heff_nomatch(v_t_2429);
    }
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nothing: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hd_2422);
      heff_drop(v_h_2426);
      V v_t_2433 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str4), heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str5), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str6)))));
      V f_ = v_k_2423;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2433});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_want_2434 = heff_field(v_t_2432, 0);
      V v_ru_24t_2432_24Just = heff_take_reuse_n(v_t_2432, 1ULL, 1);
      V v_t_2435 = (g_prelude_2eskipSpaces(heff_dup(v_h_2426), MK_INT(0LL), MK_INT(1LL)));
      V v_t_2436 = heff_intSub(heff_strLength(heff_dup(v_h_2426)), MK_INT(1LL));
      V v_t_2437 = (g_prelude_2eskipSpaces(heff_dup(v_h_2426), v_t_2436, MK_INT(-1LL)));
      V v_t_2438 = heff_strSlice(heff_dup(v_h_2426), v_t_2435, heff_intAdd(v_t_2437, MK_INT(1LL)));
      if (heff_strEq_c(v_t_2438, heff_dup(v_want_2434))) {
        heff_drop(v_h_2426);
        heff_drop(v_want_2434);
        heff_drop_cell(v_ru_24t_2432_24Just, 1);
        V v_t_2440 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2441 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(v_ps_240, v_t_2440, v_path_244));
        return heff_tail(v_t_2441, 2, (V[]){v_hd_2422, v_k_2423});
      } else {
        heff_drop(v_hd_2422);
        V v_t_2442 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, heff_dup(v_path_244), heff_dup(v_v_245)));
        V v_t_2443 = (g_prelude_2eskipSpaces(heff_dup(v_h_2426), MK_INT(0LL), MK_INT(1LL)));
        V v_t_2444 = heff_intSub(heff_strLength(heff_dup(v_h_2426)), MK_INT(1LL));
        V v_t_2445 = (g_prelude_2eskipSpaces(heff_dup(v_h_2426), v_t_2444, MK_INT(-1LL)));
        V v_t_2446 = heff_strSlice(v_h_2426, v_t_2443, heff_intAdd(v_t_2445, MK_INT(1LL)));
        V v_t_2447 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str7), heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str8), heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str9), heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str10), v_want_2434))))))));
        V v_x_2448 = heff_tag_at_n(v_ru_24t_2432_24Just, TAG_Left, 1, (V[]){v_t_2447});
        V f_ = v_k_2423;
        args[0] = v_x_2448;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_by_243 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam4, 1, 7, (V[]){v_by_243, v_path_244, v_v_245, v_k_2423, v_sums_242, v_ps_240, v_hd_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_str0, 1, (32));
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam2(V self, V *args);
Clo g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_entry, 5, 0};

V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(V v_rd_240, V v_root_241, V v_x3_242, V v_seen_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_rd_240);
    heff_drop(v_root_241);
    return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam0, 2, 2, (V[]){v_seen_243, v_errs_244});
  }
  case TAG_Cons: {
    V v_n_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2412;
    if (heff_strEq_c(heff_dup(heff_rfield(v_n_247, 1)), heff_dup(v_root_241))) {
      v_t_2412 = NTAG(TAG_True);
    } else {
      v_t_2412 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam1, 1, 1, (V[]){heff_dup(v_n_247)}), v_seen_243));
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop_rec(v_n_247, 3);
      V t_0 = v_rd_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_seen_243;
      V t_4 = v_errs_244;
      v_rd_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_seen_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    }
    case TAG_False: {
      V v_c_2413 = heff_tr(heff_apply(heff_dup(v_rd_240), 3, (V[]){heff_dup(heff_rfield(v_n_247, 0)), heff_dup(heff_rfield(v_n_247, 1)), heff_dup(heff_rfield(v_n_247, 2))}));
      return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam2, 2, 7, (V[]){v_c_2413, v_n_247, v_seen_243, v_errs_244, v_rd_240, v_root_241, v_rest_248});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_seen_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_seen_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_n_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 0)), heff_dup(heff_rfield(v_n_247, 1)))) {
    return heff_strEq(heff_get_n(v_x_2410, 1, 3), heff_get_n(v_n_247, 2, 3));
  } else {
    heff_drop_rec(v_x_2410, 3);
    heff_drop_rec(v_n_247, 3);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam4(V self, V *args) {
  V v_r_2425 = args[0];
  V v_n_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_strAppend(heff_take_field(v_n_247, 1), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_str0), heff_get_n(v_n_247, 2, 3)));
  return heff_rec_n(3, shape_by__path__version, (V[]){v_t_2426, heff_dup(heff_rfield(v_r_2425, 1)), heff_get_n(v_r_2425, 2, 3)});
}
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_n_247 = heff_env(self)[0];
  V v_seen_243 = heff_env(self)[1];
  V v_errs_244 = heff_env(self)[2];
  V v_rd_240 = heff_env(self)[3];
  V v_root_241 = heff_env(self)[4];
  V v_rest_248 = heff_env(self)[5];
  V v_hd_2414 = heff_env(self)[6];
  V v_k_2415 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_why_2417 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2418 = heff_rec_n(3, shape_path__version__pkg, (V[]){heff_take_field(v_n_247, 1), heff_get_n(v_n_247, 2, 3), NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
    V v_t_2420 = (g_prelude_2e_2b_2b(v_seen_243, v_t_2419));
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2417, NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b(v_errs_244, v_t_2421));
    V v_t_2423 = (g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(v_rd_240, v_root_241, v_rest_248, v_t_2420, v_t_2422));
    return heff_tail(v_t_2423, 2, (V[]){v_hd_2414, v_k_2415});
  }
  case TAG_Right: {
    V v_pk_2424 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2427 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam4, 1, 1, (V[]){heff_dup(v_n_247)}), heff_dup(heff_rfield(v_pk_2424, 2))));
    V v_t_2428 = (g_prelude_2e_2b_2b(v_rest_248, v_t_2427));
    V v_t_2429 = heff_rec_n(3, shape_path__version__pkg, (V[]){heff_take_field(v_n_247, 1), heff_get_n(v_n_247, 2, 3), heff_tag_n(TAG_Just, 1, (V[]){v_pk_2424})});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    V v_t_2431 = (g_prelude_2e_2b_2b(v_seen_243, v_t_2430));
    V v_t_2432 = (g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(v_rd_240, v_root_241, v_t_2428, v_t_2431, v_errs_244));
    return heff_tail(v_t_2432, 2, (V[]){v_hd_2414, v_k_2415});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_n_247 = heff_env(self)[1];
  V v_seen_243 = heff_env(self)[2];
  V v_errs_244 = heff_env(self)[3];
  V v_rd_240 = heff_env(self)[4];
  V v_root_241 = heff_env(self)[5];
  V v_rest_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam3, 1, 8, (V[]){v_n_247, v_seen_243, v_errs_244, v_rd_240, v_root_241, v_rest_248, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str0, 19, (32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121));
HEFF_STRA(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str1, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str2, 2, (44, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str3, 7, (32, 104, 111, 108, 100, 115, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str4, 60, (58, 32, 97, 32, 112, 97, 99, 107, 97, 103, 101, 39, 115, 32, 115, 114, 99, 47, 32, 104, 111, 108, 100, 115, 32, 111, 110, 101, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121, 44, 32, 110, 97, 109, 101, 100, 32, 97, 115, 32, 116, 104, 101, 32, 112, 97, 99, 107, 97, 103, 101));
HEFF_STRA(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str5, 7, (32, 104, 111, 108, 100, 115, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str6, 26, (44, 32, 119, 104, 105, 99, 104, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121));
HEFF_STRA(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str7, 72, (32, 99, 97, 110, 110, 111, 116, 32, 110, 97, 109, 101, 32, 97, 32, 112, 97, 99, 107, 97, 103, 101, 58, 32, 97, 32, 108, 111, 119, 101, 114, 99, 97, 115, 101, 32, 108, 101, 116, 116, 101, 114, 44, 32, 116, 104, 101, 110, 32, 108, 101, 116, 116, 101, 114, 115, 44, 32, 100, 105, 103, 105, 116, 115, 32, 97, 110, 100, 32, 96, 95, 96));
HEFF_STRA(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str8, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str9, 2, (44, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str10, 7, (32, 104, 111, 108, 100, 115, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str11, 60, (58, 32, 97, 32, 112, 97, 99, 107, 97, 103, 101, 39, 115, 32, 115, 114, 99, 47, 32, 104, 111, 108, 100, 115, 32, 111, 110, 101, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121, 44, 32, 110, 97, 109, 101, 100, 32, 97, 115, 32, 116, 104, 101, 32, 112, 97, 99, 107, 97, 103, 101));
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam0, 1, 0};
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam2(V self, V *args); static Clo g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam2, 1, 0};
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_entry, 4, 0};

V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(V v_ps_240, V v_src_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(v_src_241), ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(v_t_247, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam1, 1, 4, (V[]){v_src_241, v_k_243, v_ps_240, v_hd_242})));
}
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam0(V self, V *args) {
  V v_ns_244 = args[0];
  return v_ns_244;
}
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam2(V self, V *args) {
  V v_ns_2425 = args[0];
  return v_ns_2425;
}
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_src_241 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2441;
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    V v_t_2431 = heff_strAppend(v_src_241, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str5), heff_strAppend(v_x_2416, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str6))));
    v_x_2441 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2431});
    break;
  }
  case TAG_Just: {
    V v_ru_24x_2430_24Just = heff_take_reuse_n(v_x_2430, 0ULL, 1);
    V v_t_2433 = (g_heff_2ebuild_2eproject_2eisName(heff_dup(v_x_2416)));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_True: {
      heff_drop(v_src_241);
      heff_drop_rec(v_ps_240, 6);
      v_x_2441 = heff_tag_at_n(v_ru_24x_2430_24Just, TAG_Right, 1, (V[]){v_x_2416});
      break;
    }
    case TAG_False: {
      V v_st_2434 = heff_get_n(v_ps_240, 5, 6);
      V v_t_2435 = (g_std_2epath_2eparse(v_st_2434, v_src_241));
      V v_t_2436 = (g_std_2epath_2eparse(v_st_2434, v_x_2416));
      V v_p_2437 = (g_std_2epath_2ejoin_2eonto_240(v_t_2435, v_t_2436));
      V v_t_2438 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2437, 1)), heff_rfield(v_p_2437, 2)));
      V v_t_2439 = ({ V rv_2 = v_t_2438; V rr_ = heff_rec_reuse_n(v_p_2437, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2440 = ({ V a_0 = v_st_2434; V a_1 = v_t_2439; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2434); r_; });
      v_x_2441 = heff_tag_at_n(v_ru_24x_2430_24Just, TAG_Left, 1, (V[]){heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str7))});
      break;
    }
    default: heff_nomatch(v_t_2433);
    }
    break;
  }
  default: heff_nomatch(v_x_2430);
  }
  V f_ = v_k_243;
  args[0] = v_x_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_src_241 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_242);
    V v_t_249 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_src_241, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str0))});
    V f_ = v_k_243;
    args[0] = v_t_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_it1_2410 = heff_field(v_x_248, 0);
    V v_ru_24x_248_24Just = heff_take_reuse_n(v_x_248, 1ULL, 1);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hd_242);
      V v_t_2413;
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_it1_2410, 0);
        V v_xs_2412 = heff_field(v_it1_2410, 1);
        heff_take_n(v_it1_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_it1_2410);
      }
      V v_t_2414 = heff_strAppend(v_src_241, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str3), heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str4))));
      V v_x_2415 = heff_tag_at_n(v_ru_24x_248_24Just, TAG_Left, 1, (V[]){v_t_2414});
      V f_ = v_k_243;
      args[0] = v_x_2415;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_2416 = heff_dup(heff_field(v_it1_2410, 0));
      V v_it12_2417 = heff_dup(heff_field(v_it1_2410, 1));
      switch (heff_tag_of(v_it12_2417)) {
      case TAG_Nil: {
        heff_drop_tag(v_it1_2410, 2);
        V v_st_2418 = heff_dup(heff_rfield(v_ps_240, 5));
        V v_t_2419 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_src_241)));
        V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_x_2416)));
        V v_p_2421 = (g_std_2epath_2ejoin_2eonto_240(v_t_2419, v_t_2420));
        V v_t_2422 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2421, 1)), heff_rfield(v_p_2421, 2)));
        V v_t_2423 = ({ V rv_2 = v_t_2422; V rr_ = heff_rec_reuse_n(v_p_2421, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_path_2424 = ({ V a_0 = v_st_2418; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); r_; });
        V v_t_2426 = heff_tag_at_n(v_ru_24x_248_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){v_path_2424, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam2_clo)})});
        V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
        V v_c_2429 = heff_tr(heff_apply(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2428}));
        return heff_tail(v_c_2429, 2, (V[]){v_hd_242, heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam3, 1, 4, (V[]){v_src_241, v_x_2416, v_ps_240, v_k_243})});
      }
      case TAG_Cons: {
        heff_take_n(v_it12_2417, 0ULL, 2);
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_hd_242);
        heff_drop(v_x_2416);
        V v_t_2446;
        switch (heff_tag_of(v_it1_2410)) {
        case TAG_Nil: {
          v_t_2446 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2444 = heff_field(v_it1_2410, 0);
          V v_xs_2445 = heff_field(v_it1_2410, 1);
          heff_take_n(v_it1_2410, 3ULL, 2);
          v_t_2446 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str9); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
          break;
        }
        default: heff_nomatch(v_it1_2410);
        }
        V v_t_2447 = heff_strAppend(v_src_241, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str10), heff_strAppend(v_t_2446, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str11))));
        V v_x_2448 = heff_tag_at_n(v_ru_24x_248_24Just, TAG_Left, 1, (V[]){v_t_2447});
        V f_ = v_k_243;
        args[0] = v_x_2448;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_it12_2417);
      }
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  default: return heff_nomatch(v_x_248);
  }
}
HEFF_STRA(g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_str0, 3, (115, 114, 99));
HEFF_STRA(g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_str1, 3, (115, 114, 99));
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam3(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917(V v_ps_240, V v_root_241, V v_x_242, V v_pk_243) {
top: ;
  V v_t_245 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam0, 1, 1, (V[]){heff_dup(v_x_242)}), heff_take_field(v_root_241, 2)));
  V v_x_2418;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    v_x_2418 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 1))));
    break;
  }
  case TAG_Cons: {
    V v_r_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 2);
    V v_t_249 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam1, 1, 1, (V[]){v_r_246}), heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_x_2418 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 1))));
      break;
    }
    case TAG_Cons: {
      V v_p_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 2);
      V v_st_2412 = heff_dup(heff_rfield(v_ps_240, 5));
      V v_t_2413 = (g_std_2epath_2eparse(v_st_2412, heff_dup(heff_rfield(v_ps_240, 0))));
      V v_t_2414 = (g_std_2epath_2eparse(v_st_2412, heff_get_n(v_p_2410, 1, 2)));
      V v_p_2415 = (g_std_2epath_2ejoin_2eonto_240(v_t_2413, v_t_2414));
      V v_t_2416 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2415, 1)), heff_rfield(v_p_2415, 2)));
      V v_t_2417 = ({ V rv_2 = v_t_2416; V rr_ = heff_rec_reuse_n(v_p_2415, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
      v_x_2418 = ({ V a_0 = v_st_2412; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2412); r_; });
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_c_2421 = heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam2, 2, 1, (V[]){v_x_2418});
  return heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam3, 2, 4, (V[]){v_c_2421, v_ps_240, v_pk_243, v_x_242});
}
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam0(V self, V *args) {
  V v_r_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_r_244, 1, 3), heff_get_n(v_x_242, 0, 3));
}
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam1(V self, V *args) {
  V v_p_248 = args[0];
  V v_r_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_p_248, 0, 2), heff_get_n(v_r_246, 0, 3));
}
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_x_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  V v_pk_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_k_2423 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2445;
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    V v_why_2434 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Left = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_x_2424);
    heff_drop_rec(v_pk_243, 4);
    heff_drop_rec(v_x_242, 3);
    v_x_2445 = heff_tag_at_n(v_ru_24x_2433_24Left, TAG_Left, 1, (V[]){v_why_2434});
    break;
  }
  case TAG_Right: {
    V v_name_2435 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Right = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    V v_st_2436 = heff_get_n(v_ps_240, 5, 6);
    V v_t_2437 = (g_std_2epath_2eparse(v_st_2436, heff_dup(v_x_2424)));
    V v_t_2438 = (g_std_2epath_2eparse(v_st_2436, ((V)&g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_str1)));
    V v_p_2439 = (g_std_2epath_2ejoin_2eonto_240(v_t_2437, v_t_2438));
    V v_t_2440 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2439, 1)), heff_rfield(v_p_2439, 2)));
    V v_t_2441 = ({ V rv_2 = v_t_2440; V rr_ = heff_rec_reuse_n(v_p_2439, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2442 = ({ V a_0 = v_st_2436; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2436); r_; });
    V v_t_2443 = (g_list_2emap_24s871082722x1690249882(heff_take_field(v_pk_243, 2)));
    V v_t_2444 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_get_n(v_x_242, 0, 3), v_x_2424, v_t_2442, heff_dup(v_name_2435), v_name_2435, heff_get_n(v_pk_243, 1, 4), v_t_2443});
    v_x_2445 = heff_tag_at_n(v_ru_24x_2433_24Right, TAG_Right, 1, (V[]){v_t_2444});
    break;
  }
  default: heff_nomatch(v_x_2433);
  }
  V f_ = v_k_2423;
  args[0] = v_x_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_pk_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_k_2423 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2425 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_2426 = (g_std_2epath_2eparse(v_st_2425, heff_dup(v_x_2424)));
  V v_t_2427 = (g_std_2epath_2eparse(v_st_2425, ((V)&g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_str0)));
  V v_p_2428 = (g_std_2epath_2ejoin_2eonto_240(v_t_2426, v_t_2427));
  V v_t_2429 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2428, 1)), heff_rfield(v_p_2428, 2)));
  V v_t_2430 = ({ V rv_2 = v_t_2429; V rr_ = heff_rec_reuse_n(v_p_2428, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2431 = ({ V a_0 = v_st_2425; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2425); r_; });
  V v_c_2432 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_clo), 2, (V[]){heff_dup(v_ps_240), v_t_2431}));
  return heff_tail(v_c_2432, 2, (V[]){v_hd_2422, heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam5, 1, 5, (V[]){v_ps_240, v_x_2424, v_pk_243, v_x_242, v_k_2423})});
}
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_pk_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam4, 1, 5, (V[]){v_ps_240, v_hd_2422, v_pk_243, v_x_242, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_entry, 5, 0};

V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789(V v_ps_240, V v_root_241, V v_x3_242, V v_acc_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_root_241);
    return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam0, 2, 2, (V[]){v_acc_243, v_errs_244});
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_249 = heff_dup(heff_rfield(v_x_247, 2));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x_247, 3);
      V t_0 = v_ps_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_acc_243;
      V t_4 = v_errs_244;
      v_ps_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    }
    case TAG_Just: {
      V v_pk_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V v_c_2411 = (g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917(heff_dup(v_ps_240), heff_dup(v_root_241), v_x_247, v_pk_2410));
      return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam1, 2, 6, (V[]){v_c_2411, v_errs_244, v_ps_240, v_root_241, v_rest_248, v_acc_243});
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_errs_244 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_241 = heff_env(self)[2];
  V v_rest_248 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2415, NTAG(TAG_Nil)});
    V v_t_2417 = (g_prelude_2e_2b_2b(v_errs_244, v_t_2416));
    V v_t_2418 = (g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789(v_ps_240, v_root_241, v_rest_248, v_acc_243, v_t_2417));
    return heff_tail(v_t_2418, 2, (V[]){v_hd_2412, v_k_2413});
  }
  case TAG_Right: {
    V v_p_2419 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_2419, NTAG(TAG_Nil)});
    V v_t_2421 = (g_prelude_2e_2b_2b(v_acc_243, v_t_2420));
    V v_t_2422 = (g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789(v_ps_240, v_root_241, v_rest_248, v_t_2421, v_errs_244));
    return heff_tail(v_t_2422, 2, (V[]){v_hd_2412, v_k_2413});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_acc_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam2, 1, 7, (V[]){v_errs_244, v_ps_240, v_root_241, v_rest_248, v_acc_243, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_str0, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_str1, 11, (116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116));
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407(V v_ps_240, V v_root_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(heff_dup(v_ps_240)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam0, 2, 3, (V[]){v_c_242, v_ps_240, v_root_241});
}
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam2(V self, V *args) {
  V v_r_2412 = args[0];
  V v_by_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_rec_n(3, shape_by__path__version, (V[]){v_by_2411, heff_dup(heff_rfield(v_r_2412, 1)), heff_get_n(v_r_2412, 2, 3)});
}
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_seen_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2420; V a_1 = v_seen_2418; V r_ = (g_list_2efoldl_24s9956384x694087549(a_0, a_1)); heff_drop(v_seen_2418); r_; });
}
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_dup(heff_field(v_x_2423, 0));
    v_t_2426 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V v_t_2429;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    V v_x_2427 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2427, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_245, 0ULL, 1);
    v_t_2429 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_2432;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_y_2431 = heff_field(v_x_2415, 1);
    heff_take_n(v_x_2415, 2ULL, 2);
    v_t_2432 = v_y_2431;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2435;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_MkPair: {
    V v_y_2434 = heff_field(v_x_2423, 1);
    heff_take_n(v_x_2423, 2ULL, 2);
    v_t_2435 = v_y_2434;
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2432, v_t_2435));
  V v_x_2437 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, (g_prelude_2e_2b_2b(v_t_2429, v_t_2436))});
  V f_ = v_k_244;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_seen_2418;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_dup(heff_field(v_x_2415, 0));
    v_seen_2418 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2419 = (g_list_2efoldl_24s230517345x1163337657(NTAG(TAG_Nil), heff_dup(v_seen_2418)));
  V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam4, 1, 1, (V[]){v_seen_2418}), v_t_2419));
  V v_c_2422 = (g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789(v_ps_240, v_root_241, v_t_2421, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  return heff_tail(v_c_2422, 2, (V[]){v_hd_243, heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam5, 1, 3, (V[]){v_x_245, v_x_2415, v_k_244})});
}
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_247 = heff_dup(heff_field(v_x_245, 0));
    v_t_248 = v_y_247;
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_rd_249 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_clo), 3, (V[]){heff_dup(v_ps_240), heff_dup(v_root_241), v_t_248}));
  V v_by_2411;
  if (heff_strEq_c(heff_dup(heff_rfield(v_root_241, 0)), ((V)&g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_str0))) {
    v_by_2411 = ((V)&g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_str1);
  } else {
    v_by_2411 = heff_dup(heff_rfield(v_root_241, 0));
  }
  V v_t_2413 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam2, 1, 1, (V[]){v_by_2411}), heff_dup(heff_rfield(v_root_241, 2))));
  V v_c_2414 = (g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(v_rd_249, heff_dup(heff_rfield(v_root_241, 0)), v_t_2413, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam3, 1, 5, (V[]){v_ps_240, v_root_241, v_hd_243, v_x_245, v_k_244})});
}
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam1, 1, 4, (V[]){v_ps_240, v_root_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str0, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str1, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str2, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str3, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str4, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str5, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str6, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str7, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str8, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str9, 4, (32, 45, 62, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str10, 30, (112, 97, 99, 107, 97, 103, 101, 115, 32, 114, 101, 113, 117, 105, 114, 101, 32, 111, 110, 101, 32, 97, 110, 111, 116, 104, 101, 114, 58, 32));
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam3(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam3, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam5(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam5, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam7(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam7, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_entry, 2, 0};

V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam0, 2, 1, (V[]){v_ps_240});
  }
  case TAG_Just: {
    V v_root_247 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_c_248 = (g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407(heff_dup(v_ps_240), heff_dup(v_root_247)));
    return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam1, 2, 3, (V[]){v_c_248, v_ps_240, v_root_247});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V v_t_244 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str0), heff_take_field(v_ps_240, 0), heff_get_n(v_ps_240, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str1), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str2), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str3), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V f_ = v_k_243;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam3(V self, V *args) {
  V v_ns_2412 = args[0];
  return v_ns_2412;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam5(V self, V *args) {
  V v_ns_2420 = args[0];
  return v_ns_2420;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam7(V self, V *args) {
  V v_ns_2428 = args[0];
  return v_ns_2428;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam8(V self, V *args) {
  V v_x_2432 = args[0];
  V v_root_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_x_2419 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2434;
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Nothing: {
    v_t_2434 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2433 = heff_field(v_x_2432, 0);
    heff_take_n(v_x_2432, 1ULL, 1);
    v_t_2434 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x_2432);
  }
  V v_x_2435 = (g_list_2emap_24s1462590149x1582455373(v_t_2434));
  V v_t_2436 = (g_list_2emap_24s871082722x1690249882(heff_dup(heff_rfield(v_root_247, 2))));
  V v_t_2437 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_247, 0)), heff_dup(heff_rfield(v_ps_240, 0)), heff_dup(heff_rfield(v_ps_240, 1)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str4), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str5), heff_dup(heff_rfield(v_root_247, 1)), v_t_2436});
  V v_t_2438 = (g_prelude_2e_2b_2b(v_x_2427, v_x_2435));
  V v_t_2439 = (g_prelude_2e_2b_2b(v_x_2419, v_t_2438));
  V v_t_2442;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_dup(heff_field(v_x_2411, 0));
    v_t_2442 = v_x_2440;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, (g_heff_2ebuild_2eload_2enamedGo(v_t_2439, v_t_2442))});
  V v_t_2446;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_y_2445 = heff_dup(heff_field(v_x_2411, 1));
    v_t_2446 = v_y_2445;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2447 = (g_list_2emap_24s871082722x1690249882(heff_take_field(v_root_247, 2)));
  V v_t_2448 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_247, 0)), heff_take_field(v_ps_240, 0), heff_get_n(v_ps_240, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str7), heff_take_field(v_root_247, 1), v_t_2447});
  V v_t_2451;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 2);
    v_t_2451 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_root_247, 0, 4), NTAG(TAG_Nil)});
  V v_t_2453 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, v_t_2451}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2452; V r_ = (g_heff_2ebuild_2eload_2ecycleAmong(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2458;
  switch (heff_tag_of(v_t_2453)) {
  case TAG_Nothing: {
    v_t_2458 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_c_2454 = heff_field(v_t_2453, 0);
    heff_take_n(v_t_2453, 1ULL, 1);
    V v_t_2457;
    switch (heff_tag_of(v_c_2454)) {
    case TAG_Nil: {
      v_t_2457 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2455 = heff_field(v_c_2454, 0);
      V v_xs_2456 = heff_field(v_c_2454, 1);
      heff_take_n(v_c_2454, 3ULL, 2);
      v_t_2457 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str9); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
      break;
    }
    default: heff_nomatch(v_c_2454);
    }
    v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str10), v_t_2457), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2453);
  }
  V v_x_2459 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2443, (g_prelude_2e_2b_2b(v_t_2446, v_t_2458))});
  V f_ = v_k_2410;
  args[0] = v_x_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_x_2419 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2426;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    v_t_2426 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2425 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    v_t_2426 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  V v_x_2427 = (g_list_2emap_24s1462590149x1582455373(v_t_2426));
  V v_t_2429 = heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam7_clo)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_249, heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam8, 1, 6, (V[]){v_root_247, v_ps_240, v_x_2427, v_x_2419, v_x_2411, v_k_2410})));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2417 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V v_x_2419 = (g_list_2emap_24s1462590149x1582455373(v_t_2418));
  V v_t_2421 = heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam5_clo)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam6, 1, 6, (V[]){v_ps_240, v_hd_249, v_root_247, v_x_2419, v_x_2411, v_k_2410})));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(heff_rfield(v_ps_240, 1)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam3_clo)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam4, 1, 5, (V[]){v_ps_240, v_hd_249, v_root_247, v_x_2411, v_k_2410})));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam2, 1, 4, (V[]){v_ps_240, v_hd_249, v_root_247, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_entry, 3, 0};

V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688(V v_x2_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_pl_243 = heff_field(v_x2_240, 0);
    V v_rest_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_ReadFile, 2, (V[]){heff_dup(heff_rfield(v_pl_243, 0)), ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam0_clo)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    HEFF_LAST return g_co_2eop_24s1084803226x1249263831(heff_tag_n(TAG_InR, 1, (V[]){v_t_248}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam1, 1, 4, (V[]){v_rest_244, v_p_241, v_pl_243, v_p_242}));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam0(V self, V *args) {
  V v_a_245 = args[0];
  return v_a_245;
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_pl_243 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_243, 4);
    v_x_2413 = v_x_2410;
    break;
  }
  case TAG_Just: {
    V v_s_2411 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2412 = heff_rec_n(4, shape_path__source__place__module, (V[]){heff_dup(heff_rfield(v_pl_243, 0)), v_s_2411, heff_dup(v_pl_243), heff_get_n(v_pl_243, 3, 4)});
    v_x_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_x_2410});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_p_242;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_pl_243 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688(v_rest_244, v_p_241, heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam2, 1, 3, (V[]){v_x_249, v_pl_243, v_p_242})));
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0, 1, 0};
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_entry, 5, 0};

V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(V v_ps_240, V v_d_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_Nothing)});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_ReadDir, 2, (V[]){heff_dup(v_d_241), ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s954557541x749476273(v_t_2410, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam1, 1, 6, (V[]){v_p_244, v_x_245, v_ps_240, v_d_241, v_rest_246, v_p_243})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0(V self, V *args) {
  V v_ns_247 = args[0];
  return v_ns_247;
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2eload_2esameButCase(v_n_2413, v_x_245));
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    heff_drop(v_x_245);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_rest_246);
    heff_drop(v_p_243);
    V f_ = v_p_244;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_ns_2412 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    V v_t_2414 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam2, 1, 1, (V[]){heff_dup(v_x_245)}), v_ns_2412));
    V v_t_2415 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = heff_dup(v_d_241); V a_2 = heff_dup(v_x_245); V a_3 = v_t_2414; V r_ = (g_heff_2ebuild_2eload_2ecasesIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      V v_st_2416 = heff_dup(heff_rfield(v_ps_240, 5));
      V v_t_2417 = (g_std_2epath_2eparse(v_st_2416, v_d_241));
      V v_t_2418 = (g_std_2epath_2eparse(v_st_2416, v_x_245));
      V v_p_2419 = (g_std_2epath_2ejoin_2eonto_240(v_t_2417, v_t_2418));
      V v_t_2420 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2419, 1)), heff_rfield(v_p_2419, 2)));
      V v_t_2421 = ({ V rv_2 = v_t_2420; V rr_ = heff_rec_reuse_n(v_p_2419, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2422 = ({ V a_0 = v_st_2416; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); r_; });
      return (g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(v_ps_240, v_t_2422, v_rest_246, v_p_243, v_p_244));
    }
    case TAG_Just: {
      V v_why_2423 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop(v_x_245);
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_d_241);
      heff_drop(v_rest_246);
      heff_drop(v_p_243);
      V f_ = v_p_244;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_why_2423});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2415);
    }
  }
  default: return heff_nomatch(v_x_2411);
  }
}
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str0, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str1, 2, (44, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str2, 12, (58, 32, 110, 111, 32, 109, 111, 100, 117, 108, 101, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str3, 13, (32, 40, 108, 111, 111, 107, 101, 100, 32, 102, 111, 114, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str4, 1, (41));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str5, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str6, 4, (32, 45, 62, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str7, 12, (58, 32, 105, 109, 112, 111, 114, 116, 105, 110, 103, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str8, 13, (32, 105, 115, 32, 97, 32, 99, 121, 99, 108, 101, 58, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str9, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str10, 5, (32, 97, 110, 100, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str11, 9, (58, 32, 109, 111, 100, 117, 108, 101, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str12, 24, (32, 105, 115, 32, 109, 111, 114, 101, 32, 116, 104, 97, 110, 32, 111, 110, 101, 32, 102, 105, 108, 101, 58, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str13, 12, (58, 32, 105, 109, 112, 111, 114, 116, 105, 110, 103, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str14, 2, (58, 32));
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_entry, 8, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(V v_ps_240, V v_pkgs_241, V v_stack_242, V v_from_243, V v_imp_244, V v_x7_245, V v_st_246, V v_rs_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_stack_242);
    heff_drop(v_from_243);
    heff_drop(v_imp_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam0, 2, 2, (V[]){v_st_246, v_rs_247});
  }
  case TAG_Cons: {
    V v_w_2410 = heff_field(v_x7_245, 0);
    V v_rest_2411 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2412 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_2410)));
    V v_c_2413 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_clo), 1, (V[]){v_t_2412}));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam1, 2, 10, (V[]){v_c_2413, v_ps_240, v_pkgs_241, v_from_243, v_w_2410, v_st_246, v_stack_242, v_imp_244, v_rest_2411, v_rs_247});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_st_246 = heff_env(self)[0];
  V v_rs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_246, v_rs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam4(V self, V *args) {
  V v_x_2476 = args[0];
  V v_imp_244 = heff_env(self)[0];
  V v_f_2427 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_rs_247 = heff_env(self)[4];
  V v_pkgs_241 = heff_env(self)[5];
  V v_stack_242 = heff_env(self)[6];
  V v_from_243 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_hd_2414 = heff_env(self)[9];
  V v_k_2415 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2479;
  switch (heff_tag_of(v_x_2476)) {
  case TAG_MkPair: {
    V v_x_2477 = heff_dup(heff_field(v_x_2476, 0));
    v_t_2479 = v_x_2477;
    break;
  }
  default: heff_nomatch(v_x_2476);
  }
  V v_t_2480 = heff_tr(heff_apply(heff_dup(v_imp_244), 1, (V[]){heff_dup(heff_rfield(v_f_2427, 3))}));
  V v_t_2483;
  switch (heff_tag_of(v_x_2476)) {
  case TAG_MkPair: {
    V v_y_2482 = heff_field(v_x_2476, 1);
    heff_take_n(v_x_2476, 2ULL, 2);
    v_t_2483 = v_y_2482;
    break;
  }
  default: heff_nomatch(v_x_2476);
  }
  V v_t_2484 = (g_heff_2ebuild_2eload_2epushDone(v_t_2479, heff_dup(v_ps_240), heff_dup(heff_rfield(v_f_2427, 3)), heff_take_field(v_f_2427, 0), heff_take_field(v_f_2427, 1), v_t_2480, v_t_2483));
  V v_m_2485 = heff_get_n(v_f_2427, 3, 4);
  V v_t_2487;
  if (heff_strEq_c(heff_dup(v_w_2410), heff_dup(v_m_2485))) {
    heff_drop(v_w_2410);
    heff_drop(v_m_2485);
    v_t_2487 = v_rs_247;
  } else {
    v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2485}), v_rs_247});
  }
  V v_t_2488 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2484, v_t_2487));
  return heff_tail(v_t_2488, 2, (V[]){v_hd_2414, v_k_2415});
}
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam3(V self, V *args) {
  V v_x_2454 = args[0];
  V v_f_2427 = heff_env(self)[0];
  V v_stack_242 = heff_env(self)[1];
  V v_imp_244 = heff_env(self)[2];
  V v_others_2428 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  V v_from_243 = heff_env(self)[6];
  V v_w_2410 = heff_env(self)[7];
  V v_ps_240 = heff_env(self)[8];
  V v_pkgs_241 = heff_env(self)[9];
  V v_hd_2414 = heff_env(self)[10];
  V v_rs_247 = heff_env(self)[11];
  V v_rest_2411 = heff_env(self)[12];
  V v_k_2415 = heff_env(self)[13];
  heff_clo_take(self, 14);
  V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2427, 3)), heff_dup(v_stack_242)});
  V v_t_2456 = heff_tr(heff_apply(heff_dup(v_imp_244), 1, (V[]){heff_dup(heff_rfield(v_f_2427, 3))}));
  V v_t_2457 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2456, heff_dup(heff_rfield(v_f_2427, 1))));
  V v_imps_2458 = heff_get_n(v_t_2457, 0, 3);
  V v_t_2459 = (g_list_2emap_24s424270175x1918189508(v_imps_2458));
  V v_t_2460 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2459));
  V v_t_2474;
  switch (heff_tag_of(v_x_2454)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_others_2428)) {
    case TAG_Nil: {
      heff_drop_tag(v_x_2416, 2);
      v_t_2474 = v_st_246;
      break;
    }
    case TAG_Cons: {
      V v_ru_24others_2428_24Cons = heff_take_reuse_n(v_others_2428, 0ULL, 2);
      V v_x2_2463 = (g_list_2emap_24s1900047848x1273517071(v_x_2416));
      V v_t_2466;
      switch (heff_tag_of(v_x2_2463)) {
      case TAG_Nil: {
        v_t_2466 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str9);
        break;
      }
      case TAG_Cons: {
        V v_x_2464 = heff_field(v_x2_2463, 0);
        V v_xs_2465 = heff_field(v_x2_2463, 1);
        heff_take_n(v_x2_2463, 3ULL, 2);
        v_t_2466 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str10); V a_1 = v_x_2464; V a_2 = v_xs_2465; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2465); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2463);
      }
      V v_e_2467 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str11), heff_strAppend(heff_dup(v_w_2410), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str12), v_t_2466))));
      V v_t_2468 = heff_tag_at_n(v_ru_24others_2428_24Cons, TAG_Cons, 2, (V[]){v_e_2467, NTAG(TAG_Nil)});
      V v_t_2469 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2468));
      v_t_2474 = ({ V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_n(v_st_246, 3ULL, 3, shape_done__doneMods__errors); heff_rfield(rr_, 2) = rv_2; rr_; });
      break;
    }
    default: heff_nomatch(v_others_2428);
    }
    break;
  }
  case TAG_Just: {
    V v_why_2470 = heff_field(v_x_2454, 0);
    heff_take_n(v_x_2454, 1ULL, 1);
    heff_drop(v_others_2428);
    heff_drop_tag(v_x_2416, 2);
    V v_t_2471 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str13), heff_strAppend(heff_dup(v_w_2410), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str14), v_why_2470))));
    V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2471, NTAG(TAG_Nil)});
    V v_t_2473 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2472));
    v_t_2474 = ({ V rv_2 = v_t_2473; V rr_ = heff_rec_reuse_n(v_st_246, 3ULL, 3, shape_done__doneMods__errors); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2454);
  }
  V v_c_2475 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(heff_dup(v_ps_240), heff_dup(v_pkgs_241), v_t_2455, heff_dup(heff_rfield(v_f_2427, 0)), heff_dup(v_imp_244), v_t_2460, v_t_2474, NTAG(TAG_Nil)));
  return heff_tail(v_c_2475, 2, (V[]){heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam4, 1, 11, (V[]){v_imp_244, v_f_2427, v_ps_240, v_w_2410, v_rs_247, v_pkgs_241, v_stack_242, v_from_243, v_rest_2411, v_hd_2414, v_k_2415})});
}
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_pkgs_241 = heff_env(self)[1];
  V v_from_243 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_stack_242 = heff_env(self)[5];
  V v_imp_244 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_rs_247 = heff_env(self)[8];
  V v_hd_2414 = heff_env(self)[9];
  V v_k_2415 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nil: {
    V v_places_2417 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_2410)));
    V v_x2_2418 = (g_list_2emap_24s201309086x301344224(v_places_2417));
    V v_t_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_t_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str1); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_e_2422 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str2), heff_strAppend(v_w_2410, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str3), heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str4))))));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2422, NTAG(TAG_Nil)});
    V v_t_2424 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2423));
    V v_t_2425 = ({ V rv_2 = v_t_2424; V rr_ = heff_rec_reuse_n(v_st_246, 3ULL, 3, shape_done__doneMods__errors); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2426 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2425, v_rs_247));
    return heff_tail(v_t_2426, 2, (V[]){v_hd_2414, v_k_2415});
  }
  case TAG_Cons: {
    V v_f_2427 = heff_dup(heff_field(v_x_2416, 0));
    V v_others_2428 = heff_dup(heff_field(v_x_2416, 1));
    V v_t_2429 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2427, 3))}));
    V v_t_2430 = (g_list_2eany(v_t_2429, heff_rfield(v_st_246, 1)));
    switch (heff_tag_of(v_t_2430)) {
    case TAG_True: {
      heff_drop_tag(v_x_2416, 2);
      heff_drop(v_others_2428);
      V v_m_2431 = heff_get_n(v_f_2427, 3, 4);
      V v_t_2433;
      if (heff_strEq_c(heff_dup(v_w_2410), heff_dup(v_m_2431))) {
        heff_drop(v_w_2410);
        heff_drop(v_m_2431);
        v_t_2433 = v_rs_247;
      } else {
        v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2431}), v_rs_247});
      }
      V v_t_2434 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_st_246, v_t_2433));
      return heff_tail(v_t_2434, 2, (V[]){v_hd_2414, v_k_2415});
    }
    case TAG_False: {
      V v_t_2435 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2427, 3))}));
      V v_t_2436 = (g_list_2eany(v_t_2435, v_stack_242));
      switch (heff_tag_of(v_t_2436)) {
      case TAG_True: {
        heff_drop_tag(v_x_2416, 2);
        heff_drop(v_others_2428);
        V v_m_2437 = heff_dup(heff_rfield(v_f_2427, 3));
        V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_242)));
        V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2437), NTAG(TAG_Nil)});
        V v_x2_2440 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2439));
        V v_t_2443;
        switch (heff_tag_of(v_x2_2440)) {
        case TAG_Nil: {
          v_t_2443 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2441 = heff_field(v_x2_2440, 0);
          V v_xs_2442 = heff_field(v_x2_2440, 1);
          heff_take_n(v_x2_2440, 3ULL, 2);
          v_t_2443 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str6); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2440);
        }
        V v_e_2444 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str7), heff_strAppend(v_m_2437, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str8), v_t_2443))));
        V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2444, NTAG(TAG_Nil)});
        V v_t_2446 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2445));
        V v_t_2447 = ({ V rv_2 = v_t_2446; V rr_ = heff_rec_reuse_n(v_st_246, 3ULL, 3, shape_done__doneMods__errors); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2448 = heff_get_n(v_f_2427, 3, 4);
        V v_t_2450;
        if (heff_strEq_c(heff_dup(v_w_2410), heff_dup(v_m_2448))) {
          heff_drop(v_w_2410);
          heff_drop(v_m_2448);
          v_t_2450 = v_rs_247;
        } else {
          v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2448}), v_rs_247});
        }
        V v_t_2451 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2447, v_t_2450));
        return heff_tail(v_t_2451, 2, (V[]){v_hd_2414, v_k_2415});
      }
      case TAG_False: {
        V v_t_2452 = heff_get_n(heff_dup(heff_rfield(v_f_2427, 2)), 1, 4);
        V v_t_2453 = heff_get_n(heff_dup(heff_rfield(v_f_2427, 2)), 2, 4);
        return (g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(heff_dup(v_ps_240), v_t_2452, v_t_2453, heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam3, 1, 14, (V[]){v_f_2427, v_stack_242, v_imp_244, v_others_2428, v_st_246, v_x_2416, v_from_243, v_w_2410, v_ps_240, v_pkgs_241, v_hd_2414, v_rs_247, v_rest_2411, v_k_2415})));
      }
      default: return heff_nomatch(v_t_2436);
      }
    }
    default: return heff_nomatch(v_t_2430);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_pkgs_241 = heff_env(self)[2];
  V v_from_243 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_st_246 = heff_env(self)[5];
  V v_stack_242 = heff_env(self)[6];
  V v_imp_244 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam2, 1, 11, (V[]){v_ps_240, v_pkgs_241, v_from_243, v_w_2410, v_st_246, v_stack_242, v_imp_244, v_rest_2411, v_rs_247, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam2(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_entry, 6, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(V v_ps_240, V v_pkgs_241, V v_from_242, V v_before_243, V v_x6_244, V v_st_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_before_243);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam0, 2, 1, (V[]){v_st_245});
  }
  case TAG_Cons: {
    V v_m_248 = heff_field(v_x6_244, 0);
    V v_ms_249 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_2410 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_248), NTAG(TAG_Nil)});
    V v_c_2412 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(heff_dup(v_ps_240), heff_dup(v_pkgs_241), NTAG(TAG_Nil), heff_dup(v_from_242), heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam1, 1, 1, (V[]){heff_dup(v_before_243)}), v_t_2410, v_st_245, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam2, 2, 7, (V[]){v_c_2412, v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_st_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_before_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2411);
  return v_before_243;
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_before_243 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_pkgs_241 = heff_env(self)[3];
  V v_from_242 = heff_env(self)[4];
  V v_ms_249 = heff_env(self)[5];
  V v_hd_2413 = heff_env(self)[6];
  V v_k_2414 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_248, NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_before_243, v_t_2416));
  V v_t_2420;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 2);
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2421 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(v_ps_240, v_pkgs_241, v_from_242, v_t_2417, v_ms_249, v_t_2420));
  return heff_tail(v_t_2421, 2, (V[]){v_hd_2413, v_k_2414});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_m_248 = heff_env(self)[1];
  V v_before_243 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_pkgs_241 = heff_env(self)[4];
  V v_from_242 = heff_env(self)[5];
  V v_ms_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam3, 1, 8, (V[]){v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_str0, 12, (99, 97, 110, 110, 111, 116, 32, 114, 101, 97, 100, 32));
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam4(V self, V *args); static Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam4, 1, 0};
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam9(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam11(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam10(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam13(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam12(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_entry, 2, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291(V v_h_240, V v_file_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(v_h_240, heff_dup(v_file_241)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam0, 2, 2, (V[]){v_c_242, v_file_241});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam4(V self, V *args) {
  V v_a_2414 = args[0];
  return v_a_2414;
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2429;
  args[0] = heff_get_n(v_x_2430, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2427;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam7, 1, 1, (V[]){v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam9(V self, V *args) {
  V v_s_2439 = args[0];
  V v_m_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_s_2439, 0, 7), v_m_2438);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam11(V self, V *args) {
  V v_s_2448 = args[0];
  V v_m_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_s_2448, 0, 7), v_m_2447);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam10(V self, V *args) {
  V v_m_2447 = args[0];
  V v_x_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam11, 1, 1, (V[]){v_m_2447}); V a_1 = v_x_2432; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_x_2432); r_; });
  switch (heff_tag_of(v_t_2449)) {
  case TAG_Nothing: {
    return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
  }
  case TAG_Just: {
    V v_s_2450 = heff_field(v_t_2449, 0);
    heff_take_n(v_t_2449, 1ULL, 1);
    return heff_get_n(v_s_2450, 5, 7);
  }
  default: return heff_nomatch(v_t_2449);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam13(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_s_2458, 0, 7), v_m_2457);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam12(V self, V *args) {
  V v_x_2452 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_x_2432 = heff_env(self)[2];
  V v_src_2423 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2455;
  switch (heff_tag_of(v_x_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_dup(heff_field(v_x_2452, 0));
    v_t_2455 = v_x_2453;
    break;
  }
  default: heff_nomatch(v_x_2452);
  }
  V v_t_2456 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_m_2457 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_2459 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam13, 1, 1, (V[]){v_m_2457}); V a_1 = v_x_2432; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_x_2432); r_; });
  V v_t_2461;
  switch (heff_tag_of(v_t_2459)) {
  case TAG_Nothing: {
    v_t_2461 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    break;
  }
  case TAG_Just: {
    V v_s_2460 = heff_field(v_t_2459, 0);
    heff_take_n(v_t_2459, 1ULL, 1);
    v_t_2461 = heff_get_n(v_s_2460, 5, 7);
    break;
  }
  default: heff_nomatch(v_t_2459);
  }
  V v_t_2464;
  switch (heff_tag_of(v_x_2452)) {
  case TAG_MkPair: {
    V v_y_2463 = heff_field(v_x_2452, 1);
    heff_take_n(v_x_2452, 2ULL, 2);
    v_t_2464 = v_y_2463;
    break;
  }
  default: heff_nomatch(v_x_2452);
  }
  V v_t_2465 = (g_heff_2ebuild_2eload_2epushDone(v_t_2455, heff_dup(v_x_245), v_t_2456, v_file_241, v_src_2423, v_t_2461, v_t_2464));
  V v_x_2466 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_2465; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
  V f_ = v_k_244;
  args[0] = v_x_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam8(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_src_2423 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_x_247 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2435;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_dup(heff_field(v_x_2413, 0));
    v_t_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2436 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
  V v_m_2438 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_2440 = (g_list_2efind(heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam9, 1, 1, (V[]){v_m_2438}), v_x_2432));
  V v_t_2442;
  switch (heff_tag_of(v_t_2440)) {
  case TAG_Nothing: {
    v_t_2442 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    break;
  }
  case TAG_Just: {
    V v_s_2441 = heff_field(v_t_2440, 0);
    heff_take_n(v_t_2440, 1ULL, 1);
    v_t_2442 = heff_get_n(v_s_2441, 5, 7);
    break;
  }
  default: heff_nomatch(v_t_2440);
  }
  V v_t_2443 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2442, heff_dup(v_src_2423)));
  V v_imps_2444 = heff_get_n(v_t_2443, 0, 3);
  V v_t_2445 = (g_list_2emap_24s424270175x1918189508(v_imps_2444));
  V v_t_2446 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2445));
  V v_c_2451 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(heff_dup(v_x_245), v_t_2435, v_t_2437, heff_dup(v_file_241), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam10, 1, 1, (V[]){heff_dup(v_x_2432)}), v_t_2446, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
  return heff_tail(v_c_2451, 2, (V[]){v_hd_243, heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam12, 1, 7, (V[]){v_x_245, v_file_241, v_x_2432, v_src_2423, v_x_247, v_x_2413, v_k_244})});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_str0), v_file_241), NTAG(TAG_Nil)});
    V v_t_2420 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_t_2419));
    V v_t_2421 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2420});
    V v_x_2422 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_2421; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
    V f_ = v_k_244;
    args[0] = v_x_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2423 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    V v_pkgs_2426;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_dup(heff_field(v_x_2413, 0));
      v_pkgs_2426 = v_x_2424;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_c_2427 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(heff_dup(v_x_245), v_pkgs_2426, heff_dup(v_file_241), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get())));
    V v_c_2431 = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam6, 2, 1, (V[]){v_c_2427});
    return heff_tail(v_c_2431, 2, (V[]){heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam8, 1, 7, (V[]){v_x_2413, v_x_245, v_file_241, v_src_2423, v_hd_243, v_x_247, v_k_244})});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_file_241), ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam4_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s1084803226x1249263831(v_t_2417, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam5, 1, 6, (V[]){v_file_241, v_x_245, v_x_247, v_x_2413, v_k_244, v_hd_243})));
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_248 = heff_dup(heff_field(v_x_247, 0));
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      heff_take_n(v_x11_248, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Just, 1, (V[]){v_p_2410});
      break;
    }
    default: heff_nomatch(v_x11_248);
    }
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_c_2412 = (g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101(heff_dup(v_x_245), v_t_2411));
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam3, 1, 5, (V[]){v_file_241, v_hd_243, v_x_245, v_x_247, v_k_244})});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = (g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738(heff_dup(v_x_245)));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_file_241, v_k_244})});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam1, 1, 3, (V[]){v_hd_243, v_file_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0, 2, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(V v_read_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    return ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0_clo);
  }
  case TAG_Cons: {
    V v_pl_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_apply(heff_dup(v_read_240), 1, (V[]){heff_dup(heff_rfield(v_pl_244, 0))}));
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam1, 2, 4, (V[]){v_c_246, v_read_240, v_rest_245, v_pl_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_pl_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2414;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_244, 4);
    v_x_2414 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_s_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2413 = heff_rec_n(4, shape_path__source__place__module, (V[]){heff_dup(heff_rfield(v_pl_244, 0)), v_s_2412, heff_dup(v_pl_244), heff_get_n(v_pl_244, 3, 4)});
    v_x_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(v_read_240, v_rest_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam3, 1, 3, (V[]){v_x_249, v_pl_244, v_k_248})});
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam2, 1, 5, (V[]){v_read_240, v_rest_245, v_hd_247, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str0, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str1, 2, (44, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str2, 12, (58, 32, 110, 111, 32, 109, 111, 100, 117, 108, 101, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str3, 13, (32, 40, 108, 111, 111, 107, 101, 100, 32, 102, 111, 114, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str4, 1, (41));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str5, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str6, 4, (32, 45, 62, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str7, 12, (58, 32, 105, 109, 112, 111, 114, 116, 105, 110, 103, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str8, 13, (32, 105, 115, 32, 97, 32, 99, 121, 99, 108, 101, 58, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str9, 0, (0));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str10, 5, (32, 97, 110, 100, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str11, 9, (58, 32, 109, 111, 100, 117, 108, 101, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str12, 24, (32, 105, 115, 32, 109, 111, 114, 101, 32, 116, 104, 97, 110, 32, 111, 110, 101, 32, 102, 105, 108, 101, 58, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str13, 12, (58, 32, 105, 109, 112, 111, 114, 116, 105, 110, 103, 32));
HEFF_STRA(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str14, 2, (58, 32));
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_entry, 9, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(V v_read_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_imp_245, V v_x7_246, V v_st_247, V v_rs_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_stack_243);
    heff_drop(v_from_244);
    heff_drop(v_imp_245);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam0, 2, 2, (V[]){v_st_247, v_rs_248});
  }
  case TAG_Cons: {
    V v_w_2411 = heff_field(v_x7_246, 0);
    V v_rest_2412 = heff_field(v_x7_246, 1);
    heff_take_n(v_x7_246, 3ULL, 2);
    V v_t_2413 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_c_2414 = (g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(heff_dup(v_read_240), v_t_2413));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam1, 2, 11, (V[]){v_c_2414, v_ps_241, v_pkgs_242, v_from_244, v_w_2411, v_st_247, v_read_240, v_stack_243, v_imp_245, v_rest_2412, v_rs_248});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_247 = heff_env(self)[0];
  V v_rs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_247, v_rs_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam4(V self, V *args) {
  V v_x_2477 = args[0];
  V v_imp_245 = heff_env(self)[0];
  V v_f_2428 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_rs_248 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_pkgs_242 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_from_244 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2480;
  switch (heff_tag_of(v_x_2477)) {
  case TAG_MkPair: {
    V v_x_2478 = heff_dup(heff_field(v_x_2477, 0));
    v_t_2480 = v_x_2478;
    break;
  }
  default: heff_nomatch(v_x_2477);
  }
  V v_t_2481 = heff_tr(heff_apply(heff_dup(v_imp_245), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
  V v_t_2484;
  switch (heff_tag_of(v_x_2477)) {
  case TAG_MkPair: {
    V v_y_2483 = heff_field(v_x_2477, 1);
    heff_take_n(v_x_2477, 2ULL, 2);
    v_t_2484 = v_y_2483;
    break;
  }
  default: heff_nomatch(v_x_2477);
  }
  V v_t_2485 = (g_heff_2ebuild_2eload_2epushDone(v_t_2480, heff_dup(v_ps_241), heff_dup(heff_rfield(v_f_2428, 3)), heff_take_field(v_f_2428, 0), heff_take_field(v_f_2428, 1), v_t_2481, v_t_2484));
  V v_m_2486 = heff_get_n(v_f_2428, 3, 4);
  V v_t_2488;
  if (heff_strEq_c(heff_dup(v_w_2411), heff_dup(v_m_2486))) {
    heff_drop(v_w_2411);
    heff_drop(v_m_2486);
    v_t_2488 = v_rs_248;
  } else {
    v_t_2488 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2486}), v_rs_248});
  }
  V v_t_2489 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2485, v_t_2488));
  return heff_tail(v_t_2489, 2, (V[]){v_hd_2415, v_k_2416});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam3(V self, V *args) {
  V v_x_2455 = args[0];
  V v_f_2428 = heff_env(self)[0];
  V v_stack_243 = heff_env(self)[1];
  V v_imp_245 = heff_env(self)[2];
  V v_others_2429 = heff_env(self)[3];
  V v_st_247 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_from_244 = heff_env(self)[6];
  V v_w_2411 = heff_env(self)[7];
  V v_read_240 = heff_env(self)[8];
  V v_ps_241 = heff_env(self)[9];
  V v_pkgs_242 = heff_env(self)[10];
  V v_hd_2415 = heff_env(self)[11];
  V v_rs_248 = heff_env(self)[12];
  V v_rest_2412 = heff_env(self)[13];
  V v_k_2416 = heff_env(self)[14];
  heff_clo_take(self, 15);
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2428, 3)), heff_dup(v_stack_243)});
  V v_t_2457 = heff_tr(heff_apply(heff_dup(v_imp_245), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
  V v_t_2458 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2457, heff_dup(heff_rfield(v_f_2428, 1))));
  V v_imps_2459 = heff_get_n(v_t_2458, 0, 3);
  V v_t_2460 = (g_list_2emap_24s424270175x1918189508(v_imps_2459));
  V v_t_2461 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2460));
  V v_t_2475;
  switch (heff_tag_of(v_x_2455)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_others_2429)) {
    case TAG_Nil: {
      heff_drop_tag(v_x_2417, 2);
      v_t_2475 = v_st_247;
      break;
    }
    case TAG_Cons: {
      V v_ru_24others_2429_24Cons = heff_take_reuse_n(v_others_2429, 0ULL, 2);
      V v_x2_2464 = (g_list_2emap_24s1900047848x1273517071(v_x_2417));
      V v_t_2467;
      switch (heff_tag_of(v_x2_2464)) {
      case TAG_Nil: {
        v_t_2467 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str9);
        break;
      }
      case TAG_Cons: {
        V v_x_2465 = heff_field(v_x2_2464, 0);
        V v_xs_2466 = heff_field(v_x2_2464, 1);
        heff_take_n(v_x2_2464, 3ULL, 2);
        v_t_2467 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str10); V a_1 = v_x_2465; V a_2 = v_xs_2466; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2466); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2464);
      }
      V v_e_2468 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str11), heff_strAppend(heff_dup(v_w_2411), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str12), v_t_2467))));
      V v_t_2469 = heff_tag_at_n(v_ru_24others_2429_24Cons, TAG_Cons, 2, (V[]){v_e_2468, NTAG(TAG_Nil)});
      V v_t_2470 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2469));
      v_t_2475 = ({ V rv_2 = v_t_2470; V rr_ = heff_rec_reuse_n(v_st_247, 3ULL, 3, shape_done__doneMods__errors); heff_rfield(rr_, 2) = rv_2; rr_; });
      break;
    }
    default: heff_nomatch(v_others_2429);
    }
    break;
  }
  case TAG_Just: {
    V v_why_2471 = heff_field(v_x_2455, 0);
    heff_take_n(v_x_2455, 1ULL, 1);
    heff_drop(v_others_2429);
    heff_drop_tag(v_x_2417, 2);
    V v_t_2472 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str13), heff_strAppend(heff_dup(v_w_2411), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str14), v_why_2471))));
    V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2472, NTAG(TAG_Nil)});
    V v_t_2474 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2473));
    v_t_2475 = ({ V rv_2 = v_t_2474; V rr_ = heff_rec_reuse_n(v_st_247, 3ULL, 3, shape_done__doneMods__errors); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2455);
  }
  V v_c_2476 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), v_t_2456, heff_dup(heff_rfield(v_f_2428, 0)), heff_dup(v_imp_245), v_t_2461, v_t_2475, NTAG(TAG_Nil)));
  return heff_tail(v_c_2476, 2, (V[]){heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam4, 1, 12, (V[]){v_imp_245, v_f_2428, v_ps_241, v_w_2411, v_rs_248, v_read_240, v_pkgs_242, v_stack_243, v_from_244, v_rest_2412, v_hd_2415, v_k_2416})});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_pkgs_242 = heff_env(self)[1];
  V v_from_244 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_st_247 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_imp_245 = heff_env(self)[7];
  V v_rest_2412 = heff_env(self)[8];
  V v_rs_248 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nil: {
    V v_places_2418 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_x2_2419 = (g_list_2emap_24s201309086x301344224(v_places_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str1); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_e_2423 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str2), heff_strAppend(v_w_2411, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str3), heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str4))))));
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2423, NTAG(TAG_Nil)});
    V v_t_2425 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2424));
    V v_t_2426 = ({ V rv_2 = v_t_2425; V rr_ = heff_rec_reuse_n(v_st_247, 3ULL, 3, shape_done__doneMods__errors); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2427 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2426, v_rs_248));
    return heff_tail(v_t_2427, 2, (V[]){v_hd_2415, v_k_2416});
  }
  case TAG_Cons: {
    V v_f_2428 = heff_dup(heff_field(v_x_2417, 0));
    V v_others_2429 = heff_dup(heff_field(v_x_2417, 1));
    V v_t_2430 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
    V v_t_2431 = (g_list_2eany(v_t_2430, heff_rfield(v_st_247, 1)));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      heff_drop_tag(v_x_2417, 2);
      heff_drop(v_others_2429);
      V v_m_2432 = heff_get_n(v_f_2428, 3, 4);
      V v_t_2434;
      if (heff_strEq_c(heff_dup(v_w_2411), heff_dup(v_m_2432))) {
        heff_drop(v_w_2411);
        heff_drop(v_m_2432);
        v_t_2434 = v_rs_248;
      } else {
        v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2432}), v_rs_248});
      }
      V v_t_2435 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_st_247, v_t_2434));
      return heff_tail(v_t_2435, 2, (V[]){v_hd_2415, v_k_2416});
    }
    case TAG_False: {
      V v_t_2436 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
      V v_t_2437 = (g_list_2eany(v_t_2436, v_stack_243));
      switch (heff_tag_of(v_t_2437)) {
      case TAG_True: {
        heff_drop_tag(v_x_2417, 2);
        heff_drop(v_others_2429);
        V v_m_2438 = heff_dup(heff_rfield(v_f_2428, 3));
        V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_243)));
        V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2438), NTAG(TAG_Nil)});
        V v_x2_2441 = (g_prelude_2e_2b_2b(v_t_2439, v_t_2440));
        V v_t_2444;
        switch (heff_tag_of(v_x2_2441)) {
        case TAG_Nil: {
          v_t_2444 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2442 = heff_field(v_x2_2441, 0);
          V v_xs_2443 = heff_field(v_x2_2441, 1);
          heff_take_n(v_x2_2441, 3ULL, 2);
          v_t_2444 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str6); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2441);
        }
        V v_e_2445 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str7), heff_strAppend(v_m_2438, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str8), v_t_2444))));
        V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2445, NTAG(TAG_Nil)});
        V v_t_2447 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2446));
        V v_t_2448 = ({ V rv_2 = v_t_2447; V rr_ = heff_rec_reuse_n(v_st_247, 3ULL, 3, shape_done__doneMods__errors); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2449 = heff_get_n(v_f_2428, 3, 4);
        V v_t_2451;
        if (heff_strEq_c(heff_dup(v_w_2411), heff_dup(v_m_2449))) {
          heff_drop(v_w_2411);
          heff_drop(v_m_2449);
          v_t_2451 = v_rs_248;
        } else {
          v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2449}), v_rs_248});
        }
        V v_t_2452 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2448, v_t_2451));
        return heff_tail(v_t_2452, 2, (V[]){v_hd_2415, v_k_2416});
      }
      case TAG_False: {
        V v_t_2453 = heff_get_n(heff_dup(heff_rfield(v_f_2428, 2)), 1, 4);
        V v_t_2454 = heff_get_n(heff_dup(heff_rfield(v_f_2428, 2)), 2, 4);
        return (g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(heff_dup(v_ps_241), v_t_2453, v_t_2454, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam3, 1, 15, (V[]){v_f_2428, v_stack_243, v_imp_245, v_others_2429, v_st_247, v_x_2417, v_from_244, v_w_2411, v_read_240, v_ps_241, v_pkgs_242, v_hd_2415, v_rs_248, v_rest_2412, v_k_2416})));
      }
      default: return heff_nomatch(v_t_2437);
      }
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_pkgs_242 = heff_env(self)[2];
  V v_from_244 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_st_247 = heff_env(self)[5];
  V v_read_240 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_imp_245 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam2, 1, 12, (V[]){v_ps_241, v_pkgs_242, v_from_244, v_w_2411, v_st_247, v_read_240, v_stack_243, v_imp_245, v_rest_2412, v_rs_248, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam2(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_entry, 7, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(V v_read_240, V v_ps_241, V v_pkgs_242, V v_from_243, V v_before_244, V v_x6_245, V v_st_246) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_from_243);
    heff_drop(v_before_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam0, 2, 1, (V[]){v_st_246});
  }
  case TAG_Cons: {
    V v_m_249 = heff_field(v_x6_245, 0);
    V v_ms_2410 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_2411 = heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_249), NTAG(TAG_Nil)});
    V v_c_2413 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), NTAG(TAG_Nil), heff_dup(v_from_243), heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam1, 1, 1, (V[]){heff_dup(v_before_244)}), v_t_2411, v_st_246, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam2, 2, 8, (V[]){v_c_2413, v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_st_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_before_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2412);
  return v_before_244;
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_before_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_pkgs_242 = heff_env(self)[4];
  V v_from_243 = heff_env(self)[5];
  V v_ms_2410 = heff_env(self)[6];
  V v_hd_2414 = heff_env(self)[7];
  V v_k_2415 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_249, NTAG(TAG_Nil)});
  V v_t_2418 = (g_prelude_2e_2b_2b(v_before_244, v_t_2417));
  V v_t_2421;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 2);
    v_t_2421 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V v_t_2422 = (g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_t_2418, v_ms_2410, v_t_2421));
  return heff_tail(v_t_2422, 2, (V[]){v_hd_2414, v_k_2415});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_m_249 = heff_env(self)[1];
  V v_before_244 = heff_env(self)[2];
  V v_read_240 = heff_env(self)[3];
  V v_ps_241 = heff_env(self)[4];
  V v_pkgs_242 = heff_env(self)[5];
  V v_from_243 = heff_env(self)[6];
  V v_ms_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam3, 1, 9, (V[]){v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_str0, 12, (99, 97, 110, 110, 111, 116, 32, 114, 101, 97, 100, 32));
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam10(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam9(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam12(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam11(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_entry, 3, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(V v_read_240, V v_h_241, V v_file_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(v_h_241, heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam0, 2, 3, (V[]){v_c_243, v_read_240, v_file_242});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2427;
  args[0] = heff_get_n(v_x_2428, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam5(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2425;
  args[0] = v_hd_2426;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam6, 1, 1, (V[]){v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam8(V self, V *args) {
  V v_s_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_s_2437, 0, 7), v_m_2436);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam10(V self, V *args) {
  V v_s_2446 = args[0];
  V v_m_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_s_2446, 0, 7), v_m_2445);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam9(V self, V *args) {
  V v_m_2445 = args[0];
  V v_x_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam10, 1, 1, (V[]){v_m_2445}); V a_1 = v_x_2430; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_x_2430); r_; });
  switch (heff_tag_of(v_t_2447)) {
  case TAG_Nothing: {
    return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
  }
  case TAG_Just: {
    V v_s_2448 = heff_field(v_t_2447, 0);
    heff_take_n(v_t_2447, 1ULL, 1);
    return heff_get_n(v_s_2448, 5, 7);
  }
  default: return heff_nomatch(v_t_2447);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam12(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_s_2456, 0, 7), v_m_2455);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam11(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  V v_src_2421 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_x_2414 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2453;
  switch (heff_tag_of(v_x_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_dup(heff_field(v_x_2450, 0));
    v_t_2453 = v_x_2451;
    break;
  }
  default: heff_nomatch(v_x_2450);
  }
  V v_t_2454 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_m_2455 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_t_2457 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam12, 1, 1, (V[]){v_m_2455}); V a_1 = v_x_2430; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_x_2430); r_; });
  V v_t_2459;
  switch (heff_tag_of(v_t_2457)) {
  case TAG_Nothing: {
    v_t_2459 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    break;
  }
  case TAG_Just: {
    V v_s_2458 = heff_field(v_t_2457, 0);
    heff_take_n(v_t_2457, 1ULL, 1);
    v_t_2459 = heff_get_n(v_s_2458, 5, 7);
    break;
  }
  default: heff_nomatch(v_t_2457);
  }
  V v_t_2462;
  switch (heff_tag_of(v_x_2450)) {
  case TAG_MkPair: {
    V v_y_2461 = heff_field(v_x_2450, 1);
    heff_take_n(v_x_2450, 2ULL, 2);
    v_t_2462 = v_y_2461;
    break;
  }
  default: heff_nomatch(v_x_2450);
  }
  V v_t_2463 = (g_heff_2ebuild_2eload_2epushDone(v_t_2453, heff_dup(v_x_246), v_t_2454, v_file_242, v_src_2421, v_t_2459, v_t_2462));
  V v_x_2464 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2463; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
  V f_ = v_k_245;
  args[0] = v_x_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_src_2421 = heff_env(self)[3];
  V v_read_240 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_x_248 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2433;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_dup(heff_field(v_x_2414, 0));
    v_t_2433 = v_x_2431;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2434 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
  V v_m_2436 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_t_2438 = (g_list_2efind(heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam8, 1, 1, (V[]){v_m_2436}), v_x_2430));
  V v_t_2440;
  switch (heff_tag_of(v_t_2438)) {
  case TAG_Nothing: {
    v_t_2440 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    break;
  }
  case TAG_Just: {
    V v_s_2439 = heff_field(v_t_2438, 0);
    heff_take_n(v_t_2438, 1ULL, 1);
    v_t_2440 = heff_get_n(v_s_2439, 5, 7);
    break;
  }
  default: heff_nomatch(v_t_2438);
  }
  V v_t_2441 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2440, heff_dup(v_src_2421)));
  V v_imps_2442 = heff_get_n(v_t_2441, 0, 3);
  V v_t_2443 = (g_list_2emap_24s424270175x1918189508(v_imps_2442));
  V v_t_2444 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2443));
  V v_c_2449 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, heff_dup(v_x_246), v_t_2433, v_t_2435, heff_dup(v_file_242), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam9, 1, 1, (V[]){heff_dup(v_x_2430)}), v_t_2444, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
  return heff_tail(v_c_2449, 2, (V[]){v_hd_244, heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam11, 1, 7, (V[]){v_x_246, v_file_242, v_x_2430, v_src_2421, v_x_248, v_x_2414, v_k_245})});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_hd_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_read_240);
    heff_drop(v_hd_244);
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_str0), v_file_242), NTAG(TAG_Nil)});
    V v_t_2418 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_t_2417));
    V v_t_2419 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2418});
    V v_x_2420 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2419; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
    V f_ = v_k_245;
    args[0] = v_x_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2421 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_pkgs_2424;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_dup(heff_field(v_x_2414, 0));
      v_pkgs_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_c_2425 = (g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(heff_dup(v_read_240), heff_dup(v_x_246), v_pkgs_2424, heff_dup(v_file_242), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get())));
    V v_c_2429 = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam5, 2, 1, (V[]){v_c_2425});
    return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam7, 1, 8, (V[]){v_x_2414, v_x_246, v_file_242, v_src_2421, v_read_240, v_hd_244, v_x_248, v_k_245})});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415 = heff_tr(heff_apply(heff_dup(v_read_240), 1, (V[]){heff_dup(v_file_242)}));
  return heff_tail(v_c_2415, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam4, 1, 7, (V[]){v_file_242, v_x_246, v_x_248, v_x_2414, v_k_245, v_read_240, v_hd_244})});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_249 = heff_dup(heff_field(v_x_248, 0));
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      heff_take_n(v_x11_249, 0ULL, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      v_t_2412 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Just, 1, (V[]){v_p_2411});
      break;
    }
    default: heff_nomatch(v_x11_249);
    }
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_c_2413 = (g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101(heff_dup(v_x_246), v_t_2412));
  return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam3, 1, 6, (V[]){v_read_240, v_file_242, v_hd_244, v_x_246, v_x_248, v_k_245})});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_247 = (g_heff_2ebuild_2eload_2ereadPackageAt_24s1948646494x493576738(heff_dup(v_x_246)));
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam2, 1, 5, (V[]){v_x_246, v_hd_244, v_read_240, v_file_242, v_k_245})});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam1, 1, 4, (V[]){v_hd_244, v_read_240, v_file_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}