// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2etoplevel_2eselfTermF_lam0(V self, V *args);
V g_heff_2etoplevel_2eselfTermF_lam1(V self, V *args);
V g_heff_2etoplevel_2eselfTermF_lam2(V self, V *args);
Clo g_heff_2etoplevel_2eselfTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eselfTermF_entry, 4, 0};

V g_heff_2etoplevel_2eselfTermF(V v_r_240, V v_k_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    heff_drop(v_r_240);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SGlobal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_246 = heff_strEq(heff_dup(v_x_245), v_k_241);
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_x_245);
      return heff_tag_at(v_ru_24t_243_24SGlobal, TAG_SLocal, 1, (V[]){v_d_242});
    }
    case TAG_False: {
      heff_drop(v_d_242);
      return heff_tag_at(v_ru_24t_243_24SGlobal, TAG_SGlobal, 1, (V[]){v_x_245});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_SCode: {
    V v_a_247 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    V v_t_248 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_a_247}));
    return heff_tag_at(v_ru_24t_243_24SCode, TAG_SCode, 1, (V[]){v_t_248});
  }
  case TAG_SApp: {
    V v_f_249 = heff_field(v_t_243, 0);
    V v_a_2410 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SApp = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 2, (V[]){heff_dup(v_d_242), v_f_249}));
    V v_t_2412 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_a_2410}));
    return heff_tag_at(v_ru_24t_243_24SApp, TAG_SApp, 2, (V[]){v_t_2411, v_t_2412});
  }
  case TAG_SLam: {
    V v_dom_2413 = heff_field(v_t_243, 0);
    V v_it2_2414 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SLam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    switch (heff_tag_of(v_it2_2414)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_it2_2414, 0);
      V v_b_2416 = heff_field(v_it2_2414, 1);
      heff_take_n(v_it2_2414, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dom_2413}));
      V v_t_2418 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2416}));
      return heff_tag_at(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2417, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2415, v_t_2418})});
    }
    case TAG_AbsConst: {
      V v_b_2419 = heff_field(v_it2_2414, 0);
      heff_take_n(v_it2_2414, 1ULL, 1);
      V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dom_2413}));
      V v_t_2421 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_b_2419}));
      return heff_tag_at(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2420, heff_tag(TAG_AbsConst, 1, (V[]){v_t_2421})});
    }
    default: return heff_nomatch(v_it2_2414);
    }
  }
  case TAG_SCons: {
    V v_c_2422 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCons = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    V v_f_2423 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_d_242}));
    V v_xs_2424 = heff_get(heff_dup(v_c_2422), LBL_values);
    V v_t_2427 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2424)), heff_clo(g_heff_2etoplevel_2eselfTermF_lam0, 1, 2, (V[]){v_xs_2424, v_f_2423}));
    V v_t_2428 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_c_2422), LBL_keys), heff_get(v_c_2422, LBL_byName), v_t_2427});
    return heff_tag_at(v_ru_24t_243_24SCons, TAG_SCons, 1, (V[]){v_t_2428});
  }
  case TAG_SProj: {
    V v_e_2429 = heff_field(v_t_243, 0);
    V v_l_2430 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SProj = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_t_2431 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2429}));
    return heff_tag_at(v_ru_24t_243_24SProj, TAG_SProj, 2, (V[]){v_t_2431, v_l_2430});
  }
  case TAG_STag: {
    V v_tg_2432 = heff_field(v_t_243, 0);
    V v_as_2433 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24STag = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_f_2434 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_d_242}));
    V v_t_2437 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_as_2433)), heff_clo(g_heff_2etoplevel_2eselfTermF_lam1, 1, 2, (V[]){v_as_2433, v_f_2434}));
    return heff_tag_at(v_ru_24t_243_24STag, TAG_STag, 2, (V[]){v_tg_2432, v_t_2437});
  }
  case TAG_SMatch: {
    V v_e_2438 = heff_field(v_t_243, 0);
    V v_cs_2439 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SMatch = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_t_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 2, (V[]){heff_dup(v_d_242), v_e_2438}));
    V v_xs_2441 = heff_get(heff_dup(v_cs_2439), LBL_values);
    V v_t_2448 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2441)), heff_clo(g_heff_2etoplevel_2eselfTermF_lam2, 1, 3, (V[]){v_xs_2441, v_d_242, v_r_240}));
    V v_t_2449 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_cs_2439), LBL_keys), heff_get(v_cs_2439, LBL_byName), v_t_2448});
    return heff_tag_at(v_ru_24t_243_24SMatch, TAG_SMatch, 2, (V[]){v_t_2440, v_t_2449});
  }
  case TAG_SSpecialize: {
    V v_e_2450 = heff_field(v_t_243, 0);
    V v_l_2451 = heff_field(v_t_243, 1);
    V v_v_2452 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SSpecialize = heff_take_reuse_n(v_t_243, 7ULL, 3);
    heff_drop(v_k_241);
    V v_t_2453 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 2, (V[]){heff_dup(v_d_242), v_e_2450}));
    V v_t_2454 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_v_2452}));
    return heff_tag_at(v_ru_24t_243_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2453, v_l_2451, v_t_2454});
  }
  case TAG_SIs: {
    V v_e_2455 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIs = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    V v_t_2456 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2455}));
    return heff_tag_at(v_ru_24t_243_24SIs, TAG_SIs, 1, (V[]){v_t_2456});
  }
  case TAG_SOpaque: {
    heff_drop(v_r_240);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SAbandon: {
    heff_drop(v_r_240);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SRec: {
    V v_e_2457 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SRec = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    V v_t_2458 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2457}));
    return heff_tag_at(v_ru_24t_243_24SRec, TAG_SRec, 1, (V[]){v_t_2458});
  }
  case TAG_SFix: {
    V v_dom_2459 = heff_field(v_t_243, 0);
    V v_it2_2460 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SFix = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    switch (heff_tag_of(v_it2_2460)) {
    case TAG_MkAbs: {
      V v_x_2461 = heff_field(v_it2_2460, 0);
      V v_b_2462 = heff_field(v_it2_2460, 1);
      heff_take_n(v_it2_2460, 3ULL, 2);
      V v_t_2463 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dom_2459}));
      V v_t_2464 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2462}));
      return heff_tag_at(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2463, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2461, v_t_2464})});
    }
    case TAG_AbsConst: {
      V v_b_2465 = heff_field(v_it2_2460, 0);
      heff_take_n(v_it2_2460, 1ULL, 1);
      V v_t_2466 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dom_2459}));
      V v_t_2467 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_b_2465}));
      return heff_tag_at(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2466, heff_tag(TAG_AbsConst, 1, (V[]){v_t_2467})});
    }
    default: return heff_nomatch(v_it2_2460);
    }
  }
  case TAG_SImplicit: {
    V v_x_2468 = heff_field(v_t_243, 0);
    V v_e_2469 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SImplicit = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_t_2470 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2469}));
    return heff_tag_at(v_ru_24t_243_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2468, v_t_2470});
  }
  case TAG_SPrim: {
    heff_drop(v_r_240);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SMetaApp: {
    V v_m_2472 = heff_field(v_t_243, 0);
    V v_ix_2473 = heff_field(v_t_243, 1);
    V v_ty2_2474 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SMetaApp = heff_take_reuse_n(v_t_243, 7ULL, 3);
    heff_drop(v_k_241);
    V v_t_2475 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_ty2_2474}));
    return heff_tag_at(v_ru_24t_243_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2472, v_ix_2473, v_t_2475});
  }
  case TAG_SLitInt: {
    heff_drop(v_r_240);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat: {
    heff_drop(v_r_240);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitString: {
    heff_drop(v_r_240);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2etoplevel_2eselfTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2eselfTermF(a[0], a[1], a[2], a[3]);
}
V g_heff_2etoplevel_2eselfTermF_lam0(V self, V *args) {
  V v_i_2425 = args[0];
  V v_xs_2424 = heff_env(self)[0];
  V v_f_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_arrayIndex(v_xs_2424, v_i_2425);
  V f_ = v_f_2423;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eselfTermF_lam1(V self, V *args) {
  V v_i_2435 = args[0];
  V v_as_2433 = heff_env(self)[0];
  V v_f_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_arrayIndex(v_as_2433, v_i_2435);
  V f_ = v_f_2434;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eselfTermF_lam2(V self, V *args) {
  V v_i_2442 = args[0];
  V v_xs_2441 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_2443 = heff_arrayIndex(v_xs_2441, v_i_2442);
  switch (heff_tag_of(v_p_2443)) {
  case TAG_MkPair: {
    V v_xs_2444 = heff_field(v_p_2443, 0);
    V v_b_2445 = heff_field(v_p_2443, 1);
    V v_ru_24p_2443_24MkPair = heff_take_reuse_n(v_p_2443, 3ULL, 2);
    V v_t_2446 = heff_intAdd(v_d_242, heff_arrayLength(heff_dup(v_xs_2444)));
    V v_t_2447 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_t_2446, v_b_2445}));
    return heff_tag_at(v_ru_24p_2443_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2444, v_t_2447});
  }
  default: return heff_nomatch(v_p_2443);
  }
}
V g_heff_2etoplevel_2eselfTypeF_lam0(V self, V *args);
V g_heff_2etoplevel_2eselfTypeF_lam2(V self, V *args);
V g_heff_2etoplevel_2eselfTypeF_lam1(V self, V *args);
V g_heff_2etoplevel_2eselfTypeF_lam3(V self, V *args);
Clo g_heff_2etoplevel_2eselfTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eselfTypeF_entry, 4, 0};

V g_heff_2etoplevel_2eselfTypeF(V v_r_240, V v_k_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_245}));
    return heff_tag_at(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_246});
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_t_243, 0);
    V v_dom_248 = heff_field(v_t_243, 1);
    V v_it3_249 = heff_field(v_t_243, 2);
    V v_implicit_2410 = heff_field(v_t_243, 3);
    V v_ru_24t_243_24SFunction = heff_take_reuse_n(v_t_243, 15ULL, 4);
    switch (heff_tag_of(v_it3_249)) {
    case TAG_MkAbs: {
      V v_x_2411 = heff_field(v_it3_249, 0);
      V v_b_2412 = heff_field(v_it3_249, 1);
      heff_take_n(v_it3_249, 3ULL, 2);
      V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2414 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2412}));
      return heff_tag_at(v_ru_24t_243_24SFunction, TAG_SFunction, 4, (V[]){v_level_247, v_t_2413, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2411, v_t_2414}), v_implicit_2410});
    }
    case TAG_AbsConst: {
      V v_b_2415 = heff_field(v_it3_249, 0);
      heff_take_n(v_it3_249, 1ULL, 1);
      V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2417 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_b_2415}));
      return heff_tag_at(v_ru_24t_243_24SFunction, TAG_SFunction, 4, (V[]){v_level_247, v_t_2416, heff_tag(TAG_AbsConst, 1, (V[]){v_t_2417}), v_implicit_2410});
    }
    default: return heff_nomatch(v_it3_249);
    }
  }
  case TAG_SRecord: {
    V v_level_2418 = heff_field(v_t_243, 0);
    V v_ft_2419 = heff_field(v_t_243, 1);
    V v_ds_2420 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SRecord = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_f_2421 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_d_242}));
    V v_xs_2422 = heff_get(heff_dup(v_ft_2419), LBL_values);
    V v_t_2425 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2422)), heff_clo(g_heff_2etoplevel_2eselfTypeF_lam0, 1, 2, (V[]){v_xs_2422, v_f_2421}));
    V v_t_2426 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_ft_2419), LBL_keys), heff_get(v_ft_2419, LBL_byName), v_t_2425});
    return heff_tag_at(v_ru_24t_243_24SRecord, TAG_SRecord, 3, (V[]){v_level_2418, v_t_2426, v_ds_2420});
  }
  case TAG_SSum: {
    V v_vs_2427 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2428 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_d_242}));
    V v_f_2432 = heff_clo(g_heff_2etoplevel_2eselfTypeF_lam1, 1, 1, (V[]){v_f_2428});
    V v_xs_2433 = heff_get(heff_dup(v_vs_2427), LBL_values);
    V v_t_2436 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2433)), heff_clo(g_heff_2etoplevel_2eselfTypeF_lam3, 1, 2, (V[]){v_xs_2433, v_f_2432}));
    V v_t_2437 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_vs_2427), LBL_keys), heff_get(v_vs_2427, LBL_byName), v_t_2436});
    return heff_tag_at(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2437});
  }
  case TAG_SIsTy: {
    V v_a_2438 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2439 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_a_2438}));
    return heff_tag_at(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2439});
  }
  case TAG_SPrimInt: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    V v_a_2440 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SPrimArray = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2441 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_a_2440}));
    return heff_tag_at(v_ru_24t_243_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2441});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2etoplevel_2eselfTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eselfTypeF(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2etoplevel_2eselfTypeF_lam0(V self, V *args) {
  V v_i_2423 = args[0];
  V v_xs_2422 = heff_env(self)[0];
  V v_f_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_arrayIndex(v_xs_2422, v_i_2423);
  V f_ = v_f_2421;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eselfTypeF_lam2(V self, V *args) {
  V v_i_2430 = args[0];
  V v_xs_2429 = heff_env(self)[0];
  V v_f_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_arrayIndex(v_xs_2429, v_i_2430);
  V f_ = v_f_2428;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eselfTypeF_lam1(V self, V *args) {
  V v_xs_2429 = args[0];
  V v_f_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2429)), heff_clo(g_heff_2etoplevel_2eselfTypeF_lam2, 1, 2, (V[]){v_xs_2429, v_f_2428}));
}
V g_heff_2etoplevel_2eselfTypeF_lam3(V self, V *args) {
  V v_i_2434 = args[0];
  V v_xs_2433 = heff_env(self)[0];
  V v_f_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2435 = heff_arrayIndex(v_xs_2433, v_i_2434);
  V f_ = v_f_2432;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eselfWalk_lam0(V self, V *args);
V g_heff_2etoplevel_2eselfWalk_lam1(V self, V *args);
Clo g_heff_2etoplevel_2eselfWalk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eselfWalk_entry, 1, 0};

V g_heff_2etoplevel_2eselfWalk(V v_k_240) {
top: ;
  return heff_rec(2, shape_80_351, (V[]){heff_clo(g_heff_2etoplevel_2eselfWalk_lam0, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo(g_heff_2etoplevel_2eselfWalk_lam1, 2, 1, (V[]){v_k_240})});
}
V g_heff_2etoplevel_2eselfWalk_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2eselfWalk(a[0]);
}
V g_heff_2etoplevel_2eselfWalk_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2etoplevel_2eselfWalk(heff_dup(v_k_240)));
  return (g_heff_2etoplevel_2eselfTermF(v_t_243, v_k_240, v_d_241, v_t_242));
}
V g_heff_2etoplevel_2eselfWalk_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2etoplevel_2eselfWalk(heff_dup(v_k_240)));
  return ({ V a_0 = v_t_246; V a_1 = v_k_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2etoplevel_2eselfTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_k_240); r_; });
}
V g_heff_2etoplevel_2enominalSyn_lam3(V self, V *args);
V g_heff_2etoplevel_2enominalSyn_lam2(V self, V *args);
V g_heff_2etoplevel_2enominalSyn_lam1(V self, V *args);
V g_heff_2etoplevel_2enominalSyn_lam0(V self, V *args);
Clo g_heff_2etoplevel_2enominalSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2enominalSyn_entry, 1, 0};

V g_heff_2etoplevel_2enominalSyn(V v_j_240) {
top: ;
  return heff_tag(TAG_MkSyn, 1, (V[]){heff_clo(g_heff_2etoplevel_2enominalSyn_lam0, 1, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2etoplevel_2enominalSyn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2enominalSyn(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2enominalSyn_lam3(V self, V *args) {
  V v_u_2411 = args[0];
  V v_res_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  V v_x1_2412 = heff_tr(heff_apply(heff_get(v_res_248, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2413;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    v_t_2416 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  return heff_tag(TAG_Become, 1, (V[]){v_t_2416});
}
V g_heff_2etoplevel_2enominalSyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_res_248 = heff_field(v_x_247, 0);
    V v_a_249 = heff_field(v_x_247, 1);
    V v_ru_24x_247_24MkPair = heff_take_reuse_n(v_x_247, 3ULL, 2);
    V v_t_2410 = heff_tag(TAG_SIs, 1, (V[]){heff_get(heff_dup(v_res_248), LBL_stx)});
    V v_t_2417 = heff_tag_at(v_ru_24x_247_24MkPair, TAG_MkPair, 2, (V[]){heff_rec(2, shape_326_366, (V[]){v_t_2410, heff_clo(g_heff_2etoplevel_2enominalSyn_lam3, 1, 1, (V[]){v_res_248})}), v_a_249});
    V f_ = v_k_246;
    args[0] = v_t_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2etoplevel_2enominalSyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo(g_heff_2etoplevel_2enominalSyn_lam2, 1, 1, (V[]){v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2enominalSyn_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_244;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkSyn: {
    V v_f_242 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_243 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){heff_get(heff_dup(v_e_241), LBL_scope), heff_get(heff_dup(v_e_241), LBL_globals), NTAG(TAG_ForNominative), heff_get(heff_dup(v_e_241), LBL_lams), heff_get(heff_dup(v_e_241), LBL_self), heff_get(v_e_241, LBL_insts)});
    v_c_244 = heff_tr(heff_apply(v_f_242, 1, (V[]){v_t_243}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo(g_heff_2etoplevel_2enominalSyn_lam1, 2, 1, (V[]){v_c_244});
}
V g_heff_2etoplevel_2enominalChk_lam3(V self, V *args);
V g_heff_2etoplevel_2enominalChk_lam2(V self, V *args);
V g_heff_2etoplevel_2enominalChk_lam1(V self, V *args);
V g_heff_2etoplevel_2enominalChk_lam0(V self, V *args);
Clo g_heff_2etoplevel_2enominalChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2enominalChk_entry, 1, 0};

V g_heff_2etoplevel_2enominalChk(V v_j_240) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2etoplevel_2enominalChk_lam0, 2, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2etoplevel_2enominalChk_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2enominalChk(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2enominalChk_lam3(V self, V *args) {
  V v_u_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  V v_x1_2411 = heff_tr(heff_apply(heff_get(v_x_248, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return heff_tag(TAG_Become, 1, (V[]){v_t_2415});
}
V g_heff_2etoplevel_2enominalChk_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag(TAG_SIs, 1, (V[]){heff_get(heff_dup(v_x_248), LBL_stx)});
  V f_ = v_k_247;
  args[0] = heff_rec(2, shape_326_366, (V[]){v_t_249, heff_clo(g_heff_2etoplevel_2enominalChk_lam3, 1, 1, (V[]){v_x_248})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2enominalChk_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo(g_heff_2etoplevel_2enominalChk_lam2, 1, 1, (V[]){v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2enominalChk_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_245;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkChk: {
    V v_f_243 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_244 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){heff_get(heff_dup(v_e_241), LBL_scope), heff_get(heff_dup(v_e_241), LBL_globals), NTAG(TAG_ForNominative), heff_get(heff_dup(v_e_241), LBL_lams), heff_get(heff_dup(v_e_241), LBL_self), heff_get(v_e_241, LBL_insts)});
    v_c_245 = heff_tr(heff_apply(v_f_243, 2, (V[]){v_t_244, v_a_242}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo(g_heff_2etoplevel_2enominalChk_lam1, 2, 1, (V[]){v_c_245});
}
V g_heff_2etoplevel_2enominalTyp_lam3(V self, V *args);
V g_heff_2etoplevel_2enominalTyp_lam2(V self, V *args);
V g_heff_2etoplevel_2enominalTyp_lam1(V self, V *args);
V g_heff_2etoplevel_2enominalTyp_lam0(V self, V *args);
Clo g_heff_2etoplevel_2enominalTyp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2enominalTyp_entry, 1, 0};

V g_heff_2etoplevel_2enominalTyp(V v_j_240) {
top: ;
  return heff_tag(TAG_MkTyp, 1, (V[]){heff_clo(g_heff_2etoplevel_2enominalTyp_lam0, 1, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2etoplevel_2enominalTyp_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2enominalTyp(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2enominalTyp_lam3(V self, V *args) {
  V v_u_249 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  V v_x1_2410 = heff_tr(heff_apply(heff_get(v_x_247, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2414;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2410, 0ULL, 1);
    v_t_2414 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  return heff_tag(TAG_Become, 1, (V[]){v_t_2414});
}
V g_heff_2etoplevel_2enominalTyp_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag(TAG_SIsTy, 1, (V[]){heff_get(heff_dup(v_x_247), LBL_stx)});
  V f_ = v_k_246;
  args[0] = heff_rec(2, shape_326_366, (V[]){v_t_248, heff_clo(g_heff_2etoplevel_2enominalTyp_lam3, 1, 1, (V[]){v_x_247})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2enominalTyp_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo(g_heff_2etoplevel_2enominalTyp_lam2, 1, 1, (V[]){v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2enominalTyp_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_244;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkTyp: {
    V v_f_242 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_243 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){heff_get(heff_dup(v_e_241), LBL_scope), heff_get(heff_dup(v_e_241), LBL_globals), NTAG(TAG_ForNominative), heff_get(heff_dup(v_e_241), LBL_lams), heff_get(heff_dup(v_e_241), LBL_self), heff_get(v_e_241, LBL_insts)});
    v_c_244 = heff_tr(heff_apply(v_f_242, 1, (V[]){v_t_243}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo(g_heff_2etoplevel_2enominalTyp_lam1, 2, 1, (V[]){v_c_244});
}
Clo g_heff_2etoplevel_2echecksOnly_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2echecksOnly_entry, 1, 0};

V g_heff_2etoplevel_2echecksOnly(V v_c_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_c_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_c_240, 0);
    v_t_243 = heff_dup(v_x_241);
    break;
  }
  default: heff_nomatch(v_c_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_CInf: {
    V v_i_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = (g_heff_2epresyntax_2einfSpineOf(v_i_244));
    V v_x1_246 = heff_get(v_t_245, LBL_head);
    V v_t_249;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_At: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 2);
      v_t_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_IVar: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_IInt: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_IFloat: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_IString: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_IApp: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_IAnn: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_ISpec: {
      heff_take_n(v_t_249, 0ULL, 4);
      return NTAG(TAG_False);
    }
    case TAG_IAnnLam: {
      heff_take_n(v_t_249, 0ULL, 4);
      return NTAG(TAG_True);
    }
    case TAG_IInvalid: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_INominal: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_CType: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_CLam: {
    heff_take_n(v_t_243, 0ULL, 3);
    return NTAG(TAG_True);
  }
  case TAG_CImplicitLam: {
    heff_take_n(v_t_243, 0ULL, 3);
    return NTAG(TAG_True);
  }
  case TAG_CAnnLam: {
    heff_take_n(v_t_243, 0ULL, 4);
    return NTAG(TAG_True);
  }
  case TAG_CTag: {
    heff_take_n(v_t_243, 0ULL, 3);
    return NTAG(TAG_True);
  }
  case TAG_CStruct: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_CMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_CLetIn: {
    heff_take_n(v_t_243, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_CLocal: {
    heff_take_n(v_t_243, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_CAbandon: {
    return NTAG(TAG_True);
  }
  case TAG_CNominal: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2etoplevel_2echecksOnly_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2echecksOnly(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2erecoveringChk_lam0(V self, V *args);
V g_heff_2etoplevel_2erecoveringChk_lam1(V self, V *args);
V g_heff_2etoplevel_2erecoveringChk_lam3(V self, V *args);
V g_heff_2etoplevel_2erecoveringChk_lam2(V self, V *args);
Clo g_heff_2etoplevel_2erecoveringChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2erecoveringChk_entry, 3, 0};

V g_heff_2etoplevel_2erecoveringChk(V v_m_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tr(heff_apply(v_m_240, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2etoplevel_2erecoveringChk_lam0, 1, 1, (V[]){heff_dup(v_hd_241)})}));
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Catch, 2, (V[]){v_t_244, heff_clo(g_heff_2etoplevel_2erecoveringChk_lam1, 1, 1, (V[]){heff_dup(v_hd_241)})})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2etoplevel_2erecoveringChk_lam2, 1, 1, (V[]){v_k_242})});
}
V g_heff_2etoplevel_2erecoveringChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2erecoveringChk(a[0], a[1], a[2]);
}
V g_heff_2etoplevel_2erecoveringChk_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_hd_241, LBL_ret);
  args[0] = heff_tag(TAG_Right, 1, (V[]){v_x_243});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erecoveringChk_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_hd_241, LBL_ret);
  args[0] = heff_tag(TAG_Left, 1, (V[]){v_s_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erecoveringChk_lam3(V self, V *args) {
  V v_e_2411 = args[0];
  V v_a_2412 = args[1];
  V v_hd_2413 = args[2];
  V v_k2_2414 = args[3];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2411);
  heff_drop(v_a_2412);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_d_2410})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2416}));
  V f_ = heff_get(v_hd_2413, LBL_bind);
  args[0] = v_t_2417;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2erecoveringChk_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    V v_d_2410 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Left = heff_take_reuse_n(v_x_249, 1ULL, 1);
    V v_t_2418 = ({ V b_0 = heff_tag_at(v_ru_24x_249_24Left, TAG_MkChk, 1, (V[]){heff_clo(g_heff_2etoplevel_2erecoveringChk_lam3, 4, 1, (V[]){v_d_2410})}); V r_ = (g_heff_2erules_2erecovering(b_0)); heff_drop(b_0); r_; });
    V f_ = v_k_242;
    args[0] = v_t_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_c_2419 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2420 = ({ V a_0 = v_c_2419; V r_ = (g_heff_2erules_2erecovering(a_0)); heff_drop(v_c_2419); r_; });
    V f_ = v_k_242;
    args[0] = v_t_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2etoplevel_2etraverseEL_lam0(V self, V *args); static Clo g_heff_2etoplevel_2etraverseEL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_lam0, 2, 0};
V g_heff_2etoplevel_2etraverseEL_lam3(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_lam2(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_lam1(V self, V *args);
Clo g_heff_2etoplevel_2etraverseEL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_entry, 2, 0};

V g_heff_2etoplevel_2etraverseEL(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2etoplevel_2etraverseEL_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo(g_heff_2etoplevel_2etraverseEL_lam1, 2, 3, (V[]){v_c_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2etoplevel_2etraverseEL_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2etraverseEL(a[0], a[1]);
}
V g_heff_2etoplevel_2etraverseEL_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2etoplevel_2etraverseEL(v_f_240, v_xs_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2etoplevel_2etraverseEL_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2etoplevel_2etraverseEL_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2etoplevel_2etraverseEL_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2etoplevel_2epatName_str0 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2etoplevel_2epatName_str1 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2etoplevel_2epatName_str2 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2etoplevel_2epatName_str3 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2etoplevel_2epatName_str4 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2etoplevel_2epatName_str5 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2etoplevel_2epatName_str6 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2etoplevel_2epatName_str7 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101}};
V g_heff_2etoplevel_2epatName_lam0(V self, V *args);
V g_heff_2etoplevel_2epatName_lam1(V self, V *args);
V g_heff_2etoplevel_2epatName_lam2(V self, V *args);
V g_heff_2etoplevel_2epatName_lam3(V self, V *args);
V g_heff_2etoplevel_2epatName_lam4(V self, V *args);
V g_heff_2etoplevel_2epatName_lam5(V self, V *args);
V g_heff_2etoplevel_2epatName_lam6(V self, V *args);
V g_heff_2etoplevel_2epatName_lam7(V self, V *args);
V g_heff_2etoplevel_2epatName_lam8(V self, V *args);
Clo g_heff_2etoplevel_2epatName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2epatName_entry, 1, 0};

V g_heff_2etoplevel_2epatName(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      return heff_clo(g_heff_2etoplevel_2epatName_lam0, 2, 1, (V[]){heff_dup(v_x_243)});
    }
    case TAG_PatTag: {
      V v_sp_2411;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2410 = heff_field(v_p_240, 1);
        v_sp_2411 = heff_dup(v_s_2410);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2epatName_lam1, 2, 1, (V[]){v_sp_2411});
    }
    case TAG_PatOp: {
      V v_sp_2423;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2422 = heff_field(v_p_240, 1);
        v_sp_2423 = heff_dup(v_s_2422);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2epatName_lam2, 2, 1, (V[]){v_sp_2423});
    }
    case TAG_PatInt: {
      V v_sp_2433;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_p_240, 1);
        v_sp_2433 = heff_dup(v_s_2432);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2epatName_lam3, 2, 1, (V[]){v_sp_2433});
    }
    case TAG_PatFloat: {
      V v_sp_2443;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2442 = heff_field(v_p_240, 1);
        v_sp_2443 = heff_dup(v_s_2442);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2epatName_lam4, 2, 1, (V[]){v_sp_2443});
    }
    case TAG_PatString: {
      V v_sp_2453;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2452 = heff_field(v_p_240, 1);
        v_sp_2453 = heff_dup(v_s_2452);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2epatName_lam5, 2, 1, (V[]){v_sp_2453});
    }
    case TAG_PatRecord: {
      V v_sp_2463;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2462 = heff_field(v_p_240, 1);
        v_sp_2463 = heff_dup(v_s_2462);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2epatName_lam6, 2, 1, (V[]){v_sp_2463});
    }
    case TAG_PatWord: {
      V v_sp_2473;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2472 = heff_field(v_p_240, 1);
        v_sp_2473 = heff_dup(v_s_2472);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2epatName_lam7, 2, 1, (V[]){v_sp_2473});
    }
    case TAG_PatAs: {
      V v_sp_2485;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2484 = heff_field(v_p_240, 1);
        v_sp_2485 = heff_dup(v_s_2484);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2epatName_lam8, 2, 1, (V[]){v_sp_2485});
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2etoplevel_2epatName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2epatName(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2epatName_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_x_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2epatName_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_sp_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2epatName_str0), v_sp_2411, NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2416}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2417;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2epatName_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_sp_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2epatName_str1), v_sp_2423, NTAG(TAG_Nothing)});
  V v_t_2427 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2424), LBL_malg), 1, (V[]){v_t_2428}));
  V f_ = heff_get(v_hd_2424, LBL_bind);
  args[0] = v_t_2429;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2epatName_lam3(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k2_2435 = args[1];
  V v_sp_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2epatName_str2), v_sp_2433, NTAG(TAG_Nothing)});
  V v_t_2437 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2434), LBL_malg), 1, (V[]){v_t_2438}));
  V f_ = heff_get(v_hd_2434, LBL_bind);
  args[0] = v_t_2439;
  args[1] = v_k2_2435;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2epatName_lam4(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k2_2445 = args[1];
  V v_sp_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2epatName_str3), v_sp_2443, NTAG(TAG_Nothing)});
  V v_t_2447 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2444), LBL_malg), 1, (V[]){v_t_2448}));
  V f_ = heff_get(v_hd_2444, LBL_bind);
  args[0] = v_t_2449;
  args[1] = v_k2_2445;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2epatName_lam5(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k2_2455 = args[1];
  V v_sp_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2epatName_str4), v_sp_2453, NTAG(TAG_Nothing)});
  V v_t_2457 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2454), LBL_malg), 1, (V[]){v_t_2458}));
  V f_ = heff_get(v_hd_2454, LBL_bind);
  args[0] = v_t_2459;
  args[1] = v_k2_2455;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2epatName_lam6(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k2_2465 = args[1];
  V v_sp_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2epatName_str5), v_sp_2463, NTAG(TAG_Nothing)});
  V v_t_2467 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2464), LBL_malg), 1, (V[]){v_t_2468}));
  V f_ = heff_get(v_hd_2464, LBL_bind);
  args[0] = v_t_2469;
  args[1] = v_k2_2465;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2epatName_lam7(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k2_2475 = args[1];
  V v_sp_2473 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2476 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2epatName_str6), v_sp_2473, NTAG(TAG_Nothing)});
  V v_t_2477 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2474), LBL_malg), 1, (V[]){v_t_2478}));
  V f_ = heff_get(v_hd_2474, LBL_bind);
  args[0] = v_t_2479;
  args[1] = v_k2_2475;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2epatName_lam8(V self, V *args) {
  V v_hd_2486 = args[0];
  V v_k2_2487 = args[1];
  V v_sp_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2488 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2epatName_str7), v_sp_2485, NTAG(TAG_Nothing)});
  V v_t_2489 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2486), LBL_malg), 1, (V[]){v_t_2490}));
  V f_ = heff_get(v_hd_2486, LBL_bind);
  args[0] = v_t_2491;
  args[1] = v_k2_2487;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etraverseEL_24s432_lam0(V self, V *args); static Clo g_heff_2etoplevel_2etraverseEL_24s432_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s432_lam0, 2, 0};
V g_heff_2etoplevel_2etraverseEL_24s432_lam3(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s432_lam2(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s432_lam1(V self, V *args);
Clo g_heff_2etoplevel_2etraverseEL_24s432_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s432_entry, 1, 0};

V g_heff_2etoplevel_2etraverseEL_24s432(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2etoplevel_2etraverseEL_24s432_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2etoplevel_2epatName(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo(g_heff_2etoplevel_2etraverseEL_24s432_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2etraverseEL_24s432_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2etraverseEL_24s432(a[0]);
}
V g_heff_2etoplevel_2etraverseEL_24s432_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s432_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s432_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2etoplevel_2etraverseEL_24s432(v_xs_244));
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo(g_heff_2etoplevel_2etraverseEL_24s432_lam3, 1, 2, (V[]){v_k_247, v_x_248})});
}
V g_heff_2etoplevel_2etraverseEL_24s432_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2etoplevel_2etraverseEL_24s432_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2etoplevel_2edoPat_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2etoplevel_2edoPat_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[75]; } g_heff_2etoplevel_2edoPat_str2 = {{0x80000000u, K_STR, 0}, 75, 75, {97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[75]; } g_heff_2etoplevel_2edoPat_str3 = {{0x80000000u, K_STR, 0}, 75, 75, {97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[75]; } g_heff_2etoplevel_2edoPat_str4 = {{0x80000000u, K_STR, 0}, 75, 75, {97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[75]; } g_heff_2etoplevel_2edoPat_str5 = {{0x80000000u, K_STR, 0}, 75, 75, {97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[75]; } g_heff_2etoplevel_2edoPat_str6 = {{0x80000000u, K_STR, 0}, 75, 75, {97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[75]; } g_heff_2etoplevel_2edoPat_str7 = {{0x80000000u, K_STR, 0}, 75, 75, {97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[75]; } g_heff_2etoplevel_2edoPat_str8 = {{0x80000000u, K_STR, 0}, 75, 75, {97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[75]; } g_heff_2etoplevel_2edoPat_str9 = {{0x80000000u, K_STR, 0}, 75, 75, {97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96}};
V g_heff_2etoplevel_2edoPat_lam0(V self, V *args); static Clo g_heff_2etoplevel_2edoPat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2edoPat_lam0, 2, 0};
V g_heff_2etoplevel_2edoPat_lam1(V self, V *args);
V g_heff_2etoplevel_2edoPat_lam3(V self, V *args);
V g_heff_2etoplevel_2edoPat_lam2(V self, V *args);
V g_heff_2etoplevel_2edoPat_lam4(V self, V *args);
V g_heff_2etoplevel_2edoPat_lam5(V self, V *args);
V g_heff_2etoplevel_2edoPat_lam6(V self, V *args);
V g_heff_2etoplevel_2edoPat_lam7(V self, V *args);
V g_heff_2etoplevel_2edoPat_lam8(V self, V *args);
V g_heff_2etoplevel_2edoPat_lam9(V self, V *args);
V g_heff_2etoplevel_2edoPat_lam10(V self, V *args);
Clo g_heff_2etoplevel_2edoPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2edoPat_entry, 1, 0};

V g_heff_2etoplevel_2edoPat(V v_p_240) {
top: ;
  V v_t_241 = (g_heff_2epresyntax_2epatSpineOf(heff_dup(v_p_240)));
  V v_it_242 = heff_get(v_t_241, LBL_head);
  switch (heff_tag_of(v_it_242)) {
  case TAG_At: {
    V v_it1_243 = heff_field(v_it_242, 0);
    heff_take_n(v_it_242, 1ULL, 2);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_PatVar: {
      V v_it11_245 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      V v_t_246 = heff_strEq(v_it11_245, ((V)&g_heff_2etoplevel_2edoPat_str0));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_p_240);
        return ((V)&g_heff_2etoplevel_2edoPat_lam0_clo);
      }
      case TAG_False: {
        V v_sp_2412;
        switch (heff_tag_of(v_p_240)) {
        case TAG_At: {
          V v_s_2411 = heff_field(v_p_240, 1);
          heff_take_n(v_p_240, 2ULL, 2);
          v_sp_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_p_240);
        }
        return heff_clo(g_heff_2etoplevel_2edoPat_lam1, 2, 1, (V[]){v_sp_2412});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_PatTag: {
      V v_x_2419 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 3);
      V v_t_2422 = (g_heff_2epresyntax_2epatSpineOf(v_p_240));
      V v_c_2423 = (g_heff_2etoplevel_2etraverseEL_24s432(heff_get(v_t_2422, LBL_args)));
      return heff_clo(g_heff_2etoplevel_2edoPat_lam2, 2, 2, (V[]){v_c_2423, v_x_2419});
    }
    case TAG_PatOp: {
      heff_take_n(v_it1_243, 0ULL, 3);
      V v_sp_2432;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2431 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2432 = v_s_2431;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2edoPat_lam4, 2, 1, (V[]){v_sp_2432});
    }
    case TAG_PatInt: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2442;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2441 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2edoPat_lam5, 2, 1, (V[]){v_sp_2442});
    }
    case TAG_PatFloat: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2452;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2451 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2452 = v_s_2451;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2edoPat_lam6, 2, 1, (V[]){v_sp_2452});
    }
    case TAG_PatString: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2462;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2461 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2462 = v_s_2461;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2edoPat_lam7, 2, 1, (V[]){v_sp_2462});
    }
    case TAG_PatRecord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2472;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2471 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2472 = v_s_2471;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2edoPat_lam8, 2, 1, (V[]){v_sp_2472});
    }
    case TAG_PatWord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2482;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2481 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2482 = v_s_2481;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2edoPat_lam9, 2, 1, (V[]){v_sp_2482});
    }
    case TAG_PatAs: {
      heff_take_n(v_it1_243, 0ULL, 3);
      V v_sp_2494;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2493 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2494 = v_s_2493;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo(g_heff_2etoplevel_2edoPat_lam10, 2, 1, (V[]){v_sp_2494});
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2etoplevel_2edoPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2edoPat(a[0]);
}
V g_heff_2etoplevel_2edoPat_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V v_t_249 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2etoplevel_2edoPat_str1), NTAG(TAG_Nil)});
  V f_ = v_k_248;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2edoPat_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_sp_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2edoPat_str2), v_sp_2412, NTAG(TAG_Nothing)});
  V v_t_2416 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2417}));
  V f_ = heff_get(v_hd_2413, LBL_bind);
  args[0] = v_t_2418;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2edoPat_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2425;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_x_2419, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2edoPat_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo(g_heff_2etoplevel_2edoPat_lam3, 1, 2, (V[]){v_k_2425, v_x_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2edoPat_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k2_2434 = args[1];
  V v_sp_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2edoPat_str3), v_sp_2432, NTAG(TAG_Nothing)});
  V v_t_2436 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2433), LBL_malg), 1, (V[]){v_t_2437}));
  V f_ = heff_get(v_hd_2433, LBL_bind);
  args[0] = v_t_2438;
  args[1] = v_k2_2434;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2edoPat_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_sp_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2edoPat_str4), v_sp_2442, NTAG(TAG_Nothing)});
  V v_t_2446 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2443), LBL_malg), 1, (V[]){v_t_2447}));
  V f_ = heff_get(v_hd_2443, LBL_bind);
  args[0] = v_t_2448;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2edoPat_lam6(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k2_2454 = args[1];
  V v_sp_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2455 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2edoPat_str5), v_sp_2452, NTAG(TAG_Nothing)});
  V v_t_2456 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2453), LBL_malg), 1, (V[]){v_t_2457}));
  V f_ = heff_get(v_hd_2453, LBL_bind);
  args[0] = v_t_2458;
  args[1] = v_k2_2454;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2edoPat_lam7(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k2_2464 = args[1];
  V v_sp_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2edoPat_str6), v_sp_2462, NTAG(TAG_Nothing)});
  V v_t_2466 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2463), LBL_malg), 1, (V[]){v_t_2467}));
  V f_ = heff_get(v_hd_2463, LBL_bind);
  args[0] = v_t_2468;
  args[1] = v_k2_2464;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2edoPat_lam8(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k2_2474 = args[1];
  V v_sp_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2475 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2edoPat_str7), v_sp_2472, NTAG(TAG_Nothing)});
  V v_t_2476 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2473), LBL_malg), 1, (V[]){v_t_2477}));
  V f_ = heff_get(v_hd_2473, LBL_bind);
  args[0] = v_t_2478;
  args[1] = v_k2_2474;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2edoPat_lam9(V self, V *args) {
  V v_hd_2483 = args[0];
  V v_k2_2484 = args[1];
  V v_sp_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2485 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2edoPat_str8), v_sp_2482, NTAG(TAG_Nothing)});
  V v_t_2486 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2483), LBL_malg), 1, (V[]){v_t_2487}));
  V f_ = heff_get(v_hd_2483, LBL_bind);
  args[0] = v_t_2488;
  args[1] = v_k2_2484;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2edoPat_lam10(V self, V *args) {
  V v_hd_2495 = args[0];
  V v_k2_2496 = args[1];
  V v_sp_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2497 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2edoPat_str9), v_sp_2494, NTAG(TAG_Nothing)});
  V v_t_2498 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2495), LBL_malg), 1, (V[]){v_t_2499}));
  V f_ = heff_get(v_hd_2495, LBL_bind);
  args[0] = v_t_24100;
  args[1] = v_k2_2496;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2etoplevel_2eannotatesData_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eannotatesData_entry, 1, 0};

V g_heff_2etoplevel_2eannotatesData(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_IVar: {
      return NTAG(TAG_False);
    }
    case TAG_IInt: {
      return NTAG(TAG_False);
    }
    case TAG_IFloat: {
      return NTAG(TAG_False);
    }
    case TAG_IString: {
      return NTAG(TAG_False);
    }
    case TAG_IApp: {
      return NTAG(TAG_False);
    }
    case TAG_IAnn: {
      V v_c_249 = heff_field(v_x11_241, 0);
      V v_t_2413;
      switch (heff_tag_of(v_c_249)) {
      case TAG_At: {
        V v_x_2411 = heff_field(v_c_249, 0);
        v_t_2413 = heff_dup(v_x_2411);
        break;
      }
      default: heff_nomatch(v_c_249);
      }
      switch (heff_tag_of(v_t_2413)) {
      case TAG_CInf: {
        heff_take_n(v_t_2413, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_CType: {
        heff_take_n(v_t_2413, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_CLam: {
        heff_take_n(v_t_2413, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_CImplicitLam: {
        heff_take_n(v_t_2413, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_CAnnLam: {
        heff_take_n(v_t_2413, 0ULL, 4);
        return NTAG(TAG_False);
      }
      case TAG_CTag: {
        heff_take_n(v_t_2413, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_CStruct: {
        heff_take_n(v_t_2413, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_CMatch: {
        heff_take_n(v_t_2413, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_CLetIn: {
        heff_take_n(v_t_2413, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_CLocal: {
        heff_take_n(v_t_2413, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_CAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_CNominal: {
        heff_take_n(v_t_2413, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    case TAG_ISpec: {
      return NTAG(TAG_False);
    }
    case TAG_IAnnLam: {
      return NTAG(TAG_False);
    }
    case TAG_IInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_INominal: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2etoplevel_2eannotatesData_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eannotatesData(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2etoplevel_2eallL_24s433_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eallL_24s433_entry, 1, 0};

V g_heff_2etoplevel_2eallL_24s433(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2420;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_PatVar: {
        v_t_2420 = NTAG(TAG_True);
        break;
      }
      case TAG_PatTag: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_PatOp: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_PatInt: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_PatFloat: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_PatString: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_PatRecord: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_PatWord: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_PatAs: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2eallL_24s433_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eallL_24s433(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2etoplevel_2eflatPat_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2etoplevel_2eflatPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eflatPat_entry, 1, 0};

V g_heff_2etoplevel_2eflatPat(V v_gr_240) {
top: ;
  V v_t_241 = heff_get(heff_dup(v_gr_240), LBL_head);
  V v_t_244;
  switch (heff_tag_of(v_t_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 2);
    v_t_244 = v_x_242;
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_PatVar: {
    V v_x_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_t_246 = heff_strEq(v_x_245, ((V)&g_heff_2etoplevel_2eflatPat_str0));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_get(v_gr_240, LBL_args); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
      return heff_intEq(v_t_247, MK_INT(0LL));
    }
    case TAG_False: {
      heff_drop(v_gr_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_PatTag: {
    heff_take_n(v_t_244, 0ULL, 3);
    return ({ V b_0 = heff_get(v_gr_240, LBL_args); V r_ = (g_heff_2etoplevel_2eallL_24s433(b_0)); heff_drop(b_0); r_; });
  }
  case TAG_PatOp: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop(v_gr_240);
    return NTAG(TAG_False);
  }
  case TAG_PatInt: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_gr_240);
    return NTAG(TAG_False);
  }
  case TAG_PatFloat: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_gr_240);
    return NTAG(TAG_False);
  }
  case TAG_PatString: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_gr_240);
    return NTAG(TAG_False);
  }
  case TAG_PatRecord: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_gr_240);
    return NTAG(TAG_False);
  }
  case TAG_PatWord: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_gr_240);
    return NTAG(TAG_False);
  }
  case TAG_PatAs: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop(v_gr_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2etoplevel_2eflatPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2eflatPat(a[0]);
}
Clo g_heff_2etoplevel_2etagSpans_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etagSpans_entry, 1, 0};

V g_heff_2etoplevel_2etagSpans(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      switch (heff_tag_of(v_x111_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x111_243, 0);
        heff_take_n(v_x111_243, 1ULL, 2);
        V v_acc_247 = (g_heff_2etoplevel_2etagSpans(v_rest_242));
        V v_t_248 = (g_heff_2epresyntax_2epatSpineOf(v_p_245));
        V v_it_249 = heff_get(v_t_248, LBL_head);
        switch (heff_tag_of(v_it_249)) {
        case TAG_At: {
          V v_it1_2410 = heff_field(v_it_249, 0);
          V v_tsp_2411 = heff_field(v_it_249, 1);
          heff_take_n(v_it_249, 3ULL, 2);
          switch (heff_tag_of(v_it1_2410)) {
          case TAG_PatVar: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatTag: {
            V v_x_2413 = heff_field(v_it1_2410, 0);
            heff_take_n(v_it1_2410, 1ULL, 3);
            return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2413, v_tsp_2411}), v_acc_247});
          }
          case TAG_PatOp: {
            heff_take_n(v_it1_2410, 0ULL, 3);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatInt: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatFloat: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatString: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatRecord: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatWord: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatAs: {
            heff_take_n(v_it1_2410, 0ULL, 3);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          default: return heff_nomatch(v_it1_2410);
          }
        }
        default: return heff_nomatch(v_it_249);
        }
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2etoplevel_2etagSpans_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2etagSpans(a[0]);
}
Clo g_heff_2etoplevel_2elamsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2elamsOf_entry, 2, 0};

V g_heff_2etoplevel_2elamsOf(V v_n_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_b_241)) {
  case TAG_SLocal: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SGlobal: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SCode: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SApp: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLam: {
    V v_b2_248 = heff_field(v_b_241, 1);
    heff_take_n(v_b_241, 2ULL, 2);
    switch (heff_tag_of(v_b2_248)) {
    case TAG_MkAbs: {
      V v_b22_2410 = heff_field(v_b2_248, 1);
      heff_take_n(v_b2_248, 2ULL, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_b22_2410;
      v_n_240 = t_0;
      v_b_241 = t_1;
      goto top;
    }
    case TAG_AbsConst: {
      V v_b21_2411 = heff_field(v_b2_248, 0);
      heff_take_n(v_b2_248, 1ULL, 1);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_b21_2411;
      v_n_240 = t_0;
      v_b_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_b2_248);
    }
  }
  case TAG_SCons: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SProj: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_STag: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SMatch: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SSpecialize: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SIs: {
    V v_b1_2422 = heff_field(v_b_241, 0);
    heff_take_n(v_b_241, 1ULL, 1);
    V t_0 = v_n_240;
    V t_1 = v_b1_2422;
    v_n_240 = t_0;
    v_b_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SAbandon: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SRec: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SFix: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SImplicit: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SPrim: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SMetaApp: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitInt: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitFloat: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitString: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  default: return heff_nomatch(v_b_241);
  }
}
V g_heff_2etoplevel_2elamsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2elamsOf(a[0], a[1]);
}
Clo g_heff_2etoplevel_2eparamsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eparamsOf_entry, 3, 0};

V g_heff_2etoplevel_2eparamsOf(V v_i_240, V v_e_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SU: {
    V v_ru_24x3_242_24SU = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at(v_ru_24x3_242_24SU, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SDecode: {
    V v_ru_24x3_242_24SDecode = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at(v_ru_24x3_242_24SDecode, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SFunction: {
    V v_cod_247 = heff_field(v_x3_242, 2);
    V v_x34_248 = heff_field(v_x3_242, 3);
    heff_take_n(v_x3_242, 12ULL, 4);
    switch (heff_tag_of(v_x34_248)) {
    case TAG_Expl: {
      V v_t_2412;
      switch (heff_tag_of(v_cod_247)) {
      case TAG_MkAbs: {
        V v_t_2410 = heff_field(v_cod_247, 1);
        heff_take_n(v_cod_247, 2ULL, 2);
        v_t_2412 = v_t_2410;
        break;
      }
      case TAG_AbsConst: {
        V v_t_2411 = heff_field(v_cod_247, 0);
        heff_take_n(v_cod_247, 1ULL, 1);
        v_t_2412 = v_t_2411;
        break;
      }
      default: heff_nomatch(v_cod_247);
      }
      V t_0 = v_i_240;
      V t_1 = heff_intAdd(v_e_241, MK_INT(1LL));
      V t_2 = v_t_2412;
      v_i_240 = t_0;
      v_e_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Impl: {
      V v_t_2413 = heff_intLt(MK_INT(0LL), heff_dup(v_e_241));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        heff_drop(v_cod_247);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V v_t_2417;
        switch (heff_tag_of(v_cod_247)) {
        case TAG_MkAbs: {
          V v_t_2415 = heff_field(v_cod_247, 1);
          heff_take_n(v_cod_247, 2ULL, 2);
          v_t_2417 = v_t_2415;
          break;
        }
        case TAG_AbsConst: {
          V v_t_2416 = heff_field(v_cod_247, 0);
          heff_take_n(v_cod_247, 1ULL, 1);
          v_t_2417 = v_t_2416;
          break;
        }
        default: heff_nomatch(v_cod_247);
        }
        V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
        V t_1 = v_e_241;
        V t_2 = v_t_2417;
        v_i_240 = t_0;
        v_e_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    case TAG_Inst: {
      heff_drop(v_i_240);
      heff_drop(v_e_241);
      heff_drop(v_cod_247);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x34_248);
    }
  }
  case TAG_SRecord: {
    heff_take_n(v_x3_242, 0ULL, 3);
    return heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SSum: {
    V v_ru_24x3_242_24SSum = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at(v_ru_24x3_242_24SSum, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SIsTy: {
    V v_ru_24x3_242_24SIsTy = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at(v_ru_24x3_242_24SIsTy, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimInt: {
    return heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimFloat: {
    return heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimString: {
    return heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimArray: {
    V v_ru_24x3_242_24SPrimArray = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at(v_ru_24x3_242_24SPrimArray, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2etoplevel_2eparamsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2eparamsOf(a[0], a[1], a[2]);
}
Clo g_heff_2etoplevel_2eparamsInOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eparamsInOrder_entry, 3, 0};

V g_heff_2etoplevel_2eparamsInOrder(V v_k_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_intEq(v_i_241, v_k_240);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_SLocal: {
      V v_j_245 = heff_field(v_x31_243, 0);
      V v_t_246 = heff_intSub(heff_intSub(heff_dup(v_k_240), MK_INT(1LL)), heff_dup(v_i_241));
      V v_t_247 = heff_intEq(heff_dup(v_j_245), v_t_246);
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        V t_0 = v_k_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_i_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_k_240);
        heff_drop(v_i_241);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_SGlobal: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SCode: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SApp: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLam: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SCons: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SProj: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_STag: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SMatch: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SSpecialize: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SIs: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SOpaque: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SAbandon: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SFix: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SImplicit: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SPrim: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SMetaApp: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitInt: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitString: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2etoplevel_2eparamsInOrder_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eparamsInOrder(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2etoplevel_2etagSynonym_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etagSynonym_entry, 1, 0};

V g_heff_2etoplevel_2etagSynonym(V v_ge_240) {
top: ;
  V v_it_241 = (g_heff_2etoplevel_2eparamsOf(MK_INT(0LL), MK_INT(0LL), heff_get(heff_dup(v_ge_240), LBL_tySyntax)));
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nothing: {
    heff_drop(v_ge_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_it1_242 = heff_field(v_it_241, 0);
    V v_ru_24it_241_24Just = heff_take_reuse_n(v_it_241, 1ULL, 1);
    switch (heff_tag_of(v_it1_242)) {
    case TAG_MkPair: {
      V v_i_243 = heff_field(v_it1_242, 0);
      V v_k_244 = heff_field(v_it1_242, 1);
      heff_take_n(v_it1_242, 3ULL, 2);
      V v_it_245 = (g_heff_2etoplevel_2elamsOf(MK_INT(0LL), heff_get(v_ge_240, LBL_syntax)));
      switch (heff_tag_of(v_it_245)) {
      case TAG_MkPair: {
        V v_n_246 = heff_field(v_it_245, 0);
        V v_it2_247 = heff_field(v_it_245, 1);
        heff_take_n(v_it_245, 3ULL, 2);
        switch (heff_tag_of(v_it2_247)) {
        case TAG_SLocal: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          V v_t_2418 = heff_field(v_it2_247, 0);
          V v_args_2419 = heff_field(v_it2_247, 1);
          heff_take_n(v_it2_247, 3ULL, 2);
          V v_t_2420 = heff_intEq(v_n_246, heff_intAdd(v_i_243, heff_dup(v_k_244)));
          switch (heff_tag_of(v_t_2420)) {
          case TAG_True: {
            V v_t_2421 = ({ V a_0 = heff_dup(v_k_244); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_args_2419); V r_ = (g_heff_2etoplevel_2eparamsInOrder(a_0, a_1, b_2)); heff_drop(b_2); r_; });
            switch (heff_tag_of(v_t_2421)) {
            case TAG_True: {
              return heff_tag_at(v_ru_24it_241_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2418, v_k_244})});
            }
            case TAG_False: {
              heff_drop_cell(v_ru_24it_241_24Just, 1);
              heff_drop(v_k_244);
              heff_drop(v_t_2418);
              return NTAG(TAG_Nothing);
            }
            default: return heff_nomatch(v_t_2421);
            }
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24it_241_24Just, 1);
            heff_drop(v_k_244);
            heff_drop(v_t_2418);
            heff_drop(v_args_2419);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2420);
          }
        }
        case TAG_SMatch: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_it2_247, 0ULL, 3);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SOpaque: {
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_it2_247, 0ULL, 3);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it2_247);
        }
      }
      default: return heff_nomatch(v_it_245);
      }
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  default: return heff_nomatch(v_it_241);
  }
}
V g_heff_2etoplevel_2etagSynonym_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2etagSynonym(a[0]);
}
Clo g_heff_2etoplevel_2eallL_24s434_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eallL_24s434_entry, 1, 0};

V g_heff_2etoplevel_2eallL_24s434(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_x1_243 = (g_heff_2etoplevel_2ehasOpPat(heff_dup(v_x_241)));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2eallL_24s434_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eallL_24s434(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2etoplevel_2eallL_24s435_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eallL_24s435_entry, 1, 0};

V g_heff_2etoplevel_2eallL_24s435(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_q_244 = heff_field(v_x_241, 1);
      V v_x1_245 = (g_heff_2etoplevel_2ehasOpPat(heff_dup(v_q_244)));
      switch (heff_tag_of(v_x1_245)) {
      case TAG_True: {
        v_t_246 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_246 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2eallL_24s435_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eallL_24s435(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2etoplevel_2ehasOpPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ehasOpPat_entry, 1, 0};

V g_heff_2etoplevel_2ehasOpPat(V v_p_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_p_240, 0);
    heff_take_n(v_p_240, 1ULL, 2);
    v_t_243 = v_x_241;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_PatVar: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PatTag: {
    V v_ps_247 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 4ULL, 3);
    V v_x1_248 = ({ V a_0 = v_ps_247; V r_ = (g_heff_2etoplevel_2eallL_24s434(a_0)); heff_drop(v_ps_247); r_; });
    switch (heff_tag_of(v_x1_248)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_248);
    }
  }
  case TAG_PatOp: {
    heff_take_n(v_t_243, 0ULL, 3);
    return NTAG(TAG_True);
  }
  case TAG_PatInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PatFloat: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PatString: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PatRecord: {
    V v_fs_2415 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_x1_2416 = ({ V a_0 = v_fs_2415; V r_ = (g_heff_2etoplevel_2eallL_24s435(a_0)); heff_drop(v_fs_2415); r_; });
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2416);
    }
  }
  case TAG_PatWord: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PatAs: {
    V v_q_2420 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 4ULL, 3);
    V t_0 = v_q_2420;
    v_p_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2etoplevel_2ehasOpPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2ehasOpPat(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2etoplevel_2eopPat_str0 = {{0x80000000u, K_STR, 0}, 17, 17, {110, 111, 32, 115, 117, 99, 104, 32, 111, 112, 101, 114, 97, 116, 111, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2etoplevel_2eopPat_str1 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 105, 110, 32, 115, 99, 111, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2etoplevel_2eopPat_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[105]; } g_heff_2etoplevel_2eopPat_str3 = {{0x80000000u, K_STR, 0}, 105, 105, {96, 32, 105, 115, 32, 110, 111, 116, 32, 97, 110, 111, 116, 104, 101, 114, 32, 110, 97, 109, 101, 32, 102, 111, 114, 32, 97, 32, 116, 97, 103, 44, 32, 115, 111, 32, 110, 111, 32, 112, 97, 116, 116, 101, 114, 110, 32, 99, 97, 110, 32, 117, 115, 101, 32, 105, 116, 58, 32, 97, 110, 32, 111, 112, 101, 114, 97, 116, 111, 114, 32, 105, 110, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 100, 101, 102, 105, 110, 101, 100, 32, 97, 115, 32, 111, 110, 101, 44, 32, 96, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2etoplevel_2eopPat_str4 = {{0x80000000u, K_STR, 0}, 14, 14, {41, 32, 120, 32, 121, 32, 61, 32, 67, 32, 120, 32, 121, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2etoplevel_2eopPat_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[105]; } g_heff_2etoplevel_2eopPat_str6 = {{0x80000000u, K_STR, 0}, 105, 105, {96, 32, 105, 115, 32, 110, 111, 116, 32, 97, 110, 111, 116, 104, 101, 114, 32, 110, 97, 109, 101, 32, 102, 111, 114, 32, 97, 32, 116, 97, 103, 44, 32, 115, 111, 32, 110, 111, 32, 112, 97, 116, 116, 101, 114, 110, 32, 99, 97, 110, 32, 117, 115, 101, 32, 105, 116, 58, 32, 97, 110, 32, 111, 112, 101, 114, 97, 116, 111, 114, 32, 105, 110, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 100, 101, 102, 105, 110, 101, 100, 32, 97, 115, 32, 111, 110, 101, 44, 32, 96, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2etoplevel_2eopPat_str7 = {{0x80000000u, K_STR, 0}, 14, 14, {41, 32, 120, 32, 121, 32, 61, 32, 67, 32, 120, 32, 121, 96}};
V g_heff_2etoplevel_2eopPat_lam0(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam1(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam3(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam2(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam4(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam5(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam6(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam8(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam7(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam9(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam10(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam11(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam12(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam15(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam14(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam13(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam17(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam16(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam18(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam20(V self, V *args);
V g_heff_2etoplevel_2eopPat_lam19(V self, V *args);
Clo g_heff_2etoplevel_2eopPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eopPat_entry, 2, 0};

V g_heff_2etoplevel_2eopPat(V v_g_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_it1_242 = heff_dup(heff_field(v_p_241, 0));
    V v_it2_243 = heff_dup(heff_field(v_p_241, 1));
    switch (heff_tag_of(v_it1_242)) {
    case TAG_PatVar: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_it2_243);
      return heff_clo(g_heff_2etoplevel_2eopPat_lam0, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatTag: {
      V v_t_247 = heff_field(v_it1_242, 0);
      V v_tsp_248 = heff_field(v_it1_242, 1);
      V v_args_249 = heff_field(v_it1_242, 2);
      heff_take_n(v_it1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      heff_drop(v_it2_243);
      V v_c_2411 = (g_heff_2etoplevel_2etraverseEL(heff_clo(g_heff_2etoplevel_2eopPat_lam1, 1, 1, (V[]){v_g_240}), v_args_249));
      return heff_clo(g_heff_2etoplevel_2eopPat_lam2, 2, 3, (V[]){v_c_2411, v_t_247, v_tsp_248});
    }
    case TAG_PatOp: {
      V v_x_2422 = heff_field(v_it1_242, 0);
      V v_xsp_2423 = heff_field(v_it1_242, 1);
      V v_args_2424 = heff_field(v_it1_242, 2);
      heff_take_n(v_it1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      heff_drop(v_it2_243);
      V v_t_2425 = ({ V a_0 = heff_dup(v_x_2422); V b_1 = heff_get(heff_dup(v_g_240), LBL_entries); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
      V v_it_2431;
      switch (heff_tag_of(v_t_2425)) {
      case TAG_Nothing: {
        V v_t_2426 = ({ V a_0 = heff_dup(v_x_2422); V b_1 = heff_get(heff_dup(v_g_240), LBL_aliases); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_t_2426)) {
        case TAG_Nothing: {
          v_it_2431 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_k_2427 = heff_field(v_t_2426, 0);
          V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 1ULL, 1);
          V v_t_2428 = ({ V a_0 = heff_dup(v_k_2427); V b_1 = heff_get(heff_dup(v_g_240), LBL_entries); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
          switch (heff_tag_of(v_t_2428)) {
          case TAG_Nothing: {
            heff_drop(v_k_2427);
            heff_drop_cell(v_ru_24t_2426_24Just, 1);
            v_it_2431 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_e_2429 = heff_field(v_t_2428, 0);
            heff_take_n(v_t_2428, 1ULL, 1);
            v_it_2431 = heff_tag_at(v_ru_24t_2426_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_k_2427, v_e_2429})});
            break;
          }
          default: heff_nomatch(v_t_2428);
          }
          break;
        }
        default: heff_nomatch(v_t_2426);
        }
        break;
      }
      case TAG_Just: {
        V v_e_2430 = heff_field(v_t_2425, 0);
        V v_ru_24t_2425_24Just = heff_take_reuse_n(v_t_2425, 1ULL, 1);
        v_it_2431 = heff_tag_at(v_ru_24t_2425_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_x_2422), v_e_2430})});
        break;
      }
      default: heff_nomatch(v_t_2425);
      }
      switch (heff_tag_of(v_it_2431)) {
      case TAG_Nothing: {
        heff_drop(v_g_240);
        heff_drop(v_args_2424);
        return heff_clo(g_heff_2etoplevel_2eopPat_lam4, 2, 2, (V[]){v_x_2422, v_xsp_2423});
      }
      case TAG_Just: {
        V v_it1_2439 = heff_field(v_it_2431, 0);
        heff_take_n(v_it_2431, 1ULL, 1);
        switch (heff_tag_of(v_it1_2439)) {
        case TAG_MkPair: {
          V v_ge_2441 = heff_field(v_it1_2439, 1);
          heff_take_n(v_it1_2439, 2ULL, 2);
          V v_it_2442 = (g_heff_2etoplevel_2etagSynonym(v_ge_2441));
          switch (heff_tag_of(v_it_2442)) {
          case TAG_Nothing: {
            heff_drop(v_g_240);
            heff_drop(v_args_2424);
            return heff_clo(g_heff_2etoplevel_2eopPat_lam5, 2, 2, (V[]){v_x_2422, v_xsp_2423});
          }
          case TAG_Just: {
            V v_it1_2450 = heff_field(v_it_2442, 0);
            heff_take_n(v_it_2442, 1ULL, 1);
            switch (heff_tag_of(v_it1_2450)) {
            case TAG_MkPair: {
              V v_t_2451 = heff_field(v_it1_2450, 0);
              V v_k_2452 = heff_field(v_it1_2450, 1);
              heff_take_n(v_it1_2450, 3ULL, 2);
              V v_t_2453 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_args_2424));
              V v_t_2454 = heff_intEq(v_k_2452, v_t_2453);
              switch (heff_tag_of(v_t_2454)) {
              case TAG_True: {
                heff_drop(v_x_2422);
                V v_c_2456 = (g_heff_2etoplevel_2etraverseEL(heff_clo(g_heff_2etoplevel_2eopPat_lam6, 1, 1, (V[]){v_g_240}), v_args_2424));
                return heff_clo(g_heff_2etoplevel_2eopPat_lam7, 2, 3, (V[]){v_c_2456, v_t_2451, v_xsp_2423});
              }
              case TAG_False: {
                heff_drop(v_g_240);
                heff_drop(v_args_2424);
                heff_drop(v_t_2451);
                return heff_clo(g_heff_2etoplevel_2eopPat_lam9, 2, 2, (V[]){v_x_2422, v_xsp_2423});
              }
              default: return heff_nomatch(v_t_2454);
              }
            }
            default: return heff_nomatch(v_it1_2450);
            }
          }
          default: return heff_nomatch(v_it_2442);
          }
        }
        default: return heff_nomatch(v_it1_2439);
        }
      }
      default: return heff_nomatch(v_it_2431);
      }
    }
    case TAG_PatInt: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_it2_243);
      return heff_clo(g_heff_2etoplevel_2eopPat_lam10, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatFloat: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_it2_243);
      return heff_clo(g_heff_2etoplevel_2eopPat_lam11, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatString: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_it2_243);
      return heff_clo(g_heff_2etoplevel_2eopPat_lam12, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatRecord: {
      V v_fs_2483 = heff_field(v_it1_242, 0);
      heff_take_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_p_241, 2);
      V v_c_2491 = (g_heff_2etoplevel_2etraverseEL(heff_clo(g_heff_2etoplevel_2eopPat_lam13, 1, 1, (V[]){v_g_240}), v_fs_2483));
      return heff_clo(g_heff_2etoplevel_2eopPat_lam16, 2, 2, (V[]){v_c_2491, v_it2_243});
    }
    case TAG_PatWord: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_it2_243);
      return heff_clo(g_heff_2etoplevel_2eopPat_lam18, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatAs: {
      V v_x_2499 = heff_field(v_it1_242, 0);
      V v_xsp_24100 = heff_field(v_it1_242, 1);
      V v_q_24101 = heff_field(v_it1_242, 2);
      heff_take_n(v_it1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      V v_c_24102 = (g_heff_2etoplevel_2eopPat(v_g_240, v_q_24101));
      return heff_clo(g_heff_2etoplevel_2eopPat_lam19, 2, 4, (V[]){v_c_24102, v_x_2499, v_xsp_24100, v_it2_243});
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2etoplevel_2eopPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2eopPat(a[0], a[1]);
}
V g_heff_2etoplevel_2eopPat_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eopPat_lam1(V self, V *args) {
  V v_m_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2etoplevel_2eopPat(v_g_240, v_m_2410));
}
V g_heff_2etoplevel_2eopPat_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_t_247 = heff_env(self)[0];
  V v_tsp_248 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_PatVar, 1, (V[]){heff_dup(v_t_247)}), heff_dup(v_tsp_248)});
  V v_x1_2416 = (g_heff_2epresyntax_2elastOr(v_t_2415, v_x_2414));
  V v_b_2419;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_At: {
    V v_s_2418 = heff_field(v_x1_2416, 1);
    heff_take_n(v_x1_2416, 2ULL, 2);
    v_b_2419 = v_s_2418;
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_t_2420 = heff_rec(2, shape_320_83, (V[]){heff_get(heff_dup(v_tsp_248), LBL_start), heff_get(v_b_2419, LBL_end)});
  V v_x_2421 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_PatTag, 3, (V[]){v_t_247, v_tsp_248, v_x_2414}), v_t_2420});
  V f_ = v_k_2413;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eopPat_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_t_247 = heff_env(self)[1];
  V v_tsp_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo(g_heff_2etoplevel_2eopPat_lam3, 1, 3, (V[]){v_t_247, v_tsp_248, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eopPat_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_strAppend(((V)&g_heff_2etoplevel_2eopPat_str0), heff_strAppend(v_x_2422, ((V)&g_heff_2etoplevel_2eopPat_str1)));
  V v_t_2435 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2434, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2436 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2432), LBL_malg), 1, (V[]){v_t_2437}));
  V f_ = heff_get(v_hd_2432, LBL_bind);
  args[0] = v_t_2438;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eopPat_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2445 = heff_strAppend(((V)&g_heff_2etoplevel_2eopPat_str2), heff_strAppend(heff_dup(v_x_2422), heff_strAppend(((V)&g_heff_2etoplevel_2eopPat_str3), heff_strAppend(v_x_2422, ((V)&g_heff_2etoplevel_2eopPat_str4)))));
  V v_t_2446 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2445, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2447 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2443), LBL_malg), 1, (V[]){v_t_2448}));
  V f_ = heff_get(v_hd_2443, LBL_bind);
  args[0] = v_t_2449;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eopPat_lam6(V self, V *args) {
  V v_m_2455 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2etoplevel_2eopPat(v_g_240, v_m_2455));
}
V g_heff_2etoplevel_2eopPat_lam8(V self, V *args) {
  V v_x_2459 = args[0];
  V v_t_2451 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  V v_k_2458 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2460 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_PatVar, 1, (V[]){heff_dup(v_t_2451)}), heff_dup(v_xsp_2423)});
  V v_x1_2461 = (g_heff_2epresyntax_2elastOr(v_t_2460, v_x_2459));
  V v_b_2464;
  switch (heff_tag_of(v_x1_2461)) {
  case TAG_At: {
    V v_s_2463 = heff_field(v_x1_2461, 1);
    heff_take_n(v_x1_2461, 2ULL, 2);
    v_b_2464 = v_s_2463;
    break;
  }
  default: heff_nomatch(v_x1_2461);
  }
  V v_t_2465 = heff_rec(2, shape_320_83, (V[]){heff_get(heff_dup(v_xsp_2423), LBL_start), heff_get(v_b_2464, LBL_end)});
  V v_x_2466 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_PatTag, 3, (V[]){v_t_2451, v_xsp_2423, v_x_2459}), v_t_2465});
  V f_ = v_k_2458;
  args[0] = v_x_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eopPat_lam7(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  V v_c_2456 = heff_env(self)[0];
  V v_t_2451 = heff_env(self)[1];
  V v_xsp_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2456;
  args[0] = v_hd_2457;
  args[1] = heff_clo(g_heff_2etoplevel_2eopPat_lam8, 1, 3, (V[]){v_t_2451, v_xsp_2423, v_k_2458});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eopPat_lam9(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k2_2468 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2469 = heff_strAppend(((V)&g_heff_2etoplevel_2eopPat_str5), heff_strAppend(heff_dup(v_x_2422), heff_strAppend(((V)&g_heff_2etoplevel_2eopPat_str6), heff_strAppend(v_x_2422, ((V)&g_heff_2etoplevel_2eopPat_str7)))));
  V v_t_2470 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2469, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2471 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2467), LBL_malg), 1, (V[]){v_t_2472}));
  V f_ = heff_get(v_hd_2467, LBL_bind);
  args[0] = v_t_2473;
  args[1] = v_k2_2468;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eopPat_lam10(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k_2476 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2475);
  V f_ = v_k_2476;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eopPat_lam11(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k_2479 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2478);
  V f_ = v_k_2479;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eopPat_lam12(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k_2482 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2481);
  V f_ = v_k_2482;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eopPat_lam15(V self, V *args) {
  V v_x_2490 = args[0];
  V v_k_2489 = heff_env(self)[0];
  V v_x_2485 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2489;
  args[0] = heff_tag(TAG_MkFieldPat, 2, (V[]){v_x_2485, v_x_2490});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eopPat_lam14(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_c_2487 = heff_env(self)[0];
  V v_x_2485 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2487;
  args[0] = v_hd_2488;
  args[1] = heff_clo(g_heff_2etoplevel_2eopPat_lam15, 1, 2, (V[]){v_k_2489, v_x_2485});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eopPat_lam13(V self, V *args) {
  V v_m_2484 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2484)) {
  case TAG_MkFieldPat: {
    V v_x_2485 = heff_field(v_m_2484, 0);
    V v_p_2486 = heff_field(v_m_2484, 1);
    heff_take_n(v_m_2484, 3ULL, 2);
    V v_c_2487 = (g_heff_2etoplevel_2eopPat(v_g_240, v_p_2486));
    return heff_clo(g_heff_2etoplevel_2eopPat_lam14, 2, 2, (V[]){v_c_2487, v_x_2485});
  }
  default: return heff_nomatch(v_m_2484);
  }
}
V g_heff_2etoplevel_2eopPat_lam17(V self, V *args) {
  V v_x_2494 = args[0];
  V v_it2_243 = heff_env(self)[0];
  V v_k_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2495 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_PatRecord, 1, (V[]){v_x_2494}), v_it2_243});
  V f_ = v_k_2493;
  args[0] = v_t_2495;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eopPat_lam16(V self, V *args) {
  V v_hd_2492 = args[0];
  V v_k_2493 = args[1];
  V v_c_2491 = heff_env(self)[0];
  V v_it2_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2491;
  args[0] = v_hd_2492;
  args[1] = heff_clo(g_heff_2etoplevel_2eopPat_lam17, 1, 2, (V[]){v_it2_243, v_k_2493});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eopPat_lam18(V self, V *args) {
  V v_hd_2497 = args[0];
  V v_k_2498 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2497);
  V f_ = v_k_2498;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eopPat_lam20(V self, V *args) {
  V v_x_24105 = args[0];
  V v_x_2499 = heff_env(self)[0];
  V v_xsp_24100 = heff_env(self)[1];
  V v_it2_243 = heff_env(self)[2];
  V v_k_24104 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24106 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_PatAs, 3, (V[]){v_x_2499, v_xsp_24100, v_x_24105}), v_it2_243});
  V f_ = v_k_24104;
  args[0] = v_t_24106;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eopPat_lam19(V self, V *args) {
  V v_hd_24103 = args[0];
  V v_k_24104 = args[1];
  V v_c_24102 = heff_env(self)[0];
  V v_x_2499 = heff_env(self)[1];
  V v_xsp_24100 = heff_env(self)[2];
  V v_it2_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24102;
  args[0] = v_hd_24103;
  args[1] = heff_clo(g_heff_2etoplevel_2eopPat_lam20, 1, 4, (V[]){v_x_2499, v_xsp_24100, v_it2_243, v_k_24104});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2etoplevel_2eallL_24s436_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eallL_24s436_entry, 1, 0};

V g_heff_2etoplevel_2eallL_24s436(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_x1_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkEquation: {
        V v_ps_247 = heff_field(v_x11_243, 2);
        V v_x1_249 = (g_heff_2etoplevel_2eallL_24s434(v_ps_247));
        switch (heff_tag_of(v_x1_249)) {
        case TAG_True: {
          v_x1_2410 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_x1_2410 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x1_249);
        }
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2410);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2eallL_24s436_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eallL_24s436(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2etoplevel_2eallL_24s437_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eallL_24s437_entry, 1, 0};

V g_heff_2etoplevel_2eallL_24s437(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_x1_247;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x11_243, 0);
        v_x1_247 = (g_heff_2etoplevel_2ehasOpPat(heff_dup(v_p_245)));
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_x1_247)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2eallL_24s437_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eallL_24s437(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2etoplevel_2eallL_24s438_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eallL_24s438_entry, 1, 0};

V g_heff_2etoplevel_2eallL_24s438(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x11_243, 0);
        V v_t_247 = (g_heff_2epresyntax_2epatSpineOf(heff_dup(v_p_245)));
        v_t_248 = (g_heff_2etoplevel_2eflatPat(v_t_247));
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2eallL_24s438_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eallL_24s438(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2etoplevel_2echkHeadOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2echkHeadOf_entry, 2, 0};

V g_heff_2etoplevel_2echkHeadOf(V v_n_240, V v_j_241) {
top: ;
  V v_t_2423;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_i1_242 = heff_dup(heff_field(v_n_240, 0));
    switch (heff_tag_of(v_i1_242)) {
    case TAG_IVar: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2423 = heff_dup(v_n_240);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2423 = heff_dup(v_n_240);
      break;
    }
    case TAG_IFloat: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2423 = heff_dup(v_n_240);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2423 = heff_dup(v_n_240);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_i1_242, 0ULL, 2);
      v_t_2423 = heff_dup(v_n_240);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_i1_242, 0ULL, 2);
      v_t_2423 = heff_dup(v_n_240);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_i1_242, 0ULL, 4);
      v_t_2423 = heff_dup(v_n_240);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_i1_242, 0ULL, 4);
      v_t_2423 = heff_dup(v_n_240);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_i1_242, 0ULL, 2);
      v_t_2423 = heff_dup(v_n_240);
      break;
    }
    case TAG_INominal: {
      V v_i11_2422 = heff_field(v_i1_242, 0);
      heff_take_n(v_i1_242, 1ULL, 1);
      v_t_2423 = v_i11_2422;
      break;
    }
    default: heff_nomatch(v_i1_242);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_t_2424 = (g_heff_2epresyntax_2einfSpineOf(v_t_2423));
  V v_it_2425 = heff_get(v_t_2424, LBL_head);
  switch (heff_tag_of(v_it_2425)) {
  case TAG_At: {
    V v_it1_2426 = heff_field(v_it_2425, 0);
    heff_take_n(v_it_2425, 1ULL, 2);
    switch (heff_tag_of(v_it1_2426)) {
    case TAG_IVar: {
      V v_x_2428 = heff_field(v_it1_2426, 0);
      heff_take_n(v_it1_2426, 1ULL, 1);
      V v_t_2431;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2430 = heff_dup(heff_field(v_n_240, 1));
        v_t_2431 = v_s_2430;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      V v_t_2434;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2433 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2434 = v_s_2433;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      V v_t_2435 = (g_heff_2erules_2eapply(v_t_2434, v_j_241));
      return ({ V a_0 = v_t_2431; V a_1 = v_x_2428; V a_2 = v_t_2435; V r_ = (g_heff_2erules_2eautoRec(a_0, a_1, a_2)); heff_drop(v_t_2435); r_; });
    }
    case TAG_IInt: {
      heff_take_n(v_it1_2426, 0ULL, 1);
      V v_t_2439;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2438 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2439 = v_s_2438;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2erules_2eapply(v_t_2439, v_j_241);
    }
    case TAG_IFloat: {
      heff_take_n(v_it1_2426, 0ULL, 1);
      V v_t_2443;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2442 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2443 = v_s_2442;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2erules_2eapply(v_t_2443, v_j_241);
    }
    case TAG_IString: {
      heff_take_n(v_it1_2426, 0ULL, 1);
      V v_t_2447;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2446 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2447 = v_s_2446;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2erules_2eapply(v_t_2447, v_j_241);
    }
    case TAG_IApp: {
      heff_take_n(v_it1_2426, 0ULL, 2);
      V v_t_2452;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2451 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2452 = v_s_2451;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2erules_2eapply(v_t_2452, v_j_241);
    }
    case TAG_IAnn: {
      heff_take_n(v_it1_2426, 0ULL, 2);
      V v_t_2457;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2456 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2erules_2eapply(v_t_2457, v_j_241);
    }
    case TAG_ISpec: {
      heff_take_n(v_it1_2426, 0ULL, 4);
      V v_t_2464;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2463 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2464 = v_s_2463;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2erules_2eapply(v_t_2464, v_j_241);
    }
    case TAG_IAnnLam: {
      heff_take_n(v_it1_2426, 0ULL, 4);
      V v_t_2471;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2470 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2471 = v_s_2470;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2erules_2eapply(v_t_2471, v_j_241);
    }
    case TAG_IInvalid: {
      heff_take_n(v_it1_2426, 0ULL, 2);
      V v_t_2476;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2475 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2476 = v_s_2475;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2erules_2eapply(v_t_2476, v_j_241);
    }
    case TAG_INominal: {
      heff_take_n(v_it1_2426, 0ULL, 1);
      V v_t_2480;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2479 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2480 = v_s_2479;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2erules_2eapply(v_t_2480, v_j_241);
    }
    default: return heff_nomatch(v_it1_2426);
    }
  }
  default: return heff_nomatch(v_it_2425);
  }
}
V g_heff_2etoplevel_2echkHeadOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2echkHeadOf(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2etoplevel_2ebinderF_24s440_lam1(V self, V *args);
V g_heff_2etoplevel_2ebinderF_24s440_lam0(V self, V *args);
V g_heff_2etoplevel_2ebinderF_24s440_lam3(V self, V *args);
V g_heff_2etoplevel_2ebinderF_24s440_lam2(V self, V *args);
V g_heff_2etoplevel_2ebinderF_24s440_lam5(V self, V *args);
V g_heff_2etoplevel_2ebinderF_24s440_lam4(V self, V *args);
V g_heff_2etoplevel_2ebinderF_24s440_lam7(V self, V *args);
V g_heff_2etoplevel_2ebinderF_24s440_lam6(V self, V *args);
Clo g_heff_2etoplevel_2ebinderF_24s440_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ebinderF_24s440_entry, 1, 0};

V g_heff_2etoplevel_2ebinderF_24s440(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_t_243 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 5ULL, 3);
    V v_c_244 = ({ V a_0 = v_t_243; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_t_243); r_; });
    return heff_clo(g_heff_2etoplevel_2ebinderF_24s440_lam0, 2, 2, (V[]){v_c_244, v_x_241});
  }
  case TAG_PiImplicit: {
    V v_x_248 = heff_field(v_x2_240, 0);
    V v_sp_2410 = heff_field(v_x2_240, 2);
    V v_t_2411 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 13ULL, 4);
    V v_c_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_t_2411); r_; });
    return heff_clo(g_heff_2etoplevel_2ebinderF_24s440_lam2, 2, 3, (V[]){v_c_2412, v_sp_2410, v_x_248});
  }
  case TAG_PiInstance: {
    V v_x_2416 = heff_field(v_x2_240, 0);
    V v_sp_2418 = heff_field(v_x2_240, 2);
    V v_t_2419 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 13ULL, 4);
    V v_c_2420 = ({ V a_0 = v_t_2419; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_t_2419); r_; });
    return heff_clo(g_heff_2etoplevel_2ebinderF_24s440_lam4, 2, 3, (V[]){v_c_2420, v_sp_2418, v_x_2416});
  }
  case TAG_PiAnon: {
    V v_d_2424 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_c_2425 = ({ V a_0 = v_d_2424; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_d_2424); r_; });
    return heff_clo(g_heff_2etoplevel_2ebinderF_24s440_lam6, 2, 1, (V[]){v_c_2425});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2ebinderF_24s440_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2ebinderF_24s440(a[0]);
}
V g_heff_2etoplevel_2ebinderF_24s440_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_246;
  args[0] = heff_tag(TAG_Named, 2, (V[]){v_x_241, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2ebinderF_24s440_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo(g_heff_2etoplevel_2ebinderF_24s440_lam1, 1, 2, (V[]){v_k_246, v_x_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2ebinderF_24s440_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_sp_2410 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2414;
  args[0] = heff_tag(TAG_NamedImplicit, 3, (V[]){v_sp_2410, v_x_248, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2ebinderF_24s440_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_sp_2410 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo(g_heff_2etoplevel_2ebinderF_24s440_lam3, 1, 3, (V[]){v_k_2414, v_sp_2410, v_x_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2ebinderF_24s440_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  V v_sp_2418 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2422;
  args[0] = heff_tag(TAG_NamedInstance, 3, (V[]){v_sp_2418, v_x_2416, v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2ebinderF_24s440_lam4(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_sp_2418 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo(g_heff_2etoplevel_2ebinderF_24s440_lam5, 1, 3, (V[]){v_k_2422, v_sp_2418, v_x_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2ebinderF_24s440_lam7(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2427;
  args[0] = heff_tag(TAG_Anonymous, 1, (V[]){v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2ebinderF_24s440_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2425;
  args[0] = v_hd_2426;
  args[1] = heff_clo(g_heff_2etoplevel_2ebinderF_24s440_lam7, 1, 1, (V[]){v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eelimF_24s446_lam1(V self, V *args);
V g_heff_2etoplevel_2eelimF_24s446_lam0(V self, V *args);
V g_heff_2etoplevel_2eelimF_24s446_lam2(V self, V *args);
V g_heff_2etoplevel_2eelimF_24s446_lam7(V self, V *args);
V g_heff_2etoplevel_2eelimF_24s446_lam6(V self, V *args);
V g_heff_2etoplevel_2eelimF_24s446_lam5(V self, V *args);
V g_heff_2etoplevel_2eelimF_24s446_lam4(V self, V *args);
V g_heff_2etoplevel_2eelimF_24s446_lam3(V self, V *args);
Clo g_heff_2etoplevel_2eelimF_24s446_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelimF_24s446_entry, 3, 0};

V g_heff_2etoplevel_2eelimF_24s446(V v_start_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_At: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_sp_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_ArgExplicit: {
      V v_c_245 = heff_field(v_x41_243, 0);
      V v_t_246 = (g_heff_2etoplevel_2echkF_24s443(heff_dup(v_c_245)));
      V v_c_247 = heff_tr(heff_apply(((V)&g_heff_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_246}));
      return heff_clo(g_heff_2etoplevel_2eelimF_24s446_lam0, 2, 5, (V[]){v_c_247, heff_dup(v_c_245), v_start_240, heff_dup(v_sp_244), heff_dup(v_s_241)});
    }
    case TAG_ArgProject: {
      V v_x_2414 = heff_field(v_x41_243, 0);
      heff_drop(v_start_240);
      return heff_clo(g_heff_2etoplevel_2eelimF_24s446_lam2, 2, 3, (V[]){heff_dup(v_sp_244), heff_dup(v_s_241), heff_dup(v_x_2414)});
    }
    case TAG_ArgNamed: {
      V v_x_2418 = heff_field(v_x41_243, 0);
      V v_c_2419 = heff_field(v_x41_243, 1);
      V v_t_2420 = (g_heff_2etoplevel_2echkF_24s443(heff_dup(v_c_2419)));
      V v_c_2421 = heff_tr(heff_apply(((V)&g_heff_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_2420}));
      return heff_clo(g_heff_2etoplevel_2eelimF_24s446_lam3, 2, 5, (V[]){v_c_2421, heff_dup(v_s_241), v_start_240, heff_dup(v_sp_244), heff_dup(v_x_2418)});
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2etoplevel_2eelimF_24s446_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eelimF_24s446(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
V g_heff_2etoplevel_2eelimF_24s446_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = ({ V a_0 = v_c_245; V r_ = (g_heff_2etoplevel_2echecksOnly(a_0)); heff_drop(v_c_245); r_; });
  V v_t_2412 = heff_rec(2, shape_320_83, (V[]){v_start_240, heff_get(v_sp_244, LBL_end)});
  V v_x_2413 = ({ V a_0 = v_t_2411; V a_1 = v_t_2412; V a_2 = v_s_241; V a_3 = v_x_2410; V r_ = (g_heff_2erules_2efunctionElimC(a_0, a_1, a_2, a_3)); heff_drop(v_t_2411); heff_drop(v_s_241); heff_drop(v_x_2410); r_; });
  V f_ = v_k_249;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eelimF_24s446_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_s_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo(g_heff_2etoplevel_2eelimF_24s446_lam1, 1, 5, (V[]){v_c_245, v_start_240, v_sp_244, v_s_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eelimF_24s446_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_sp_244 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2415);
  V v_t_2417 = ({ V a_0 = v_sp_244; V a_1 = v_s_241; V a_2 = v_x_2414; V r_ = (g_heff_2erules_2erecordElim(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
  V f_ = v_k_2416;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eelimF_24s446_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_x_2424 = heff_env(self)[3];
  V v_e_2425 = heff_env(self)[4];
  V v_hd_2428 = heff_env(self)[5];
  V v_k_2429 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_MkPair: {
    V v_ecallee_2431 = heff_field(v_x_2430, 0);
    V v_a0_2432 = heff_field(v_x_2430, 1);
    heff_take_n(v_x_2430, 3ULL, 2);
    V v_t_2433 = heff_rec(2, shape_320_83, (V[]){v_start_240, heff_get(v_sp_244, LBL_end)});
    return ({ V a_0 = v_t_2433; V a_1 = v_x_2418; V a_2 = v_x_2424; V a_3 = v_e_2425; V a_4 = v_ecallee_2431; V a_5 = v_a0_2432; V a_6 = v_hd_2428; V a_7 = v_k_2429; V r_ = (g_heff_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2424); r_; });
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2etoplevel_2eelimF_24s446_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2418 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  V v_e_2425 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2427;
  args[0] = heff_dup(v_hd_2428);
  args[1] = heff_clo(g_heff_2etoplevel_2eelimF_24s446_lam7, 1, 7, (V[]){v_start_240, v_sp_244, v_x_2418, v_x_2424, v_e_2425, v_hd_2428, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eelimF_24s446_lam5(V self, V *args) {
  V v_e_2425 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2418 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2427;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_2426 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_2427 = heff_tr(heff_apply(v_f_2426, 1, (V[]){heff_dup(v_e_2425)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo(g_heff_2etoplevel_2eelimF_24s446_lam6, 2, 6, (V[]){v_c_2427, v_start_240, v_sp_244, v_x_2418, v_x_2424, v_e_2425});
}
V g_heff_2etoplevel_2eelimF_24s446_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_2423;
  args[0] = heff_tag(TAG_MkSyn, 1, (V[]){heff_clo(g_heff_2etoplevel_2eelimF_24s446_lam5, 1, 5, (V[]){v_s_241, v_start_240, v_sp_244, v_x_2418, v_x_2424})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eelimF_24s446_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2421;
  args[0] = v_hd_2422;
  args[1] = heff_clo(g_heff_2etoplevel_2eelimF_24s446_lam4, 1, 5, (V[]){v_k_2423, v_s_241, v_start_240, v_sp_244, v_x_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eelimAll_24s445_lam0(V self, V *args);
V g_heff_2etoplevel_2eelimAll_24s445_lam2(V self, V *args);
V g_heff_2etoplevel_2eelimAll_24s445_lam1(V self, V *args);
Clo g_heff_2etoplevel_2eelimAll_24s445_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelimAll_24s445_entry, 3, 0};

V g_heff_2etoplevel_2eelimAll_24s445(V v_start_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_start_240);
    return heff_clo(g_heff_2etoplevel_2eelimAll_24s445_lam0, 2, 1, (V[]){v_s_241});
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x4_242, 0);
    V v_rest_246 = heff_field(v_x4_242, 1);
    V v_c_247 = ({ V a_0 = heff_dup(v_start_240); V a_1 = v_s_241; V a_2 = v_a_245; V r_ = (g_heff_2etoplevel_2eelimF_24s446(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
    return heff_clo(g_heff_2etoplevel_2eelimAll_24s445_lam1, 2, 3, (V[]){v_c_247, v_start_240, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2etoplevel_2eelimAll_24s445_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eelimAll_24s445(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2etoplevel_2eelimAll_24s445_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_s_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eelimAll_24s445_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_start_240; V a_1 = v_x_2410; V a_2 = v_rest_246; V r_ = (g_heff_2etoplevel_2eelimAll_24s445(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  return heff_tail(v_t_2411, 2, (V[]){v_hd_248, v_k_249});
}
V g_heff_2etoplevel_2eelimAll_24s445_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo(g_heff_2etoplevel_2eelimAll_24s445_lam2, 1, 4, (V[]){v_start_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam0(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam3(V self, V *args); static Clo g_heff_2etoplevel_2einfF_24s444_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2einfF_24s444_lam3, 1, 0};
V g_heff_2etoplevel_2einfF_24s444_lam2(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam1(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam6(V self, V *args); static Clo g_heff_2etoplevel_2einfF_24s444_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2einfF_24s444_lam6, 1, 0};
V g_heff_2etoplevel_2einfF_24s444_lam5(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam4(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam9(V self, V *args); static Clo g_heff_2etoplevel_2einfF_24s444_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2einfF_24s444_lam9, 1, 0};
V g_heff_2etoplevel_2einfF_24s444_lam8(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam7(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam11(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam10(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam14(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam13(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam12(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam17(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam16(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam15(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam20(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam19(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam18(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam21(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam23(V self, V *args);
V g_heff_2etoplevel_2einfF_24s444_lam22(V self, V *args);
Clo g_heff_2etoplevel_2einfF_24s444_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2einfF_24s444_entry, 1, 0};

V g_heff_2etoplevel_2einfF_24s444(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_it1_241 = heff_dup(heff_field(v_n_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_it1_241)) {
    case TAG_IVar: {
      V v_x_243 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo(g_heff_2etoplevel_2einfF_24s444_lam0, 2, 2, (V[]){v_sp_242, v_x_243});
    }
    case TAG_IInt: {
      V v_i_247 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      return heff_clo(g_heff_2etoplevel_2einfF_24s444_lam1, 2, 1, (V[]){v_i_247});
    }
    case TAG_IFloat: {
      V v_x_2416 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      return heff_clo(g_heff_2etoplevel_2einfF_24s444_lam4, 2, 1, (V[]){v_x_2416});
    }
    case TAG_IString: {
      V v_s_2425 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      return heff_clo(g_heff_2etoplevel_2einfF_24s444_lam7, 2, 1, (V[]){v_s_2425});
    }
    case TAG_IApp: {
      V v_h_2434 = heff_field(v_it1_241, 0);
      V v_args_2435 = heff_field(v_it1_241, 1);
      heff_take_n(v_it1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2436 = (g_heff_2etoplevel_2einfF_24s444(heff_dup(v_h_2434)));
      return heff_clo(g_heff_2etoplevel_2einfF_24s444_lam10, 2, 3, (V[]){v_c_2436, v_h_2434, v_args_2435});
    }
    case TAG_IAnn: {
      V v_n0_2444 = heff_field(v_it1_241, 0);
      V v_n1_2445 = heff_field(v_it1_241, 1);
      heff_take_n(v_it1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2446 = (g_heff_2etoplevel_2echkF_24s443(v_n0_2444));
      return heff_clo(g_heff_2etoplevel_2einfF_24s444_lam12, 2, 2, (V[]){v_c_2446, v_n1_2445});
    }
    case TAG_ISpec: {
      V v_n0_2453 = heff_field(v_it1_241, 0);
      V v_x_2454 = heff_field(v_it1_241, 1);
      V v_v_2456 = heff_field(v_it1_241, 3);
      heff_take_n(v_it1_241, 11ULL, 4);
      heff_drop(v_sp_242);
      V v_c_2457 = (g_heff_2etoplevel_2echkF_24s443(v_v_2456));
      return heff_clo(g_heff_2etoplevel_2einfF_24s444_lam15, 2, 4, (V[]){v_c_2457, v_n0_2453, v_n_240, v_x_2454});
    }
    case TAG_IAnnLam: {
      V v_x_2467 = heff_field(v_it1_241, 0);
      V v_tyN_2469 = heff_field(v_it1_241, 2);
      V v_body_2470 = heff_field(v_it1_241, 3);
      heff_take_n(v_it1_241, 13ULL, 4);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2471 = ({ V a_0 = v_tyN_2469; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_tyN_2469); r_; });
      return heff_clo(g_heff_2etoplevel_2einfF_24s444_lam18, 2, 3, (V[]){v_c_2471, v_body_2470, v_x_2467});
    }
    case TAG_IInvalid: {
      V v_code_2478 = heff_field(v_it1_241, 0);
      V v_why_2479 = heff_field(v_it1_241, 1);
      heff_take_n(v_it1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      return heff_clo(g_heff_2etoplevel_2einfF_24s444_lam21, 2, 3, (V[]){v_code_2478, v_why_2479, v_sp_242});
    }
    case TAG_INominal: {
      V v_i_2486 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2487 = (g_heff_2etoplevel_2einfF_24s444(v_i_2486));
      return heff_clo(g_heff_2etoplevel_2einfF_24s444_lam22, 2, 1, (V[]){v_c_2487});
    }
    default: return heff_nomatch(v_it1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2etoplevel_2einfF_24s444_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2einfF_24s444(a[0]);
}
V g_heff_2etoplevel_2einfF_24s444_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_244);
  V v_t_246 = (g_heff_2erules_2efind(v_sp_242, v_x_243));
  V f_ = v_k_245;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam3(V self, V *args) {
  V v_u_2413 = args[0];
  heff_drop(v_u_2413);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2etoplevel_2einfF_24s444_lam2(V self, V *args) {
  V v_e_2410 = args[0];
  V v_hd_2411 = args[1];
  V v_k_2412 = args[2];
  V v_i_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2410);
  heff_drop(v_hd_2411);
  V v_t_2414 = heff_rec(2, shape_326_366, (V[]){heff_tag(TAG_SLitInt, 1, (V[]){v_i_247}), ((V)&g_heff_2etoplevel_2einfF_24s444_lam3_clo)});
  V v_t_2415 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2414, NTAG(TAG_VPrimInt)});
  V f_ = v_k_2412;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_i_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag(TAG_MkSyn, 1, (V[]){heff_clo(g_heff_2etoplevel_2einfF_24s444_lam2, 3, 1, (V[]){v_i_247})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam6(V self, V *args) {
  V v_u_2422 = args[0];
  heff_drop(v_u_2422);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2etoplevel_2einfF_24s444_lam5(V self, V *args) {
  V v_e_2419 = args[0];
  V v_hd_2420 = args[1];
  V v_k_2421 = args[2];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2419);
  heff_drop(v_hd_2420);
  V v_t_2423 = heff_rec(2, shape_326_366, (V[]){heff_tag(TAG_SLitFloat, 1, (V[]){v_x_2416}), ((V)&g_heff_2etoplevel_2einfF_24s444_lam6_clo)});
  V v_t_2424 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2423, NTAG(TAG_VPrimFloat)});
  V f_ = v_k_2421;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = heff_tag(TAG_MkSyn, 1, (V[]){heff_clo(g_heff_2etoplevel_2einfF_24s444_lam5, 3, 1, (V[]){v_x_2416})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam9(V self, V *args) {
  V v_u_2431 = args[0];
  heff_drop(v_u_2431);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2etoplevel_2einfF_24s444_lam8(V self, V *args) {
  V v_e_2428 = args[0];
  V v_hd_2429 = args[1];
  V v_k_2430 = args[2];
  V v_s_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2428);
  heff_drop(v_hd_2429);
  V v_t_2432 = heff_rec(2, shape_326_366, (V[]){heff_tag(TAG_SLitString, 1, (V[]){v_s_2425}), ((V)&g_heff_2etoplevel_2einfF_24s444_lam9_clo)});
  V v_t_2433 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2432, NTAG(TAG_VPrimString)});
  V f_ = v_k_2430;
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam7(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_s_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = heff_tag(TAG_MkSyn, 1, (V[]){heff_clo(g_heff_2etoplevel_2einfF_24s444_lam8, 3, 1, (V[]){v_s_2425})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam11(V self, V *args) {
  V v_x_2439 = args[0];
  V v_h_2434 = heff_env(self)[0];
  V v_args_2435 = heff_env(self)[1];
  V v_hd_2437 = heff_env(self)[2];
  V v_k_2438 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2442;
  switch (heff_tag_of(v_h_2434)) {
  case TAG_At: {
    V v_s_2441 = heff_field(v_h_2434, 1);
    heff_take_n(v_h_2434, 2ULL, 2);
    v_t_2442 = v_s_2441;
    break;
  }
  default: heff_nomatch(v_h_2434);
  }
  V v_c_2443 = ({ V a_0 = heff_get(v_t_2442, LBL_start); V a_1 = v_x_2439; V a_2 = v_args_2435; V r_ = (g_heff_2etoplevel_2eelimAll_24s445(a_0, a_1, a_2)); heff_drop(v_args_2435); r_; });
  return heff_tail(v_c_2443, 2, (V[]){v_hd_2437, v_k_2438});
}
V g_heff_2etoplevel_2einfF_24s444_lam10(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_c_2436 = heff_env(self)[0];
  V v_h_2434 = heff_env(self)[1];
  V v_args_2435 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2436;
  args[0] = heff_dup(v_hd_2437);
  args[1] = heff_clo(g_heff_2etoplevel_2einfF_24s444_lam11, 1, 4, (V[]){v_h_2434, v_args_2435, v_hd_2437, v_k_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam14(V self, V *args) {
  V v_x_2451 = args[0];
  V v_x_2449 = heff_env(self)[0];
  V v_k_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2452 = ({ V a_0 = v_x_2451; V a_1 = v_x_2449; V r_ = (g_heff_2erules_2eannot(a_0, a_1)); heff_drop(v_x_2451); heff_drop(v_x_2449); r_; });
  V f_ = v_k_2448;
  args[0] = v_t_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam13(V self, V *args) {
  V v_x_2449 = args[0];
  V v_n1_2445 = heff_env(self)[0];
  V v_hd_2447 = heff_env(self)[1];
  V v_k_2448 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2450 = ({ V a_0 = v_n1_2445; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_n1_2445); r_; });
  return heff_tail(v_c_2450, 2, (V[]){v_hd_2447, heff_clo(g_heff_2etoplevel_2einfF_24s444_lam14, 1, 2, (V[]){v_x_2449, v_k_2448})});
}
V g_heff_2etoplevel_2einfF_24s444_lam12(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  V v_n1_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2446;
  args[0] = heff_dup(v_hd_2447);
  args[1] = heff_clo(g_heff_2etoplevel_2einfF_24s444_lam13, 1, 3, (V[]){v_n1_2445, v_hd_2447, v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam17(V self, V *args) {
  V v_x_2462 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2454 = heff_env(self)[1];
  V v_x_2460 = heff_env(self)[2];
  V v_k_2459 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2465;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2464 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2465 = v_s_2464;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2466 = ({ V a_0 = v_t_2465; V a_1 = v_x_2462; V a_2 = v_x_2454; V a_3 = v_x_2460; V r_ = (g_heff_2erules_2erecordSpec(a_0, a_1, a_2, a_3)); heff_drop(v_x_2462); heff_drop(v_x_2460); r_; });
  V f_ = v_k_2459;
  args[0] = v_x_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam16(V self, V *args) {
  V v_x_2460 = args[0];
  V v_n0_2453 = heff_env(self)[0];
  V v_hd_2458 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2454 = heff_env(self)[3];
  V v_k_2459 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2461 = (g_heff_2etoplevel_2einfF_24s444(v_n0_2453));
  return heff_tail(v_c_2461, 2, (V[]){v_hd_2458, heff_clo(g_heff_2etoplevel_2einfF_24s444_lam17, 1, 4, (V[]){v_n_240, v_x_2454, v_x_2460, v_k_2459})});
}
V g_heff_2etoplevel_2einfF_24s444_lam15(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_c_2457 = heff_env(self)[0];
  V v_n0_2453 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2454 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2457;
  args[0] = heff_dup(v_hd_2458);
  args[1] = heff_clo(g_heff_2etoplevel_2einfF_24s444_lam16, 1, 5, (V[]){v_n0_2453, v_hd_2458, v_n_240, v_x_2454, v_k_2459});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam20(V self, V *args) {
  V v_x_2476 = args[0];
  V v_x_2467 = heff_env(self)[0];
  V v_x_2474 = heff_env(self)[1];
  V v_k_2473 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2477 = ({ V a_0 = v_x_2467; V a_1 = v_x_2474; V a_2 = v_x_2476; V r_ = (g_heff_2erules_2efunctionIntroSyn(a_0, a_1, a_2)); heff_drop(v_x_2474); heff_drop(v_x_2476); r_; });
  V f_ = v_k_2473;
  args[0] = v_t_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam19(V self, V *args) {
  V v_x_2474 = args[0];
  V v_body_2470 = heff_env(self)[0];
  V v_hd_2472 = heff_env(self)[1];
  V v_x_2467 = heff_env(self)[2];
  V v_k_2473 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2475 = (g_heff_2etoplevel_2einfF_24s444(v_body_2470));
  return heff_tail(v_c_2475, 2, (V[]){v_hd_2472, heff_clo(g_heff_2etoplevel_2einfF_24s444_lam20, 1, 3, (V[]){v_x_2467, v_x_2474, v_k_2473})});
}
V g_heff_2etoplevel_2einfF_24s444_lam18(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k_2473 = args[1];
  V v_c_2471 = heff_env(self)[0];
  V v_body_2470 = heff_env(self)[1];
  V v_x_2467 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2471;
  args[0] = heff_dup(v_hd_2472);
  args[1] = heff_clo(g_heff_2etoplevel_2einfF_24s444_lam19, 1, 4, (V[]){v_body_2470, v_hd_2472, v_x_2467, v_k_2473});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam21(V self, V *args) {
  V v_hd_2480 = args[0];
  V v_k2_2481 = args[1];
  V v_code_2478 = heff_env(self)[0];
  V v_why_2479 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2482 = heff_rec(5, shape_47_297_193_314_206, (V[]){heff_intAdd(MK_INT(200LL), v_code_2478), NTAG(TAG_SError), v_why_2479, v_sp_242, NTAG(TAG_Nothing)});
  V v_t_2483 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2480), LBL_malg), 1, (V[]){v_t_2484}));
  V f_ = heff_get(v_hd_2480, LBL_bind);
  args[0] = v_t_2485;
  args[1] = v_k2_2481;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam23(V self, V *args) {
  V v_x_2490 = args[0];
  V v_k_2489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2491 = ({ V a_0 = v_x_2490; V r_ = (g_heff_2etoplevel_2enominalSyn(a_0)); heff_drop(v_x_2490); r_; });
  V f_ = v_k_2489;
  args[0] = v_t_2491;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2einfF_24s444_lam22(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_c_2487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2487;
  args[0] = v_hd_2488;
  args[1] = heff_clo(g_heff_2etoplevel_2einfF_24s444_lam23, 1, 1, (V[]){v_k_2489});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etraverseEL_24s448_lam0(V self, V *args); static Clo g_heff_2etoplevel_2etraverseEL_24s448_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s448_lam0, 2, 0};
V g_heff_2etoplevel_2etraverseEL_24s448_lam3(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s448_lam2(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s448_lam1(V self, V *args);
Clo g_heff_2etoplevel_2etraverseEL_24s448_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s448_entry, 1, 0};

V g_heff_2etoplevel_2etraverseEL_24s448(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2etoplevel_2etraverseEL_24s448_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_245 = (g_heff_2etoplevel_2echkF_24s443(v_x_243));
    V v_c_246 = heff_tr(heff_apply(((V)&g_heff_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_245}));
    return heff_clo(g_heff_2etoplevel_2etraverseEL_24s448_lam1, 2, 2, (V[]){v_c_246, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2etraverseEL_24s448_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2etraverseEL_24s448(a[0]);
}
V g_heff_2etoplevel_2etraverseEL_24s448_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s448_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s448_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2410 = (g_heff_2etoplevel_2etraverseEL_24s448(v_xs_244));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2etoplevel_2etraverseEL_24s448_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2etoplevel_2etraverseEL_24s448_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2etoplevel_2etraverseEL_24s448_lam2, 1, 3, (V[]){v_xs_244, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[44]; } g_heff_2etoplevel_2efieldSetF_24s449_str0 = {{0x80000000u, K_STR, 0}, 44, 44, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 102, 105, 101, 108, 100, 32, 115, 101, 116, 116, 105, 110, 103, 32, 111, 102, 32, 116, 104, 101, 32, 102, 111, 114, 109, 32, 96, 120, 32, 61, 32, 118, 96}};
V g_heff_2etoplevel_2efieldSetF_24s449_lam1(V self, V *args);
V g_heff_2etoplevel_2efieldSetF_24s449_lam0(V self, V *args);
V g_heff_2etoplevel_2efieldSetF_24s449_lam2(V self, V *args);
Clo g_heff_2etoplevel_2efieldSetF_24s449_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2efieldSetF_24s449_entry, 1, 0};

V g_heff_2etoplevel_2efieldSetF_24s449(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_SetField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_e_245 = heff_field(v_x21_241, 2);
      V v_t_246 = (g_heff_2etoplevel_2echkF_24s443(heff_dup(v_e_245)));
      V v_c_247 = heff_tr(heff_apply(((V)&g_heff_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_246}));
      return heff_clo(g_heff_2etoplevel_2efieldSetF_24s449_lam0, 2, 4, (V[]){v_c_247, heff_dup(v_e_245), heff_dup(v_x_243), heff_dup(v_xsp_244)});
    }
    case TAG_BadFieldSet: {
      return heff_clo(g_heff_2etoplevel_2efieldSetF_24s449_lam2, 2, 1, (V[]){heff_dup(v_x22_242)});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2efieldSetF_24s449_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2efieldSetF_24s449(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2efieldSetF_24s449_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_xsp_244 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413;
  switch (heff_tag_of(v_e_245)) {
  case TAG_At: {
    V v_s_2412 = heff_field(v_e_245, 1);
    heff_take_n(v_e_245, 2ULL, 2);
    v_t_2413 = v_s_2412;
    break;
  }
  default: heff_nomatch(v_e_245);
  }
  V v_x_2414 = heff_rec(4, shape_198_43_314_199, (V[]){v_x_243, v_x_2410, v_t_2413, v_xsp_244});
  V f_ = v_k_249;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2efieldSetF_24s449_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_e_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_xsp_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo(g_heff_2etoplevel_2efieldSetF_24s449_lam1, 1, 4, (V[]){v_e_245, v_x_243, v_xsp_244, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2efieldSetF_24s449_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k2_2417 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(202LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2efieldSetF_24s449_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2416), LBL_malg), 1, (V[]){v_t_2420}));
  V f_ = heff_get(v_hd_2416, LBL_bind);
  args[0] = v_t_2421;
  args[1] = v_k2_2417;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etraverseEL_24s450_lam0(V self, V *args); static Clo g_heff_2etoplevel_2etraverseEL_24s450_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s450_lam0, 2, 0};
V g_heff_2etoplevel_2etraverseEL_24s450_lam3(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s450_lam2(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s450_lam1(V self, V *args);
Clo g_heff_2etoplevel_2etraverseEL_24s450_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s450_entry, 1, 0};

V g_heff_2etoplevel_2etraverseEL_24s450(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2etoplevel_2etraverseEL_24s450_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2etoplevel_2efieldSetF_24s449(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo(g_heff_2etoplevel_2etraverseEL_24s450_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2etraverseEL_24s450_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2etraverseEL_24s450(a[0]);
}
V g_heff_2etoplevel_2etraverseEL_24s450_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s450_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s450_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2etoplevel_2etraverseEL_24s450(v_xs_244));
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo(g_heff_2etoplevel_2etraverseEL_24s450_lam3, 1, 2, (V[]){v_k_247, v_x_248})});
}
V g_heff_2etoplevel_2etraverseEL_24s450_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2etoplevel_2etraverseEL_24s450_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2edoCase_24s451_lam2(V self, V *args);
V g_heff_2etoplevel_2edoCase_24s451_lam1(V self, V *args);
V g_heff_2etoplevel_2edoCase_24s451_lam0(V self, V *args);
Clo g_heff_2etoplevel_2edoCase_24s451_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2edoCase_24s451_entry, 1, 0};

V g_heff_2etoplevel_2edoCase_24s451(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkAlt: {
      V v_p_243 = heff_field(v_x21_241, 0);
      V v_body_244 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_c_245 = (g_heff_2etoplevel_2edoPat(v_p_243));
      return heff_clo(g_heff_2etoplevel_2edoCase_24s451_lam0, 2, 2, (V[]){v_c_245, v_body_244});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2edoCase_24s451_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2edoCase_24s451(a[0]);
}
V g_heff_2etoplevel_2edoCase_24s451_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_xs_2410 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414 = heff_tag(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_xs_2410), v_x_2413});
  V f_ = v_k_247;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_x_249, v_t_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2edoCase_24s451_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_body_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x_248, 0);
    V v_xs_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2411 = (g_heff_2etoplevel_2echkF_24s443(v_body_244));
    V v_c_2412 = heff_tr(heff_apply(((V)&g_heff_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_2411}));
    return heff_tail(v_c_2412, 2, (V[]){v_hd_246, heff_clo(g_heff_2etoplevel_2edoCase_24s451_lam2, 1, 3, (V[]){v_xs_2410, v_k_247, v_x_249})});
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2etoplevel_2edoCase_24s451_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_body_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2etoplevel_2edoCase_24s451_lam1, 1, 3, (V[]){v_body_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etraverseEL_24s452_lam0(V self, V *args); static Clo g_heff_2etoplevel_2etraverseEL_24s452_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s452_lam0, 2, 0};
V g_heff_2etoplevel_2etraverseEL_24s452_lam3(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s452_lam2(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s452_lam1(V self, V *args);
Clo g_heff_2etoplevel_2etraverseEL_24s452_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s452_entry, 1, 0};

V g_heff_2etoplevel_2etraverseEL_24s452(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2etoplevel_2etraverseEL_24s452_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = (g_heff_2etoplevel_2edoCase_24s451(v_x_243));
    return heff_clo(g_heff_2etoplevel_2etraverseEL_24s452_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2etraverseEL_24s452_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2etraverseEL_24s452(a[0]);
}
V g_heff_2etoplevel_2etraverseEL_24s452_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s452_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s452_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2etoplevel_2etraverseEL_24s452(v_xs_244));
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo(g_heff_2etoplevel_2etraverseEL_24s452_lam3, 1, 2, (V[]){v_k_247, v_x_248})});
}
V g_heff_2etoplevel_2etraverseEL_24s452_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2etoplevel_2etraverseEL_24s452_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2elocalBody_24s454_lam3(V self, V *args);
V g_heff_2etoplevel_2elocalBody_24s454_lam5(V self, V *args);
V g_heff_2etoplevel_2elocalBody_24s454_lam4(V self, V *args);
V g_heff_2etoplevel_2elocalBody_24s454_lam2(V self, V *args);
V g_heff_2etoplevel_2elocalBody_24s454_lam8(V self, V *args);
V g_heff_2etoplevel_2elocalBody_24s454_lam9(V self, V *args);
V g_heff_2etoplevel_2elocalBody_24s454_lam7(V self, V *args);
V g_heff_2etoplevel_2elocalBody_24s454_lam6(V self, V *args);
V g_heff_2etoplevel_2elocalBody_24s454_lam1(V self, V *args);
V g_heff_2etoplevel_2elocalBody_24s454_lam0(V self, V *args);
V g_heff_2etoplevel_2elocalBody_24s454_lam10(V self, V *args);
Clo g_heff_2etoplevel_2elocalBody_24s454_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2elocalBody_24s454_entry, 3, 0};

V g_heff_2etoplevel_2elocalBody_24s454(V v_f_240, V v_eqs_241, V v_sp_242) {
top: ;
  V v_x1_243 = (g_heff_2etoplevel_2eallL_24s436(v_eqs_241));
  V v_t_244;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_True: {
    v_t_244 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_244 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return heff_clo(g_heff_2etoplevel_2elocalBody_24s454_lam0, 2, 3, (V[]){v_eqs_241, v_f_240, v_sp_242});
  }
  case TAG_False: {
    V v_t_2438 = (g_heff_2eclauses_2edesugar(v_f_240, NTAG(TAG_Nil), v_eqs_241, v_sp_242));
    switch (heff_tag_of(v_t_2438)) {
    case TAG_Left: {
      V v_err_2439 = heff_field(v_t_2438, 0);
      heff_take_n(v_t_2438, 1ULL, 1);
      return heff_clo(g_heff_2etoplevel_2elocalBody_24s454_lam10, 2, 1, (V[]){v_err_2439});
    }
    case TAG_Right: {
      V v_b_2446 = heff_field(v_t_2438, 0);
      heff_take_n(v_t_2438, 1ULL, 1);
      return (g_heff_2etoplevel_2echkF_24s443(v_b_2446));
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2etoplevel_2elocalBody_24s454_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2elocalBody_24s454(a[0], a[1], a[2]);
}
V g_heff_2etoplevel_2elocalBody_24s454_lam3(V self, V *args) {
  V v_m_2416 = args[0];
  V v_e_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2etoplevel_2eopPat(heff_get(v_e_247, LBL_globals), v_m_2416));
}
V g_heff_2etoplevel_2elocalBody_24s454_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_f_2412 = heff_env(self)[0];
  V v_fsp_2413 = heff_env(self)[1];
  V v_rhs_2415 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2421 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_MkEquation, 4, (V[]){v_f_2412, v_fsp_2413, v_x_2420, v_rhs_2415}), v_sp_2411});
  V f_ = v_k_2419;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2elocalBody_24s454_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_f_2412 = heff_env(self)[1];
  V v_fsp_2413 = heff_env(self)[2];
  V v_rhs_2415 = heff_env(self)[3];
  V v_sp_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo(g_heff_2etoplevel_2elocalBody_24s454_lam5, 1, 5, (V[]){v_f_2412, v_fsp_2413, v_rhs_2415, v_sp_2411, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2elocalBody_24s454_lam2(V self, V *args) {
  V v_m_249 = args[0];
  V v_e_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_249)) {
  case TAG_At: {
    V v_x21_2410 = heff_field(v_m_249, 0);
    V v_sp_2411 = heff_field(v_m_249, 1);
    heff_take_n(v_m_249, 3ULL, 2);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkEquation: {
      V v_f_2412 = heff_field(v_x21_2410, 0);
      V v_fsp_2413 = heff_field(v_x21_2410, 1);
      V v_ps_2414 = heff_field(v_x21_2410, 2);
      V v_rhs_2415 = heff_field(v_x21_2410, 3);
      heff_take_n(v_x21_2410, 15ULL, 4);
      V v_c_2417 = (g_heff_2etoplevel_2etraverseEL(heff_clo(g_heff_2etoplevel_2elocalBody_24s454_lam3, 1, 1, (V[]){v_e_247}), v_ps_2414));
      return heff_clo(g_heff_2etoplevel_2elocalBody_24s454_lam4, 2, 5, (V[]){v_c_2417, v_f_2412, v_fsp_2413, v_rhs_2415, v_sp_2411});
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_m_249);
  }
}
V g_heff_2etoplevel_2elocalBody_24s454_lam8(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k2_2429 = args[1];
  V v_err_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(210LL), NTAG(TAG_SError), heff_get(heff_dup(v_err_2427), LBL_msg), heff_get(v_err_2427, LBL_span), NTAG(TAG_Nothing)});
  V v_t_2431 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2428), LBL_malg), 1, (V[]){v_t_2432}));
  V f_ = heff_get(v_hd_2428, LBL_bind);
  args[0] = v_t_2433;
  args[1] = v_k2_2429;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2elocalBody_24s454_lam9(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_247 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  V v_hd_2423 = heff_env(self)[2];
  V v_k_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2436)) {
  case TAG_MkChk: {
    V v_f_2437 = heff_field(v_x_2436, 0);
    heff_take_n(v_x_2436, 1ULL, 1);
    return heff_tail(v_f_2437, 4, (V[]){v_e_247, v_a_248, v_hd_2423, v_k_2424});
  }
  default: return heff_nomatch(v_x_2436);
  }
}
V g_heff_2etoplevel_2elocalBody_24s454_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_hd_2423 = heff_env(self)[2];
  V v_e_247 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  V v_k_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2426 = (g_heff_2eclauses_2edesugar(v_f_240, NTAG(TAG_Nil), v_x_2425, v_sp_242));
  V v_c_2435;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Left: {
    V v_err_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    v_c_2435 = heff_clo(g_heff_2etoplevel_2elocalBody_24s454_lam8, 2, 1, (V[]){v_err_2427});
    break;
  }
  case TAG_Right: {
    V v_b_2434 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    v_c_2435 = (g_heff_2etoplevel_2echkF_24s443(v_b_2434));
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  return heff_tail(v_c_2435, 2, (V[]){heff_dup(v_hd_2423), heff_clo(g_heff_2etoplevel_2elocalBody_24s454_lam9, 1, 4, (V[]){v_e_247, v_a_248, v_hd_2423, v_k_2424})});
}
V g_heff_2etoplevel_2elocalBody_24s454_lam6(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_e_247 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo(g_heff_2etoplevel_2elocalBody_24s454_lam7, 1, 6, (V[]){v_f_240, v_sp_242, v_hd_2423, v_e_247, v_a_248, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2elocalBody_24s454_lam1(V self, V *args) {
  V v_e_247 = args[0];
  V v_a_248 = args[1];
  V v_eqs_241 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2422 = (g_heff_2etoplevel_2etraverseEL(heff_clo(g_heff_2etoplevel_2elocalBody_24s454_lam2, 1, 1, (V[]){heff_dup(v_e_247)}), v_eqs_241));
  return heff_clo(g_heff_2etoplevel_2elocalBody_24s454_lam6, 2, 5, (V[]){v_c_2422, v_f_240, v_sp_242, v_e_247, v_a_248});
}
V g_heff_2etoplevel_2elocalBody_24s454_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_eqs_241 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2etoplevel_2elocalBody_24s454_lam1, 2, 3, (V[]){v_eqs_241, v_f_240, v_sp_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2elocalBody_24s454_lam10(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_err_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(210LL), NTAG(TAG_SError), heff_get(heff_dup(v_err_2439), LBL_msg), heff_get(v_err_2439, LBL_span), NTAG(TAG_Nothing)});
  V v_t_2443 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2440), LBL_malg), 1, (V[]){v_t_2444}));
  V f_ = heff_get(v_hd_2440, LBL_bind);
  args[0] = v_t_2445;
  args[1] = v_k2_2441;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[40]; } g_heff_2etoplevel_2elocalsJ_24s453_str0 = {{0x80000000u, K_STR, 0}, 40, 40, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 108, 111, 99, 97, 108, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[40]; } g_heff_2etoplevel_2elocalsJ_24s453_str1 = {{0x80000000u, K_STR, 0}, 40, 40, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 108, 111, 99, 97, 108, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[40]; } g_heff_2etoplevel_2elocalsJ_24s453_str2 = {{0x80000000u, K_STR, 0}, 40, 40, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 108, 111, 99, 97, 108, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[40]; } g_heff_2etoplevel_2elocalsJ_24s453_str3 = {{0x80000000u, K_STR, 0}, 40, 40, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 108, 111, 99, 97, 108, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[40]; } g_heff_2etoplevel_2elocalsJ_24s453_str4 = {{0x80000000u, K_STR, 0}, 40, 40, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 108, 111, 99, 97, 108, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110}};
V g_heff_2etoplevel_2elocalsJ_24s453_lam3(V self, V *args);
V g_heff_2etoplevel_2elocalsJ_24s453_lam2(V self, V *args);
V g_heff_2etoplevel_2elocalsJ_24s453_lam1(V self, V *args);
V g_heff_2etoplevel_2elocalsJ_24s453_lam0(V self, V *args);
V g_heff_2etoplevel_2elocalsJ_24s453_lam4(V self, V *args);
V g_heff_2etoplevel_2elocalsJ_24s453_lam5(V self, V *args);
V g_heff_2etoplevel_2elocalsJ_24s453_lam6(V self, V *args);
V g_heff_2etoplevel_2elocalsJ_24s453_lam7(V self, V *args);
V g_heff_2etoplevel_2elocalsJ_24s453_lam8(V self, V *args);
Clo g_heff_2etoplevel_2elocalsJ_24s453_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2elocalsJ_24s453_entry, 2, 0};

V g_heff_2etoplevel_2elocalsJ_24s453(V v_x2_240, V v_body_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return (g_heff_2etoplevel_2echkF_24s443(v_body_241));
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_240, 0);
    V v_ds_243 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_d_242)) {
    case TAG_At: {
      V v_x_244 = heff_field(v_d_242, 0);
      v_t_246 = heff_dup(v_x_244);
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_DeclEquations: {
      V v_name_247 = heff_field(v_t_246, 0);
      V v_tyN_249 = heff_field(v_t_246, 2);
      V v_eqs_2410 = heff_field(v_t_246, 3);
      heff_take_n(v_t_246, 13ULL, 4);
      V v_c_2411 = ({ V a_0 = v_tyN_249; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_tyN_249); r_; });
      return heff_clo(g_heff_2etoplevel_2elocalsJ_24s453_lam0, 2, 6, (V[]){v_c_2411, heff_dup(v_d_242), v_name_247, v_eqs_2410, heff_dup(v_ds_243), v_body_241});
    }
    case TAG_DeclDefine: {
      heff_take_n(v_t_246, 0ULL, 5);
      heff_drop(v_body_241);
      V v_sp_2430;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2429 = heff_field(v_d_242, 1);
        v_sp_2430 = heff_dup(v_s_2429);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo(g_heff_2etoplevel_2elocalsJ_24s453_lam4, 2, 1, (V[]){v_sp_2430});
    }
    case TAG_DeclTheory: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop(v_body_241);
      V v_sp_2443;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2442 = heff_field(v_d_242, 1);
        v_sp_2443 = heff_dup(v_s_2442);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo(g_heff_2etoplevel_2elocalsJ_24s453_lam5, 2, 1, (V[]){v_sp_2443});
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop(v_body_241);
      V v_sp_2455;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2454 = heff_field(v_d_242, 1);
        v_sp_2455 = heff_dup(v_s_2454);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo(g_heff_2etoplevel_2elocalsJ_24s453_lam6, 2, 1, (V[]){v_sp_2455});
    }
    case TAG_DeclTest: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_body_241);
      V v_sp_2466;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2465 = heff_field(v_d_242, 1);
        v_sp_2466 = heff_dup(v_s_2465);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo(g_heff_2etoplevel_2elocalsJ_24s453_lam7, 2, 1, (V[]){v_sp_2466});
    }
    case TAG_DeclWatch: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_body_241);
      V v_sp_2476;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2475 = heff_field(v_d_242, 1);
        v_sp_2476 = heff_dup(v_s_2475);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo(g_heff_2etoplevel_2elocalsJ_24s453_lam8, 2, 1, (V[]){v_sp_2476});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2elocalsJ_24s453_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2elocalsJ_24s453(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2elocalsJ_24s453_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_name_247 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_k_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2422 = ({ V a_0 = v_name_247; V a_1 = v_x_2414; V a_2 = v_x_2419; V a_3 = v_x_2421; V r_ = (g_heff_2erules_2elocalDef(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); heff_drop(v_x_2419); heff_drop(v_x_2421); r_; });
  V f_ = v_k_2413;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2elocalsJ_24s453_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ds_243 = heff_env(self)[0];
  V v_body_241 = heff_env(self)[1];
  V v_hd_2412 = heff_env(self)[2];
  V v_name_247 = heff_env(self)[3];
  V v_x_2414 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2420 = ({ V a_0 = v_ds_243; V a_1 = v_body_241; V r_ = (g_heff_2etoplevel_2elocalsJ_24s453(a_0, a_1)); heff_drop(v_ds_243); r_; });
  return heff_tail(v_c_2420, 2, (V[]){v_hd_2412, heff_clo(g_heff_2etoplevel_2elocalsJ_24s453_lam3, 1, 4, (V[]){v_name_247, v_x_2414, v_x_2419, v_k_2413})});
}
V g_heff_2etoplevel_2elocalsJ_24s453_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_name_247 = heff_env(self)[1];
  V v_eqs_2410 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_ds_243 = heff_env(self)[4];
  V v_body_241 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2417;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2416 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2417 = v_s_2416;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_c_2418 = (g_heff_2etoplevel_2elocalBody_24s454(heff_dup(v_name_247), v_eqs_2410, v_t_2417));
  return heff_tail(v_c_2418, 2, (V[]){heff_dup(v_hd_2412), heff_clo(g_heff_2etoplevel_2elocalsJ_24s453_lam2, 1, 6, (V[]){v_ds_243, v_body_241, v_hd_2412, v_name_247, v_x_2414, v_k_2413})});
}
V g_heff_2etoplevel_2elocalsJ_24s453_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_name_247 = heff_env(self)[2];
  V v_eqs_2410 = heff_env(self)[3];
  V v_ds_243 = heff_env(self)[4];
  V v_body_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo(g_heff_2etoplevel_2elocalsJ_24s453_lam1, 1, 7, (V[]){v_d_242, v_name_247, v_eqs_2410, v_hd_2412, v_ds_243, v_body_241, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2elocalsJ_24s453_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k2_2432 = args[1];
  V v_sp_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2elocalsJ_24s453_str0), v_sp_2430, NTAG(TAG_Nothing)});
  V v_t_2434 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2431), LBL_malg), 1, (V[]){v_t_2435}));
  V f_ = heff_get(v_hd_2431, LBL_bind);
  args[0] = v_t_2436;
  args[1] = v_k2_2432;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2elocalsJ_24s453_lam5(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k2_2445 = args[1];
  V v_sp_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2elocalsJ_24s453_str1), v_sp_2443, NTAG(TAG_Nothing)});
  V v_t_2447 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2444), LBL_malg), 1, (V[]){v_t_2448}));
  V f_ = heff_get(v_hd_2444, LBL_bind);
  args[0] = v_t_2449;
  args[1] = v_k2_2445;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2elocalsJ_24s453_lam6(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_sp_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2elocalsJ_24s453_str2), v_sp_2455, NTAG(TAG_Nothing)});
  V v_t_2459 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2456), LBL_malg), 1, (V[]){v_t_2460}));
  V f_ = heff_get(v_hd_2456, LBL_bind);
  args[0] = v_t_2461;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2elocalsJ_24s453_lam7(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k2_2468 = args[1];
  V v_sp_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2elocalsJ_24s453_str3), v_sp_2466, NTAG(TAG_Nothing)});
  V v_t_2470 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2467), LBL_malg), 1, (V[]){v_t_2471}));
  V f_ = heff_get(v_hd_2467, LBL_bind);
  args[0] = v_t_2472;
  args[1] = v_k2_2468;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2elocalsJ_24s453_lam8(V self, V *args) {
  V v_hd_2477 = args[0];
  V v_k2_2478 = args[1];
  V v_sp_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2479 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2elocalsJ_24s453_str4), v_sp_2476, NTAG(TAG_Nothing)});
  V v_t_2480 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2477), LBL_malg), 1, (V[]){v_t_2481}));
  V f_ = heff_get(v_hd_2477, LBL_bind);
  args[0] = v_t_2482;
  args[1] = v_k2_2478;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2etoplevel_2erawF_24s447_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 116}};
V g_heff_2etoplevel_2erawF_24s447_lam1(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam0(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam3(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam2(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam6(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam5(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam4(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam8(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam7(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam10(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam9(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam15(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam14(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam13(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam18(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam17(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam16(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam12(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam11(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam21(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam20(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam19(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam22(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam25(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam24(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam23(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam28(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam27(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam26(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam29(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam31(V self, V *args);
V g_heff_2etoplevel_2erawF_24s447_lam30(V self, V *args);
Clo g_heff_2etoplevel_2erawF_24s447_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2erawF_24s447_entry, 1, 0};

V g_heff_2etoplevel_2erawF_24s447(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_it1_241 = heff_dup(heff_field(v_n_240, 0));
    V v_it2_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_it1_241)) {
    case TAG_CInf: {
      heff_take_n(v_it1_241, 0ULL, 1);
      heff_drop(v_it2_242);
      HEFF_LAST return g_heff_2etoplevel_2echkF_24s443(v_n_240);
    }
    case TAG_CType: {
      heff_take_n(v_it1_241, 0ULL, 1);
      heff_drop(v_it2_242);
      HEFF_LAST return g_heff_2etoplevel_2echkF_24s443(v_n_240);
    }
    case TAG_CLam: {
      V v_x_245 = heff_field(v_it1_241, 0);
      V v_body_247 = heff_field(v_it1_241, 2);
      heff_take_n(v_it1_241, 5ULL, 3);
      heff_drop(v_it2_242);
      V v_t_248 = (g_heff_2etoplevel_2echkF_24s443(v_body_247));
      V v_c_249 = heff_tr(heff_apply(((V)&g_heff_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_248}));
      return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam0, 2, 3, (V[]){v_c_249, v_n_240, v_x_245});
    }
    case TAG_CImplicitLam: {
      V v_x_2417 = heff_field(v_it1_241, 0);
      V v_body_2419 = heff_field(v_it1_241, 2);
      heff_take_n(v_it1_241, 5ULL, 3);
      heff_drop(v_it2_242);
      V v_t_2420 = (g_heff_2etoplevel_2echkF_24s443(v_body_2419));
      V v_c_2421 = heff_tr(heff_apply(((V)&g_heff_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_2420}));
      return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam2, 2, 3, (V[]){v_c_2421, v_n_240, v_x_2417});
    }
    case TAG_CAnnLam: {
      V v_x_2429 = heff_field(v_it1_241, 0);
      V v_tyN_2431 = heff_field(v_it1_241, 2);
      V v_body_2432 = heff_field(v_it1_241, 3);
      heff_take_n(v_it1_241, 13ULL, 4);
      heff_drop(v_it2_242);
      V v_c_2433 = ({ V a_0 = v_tyN_2431; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_tyN_2431); r_; });
      return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam4, 2, 4, (V[]){v_c_2433, v_body_2432, v_n_240, v_x_2429});
    }
    case TAG_CTag: {
      V v_x_2443 = heff_field(v_it1_241, 0);
      V v_tsp_2444 = heff_field(v_it1_241, 1);
      V v_args_2445 = heff_field(v_it1_241, 2);
      heff_take_n(v_it1_241, 7ULL, 3);
      heff_drop(v_it2_242);
      V v_c_2446 = (g_heff_2etoplevel_2etraverseEL_24s448(v_args_2445));
      return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam7, 2, 4, (V[]){v_c_2446, v_n_240, v_tsp_2444, v_x_2443});
    }
    case TAG_CStruct: {
      V v_fields_2454 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      V v_c_2455 = (g_heff_2etoplevel_2etraverseEL_24s450(v_fields_2454));
      return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam9, 2, 2, (V[]){v_c_2455, v_it2_242});
    }
    case TAG_CMatch: {
      V v_scrutN_2460 = heff_field(v_it1_241, 0);
      V v_casesN_2461 = heff_field(v_it1_241, 1);
      heff_take_n(v_it1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      V v_x1_2462 = (g_heff_2etoplevel_2eallL_24s437(v_casesN_2461));
      V v_t_2463;
      switch (heff_tag_of(v_x1_2462)) {
      case TAG_True: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2463 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x1_2462);
      }
      switch (heff_tag_of(v_t_2463)) {
      case TAG_True: {
        return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam11, 2, 3, (V[]){v_casesN_2461, v_scrutN_2460, v_it2_242});
      }
      case TAG_False: {
        V v_t_2486 = (g_heff_2etoplevel_2eallL_24s438(v_casesN_2461));
        V v_t_2488;
        switch (heff_tag_of(v_t_2486)) {
        case TAG_True: {
          V v_x1_2487 = (g_heff_2etoplevel_2eannotatesData(v_scrutN_2460));
          switch (heff_tag_of(v_x1_2487)) {
          case TAG_True: {
            v_t_2488 = NTAG(TAG_False);
            break;
          }
          case TAG_False: {
            v_t_2488 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_x1_2487);
          }
          break;
        }
        case TAG_False: {
          v_t_2488 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2486);
        }
        switch (heff_tag_of(v_t_2488)) {
        case TAG_True: {
          V v_c_2489 = (g_heff_2etoplevel_2einfF_24s444(v_scrutN_2460));
          return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam19, 2, 3, (V[]){v_c_2489, v_casesN_2461, v_it2_242});
        }
        case TAG_False: {
          V v_x1_24101 = (g_heff_2eclauses_2etraverseC_24s302(v_casesN_2461));
          V v_t_24107;
          switch (heff_tag_of(v_x1_24101)) {
          case TAG_Left: {
            V v_e_24102 = heff_field(v_x1_24101, 0);
            V v_ru_24x1_24101_24Left = heff_take_reuse_n(v_x1_24101, 1ULL, 1);
            heff_drop(v_it2_242);
            v_t_24107 = heff_tag_at(v_ru_24x1_24101_24Left, TAG_Left, 1, (V[]){v_e_24102});
            break;
          }
          case TAG_Right: {
            V v_x_24103 = heff_field(v_x1_24101, 0);
            heff_take_n(v_x1_24101, 1ULL, 1);
            V v_t_24104 = (g_heff_2eclauses_2econcatMapC_24s301(v_x_24103));
            V v_t_24105 = (g_heff_2eclauses_2econcatMapC_24s301(v_x_24103));
            V v_t_24106 = ({ V a_0 = v_t_24105; V a_1 = ((V)&g_heff_2etoplevel_2erawF_24s447_str0); V r_ = (g_heff_2eclauses_2efresh(a_0, a_1)); heff_drop(v_t_24105); r_; });
            v_t_24107 = (g_heff_2eclauses_2ecaseTreeOf(v_it2_242, v_x_24103, v_t_24104, v_t_24106));
            break;
          }
          default: heff_nomatch(v_x1_24101);
          }
          switch (heff_tag_of(v_t_24107)) {
          case TAG_Left: {
            V v_err_24108 = heff_field(v_t_24107, 0);
            heff_take_n(v_t_24107, 1ULL, 1);
            heff_drop(v_scrutN_2460);
            return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam22, 2, 1, (V[]){v_err_24108});
          }
          case TAG_Right: {
            V v_r_24115 = heff_field(v_t_24107, 0);
            heff_take_n(v_t_24107, 1ULL, 1);
            V v_c_24116 = (g_heff_2etoplevel_2einfF_24s444(v_scrutN_2460));
            return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam23, 2, 2, (V[]){v_c_24116, v_r_24115});
          }
          default: return heff_nomatch(v_t_24107);
          }
        }
        default: return heff_nomatch(v_t_2488);
        }
      }
      default: return heff_nomatch(v_t_2463);
      }
    }
    case TAG_CLetIn: {
      V v_rhsN_24123 = heff_field(v_it1_241, 0);
      V v_alt0_24124 = heff_field(v_it1_241, 1);
      V v_ru_24it1_241_24CLetIn = heff_take_reuse_n(v_it1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      switch (heff_tag_of(v_alt0_24124)) {
      case TAG_At: {
        V v_it1_24125 = heff_dup(heff_field(v_alt0_24124, 0));
        switch (heff_tag_of(v_it1_24125)) {
        case TAG_MkAlt: {
          V v_it11_24127 = heff_field(v_it1_24125, 0);
          V v_bodyN_24128 = heff_field(v_it1_24125, 1);
          V v_ru_24it1_24125_24MkAlt = heff_take_reuse_n(v_it1_24125, 3ULL, 2);
          switch (heff_tag_of(v_it11_24127)) {
          case TAG_At: {
            V v_it111_24129 = heff_field(v_it11_24127, 0);
            heff_take_n(v_it11_24127, 1ULL, 2);
            switch (heff_tag_of(v_it111_24129)) {
            case TAG_PatVar: {
              V v_x_24131 = heff_field(v_it111_24129, 0);
              heff_take_n(v_it111_24129, 1ULL, 1);
              heff_drop(v_it2_242);
              heff_drop_tag(v_alt0_24124, 2);
              heff_drop_cell(v_ru_24it1_241_24CLetIn, 2);
              heff_drop_cell(v_ru_24it1_24125_24MkAlt, 2);
              V v_c_24132 = (g_heff_2etoplevel_2einfF_24s444(v_rhsN_24123));
              return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam26, 2, 3, (V[]){v_c_24132, v_bodyN_24128, v_x_24131});
            }
            case TAG_PatTag: {
              heff_take_n(v_it111_24129, 0ULL, 3);
              heff_drop(v_bodyN_24128);
              V v_t_24143 = heff_tag_at(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24144 = heff_tag_at(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24143}), v_it2_242});
              V t_0 = v_t_24144;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatOp: {
              heff_take_n(v_it111_24129, 0ULL, 3);
              heff_drop(v_bodyN_24128);
              V v_t_24148 = heff_tag_at(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24149 = heff_tag_at(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24148}), v_it2_242});
              V t_0 = v_t_24149;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatInt: {
              heff_take_n(v_it111_24129, 0ULL, 1);
              heff_drop(v_bodyN_24128);
              V v_t_24151 = heff_tag_at(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24152 = heff_tag_at(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24151}), v_it2_242});
              V t_0 = v_t_24152;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatFloat: {
              heff_take_n(v_it111_24129, 0ULL, 1);
              heff_drop(v_bodyN_24128);
              V v_t_24154 = heff_tag_at(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24155 = heff_tag_at(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24154}), v_it2_242});
              V t_0 = v_t_24155;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatString: {
              heff_take_n(v_it111_24129, 0ULL, 1);
              heff_drop(v_bodyN_24128);
              V v_t_24157 = heff_tag_at(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24158 = heff_tag_at(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24157}), v_it2_242});
              V t_0 = v_t_24158;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatRecord: {
              heff_take_n(v_it111_24129, 0ULL, 1);
              heff_drop(v_bodyN_24128);
              V v_t_24160 = heff_tag_at(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24161 = heff_tag_at(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24160}), v_it2_242});
              V t_0 = v_t_24161;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatWord: {
              heff_take_n(v_it111_24129, 0ULL, 1);
              heff_drop(v_bodyN_24128);
              V v_t_24163 = heff_tag_at(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24164 = heff_tag_at(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24163}), v_it2_242});
              V t_0 = v_t_24164;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatAs: {
              heff_take_n(v_it111_24129, 0ULL, 3);
              heff_drop(v_bodyN_24128);
              V v_t_24168 = heff_tag_at(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24169 = heff_tag_at(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24168}), v_it2_242});
              V t_0 = v_t_24169;
              v_n_240 = t_0;
              goto top;
            }
            default: return heff_nomatch(v_it111_24129);
            }
          }
          default: return heff_nomatch(v_it11_24127);
          }
        }
        default: return heff_nomatch(v_it1_24125);
        }
      }
      default: return heff_nomatch(v_alt0_24124);
      }
    }
    case TAG_CLocal: {
      V v_bodyN_24170 = heff_field(v_it1_241, 0);
      V v_defs_24171 = heff_field(v_it1_241, 1);
      heff_take_n(v_it1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_it2_242);
      return ({ V a_0 = v_defs_24171; V a_1 = v_bodyN_24170; V r_ = (g_heff_2etoplevel_2elocalsJ_24s453(a_0, a_1)); heff_drop(v_defs_24171); r_; });
    }
    case TAG_CAbandon: {
      heff_drop_tag(v_n_240, 2);
      return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam29, 2, 1, (V[]){v_it2_242});
    }
    case TAG_CNominal: {
      V v_c_24175 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_it2_242);
      V v_c_24176 = (g_heff_2etoplevel_2erawF_24s447(v_c_24175));
      return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam30, 2, 1, (V[]){v_c_24176});
    }
    default: return heff_nomatch(v_it1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2etoplevel_2erawF_24s447_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2erawF_24s447(a[0]);
}
V g_heff_2etoplevel_2erawF_24s447_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2414 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2415 = v_s_2414;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2416 = ({ V a_0 = v_t_2415; V a_1 = v_x_245; V a_2 = v_x_2412; V r_ = (g_heff_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
  V f_ = v_k_2411;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo(g_heff_2etoplevel_2erawF_24s447_lam1, 1, 3, (V[]){v_n_240, v_x_245, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2427;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2426 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2427 = v_s_2426;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2428 = ({ V a_0 = v_t_2427; V a_1 = v_x_2417; V a_2 = v_x_2424; V r_ = (g_heff_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_x_2424); r_; });
  V f_ = v_k_2423;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2421;
  args[0] = v_hd_2422;
  args[1] = heff_clo(g_heff_2etoplevel_2erawF_24s447_lam3, 1, 3, (V[]){v_n_240, v_x_2417, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_x_2436 = heff_env(self)[2];
  V v_k_2435 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2441;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2440 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2441 = v_s_2440;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2442 = ({ V a_0 = v_t_2441; V a_1 = v_x_2429; V a_2 = v_x_2436; V a_3 = v_x_2438; V r_ = (g_heff_2erules_2efunctionIntroAnn(a_0, a_1, a_2, a_3)); heff_drop(v_x_2436); heff_drop(v_x_2438); r_; });
  V f_ = v_k_2435;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_body_2432 = heff_env(self)[0];
  V v_hd_2434 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  V v_k_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2437 = (g_heff_2etoplevel_2echkF_24s443(v_body_2432));
  return heff_tail(v_c_2437, 2, (V[]){v_hd_2434, heff_clo(g_heff_2etoplevel_2erawF_24s447_lam6, 1, 4, (V[]){v_n_240, v_x_2429, v_x_2436, v_k_2435})});
}
V g_heff_2etoplevel_2erawF_24s447_lam4(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_body_2432 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2433;
  args[0] = heff_dup(v_hd_2434);
  args[1] = heff_clo(g_heff_2etoplevel_2erawF_24s447_lam5, 1, 5, (V[]){v_body_2432, v_hd_2434, v_n_240, v_x_2429, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_tsp_2444 = heff_env(self)[1];
  V v_x_2443 = heff_env(self)[2];
  V v_k_2448 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2452;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2451 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2452 = v_s_2451;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2453 = (g_heff_2erules_2esumIntro(v_t_2452, v_tsp_2444, v_x_2443, v_x_2449));
  V f_ = v_k_2448;
  args[0] = v_x_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam7(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_tsp_2444 = heff_env(self)[2];
  V v_x_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2446;
  args[0] = v_hd_2447;
  args[1] = heff_clo(g_heff_2etoplevel_2erawF_24s447_lam8, 1, 4, (V[]){v_n_240, v_tsp_2444, v_x_2443, v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam10(V self, V *args) {
  V v_x_2458 = args[0];
  V v_it2_242 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = (g_heff_2erules_2erecordIntro(v_it2_242, v_x_2458));
  V f_ = v_k_2457;
  args[0] = v_t_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam9(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_it2_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2455;
  args[0] = v_hd_2456;
  args[1] = heff_clo(g_heff_2etoplevel_2erawF_24s447_lam10, 1, 2, (V[]){v_it2_242, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam15(V self, V *args) {
  V v_x_2476 = args[0];
  V v_body_2472 = heff_env(self)[0];
  V v_sp_2470 = heff_env(self)[1];
  V v_k_2475 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2477 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_MkAlt, 2, (V[]){v_x_2476, v_body_2472}), v_sp_2470});
  V f_ = v_k_2475;
  args[0] = v_t_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam14(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  V v_c_2473 = heff_env(self)[0];
  V v_body_2472 = heff_env(self)[1];
  V v_sp_2470 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2473;
  args[0] = v_hd_2474;
  args[1] = heff_clo(g_heff_2etoplevel_2erawF_24s447_lam15, 1, 3, (V[]){v_body_2472, v_sp_2470, v_k_2475});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam13(V self, V *args) {
  V v_m_2468 = args[0];
  V v_e_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2468)) {
  case TAG_At: {
    V v_x21_2469 = heff_field(v_m_2468, 0);
    V v_sp_2470 = heff_field(v_m_2468, 1);
    heff_take_n(v_m_2468, 3ULL, 2);
    switch (heff_tag_of(v_x21_2469)) {
    case TAG_MkAlt: {
      V v_p_2471 = heff_field(v_x21_2469, 0);
      V v_body_2472 = heff_field(v_x21_2469, 1);
      heff_take_n(v_x21_2469, 3ULL, 2);
      V v_c_2473 = (g_heff_2etoplevel_2eopPat(heff_get(v_e_2466, LBL_globals), v_p_2471));
      return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam14, 2, 3, (V[]){v_c_2473, v_body_2472, v_sp_2470});
    }
    default: return heff_nomatch(v_x21_2469);
    }
  }
  default: return heff_nomatch(v_m_2468);
  }
}
V g_heff_2etoplevel_2erawF_24s447_lam18(V self, V *args) {
  V v_x_2484 = args[0];
  V v_e_2466 = heff_env(self)[0];
  V v_a_2467 = heff_env(self)[1];
  V v_hd_2479 = heff_env(self)[2];
  V v_k_2480 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2484)) {
  case TAG_MkChk: {
    V v_f_2485 = heff_field(v_x_2484, 0);
    heff_take_n(v_x_2484, 1ULL, 1);
    return heff_tail(v_f_2485, 4, (V[]){v_e_2466, v_a_2467, v_hd_2479, v_k_2480});
  }
  default: return heff_nomatch(v_x_2484);
  }
}
V g_heff_2etoplevel_2erawF_24s447_lam17(V self, V *args) {
  V v_x_2481 = args[0];
  V v_scrutN_2460 = heff_env(self)[0];
  V v_it2_242 = heff_env(self)[1];
  V v_hd_2479 = heff_env(self)[2];
  V v_e_2466 = heff_env(self)[3];
  V v_a_2467 = heff_env(self)[4];
  V v_k_2480 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2482 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_CMatch, 2, (V[]){v_scrutN_2460, v_x_2481}), v_it2_242});
  V v_c_2483 = (g_heff_2etoplevel_2echkF_24s443(v_t_2482));
  return heff_tail(v_c_2483, 2, (V[]){heff_dup(v_hd_2479), heff_clo(g_heff_2etoplevel_2erawF_24s447_lam18, 1, 4, (V[]){v_e_2466, v_a_2467, v_hd_2479, v_k_2480})});
}
V g_heff_2etoplevel_2erawF_24s447_lam16(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  V v_c_2478 = heff_env(self)[0];
  V v_scrutN_2460 = heff_env(self)[1];
  V v_it2_242 = heff_env(self)[2];
  V v_e_2466 = heff_env(self)[3];
  V v_a_2467 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2478;
  args[0] = heff_dup(v_hd_2479);
  args[1] = heff_clo(g_heff_2etoplevel_2erawF_24s447_lam17, 1, 6, (V[]){v_scrutN_2460, v_it2_242, v_hd_2479, v_e_2466, v_a_2467, v_k_2480});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam12(V self, V *args) {
  V v_e_2466 = args[0];
  V v_a_2467 = args[1];
  V v_casesN_2461 = heff_env(self)[0];
  V v_scrutN_2460 = heff_env(self)[1];
  V v_it2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2478 = (g_heff_2etoplevel_2etraverseEL(heff_clo(g_heff_2etoplevel_2erawF_24s447_lam13, 1, 1, (V[]){heff_dup(v_e_2466)}), v_casesN_2461));
  return heff_clo(g_heff_2etoplevel_2erawF_24s447_lam16, 2, 5, (V[]){v_c_2478, v_scrutN_2460, v_it2_242, v_e_2466, v_a_2467});
}
V g_heff_2etoplevel_2erawF_24s447_lam11(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_casesN_2461 = heff_env(self)[0];
  V v_scrutN_2460 = heff_env(self)[1];
  V v_it2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2464);
  V f_ = v_k_2465;
  args[0] = heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2etoplevel_2erawF_24s447_lam12, 2, 3, (V[]){v_casesN_2461, v_scrutN_2460, v_it2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam21(V self, V *args) {
  V v_x_2494 = args[0];
  V v_casesN_2461 = heff_env(self)[0];
  V v_it2_242 = heff_env(self)[1];
  V v_x_2492 = heff_env(self)[2];
  V v_k_2491 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2495 = (g_heff_2etoplevel_2etagSpans(v_casesN_2461));
  V v_t_2496 = (g_prelude_2emap_24s5(heff_dup(v_x_2494)));
  V v_t_2497 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_x_2494));
  V v_t_2498 = (g_prelude_2emap_24s6(v_x_2494));
  V v_t_2499 = heff_rec(3, shape_153_35_368, (V[]){heff_arrayFromList(v_t_2496), v_t_2497, heff_arrayFromList(v_t_2498)});
  V v_x_24100 = ({ V a_0 = v_it2_242; V a_1 = v_x_2492; V a_2 = v_t_2495; V a_3 = v_t_2499; V r_ = (g_heff_2erules_2esumElim(a_0, a_1, a_2, a_3)); heff_drop(v_x_2492); heff_drop(v_t_2495); r_; });
  V f_ = v_k_2491;
  args[0] = v_x_24100;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam20(V self, V *args) {
  V v_x_2492 = args[0];
  V v_casesN_2461 = heff_env(self)[0];
  V v_hd_2490 = heff_env(self)[1];
  V v_it2_242 = heff_env(self)[2];
  V v_k_2491 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2493 = (g_heff_2etoplevel_2etraverseEL_24s452(heff_dup(v_casesN_2461)));
  return heff_tail(v_c_2493, 2, (V[]){v_hd_2490, heff_clo(g_heff_2etoplevel_2erawF_24s447_lam21, 1, 4, (V[]){v_casesN_2461, v_it2_242, v_x_2492, v_k_2491})});
}
V g_heff_2etoplevel_2erawF_24s447_lam19(V self, V *args) {
  V v_hd_2490 = args[0];
  V v_k_2491 = args[1];
  V v_c_2489 = heff_env(self)[0];
  V v_casesN_2461 = heff_env(self)[1];
  V v_it2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2489;
  args[0] = heff_dup(v_hd_2490);
  args[1] = heff_clo(g_heff_2etoplevel_2erawF_24s447_lam20, 1, 4, (V[]){v_casesN_2461, v_hd_2490, v_it2_242, v_k_2491});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam22(V self, V *args) {
  V v_hd_24109 = args[0];
  V v_k2_24110 = args[1];
  V v_err_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24111 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), heff_get(heff_dup(v_err_24108), LBL_msg), heff_get(v_err_24108, LBL_span), NTAG(TAG_Nothing)});
  V v_t_24112 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24112})});
  V v_t_24114 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24109), LBL_malg), 1, (V[]){v_t_24113}));
  V f_ = heff_get(v_hd_24109, LBL_bind);
  args[0] = v_t_24114;
  args[1] = v_k2_24110;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam25(V self, V *args) {
  V v_x_24121 = args[0];
  V v_r_24115 = heff_env(self)[0];
  V v_x_24119 = heff_env(self)[1];
  V v_k_24118 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24122 = ({ V a_0 = heff_get(v_r_24115, LBL_scrutinee); V a_1 = v_x_24119; V a_2 = v_x_24121; V r_ = (g_heff_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_x_24119); heff_drop(v_x_24121); r_; });
  V f_ = v_k_24118;
  args[0] = v_t_24122;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam24(V self, V *args) {
  V v_x_24119 = args[0];
  V v_r_24115 = heff_env(self)[0];
  V v_hd_24117 = heff_env(self)[1];
  V v_k_24118 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24120 = (g_heff_2etoplevel_2echkF_24s443(heff_get(heff_dup(v_r_24115), LBL_tree)));
  return heff_tail(v_c_24120, 2, (V[]){v_hd_24117, heff_clo(g_heff_2etoplevel_2erawF_24s447_lam25, 1, 3, (V[]){v_r_24115, v_x_24119, v_k_24118})});
}
V g_heff_2etoplevel_2erawF_24s447_lam23(V self, V *args) {
  V v_hd_24117 = args[0];
  V v_k_24118 = args[1];
  V v_c_24116 = heff_env(self)[0];
  V v_r_24115 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24116;
  args[0] = heff_dup(v_hd_24117);
  args[1] = heff_clo(g_heff_2etoplevel_2erawF_24s447_lam24, 1, 3, (V[]){v_r_24115, v_hd_24117, v_k_24118});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam28(V self, V *args) {
  V v_x_24138 = args[0];
  V v_x_24131 = heff_env(self)[0];
  V v_x_24135 = heff_env(self)[1];
  V v_k_24134 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24139 = ({ V a_0 = v_x_24131; V a_1 = v_x_24135; V a_2 = v_x_24138; V r_ = (g_heff_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_x_24135); heff_drop(v_x_24138); r_; });
  V f_ = v_k_24134;
  args[0] = v_t_24139;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam27(V self, V *args) {
  V v_x_24135 = args[0];
  V v_bodyN_24128 = heff_env(self)[0];
  V v_hd_24133 = heff_env(self)[1];
  V v_x_24131 = heff_env(self)[2];
  V v_k_24134 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24136 = (g_heff_2etoplevel_2echkF_24s443(v_bodyN_24128));
  V v_c_24137 = heff_tr(heff_apply(((V)&g_heff_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_24136}));
  return heff_tail(v_c_24137, 2, (V[]){v_hd_24133, heff_clo(g_heff_2etoplevel_2erawF_24s447_lam28, 1, 3, (V[]){v_x_24131, v_x_24135, v_k_24134})});
}
V g_heff_2etoplevel_2erawF_24s447_lam26(V self, V *args) {
  V v_hd_24133 = args[0];
  V v_k_24134 = args[1];
  V v_c_24132 = heff_env(self)[0];
  V v_bodyN_24128 = heff_env(self)[1];
  V v_x_24131 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24132;
  args[0] = heff_dup(v_hd_24133);
  args[1] = heff_clo(g_heff_2etoplevel_2erawF_24s447_lam27, 1, 4, (V[]){v_bodyN_24128, v_hd_24133, v_x_24131, v_k_24134});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam29(V self, V *args) {
  V v_hd_24172 = args[0];
  V v_k_24173 = args[1];
  V v_it2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24172);
  V v_t_24174 = (g_heff_2erules_2eabandonChk(v_it2_242));
  V f_ = v_k_24173;
  args[0] = v_t_24174;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam31(V self, V *args) {
  V v_x_24179 = args[0];
  V v_k_24178 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24180 = ({ V a_0 = v_x_24179; V r_ = (g_heff_2etoplevel_2enominalChk(a_0)); heff_drop(v_x_24179); r_; });
  V f_ = v_k_24178;
  args[0] = v_t_24180;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2erawF_24s447_lam30(V self, V *args) {
  V v_hd_24177 = args[0];
  V v_k_24178 = args[1];
  V v_c_24176 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24176;
  args[0] = v_hd_24177;
  args[1] = heff_clo(g_heff_2etoplevel_2erawF_24s447_lam31, 1, 1, (V[]){v_k_24178});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam1(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam0(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam3(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam2(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam5(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam4(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam7(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam6(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam9(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam8(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam11(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam10(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam13(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam12(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam15(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam14(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam17(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam16(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam19(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam18(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam21(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam20(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam23(V self, V *args);
V g_heff_2etoplevel_2echkF_24s443_lam22(V self, V *args);
Clo g_heff_2etoplevel_2echkF_24s443_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2echkF_24s443_entry, 1, 0};

V g_heff_2etoplevel_2echkF_24s443(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_it1_241 = heff_dup(heff_field(v_n_240, 0));
    V v_it2_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_it1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_it2_242);
      V v_c_244 = (g_heff_2etoplevel_2einfF_24s444(heff_dup(v_i_243)));
      return heff_clo(g_heff_2etoplevel_2echkF_24s443_lam0, 2, 2, (V[]){v_c_244, v_i_243});
    }
    case TAG_CType: {
      V v_t_2410 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      V v_c_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_t_2410); r_; });
      return heff_clo(g_heff_2etoplevel_2echkF_24s443_lam2, 2, 2, (V[]){v_c_2411, v_it2_242});
    }
    case TAG_CLam: {
      heff_take_n(v_it1_241, 0ULL, 3);
      heff_drop(v_it2_242);
      V v_c_2419 = (g_heff_2etoplevel_2erawF_24s447(heff_dup(v_n_240)));
      return heff_clo(g_heff_2etoplevel_2echkF_24s443_lam4, 2, 2, (V[]){v_c_2419, v_n_240});
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_it1_241, 0ULL, 3);
      heff_drop(v_it2_242);
      V v_c_2453 = (g_heff_2etoplevel_2erawF_24s447(heff_dup(v_n_240)));
      return heff_clo(g_heff_2etoplevel_2echkF_24s443_lam6, 2, 2, (V[]){v_c_2453, v_n_240});
    }
    case TAG_CAnnLam: {
      heff_take_n(v_it1_241, 0ULL, 4);
      heff_drop(v_it2_242);
      V v_c_2488 = (g_heff_2etoplevel_2erawF_24s447(heff_dup(v_n_240)));
      return heff_clo(g_heff_2etoplevel_2echkF_24s443_lam8, 2, 2, (V[]){v_c_2488, v_n_240});
    }
    case TAG_CTag: {
      heff_take_n(v_it1_241, 0ULL, 3);
      heff_drop(v_it2_242);
      V v_c_24122 = (g_heff_2etoplevel_2erawF_24s447(heff_dup(v_n_240)));
      return heff_clo(g_heff_2etoplevel_2echkF_24s443_lam10, 2, 2, (V[]){v_c_24122, v_n_240});
    }
    case TAG_CStruct: {
      heff_take_n(v_it1_241, 0ULL, 1);
      heff_drop(v_it2_242);
      V v_c_24154 = (g_heff_2etoplevel_2erawF_24s447(heff_dup(v_n_240)));
      return heff_clo(g_heff_2etoplevel_2echkF_24s443_lam12, 2, 2, (V[]){v_c_24154, v_n_240});
    }
    case TAG_CMatch: {
      heff_take_n(v_it1_241, 0ULL, 2);
      heff_drop(v_it2_242);
      V v_c_24187 = (g_heff_2etoplevel_2erawF_24s447(heff_dup(v_n_240)));
      return heff_clo(g_heff_2etoplevel_2echkF_24s443_lam14, 2, 2, (V[]){v_c_24187, v_n_240});
    }
    case TAG_CLetIn: {
      heff_take_n(v_it1_241, 0ULL, 2);
      heff_drop(v_it2_242);
      V v_c_24220 = (g_heff_2etoplevel_2erawF_24s447(heff_dup(v_n_240)));
      return heff_clo(g_heff_2etoplevel_2echkF_24s443_lam16, 2, 2, (V[]){v_c_24220, v_n_240});
    }
    case TAG_CLocal: {
      heff_take_n(v_it1_241, 0ULL, 2);
      heff_drop(v_it2_242);
      V v_c_24253 = (g_heff_2etoplevel_2erawF_24s447(heff_dup(v_n_240)));
      return heff_clo(g_heff_2etoplevel_2echkF_24s443_lam18, 2, 2, (V[]){v_c_24253, v_n_240});
    }
    case TAG_CAbandon: {
      heff_drop(v_it2_242);
      V v_c_24284 = (g_heff_2etoplevel_2erawF_24s447(heff_dup(v_n_240)));
      return heff_clo(g_heff_2etoplevel_2echkF_24s443_lam20, 2, 2, (V[]){v_c_24284, v_n_240});
    }
    case TAG_CNominal: {
      heff_take_n(v_it1_241, 0ULL, 1);
      heff_drop(v_it2_242);
      V v_c_24316 = (g_heff_2etoplevel_2erawF_24s447(heff_dup(v_n_240)));
      return heff_clo(g_heff_2etoplevel_2echkF_24s443_lam22, 2, 2, (V[]){v_c_24316, v_n_240});
    }
    default: return heff_nomatch(v_it1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2etoplevel_2echkF_24s443_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2echkF_24s443(a[0]);
}
V g_heff_2etoplevel_2echkF_24s443_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_i_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = ({ V a_0 = v_i_243; V a_1 = v_x_247; V r_ = (g_heff_2etoplevel_2echkHeadOf(a_0, a_1)); heff_drop(v_x_247); r_; });
  V v_x_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2erules_2eimplicitLams(a_0)); heff_drop(v_t_248); r_; });
  V f_ = v_k_246;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo(g_heff_2etoplevel_2echkF_24s443_lam1, 1, 2, (V[]){v_i_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_it2_242 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = ({ V a_0 = v_it2_242; V a_1 = v_x_2414; V r_ = (g_heff_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2414); r_; });
  V f_ = v_k_2413;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_it2_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo(g_heff_2etoplevel_2echkF_24s443_lam3, 1, 2, (V[]){v_it2_242, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2448;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2423 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2423)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2423, 0ULL, 3);
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2423, 0ULL, 3);
      v_t_2448 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2423, 0ULL, 4);
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2423, 0ULL, 3);
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2423, 0ULL, 2);
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2423, 0ULL, 2);
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2423, 0ULL, 2);
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2423);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2449;
  switch (heff_tag_of(v_t_2448)) {
  case TAG_True: {
    v_x_2449 = v_x_2422;
    break;
  }
  case TAG_False: {
    v_x_2449 = ({ V a_0 = v_x_2422; V r_ = (g_heff_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2422); r_; });
    break;
  }
  default: heff_nomatch(v_t_2448);
  }
  V f_ = v_k_2421;
  args[0] = v_x_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam4(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo(g_heff_2etoplevel_2echkF_24s443_lam5, 1, 2, (V[]){v_n_240, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam7(V self, V *args) {
  V v_x_2456 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2455 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2482;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2457 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2457)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2457, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2457, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2457, 0ULL, 3);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2457, 0ULL, 3);
      v_t_2482 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2457, 0ULL, 4);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2457, 0ULL, 3);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2457, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2457, 0ULL, 2);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2457, 0ULL, 2);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2457, 0ULL, 2);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2457, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2457);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2483;
  switch (heff_tag_of(v_t_2482)) {
  case TAG_True: {
    v_x_2483 = v_x_2456;
    break;
  }
  case TAG_False: {
    v_x_2483 = ({ V a_0 = v_x_2456; V r_ = (g_heff_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2456); r_; });
    break;
  }
  default: heff_nomatch(v_t_2482);
  }
  V f_ = v_k_2455;
  args[0] = v_x_2483;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam6(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  V v_c_2453 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2453;
  args[0] = v_hd_2454;
  args[1] = heff_clo(g_heff_2etoplevel_2echkF_24s443_lam7, 1, 2, (V[]){v_n_240, v_k_2455});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam9(V self, V *args) {
  V v_x_2491 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2490 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24117;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2492 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2492)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2492, 0ULL, 1);
      v_t_24117 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2492, 0ULL, 1);
      v_t_24117 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2492, 0ULL, 3);
      v_t_24117 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2492, 0ULL, 3);
      v_t_24117 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2492, 0ULL, 4);
      v_t_24117 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2492, 0ULL, 3);
      v_t_24117 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2492, 0ULL, 1);
      v_t_24117 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2492, 0ULL, 2);
      v_t_24117 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2492, 0ULL, 2);
      v_t_24117 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2492, 0ULL, 2);
      v_t_24117 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24117 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2492, 0ULL, 1);
      v_t_24117 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2492);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24118;
  switch (heff_tag_of(v_t_24117)) {
  case TAG_True: {
    v_x_24118 = v_x_2491;
    break;
  }
  case TAG_False: {
    v_x_24118 = ({ V a_0 = v_x_2491; V r_ = (g_heff_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2491); r_; });
    break;
  }
  default: heff_nomatch(v_t_24117);
  }
  V f_ = v_k_2490;
  args[0] = v_x_24118;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam8(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k_2490 = args[1];
  V v_c_2488 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2488;
  args[0] = v_hd_2489;
  args[1] = heff_clo(g_heff_2etoplevel_2echkF_24s443_lam9, 1, 2, (V[]){v_n_240, v_k_2490});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam11(V self, V *args) {
  V v_x_24125 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24124 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24151;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24126 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24126)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24126, 0ULL, 1);
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24126, 0ULL, 1);
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24126, 0ULL, 3);
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24126, 0ULL, 3);
      v_t_24151 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24126, 0ULL, 4);
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24126, 0ULL, 3);
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24126, 0ULL, 1);
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24126, 0ULL, 2);
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24126, 0ULL, 2);
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24126, 0ULL, 2);
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24126, 0ULL, 1);
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24126);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24152;
  switch (heff_tag_of(v_t_24151)) {
  case TAG_True: {
    v_x_24152 = v_x_24125;
    break;
  }
  case TAG_False: {
    v_x_24152 = ({ V a_0 = v_x_24125; V r_ = (g_heff_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24125); r_; });
    break;
  }
  default: heff_nomatch(v_t_24151);
  }
  V f_ = v_k_24124;
  args[0] = v_x_24152;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam10(V self, V *args) {
  V v_hd_24123 = args[0];
  V v_k_24124 = args[1];
  V v_c_24122 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24122;
  args[0] = v_hd_24123;
  args[1] = heff_clo(g_heff_2etoplevel_2echkF_24s443_lam11, 1, 2, (V[]){v_n_240, v_k_24124});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam13(V self, V *args) {
  V v_x_24157 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24156 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24183;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24158 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24158)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24158, 0ULL, 1);
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24158, 0ULL, 1);
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24158, 0ULL, 3);
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24158, 0ULL, 3);
      v_t_24183 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24158, 0ULL, 4);
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24158, 0ULL, 3);
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24158, 0ULL, 1);
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24158, 0ULL, 2);
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24158, 0ULL, 2);
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24158, 0ULL, 2);
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24158, 0ULL, 1);
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24158);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24184;
  switch (heff_tag_of(v_t_24183)) {
  case TAG_True: {
    v_x_24184 = v_x_24157;
    break;
  }
  case TAG_False: {
    v_x_24184 = ({ V a_0 = v_x_24157; V r_ = (g_heff_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24157); r_; });
    break;
  }
  default: heff_nomatch(v_t_24183);
  }
  V f_ = v_k_24156;
  args[0] = v_x_24184;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam12(V self, V *args) {
  V v_hd_24155 = args[0];
  V v_k_24156 = args[1];
  V v_c_24154 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24154;
  args[0] = v_hd_24155;
  args[1] = heff_clo(g_heff_2etoplevel_2echkF_24s443_lam13, 1, 2, (V[]){v_n_240, v_k_24156});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam15(V self, V *args) {
  V v_x_24190 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24189 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24216;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24191 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24191)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24191, 0ULL, 1);
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24191, 0ULL, 1);
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24191, 0ULL, 3);
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24191, 0ULL, 3);
      v_t_24216 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24191, 0ULL, 4);
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24191, 0ULL, 3);
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24191, 0ULL, 1);
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24191, 0ULL, 2);
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24191, 0ULL, 2);
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24191, 0ULL, 2);
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24191, 0ULL, 1);
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24191);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24217;
  switch (heff_tag_of(v_t_24216)) {
  case TAG_True: {
    v_x_24217 = v_x_24190;
    break;
  }
  case TAG_False: {
    v_x_24217 = ({ V a_0 = v_x_24190; V r_ = (g_heff_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24190); r_; });
    break;
  }
  default: heff_nomatch(v_t_24216);
  }
  V f_ = v_k_24189;
  args[0] = v_x_24217;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam14(V self, V *args) {
  V v_hd_24188 = args[0];
  V v_k_24189 = args[1];
  V v_c_24187 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24187;
  args[0] = v_hd_24188;
  args[1] = heff_clo(g_heff_2etoplevel_2echkF_24s443_lam15, 1, 2, (V[]){v_n_240, v_k_24189});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam17(V self, V *args) {
  V v_x_24223 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24222 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24249;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24224 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24224)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24224, 0ULL, 1);
      v_t_24249 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24224, 0ULL, 1);
      v_t_24249 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24224, 0ULL, 3);
      v_t_24249 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24224, 0ULL, 3);
      v_t_24249 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24224, 0ULL, 4);
      v_t_24249 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24224, 0ULL, 3);
      v_t_24249 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24224, 0ULL, 1);
      v_t_24249 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24224, 0ULL, 2);
      v_t_24249 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24224, 0ULL, 2);
      v_t_24249 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24224, 0ULL, 2);
      v_t_24249 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24249 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24224, 0ULL, 1);
      v_t_24249 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24224);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24250;
  switch (heff_tag_of(v_t_24249)) {
  case TAG_True: {
    v_x_24250 = v_x_24223;
    break;
  }
  case TAG_False: {
    v_x_24250 = ({ V a_0 = v_x_24223; V r_ = (g_heff_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24223); r_; });
    break;
  }
  default: heff_nomatch(v_t_24249);
  }
  V f_ = v_k_24222;
  args[0] = v_x_24250;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam16(V self, V *args) {
  V v_hd_24221 = args[0];
  V v_k_24222 = args[1];
  V v_c_24220 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24220;
  args[0] = v_hd_24221;
  args[1] = heff_clo(g_heff_2etoplevel_2echkF_24s443_lam17, 1, 2, (V[]){v_n_240, v_k_24222});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam19(V self, V *args) {
  V v_x_24256 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24255 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24282;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24257 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24257)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24257, 0ULL, 1);
      v_t_24282 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24257, 0ULL, 1);
      v_t_24282 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24257, 0ULL, 3);
      v_t_24282 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24257, 0ULL, 3);
      v_t_24282 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24257, 0ULL, 4);
      v_t_24282 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24257, 0ULL, 3);
      v_t_24282 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24257, 0ULL, 1);
      v_t_24282 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24257, 0ULL, 2);
      v_t_24282 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24257, 0ULL, 2);
      v_t_24282 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24257, 0ULL, 2);
      v_t_24282 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24282 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24257, 0ULL, 1);
      v_t_24282 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24257);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24283;
  switch (heff_tag_of(v_t_24282)) {
  case TAG_True: {
    v_x_24283 = v_x_24256;
    break;
  }
  case TAG_False: {
    v_x_24283 = ({ V a_0 = v_x_24256; V r_ = (g_heff_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24256); r_; });
    break;
  }
  default: heff_nomatch(v_t_24282);
  }
  V f_ = v_k_24255;
  args[0] = v_x_24283;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam18(V self, V *args) {
  V v_hd_24254 = args[0];
  V v_k_24255 = args[1];
  V v_c_24253 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24253;
  args[0] = v_hd_24254;
  args[1] = heff_clo(g_heff_2etoplevel_2echkF_24s443_lam19, 1, 2, (V[]){v_n_240, v_k_24255});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam21(V self, V *args) {
  V v_x_24287 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24286 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24313;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24288 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24288)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24288, 0ULL, 1);
      v_t_24313 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24288, 0ULL, 1);
      v_t_24313 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24288, 0ULL, 3);
      v_t_24313 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24288, 0ULL, 3);
      v_t_24313 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24288, 0ULL, 4);
      v_t_24313 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24288, 0ULL, 3);
      v_t_24313 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24288, 0ULL, 1);
      v_t_24313 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24288, 0ULL, 2);
      v_t_24313 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24288, 0ULL, 2);
      v_t_24313 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24288, 0ULL, 2);
      v_t_24313 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24313 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24288, 0ULL, 1);
      v_t_24313 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24288);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24314;
  switch (heff_tag_of(v_t_24313)) {
  case TAG_True: {
    v_x_24314 = v_x_24287;
    break;
  }
  case TAG_False: {
    v_x_24314 = ({ V a_0 = v_x_24287; V r_ = (g_heff_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24287); r_; });
    break;
  }
  default: heff_nomatch(v_t_24313);
  }
  V f_ = v_k_24286;
  args[0] = v_x_24314;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam20(V self, V *args) {
  V v_hd_24285 = args[0];
  V v_k_24286 = args[1];
  V v_c_24284 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24284;
  args[0] = v_hd_24285;
  args[1] = heff_clo(g_heff_2etoplevel_2echkF_24s443_lam21, 1, 2, (V[]){v_n_240, v_k_24286});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam23(V self, V *args) {
  V v_x_24319 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24318 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24345;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24320 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24320)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24320, 0ULL, 1);
      v_t_24345 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24320, 0ULL, 1);
      v_t_24345 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24320, 0ULL, 3);
      v_t_24345 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24320, 0ULL, 3);
      v_t_24345 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24320, 0ULL, 4);
      v_t_24345 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24320, 0ULL, 3);
      v_t_24345 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24320, 0ULL, 1);
      v_t_24345 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24320, 0ULL, 2);
      v_t_24345 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24320, 0ULL, 2);
      v_t_24345 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24320, 0ULL, 2);
      v_t_24345 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24345 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24320, 0ULL, 1);
      v_t_24345 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24320);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24346;
  switch (heff_tag_of(v_t_24345)) {
  case TAG_True: {
    v_x_24346 = v_x_24319;
    break;
  }
  case TAG_False: {
    v_x_24346 = ({ V a_0 = v_x_24319; V r_ = (g_heff_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24319); r_; });
    break;
  }
  default: heff_nomatch(v_t_24345);
  }
  V f_ = v_k_24318;
  args[0] = v_x_24346;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2echkF_24s443_lam22(V self, V *args) {
  V v_hd_24317 = args[0];
  V v_k_24318 = args[1];
  V v_c_24316 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24316;
  args[0] = v_hd_24317;
  args[1] = heff_clo(g_heff_2etoplevel_2echkF_24s443_lam23, 1, 2, (V[]){v_n_240, v_k_24318});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2edefaultF_24s442_lam0(V self, V *args); static Clo g_heff_2etoplevel_2edefaultF_24s442_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2edefaultF_24s442_lam0, 2, 0};
V g_heff_2etoplevel_2edefaultF_24s442_lam2(V self, V *args);
V g_heff_2etoplevel_2edefaultF_24s442_lam1(V self, V *args);
V g_heff_2etoplevel_2edefaultF_24s442_lam4(V self, V *args);
V g_heff_2etoplevel_2edefaultF_24s442_lam3(V self, V *args);
Clo g_heff_2etoplevel_2edefaultF_24s442_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2edefaultF_24s442_entry, 1, 0};

V g_heff_2etoplevel_2edefaultF_24s442(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2etoplevel_2edefaultF_24s442_lam0_clo);
  }
  case TAG_Just: {
    V v_c_243 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_c_244 = (g_heff_2etoplevel_2echkF_24s443(heff_dup(v_c_243)));
    V v_c_2412 = heff_tr(heff_apply(((V)&g_heff_2etoplevel_2erecoveringChk_clo), 1, (V[]){heff_clo(g_heff_2etoplevel_2edefaultF_24s442_lam1, 2, 2, (V[]){v_c_244, v_c_243})}));
    return heff_clo(g_heff_2etoplevel_2edefaultF_24s442_lam3, 2, 1, (V[]){v_c_2412});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2edefaultF_24s442_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2edefaultF_24s442(a[0]);
}
V g_heff_2etoplevel_2edefaultF_24s442_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2edefaultF_24s442_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410;
  switch (heff_tag_of(v_c_243)) {
  case TAG_At: {
    V v_s_249 = heff_field(v_c_243, 1);
    heff_take_n(v_c_243, 2ULL, 2);
    v_t_2410 = v_s_249;
    break;
  }
  default: heff_nomatch(v_c_243);
  }
  V v_x_2411 = ({ V a_0 = v_t_2410; V a_1 = v_x_247; V r_ = (g_heff_2erules_2eclosedDefault(a_0, a_1)); heff_drop(v_x_247); r_; });
  V f_ = v_k_246;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2edefaultF_24s442_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo(g_heff_2etoplevel_2edefaultF_24s442_lam2, 1, 2, (V[]){v_c_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2edefaultF_24s442_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2414;
  args[0] = heff_tag(TAG_Just, 1, (V[]){v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2edefaultF_24s442_lam3(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo(g_heff_2etoplevel_2edefaultF_24s442_lam4, 1, 1, (V[]){v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[48]; } g_heff_2etoplevel_2efieldDeclF_24s441_str0 = {{0x80000000u, K_STR, 0}, 48, 48, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 102, 105, 101, 108, 100, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110, 32, 111, 102, 32, 116, 104, 101, 32, 102, 111, 114, 109, 32, 96, 120, 32, 58, 32, 65, 96}};
V g_heff_2etoplevel_2efieldDeclF_24s441_lam2(V self, V *args);
V g_heff_2etoplevel_2efieldDeclF_24s441_lam1(V self, V *args);
V g_heff_2etoplevel_2efieldDeclF_24s441_lam0(V self, V *args);
V g_heff_2etoplevel_2efieldDeclF_24s441_lam3(V self, V *args);
Clo g_heff_2etoplevel_2efieldDeclF_24s441_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2efieldDeclF_24s441_entry, 1, 0};

V g_heff_2etoplevel_2efieldDeclF_24s441(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclareField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_d_246 = heff_field(v_x21_241, 3);
      V v_c_247 = (g_heff_2etoplevel_2etypF_24s439(v_t_245));
      return heff_clo(g_heff_2etoplevel_2efieldDeclF_24s441_lam0, 2, 3, (V[]){v_c_247, heff_dup(v_d_246), heff_dup(v_x_243)});
    }
    case TAG_BadFieldDecl: {
      return heff_clo(g_heff_2etoplevel_2efieldDeclF_24s441_lam3, 2, 1, (V[]){heff_dup(v_x22_242)});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2efieldDeclF_24s441_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2efieldDeclF_24s441(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2efieldDeclF_24s441_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_249;
  args[0] = heff_rec(3, shape_198_353_62, (V[]){v_x_243, v_x_2410, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2efieldDeclF_24s441_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_d_246 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2411 = (g_heff_2etoplevel_2edefaultF_24s442(v_d_246));
  return heff_tail(v_c_2411, 2, (V[]){v_hd_248, heff_clo(g_heff_2etoplevel_2efieldDeclF_24s441_lam2, 1, 3, (V[]){v_k_249, v_x_243, v_x_2410})});
}
V g_heff_2etoplevel_2efieldDeclF_24s441_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo(g_heff_2etoplevel_2efieldDeclF_24s441_lam1, 1, 4, (V[]){v_d_246, v_hd_248, v_k_249, v_x_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2efieldDeclF_24s441_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k2_2415 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(201LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2efieldDeclF_24s441_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2414, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2415;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etraverseEL_24s455_lam0(V self, V *args); static Clo g_heff_2etoplevel_2etraverseEL_24s455_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s455_lam0, 2, 0};
V g_heff_2etoplevel_2etraverseEL_24s455_lam3(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s455_lam2(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s455_lam1(V self, V *args);
Clo g_heff_2etoplevel_2etraverseEL_24s455_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s455_entry, 1, 0};

V g_heff_2etoplevel_2etraverseEL_24s455(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2etoplevel_2etraverseEL_24s455_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2etoplevel_2efieldDeclF_24s441(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo(g_heff_2etoplevel_2etraverseEL_24s455_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2etraverseEL_24s455_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2etraverseEL_24s455(a[0]);
}
V g_heff_2etoplevel_2etraverseEL_24s455_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s455_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s455_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2etoplevel_2etraverseEL_24s455(v_xs_244));
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo(g_heff_2etoplevel_2etraverseEL_24s455_lam3, 1, 2, (V[]){v_k_247, v_x_248})});
}
V g_heff_2etoplevel_2etraverseEL_24s455_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2etoplevel_2etraverseEL_24s455_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etraverseEL_24s457_lam0(V self, V *args); static Clo g_heff_2etoplevel_2etraverseEL_24s457_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s457_lam0, 2, 0};
V g_heff_2etoplevel_2etraverseEL_24s457_lam2(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s457_lam1(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s457_lam5(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s457_lam4(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s457_lam3(V self, V *args);
Clo g_heff_2etoplevel_2etraverseEL_24s457_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s457_entry, 1, 0};

V g_heff_2etoplevel_2etraverseEL_24s457(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2etoplevel_2etraverseEL_24s457_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = (g_heff_2etoplevel_2etypF_24s439(v_x_243));
    V v_c_2413 = heff_clo(g_heff_2etoplevel_2etraverseEL_24s457_lam1, 2, 2, (V[]){v_c_245, v_x_243});
    return heff_clo(g_heff_2etoplevel_2etraverseEL_24s457_lam3, 2, 2, (V[]){v_c_2413, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2etraverseEL_24s457_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2etraverseEL_24s457(a[0]);
}
V g_heff_2etoplevel_2etraverseEL_24s457_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s457_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411;
  switch (heff_tag_of(v_x_243)) {
  case TAG_At: {
    V v_s_2410 = heff_field(v_x_243, 1);
    heff_take_n(v_x_243, 2ULL, 2);
    v_t_2411 = v_s_2410;
    break;
  }
  default: heff_nomatch(v_x_243);
  }
  V v_x_2412 = ({ V a_0 = v_t_2411; V a_1 = v_x_248; V r_ = (g_heff_2erules_2easSmall(a_0, a_1)); heff_drop(v_x_248); r_; });
  V f_ = v_k_247;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s457_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo(g_heff_2etoplevel_2etraverseEL_24s457_lam2, 1, 2, (V[]){v_x_243, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etraverseEL_24s457_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2415;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_2416, v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s457_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2417 = (g_heff_2etoplevel_2etraverseEL_24s457(v_xs_244));
  return heff_tail(v_c_2417, 2, (V[]){v_hd_2414, heff_clo(g_heff_2etoplevel_2etraverseEL_24s457_lam5, 1, 2, (V[]){v_k_2415, v_x_2416})});
}
V g_heff_2etoplevel_2etraverseEL_24s457_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo(g_heff_2etoplevel_2etraverseEL_24s457_lam4, 1, 3, (V[]){v_xs_244, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2etoplevel_2evariantF_24s456_str0 = {{0x80000000u, K_STR, 0}, 45, 45, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 118, 97, 114, 105, 97, 110, 116, 32, 105, 110, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
V g_heff_2etoplevel_2evariantF_24s456_lam1(V self, V *args);
V g_heff_2etoplevel_2evariantF_24s456_lam0(V self, V *args);
V g_heff_2etoplevel_2evariantF_24s456_lam2(V self, V *args);
Clo g_heff_2etoplevel_2evariantF_24s456_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2evariantF_24s456_entry, 1, 0};

V g_heff_2etoplevel_2evariantF_24s456(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TagVariant: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_args_245 = heff_field(v_x21_241, 2);
      heff_take_n(v_x21_241, 5ULL, 3);
      heff_drop(v_x22_242);
      V v_c_246 = (g_heff_2etoplevel_2etraverseEL_24s457(v_args_245));
      return heff_clo(g_heff_2etoplevel_2evariantF_24s456_lam0, 2, 2, (V[]){v_c_246, v_x_243});
    }
    case TAG_BadVariant: {
      heff_take_n(v_x21_241, 0ULL, 1);
      return heff_clo(g_heff_2etoplevel_2evariantF_24s456_lam2, 2, 1, (V[]){v_x22_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2evariantF_24s456_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2evariantF_24s456(a[0]);
}
V g_heff_2etoplevel_2evariantF_24s456_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){v_x_243, heff_arrayFromList(v_x_249)});
  V f_ = v_k_248;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2evariantF_24s456_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo(g_heff_2etoplevel_2evariantF_24s456_lam1, 1, 2, (V[]){v_x_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2evariantF_24s456_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2evariantF_24s456_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2416}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2417;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etraverseEL_24s458_lam0(V self, V *args); static Clo g_heff_2etoplevel_2etraverseEL_24s458_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s458_lam0, 2, 0};
V g_heff_2etoplevel_2etraverseEL_24s458_lam3(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s458_lam2(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s458_lam1(V self, V *args);
Clo g_heff_2etoplevel_2etraverseEL_24s458_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s458_entry, 1, 0};

V g_heff_2etoplevel_2etraverseEL_24s458(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2etoplevel_2etraverseEL_24s458_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = (g_heff_2etoplevel_2evariantF_24s456(v_x_243));
    return heff_clo(g_heff_2etoplevel_2etraverseEL_24s458_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2etraverseEL_24s458_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2etraverseEL_24s458(a[0]);
}
V g_heff_2etoplevel_2etraverseEL_24s458_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s458_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s458_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2etoplevel_2etraverseEL_24s458(v_xs_244));
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo(g_heff_2etoplevel_2etraverseEL_24s458_lam3, 1, 2, (V[]){v_k_247, v_x_248})});
}
V g_heff_2etoplevel_2etraverseEL_24s458_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2etoplevel_2etraverseEL_24s458_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam2(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam1(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam0(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam4(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam3(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam6(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam5(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam9(V self, V *args); static Clo g_heff_2etoplevel_2etypF_24s439_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etypF_24s439_lam9, 1, 0};
V g_heff_2etoplevel_2etypF_24s439_lam8(V self, V *args); static Clo g_heff_2etoplevel_2etypF_24s439_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etypF_24s439_lam8, 3, 0};
V g_heff_2etoplevel_2etypF_24s439_lam7(V self, V *args); static Clo g_heff_2etoplevel_2etypF_24s439_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etypF_24s439_lam7, 2, 0};
V g_heff_2etoplevel_2etypF_24s439_lam10(V self, V *args); static Clo g_heff_2etoplevel_2etypF_24s439_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etypF_24s439_lam10, 2, 0};
V g_heff_2etoplevel_2etypF_24s439_lam11(V self, V *args); static Clo g_heff_2etoplevel_2etypF_24s439_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etypF_24s439_lam11, 2, 0};
V g_heff_2etoplevel_2etypF_24s439_lam12(V self, V *args); static Clo g_heff_2etoplevel_2etypF_24s439_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etypF_24s439_lam12, 2, 0};
V g_heff_2etoplevel_2etypF_24s439_lam14(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam13(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam16(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam15(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam21(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam20(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam19(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam18(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam17(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam23(V self, V *args);
V g_heff_2etoplevel_2etypF_24s439_lam22(V self, V *args);
Clo g_heff_2etoplevel_2etypF_24s439_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etypF_24s439_entry, 1, 0};

V g_heff_2etoplevel_2etypF_24s439(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_it1_241 = heff_field(v_n_240, 0);
    V v_it2_242 = heff_field(v_n_240, 1);
    switch (heff_tag_of(v_it1_241)) {
    case TAG_TPi: {
      V v_b_243 = heff_field(v_it1_241, 0);
      V v_codN_244 = heff_field(v_it1_241, 1);
      V v_c_245 = (g_heff_2etoplevel_2ebinderF_24s440(heff_dup(v_b_243)));
      return heff_clo(g_heff_2etoplevel_2etypF_24s439_lam0, 2, 2, (V[]){v_c_245, heff_dup(v_codN_244)});
    }
    case TAG_TSig: {
      V v_fields_2412 = heff_field(v_it1_241, 0);
      V v_c_2413 = (g_heff_2etoplevel_2etraverseEL_24s455(heff_dup(v_fields_2412)));
      return heff_clo(g_heff_2etoplevel_2etypF_24s439_lam3, 2, 1, (V[]){v_c_2413});
    }
    case TAG_TSum: {
      V v_variantNs_2418 = heff_field(v_it1_241, 0);
      V v_c_2419 = (g_heff_2etoplevel_2etraverseEL_24s458(heff_dup(v_variantNs_2418)));
      return heff_clo(g_heff_2etoplevel_2etypF_24s439_lam5, 2, 1, (V[]){v_c_2419});
    }
    case TAG_TType: {
      return ((V)&g_heff_2etoplevel_2etypF_24s439_lam7_clo);
    }
    case TAG_TInt: {
      return ((V)&g_heff_2etoplevel_2etypF_24s439_lam10_clo);
    }
    case TAG_TFloat: {
      return ((V)&g_heff_2etoplevel_2etypF_24s439_lam11_clo);
    }
    case TAG_TString: {
      return ((V)&g_heff_2etoplevel_2etypF_24s439_lam12_clo);
    }
    case TAG_TArray: {
      V v_a0_2442 = heff_field(v_it1_241, 0);
      V v_c_2443 = (g_heff_2etoplevel_2etypF_24s439(v_a0_2442));
      return heff_clo(g_heff_2etoplevel_2etypF_24s439_lam13, 2, 1, (V[]){v_c_2443});
    }
    case TAG_TInf: {
      V v_i_2448 = heff_field(v_it1_241, 0);
      V v_c_2449 = (g_heff_2etoplevel_2einfF_24s444(heff_dup(v_i_2448)));
      return heff_clo(g_heff_2etoplevel_2etypF_24s439_lam15, 2, 2, (V[]){v_c_2449, heff_dup(v_it2_242)});
    }
    case TAG_TChk: {
      V v_ch_2454 = heff_field(v_it1_241, 0);
      V v_c_2455 = (g_heff_2etoplevel_2erawF_24s447(heff_dup(v_ch_2454)));
      return heff_clo(g_heff_2etoplevel_2etypF_24s439_lam17, 2, 1, (V[]){v_c_2455});
    }
    case TAG_TNominal: {
      V v_t_2467 = heff_field(v_it1_241, 0);
      V v_c_2468 = (g_heff_2etoplevel_2etypF_24s439(v_t_2467));
      return heff_clo(g_heff_2etoplevel_2etypF_24s439_lam22, 2, 1, (V[]){v_c_2468});
    }
    default: return heff_nomatch(v_it1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2etoplevel_2etypF_24s439_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2etypF_24s439(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2etypF_24s439_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = ({ V a_0 = v_x_248; V a_1 = v_x_2410; V r_ = (g_heff_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_x_2410); r_; });
  V f_ = v_k_247;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_codN_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = ({ V a_0 = v_codN_244; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_codN_244); r_; });
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo(g_heff_2etoplevel_2etypF_24s439_lam2, 1, 2, (V[]){v_x_248, v_k_247})});
}
V g_heff_2etoplevel_2etypF_24s439_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_codN_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2etoplevel_2etypF_24s439_lam1, 1, 3, (V[]){v_codN_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = (g_heff_2erules_2erecordFormation(v_x_2416));
  V f_ = v_k_2415;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo(g_heff_2etoplevel_2etypF_24s439_lam4, 1, 1, (V[]){v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = (g_prelude_2emap_24s5(heff_dup(v_x_2422)));
  V v_t_2424 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_x_2422));
  V v_t_2425 = (g_prelude_2emap_24s6(v_x_2422));
  V v_t_2426 = heff_rec(3, shape_153_35_368, (V[]){heff_arrayFromList(v_t_2423), v_t_2424, heff_arrayFromList(v_t_2425)});
  V v_x_2427 = (g_heff_2erules_2esumFormation(v_t_2426));
  V f_ = v_k_2421;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam5(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo(g_heff_2etoplevel_2etypF_24s439_lam6, 1, 1, (V[]){v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam9(V self, V *args) {
  V v_u2_2434 = args[0];
  heff_drop(v_u2_2434);
  V v_t_2435 = heff_tag(TAG_VU, 1, (V[]){NTAG(TAG_SmallU)});
  return heff_tag(TAG_Nom, 1, (V[]){v_t_2435});
}
V g_heff_2etoplevel_2etypF_24s439_lam8(V self, V *args) {
  V v_e_2430 = args[0];
  V v_hd_2431 = args[1];
  V v_k_2432 = args[2];
  heff_drop(v_e_2430);
  heff_drop(v_hd_2431);
  V v_t_2433 = heff_tag(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
  V f_ = v_k_2432;
  args[0] = heff_rec(2, shape_326_366, (V[]){v_t_2433, ((V)&g_heff_2etoplevel_2etypF_24s439_lam9_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam7(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = heff_tag(TAG_MkTyp, 1, (V[]){((V)&g_heff_2etoplevel_2etypF_24s439_lam8_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam10(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = heff_dup(g_heff_2erules_2eprimInt_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam11(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = heff_dup(g_heff_2erules_2eprimFloat_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam12(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = heff_dup(g_heff_2erules_2eprimString_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam14(V self, V *args) {
  V v_x_2446 = args[0];
  V v_k_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447 = ({ V a_0 = v_x_2446; V r_ = (g_heff_2erules_2eprimArray(a_0)); heff_drop(v_x_2446); r_; });
  V f_ = v_k_2445;
  args[0] = v_t_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam13(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_c_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2443;
  args[0] = v_hd_2444;
  args[1] = heff_clo(g_heff_2etoplevel_2etypF_24s439_lam14, 1, 1, (V[]){v_k_2445});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam16(V self, V *args) {
  V v_x_2452 = args[0];
  V v_it2_242 = heff_env(self)[0];
  V v_k_2451 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453 = ({ V a_0 = v_it2_242; V a_1 = v_x_2452; V r_ = (g_heff_2erules_2euniverseElimSyn(a_0, a_1)); heff_drop(v_x_2452); r_; });
  V f_ = v_k_2451;
  args[0] = v_t_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam15(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_c_2449 = heff_env(self)[0];
  V v_it2_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2449;
  args[0] = v_hd_2450;
  args[1] = heff_clo(g_heff_2etoplevel_2etypF_24s439_lam16, 1, 2, (V[]){v_it2_242, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam21(V self, V *args) {
  V v_x_2465 = args[0];
  V v_k_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = (g_heff_2ememoed_2edecode(v_x_2465));
  V f_ = v_k_2464;
  args[0] = v_t_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam20(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k_2464 = args[1];
  V v_c_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2462;
  args[0] = v_hd_2463;
  args[1] = heff_clo(g_heff_2etoplevel_2etypF_24s439_lam21, 1, 1, (V[]){v_k_2464});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam19(V self, V *args) {
  V v_e_2459 = args[0];
  V v_x_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2462;
  switch (heff_tag_of(v_x_2458)) {
  case TAG_MkChk: {
    V v_f_2460 = heff_field(v_x_2458, 0);
    V v_ru_24x_2458_24MkChk = heff_take_reuse_n(v_x_2458, 1ULL, 1);
    V v_t_2461 = heff_tag_at(v_ru_24x_2458_24MkChk, TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
    v_c_2462 = heff_tr(heff_apply(v_f_2460, 2, (V[]){v_e_2459, v_t_2461}));
    break;
  }
  default: heff_nomatch(v_x_2458);
  }
  return heff_clo(g_heff_2etoplevel_2etypF_24s439_lam20, 2, 1, (V[]){v_c_2462});
}
V g_heff_2etoplevel_2etypF_24s439_lam18(V self, V *args) {
  V v_x_2458 = args[0];
  V v_k_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2457;
  args[0] = heff_tag(TAG_MkTyp, 1, (V[]){heff_clo(g_heff_2etoplevel_2etypF_24s439_lam19, 1, 1, (V[]){v_x_2458})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam17(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2455;
  args[0] = v_hd_2456;
  args[1] = heff_clo(g_heff_2etoplevel_2etypF_24s439_lam18, 1, 1, (V[]){v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam23(V self, V *args) {
  V v_x_2471 = args[0];
  V v_k_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2472 = ({ V a_0 = v_x_2471; V r_ = (g_heff_2etoplevel_2enominalTyp(a_0)); heff_drop(v_x_2471); r_; });
  V f_ = v_k_2470;
  args[0] = v_t_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etypF_24s439_lam22(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k_2470 = args[1];
  V v_c_2468 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2468;
  args[0] = v_hd_2469;
  args[1] = heff_clo(g_heff_2etoplevel_2etypF_24s439_lam23, 1, 1, (V[]){v_k_2470});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eargBinding_lam1(V self, V *args);
V g_heff_2etoplevel_2eargBinding_lam0(V self, V *args);
V g_heff_2etoplevel_2eargBinding_lam3(V self, V *args);
V g_heff_2etoplevel_2eargBinding_lam2(V self, V *args);
Clo g_heff_2etoplevel_2eargBinding_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eargBinding_entry, 1, 0};

V g_heff_2etoplevel_2eargBinding(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_ExplicitParam: {
      V v_x_243 = heff_field(v_x11_241, 0);
      V v_t_245 = heff_field(v_x11_241, 2);
      V v_n_248;
      switch (heff_tag_of(v_t_245)) {
      case TAG_At: {
        V v_n_246 = heff_field(v_t_245, 0);
        V v_sp_247 = heff_field(v_t_245, 1);
        v_n_248 = (g_heff_2epresyntax_2etypNom_24s74(heff_dup(v_sp_247), heff_dup(v_n_246)));
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      V v_c_249 = ({ V a_0 = v_n_248; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_n_248); r_; });
      return heff_clo(g_heff_2etoplevel_2eargBinding_lam0, 2, 3, (V[]){v_c_249, heff_dup(v_sp_242), heff_dup(v_x_243)});
    }
    case TAG_ImplicitParam: {
      V v_x_2414 = heff_field(v_x11_241, 0);
      V v_t_2416 = heff_field(v_x11_241, 2);
      V v_n_2419;
      switch (heff_tag_of(v_t_2416)) {
      case TAG_At: {
        V v_n_2417 = heff_field(v_t_2416, 0);
        V v_sp_2418 = heff_field(v_t_2416, 1);
        v_n_2419 = (g_heff_2epresyntax_2etypNom_24s74(heff_dup(v_sp_2418), heff_dup(v_n_2417)));
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
      V v_c_2420 = ({ V a_0 = v_n_2419; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_n_2419); r_; });
      return heff_clo(g_heff_2etoplevel_2eargBinding_lam2, 2, 3, (V[]){v_c_2420, heff_dup(v_sp_242), heff_dup(v_x_2414)});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2etoplevel_2eargBinding_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eargBinding(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2eargBinding_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_rec(4, shape_314_198_353_134, (V[]){v_sp_242, v_x_243, v_x_2412, NTAG(TAG_Expl)});
  V f_ = v_k_2411;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eargBinding_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo(g_heff_2etoplevel_2eargBinding_lam1, 1, 3, (V[]){v_sp_242, v_x_243, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eargBinding_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_k_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2424 = heff_rec(4, shape_314_198_353_134, (V[]){v_sp_242, v_x_2414, v_x_2423, NTAG(TAG_Impl)});
  V f_ = v_k_2422;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eargBinding_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo(g_heff_2etoplevel_2eargBinding_lam3, 1, 3, (V[]){v_sp_242, v_x_2414, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2etoplevel_2ewithOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ewithOne_entry, 2, 0};

V g_heff_2etoplevel_2ewithOne(V v_ab_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_c_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_get(heff_dup(v_ab_240), LBL_implicit);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Expl: {
      V v_t_245 = heff_tag_at(v_ru_24x2_241_24MkPair, TAG_Named, 2, (V[]){heff_get(heff_dup(v_ab_240), LBL_name), heff_get(heff_dup(v_ab_240), LBL_typ)});
      V v_t_246 = ({ V a_0 = v_t_245; V a_1 = v_t_242; V r_ = (g_heff_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_242); r_; });
      return heff_tag(TAG_MkPair, 2, (V[]){v_t_246, ({ V a_0 = heff_get(heff_dup(v_ab_240), LBL_span); V a_1 = heff_get(v_ab_240, LBL_name); V a_2 = v_c_243; V r_ = (g_heff_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_c_243); r_; })});
    }
    case TAG_Impl: {
      V v_t_247 = heff_tag(TAG_NamedImplicit, 3, (V[]){heff_get(heff_dup(v_ab_240), LBL_span), heff_get(heff_dup(v_ab_240), LBL_name), heff_get(heff_dup(v_ab_240), LBL_typ)});
      V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_t_242; V r_ = (g_heff_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_242); r_; });
      return heff_tag_at(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_248, ({ V a_0 = heff_get(heff_dup(v_ab_240), LBL_span); V a_1 = heff_get(v_ab_240, LBL_name); V a_2 = v_c_243; V r_ = (g_heff_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_243); r_; })});
    }
    case TAG_Inst: {
      V v_t_249 = heff_tag(TAG_NamedInstance, 3, (V[]){heff_get(heff_dup(v_ab_240), LBL_span), heff_get(heff_dup(v_ab_240), LBL_name), heff_get(heff_dup(v_ab_240), LBL_typ)});
      V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_t_242; V r_ = (g_heff_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_242); r_; });
      return heff_tag_at(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_2410, ({ V a_0 = heff_get(heff_dup(v_ab_240), LBL_span); V a_1 = heff_get(v_ab_240, LBL_name); V a_2 = v_c_243; V r_ = (g_heff_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_243); r_; })});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2etoplevel_2ewithOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2ewithOne(a[0], a[1]);
}
Clo g_heff_2etoplevel_2ewithArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ewithArgs_entry, 2, 0};

V g_heff_2etoplevel_2ewithArgs(V v_x1_240, V v_base_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_base_241;
  }
  case TAG_Cons: {
    V v_ab_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_heff_2etoplevel_2ewithArgs(v_rest_243, v_base_241));
    HEFF_LAST return g_heff_2etoplevel_2ewithOne(heff_dup(v_ab_242), v_t_244);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2etoplevel_2ewithArgs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2ewithArgs(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2etraverseEL_24s459_lam0(V self, V *args); static Clo g_heff_2etoplevel_2etraverseEL_24s459_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s459_lam0, 2, 0};
V g_heff_2etoplevel_2etraverseEL_24s459_lam3(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s459_lam2(V self, V *args);
V g_heff_2etoplevel_2etraverseEL_24s459_lam1(V self, V *args);
Clo g_heff_2etoplevel_2etraverseEL_24s459_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etraverseEL_24s459_entry, 1, 0};

V g_heff_2etoplevel_2etraverseEL_24s459(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2etoplevel_2etraverseEL_24s459_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2etoplevel_2eargBinding(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo(g_heff_2etoplevel_2etraverseEL_24s459_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2etraverseEL_24s459_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2etraverseEL_24s459(a[0]);
}
V g_heff_2etoplevel_2etraverseEL_24s459_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s459_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etraverseEL_24s459_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2etoplevel_2etraverseEL_24s459(v_xs_244));
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo(g_heff_2etoplevel_2etraverseEL_24s459_lam3, 1, 2, (V[]){v_k_247, v_x_248})});
}
V g_heff_2etoplevel_2etraverseEL_24s459_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2etoplevel_2etraverseEL_24s459_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2etheoryD_lam4(V self, V *args); static Clo g_heff_2etoplevel_2etheoryD_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etheoryD_lam4, 1, 0};
V g_heff_2etoplevel_2etheoryD_lam3(V self, V *args); static Clo g_heff_2etoplevel_2etheoryD_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etheoryD_lam3, 3, 0};
V g_heff_2etoplevel_2etheoryD_lam2(V self, V *args);
V g_heff_2etoplevel_2etheoryD_lam1(V self, V *args);
V g_heff_2etoplevel_2etheoryD_lam0(V self, V *args);
Clo g_heff_2etoplevel_2etheoryD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etheoryD_entry, 3, 0};

V g_heff_2etoplevel_2etheoryD(V v_name_240, V v_params_241, V v_bodyN_242) {
top: ;
  V v_c_243 = (g_heff_2etoplevel_2etraverseEL_24s459(v_params_241));
  return heff_clo(g_heff_2etoplevel_2etheoryD_lam0, 2, 3, (V[]){v_c_243, heff_dup(v_bodyN_242), v_name_240});
}
V g_heff_2etoplevel_2etheoryD_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2etheoryD(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2etoplevel_2etheoryD_lam4(V self, V *args) {
  V v_u2_2416 = args[0];
  heff_drop(v_u2_2416);
  V v_t_2417 = heff_tag(TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
  return heff_tag(TAG_Nom, 1, (V[]){v_t_2417});
}
V g_heff_2etoplevel_2etheoryD_lam3(V self, V *args) {
  V v_e_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_e_2412);
  heff_drop(v_hd_2413);
  V v_t_2415 = heff_tag(TAG_SU, 1, (V[]){NTAG(TAG_LargeU)});
  V f_ = v_k_2414;
  args[0] = heff_rec(2, shape_326_366, (V[]){v_t_2415, ((V)&g_heff_2etoplevel_2etheoryD_lam4_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2etheoryD_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_MkTyp, 1, (V[]){((V)&g_heff_2etoplevel_2etheoryD_lam3_clo)}), v_x_2411});
  V v_x2_2419 = ({ V a_0 = v_x_246; V a_1 = v_t_2418; V r_ = (g_heff_2etoplevel_2ewithArgs(a_0, a_1)); heff_drop(v_x_246); r_; });
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_ty_2420 = heff_field(v_x2_2419, 0);
    V v_tm_2421 = heff_field(v_x2_2419, 1);
    heff_take_n(v_x2_2419, 3ULL, 2);
    V v_t_2422 = heff_rec(4, shape_198_351_339_255, (V[]){v_name_240, v_ty_2420, v_tm_2421, NTAG(TAG_False)});
    V f_ = v_k_245;
    args[0] = v_t_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2etoplevel_2etheoryD_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_bodyN_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_n_249;
  switch (heff_tag_of(v_bodyN_242)) {
  case TAG_At: {
    V v_n_247 = heff_field(v_bodyN_242, 0);
    V v_sp_248 = heff_field(v_bodyN_242, 1);
    heff_take_n(v_bodyN_242, 3ULL, 2);
    v_n_249 = (g_heff_2epresyntax_2echkDe_24s85(v_sp_248, v_n_247));
    break;
  }
  default: heff_nomatch(v_bodyN_242);
  }
  V v_c_2410 = (g_heff_2etoplevel_2echkF_24s443(v_n_249));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_244, heff_clo(g_heff_2etoplevel_2etheoryD_lam2, 1, 3, (V[]){v_x_246, v_name_240, v_k_245})});
}
V g_heff_2etoplevel_2etheoryD_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_bodyN_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo(g_heff_2etoplevel_2etheoryD_lam1, 1, 4, (V[]){v_bodyN_242, v_hd_244, v_name_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2etoplevel_2eexplicitNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eexplicitNames_entry, 1, 0};

V g_heff_2etoplevel_2eexplicitNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ab_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_ab_241), LBL_implicit);
    V v_x1_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Expl: {
      v_x1_244 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_x1_244 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_x1_244 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    switch (heff_tag_of(v_x1_244)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_ab_241, LBL_name), (g_heff_2etoplevel_2eexplicitNames(v_rest_242))});
    }
    case TAG_False: {
      heff_drop(v_ab_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2etoplevel_2eexplicitNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2eexplicitNames(a[0]);
}
V g_heff_2etoplevel_2edefineD_lam3(V self, V *args);
V g_heff_2etoplevel_2edefineD_lam2(V self, V *args);
V g_heff_2etoplevel_2edefineD_lam1(V self, V *args);
V g_heff_2etoplevel_2edefineD_lam0(V self, V *args);
Clo g_heff_2etoplevel_2edefineD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2edefineD_entry, 4, 0};

V g_heff_2etoplevel_2edefineD(V v_name_240, V v_params_241, V v_tyN_242, V v_bodyN_243) {
top: ;
  V v_c_244 = (g_heff_2etoplevel_2etraverseEL_24s459(v_params_241));
  return heff_clo(g_heff_2etoplevel_2edefineD_lam0, 2, 4, (V[]){v_c_244, heff_dup(v_tyN_242), heff_dup(v_bodyN_243), v_name_240});
}
V g_heff_2etoplevel_2edefineD_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2edefineD(a[0], a[1], a[2], a[3]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2etoplevel_2edefineD_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2418 = ({ V a_0 = v_x_247; V a_1 = heff_tag(TAG_MkPair, 2, (V[]){v_x_2412, v_x_2417}); V r_ = (g_heff_2etoplevel_2ewithArgs(a_0, a_1)); heff_drop(v_x_247); r_; });
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_ty_2419 = heff_field(v_x2_2418, 0);
    V v_tm_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = heff_rec(4, shape_198_351_339_255, (V[]){v_name_240, v_ty_2419, v_tm_2420, NTAG(TAG_False)});
    V f_ = v_k_246;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2etoplevel_2edefineD_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_bodyN_243 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_n_2415;
  switch (heff_tag_of(v_bodyN_243)) {
  case TAG_At: {
    V v_n_2413 = heff_field(v_bodyN_243, 0);
    V v_sp_2414 = heff_field(v_bodyN_243, 1);
    heff_take_n(v_bodyN_243, 3ULL, 2);
    v_n_2415 = (g_heff_2epresyntax_2echkDe_24s85(v_sp_2414, v_n_2413));
    break;
  }
  default: heff_nomatch(v_bodyN_243);
  }
  V v_c_2416 = (g_heff_2etoplevel_2echkF_24s443(v_n_2415));
  return heff_tail(v_c_2416, 2, (V[]){v_hd_245, heff_clo(g_heff_2etoplevel_2edefineD_lam3, 1, 4, (V[]){v_x_247, v_x_2412, v_name_240, v_k_246})});
}
V g_heff_2etoplevel_2edefineD_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_tyN_242 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_bodyN_243 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_n_2410;
  switch (heff_tag_of(v_tyN_242)) {
  case TAG_At: {
    V v_n_248 = heff_field(v_tyN_242, 0);
    V v_sp_249 = heff_field(v_tyN_242, 1);
    heff_take_n(v_tyN_242, 3ULL, 2);
    v_n_2410 = (g_heff_2epresyntax_2etypNom_24s74(v_sp_249, v_n_248));
    break;
  }
  default: heff_nomatch(v_tyN_242);
  }
  V v_c_2411 = ({ V a_0 = v_n_2410; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_n_2410); r_; });
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_hd_245), heff_clo(g_heff_2etoplevel_2edefineD_lam2, 1, 5, (V[]){v_bodyN_243, v_hd_245, v_x_247, v_name_240, v_k_246})});
}
V g_heff_2etoplevel_2edefineD_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_tyN_242 = heff_env(self)[1];
  V v_bodyN_243 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo(g_heff_2etoplevel_2edefineD_lam1, 1, 5, (V[]){v_tyN_242, v_hd_245, v_bodyN_243, v_name_240, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eequationsBody_lam0(V self, V *args);
V g_heff_2etoplevel_2eequationsBody_lam1(V self, V *args);
V g_heff_2etoplevel_2eequationsBody_lam3(V self, V *args);
V g_heff_2etoplevel_2eequationsBody_lam2(V self, V *args);
Clo g_heff_2etoplevel_2eequationsBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eequationsBody_entry, 4, 0};

V g_heff_2etoplevel_2eequationsBody(V v_name_240, V v_args_241, V v_eqs_242, V v_sp_243) {
top: ;
  V v_t_244 = (g_heff_2etoplevel_2eexplicitNames(v_args_241));
  V v_t_245 = (g_heff_2eclauses_2edesugar(v_name_240, v_t_244, v_eqs_242, v_sp_243));
  V v_c_2416;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Left: {
    V v_err_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_c_2416 = heff_clo(g_heff_2etoplevel_2eequationsBody_lam0, 2, 1, (V[]){v_err_246});
    break;
  }
  case TAG_Right: {
    V v_b_2413 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_c_2416 = heff_clo(g_heff_2etoplevel_2eequationsBody_lam1, 2, 1, (V[]){v_b_2413});
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_clo(g_heff_2etoplevel_2eequationsBody_lam2, 2, 1, (V[]){v_c_2416});
}
V g_heff_2etoplevel_2eequationsBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2eequationsBody(a[0], a[1], a[2], a[3]);
}
V g_heff_2etoplevel_2eequationsBody_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_err_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(210LL), NTAG(TAG_SError), heff_get(heff_dup(v_err_246), LBL_msg), heff_get(v_err_246, LBL_span), NTAG(TAG_Nothing)});
  V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2411}));
  V f_ = heff_get(v_hd_247, LBL_bind);
  args[0] = v_t_2412;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eequationsBody_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_b_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = v_b_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eequationsBody_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_n_2422;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_At: {
    V v_n_2420 = heff_field(v_x_2419, 0);
    V v_sp_2421 = heff_field(v_x_2419, 1);
    heff_take_n(v_x_2419, 3ULL, 2);
    v_n_2422 = (g_heff_2epresyntax_2echkDe_24s85(v_sp_2421, v_n_2420));
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V v_t_2423 = (g_heff_2etoplevel_2echkF_24s443(v_n_2422));
  return heff_tail(v_t_2423, 2, (V[]){v_hd_2417, v_k_2418});
}
V g_heff_2etoplevel_2eequationsBody_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo(g_heff_2etoplevel_2eequationsBody_lam3, 1, 2, (V[]){v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eequationsD_lam3(V self, V *args);
V g_heff_2etoplevel_2eequationsD_lam5(V self, V *args);
V g_heff_2etoplevel_2eequationsD_lam4(V self, V *args);
V g_heff_2etoplevel_2eequationsD_lam2(V self, V *args);
V g_heff_2etoplevel_2eequationsD_lam8(V self, V *args);
V g_heff_2etoplevel_2eequationsD_lam7(V self, V *args);
V g_heff_2etoplevel_2eequationsD_lam6(V self, V *args);
V g_heff_2etoplevel_2eequationsD_lam1(V self, V *args);
V g_heff_2etoplevel_2eequationsD_lam0(V self, V *args);
V g_heff_2etoplevel_2eequationsD_lam11(V self, V *args);
V g_heff_2etoplevel_2eequationsD_lam10(V self, V *args);
V g_heff_2etoplevel_2eequationsD_lam9(V self, V *args);
Clo g_heff_2etoplevel_2eequationsD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eequationsD_entry, 4, 0};

V g_heff_2etoplevel_2eequationsD(V v_name_240, V v_tyN_241, V v_eqs_242, V v_sp_243) {
top: ;
  V v_x1_244 = (g_heff_2etoplevel_2eallL_24s436(v_eqs_242));
  V v_t_245;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_True: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_c_2430;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_c_2430 = heff_clo(g_heff_2etoplevel_2eequationsD_lam0, 2, 3, (V[]){v_eqs_242, heff_dup(v_name_240), v_sp_243});
    break;
  }
  case TAG_False: {
    v_c_2430 = (g_heff_2etoplevel_2eequationsBody(heff_dup(v_name_240), NTAG(TAG_Nil), v_eqs_242, v_sp_243));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_clo(g_heff_2etoplevel_2eequationsD_lam9, 2, 3, (V[]){v_c_2430, heff_dup(v_tyN_241), v_name_240});
}
V g_heff_2etoplevel_2eequationsD_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eequationsD(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2etoplevel_2eequationsD_lam3(V self, V *args) {
  V v_m_2417 = args[0];
  V v_e_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2etoplevel_2eopPat(heff_get(v_e_248, LBL_globals), v_m_2417));
}
V g_heff_2etoplevel_2eequationsD_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_f_2413 = heff_env(self)[0];
  V v_fsp_2414 = heff_env(self)[1];
  V v_rhs_2416 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_k_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2422 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_MkEquation, 4, (V[]){v_f_2413, v_fsp_2414, v_x_2421, v_rhs_2416}), v_sp_2412});
  V f_ = v_k_2420;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eequationsD_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_f_2413 = heff_env(self)[1];
  V v_fsp_2414 = heff_env(self)[2];
  V v_rhs_2416 = heff_env(self)[3];
  V v_sp_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo(g_heff_2etoplevel_2eequationsD_lam5, 1, 5, (V[]){v_f_2413, v_fsp_2414, v_rhs_2416, v_sp_2412, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eequationsD_lam2(V self, V *args) {
  V v_m_2410 = args[0];
  V v_e_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2410)) {
  case TAG_At: {
    V v_x21_2411 = heff_field(v_m_2410, 0);
    V v_sp_2412 = heff_field(v_m_2410, 1);
    heff_take_n(v_m_2410, 3ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkEquation: {
      V v_f_2413 = heff_field(v_x21_2411, 0);
      V v_fsp_2414 = heff_field(v_x21_2411, 1);
      V v_ps_2415 = heff_field(v_x21_2411, 2);
      V v_rhs_2416 = heff_field(v_x21_2411, 3);
      heff_take_n(v_x21_2411, 15ULL, 4);
      V v_c_2418 = (g_heff_2etoplevel_2etraverseEL(heff_clo(g_heff_2etoplevel_2eequationsD_lam3, 1, 1, (V[]){v_e_248}), v_ps_2415));
      return heff_clo(g_heff_2etoplevel_2eequationsD_lam4, 2, 5, (V[]){v_c_2418, v_f_2413, v_fsp_2414, v_rhs_2416, v_sp_2412});
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_m_2410);
  }
}
V g_heff_2etoplevel_2eequationsD_lam8(V self, V *args) {
  V v_x_2428 = args[0];
  V v_e_248 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  V v_hd_2424 = heff_env(self)[2];
  V v_k_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkChk: {
    V v_f_2429 = heff_field(v_x_2428, 0);
    heff_take_n(v_x_2428, 1ULL, 1);
    return heff_tail(v_f_2429, 4, (V[]){v_e_248, v_a_249, v_hd_2424, v_k_2425});
  }
  default: return heff_nomatch(v_x_2428);
  }
}
V g_heff_2etoplevel_2eequationsD_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_name_240 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_hd_2424 = heff_env(self)[2];
  V v_e_248 = heff_env(self)[3];
  V v_a_249 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2427 = (g_heff_2etoplevel_2eequationsBody(v_name_240, NTAG(TAG_Nil), v_x_2426, v_sp_243));
  return heff_tail(v_c_2427, 2, (V[]){heff_dup(v_hd_2424), heff_clo(g_heff_2etoplevel_2eequationsD_lam8, 1, 4, (V[]){v_e_248, v_a_249, v_hd_2424, v_k_2425})});
}
V g_heff_2etoplevel_2eequationsD_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_e_248 = heff_env(self)[3];
  V v_a_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo(g_heff_2etoplevel_2eequationsD_lam7, 1, 6, (V[]){v_name_240, v_sp_243, v_hd_2424, v_e_248, v_a_249, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eequationsD_lam1(V self, V *args) {
  V v_e_248 = args[0];
  V v_a_249 = args[1];
  V v_eqs_242 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2423 = (g_heff_2etoplevel_2etraverseEL(heff_clo(g_heff_2etoplevel_2eequationsD_lam2, 1, 1, (V[]){heff_dup(v_e_248)}), v_eqs_242));
  return heff_clo(g_heff_2etoplevel_2eequationsD_lam6, 2, 5, (V[]){v_c_2423, v_name_240, v_sp_243, v_e_248, v_a_249});
}
V g_heff_2etoplevel_2eequationsD_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_eqs_242 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2etoplevel_2eequationsD_lam1, 2, 3, (V[]){v_eqs_242, v_name_240, v_sp_243})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eequationsD_lam11(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2439 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = heff_tag(TAG_MkPair, 2, (V[]){v_x_2438, v_x_2433}); V r_ = (g_heff_2etoplevel_2ewithArgs(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_ty_2440 = heff_field(v_x2_2439, 0);
    V v_tm_2441 = heff_field(v_x2_2439, 1);
    heff_take_n(v_x2_2439, 3ULL, 2);
    V v_t_2442 = heff_rec(4, shape_198_351_339_255, (V[]){v_name_240, v_ty_2440, v_tm_2441, NTAG(TAG_False)});
    V f_ = v_k_2432;
    args[0] = v_t_2442;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2etoplevel_2eequationsD_lam10(V self, V *args) {
  V v_x_2433 = args[0];
  V v_tyN_241 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_n_2436;
  switch (heff_tag_of(v_tyN_241)) {
  case TAG_At: {
    V v_n_2434 = heff_field(v_tyN_241, 0);
    V v_sp_2435 = heff_field(v_tyN_241, 1);
    heff_take_n(v_tyN_241, 3ULL, 2);
    v_n_2436 = (g_heff_2epresyntax_2etypNom_24s74(v_sp_2435, v_n_2434));
    break;
  }
  default: heff_nomatch(v_tyN_241);
  }
  V v_c_2437 = ({ V a_0 = v_n_2436; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_n_2436); r_; });
  return heff_tail(v_c_2437, 2, (V[]){v_hd_2431, heff_clo(g_heff_2etoplevel_2eequationsD_lam11, 1, 3, (V[]){v_x_2433, v_name_240, v_k_2432})});
}
V g_heff_2etoplevel_2eequationsD_lam9(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_tyN_241 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2430;
  args[0] = heff_dup(v_hd_2431);
  args[1] = heff_clo(g_heff_2etoplevel_2eequationsD_lam10, 1, 4, (V[]){v_tyN_241, v_hd_2431, v_name_240, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2etoplevel_2edeclJ_str0 = {{0x80000000u, K_STR, 0}, 45, 45, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 116, 111, 112, 45, 108, 101, 118, 101, 108, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2etoplevel_2edeclJ_str1 = {{0x80000000u, K_STR, 0}, 45, 45, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 116, 111, 112, 45, 108, 101, 118, 101, 108, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110}};
V g_heff_2etoplevel_2edeclJ_lam3(V self, V *args); static Clo g_heff_2etoplevel_2edeclJ_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2edeclJ_lam3, 1, 0};
V g_heff_2etoplevel_2edeclJ_lam2(V self, V *args);
V g_heff_2etoplevel_2edeclJ_lam1(V self, V *args);
V g_heff_2etoplevel_2edeclJ_lam0(V self, V *args);
V g_heff_2etoplevel_2edeclJ_lam4(V self, V *args);
V g_heff_2etoplevel_2edeclJ_lam5(V self, V *args);
Clo g_heff_2etoplevel_2edeclJ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2edeclJ_entry, 1, 0};

V g_heff_2etoplevel_2edeclJ(V v_d_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_d_240, 0);
    v_t_243 = heff_dup(v_x_241);
    break;
  }
  default: heff_nomatch(v_d_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_DeclEquations: {
    V v_name_244 = heff_field(v_t_243, 0);
    V v_tyN_246 = heff_field(v_t_243, 2);
    V v_eqs_247 = heff_field(v_t_243, 3);
    heff_take_n(v_t_243, 13ULL, 4);
    V v_t_2410;
    switch (heff_tag_of(v_tyN_246)) {
    case TAG_At: {
      V v_s_249 = heff_dup(heff_field(v_tyN_246, 1));
      v_t_2410 = v_s_249;
      break;
    }
    default: heff_nomatch(v_tyN_246);
    }
    V v_t_2413;
    switch (heff_tag_of(v_d_240)) {
    case TAG_At: {
      V v_s_2412 = heff_field(v_d_240, 1);
      v_t_2413 = heff_dup(v_s_2412);
      break;
    }
    default: heff_nomatch(v_d_240);
    }
    V v_t_2414 = heff_rec(2, shape_320_83, (V[]){heff_get(v_t_2410, LBL_start), heff_get(v_t_2413, LBL_end)});
    return ({ V a_0 = v_name_244; V a_1 = v_tyN_246; V a_2 = v_eqs_247; V a_3 = v_t_2414; V r_ = (g_heff_2etoplevel_2eequationsD(a_0, a_1, a_2, a_3)); heff_drop(v_tyN_246); r_; });
  }
  case TAG_DeclDefine: {
    V v_name_2415 = heff_field(v_t_243, 0);
    V v_params_2417 = heff_field(v_t_243, 2);
    V v_tyN_2418 = heff_field(v_t_243, 3);
    V v_bodyN_2419 = heff_field(v_t_243, 4);
    heff_take_n(v_t_243, 29ULL, 5);
    return ({ V a_0 = v_name_2415; V a_1 = v_params_2417; V a_2 = v_tyN_2418; V a_3 = v_bodyN_2419; V r_ = (g_heff_2etoplevel_2edefineD(a_0, a_1, a_2, a_3)); heff_drop(v_tyN_2418); heff_drop(v_bodyN_2419); r_; });
  }
  case TAG_DeclTheory: {
    V v_name_2420 = heff_field(v_t_243, 0);
    V v_params_2422 = heff_field(v_t_243, 2);
    V v_bodyN_2423 = heff_field(v_t_243, 3);
    heff_take_n(v_t_243, 13ULL, 4);
    return ({ V a_0 = v_name_2420; V a_1 = v_params_2422; V a_2 = v_bodyN_2423; V r_ = (g_heff_2etoplevel_2etheoryD(a_0, a_1, a_2)); heff_drop(v_bodyN_2423); r_; });
  }
  case TAG_DeclPrimitive: {
    V v_x_2424 = heff_field(v_t_243, 0);
    V v_tyN_2426 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    V v_n_2429;
    switch (heff_tag_of(v_tyN_2426)) {
    case TAG_At: {
      V v_n_2427 = heff_field(v_tyN_2426, 0);
      V v_sp_2428 = heff_field(v_tyN_2426, 1);
      heff_take_n(v_tyN_2426, 3ULL, 2);
      v_n_2429 = (g_heff_2epresyntax_2etypNom_24s74(v_sp_2428, v_n_2427));
      break;
    }
    default: heff_nomatch(v_tyN_2426);
    }
    V v_c_2430 = ({ V a_0 = v_n_2429; V r_ = (g_heff_2etoplevel_2etypF_24s439(a_0)); heff_drop(v_n_2429); r_; });
    return heff_clo(g_heff_2etoplevel_2edeclJ_lam0, 2, 2, (V[]){v_c_2430, v_x_2424});
  }
  case TAG_DeclTest: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_sp_2445;
    switch (heff_tag_of(v_d_240)) {
    case TAG_At: {
      V v_s_2444 = heff_field(v_d_240, 1);
      v_sp_2445 = heff_dup(v_s_2444);
      break;
    }
    default: heff_nomatch(v_d_240);
    }
    return heff_clo(g_heff_2etoplevel_2edeclJ_lam4, 2, 1, (V[]){v_sp_2445});
  }
  case TAG_DeclWatch: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_sp_2455;
    switch (heff_tag_of(v_d_240)) {
    case TAG_At: {
      V v_s_2454 = heff_field(v_d_240, 1);
      v_sp_2455 = heff_dup(v_s_2454);
      break;
    }
    default: heff_nomatch(v_d_240);
    }
    return heff_clo(g_heff_2etoplevel_2edeclJ_lam5, 2, 1, (V[]){v_sp_2455});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2etoplevel_2edeclJ_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2edeclJ(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2edeclJ_lam3(V self, V *args) {
  V v_u_2438 = args[0];
  heff_drop(v_u_2438);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2etoplevel_2edeclJ_lam2(V self, V *args) {
  V v_e_2434 = args[0];
  V v_a_2435 = args[1];
  V v_hd_2436 = args[2];
  V v_k_2437 = args[3];
  V v_x_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2434);
  heff_drop(v_a_2435);
  heff_drop(v_hd_2436);
  V v_t_2439 = heff_rec(2, shape_326_366, (V[]){heff_tag(TAG_SPrim, 1, (V[]){v_x_2424}), ((V)&g_heff_2etoplevel_2edeclJ_lam3_clo)});
  V f_ = v_k_2437;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2edeclJ_lam1(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_k_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_rec(4, shape_198_351_339_255, (V[]){heff_dup(v_x_2424), v_x_2433, heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2etoplevel_2edeclJ_lam2, 4, 1, (V[]){v_x_2424})}), NTAG(TAG_True)});
  V f_ = v_k_2432;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2edeclJ_lam0(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2430;
  args[0] = v_hd_2431;
  args[1] = heff_clo(g_heff_2etoplevel_2edeclJ_lam1, 1, 2, (V[]){v_x_2424, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2edeclJ_lam4(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k2_2447 = args[1];
  V v_sp_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2edeclJ_str0), v_sp_2445, NTAG(TAG_Nothing)});
  V v_t_2449 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2446), LBL_malg), 1, (V[]){v_t_2450}));
  V f_ = heff_get(v_hd_2446, LBL_bind);
  args[0] = v_t_2451;
  args[1] = v_k2_2447;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2edeclJ_lam5(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_sp_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2edeclJ_str1), v_sp_2455, NTAG(TAG_Nothing)});
  V v_t_2459 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2456), LBL_malg), 1, (V[]){v_t_2460}));
  V f_ = heff_get(v_hd_2456, LBL_bind);
  args[0] = v_t_2461;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2etoplevel_2erecoveredCheck_str0 = {{0x80000000u, K_STR, 0}, 21, 21, {101, 114, 114, 111, 114, 115, 32, 114, 101, 99, 111, 118, 101, 114, 101, 100, 32, 102, 114, 111, 109}};
V g_heff_2etoplevel_2erecoveredCheck_lam0(V self, V *args); static Clo g_heff_2etoplevel_2erecoveredCheck_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2erecoveredCheck_lam0, 1, 0};
V g_heff_2etoplevel_2erecoveredCheck_lam1(V self, V *args);
Clo g_heff_2etoplevel_2erecoveredCheck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2erecoveredCheck_entry, 2, 0};

V g_heff_2etoplevel_2erecoveredCheck(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2etoplevel_2erecoveredCheck_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2etoplevel_2erecoveredCheck_lam1, 1, 2, (V[]){v_k_241, v_hd_240})});
}
V g_heff_2etoplevel_2erecoveredCheck_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2erecoveredCheck(a[0], a[1]);
}
V g_heff_2etoplevel_2erecoveredCheck_lam0(V self, V *args) {
  V v_c_242 = args[0];
  return heff_get(v_c_242, LBL_recovered);
}
V g_heff_2etoplevel_2erecoveredCheck_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = ({ V a_0 = MK_INT(0LL); V a_1 = v_x_246; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_x_246); r_; });
  V v_t_248 = heff_intEq(v_t_247, MK_INT(0LL));
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_249 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2erecoveredCheck_str0), heff_dup(g_heff_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2411}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2412, v_k_241});
  }
  default: return heff_nomatch(v_t_248);
  }
}
Clo g_heff_2etoplevel_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eanyL_entry, 2, 0};

V g_heff_2etoplevel_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2etoplevel_2eanyL_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eanyL(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2etoplevel_2epoisonedLeft_str0 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 97, 110, 32, 101, 114, 114, 111, 114, 32, 107, 101, 112, 116, 32, 102, 114, 111, 109, 32, 98, 101, 105, 110, 103, 32, 105, 110, 102, 101, 114, 114, 101, 100}};
V g_heff_2etoplevel_2epoisonedLeft_lam0(V self, V *args); static Clo g_heff_2etoplevel_2epoisonedLeft_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2epoisonedLeft_lam0, 1, 0};
V g_heff_2etoplevel_2epoisonedLeft_lam2(V self, V *args); static Clo g_heff_2etoplevel_2epoisonedLeft_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2epoisonedLeft_lam2, 1, 0};
V g_heff_2etoplevel_2epoisonedLeft_lam4(V self, V *args);
V g_heff_2etoplevel_2epoisonedLeft_lam3(V self, V *args);
V g_heff_2etoplevel_2epoisonedLeft_lam1(V self, V *args);
Clo g_heff_2etoplevel_2epoisonedLeft_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2epoisonedLeft_entry, 2, 0};

V g_heff_2etoplevel_2epoisonedLeft(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2etoplevel_2epoisonedLeft_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2etoplevel_2epoisonedLeft_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2etoplevel_2epoisonedLeft_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2epoisonedLeft(a[0], a[1]);
}
V g_heff_2etoplevel_2epoisonedLeft_lam0(V self, V *args) {
  V v_c_242 = args[0];
  return heff_get(v_c_242, LBL_poisoned);
}
V g_heff_2etoplevel_2epoisonedLeft_lam2(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get(v_c_247, LBL_metas);
}
V g_heff_2etoplevel_2epoisonedLeft_lam4(V self, V *args) {
  V v_m_2414 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = ({ V a_0 = v_m_2414; V a_1 = v_x_2411; V r_ = (g_map_2elookup_24s12(a_0, a_1)); heff_drop(v_x_2411); r_; });
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_me_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    V v_t_2417 = heff_get(v_me_2416, LBL_sol);
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nothing: {
      return NTAG(TAG_True);
    }
    case TAG_Just: {
      heff_take_n(v_t_2417, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2etoplevel_2epoisonedLeft_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = ({ V a_0 = v_x_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_x_246); r_; });
  V v_t_2413 = (g_prelude_2emap_24s5(v_t_2412));
  V v_t_2419 = ({ V a_0 = heff_clo(g_heff_2etoplevel_2epoisonedLeft_lam4, 1, 1, (V[]){v_x_2411}); V a_1 = v_t_2413; V r_ = (g_heff_2etoplevel_2eanyL(a_0, a_1)); heff_drop(v_t_2413); r_; });
  switch (heff_tag_of(v_t_2419)) {
  case TAG_True: {
    V v_t_2420 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2epoisonedLeft_str0), heff_dup(g_heff_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2422}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2423, v_k_241});
  }
  case TAG_False: {
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2etoplevel_2epoisonedLeft_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2etoplevel_2epoisonedLeft_lam2_clo)})});
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_249}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2etoplevel_2epoisonedLeft_lam3, 1, 3, (V[]){v_x_246, v_hd_240, v_k_241})});
}
Clo g_heff_2etoplevel_2eappendM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eappendM_entry, 2, 0};

V g_heff_2etoplevel_2eappendM(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2etoplevel_2eappendM(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2etoplevel_2eappendM_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2eappendM(a[0], a[1]);
}
Clo g_heff_2etoplevel_2econcatMapM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2econcatMapM_entry, 2, 0};

V g_heff_2etoplevel_2econcatMapM(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2etoplevel_2econcatMapM(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2etoplevel_2eappendM(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2etoplevel_2econcatMapM_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2econcatMapM(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2etoplevel_2espineVals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2espineVals_entry, 1, 0};

V g_heff_2etoplevel_2espineVals(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_241 = heff_field(v_x1_240, 0);
    V v_e_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2etoplevel_2espineVals(v_sp_241));
    V v_t_244 = heff_tag_at(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_e_242, NTAG(TAG_Nil)});
    return (g_heff_2etoplevel_2eappendM(v_t_243, v_t_244));
  }
  case TAG_SpProj: {
    V v_sp_245 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    V t_0 = v_sp_245;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SpSpec: {
    V v_sp_247 = heff_field(v_x1_240, 0);
    V v_e_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 5ULL, 3);
    V v_t_2410 = (g_heff_2etoplevel_2espineVals(v_sp_247));
    V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_e_249, NTAG(TAG_Nil)});
    return (g_heff_2etoplevel_2eappendM(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2etoplevel_2espineVals_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2espineVals(a[0]);
}
V g_heff_2etoplevel_2emetasInV_lam0(V self, V *args);
Clo g_heff_2etoplevel_2emetasInV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2emetasInV_entry, 2, 0};

V g_heff_2etoplevel_2emetasInV(V v_mc_240, V v_v_241) {
top: ;
  V v_t_242 = (g_heff_2evalue_2eforceEl(v_mc_240, v_v_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_VNeu: {
    V v_h_243 = heff_field(v_t_242, 0);
    V v_sp_244 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 5);
    V v_t_2411;
    switch (heff_tag_of(v_h_243)) {
    case TAG_HLocal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HMeta: {
      V v_m_2410 = heff_field(v_h_243, 0);
      heff_take_n(v_h_243, 1ULL, 1);
      v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_m_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_HError: {
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_h_243);
    }
    V v_t_2412 = (g_heff_2etoplevel_2espineVals(v_sp_244));
    V v_t_2414 = ({ V a_0 = heff_clo(g_heff_2etoplevel_2emetasInV_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}); V a_1 = v_t_2412; V r_ = (g_heff_2etoplevel_2econcatMapM(a_0, a_1)); heff_drop(v_t_2412); r_; });
    HEFF_LAST return g_heff_2etoplevel_2eappendM(v_t_2411, v_t_2414);
  }
  case TAG_VCode: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VLam: {
    heff_take_n(v_t_242, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_VCons: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VOpaque: {
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2etoplevel_2emetasInV_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2emetasInV(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2emetasInV_lam0(V self, V *args) {
  V v_v2_2413 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_mc_240; V a_1 = v_v2_2413; V r_ = (g_heff_2etoplevel_2emetasInV(a_0, a_1)); heff_drop(v_mc_240); r_; });
}
V g_heff_2etoplevel_2enubInt_lam0(V self, V *args);
Clo g_heff_2etoplevel_2enubInt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2enubInt_entry, 1, 0};

V g_heff_2etoplevel_2enubInt(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2etoplevel_2enubInt_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2etoplevel_2enubInt(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2etoplevel_2enubInt_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2enubInt(a[0]);
}
V g_heff_2etoplevel_2enubInt_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_intEq(v_y_243, v_x_241);
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2etoplevel_2eshownV_lam0(V self, V *args);
Clo g_heff_2etoplevel_2eshownV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eshownV_entry, 4, 0};

V g_heff_2etoplevel_2eshownV(V v_g_240, V v_mc_241, V v_cs_242, V v_v_243) {
top: ;
  V v_t_244 = (g_heff_2evalue_2eforceEl(v_mc_241, v_v_243));
  V v_e_245 = (g_heff_2ereadback_2ereadbTermF_24s178(heff_get(heff_dup(v_cs_242), LBL_len), v_t_244));
  V v_t_2411 = (g_heff_2erename_2erkOf(heff_clo(g_heff_2etoplevel_2eshownV_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2412 = heff_tr(heff_apply(heff_get(v_t_2411, LBL_el), 1, (V[]){v_e_245}));
  return (g_heff_2epsurface_2eelF_24s91_24s305(MK_INT(0LL), heff_get(v_cs_242, LBL_names), v_e_2412));
}
V g_heff_2etoplevel_2eshownV_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eshownV(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2etoplevel_2eshownV_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_247 = (g_heff_2erename_2edescribeKey(heff_dup(v_x_246)));
  V v_t_248 = ({ V b_0 = heff_get(v_g_240, LBL_aliases); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_249 = ({ V a_0 = v_t_248; V a_1 = v_x_246; V r_ = (g_heff_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_248); r_; });
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nothing: {
    return v_d_247;
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    heff_take_n(v_x2_249, 1ULL, 1);
    heff_drop(v_d_247);
    return v_x_2410;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[50]; } g_heff_2etoplevel_2estuckWith_str0 = {{0x80000000u, K_STR, 0}, 50, 50, {116, 104, 101, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 115, 32, 102, 111, 117, 110, 100, 32, 100, 111, 32, 110, 111, 116, 32, 102, 105, 116, 32, 116, 111, 103, 101, 116, 104, 101, 114, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2etoplevel_2estuckWith_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 97, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2etoplevel_2estuckWith_str2 = {{0x80000000u, K_STR, 0}, 14, 14, {32, 97, 114, 101, 32, 110, 111, 116, 32, 101, 113, 117, 97, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2etoplevel_2estuckWith_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {102, 111, 117, 110, 100, 32, 102, 111, 114, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2etoplevel_2estuckWith_str4 = {{0x80000000u, K_STR, 0}, 17, 17, {96, 44, 32, 105, 116, 32, 119, 111, 117, 108, 100, 32, 110, 101, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2etoplevel_2estuckWith_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[35]; } g_heff_2etoplevel_2estuckWith_str6 = {{0x80000000u, K_STR, 0}, 35, 35, {99, 97, 110, 110, 111, 116, 32, 105, 110, 102, 101, 114, 32, 97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2etoplevel_2estuckWith_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2etoplevel_2estuckWith_str8 = {{0x80000000u, K_STR, 0}, 24, 24, {32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 105, 116, 32, 105, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2etoplevel_2estuckWith_str9 = {{0x80000000u, K_STR, 0}, 36, 36, {99, 97, 110, 110, 111, 116, 32, 105, 110, 102, 101, 114, 32, 116, 104, 101, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2etoplevel_2estuckWith_str10 = {{0x80000000u, K_STR, 0}, 14, 14, {96, 58, 32, 103, 105, 118, 101, 32, 105, 116, 44, 32, 96, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2etoplevel_2estuckWith_str11 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 58, 61, 32, 46, 46, 46, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2etoplevel_2estuckWith_str12 = {{0x80000000u, K_STR, 0}, 21, 21, {119, 104, 97, 116, 32, 105, 115, 32, 107, 110, 111, 119, 110, 32, 111, 102, 32, 105, 116, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2etoplevel_2estuckWith_str13 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2etoplevel_2estuckWith_str14 = {{0x80000000u, K_STR, 0}, 25, 25, {44, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 105, 116, 32, 105, 115}};
Clo g_heff_2etoplevel_2estuckWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2estuckWith_entry, 5, 0};

V g_heff_2etoplevel_2estuckWith(V v_fallback_240, V v_p_241, V v_about_242, V v_left_243, V v_right_244) {
top: ;
  V v_t_245 = heff_get(v_p_241, LBL_failed);
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    V v_t_246 = heff_strAppend(((V)&g_heff_2etoplevel_2estuckWith_str0), heff_strAppend(heff_dup(v_left_243), heff_strAppend(((V)&g_heff_2etoplevel_2estuckWith_str1), heff_strAppend(heff_dup(v_right_244), ((V)&g_heff_2etoplevel_2estuckWith_str2)))));
    V v_t_248;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      v_t_248 = v_fallback_240;
      break;
    }
    case TAG_Just: {
      V v_me_247 = heff_dup(heff_field(v_about_242, 0));
      heff_drop(v_fallback_240);
      v_t_248 = heff_get(v_me_247, LBL_span);
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    V v_t_2411;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      heff_drop(v_left_243);
      heff_drop(v_right_244);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_me_249 = heff_field(v_about_242, 0);
      V v_ru_24about_242_24Just = heff_take_reuse_n(v_about_242, 1ULL, 1);
      V v_t_2410 = heff_strAppend(((V)&g_heff_2etoplevel_2estuckWith_str3), heff_strAppend(heff_get(v_me_249, LBL_name), heff_strAppend(((V)&g_heff_2etoplevel_2estuckWith_str4), heff_strAppend(v_left_243, heff_strAppend(((V)&g_heff_2etoplevel_2estuckWith_str5), v_right_244)))));
      v_t_2411 = heff_tag_at(v_ru_24about_242_24Just, TAG_Just, 1, (V[]){v_t_2410});
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    return heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_246, v_t_248, v_t_2411});
  }
  case TAG_False: {
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      V v_t_2412 = heff_strAppend(((V)&g_heff_2etoplevel_2estuckWith_str6), heff_strAppend(v_left_243, heff_strAppend(((V)&g_heff_2etoplevel_2estuckWith_str7), heff_strAppend(v_right_244, ((V)&g_heff_2etoplevel_2estuckWith_str8)))));
      return heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(327LL), NTAG(TAG_SError), v_t_2412, v_fallback_240, NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      V v_me_2413 = heff_field(v_about_242, 0);
      heff_take_n(v_about_242, 1ULL, 1);
      heff_drop(v_fallback_240);
      V v_t_2414 = heff_strAppend(((V)&g_heff_2etoplevel_2estuckWith_str9), heff_strAppend(heff_get(heff_dup(v_me_2413), LBL_name), heff_strAppend(((V)&g_heff_2etoplevel_2estuckWith_str10), heff_strAppend(heff_get(heff_dup(v_me_2413), LBL_name), ((V)&g_heff_2etoplevel_2estuckWith_str11)))));
      V v_t_2415 = heff_strAppend(((V)&g_heff_2etoplevel_2estuckWith_str12), heff_strAppend(v_left_243, heff_strAppend(((V)&g_heff_2etoplevel_2estuckWith_str13), heff_strAppend(v_right_244, ((V)&g_heff_2etoplevel_2estuckWith_str14)))));
      return heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(327LL), NTAG(TAG_SError), v_t_2414, heff_get(v_me_2413, LBL_span), heff_tag(TAG_Just, 1, (V[]){v_t_2415})});
    }
    default: return heff_nomatch(v_about_242);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2etoplevel_2estuckWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2estuckWith(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2etoplevel_2estuckAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2estuckAt_entry, 4, 0};

V g_heff_2etoplevel_2estuckAt(V v_g_240, V v_fallback_241, V v_p_242, V v_mc_243) {
top: ;
  V v_t_244 = (g_heff_2etoplevel_2emetasInV(v_mc_243, heff_get(heff_dup(v_p_242), LBL_left)));
  V v_t_245 = (g_heff_2etoplevel_2emetasInV(v_mc_243, heff_get(heff_dup(v_p_242), LBL_right)));
  V v_t_246 = (g_heff_2etoplevel_2eappendM(v_t_244, v_t_245));
  V v_x1_247 = (g_heff_2etoplevel_2enubInt(v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    v_t_2410 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 2);
    v_t_2410 = (g_map_2elookup_24s12(v_x_248, v_mc_243));
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  V v_t_2411 = (g_heff_2etoplevel_2eshownV(heff_dup(v_g_240), v_mc_243, heff_get(heff_dup(v_p_242), LBL_shape), heff_get(heff_dup(v_p_242), LBL_left)));
  V v_t_2412 = (g_heff_2etoplevel_2eshownV(v_g_240, v_mc_243, heff_get(heff_dup(v_p_242), LBL_shape), heff_get(heff_dup(v_p_242), LBL_right)));
  return (g_heff_2etoplevel_2estuckWith(v_fallback_241, v_p_242, v_t_2410, v_t_2411, v_t_2412));
}
V g_heff_2etoplevel_2estuckAt_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2estuckAt(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2etoplevel_2eentryFor_lam0(V self, V *args);
Clo g_heff_2etoplevel_2eentryFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eentryFor_entry, 5, 0};

V g_heff_2etoplevel_2eentryFor(V v_g_240, V v_k_241, V v_prim_242, V v_tyStx_243, V v_bodyStx_244) {
top: ;
  V v_t_2410;
  switch (heff_tag_of(v_prim_242)) {
  case TAG_True: {
    v_t_2410 = (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HGlobal, 1, (V[]){v_k_241}), NTAG(TAG_SpId), heff_clo(g_heff_2etoplevel_2eentryFor_lam0, 1, 2, (V[]){heff_dup(v_g_240), heff_dup(v_tyStx_243)}), NTAG(TAG_Nothing)));
    break;
  }
  case TAG_False: {
    v_t_2410 = (g_heff_2etop_2evalueOf(heff_dup(v_g_240), v_k_241, heff_dup(v_tyStx_243), heff_dup(v_bodyStx_244)));
    break;
  }
  default: heff_nomatch(v_prim_242);
  }
  V v_x1_2411 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return heff_rec(4, shape_329_352_367_355, (V[]){v_bodyStx_244, v_tyStx_243, v_t_2410, v_t_2415});
}
V g_heff_2etoplevel_2eentryFor_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eentryFor(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2etoplevel_2eentryFor_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_tyStx_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_245);
  V v_x1_246 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_tyStx_243, NTAG(TAG_LNil)));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Nom: {
    V v_x_247 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 1);
    return v_x_247;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_246, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_249 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 1);
    return v_x_249;
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2etoplevel_2eerrEntry_lam0(V self, V *args);
Clo g_heff_2etoplevel_2eerrEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eerrEntry_entry, 3, 0};

V g_heff_2etoplevel_2eerrEntry(V v_g_240, V v_k_241, V v_tyStx_242) {
top: ;
  V v_x1_243 = (g_heff_2eeval_2eevalTypeF_24s15(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_tyStx_242), NTAG(TAG_LNil)));
  V v_a_247;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nom: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 1);
    v_a_247 = v_x_244;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_243, 0ULL, 1);
    v_a_247 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_246 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 1);
    v_a_247 = v_x_246;
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_249 = (g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2etoplevel_2eerrEntry_lam0, 1, 1, (V[]){v_a_247}), NTAG(TAG_Nothing)));
  V v_x1_2410 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_242), NTAG(TAG_LNil)));
  V v_t_2414;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2410, 0ULL, 1);
    v_t_2414 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  return heff_rec(4, shape_329_352_367_355, (V[]){NTAG(TAG_SAbandon), v_tyStx_242, v_t_249, v_t_2414});
}
V g_heff_2etoplevel_2eerrEntry_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eerrEntry(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2etoplevel_2eerrEntry_lam0(V self, V *args) {
  V v_u_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return v_a_247;
}
V g_heff_2etoplevel_2echeckStuck_lam0(V self, V *args); static Clo g_heff_2etoplevel_2echeckStuck_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2echeckStuck_lam0, 1, 0};
V g_heff_2etoplevel_2echeckStuck_lam1(V self, V *args);
Clo g_heff_2etoplevel_2echeckStuck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2echeckStuck_entry, 5, 0};

V g_heff_2etoplevel_2echeckStuck(V v_g_240, V v_sp_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_sp_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2etoplevel_2echeckStuck_lam0_clo)})});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2etoplevel_2echeckStuck_lam1, 1, 5, (V[]){v_g_240, v_sp_241, heff_dup(v_p_245), v_p_243, v_p_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2etoplevel_2echeckStuck_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2echeckStuck(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2etoplevel_2echeckStuck_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get(v_c_247, LBL_metas);
}
V g_heff_2etoplevel_2echeckStuck_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2412 = ({ V a_0 = v_g_240; V a_1 = v_sp_241; V a_2 = v_p_245; V a_3 = v_x_2411; V r_ = (g_heff_2etoplevel_2estuckAt(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_x_2412})});
  V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get(v_p_243, LBL_bind), 2, (V[]){v_t_2415, v_p_244});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2etoplevel_2echeckUnsolved_str0 = {{0x80000000u, K_STR, 0}, 36, 36, {99, 97, 110, 110, 111, 116, 32, 105, 110, 102, 101, 114, 32, 116, 104, 101, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2etoplevel_2echeckUnsolved_str1 = {{0x80000000u, K_STR, 0}, 21, 21, {96, 59, 32, 103, 105, 118, 101, 32, 105, 116, 32, 97, 115, 32, 96, 123, 46, 46, 46, 125, 96}};
Clo g_heff_2etoplevel_2echeckUnsolved_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2echeckUnsolved_entry, 3, 0};

V g_heff_2etoplevel_2echeckUnsolved(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_u_243 = heff_field(v_x1_240, 0);
    V v_t_245 = heff_strAppend(((V)&g_heff_2etoplevel_2echeckUnsolved_str0), heff_strAppend(heff_get(heff_dup(v_u_243), LBL_name), ((V)&g_heff_2etoplevel_2echeckUnsolved_str1)));
    V v_t_246 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(328LL), NTAG(TAG_SError), v_t_245, heff_get(heff_dup(v_u_243), LBL_span), NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_248}));
    return heff_tail(heff_get(v_p_241, LBL_bind), 2, (V[]){v_t_249, v_p_242});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2etoplevel_2echeckUnsolved_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2echeckUnsolved(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2ebodyEnv_lam0(V self, V *args);
V g_heff_2etoplevel_2ebodyEnv_lam1(V self, V *args);
Clo g_heff_2etoplevel_2ebodyEnv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ebodyEnv_entry, 4, 0};

V g_heff_2etoplevel_2ebodyEnv(V v_gSelf_240, V v_k_241, V v_name_242, V v_aval_243) {
top: ;
  V v_v_245 = (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HGlobal, 1, (V[]){heff_dup(v_k_241)}), NTAG(TAG_SpId), heff_clo(g_heff_2etoplevel_2ebodyEnv_lam0, 1, 1, (V[]){heff_dup(v_aval_243)}), NTAG(TAG_Nothing)));
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_name_242, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo(g_heff_2etoplevel_2ebodyEnv_lam1, 1, 1, (V[]){v_v_245})});
  V v_t_249 = heff_tag(TAG_CBind, 3, (V[]){NTAG(TAG_CEmpty), heff_tag(TAG_BDelayedBy, 1, (V[]){MK_INT(1LL)}), v_aval_243});
  V v_sc_2410 = heff_rec(4, shape_168_200_179_53, (V[]){MK_INT(1LL), v_t_246, v_t_248, v_t_249});
  V v_t_2411 = heff_tag(TAG_ForDescriptive, 2, (V[]){heff_tag(TAG_HGlobal, 1, (V[]){heff_dup(v_k_241)}), NTAG(TAG_SpId)});
  return heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_sc_2410, v_gSelf_240, v_t_2411, MK_INT(0LL), heff_tag(TAG_Just, 1, (V[]){v_k_241}), NTAG(TAG_Nil)});
}
V g_heff_2etoplevel_2ebodyEnv_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2ebodyEnv(a[0], a[1], a[2], a[3]);
}
V g_heff_2etoplevel_2ebodyEnv_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_aval_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_aval_243;
}
V g_heff_2etoplevel_2ebodyEnv_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_v_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_v_245;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2etoplevel_2ebodyPhase_str0 = {{0x80000000u, K_STR, 0}, 36, 36, {99, 97, 110, 110, 111, 116, 32, 105, 110, 102, 101, 114, 32, 116, 104, 101, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2etoplevel_2ebodyPhase_str1 = {{0x80000000u, K_STR, 0}, 21, 21, {96, 59, 32, 103, 105, 118, 101, 32, 105, 116, 32, 97, 115, 32, 96, 123, 46, 46, 46, 125, 96}};
V g_heff_2etoplevel_2ebodyPhase_lam7(V self, V *args);
V g_heff_2etoplevel_2ebodyPhase_lam6(V self, V *args);
V g_heff_2etoplevel_2ebodyPhase_lam5(V self, V *args);
V g_heff_2etoplevel_2ebodyPhase_lam4(V self, V *args);
V g_heff_2etoplevel_2ebodyPhase_lam3(V self, V *args);
V g_heff_2etoplevel_2ebodyPhase_lam2(V self, V *args);
V g_heff_2etoplevel_2ebodyPhase_lam1(V self, V *args);
V g_heff_2etoplevel_2ebodyPhase_lam0(V self, V *args);
Clo g_heff_2etoplevel_2ebodyPhase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ebodyPhase_entry, 5, 0};

V g_heff_2etoplevel_2ebodyPhase(V v_dsp_240, V v_d_241, V v_gSelf_242, V v_k_243, V v_aval_244) {
top: ;
  V v_e_245 = (g_heff_2etoplevel_2ebodyEnv(heff_dup(v_gSelf_242), v_k_243, heff_get(heff_dup(v_d_241), LBL_name), heff_dup(v_aval_244)));
  V v_t_246 = heff_get(v_d_241, LBL_tm);
  V v_c_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_c_248 = heff_tr(heff_apply(v_f_247, 2, (V[]){v_e_245, v_aval_244}));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_clo(g_heff_2etoplevel_2ebodyPhase_lam0, 2, 3, (V[]){v_c_248, v_gSelf_242, v_dsp_240});
}
V g_heff_2etoplevel_2ebodyPhase_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2ebodyPhase(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2etoplevel_2ebodyPhase_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V f_ = v_k_2418;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2ebodyPhase_lam6(V self, V *args) {
  V v_unsolved_2416 = args[0];
  V v_hd_2417 = args[1];
  V v_k_2418 = args[2];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_unsolved_2416)) {
  case TAG_Nil: {
    heff_drop(v_hd_2417);
    V f_ = v_k_2418;
    args[0] = v_x_2411;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_u_2419 = heff_field(v_unsolved_2416, 0);
    heff_take_n(v_unsolved_2416, 1ULL, 2);
    V v_t_2421 = heff_strAppend(((V)&g_heff_2etoplevel_2ebodyPhase_str0), heff_strAppend(heff_get(heff_dup(v_u_2419), LBL_name), ((V)&g_heff_2etoplevel_2ebodyPhase_str1)));
    V v_t_2422 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(328LL), NTAG(TAG_SError), v_t_2421, heff_get(v_u_2419, LBL_span), NTAG(TAG_Nothing)});
    V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_2424}));
    V f_ = heff_get(v_hd_2417, LBL_bind);
    args[0] = v_t_2425;
    args[1] = heff_clo(g_heff_2etoplevel_2ebodyPhase_lam7, 1, 2, (V[]){v_k_2418, v_x_2411});
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_unsolved_2416);
  }
}
V g_heff_2etoplevel_2ebodyPhase_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2415);
  return (g_co_2ebind_24s460(heff_clo(g_heff_2etoplevel_2ebodyPhase_lam6, 3, 1, (V[]){v_x_2411}), v_hd_249, v_k_2410));
}
V g_heff_2etoplevel_2ebodyPhase_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_dsp_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2414);
  return ({ V a_0 = v_gSelf_242; V a_1 = v_dsp_240; V a_2 = v_x_2412; V a_3 = heff_dup(v_hd_249); V a_4 = heff_clo(g_heff_2etoplevel_2ebodyPhase_lam5, 1, 3, (V[]){v_x_2411, v_hd_249, v_k_2410}); V r_ = (g_heff_2etoplevel_2echeckStuck(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2412); r_; });
}
V g_heff_2etoplevel_2ebodyPhase_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2413);
  return (g_heff_2etoplevel_2epoisonedLeft(heff_dup(v_hd_249), heff_clo(g_heff_2etoplevel_2ebodyPhase_lam4, 1, 6, (V[]){v_gSelf_242, v_dsp_240, v_x_2412, v_hd_249, v_x_2411, v_k_2410})));
}
V g_heff_2etoplevel_2ebodyPhase_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2etoplevel_2erecoveredCheck(heff_dup(v_hd_249), heff_clo(g_heff_2etoplevel_2ebodyPhase_lam3, 1, 6, (V[]){v_hd_249, v_gSelf_242, v_dsp_240, v_x_2412, v_x_2411, v_k_2410})));
}
V g_heff_2etoplevel_2ebodyPhase_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2emeta_2esettleGo(heff_dup(v_gSelf_242), MK_INT(0LL), heff_dup(v_hd_249), heff_clo(g_heff_2etoplevel_2ebodyPhase_lam2, 1, 5, (V[]){v_hd_249, v_gSelf_242, v_dsp_240, v_x_2411, v_k_2410})));
}
V g_heff_2etoplevel_2ebodyPhase_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo(g_heff_2etoplevel_2ebodyPhase_lam1, 1, 4, (V[]){v_gSelf_242, v_hd_249, v_dsp_240, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eelabOut_lam0(V self, V *args);
V g_heff_2etoplevel_2eelabOut_lam1(V self, V *args);
Clo g_heff_2etoplevel_2eelabOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelabOut_entry, 6, 0};

V g_heff_2etoplevel_2eelabOut(V v_key_240, V v_g_241, V v_d_242, V v_tyStx_243, V v_mc_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Left: {
    V v_failed_246 = heff_field(v_x6_245, 0);
    heff_take_n(v_x6_245, 1ULL, 1);
    V v_t_247 = heff_get(heff_dup(v_d_242), LBL_prim);
    V v_key_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      v_key_248 = heff_get(heff_dup(v_d_242), LBL_name);
      break;
    }
    case TAG_False: {
      v_key_248 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_get(heff_dup(v_d_242), LBL_name)}));
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_249 = heff_get(heff_dup(v_d_242), LBL_prim);
    V v_t_2410;
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_key_240);
      v_t_2410 = heff_get(heff_dup(v_d_242), LBL_name);
      break;
    }
    case TAG_False: {
      v_t_2410 = heff_tr(heff_apply(v_key_240, 1, (V[]){heff_get(heff_dup(v_d_242), LBL_name)}));
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_entry_2411 = ({ V a_0 = v_g_241; V a_1 = v_t_2410; V a_2 = v_tyStx_243; V r_ = (g_heff_2etoplevel_2eerrEntry(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
    V v_x_2412 = heff_rec(5, shape_198_152_255_86_96, (V[]){heff_get(heff_dup(v_d_242), LBL_name), v_key_248, heff_get(v_d_242, LBL_prim), v_entry_2411, heff_tag(TAG_Just, 1, (V[]){v_failed_246})});
    return heff_clo(g_heff_2etoplevel_2eelabOut_lam0, 2, 1, (V[]){v_x_2412});
  }
  case TAG_Right: {
    V v_t_2415 = heff_field(v_x6_245, 0);
    heff_take_n(v_x6_245, 1ULL, 1);
    V v_t_2416 = heff_get(heff_dup(v_d_242), LBL_prim);
    V v_key_2417;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      v_key_2417 = heff_get(heff_dup(v_d_242), LBL_name);
      break;
    }
    case TAG_False: {
      v_key_2417 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_get(heff_dup(v_d_242), LBL_name)}));
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_t_2418 = heff_get(heff_dup(v_d_242), LBL_prim);
    V v_t_2419;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      v_t_2419 = heff_get(heff_dup(v_d_242), LBL_name);
      break;
    }
    case TAG_False: {
      v_t_2419 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_get(heff_dup(v_d_242), LBL_name)}));
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    V v_t_2420 = heff_get(heff_dup(v_d_242), LBL_prim);
    V v_k_2421;
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      heff_drop(v_key_240);
      v_k_2421 = heff_get(heff_dup(v_d_242), LBL_name);
      break;
    }
    case TAG_False: {
      v_k_2421 = heff_tr(heff_apply(v_key_240, 1, (V[]){heff_get(heff_dup(v_d_242), LBL_name)}));
      break;
    }
    default: heff_nomatch(v_t_2420);
    }
    V v_t_2422 = (g_heff_2eunify_2ezonker(v_mc_244));
    V v_t_2423 = heff_tr(heff_apply(heff_get(v_t_2422, LBL_el), 1, (V[]){heff_get(v_t_2415, LBL_stx)}));
    V v_t_2424 = (g_heff_2etoplevel_2eselfWalk(v_k_2421));
    V v_t_2425 = heff_tr(heff_apply(heff_get(v_t_2424, LBL_el), 2, (V[]){MK_INT(0LL), v_t_2423}));
    V v_entry_2426 = ({ V a_0 = v_g_241; V a_1 = v_t_2419; V b_2 = heff_get(heff_dup(v_d_242), LBL_prim); V a_3 = v_tyStx_243; V a_4 = v_t_2425; V r_ = (g_heff_2etoplevel_2eentryFor(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
    V v_x_2427 = heff_rec(5, shape_198_152_255_86_96, (V[]){heff_get(heff_dup(v_d_242), LBL_name), v_key_2417, heff_get(v_d_242, LBL_prim), v_entry_2426, NTAG(TAG_Nothing)});
    return heff_clo(g_heff_2etoplevel_2eelabOut_lam1, 2, 1, (V[]){v_x_2427});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2etoplevel_2eelabOut_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eelabOut(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[4]); return r;
}
V g_heff_2etoplevel_2eelabOut_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eelabOut_lam1(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_x_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}

static V g_heff_2etoplevel_2eprimNames_val;
static int g_heff_2etoplevel_2eprimNames_st;
static V g_heff_2etoplevel_2eprimNames_init(void) {
  return (g_prelude_2emap_24s5(heff_dup(g_heff_2eprims_2eprims_get())));
}
V g_heff_2etoplevel_2eprimNames_get(void) {
  if (g_heff_2etoplevel_2eprimNames_st == 2) return g_heff_2etoplevel_2eprimNames_val;
  if (g_heff_2etoplevel_2eprimNames_st == 1) heff_fail("defined by itself");
  g_heff_2etoplevel_2eprimNames_st = 1;
  g_heff_2etoplevel_2eprimNames_val = heff_tr(g_heff_2etoplevel_2eprimNames_init());
  g_heff_2etoplevel_2eprimNames_st = 2;
  return g_heff_2etoplevel_2eprimNames_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2etoplevel_2eprimKnown_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2etoplevel_2eprimKnown_str1 = {{0x80000000u, K_STR, 0}, 30, 30, {116, 104, 101, 114, 101, 32, 105, 115, 32, 110, 111, 32, 112, 114, 105, 109, 105, 116, 105, 118, 101, 32, 99, 97, 108, 108, 101, 100, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2etoplevel_2eprimKnown_str2 = {{0x80000000u, K_STR, 0}, 20, 20, {96, 32, 40, 116, 104, 101, 32, 114, 117, 110, 116, 105, 109, 101, 32, 104, 97, 115, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2etoplevel_2eprimKnown_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2etoplevel_2eprimKnown_lam0(V self, V *args);
V g_heff_2etoplevel_2eprimKnown_lam1(V self, V *args); static Clo g_heff_2etoplevel_2eprimKnown_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eprimKnown_lam1, 2, 0};
Clo g_heff_2etoplevel_2eprimKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eprimKnown_entry, 2, 0};

V g_heff_2etoplevel_2eprimKnown(V v_sp_240, V v_d_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_d_241), LBL_prim);
  V v_t_246;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_xs_243 = heff_dup(g_heff_2etoplevel_2eprimNames_get());
    V v_t_244 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_d_241), LBL_name)}));
    V v_x1_245 = ({ V a_0 = v_t_244; V a_1 = v_xs_243; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_xs_243); r_; });
    switch (heff_tag_of(v_x1_245)) {
    case TAG_True: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_246 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    break;
  }
  case TAG_False: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    V v_x2_247 = heff_dup(g_heff_2etoplevel_2eprimNames_get());
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2etoplevel_2eprimKnown_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = v_x_248; V a_1 = v_xs_249; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_msg_2411 = heff_strAppend(((V)&g_heff_2etoplevel_2eprimKnown_str1), heff_strAppend(heff_get(v_d_241, LBL_name), heff_strAppend(((V)&g_heff_2etoplevel_2eprimKnown_str2), heff_strAppend(v_t_2410, ((V)&g_heff_2etoplevel_2eprimKnown_str3)))));
    return heff_clo(g_heff_2etoplevel_2eprimKnown_lam0, 2, 2, (V[]){v_msg_2411, v_sp_240});
  }
  case TAG_False: {
    heff_drop(v_sp_240);
    heff_drop(v_d_241);
    return ((V)&g_heff_2etoplevel_2eprimKnown_lam1_clo);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2etoplevel_2eprimKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2eprimKnown(a[0], a[1]);
}
V g_heff_2etoplevel_2eprimKnown_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_msg_2411 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(329LL), NTAG(TAG_SError), v_msg_2411, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2416}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2417;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eprimKnown_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eelabBody_lam0(V self, V *args);
V g_heff_2etoplevel_2eelabBody_lam3(V self, V *args);
V g_heff_2etoplevel_2eelabBody_lam5(V self, V *args); static Clo g_heff_2etoplevel_2eelabBody_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelabBody_lam5, 1, 0};
V g_heff_2etoplevel_2eelabBody_lam9(V self, V *args); static Clo g_heff_2etoplevel_2eelabBody_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelabBody_lam9, 1, 0};
V g_heff_2etoplevel_2eelabBody_lam10(V self, V *args);
V g_heff_2etoplevel_2eelabBody_lam8(V self, V *args);
V g_heff_2etoplevel_2eelabBody_lam7(V self, V *args);
V g_heff_2etoplevel_2eelabBody_lam6(V self, V *args);
V g_heff_2etoplevel_2eelabBody_lam4(V self, V *args);
V g_heff_2etoplevel_2eelabBody_lam2(V self, V *args);
V g_heff_2etoplevel_2eelabBody_lam1(V self, V *args);
Clo g_heff_2etoplevel_2eelabBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelabBody_entry, 5, 0};

V g_heff_2etoplevel_2eelabBody(V v_key_240, V v_g_241, V v_n_242, V v_d_243, V v_a_244) {
top: ;
  V v_t_245 = heff_get(heff_dup(v_d_243), LBL_prim);
  V v_t_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_246 = heff_get(heff_dup(v_d_243), LBL_name);
    break;
  }
  case TAG_False: {
    v_t_246 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_get(heff_dup(v_d_243), LBL_name)}));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_k_247 = heff_tag(TAG_Just, 1, (V[]){v_t_246});
  V v_c_249 = heff_tr(heff_apply(((V)&g_heff_2eenvironment_2emodify_clo), 1, (V[]){heff_clo(g_heff_2etoplevel_2eelabBody_lam0, 1, 1, (V[]){v_k_247})}));
  return heff_clo(g_heff_2etoplevel_2eelabBody_lam1, 2, 6, (V[]){v_c_249, heff_dup(v_n_242), v_d_243, v_key_240, v_a_244, v_g_241});
}
V g_heff_2etoplevel_2eelabBody_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eelabBody(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2etoplevel_2eelabBody_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_248), LBL_infos), heff_get(heff_dup(v_c_248), LBL_recovered), heff_get(heff_dup(v_c_248), LBL_poisoned), heff_get(heff_dup(v_c_248), LBL_metas), heff_get(heff_dup(v_c_248), LBL_nextMeta), heff_get(heff_dup(v_c_248), LBL_postponed), heff_get(v_c_248, LBL_trace), v_k_247});
}
V g_heff_2etoplevel_2eelabBody_lam3(V self, V *args) {
  V v_u_2421 = args[0];
  V v_a_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2421);
  V v_x1_2422 = heff_tr(heff_apply(heff_get(v_a_244, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    return v_x_2423;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    return v_x_2425;
  }
  default: return heff_nomatch(v_x1_2422);
  }
}
V g_heff_2etoplevel_2eelabBody_lam5(V self, V *args) {
  V v_c_2444 = args[0];
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_2444), LBL_infos), heff_get(heff_dup(v_c_2444), LBL_recovered), heff_get(heff_dup(v_c_2444), LBL_poisoned), heff_get(heff_dup(v_c_2444), LBL_metas), heff_get(heff_dup(v_c_2444), LBL_nextMeta), heff_get(heff_dup(v_c_2444), LBL_postponed), heff_get(v_c_2444, LBL_trace), NTAG(TAG_Nothing)});
}
V g_heff_2etoplevel_2eelabBody_lam9(V self, V *args) {
  V v_c_2458 = args[0];
  return heff_get(v_c_2458, LBL_metas);
}
V g_heff_2etoplevel_2eelabBody_lam10(V self, V *args) {
  V v_x_2462 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_x_2443 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2463 = (g_heff_2eunify_2ezonker(v_x_2462));
  V v_t_2464 = heff_tr(heff_apply(heff_get(v_t_2463, LBL_ty), 1, (V[]){heff_get(v_a_244, LBL_stx)}));
  V v_t_2465 = ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_d_243; V a_3 = v_t_2464; V a_4 = v_x_2462; V a_5 = v_x_2443; V r_ = (g_heff_2etoplevel_2eelabOut(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2462); r_; });
  return heff_tail(v_t_2465, 2, (V[]){v_hd_2410, v_k_2411});
}
V g_heff_2etoplevel_2eelabBody_lam8(V self, V *args) {
  V v_x_2457 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_x_2443 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2457);
  V v_t_2459 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2etoplevel_2eelabBody_lam9_clo)})});
  V v_t_2460 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2410), LBL_malg), 1, (V[]){v_t_2460}));
  return heff_tail(heff_get(heff_dup(v_hd_2410), LBL_bind), 2, (V[]){v_t_2461, heff_clo(g_heff_2etoplevel_2eelabBody_lam10, 1, 7, (V[]){v_a_244, v_key_240, v_g_241, v_d_243, v_x_2443, v_hd_2410, v_k_2411})});
}
V g_heff_2etoplevel_2eelabBody_lam7(V self, V *args) {
  V v_x_2452 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_x_2443 = heff_env(self)[6];
  V v_k_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2452);
  V v_t_2455;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2454 = heff_field(v_n_242, 1);
    heff_take_n(v_n_242, 2ULL, 2);
    v_t_2455 = v_s_2454;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_c_2456 = (g_heff_2etoplevel_2eprimKnown(v_t_2455, heff_dup(v_d_243)));
  return heff_tail(v_c_2456, 2, (V[]){heff_dup(v_hd_2410), heff_clo(g_heff_2etoplevel_2eelabBody_lam8, 1, 7, (V[]){v_hd_2410, v_a_244, v_key_240, v_g_241, v_d_243, v_x_2443, v_k_2411})});
}
V g_heff_2etoplevel_2eelabBody_lam6(V self, V *args) {
  V v_x_2448 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_x_2443 = heff_env(self)[6];
  V v_k_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2449 = heff_tag(TAG_Put, 2, (V[]){v_x_2448, NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2410), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2450})}));
  return heff_tail(heff_get(heff_dup(v_hd_2410), LBL_bind), 2, (V[]){v_t_2451, heff_clo(g_heff_2etoplevel_2eelabBody_lam7, 1, 8, (V[]){v_n_242, v_d_243, v_hd_2410, v_a_244, v_key_240, v_g_241, v_x_2443, v_k_2411})});
}
V g_heff_2etoplevel_2eelabBody_lam4(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2445 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2etoplevel_2eelabBody_lam5_clo)})});
  V v_t_2446 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2410), LBL_malg), 1, (V[]){v_t_2446}));
  return heff_tail(heff_get(heff_dup(v_hd_2410), LBL_bind), 2, (V[]){v_t_2447, heff_clo(g_heff_2etoplevel_2eelabBody_lam6, 1, 8, (V[]){v_hd_2410, v_n_242, v_d_243, v_a_244, v_key_240, v_g_241, v_x_2443, v_k_2411})});
}
V g_heff_2etoplevel_2eelabBody_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2412);
  V v_t_2415;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2414 = heff_dup(heff_field(v_n_242, 1));
    v_t_2415 = v_s_2414;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_t_2416 = heff_get(heff_dup(v_d_243), LBL_prim);
  V v_t_2417;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    v_t_2417 = heff_get(heff_dup(v_d_243), LBL_name);
    break;
  }
  case TAG_False: {
    v_t_2417 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_get(heff_dup(v_d_243), LBL_name)}));
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_t_2418 = heff_get(heff_dup(v_d_243), LBL_prim);
  V v_t_2419;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    v_t_2419 = heff_get(heff_dup(v_d_243), LBL_name);
    break;
  }
  case TAG_False: {
    v_t_2419 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_get(heff_dup(v_d_243), LBL_name)}));
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_h_2420 = heff_tag(TAG_HGlobal, 1, (V[]){v_t_2419});
  V v_t_2426 = (g_heff_2evalue_2emkNeu_24s10(v_h_2420, NTAG(TAG_SpId), heff_clo(g_heff_2etoplevel_2eelabBody_lam3, 1, 1, (V[]){heff_dup(v_a_244)}), NTAG(TAG_Nothing)));
  V v_x1_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_a_244), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2431;
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_Nom: {
    V v_x_2428 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 1);
    v_t_2431 = v_x_2428;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2427, 0ULL, 1);
    v_t_2431 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2430 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 1);
    v_t_2431 = v_x_2430;
    break;
  }
  default: heff_nomatch(v_x1_2427);
  }
  V v_t_2432 = heff_rec(4, shape_329_352_367_355, (V[]){NTAG(TAG_SOpaque), heff_get(heff_dup(v_a_244), LBL_stx), v_t_2426, v_t_2431});
  V v_t_2433 = (g_heff_2eglobals_2eaddEntry(v_t_2417, v_t_2432, heff_dup(v_g_241)));
  V v_t_2434 = heff_get(heff_dup(v_d_243), LBL_prim);
  V v_t_2435;
  switch (heff_tag_of(v_t_2434)) {
  case TAG_True: {
    v_t_2435 = heff_get(heff_dup(v_d_243), LBL_name);
    break;
  }
  case TAG_False: {
    v_t_2435 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_get(heff_dup(v_d_243), LBL_name)}));
    break;
  }
  default: heff_nomatch(v_t_2434);
  }
  V v_x1_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_a_244), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2440;
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_Nom: {
    V v_x_2437 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    v_t_2440 = v_x_2437;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2436, 0ULL, 1);
    v_t_2440 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2439 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    v_t_2440 = v_x_2439;
    break;
  }
  default: heff_nomatch(v_x1_2436);
  }
  V v_t_2441 = (g_heff_2etoplevel_2ebodyPhase(v_t_2415, heff_dup(v_d_243), v_t_2433, v_t_2435, v_t_2440));
  V v_c_2442 = heff_tr(heff_apply(((V)&g_heff_2eenvironment_2etryE_clo), 1, (V[]){v_t_2441}));
  return heff_tail(v_c_2442, 2, (V[]){heff_dup(v_hd_2410), heff_clo(g_heff_2etoplevel_2eelabBody_lam4, 1, 7, (V[]){v_hd_2410, v_n_242, v_d_243, v_a_244, v_key_240, v_g_241, v_k_2411})});
}
V g_heff_2etoplevel_2eelabBody_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo(g_heff_2etoplevel_2eelabBody_lam2, 1, 7, (V[]){v_n_242, v_d_243, v_key_240, v_a_244, v_g_241, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2etoplevel_2ewatchSyn_str0 = {{0x80000000u, K_STR, 0}, 57, 57, {97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 45, 45, 32, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2etoplevel_2ewatchSyn_str1 = {{0x80000000u, K_STR, 0}, 57, 57, {97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 45, 45, 32, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2etoplevel_2ewatchSyn_str2 = {{0x80000000u, K_STR, 0}, 57, 57, {97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 45, 45, 32, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2etoplevel_2ewatchSyn_str3 = {{0x80000000u, K_STR, 0}, 57, 57, {97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 45, 45, 32, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2etoplevel_2ewatchSyn_str4 = {{0x80000000u, K_STR, 0}, 57, 57, {97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 45, 45, 32, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2etoplevel_2ewatchSyn_str5 = {{0x80000000u, K_STR, 0}, 57, 57, {97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 45, 45, 32, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2etoplevel_2ewatchSyn_str6 = {{0x80000000u, K_STR, 0}, 57, 57, {97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 45, 45, 32, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2etoplevel_2ewatchSyn_str7 = {{0x80000000u, K_STR, 0}, 57, 57, {97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 45, 45, 32, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2etoplevel_2ewatchSyn_str8 = {{0x80000000u, K_STR, 0}, 57, 57, {97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 45, 45, 32, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2etoplevel_2ewatchSyn_str9 = {{0x80000000u, K_STR, 0}, 57, 57, {97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 45, 45, 32, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2etoplevel_2ewatchSyn_str10 = {{0x80000000u, K_STR, 0}, 57, 57, {97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 45, 45, 32, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96}};
V g_heff_2etoplevel_2ewatchSyn_lam0(V self, V *args);
V g_heff_2etoplevel_2ewatchSyn_lam1(V self, V *args);
V g_heff_2etoplevel_2ewatchSyn_lam2(V self, V *args);
V g_heff_2etoplevel_2ewatchSyn_lam3(V self, V *args);
V g_heff_2etoplevel_2ewatchSyn_lam4(V self, V *args);
V g_heff_2etoplevel_2ewatchSyn_lam5(V self, V *args);
V g_heff_2etoplevel_2ewatchSyn_lam6(V self, V *args);
V g_heff_2etoplevel_2ewatchSyn_lam7(V self, V *args);
V g_heff_2etoplevel_2ewatchSyn_lam8(V self, V *args);
V g_heff_2etoplevel_2ewatchSyn_lam9(V self, V *args);
V g_heff_2etoplevel_2ewatchSyn_lam10(V self, V *args);
Clo g_heff_2etoplevel_2ewatchSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ewatchSyn_entry, 1, 0};

V g_heff_2etoplevel_2ewatchSyn(V v_w_240) {
top: ;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_w1_241 = heff_field(v_w_240, 0);
    switch (heff_tag_of(v_w1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_w1_241, 0);
      HEFF_LAST return g_heff_2etoplevel_2einfF_24s444(heff_dup(v_i_243));
    }
    case TAG_CType: {
      V v_sp_247;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_246 = heff_field(v_w_240, 1);
        v_sp_247 = heff_dup(v_s_246);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo(g_heff_2etoplevel_2ewatchSyn_lam0, 2, 1, (V[]){v_sp_247});
    }
    case TAG_CLam: {
      V v_sp_2419;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2418 = heff_field(v_w_240, 1);
        v_sp_2419 = heff_dup(v_s_2418);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo(g_heff_2etoplevel_2ewatchSyn_lam1, 2, 1, (V[]){v_sp_2419});
    }
    case TAG_CImplicitLam: {
      V v_sp_2431;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2430 = heff_field(v_w_240, 1);
        v_sp_2431 = heff_dup(v_s_2430);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo(g_heff_2etoplevel_2ewatchSyn_lam2, 2, 1, (V[]){v_sp_2431});
    }
    case TAG_CAnnLam: {
      V v_sp_2444;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2443 = heff_field(v_w_240, 1);
        v_sp_2444 = heff_dup(v_s_2443);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo(g_heff_2etoplevel_2ewatchSyn_lam3, 2, 1, (V[]){v_sp_2444});
    }
    case TAG_CTag: {
      V v_sp_2456;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2455 = heff_field(v_w_240, 1);
        v_sp_2456 = heff_dup(v_s_2455);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo(g_heff_2etoplevel_2ewatchSyn_lam4, 2, 1, (V[]){v_sp_2456});
    }
    case TAG_CStruct: {
      V v_sp_2466;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2465 = heff_field(v_w_240, 1);
        v_sp_2466 = heff_dup(v_s_2465);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo(g_heff_2etoplevel_2ewatchSyn_lam5, 2, 1, (V[]){v_sp_2466});
    }
    case TAG_CMatch: {
      V v_sp_2477;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2476 = heff_field(v_w_240, 1);
        v_sp_2477 = heff_dup(v_s_2476);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo(g_heff_2etoplevel_2ewatchSyn_lam6, 2, 1, (V[]){v_sp_2477});
    }
    case TAG_CLetIn: {
      V v_sp_2488;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2487 = heff_field(v_w_240, 1);
        v_sp_2488 = heff_dup(v_s_2487);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo(g_heff_2etoplevel_2ewatchSyn_lam7, 2, 1, (V[]){v_sp_2488});
    }
    case TAG_CLocal: {
      V v_sp_2499;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2498 = heff_field(v_w_240, 1);
        v_sp_2499 = heff_dup(v_s_2498);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo(g_heff_2etoplevel_2ewatchSyn_lam8, 2, 1, (V[]){v_sp_2499});
    }
    case TAG_CAbandon: {
      V v_sp_24108;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_24107 = heff_field(v_w_240, 1);
        v_sp_24108 = heff_dup(v_s_24107);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo(g_heff_2etoplevel_2ewatchSyn_lam9, 2, 1, (V[]){v_sp_24108});
    }
    case TAG_CNominal: {
      V v_sp_24118;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_24117 = heff_field(v_w_240, 1);
        v_sp_24118 = heff_dup(v_s_24117);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo(g_heff_2etoplevel_2ewatchSyn_lam10, 2, 1, (V[]){v_sp_24118});
    }
    default: return heff_nomatch(v_w1_241);
    }
  }
  default: return heff_nomatch(v_w_240);
  }
}
V g_heff_2etoplevel_2ewatchSyn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2ewatchSyn(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2etoplevel_2ewatchSyn_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k2_249 = args[1];
  V v_sp_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2ewatchSyn_str0), v_sp_247, NTAG(TAG_Nothing)});
  V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2412}));
  V f_ = heff_get(v_hd_248, LBL_bind);
  args[0] = v_t_2413;
  args[1] = v_k2_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2ewatchSyn_lam1(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k2_2421 = args[1];
  V v_sp_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2ewatchSyn_str1), v_sp_2419, NTAG(TAG_Nothing)});
  V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2420), LBL_malg), 1, (V[]){v_t_2424}));
  V f_ = heff_get(v_hd_2420, LBL_bind);
  args[0] = v_t_2425;
  args[1] = v_k2_2421;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2ewatchSyn_lam2(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_sp_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2ewatchSyn_str2), v_sp_2431, NTAG(TAG_Nothing)});
  V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2432), LBL_malg), 1, (V[]){v_t_2436}));
  V f_ = heff_get(v_hd_2432, LBL_bind);
  args[0] = v_t_2437;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2ewatchSyn_lam3(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k2_2446 = args[1];
  V v_sp_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2ewatchSyn_str3), v_sp_2444, NTAG(TAG_Nothing)});
  V v_t_2448 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2445), LBL_malg), 1, (V[]){v_t_2449}));
  V f_ = heff_get(v_hd_2445, LBL_bind);
  args[0] = v_t_2450;
  args[1] = v_k2_2446;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2ewatchSyn_lam4(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k2_2458 = args[1];
  V v_sp_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2ewatchSyn_str4), v_sp_2456, NTAG(TAG_Nothing)});
  V v_t_2460 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2457), LBL_malg), 1, (V[]){v_t_2461}));
  V f_ = heff_get(v_hd_2457, LBL_bind);
  args[0] = v_t_2462;
  args[1] = v_k2_2458;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2ewatchSyn_lam5(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k2_2468 = args[1];
  V v_sp_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2ewatchSyn_str5), v_sp_2466, NTAG(TAG_Nothing)});
  V v_t_2470 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2467), LBL_malg), 1, (V[]){v_t_2471}));
  V f_ = heff_get(v_hd_2467, LBL_bind);
  args[0] = v_t_2472;
  args[1] = v_k2_2468;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2ewatchSyn_lam6(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k2_2479 = args[1];
  V v_sp_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2480 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2ewatchSyn_str6), v_sp_2477, NTAG(TAG_Nothing)});
  V v_t_2481 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2478), LBL_malg), 1, (V[]){v_t_2482}));
  V f_ = heff_get(v_hd_2478, LBL_bind);
  args[0] = v_t_2483;
  args[1] = v_k2_2479;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2ewatchSyn_lam7(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k2_2490 = args[1];
  V v_sp_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2491 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2ewatchSyn_str7), v_sp_2488, NTAG(TAG_Nothing)});
  V v_t_2492 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2489), LBL_malg), 1, (V[]){v_t_2493}));
  V f_ = heff_get(v_hd_2489, LBL_bind);
  args[0] = v_t_2494;
  args[1] = v_k2_2490;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2ewatchSyn_lam8(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k2_24101 = args[1];
  V v_sp_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24102 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2ewatchSyn_str8), v_sp_2499, NTAG(TAG_Nothing)});
  V v_t_24103 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24100), LBL_malg), 1, (V[]){v_t_24104}));
  V f_ = heff_get(v_hd_24100, LBL_bind);
  args[0] = v_t_24105;
  args[1] = v_k2_24101;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2ewatchSyn_lam9(V self, V *args) {
  V v_hd_24109 = args[0];
  V v_k2_24110 = args[1];
  V v_sp_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24111 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2ewatchSyn_str9), v_sp_24108, NTAG(TAG_Nothing)});
  V v_t_24112 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24112})});
  V v_t_24114 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24109), LBL_malg), 1, (V[]){v_t_24113}));
  V f_ = heff_get(v_hd_24109, LBL_bind);
  args[0] = v_t_24114;
  args[1] = v_k2_24110;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2ewatchSyn_lam10(V self, V *args) {
  V v_hd_24119 = args[0];
  V v_k2_24120 = args[1];
  V v_sp_24118 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24121 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2ewatchSyn_str10), v_sp_24118, NTAG(TAG_Nothing)});
  V v_t_24122 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24119), LBL_malg), 1, (V[]){v_t_24123}));
  V f_ = heff_get(v_hd_24119, LBL_bind);
  args[0] = v_t_24124;
  args[1] = v_k2_24120;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2etoplevel_2ewatchEntry_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {62, 32, 119, 97, 116, 99, 104}};
Clo g_heff_2etoplevel_2ewatchEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ewatchEntry_entry, 4, 0};

V g_heff_2etoplevel_2ewatchEntry(V v_g_240, V v_mc_241, V v_t_242, V v_ty_243) {
top: ;
  V v_t_244 = (g_heff_2evalue_2eforceTy(v_mc_241, v_ty_243));
  V v_t_245 = (g_heff_2ereadback_2ereadbTypeF_24s182(MK_INT(0LL), v_t_244));
  V v_t_246 = (g_heff_2eunify_2ezonker(v_mc_241));
  V v_tyStx_247 = heff_tr(heff_apply(heff_get(v_t_246, LBL_ty), 1, (V[]){v_t_245}));
  V v_t_248 = (g_heff_2eunify_2ezonker(v_mc_241));
  V v_bodyStx_249 = heff_tr(heff_apply(heff_get(v_t_248, LBL_el), 1, (V[]){heff_get(v_t_242, LBL_stx)}));
  V v_t_2410 = (g_heff_2etop_2evalueOf(heff_dup(v_g_240), ((V)&g_heff_2etoplevel_2ewatchEntry_str0), heff_dup(v_tyStx_247), heff_dup(v_bodyStx_249)));
  V v_x1_2411 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_247), NTAG(TAG_LNil)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return heff_rec(4, shape_329_352_367_355, (V[]){v_bodyStx_249, v_tyStx_247, v_t_2410, v_t_2415});
}
V g_heff_2etoplevel_2ewatchEntry_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2ewatchEntry(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2etoplevel_2ewatchPhase_lam6(V self, V *args); static Clo g_heff_2etoplevel_2ewatchPhase_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ewatchPhase_lam6, 1, 0};
V g_heff_2etoplevel_2ewatchPhase_lam7(V self, V *args);
V g_heff_2etoplevel_2ewatchPhase_lam5(V self, V *args);
V g_heff_2etoplevel_2ewatchPhase_lam4(V self, V *args);
V g_heff_2etoplevel_2ewatchPhase_lam3(V self, V *args);
V g_heff_2etoplevel_2ewatchPhase_lam2(V self, V *args);
V g_heff_2etoplevel_2ewatchPhase_lam1(V self, V *args);
V g_heff_2etoplevel_2ewatchPhase_lam0(V self, V *args);
Clo g_heff_2etoplevel_2ewatchPhase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ewatchPhase_entry, 5, 0};

V g_heff_2etoplevel_2ewatchPhase(V v_g_240, V v_sp_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_t_245 = heff_field(v_x3_242, 0);
    V v_ty_246 = heff_field(v_x3_242, 1);
    return (g_heff_2emeta_2esettleGo(heff_dup(v_g_240), MK_INT(0LL), heff_dup(v_p_243), heff_clo(g_heff_2etoplevel_2ewatchPhase_lam0, 1, 6, (V[]){v_p_243, v_g_240, v_sp_241, heff_dup(v_t_245), heff_dup(v_ty_246), v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2etoplevel_2ewatchPhase_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2ewatchPhase(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2etoplevel_2ewatchPhase_lam6(V self, V *args) {
  V v_c_2415 = args[0];
  return heff_get(v_c_2415, LBL_metas);
}
V g_heff_2etoplevel_2ewatchPhase_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  V v_k_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2420 = ({ V a_0 = v_g_240; V a_1 = v_x_2419; V a_2 = v_t_245; V a_3 = v_ty_246; V r_ = (g_heff_2etoplevel_2ewatchEntry(a_0, a_1, a_2, a_3)); heff_drop(v_x_2419); r_; });
  V f_ = v_k_2413;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2ewatchPhase_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_t_245 = heff_env(self)[2];
  V v_ty_246 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2etoplevel_2ewatchPhase_lam6_clo)})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(v_hd_2412, LBL_bind), 2, (V[]){v_t_2418, heff_clo(g_heff_2etoplevel_2ewatchPhase_lam7, 1, 4, (V[]){v_g_240, v_t_245, v_ty_246, v_k_2413})});
}
V g_heff_2etoplevel_2ewatchPhase_lam4(V self, V *args) {
  V v_unsolved_2411 = args[0];
  V v_hd_2412 = args[1];
  V v_k_2413 = args[2];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_unsolved_2411; V a_1 = heff_dup(v_hd_2412); V a_2 = heff_clo(g_heff_2etoplevel_2ewatchPhase_lam5, 1, 5, (V[]){v_hd_2412, v_g_240, v_t_245, v_ty_246, v_k_2413}); V r_ = (g_heff_2etoplevel_2echeckUnsolved(a_0, a_1, a_2)); heff_drop(v_unsolved_2411); r_; });
}
V g_heff_2etoplevel_2ewatchPhase_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  return (g_co_2ebind_24s460(heff_clo(g_heff_2etoplevel_2ewatchPhase_lam4, 3, 3, (V[]){v_g_240, v_t_245, v_ty_246}), v_p_243, v_p_244));
}
V g_heff_2etoplevel_2ewatchPhase_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_t_245 = heff_env(self)[4];
  V v_ty_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_249);
  return ({ V a_0 = heff_dup(v_g_240); V a_1 = v_sp_241; V a_2 = v_x_247; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo(g_heff_2etoplevel_2ewatchPhase_lam3, 1, 5, (V[]){v_g_240, v_t_245, v_ty_246, v_p_243, v_p_244}); V r_ = (g_heff_2etoplevel_2echeckStuck(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_247); r_; });
}
V g_heff_2etoplevel_2ewatchPhase_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_t_245 = heff_env(self)[4];
  V v_ty_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_248);
  return (g_heff_2etoplevel_2epoisonedLeft(heff_dup(v_p_243), heff_clo(g_heff_2etoplevel_2ewatchPhase_lam2, 1, 7, (V[]){v_g_240, v_sp_241, v_x_247, v_p_243, v_t_245, v_ty_246, v_p_244})));
}
V g_heff_2etoplevel_2ewatchPhase_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_t_245 = heff_env(self)[3];
  V v_ty_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2etoplevel_2erecoveredCheck(heff_dup(v_p_243), heff_clo(g_heff_2etoplevel_2ewatchPhase_lam1, 1, 7, (V[]){v_p_243, v_g_240, v_sp_241, v_x_247, v_t_245, v_ty_246, v_p_244})));
}
V g_heff_2etoplevel_2eelabWatch_lam2(V self, V *args);
V g_heff_2etoplevel_2eelabWatch_lam1(V self, V *args);
V g_heff_2etoplevel_2eelabWatch_lam0(V self, V *args);
Clo g_heff_2etoplevel_2eelabWatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelabWatch_entry, 2, 0};

V g_heff_2etoplevel_2eelabWatch(V v_g_240, V v_n_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    V v_t_244 = (g_heff_2epresyntax_2echkNode_24s67(v_n_242));
    v_t_245 = heff_tag(TAG_At, 2, (V[]){v_t_244, v_sp_243});
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2etoplevel_2ewatchSyn(a_0)); heff_drop(v_t_245); r_; });
  return heff_clo(g_heff_2etoplevel_2eelabWatch_lam0, 2, 3, (V[]){v_c_246, v_g_240, v_n_241});
}
V g_heff_2etoplevel_2eelabWatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2eelabWatch(a[0], a[1]);
}
V g_heff_2etoplevel_2eelabWatch_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2415 = heff_field(v_n_241, 1);
    heff_take_n(v_n_241, 2ULL, 2);
    v_t_2416 = v_s_2415;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  return ({ V a_0 = v_g_240; V a_1 = v_t_2416; V a_2 = v_x_2413; V a_3 = v_hd_247; V a_4 = v_k_248; V r_ = (g_heff_2etoplevel_2ewatchPhase(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2413); r_; });
}
V g_heff_2etoplevel_2eelabWatch_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2412;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkSyn: {
    V v_f_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2411 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){heff_dup(g_heff_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2412 = heff_tr(heff_apply(v_f_2410, 1, (V[]){v_t_2411}));
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2etoplevel_2eelabWatch_lam2, 1, 4, (V[]){v_n_241, v_g_240, v_hd_247, v_k_248})});
}
V g_heff_2etoplevel_2eelabWatch_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2etoplevel_2eelabWatch_lam1, 1, 4, (V[]){v_g_240, v_hd_247, v_n_241, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2etoplevel_2eappendT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eappendT_entry, 2, 0};

V g_heff_2etoplevel_2eappendT(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2etoplevel_2eappendT(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2etoplevel_2eappendT_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2eappendT(a[0], a[1]);
}
Clo g_heff_2etoplevel_2econcatMapT_24s461_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2econcatMapT_24s461_entry, 1, 0};

V g_heff_2etoplevel_2econcatMapT_24s461(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intEq(heff_get(heff_dup(v_x_241), LBL_code), MK_INT(-1LL));
    V v_t_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_244 = NTAG(TAG_Nil);
      break;
    }
    case TAG_False: {
      v_t_244 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_245 = (g_heff_2etoplevel_2econcatMapT_24s461(v_xs_242));
    return (g_heff_2etoplevel_2eappendT(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2etoplevel_2econcatMapT_24s461_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2econcatMapT_24s461(a[0]);
}
Clo g_heff_2etoplevel_2etopBroken_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etopBroken_entry, 4, 0};

V g_heff_2etoplevel_2etopBroken(V v_kf_240, V v_acc_241, V v_n_242, V v_diags_243) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x_244 = heff_field(v_n_242, 0);
    v_t_246 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_t_2426;
  switch (heff_tag_of(v_t_246)) {
  case TAG_DeclEquations: {
    V v_f_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 4);
    v_t_2426 = heff_tag(TAG_Just, 1, (V[]){v_f_247});
    break;
  }
  case TAG_DeclDefine: {
    V v_x_2411 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 5);
    v_t_2426 = heff_tag(TAG_Just, 1, (V[]){v_x_2411});
    break;
  }
  case TAG_DeclTheory: {
    V v_x_2416 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 4);
    v_t_2426 = heff_tag(TAG_Just, 1, (V[]){v_x_2416});
    break;
  }
  case TAG_DeclPrimitive: {
    V v_x_2420 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 3);
    v_t_2426 = heff_tag(TAG_Just, 1, (V[]){v_x_2420});
    break;
  }
  case TAG_DeclTest: {
    V v_x_2423 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 2);
    v_t_2426 = heff_tag(TAG_Just, 1, (V[]){v_x_2423});
    break;
  }
  case TAG_DeclWatch: {
    heff_take_n(v_t_246, 0ULL, 1);
    v_t_2426 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Nothing: {
    heff_drop(v_kf_240);
    return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){heff_get(heff_dup(v_acc_241), LBL_globals), v_diags_243, heff_get(heff_dup(v_acc_241), LBL_keys), heff_get(heff_dup(v_acc_241), LBL_broken), heff_get(heff_dup(v_acc_241), LBL_watches), heff_get(heff_dup(v_acc_241), LBL_tests), heff_get(heff_dup(v_acc_241), LBL_spans), heff_get(heff_dup(v_acc_241), LBL_infos), heff_get(v_acc_241, LBL_trace)});
  }
  case TAG_Just: {
    V v_x_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    V v_k_2428 = heff_tr(heff_apply(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2427)}));
    V v_t_2429 = heff_tr(heff_apply(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2427)}));
    V v_t_2430 = heff_strEq(v_t_2429, heff_dup(v_x_2427));
    V v_g_2434;
    switch (heff_tag_of(v_t_2430)) {
    case TAG_True: {
      heff_drop(v_kf_240);
      v_g_2434 = heff_get(heff_dup(v_acc_241), LBL_globals);
      break;
    }
    case TAG_False: {
      V v_key_2431 = heff_tr(heff_apply(v_kf_240, 1, (V[]){heff_dup(v_x_2427)}));
      V v_g_2432 = heff_get(heff_dup(v_acc_241), LBL_globals);
      V v_t_2433 = (g_map_2einsert_24s7(heff_dup(v_x_2427), v_key_2431, heff_get(heff_dup(v_g_2432), LBL_aliases)));
      v_g_2434 = heff_rec(4, shape_222_85_4_32, (V[]){heff_get(heff_dup(v_g_2432), LBL_order), heff_get(heff_dup(v_g_2432), LBL_entries), v_t_2433, heff_get(v_g_2432, LBL_broken)});
      break;
    }
    default: heff_nomatch(v_t_2430);
    }
    V v_t_2435 = (g_map_2einsert_24s7(v_k_2428, NTAG(TAG_MkUnit), heff_get(heff_dup(v_g_2434), LBL_broken)));
    V v_globals_2436 = heff_rec(4, shape_222_85_4_32, (V[]){heff_get(heff_dup(v_g_2434), LBL_order), heff_get(heff_dup(v_g_2434), LBL_entries), heff_get(v_g_2434, LBL_aliases), v_t_2435});
    V v_t_2439;
    switch (heff_tag_of(v_n_242)) {
    case TAG_At: {
      V v_s_2438 = heff_field(v_n_242, 1);
      v_t_2439 = heff_dup(v_s_2438);
      break;
    }
    default: heff_nomatch(v_n_242);
    }
    V v_broken_2440 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2427, v_t_2439}), heff_get(heff_dup(v_acc_241), LBL_broken)});
    return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){v_globals_2436, v_diags_243, heff_get(heff_dup(v_acc_241), LBL_keys), v_broken_2440, heff_get(heff_dup(v_acc_241), LBL_watches), heff_get(heff_dup(v_acc_241), LBL_tests), heff_get(heff_dup(v_acc_241), LBL_spans), heff_get(heff_dup(v_acc_241), LBL_infos), heff_get(v_acc_241, LBL_trace)});
  }
  default: return heff_nomatch(v_t_2426);
  }
}
V g_heff_2etoplevel_2etopBroken_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2etopBroken(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
Clo g_heff_2etoplevel_2ekeepSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ekeepSt_entry, 2, 0};

V g_heff_2etoplevel_2ekeepSt(V v_st_240, V v_acc_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_242 = heff_field(v_st_240, 0);
    v_t_245 = heff_dup(v_c_242);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_infos_246 = (g_heff_2etoplevel_2eappendT(heff_get(v_t_245, LBL_infos), heff_get(heff_dup(v_acc_241), LBL_infos)));
  V v_t_2410;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_247 = heff_field(v_st_240, 0);
    v_t_2410 = heff_dup(v_c_247);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_trace_2411 = (g_heff_2etoplevel_2eappendT(heff_get(v_t_2410, LBL_trace), heff_get(heff_dup(v_acc_241), LBL_trace)));
  return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){heff_get(heff_dup(v_acc_241), LBL_globals), heff_get(heff_dup(v_acc_241), LBL_diags), heff_get(heff_dup(v_acc_241), LBL_keys), heff_get(heff_dup(v_acc_241), LBL_broken), heff_get(heff_dup(v_acc_241), LBL_watches), heff_get(heff_dup(v_acc_241), LBL_tests), heff_get(v_acc_241, LBL_spans), v_infos_246, v_trace_2411});
}
V g_heff_2etoplevel_2ekeepSt_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2ekeepSt(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2etoplevel_2etopTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etopTake_entry, 4, 0};

V g_heff_2etoplevel_2etopTake(V v_kf_240, V v_acc_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_st_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_Left: {
      V v_d_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      V v_t_247 = (g_heff_2etoplevel_2ekeepSt(v_st_245, heff_dup(v_acc_241)));
      V v_t_2411;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_248 = heff_field(v_st_245, 0);
        heff_take_n(v_st_245, 1ULL, 3);
        v_t_2411 = v_c_248;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_xs_2412 = heff_get(v_t_2411, LBL_recovered);
      V v_t_2413 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2412));
      V v_t_2414 = (g_heff_2etoplevel_2econcatMapT_24s461(v_t_2413));
      V v_t_2415 = heff_intEq(heff_get(heff_dup(v_d_246), LBL_code), MK_INT(-1LL));
      V v_t_2416;
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
        heff_drop(v_d_246);
        v_t_2416 = NTAG(TAG_Nil);
        break;
      }
      case TAG_False: {
        v_t_2416 = heff_tag_at(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_d_246, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_2415);
      }
      V v_t_2417 = (g_heff_2etoplevel_2eappendT(v_t_2414, v_t_2416));
      V v_t_2418 = (g_prelude_2efoldl_24s0(heff_get(v_acc_241, LBL_diags), v_t_2417));
      HEFF_LAST return g_heff_2etoplevel_2etopBroken(v_kf_240, v_t_247, v_n_242, v_t_2418);
    }
    case TAG_Right: {
      V v_r_2419 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      heff_drop(v_kf_240);
      V v_g_2420 = (g_heff_2eglobals_2eaddEntry(heff_get(heff_dup(v_r_2419), LBL_key), heff_get(heff_dup(v_r_2419), LBL_entry), heff_get(heff_dup(v_acc_241), LBL_globals)));
      V v_t_2421 = (g_map_2einsert_24s7(heff_get(heff_dup(v_r_2419), LBL_name), heff_get(heff_dup(v_r_2419), LBL_key), heff_get(heff_dup(v_g_2420), LBL_aliases)));
      V v_globals_2422 = heff_rec(4, shape_222_85_4_32, (V[]){heff_get(heff_dup(v_g_2420), LBL_order), heff_get(heff_dup(v_g_2420), LBL_entries), v_t_2421, heff_get(v_g_2420, LBL_broken)});
      V v_t_2426;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2423 = heff_dup(heff_field(v_st_245, 0));
        v_t_2426 = v_c_2423;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_xs_2427 = heff_get(v_t_2426, LBL_recovered);
      V v_t_2428 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2427));
      V v_t_2429 = (g_heff_2etoplevel_2econcatMapT_24s461(v_t_2428));
      V v_t_2430 = heff_get(heff_dup(v_r_2419), LBL_failed);
      V v_t_2433;
      switch (heff_tag_of(v_t_2430)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
        v_t_2433 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2431 = heff_field(v_t_2430, 0);
        heff_take_n(v_t_2430, 1ULL, 1);
        V v_t_2432 = heff_intEq(heff_get(heff_dup(v_d_2431), LBL_code), MK_INT(-1LL));
        switch (heff_tag_of(v_t_2432)) {
        case TAG_True: {
          heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
          heff_drop(v_d_2431);
          v_t_2433 = NTAG(TAG_Nil);
          break;
        }
        case TAG_False: {
          v_t_2433 = heff_tag_at(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_d_2431, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_t_2432);
        }
        break;
      }
      default: heff_nomatch(v_t_2430);
      }
      V v_t_2434 = (g_heff_2etoplevel_2eappendT(v_t_2429, v_t_2433));
      V v_diags_2435 = (g_prelude_2efoldl_24s0(heff_get(heff_dup(v_acc_241), LBL_diags), v_t_2434));
      V v_t_2438;
      switch (heff_tag_of(v_n_242)) {
      case TAG_At: {
        V v_s_2437 = heff_field(v_n_242, 1);
        v_t_2438 = heff_dup(v_s_2437);
        break;
      }
      default: heff_nomatch(v_n_242);
      }
      V v_t_2439 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_r_2419), LBL_name), v_t_2438});
      V v_spans_2440 = heff_tag(TAG_Cons, 2, (V[]){v_t_2439, heff_get(heff_dup(v_acc_241), LBL_spans)});
      V v_t_2444;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2441 = heff_dup(heff_field(v_st_245, 0));
        v_t_2444 = v_c_2441;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_infos_2445 = (g_heff_2etoplevel_2eappendT(heff_get(v_t_2444, LBL_infos), heff_get(heff_dup(v_acc_241), LBL_infos)));
      V v_t_2449;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2446 = heff_field(v_st_245, 0);
        heff_take_n(v_st_245, 1ULL, 3);
        v_t_2449 = v_c_2446;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_trace_2450 = (g_heff_2etoplevel_2eappendT(heff_get(v_t_2449, LBL_trace), heff_get(heff_dup(v_acc_241), LBL_trace)));
      V v_t_2451 = heff_tag(TAG_Cons, 2, (V[]){heff_get(v_r_2419, LBL_key), heff_get(heff_dup(v_acc_241), LBL_keys)});
      return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){v_globals_2422, v_diags_2435, v_t_2451, heff_get(heff_dup(v_acc_241), LBL_broken), heff_get(heff_dup(v_acc_241), LBL_watches), heff_get(v_acc_241, LBL_tests), v_spans_2440, v_infos_2445, v_trace_2450});
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2etoplevel_2etopTake_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2etopTake(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
Clo g_heff_2etoplevel_2ewatchTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ewatchTake_entry, 3, 0};

V g_heff_2etoplevel_2ewatchTake(V v_acc_240, V v_sp_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_st_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_Left: {
      V v_d_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop(v_sp_241);
      V v_t_249;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_246 = heff_dup(heff_field(v_st_244, 0));
        v_t_249 = v_c_246;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2410 = heff_get(v_t_249, LBL_recovered);
      V v_t_2411 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2410));
      V v_t_2412 = (g_heff_2etoplevel_2econcatMapT_24s461(v_t_2411));
      V v_t_2413 = heff_intEq(heff_get(heff_dup(v_d_245), LBL_code), MK_INT(-1LL));
      V v_t_2414;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
        heff_drop(v_d_245);
        v_t_2414 = NTAG(TAG_Nil);
        break;
      }
      case TAG_False: {
        v_t_2414 = heff_tag_at(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_d_245, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      V v_t_2415 = (g_heff_2etoplevel_2eappendT(v_t_2412, v_t_2414));
      V v_diags_2416 = (g_prelude_2efoldl_24s0(heff_get(heff_dup(v_acc_240), LBL_diags), v_t_2415));
      V v_t_2420;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2417 = heff_dup(heff_field(v_st_244, 0));
        v_t_2420 = v_c_2417;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2421 = (g_heff_2etoplevel_2eappendT(heff_get(v_t_2420, LBL_infos), heff_get(heff_dup(v_acc_240), LBL_infos)));
      V v_t_2425;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2422 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2425 = v_c_2422;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2426 = (g_heff_2etoplevel_2eappendT(heff_get(v_t_2425, LBL_trace), heff_get(heff_dup(v_acc_240), LBL_trace)));
      return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){heff_get(heff_dup(v_acc_240), LBL_globals), v_diags_2416, heff_get(heff_dup(v_acc_240), LBL_keys), heff_get(heff_dup(v_acc_240), LBL_broken), heff_get(heff_dup(v_acc_240), LBL_watches), heff_get(heff_dup(v_acc_240), LBL_tests), heff_get(v_acc_240, LBL_spans), v_infos_2421, v_trace_2426});
    }
    case TAG_Right: {
      V v_entry_2427 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2431;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2428 = heff_dup(heff_field(v_st_244, 0));
        v_t_2431 = v_c_2428;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2432 = heff_get(v_t_2431, LBL_recovered);
      V v_t_2433 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2432));
      V v_t_2434 = (g_heff_2etoplevel_2econcatMapT_24s461(v_t_2433));
      V v_diags_2435 = (g_prelude_2efoldl_24s0(heff_get(heff_dup(v_acc_240), LBL_diags), v_t_2434));
      V v_t_2439;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2436 = heff_dup(heff_field(v_st_244, 0));
        v_t_2439 = v_c_2436;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2440 = (g_heff_2etoplevel_2eappendT(heff_get(v_t_2439, LBL_infos), heff_get(heff_dup(v_acc_240), LBL_infos)));
      V v_t_2444;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2441 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2444 = v_c_2441;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2445 = (g_heff_2etoplevel_2eappendT(heff_get(v_t_2444, LBL_trace), heff_get(heff_dup(v_acc_240), LBL_trace)));
      V v_t_2446 = heff_tag_at(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){heff_rec(2, shape_314_86, (V[]){v_sp_241, v_entry_2427}), heff_get(heff_dup(v_acc_240), LBL_watches)});
      return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){heff_get(heff_dup(v_acc_240), LBL_globals), v_diags_2435, heff_get(heff_dup(v_acc_240), LBL_keys), heff_get(heff_dup(v_acc_240), LBL_broken), v_t_2446, heff_get(heff_dup(v_acc_240), LBL_tests), heff_get(v_acc_240, LBL_spans), v_infos_2440, v_trace_2445});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2etoplevel_2ewatchTake_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2ewatchTake(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2etoplevel_2erecoveredCheck_24s463_str0 = {{0x80000000u, K_STR, 0}, 21, 21, {101, 114, 114, 111, 114, 115, 32, 114, 101, 99, 111, 118, 101, 114, 101, 100, 32, 102, 114, 111, 109}};
Clo g_heff_2etoplevel_2erecoveredCheck_24s463_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2erecoveredCheck_24s463_entry, 2, 0};

V g_heff_2etoplevel_2erecoveredCheck_24s463(V v_k_240, V v_st_241) {
top: ;
  V v_c_245;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_c_242 = heff_dup(heff_field(v_st_241, 0));
    v_c_245 = v_c_242;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_t_246 = heff_tag(TAG_Right, 1, (V[]){heff_get(v_c_245, LBL_recovered)});
  V v_x1_247 = heff_tag(TAG_MkPair, 2, (V[]){v_t_246, v_st_241});
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_k_240);
      return heff_tag_at(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = ({ V a_0 = MK_INT(0LL); V a_1 = v_x_2411; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_x_2411); r_; });
      V v_t_2413 = heff_intEq(v_t_2412, MK_INT(0LL));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
        return heff_tail(v_k_240, 2, (V[]){NTAG(TAG_MkUnit), v_st_249});
      }
      case TAG_False: {
        heff_drop(v_k_240);
        V v_t_2414 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2etoplevel_2erecoveredCheck_24s463_str0), heff_dup(g_heff_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
        return heff_tag_at(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Left, 1, (V[]){v_t_2414}), v_st_249});
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2etoplevel_2erecoveredCheck_24s463_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2erecoveredCheck_24s463(a[0], a[1]);
}
V g_heff_2etoplevel_2eelabDecl_24s462_lam3(V self, V *args); static Clo g_heff_2etoplevel_2eelabDecl_24s462_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelabDecl_24s462_lam3, 2, 0};
V g_heff_2etoplevel_2eelabDecl_24s462_lam2(V self, V *args);
V g_heff_2etoplevel_2eelabDecl_24s462_lam1(V self, V *args);
V g_heff_2etoplevel_2eelabDecl_24s462_lam0(V self, V *args);
Clo g_heff_2etoplevel_2eelabDecl_24s462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelabDecl_24s462_entry, 4, 0};

V g_heff_2etoplevel_2eelabDecl_24s462(V v_key_240, V v_g_241, V v_n_242, V v_st_243) {
top: ;
  V v_c_247;
  switch (heff_tag_of(v_st_243)) {
  case TAG_MkSt: {
    V v_c_244 = heff_dup(heff_field(v_st_243, 0));
    v_c_247 = v_c_244;
    break;
  }
  default: heff_nomatch(v_st_243);
  }
  V v_t_248 = heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_247), LBL_infos), heff_get(heff_dup(v_c_247), LBL_recovered), heff_get(heff_dup(v_c_247), LBL_poisoned), heff_get(heff_dup(v_c_247), LBL_metas), heff_get(heff_dup(v_c_247), LBL_nextMeta), heff_get(heff_dup(v_c_247), LBL_postponed), heff_get(v_c_247, LBL_trace), NTAG(TAG_Nothing)});
  V v_x1_249 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_Right, 1, (V[]){v_t_248}), v_st_243});
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_g_241);
      return heff_tag_at(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_at(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_t_2418;
      switch (heff_tag_of(v_st_2411)) {
      case TAG_MkSt: {
        V v_d_2416 = heff_field(v_st_2411, 1);
        V v_w_2417 = heff_field(v_st_2411, 2);
        V v_ru_24st_2411_24MkSt = heff_take_reuse_n(v_st_2411, 6ULL, 3);
        v_t_2418 = heff_tag_at(v_ru_24st_2411_24MkSt, TAG_MkSt, 3, (V[]){v_x_2413, v_d_2416, v_w_2417});
        break;
      }
      default: heff_nomatch(v_st_2411);
      }
      V v_x1_2419 = heff_tag_at(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_t_2418});
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_MkPair: {
        V v_x11_2420 = heff_field(v_x1_2419, 0);
        V v_st_2421 = heff_field(v_x1_2419, 1);
        V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
        switch (heff_tag_of(v_x11_2420)) {
        case TAG_Left: {
          V v_e_2422 = heff_field(v_x11_2420, 0);
          heff_take_n(v_x11_2420, 1ULL, 1);
          heff_drop(v_key_240);
          heff_drop(v_g_241);
          return heff_tag_at(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
        }
        case TAG_Right: {
          heff_take_n(v_x11_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2419_24MkPair, 2);
          V v_c_2424 = (g_heff_2etoplevel_2edeclJ(v_n_242));
          return heff_tail(v_c_2424, 3, (V[]){heff_dup(g_heff_2emeta_2eelabH_get()), heff_clo(g_heff_2etoplevel_2eelabDecl_24s462_lam0, 1, 3, (V[]){v_g_241, v_key_240, heff_dup(v_n_242)}), v_st_2421});
        }
        default: return heff_nomatch(v_x11_2420);
        }
      }
      default: return heff_nomatch(v_x1_2419);
      }
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2etoplevel_2eelabDecl_24s462_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eelabDecl_24s462(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
V g_heff_2etoplevel_2eelabDecl_24s462_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_st_2434 = args[1];
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_Right, 1, (V[]){v_x_2433}), v_st_2434});
}
V g_heff_2etoplevel_2eelabDecl_24s462_lam2(V self, V *args) {
  V v_x_2431 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_x_2430 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2431);
  V v_t_2432 = ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_n_242; V a_3 = v_x_2425; V a_4 = v_x_2430; V r_ = (g_heff_2etoplevel_2eelabBody(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_n_242); r_; });
  return heff_tail(v_t_2432, 2, (V[]){heff_dup(g_heff_2emeta_2eelabH_get()), ((V)&g_heff_2etoplevel_2eelabDecl_24s462_lam3_clo)});
}
V g_heff_2etoplevel_2eelabDecl_24s462_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = ((V)&g_heff_2etoplevel_2erecoveredCheck_24s463_clo);
  args[0] = heff_clo(g_heff_2etoplevel_2eelabDecl_24s462_lam2, 1, 5, (V[]){v_key_240, v_g_241, v_n_242, v_x_2425, v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eelabDecl_24s462_lam0(V self, V *args) {
  V v_x_2425 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426 = heff_get(heff_dup(v_x_2425), LBL_ty);
  V v_c_2429;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_MkTyp: {
    V v_f_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    V v_t_2428 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){heff_dup(g_heff_2eenvironment_2eemptyScope_get()), heff_dup(v_g_241), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2429 = heff_tr(heff_apply(v_f_2427, 1, (V[]){v_t_2428}));
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  return heff_tail(v_c_2429, 2, (V[]){heff_dup(g_heff_2emeta_2eelabH_get()), heff_clo(g_heff_2etoplevel_2eelabDecl_24s462_lam1, 1, 4, (V[]){v_key_240, v_g_241, v_n_242, v_x_2425})});
}
V g_heff_2etoplevel_2etopOne_lam0(V self, V *args); static Clo g_heff_2etoplevel_2etopOne_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etopOne_lam0, 2, 0};
Clo g_heff_2etoplevel_2etopOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etopOne_entry, 3, 0};

V g_heff_2etoplevel_2etopOne(V v_kf_240, V v_acc_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_n1_243 = heff_dup(heff_field(v_n_242, 0));
    V v_sp_244 = heff_dup(heff_field(v_n_242, 1));
    switch (heff_tag_of(v_n1_243)) {
    case TAG_DeclEquations: {
      heff_take_n(v_n1_243, 0ULL, 4);
      heff_drop(v_sp_244);
      V v_t_249 = heff_tr(g_heff_2etoplevel_2eelabDecl_24s462(heff_dup(v_kf_240), heff_get(heff_dup(v_acc_241), LBL_globals), v_n_242, heff_dup(g_heff_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_249; V r_ = (g_heff_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclDefine: {
      heff_take_n(v_n1_243, 0ULL, 5);
      heff_drop(v_sp_244);
      V v_t_2415 = heff_tr(g_heff_2etoplevel_2eelabDecl_24s462(heff_dup(v_kf_240), heff_get(heff_dup(v_acc_241), LBL_globals), v_n_242, heff_dup(g_heff_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2415; V r_ = (g_heff_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclTheory: {
      heff_take_n(v_n1_243, 0ULL, 4);
      heff_drop(v_sp_244);
      V v_t_2420 = heff_tr(g_heff_2etoplevel_2eelabDecl_24s462(heff_dup(v_kf_240), heff_get(heff_dup(v_acc_241), LBL_globals), v_n_242, heff_dup(g_heff_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2420; V r_ = (g_heff_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_n1_243, 0ULL, 3);
      heff_drop(v_sp_244);
      V v_t_2424 = heff_tr(g_heff_2etoplevel_2eelabDecl_24s462(heff_dup(v_kf_240), heff_get(heff_dup(v_acc_241), LBL_globals), v_n_242, heff_dup(g_heff_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2424; V r_ = (g_heff_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclTest: {
      V v_x_2425 = heff_field(v_n1_243, 0);
      V v_ru_24n1_243_24DeclTest = heff_take_reuse_n(v_n1_243, 1ULL, 2);
      heff_drop(v_kf_240);
      heff_drop_tag(v_n_242, 2);
      V v_t_2427 = heff_tag_at(v_ru_24n1_243_24DeclTest, TAG_Cons, 2, (V[]){heff_rec(2, shape_198_314, (V[]){v_x_2425, v_sp_244}), heff_get(heff_dup(v_acc_241), LBL_tests)});
      return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){heff_get(heff_dup(v_acc_241), LBL_globals), heff_get(heff_dup(v_acc_241), LBL_diags), heff_get(heff_dup(v_acc_241), LBL_keys), heff_get(heff_dup(v_acc_241), LBL_broken), heff_get(heff_dup(v_acc_241), LBL_watches), v_t_2427, heff_get(heff_dup(v_acc_241), LBL_spans), heff_get(heff_dup(v_acc_241), LBL_infos), heff_get(v_acc_241, LBL_trace)});
    }
    case TAG_DeclWatch: {
      V v_e_2428 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop(v_kf_240);
      heff_drop_tag(v_n_242, 2);
      V v_m_2429 = (g_heff_2etoplevel_2eelabWatch(heff_get(heff_dup(v_acc_241), LBL_globals), v_e_2428));
      V v_t_2432 = heff_tr(heff_apply(v_m_2429, 3, (V[]){heff_dup(g_heff_2emeta_2eelabH_get()), ((V)&g_heff_2etoplevel_2etopOne_lam0_clo), heff_dup(g_heff_2eenvironment_2eemptySt_get())}));
      HEFF_LAST return g_heff_2etoplevel_2ewatchTake(v_acc_241, v_sp_244, v_t_2432);
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2etoplevel_2etopOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2etopOne(a[0], a[1], a[2]);
}
V g_heff_2etoplevel_2etopOne_lam0(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_2431 = args[1];
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_Right, 1, (V[]){v_x_2430}), v_st_2431});
}
Clo g_heff_2etoplevel_2etopGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etopGo_entry, 3, 0};

V g_heff_2etoplevel_2etopGo(V v_kf_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_kf_240);
    V v_diags_243 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_241), LBL_diags)));
    V v_keys_244 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_241), LBL_keys)));
    V v_broken_245 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_241), LBL_broken)));
    V v_watches_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_241), LBL_watches)));
    V v_tests_247 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_241), LBL_tests)));
    V v_spans_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_241), LBL_spans)));
    V v_infos_249 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_241), LBL_infos)));
    V v_trace_2410 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_241), LBL_trace)));
    return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){heff_get(v_acc_241, LBL_globals), v_diags_243, v_keys_244, v_broken_245, v_watches_246, v_tests_247, v_spans_248, v_infos_249, v_trace_2410});
  }
  case TAG_Cons: {
    V v_n_2411 = heff_field(v_x3_242, 0);
    V v_rest_2412 = heff_field(v_x3_242, 1);
    V v_t_2413 = (g_heff_2etoplevel_2etopOne(heff_dup(v_kf_240), v_acc_241, heff_dup(v_n_2411)));
    V t_0 = v_kf_240;
    V t_1 = v_t_2413;
    V t_2 = v_rest_2412;
    v_kf_240 = t_0;
    v_acc_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2etoplevel_2etopGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2etopGo(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2etoplevel_2eelabOut_24s468_lam0(V self, V *args);
V g_heff_2etoplevel_2eelabOut_24s468_lam1(V self, V *args);
Clo g_heff_2etoplevel_2eelabOut_24s468_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelabOut_24s468_entry, 5, 0};

V g_heff_2etoplevel_2eelabOut_24s468(V v_g_240, V v_d_241, V v_tyStx_242, V v_mc_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Left: {
    V v_failed_245 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    V v_t_246 = heff_get(heff_dup(v_d_241), LBL_prim);
    V v_key_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      v_key_247 = heff_get(heff_dup(v_d_241), LBL_name);
      break;
    }
    case TAG_False: {
      v_key_247 = heff_get(heff_dup(v_d_241), LBL_name);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_248 = heff_get(heff_dup(v_d_241), LBL_prim);
    V v_t_249;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      v_t_249 = heff_get(heff_dup(v_d_241), LBL_name);
      break;
    }
    case TAG_False: {
      v_t_249 = heff_get(heff_dup(v_d_241), LBL_name);
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_entry_2410 = ({ V a_0 = v_g_240; V a_1 = v_t_249; V a_2 = v_tyStx_242; V r_ = (g_heff_2etoplevel_2eerrEntry(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
    V v_x_2411 = heff_rec(5, shape_198_152_255_86_96, (V[]){heff_get(heff_dup(v_d_241), LBL_name), v_key_247, heff_get(v_d_241, LBL_prim), v_entry_2410, heff_tag(TAG_Just, 1, (V[]){v_failed_245})});
    return heff_clo(g_heff_2etoplevel_2eelabOut_24s468_lam0, 2, 1, (V[]){v_x_2411});
  }
  case TAG_Right: {
    V v_t_2414 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    V v_t_2415 = heff_get(heff_dup(v_d_241), LBL_prim);
    V v_key_2416;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_True: {
      v_key_2416 = heff_get(heff_dup(v_d_241), LBL_name);
      break;
    }
    case TAG_False: {
      v_key_2416 = heff_get(heff_dup(v_d_241), LBL_name);
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V v_t_2417 = heff_get(heff_dup(v_d_241), LBL_prim);
    V v_t_2418;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      v_t_2418 = heff_get(heff_dup(v_d_241), LBL_name);
      break;
    }
    case TAG_False: {
      v_t_2418 = heff_get(heff_dup(v_d_241), LBL_name);
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2419 = heff_get(heff_dup(v_d_241), LBL_prim);
    V v_k_2420;
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      v_k_2420 = heff_get(heff_dup(v_d_241), LBL_name);
      break;
    }
    case TAG_False: {
      v_k_2420 = heff_get(heff_dup(v_d_241), LBL_name);
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    V v_t_2421 = (g_heff_2eunify_2ezonker(v_mc_243));
    V v_t_2422 = heff_tr(heff_apply(heff_get(v_t_2421, LBL_el), 1, (V[]){heff_get(v_t_2414, LBL_stx)}));
    V v_t_2423 = (g_heff_2etoplevel_2eselfWalk(v_k_2420));
    V v_t_2424 = heff_tr(heff_apply(heff_get(v_t_2423, LBL_el), 2, (V[]){MK_INT(0LL), v_t_2422}));
    V v_entry_2425 = ({ V a_0 = v_g_240; V a_1 = v_t_2418; V b_2 = heff_get(heff_dup(v_d_241), LBL_prim); V a_3 = v_tyStx_242; V a_4 = v_t_2424; V r_ = (g_heff_2etoplevel_2eentryFor(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
    V v_x_2426 = heff_rec(5, shape_198_152_255_86_96, (V[]){heff_get(heff_dup(v_d_241), LBL_name), v_key_2416, heff_get(v_d_241, LBL_prim), v_entry_2425, NTAG(TAG_Nothing)});
    return heff_clo(g_heff_2etoplevel_2eelabOut_24s468_lam1, 2, 1, (V[]){v_x_2426});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2etoplevel_2eelabOut_24s468_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eelabOut_24s468(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); return r;
}
V g_heff_2etoplevel_2eelabOut_24s468_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eelabOut_24s468_lam1(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_x_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eelabBody_24s467_lam0(V self, V *args);
V g_heff_2etoplevel_2eelabBody_24s467_lam3(V self, V *args);
V g_heff_2etoplevel_2eelabBody_24s467_lam5(V self, V *args); static Clo g_heff_2etoplevel_2eelabBody_24s467_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelabBody_24s467_lam5, 1, 0};
V g_heff_2etoplevel_2eelabBody_24s467_lam9(V self, V *args); static Clo g_heff_2etoplevel_2eelabBody_24s467_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelabBody_24s467_lam9, 1, 0};
V g_heff_2etoplevel_2eelabBody_24s467_lam10(V self, V *args);
V g_heff_2etoplevel_2eelabBody_24s467_lam8(V self, V *args);
V g_heff_2etoplevel_2eelabBody_24s467_lam7(V self, V *args);
V g_heff_2etoplevel_2eelabBody_24s467_lam6(V self, V *args);
V g_heff_2etoplevel_2eelabBody_24s467_lam4(V self, V *args);
V g_heff_2etoplevel_2eelabBody_24s467_lam2(V self, V *args);
V g_heff_2etoplevel_2eelabBody_24s467_lam1(V self, V *args);
Clo g_heff_2etoplevel_2eelabBody_24s467_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelabBody_24s467_entry, 4, 0};

V g_heff_2etoplevel_2eelabBody_24s467(V v_g_240, V v_n_241, V v_d_242, V v_a_243) {
top: ;
  V v_t_244 = heff_get(heff_dup(v_d_242), LBL_prim);
  V v_t_245;
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    v_t_245 = heff_get(heff_dup(v_d_242), LBL_name);
    break;
  }
  case TAG_False: {
    v_t_245 = heff_get(heff_dup(v_d_242), LBL_name);
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_k_246 = heff_tag(TAG_Just, 1, (V[]){v_t_245});
  V v_c_248 = heff_tr(heff_apply(((V)&g_heff_2eenvironment_2emodify_clo), 1, (V[]){heff_clo(g_heff_2etoplevel_2eelabBody_24s467_lam0, 1, 1, (V[]){v_k_246})}));
  return heff_clo(g_heff_2etoplevel_2eelabBody_24s467_lam1, 2, 5, (V[]){v_c_248, heff_dup(v_n_241), v_d_242, v_a_243, v_g_240});
}
V g_heff_2etoplevel_2eelabBody_24s467_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eelabBody_24s467(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2etoplevel_2eelabBody_24s467_lam0(V self, V *args) {
  V v_c_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_247), LBL_infos), heff_get(heff_dup(v_c_247), LBL_recovered), heff_get(heff_dup(v_c_247), LBL_poisoned), heff_get(heff_dup(v_c_247), LBL_metas), heff_get(heff_dup(v_c_247), LBL_nextMeta), heff_get(heff_dup(v_c_247), LBL_postponed), heff_get(v_c_247, LBL_trace), v_k_246});
}
V g_heff_2etoplevel_2eelabBody_24s467_lam3(V self, V *args) {
  V v_u_2420 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2420);
  V v_x1_2421 = heff_tr(heff_apply(heff_get(v_a_243, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_Nom: {
    V v_x_2422 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    return v_x_2422;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2421, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2424 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    return v_x_2424;
  }
  default: return heff_nomatch(v_x1_2421);
  }
}
V g_heff_2etoplevel_2eelabBody_24s467_lam5(V self, V *args) {
  V v_c_2443 = args[0];
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_2443), LBL_infos), heff_get(heff_dup(v_c_2443), LBL_recovered), heff_get(heff_dup(v_c_2443), LBL_poisoned), heff_get(heff_dup(v_c_2443), LBL_metas), heff_get(heff_dup(v_c_2443), LBL_nextMeta), heff_get(heff_dup(v_c_2443), LBL_postponed), heff_get(v_c_2443, LBL_trace), NTAG(TAG_Nothing)});
}
V g_heff_2etoplevel_2eelabBody_24s467_lam9(V self, V *args) {
  V v_c_2457 = args[0];
  return heff_get(v_c_2457, LBL_metas);
}
V g_heff_2etoplevel_2eelabBody_24s467_lam10(V self, V *args) {
  V v_x_2461 = args[0];
  V v_a_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_x_2442 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2462 = (g_heff_2eunify_2ezonker(v_x_2461));
  V v_t_2463 = heff_tr(heff_apply(heff_get(v_t_2462, LBL_ty), 1, (V[]){heff_get(v_a_243, LBL_stx)}));
  V v_t_2464 = ({ V a_0 = v_g_240; V a_1 = v_d_242; V a_2 = v_t_2463; V a_3 = v_x_2461; V a_4 = v_x_2442; V r_ = (g_heff_2etoplevel_2eelabOut_24s468(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2461); r_; });
  return heff_tail(v_t_2464, 2, (V[]){v_hd_249, v_k_2410});
}
V g_heff_2etoplevel_2eelabBody_24s467_lam8(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_x_2442 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2456);
  V v_t_2458 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2etoplevel_2eelabBody_24s467_lam9_clo)})});
  V v_t_2459 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2459}));
  return heff_tail(heff_get(heff_dup(v_hd_249), LBL_bind), 2, (V[]){v_t_2460, heff_clo(g_heff_2etoplevel_2eelabBody_24s467_lam10, 1, 6, (V[]){v_a_243, v_g_240, v_d_242, v_x_2442, v_hd_249, v_k_2410})});
}
V g_heff_2etoplevel_2eelabBody_24s467_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_x_2442 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2451);
  V v_t_2454;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2453 = heff_field(v_n_241, 1);
    heff_take_n(v_n_241, 2ULL, 2);
    v_t_2454 = v_s_2453;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_2455 = (g_heff_2etoplevel_2eprimKnown(v_t_2454, heff_dup(v_d_242)));
  return heff_tail(v_c_2455, 2, (V[]){heff_dup(v_hd_249), heff_clo(g_heff_2etoplevel_2eelabBody_24s467_lam8, 1, 6, (V[]){v_hd_249, v_a_243, v_g_240, v_d_242, v_x_2442, v_k_2410})});
}
V g_heff_2etoplevel_2eelabBody_24s467_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_x_2442 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2448 = heff_tag(TAG_Put, 2, (V[]){v_x_2447, NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})}));
  return heff_tail(heff_get(heff_dup(v_hd_249), LBL_bind), 2, (V[]){v_t_2450, heff_clo(g_heff_2etoplevel_2eelabBody_24s467_lam7, 1, 7, (V[]){v_n_241, v_d_242, v_hd_249, v_a_243, v_g_240, v_x_2442, v_k_2410})});
}
V g_heff_2etoplevel_2eelabBody_24s467_lam4(V self, V *args) {
  V v_x_2442 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2444 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2etoplevel_2eelabBody_24s467_lam5_clo)})});
  V v_t_2445 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2445}));
  return heff_tail(heff_get(heff_dup(v_hd_249), LBL_bind), 2, (V[]){v_t_2446, heff_clo(g_heff_2etoplevel_2eelabBody_24s467_lam6, 1, 7, (V[]){v_hd_249, v_n_241, v_d_242, v_a_243, v_g_240, v_x_2442, v_k_2410})});
}
V g_heff_2etoplevel_2eelabBody_24s467_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_a_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2411);
  V v_t_2414;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2413 = heff_dup(heff_field(v_n_241, 1));
    v_t_2414 = v_s_2413;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_t_2415 = heff_get(heff_dup(v_d_242), LBL_prim);
  V v_t_2416;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    v_t_2416 = heff_get(heff_dup(v_d_242), LBL_name);
    break;
  }
  case TAG_False: {
    v_t_2416 = heff_get(heff_dup(v_d_242), LBL_name);
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_t_2417 = heff_get(heff_dup(v_d_242), LBL_prim);
  V v_t_2418;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    v_t_2418 = heff_get(heff_dup(v_d_242), LBL_name);
    break;
  }
  case TAG_False: {
    v_t_2418 = heff_get(heff_dup(v_d_242), LBL_name);
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  V v_h_2419 = heff_tag(TAG_HGlobal, 1, (V[]){v_t_2418});
  V v_t_2425 = (g_heff_2evalue_2emkNeu_24s10(v_h_2419, NTAG(TAG_SpId), heff_clo(g_heff_2etoplevel_2eelabBody_24s467_lam3, 1, 1, (V[]){heff_dup(v_a_243)}), NTAG(TAG_Nothing)));
  V v_x1_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_a_243), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2430;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_Nom: {
    V v_x_2427 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_t_2430 = v_x_2427;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2426, 0ULL, 1);
    v_t_2430 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2429 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_t_2430 = v_x_2429;
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  V v_t_2431 = heff_rec(4, shape_329_352_367_355, (V[]){NTAG(TAG_SOpaque), heff_get(heff_dup(v_a_243), LBL_stx), v_t_2425, v_t_2430});
  V v_t_2432 = (g_heff_2eglobals_2eaddEntry(v_t_2416, v_t_2431, heff_dup(v_g_240)));
  V v_t_2433 = heff_get(heff_dup(v_d_242), LBL_prim);
  V v_t_2434;
  switch (heff_tag_of(v_t_2433)) {
  case TAG_True: {
    v_t_2434 = heff_get(heff_dup(v_d_242), LBL_name);
    break;
  }
  case TAG_False: {
    v_t_2434 = heff_get(heff_dup(v_d_242), LBL_name);
    break;
  }
  default: heff_nomatch(v_t_2433);
  }
  V v_x1_2435 = heff_tr(heff_apply(heff_get(heff_dup(v_a_243), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2439;
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_Nom: {
    V v_x_2436 = heff_field(v_x1_2435, 0);
    heff_take_n(v_x1_2435, 1ULL, 1);
    v_t_2439 = v_x_2436;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2435, 0ULL, 1);
    v_t_2439 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2438 = heff_field(v_x1_2435, 0);
    heff_take_n(v_x1_2435, 1ULL, 1);
    v_t_2439 = v_x_2438;
    break;
  }
  default: heff_nomatch(v_x1_2435);
  }
  V v_t_2440 = (g_heff_2etoplevel_2ebodyPhase(v_t_2414, heff_dup(v_d_242), v_t_2432, v_t_2434, v_t_2439));
  V v_c_2441 = heff_tr(heff_apply(((V)&g_heff_2eenvironment_2etryE_clo), 1, (V[]){v_t_2440}));
  return heff_tail(v_c_2441, 2, (V[]){heff_dup(v_hd_249), heff_clo(g_heff_2etoplevel_2eelabBody_24s467_lam4, 1, 6, (V[]){v_hd_249, v_n_241, v_d_242, v_a_243, v_g_240, v_k_2410})});
}
V g_heff_2etoplevel_2eelabBody_24s467_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo(g_heff_2etoplevel_2eelabBody_24s467_lam2, 1, 6, (V[]){v_n_241, v_d_242, v_a_243, v_g_240, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam3(V self, V *args); static Clo g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam3, 2, 0};
V g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam2(V self, V *args);
V g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam1(V self, V *args);
V g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam0(V self, V *args);
Clo g_heff_2etoplevel_2eelabDecl_24s462_24s466_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eelabDecl_24s462_24s466_entry, 3, 0};

V g_heff_2etoplevel_2eelabDecl_24s462_24s466(V v_g_240, V v_n_241, V v_st_242) {
top: ;
  V v_c_246;
  switch (heff_tag_of(v_st_242)) {
  case TAG_MkSt: {
    V v_c_243 = heff_dup(heff_field(v_st_242, 0));
    v_c_246 = v_c_243;
    break;
  }
  default: heff_nomatch(v_st_242);
  }
  V v_t_247 = heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_246), LBL_infos), heff_get(heff_dup(v_c_246), LBL_recovered), heff_get(heff_dup(v_c_246), LBL_poisoned), heff_get(heff_dup(v_c_246), LBL_metas), heff_get(heff_dup(v_c_246), LBL_nextMeta), heff_get(heff_dup(v_c_246), LBL_postponed), heff_get(v_c_246, LBL_trace), NTAG(TAG_Nothing)});
  V v_x1_248 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_Right, 1, (V[]){v_t_247}), v_st_242});
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop(v_g_240);
      return heff_tag_at(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_t_2413 = heff_tag_at(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_t_2417;
      switch (heff_tag_of(v_st_2410)) {
      case TAG_MkSt: {
        V v_d_2415 = heff_field(v_st_2410, 1);
        V v_w_2416 = heff_field(v_st_2410, 2);
        V v_ru_24st_2410_24MkSt = heff_take_reuse_n(v_st_2410, 6ULL, 3);
        v_t_2417 = heff_tag_at(v_ru_24st_2410_24MkSt, TAG_MkSt, 3, (V[]){v_x_2412, v_d_2415, v_w_2416});
        break;
      }
      default: heff_nomatch(v_st_2410);
      }
      V v_x1_2418 = heff_tag_at(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_t_2417});
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_MkPair: {
        V v_x11_2419 = heff_field(v_x1_2418, 0);
        V v_st_2420 = heff_field(v_x1_2418, 1);
        V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
        switch (heff_tag_of(v_x11_2419)) {
        case TAG_Left: {
          V v_e_2421 = heff_field(v_x11_2419, 0);
          heff_take_n(v_x11_2419, 1ULL, 1);
          heff_drop(v_g_240);
          return heff_tag_at(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Left, 1, (V[]){v_e_2421}), v_st_2420});
        }
        case TAG_Right: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2418_24MkPair, 2);
          V v_c_2423 = (g_heff_2etoplevel_2edeclJ(v_n_241));
          return heff_tail(v_c_2423, 3, (V[]){heff_dup(g_heff_2emeta_2eelabH_get()), heff_clo(g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam0, 1, 2, (V[]){v_g_240, heff_dup(v_n_241)}), v_st_2420});
        }
        default: return heff_nomatch(v_x11_2419);
        }
      }
      default: return heff_nomatch(v_x1_2418);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2etoplevel_2eelabDecl_24s462_24s466_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eelabDecl_24s462_24s466(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_st_2433 = args[1];
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_Right, 1, (V[]){v_x_2432}), v_st_2433});
}
V g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2430);
  V v_t_2431 = ({ V a_0 = v_g_240; V a_1 = v_n_241; V a_2 = v_x_2424; V a_3 = v_x_2429; V r_ = (g_heff_2etoplevel_2eelabBody_24s467(a_0, a_1, a_2, a_3)); heff_drop(v_n_241); r_; });
  return heff_tail(v_t_2431, 2, (V[]){heff_dup(g_heff_2emeta_2eelabH_get()), ((V)&g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam3_clo)});
}
V g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = ((V)&g_heff_2etoplevel_2erecoveredCheck_24s463_clo);
  args[0] = heff_clo(g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam2, 1, 4, (V[]){v_g_240, v_n_241, v_x_2424, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam0(V self, V *args) {
  V v_x_2424 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_get(heff_dup(v_x_2424), LBL_ty);
  V v_c_2428;
  switch (heff_tag_of(v_t_2425)) {
  case TAG_MkTyp: {
    V v_f_2426 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    V v_t_2427 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){heff_dup(g_heff_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2428 = heff_tr(heff_apply(v_f_2426, 1, (V[]){v_t_2427}));
    break;
  }
  default: heff_nomatch(v_t_2425);
  }
  return heff_tail(v_c_2428, 2, (V[]){heff_dup(g_heff_2emeta_2eelabH_get()), heff_clo(g_heff_2etoplevel_2eelabDecl_24s462_24s466_lam1, 1, 3, (V[]){v_g_240, v_n_241, v_x_2424})});
}
Clo g_heff_2etoplevel_2etopBroken_24s470_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etopBroken_24s470_entry, 3, 0};

V g_heff_2etoplevel_2etopBroken_24s470(V v_acc_240, V v_n_241, V v_diags_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x_243 = heff_field(v_n_241, 0);
    v_t_245 = heff_dup(v_x_243);
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_t_2425;
  switch (heff_tag_of(v_t_245)) {
  case TAG_DeclEquations: {
    V v_f_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 4);
    v_t_2425 = heff_tag(TAG_Just, 1, (V[]){v_f_246});
    break;
  }
  case TAG_DeclDefine: {
    V v_x_2410 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 5);
    v_t_2425 = heff_tag(TAG_Just, 1, (V[]){v_x_2410});
    break;
  }
  case TAG_DeclTheory: {
    V v_x_2415 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 4);
    v_t_2425 = heff_tag(TAG_Just, 1, (V[]){v_x_2415});
    break;
  }
  case TAG_DeclPrimitive: {
    V v_x_2419 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 3);
    v_t_2425 = heff_tag(TAG_Just, 1, (V[]){v_x_2419});
    break;
  }
  case TAG_DeclTest: {
    V v_x_2422 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 2);
    v_t_2425 = heff_tag(TAG_Just, 1, (V[]){v_x_2422});
    break;
  }
  case TAG_DeclWatch: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2425 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Nothing: {
    return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){heff_get(heff_dup(v_acc_240), LBL_globals), v_diags_242, heff_get(heff_dup(v_acc_240), LBL_keys), heff_get(heff_dup(v_acc_240), LBL_broken), heff_get(heff_dup(v_acc_240), LBL_watches), heff_get(heff_dup(v_acc_240), LBL_tests), heff_get(heff_dup(v_acc_240), LBL_spans), heff_get(heff_dup(v_acc_240), LBL_infos), heff_get(v_acc_240, LBL_trace)});
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    V v_t_2427 = heff_strEq(heff_dup(v_x_2426), heff_dup(v_x_2426));
    V v_g_2430;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_True: {
      v_g_2430 = heff_get(heff_dup(v_acc_240), LBL_globals);
      break;
    }
    case TAG_False: {
      V v_g_2428 = heff_get(heff_dup(v_acc_240), LBL_globals);
      V v_t_2429 = (g_map_2einsert_24s7(heff_dup(v_x_2426), heff_dup(v_x_2426), heff_get(heff_dup(v_g_2428), LBL_aliases)));
      v_g_2430 = heff_rec(4, shape_222_85_4_32, (V[]){heff_get(heff_dup(v_g_2428), LBL_order), heff_get(heff_dup(v_g_2428), LBL_entries), v_t_2429, heff_get(v_g_2428, LBL_broken)});
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    V v_t_2431 = (g_map_2einsert_24s7(heff_dup(v_x_2426), NTAG(TAG_MkUnit), heff_get(heff_dup(v_g_2430), LBL_broken)));
    V v_globals_2432 = heff_rec(4, shape_222_85_4_32, (V[]){heff_get(heff_dup(v_g_2430), LBL_order), heff_get(heff_dup(v_g_2430), LBL_entries), heff_get(v_g_2430, LBL_aliases), v_t_2431});
    V v_t_2435;
    switch (heff_tag_of(v_n_241)) {
    case TAG_At: {
      V v_s_2434 = heff_field(v_n_241, 1);
      v_t_2435 = heff_dup(v_s_2434);
      break;
    }
    default: heff_nomatch(v_n_241);
    }
    V v_broken_2436 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2426, v_t_2435}), heff_get(heff_dup(v_acc_240), LBL_broken)});
    return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){v_globals_2432, v_diags_242, heff_get(heff_dup(v_acc_240), LBL_keys), v_broken_2436, heff_get(heff_dup(v_acc_240), LBL_watches), heff_get(heff_dup(v_acc_240), LBL_tests), heff_get(heff_dup(v_acc_240), LBL_spans), heff_get(heff_dup(v_acc_240), LBL_infos), heff_get(v_acc_240, LBL_trace)});
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2etoplevel_2etopBroken_24s470_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2etopBroken_24s470(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
Clo g_heff_2etoplevel_2etopTake_24s469_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etopTake_24s469_entry, 3, 0};

V g_heff_2etoplevel_2etopTake_24s469(V v_acc_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_st_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24MkPair = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_Left: {
      V v_d_245 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      V v_t_246 = (g_heff_2etoplevel_2ekeepSt(v_st_244, heff_dup(v_acc_240)));
      V v_t_2410;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_247 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2410 = v_c_247;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2411 = heff_get(v_t_2410, LBL_recovered);
      V v_t_2412 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2411));
      V v_t_2413 = (g_heff_2etoplevel_2econcatMapT_24s461(v_t_2412));
      V v_t_2414 = heff_intEq(heff_get(heff_dup(v_d_245), LBL_code), MK_INT(-1LL));
      V v_t_2415;
      switch (heff_tag_of(v_t_2414)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
        heff_drop(v_d_245);
        v_t_2415 = NTAG(TAG_Nil);
        break;
      }
      case TAG_False: {
        v_t_2415 = heff_tag_at(v_ru_24x4_242_24MkPair, TAG_Cons, 2, (V[]){v_d_245, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_2414);
      }
      V v_t_2416 = (g_heff_2etoplevel_2eappendT(v_t_2413, v_t_2415));
      V v_t_2417 = (g_prelude_2efoldl_24s0(heff_get(v_acc_240, LBL_diags), v_t_2416));
      HEFF_LAST return g_heff_2etoplevel_2etopBroken_24s470(v_t_246, v_n_241, v_t_2417);
    }
    case TAG_Right: {
      V v_r_2418 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      V v_g_2419 = (g_heff_2eglobals_2eaddEntry(heff_get(heff_dup(v_r_2418), LBL_key), heff_get(heff_dup(v_r_2418), LBL_entry), heff_get(heff_dup(v_acc_240), LBL_globals)));
      V v_t_2420 = (g_map_2einsert_24s7(heff_get(heff_dup(v_r_2418), LBL_name), heff_get(heff_dup(v_r_2418), LBL_key), heff_get(heff_dup(v_g_2419), LBL_aliases)));
      V v_globals_2421 = heff_rec(4, shape_222_85_4_32, (V[]){heff_get(heff_dup(v_g_2419), LBL_order), heff_get(heff_dup(v_g_2419), LBL_entries), v_t_2420, heff_get(v_g_2419, LBL_broken)});
      V v_t_2425;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2422 = heff_dup(heff_field(v_st_244, 0));
        v_t_2425 = v_c_2422;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2426 = heff_get(v_t_2425, LBL_recovered);
      V v_t_2427 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2426));
      V v_t_2428 = (g_heff_2etoplevel_2econcatMapT_24s461(v_t_2427));
      V v_t_2429 = heff_get(heff_dup(v_r_2418), LBL_failed);
      V v_t_2432;
      switch (heff_tag_of(v_t_2429)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
        v_t_2432 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2430 = heff_field(v_t_2429, 0);
        heff_take_n(v_t_2429, 1ULL, 1);
        V v_t_2431 = heff_intEq(heff_get(heff_dup(v_d_2430), LBL_code), MK_INT(-1LL));
        switch (heff_tag_of(v_t_2431)) {
        case TAG_True: {
          heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
          heff_drop(v_d_2430);
          v_t_2432 = NTAG(TAG_Nil);
          break;
        }
        case TAG_False: {
          v_t_2432 = heff_tag_at(v_ru_24x4_242_24MkPair, TAG_Cons, 2, (V[]){v_d_2430, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_t_2431);
        }
        break;
      }
      default: heff_nomatch(v_t_2429);
      }
      V v_t_2433 = (g_heff_2etoplevel_2eappendT(v_t_2428, v_t_2432));
      V v_diags_2434 = (g_prelude_2efoldl_24s0(heff_get(heff_dup(v_acc_240), LBL_diags), v_t_2433));
      V v_t_2437;
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_s_2436 = heff_field(v_n_241, 1);
        v_t_2437 = heff_dup(v_s_2436);
        break;
      }
      default: heff_nomatch(v_n_241);
      }
      V v_t_2438 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_r_2418), LBL_name), v_t_2437});
      V v_spans_2439 = heff_tag(TAG_Cons, 2, (V[]){v_t_2438, heff_get(heff_dup(v_acc_240), LBL_spans)});
      V v_t_2443;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2440 = heff_dup(heff_field(v_st_244, 0));
        v_t_2443 = v_c_2440;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2444 = (g_heff_2etoplevel_2eappendT(heff_get(v_t_2443, LBL_infos), heff_get(heff_dup(v_acc_240), LBL_infos)));
      V v_t_2448;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2445 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2448 = v_c_2445;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2449 = (g_heff_2etoplevel_2eappendT(heff_get(v_t_2448, LBL_trace), heff_get(heff_dup(v_acc_240), LBL_trace)));
      V v_t_2450 = heff_tag(TAG_Cons, 2, (V[]){heff_get(v_r_2418, LBL_key), heff_get(heff_dup(v_acc_240), LBL_keys)});
      return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){v_globals_2421, v_diags_2434, v_t_2450, heff_get(heff_dup(v_acc_240), LBL_broken), heff_get(heff_dup(v_acc_240), LBL_watches), heff_get(v_acc_240, LBL_tests), v_spans_2439, v_infos_2444, v_trace_2449});
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2etoplevel_2etopTake_24s469_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2etopTake_24s469(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2etoplevel_2etopOne_24s465_lam0(V self, V *args); static Clo g_heff_2etoplevel_2etopOne_24s465_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etopOne_24s465_lam0, 2, 0};
Clo g_heff_2etoplevel_2etopOne_24s465_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etopOne_24s465_entry, 2, 0};

V g_heff_2etoplevel_2etopOne_24s465(V v_acc_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_DeclEquations: {
      heff_take_n(v_n1_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_t_248 = heff_tr(g_heff_2etoplevel_2eelabDecl_24s462_24s466(heff_get(heff_dup(v_acc_240), LBL_globals), v_n_241, heff_dup(g_heff_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_acc_240; V a_1 = v_n_241; V a_2 = v_t_248; V r_ = (g_heff_2etoplevel_2etopTake_24s469(a_0, a_1, a_2)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclDefine: {
      heff_take_n(v_n1_242, 0ULL, 5);
      heff_drop(v_sp_243);
      V v_t_2414 = heff_tr(g_heff_2etoplevel_2eelabDecl_24s462_24s466(heff_get(heff_dup(v_acc_240), LBL_globals), v_n_241, heff_dup(g_heff_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_acc_240; V a_1 = v_n_241; V a_2 = v_t_2414; V r_ = (g_heff_2etoplevel_2etopTake_24s469(a_0, a_1, a_2)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclTheory: {
      heff_take_n(v_n1_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_t_2419 = heff_tr(g_heff_2etoplevel_2eelabDecl_24s462_24s466(heff_get(heff_dup(v_acc_240), LBL_globals), v_n_241, heff_dup(g_heff_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_acc_240; V a_1 = v_n_241; V a_2 = v_t_2419; V r_ = (g_heff_2etoplevel_2etopTake_24s469(a_0, a_1, a_2)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_n1_242, 0ULL, 3);
      heff_drop(v_sp_243);
      V v_t_2423 = heff_tr(g_heff_2etoplevel_2eelabDecl_24s462_24s466(heff_get(heff_dup(v_acc_240), LBL_globals), v_n_241, heff_dup(g_heff_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_acc_240; V a_1 = v_n_241; V a_2 = v_t_2423; V r_ = (g_heff_2etoplevel_2etopTake_24s469(a_0, a_1, a_2)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclTest: {
      V v_x_2424 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24DeclTest = heff_take_reuse_n(v_n1_242, 1ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2426 = heff_tag_at(v_ru_24n1_242_24DeclTest, TAG_Cons, 2, (V[]){heff_rec(2, shape_198_314, (V[]){v_x_2424, v_sp_243}), heff_get(heff_dup(v_acc_240), LBL_tests)});
      return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){heff_get(heff_dup(v_acc_240), LBL_globals), heff_get(heff_dup(v_acc_240), LBL_diags), heff_get(heff_dup(v_acc_240), LBL_keys), heff_get(heff_dup(v_acc_240), LBL_broken), heff_get(heff_dup(v_acc_240), LBL_watches), v_t_2426, heff_get(heff_dup(v_acc_240), LBL_spans), heff_get(heff_dup(v_acc_240), LBL_infos), heff_get(v_acc_240, LBL_trace)});
    }
    case TAG_DeclWatch: {
      V v_e_2427 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_m_2428 = (g_heff_2etoplevel_2eelabWatch(heff_get(heff_dup(v_acc_240), LBL_globals), v_e_2427));
      V v_t_2431 = heff_tr(heff_apply(v_m_2428, 3, (V[]){heff_dup(g_heff_2emeta_2eelabH_get()), ((V)&g_heff_2etoplevel_2etopOne_24s465_lam0_clo), heff_dup(g_heff_2eenvironment_2eemptySt_get())}));
      return (g_heff_2etoplevel_2ewatchTake(v_acc_240, v_sp_243, v_t_2431));
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2etoplevel_2etopOne_24s465_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2etopOne_24s465(a[0], a[1]);
}
V g_heff_2etoplevel_2etopOne_24s465_lam0(V self, V *args) {
  V v_x_2429 = args[0];
  V v_st_2430 = args[1];
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_Right, 1, (V[]){v_x_2429}), v_st_2430});
}
Clo g_heff_2etoplevel_2etopGo_24s464_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2etopGo_24s464_entry, 2, 0};

V g_heff_2etoplevel_2etopGo_24s464(V v_acc_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_diags_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_240), LBL_diags)));
    V v_keys_243 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_240), LBL_keys)));
    V v_broken_244 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_240), LBL_broken)));
    V v_watches_245 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_240), LBL_watches)));
    V v_tests_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_240), LBL_tests)));
    V v_spans_247 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_240), LBL_spans)));
    V v_infos_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_240), LBL_infos)));
    V v_trace_249 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_240), LBL_trace)));
    return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){heff_get(v_acc_240, LBL_globals), v_diags_242, v_keys_243, v_broken_244, v_watches_245, v_tests_246, v_spans_247, v_infos_248, v_trace_249});
  }
  case TAG_Cons: {
    V v_n_2410 = heff_field(v_x3_241, 0);
    V v_rest_2411 = heff_field(v_x3_241, 1);
    V v_t_2412 = (g_heff_2etoplevel_2etopOne_24s465(v_acc_240, heff_dup(v_n_2410)));
    V t_0 = v_t_2412;
    V t_1 = v_rest_2411;
    v_acc_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2etoplevel_2etopGo_24s464_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2etopGo_24s464(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2etoplevel_2eisForeignB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2eisForeignB_entry, 1, 0};

V g_heff_2etoplevel_2eisForeignB(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_True);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2etoplevel_2eisForeignB_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2etoplevel_2eisForeignB(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2etoplevel_2ethawGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ethawGlobals_entry, 2, 0};

V g_heff_2etoplevel_2ethawGlobals(V v_acc_240, V v_d_241) {
top: ;
  V v_t_242 = heff_strEq(heff_get(heff_dup(v_d_241), LBL_key), heff_get(heff_dup(v_d_241), LBL_name));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = ({ V b_0 = heff_get(heff_dup(v_d_241), LBL_body); V r_ = (g_heff_2etoplevel_2eisForeignB(b_0)); heff_drop(b_0); r_; });
    V v_t_244 = ({ V a_0 = heff_get(heff_dup(v_acc_240), LBL_globals); V a_1 = heff_get(heff_dup(v_d_241), LBL_key); V a_2 = v_t_243; V a_3 = heff_get(heff_dup(v_d_241), LBL_ty); V a_4 = heff_get(heff_dup(v_d_241), LBL_body); V r_ = (g_heff_2etoplevel_2eentryFor(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_243); r_; });
    return (g_heff_2eglobals_2eaddEntry(heff_get(v_d_241, LBL_key), v_t_244, heff_get(v_acc_240, LBL_globals)));
  }
  case TAG_False: {
    V v_t_245 = ({ V b_0 = heff_get(heff_dup(v_d_241), LBL_body); V r_ = (g_heff_2etoplevel_2eisForeignB(b_0)); heff_drop(b_0); r_; });
    V v_t_246 = ({ V a_0 = heff_get(heff_dup(v_acc_240), LBL_globals); V a_1 = heff_get(heff_dup(v_d_241), LBL_key); V a_2 = v_t_245; V a_3 = heff_get(heff_dup(v_d_241), LBL_ty); V a_4 = heff_get(heff_dup(v_d_241), LBL_body); V r_ = (g_heff_2etoplevel_2eentryFor(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_245); r_; });
    V v_g_247 = (g_heff_2eglobals_2eaddEntry(heff_get(heff_dup(v_d_241), LBL_key), v_t_246, heff_get(v_acc_240, LBL_globals)));
    V v_t_248 = (g_map_2einsert_24s7(heff_get(heff_dup(v_d_241), LBL_name), heff_get(v_d_241, LBL_key), heff_get(heff_dup(v_g_247), LBL_aliases)));
    return heff_rec(4, shape_222_85_4_32, (V[]){heff_get(heff_dup(v_g_247), LBL_order), heff_get(heff_dup(v_g_247), LBL_entries), v_t_248, heff_get(v_g_247, LBL_broken)});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2etoplevel_2ethawGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2ethawGlobals(a[0], a[1]);
}
Clo g_heff_2etoplevel_2ethawOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ethawOne_entry, 2, 0};

V g_heff_2etoplevel_2ethawOne(V v_acc_240, V v_d_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_get(heff_dup(v_d_241), LBL_body); V r_ = (g_heff_2etoplevel_2eisForeignB(b_0)); heff_drop(b_0); r_; });
  V v_t_245;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = (g_heff_2eglobals_2elookupEntry(heff_get(heff_dup(v_acc_240), LBL_globals), heff_get(heff_dup(v_d_241), LBL_key)));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      v_t_245 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_t_245 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    break;
  }
  case TAG_False: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){heff_get(heff_dup(v_d_241), LBL_key), heff_get(heff_dup(v_acc_240), LBL_keys)});
    V v_t_247 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_d_241), LBL_name), heff_get(v_d_241, LBL_span)});
    V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, heff_get(heff_dup(v_acc_240), LBL_spans)});
    return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){heff_get(heff_dup(v_acc_240), LBL_globals), heff_get(heff_dup(v_acc_240), LBL_diags), v_t_246, heff_get(heff_dup(v_acc_240), LBL_broken), heff_get(heff_dup(v_acc_240), LBL_watches), heff_get(heff_dup(v_acc_240), LBL_tests), v_t_248, heff_get(heff_dup(v_acc_240), LBL_infos), heff_get(v_acc_240, LBL_trace)});
  }
  case TAG_False: {
    V v_g_249 = (g_heff_2etoplevel_2ethawGlobals(heff_dup(v_acc_240), heff_dup(v_d_241)));
    V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_get(heff_dup(v_d_241), LBL_key), heff_get(heff_dup(v_acc_240), LBL_keys)});
    V v_t_2411 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_d_241), LBL_name), heff_get(v_d_241, LBL_span)});
    V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_t_2411, heff_get(heff_dup(v_acc_240), LBL_spans)});
    return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){v_g_249, heff_get(heff_dup(v_acc_240), LBL_diags), v_t_2410, heff_get(heff_dup(v_acc_240), LBL_broken), heff_get(heff_dup(v_acc_240), LBL_watches), heff_get(heff_dup(v_acc_240), LBL_tests), v_t_2412, heff_get(heff_dup(v_acc_240), LBL_infos), heff_get(v_acc_240, LBL_trace)});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2etoplevel_2ethawOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2ethawOne(a[0], a[1]);
}
Clo g_heff_2etoplevel_2ethawDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2etoplevel_2ethawDone_entry, 1, 0};

V g_heff_2etoplevel_2ethawDone(V v_acc_240) {
top: ;
  V v_keys_241 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_240), LBL_keys)));
  V v_spans_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_240), LBL_spans)));
  return heff_rec(9, shape_115_63_153_32_374_335_315_139_346, (V[]){heff_get(heff_dup(v_acc_240), LBL_globals), heff_get(heff_dup(v_acc_240), LBL_diags), v_keys_241, heff_get(heff_dup(v_acc_240), LBL_broken), heff_get(heff_dup(v_acc_240), LBL_watches), heff_get(heff_dup(v_acc_240), LBL_tests), v_spans_242, heff_get(heff_dup(v_acc_240), LBL_infos), heff_get(v_acc_240, LBL_trace)});
}
V g_heff_2etoplevel_2ethawDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2etoplevel_2ethawDone(a[0]);
}