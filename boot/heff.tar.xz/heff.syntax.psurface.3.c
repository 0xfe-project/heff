// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_args 9498020
#define LBL_binders 123633223
#define LBL_body 9524841
#define LBL_ctx 308385
#define LBL_head 9693863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_inner 301714032
#define LBL_keys 9783995
#define LBL_n 328
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_rest 9992347
#define LBL_values 1123329101
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_im__indent[] = {LBL_im, LBL_indent};
static uint32_t shape_n__inner[] = {LBL_n, LBL_inner};
static uint32_t shape_names__hide[] = {LBL_names, LBL_hide};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
static uint32_t shape_names__rest__ctx[] = {LBL_names, LBL_rest, LBL_ctx};
V g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439(V, V, V);
V g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_clo;
V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365(V, V, V, V, V);
V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_clo;
V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps(V, V, V, V, V, V);
V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps_clo;
V g_heff_2esyntax_2epsurface_2earrayNone_get(void);
V g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133(V, V, V, V, V);
V g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_clo;
V g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(V, V, V, V, V, V);
V g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_clo;
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_clo;
V g_heff_2esyntax_2epsurface_2eformerParam(V, V, V);
V g_heff_2esyntax_2epsurface_2eformerParam_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eformerParam_clo;
V g_heff_2esyntax_2epsurface_2eimplicitGroup(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eimplicitGroup_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eimplicitGroup_clo;
V g_heff_2esyntax_2epsurface_2eimplicitName(V, V, V);
V g_heff_2esyntax_2epsurface_2eimplicitName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eimplicitName_clo;
V g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399(V, V, V, V);
V g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_clo;
V g_heff_2esyntax_2epsurface_2enth(V, V);
V g_heff_2esyntax_2epsurface_2enth_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2enth_clo;
V g_heff_2esyntax_2epsurface_2eopHead(V);
V g_heff_2esyntax_2epsurface_2eopHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eopHead_clo;
V g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(V, V, V, V);
V g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_clo;
V g_heff_2esyntax_2epsurface_2espineGo(V, V);
V g_heff_2esyntax_2epsurface_2espineGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2espineGo_clo;
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_clo;
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_clo;
V g_heff_2esyntax_2epsurface_2ewordOf(V);
V g_heff_2esyntax_2epsurface_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2ewordOf_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;

static V g_heff_2esyntax_2epsurface_2earrayNone_val;
static HEFF_ONCE g_heff_2esyntax_2epsurface_2earrayNone_st;
static V g_heff_2esyntax_2epsurface_2earrayNone_init(void) {
  return heff_arrayFromList(NTAG(TAG_Nil));
}
V g_heff_2esyntax_2epsurface_2earrayNone_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epsurface_2earrayNone_st)) return g_heff_2esyntax_2epsurface_2earrayNone_val;
  return heff_global(&g_heff_2esyntax_2epsurface_2earrayNone_val, &g_heff_2esyntax_2epsurface_2earrayNone_st, g_heff_2esyntax_2epsurface_2earrayNone_init);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str0, 4, "plus");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str1, 5, "minus");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str2, 5, "times");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str3, 5, "slash");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str4, 7, "percent");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str5, 2, "eq");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str6, 2, "lt");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str7, 2, "gt");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str8, 3, "amp");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str9, 3, "bar");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str10, 4, "bang");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str11, 5, "caret");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str12, 1, "q");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str13, 2, "at");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str14, 4, "hash");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str15, 6, "dollar");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str16, 5, "tilde");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str17, 5, "colon");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str18, 3, "dot");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str19, 9, "backslash");
Clo g_heff_2esyntax_2epsurface_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2ewordOf_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2ewordOf(V v_c_240) {
top: ;
  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(43LL))) {
    heff_drop(v_c_240);
    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str0)});
  } else {
    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(45LL))) {
      heff_drop(v_c_240);
      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str1)});
    } else {
      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(42LL))) {
        heff_drop(v_c_240);
        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str2)});
      } else {
        if (heff_intEq_c(heff_dup(v_c_240), MK_INT(47LL))) {
          heff_drop(v_c_240);
          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str3)});
        } else {
          if (heff_intEq_c(heff_dup(v_c_240), MK_INT(37LL))) {
            heff_drop(v_c_240);
            return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str4)});
          } else {
            if (heff_intEq_c(heff_dup(v_c_240), MK_INT(61LL))) {
              heff_drop(v_c_240);
              return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str5)});
            } else {
              if (heff_intEq_c(heff_dup(v_c_240), MK_INT(60LL))) {
                heff_drop(v_c_240);
                return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str6)});
              } else {
                if (heff_intEq_c(heff_dup(v_c_240), MK_INT(62LL))) {
                  heff_drop(v_c_240);
                  return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str7)});
                } else {
                  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(38LL))) {
                    heff_drop(v_c_240);
                    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str8)});
                  } else {
                    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(124LL))) {
                      heff_drop(v_c_240);
                      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str9)});
                    } else {
                      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(33LL))) {
                        heff_drop(v_c_240);
                        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str10)});
                      } else {
                        if (heff_intEq_c(heff_dup(v_c_240), MK_INT(94LL))) {
                          heff_drop(v_c_240);
                          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str11)});
                        } else {
                          if (heff_intEq_c(heff_dup(v_c_240), MK_INT(63LL))) {
                            heff_drop(v_c_240);
                            return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str12)});
                          } else {
                            if (heff_intEq_c(heff_dup(v_c_240), MK_INT(64LL))) {
                              heff_drop(v_c_240);
                              return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str13)});
                            } else {
                              if (heff_intEq_c(heff_dup(v_c_240), MK_INT(35LL))) {
                                heff_drop(v_c_240);
                                return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str14)});
                              } else {
                                if (heff_intEq_c(heff_dup(v_c_240), MK_INT(36LL))) {
                                  heff_drop(v_c_240);
                                  return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str15)});
                                } else {
                                  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(126LL))) {
                                    heff_drop(v_c_240);
                                    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str16)});
                                  } else {
                                    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(58LL))) {
                                      heff_drop(v_c_240);
                                      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str17)});
                                    } else {
                                      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(46LL))) {
                                        heff_drop(v_c_240);
                                        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str18)});
                                      } else {
                                        if (heff_intEq_c(v_c_240, MK_INT(92LL))) {
                                          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str19)});
                                        } else {
                                          return NTAG(TAG_Nothing);
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2epsurface_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2ewordOf(a[0]);
}
Clo g_heff_2esyntax_2epsurface_2enth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2enth_entry, 2, 0};

V g_heff_2esyntax_2epsurface_2enth(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epsurface_2enth_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epsurface_2enth(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2epsurface_2espineGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2espineGo_entry, 2, 0};

V g_heff_2esyntax_2epsurface_2espineGo(V v_h_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_SLocal: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SGlobal: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SCode: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SApp: {
    V v_f_245 = heff_field(v_h_240, 0);
    V v_a_246 = heff_field(v_h_240, 1);
    V v_ru_24h_240_24SApp = heff_take_reuse_n(v_h_240, 3ULL, 2);
    V t_0 = v_f_245;
    V t_1 = heff_tag_at_n(v_ru_24h_240_24SApp, TAG_Cons, 2, (V[]){v_a_246, v_acc_241});
    v_h_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_SLam: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SCons: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SProj: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_STag: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SMatch: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SSpecialize: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SIs: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SOpaque: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SAbandon: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SRec: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SFix: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SImplicit: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SPrim: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SMetaApp: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitInt: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitFloat: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitString: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitBytes: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitRune: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitFixed: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitFloat32: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2esyntax_2epsurface_2espineGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2espineGo(a[0], a[1]);
}
Clo g_heff_2esyntax_2epsurface_2eimplicitName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eimplicitName_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2eimplicitName(V v_names_240, V v_i_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_SLocal: {
    V v_x1_244 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24Just = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      switch (heff_tag_of(v_m_245)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_244_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_246 = heff_field(v_m_245, 0);
        heff_take_n(v_m_245, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_244_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_246, v_a_242})});
      }
      default: return heff_nomatch(v_m_245);
      }
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  case TAG_SGlobal: {
    V v_x1_248 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_249 = heff_field(v_x1_248, 0);
      V v_ru_24x1_248_24Just = heff_take_reuse_n(v_x1_248, 1ULL, 1);
      switch (heff_tag_of(v_m_249)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_248_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2410 = heff_field(v_m_249, 0);
        heff_take_n(v_m_249, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_248_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2410, v_a_242})});
      }
      default: return heff_nomatch(v_m_249);
      }
    }
    default: return heff_nomatch(v_x1_248);
    }
  }
  case TAG_SCode: {
    V v_x1_2412 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2413 = heff_field(v_x1_2412, 0);
      V v_ru_24x1_2412_24Just = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
      switch (heff_tag_of(v_m_2413)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2412_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2414 = heff_field(v_m_2413, 0);
        heff_take_n(v_m_2413, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2412_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2414, v_a_242})});
      }
      default: return heff_nomatch(v_m_2413);
      }
    }
    default: return heff_nomatch(v_x1_2412);
    }
  }
  case TAG_SApp: {
    V v_x1_2417 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2418 = heff_field(v_x1_2417, 0);
      V v_ru_24x1_2417_24Just = heff_take_reuse_n(v_x1_2417, 1ULL, 1);
      switch (heff_tag_of(v_m_2418)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2417_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2419 = heff_field(v_m_2418, 0);
        heff_take_n(v_m_2418, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2417_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2419, v_a_242})});
      }
      default: return heff_nomatch(v_m_2418);
      }
    }
    default: return heff_nomatch(v_x1_2417);
    }
  }
  case TAG_SLam: {
    V v_x1_2422 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2423 = heff_field(v_x1_2422, 0);
      V v_ru_24x1_2422_24Just = heff_take_reuse_n(v_x1_2422, 1ULL, 1);
      switch (heff_tag_of(v_m_2423)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2422_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2424 = heff_field(v_m_2423, 0);
        heff_take_n(v_m_2423, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2422_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2424, v_a_242})});
      }
      default: return heff_nomatch(v_m_2423);
      }
    }
    default: return heff_nomatch(v_x1_2422);
    }
  }
  case TAG_SCons: {
    V v_x1_2426 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2426)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2427 = heff_field(v_x1_2426, 0);
      V v_ru_24x1_2426_24Just = heff_take_reuse_n(v_x1_2426, 1ULL, 1);
      switch (heff_tag_of(v_m_2427)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2426_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2428 = heff_field(v_m_2427, 0);
        heff_take_n(v_m_2427, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2426_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2428, v_a_242})});
      }
      default: return heff_nomatch(v_m_2427);
      }
    }
    default: return heff_nomatch(v_x1_2426);
    }
  }
  case TAG_SProj: {
    V v_x1_2431 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2431)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2432 = heff_field(v_x1_2431, 0);
      V v_ru_24x1_2431_24Just = heff_take_reuse_n(v_x1_2431, 1ULL, 1);
      switch (heff_tag_of(v_m_2432)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2431_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2433 = heff_field(v_m_2432, 0);
        heff_take_n(v_m_2432, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2431_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2433, v_a_242})});
      }
      default: return heff_nomatch(v_m_2432);
      }
    }
    default: return heff_nomatch(v_x1_2431);
    }
  }
  case TAG_STag: {
    V v_x1_2436 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2436)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2437 = heff_field(v_x1_2436, 0);
      V v_ru_24x1_2436_24Just = heff_take_reuse_n(v_x1_2436, 1ULL, 1);
      switch (heff_tag_of(v_m_2437)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2436_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2438 = heff_field(v_m_2437, 0);
        heff_take_n(v_m_2437, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2436_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2438, v_a_242})});
      }
      default: return heff_nomatch(v_m_2437);
      }
    }
    default: return heff_nomatch(v_x1_2436);
    }
  }
  case TAG_SMatch: {
    V v_x1_2441 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2441)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2442 = heff_field(v_x1_2441, 0);
      V v_ru_24x1_2441_24Just = heff_take_reuse_n(v_x1_2441, 1ULL, 1);
      switch (heff_tag_of(v_m_2442)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2441_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2443 = heff_field(v_m_2442, 0);
        heff_take_n(v_m_2442, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2441_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2443, v_a_242})});
      }
      default: return heff_nomatch(v_m_2442);
      }
    }
    default: return heff_nomatch(v_x1_2441);
    }
  }
  case TAG_SSpecialize: {
    V v_x1_2447 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2447)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2448 = heff_field(v_x1_2447, 0);
      V v_ru_24x1_2447_24Just = heff_take_reuse_n(v_x1_2447, 1ULL, 1);
      switch (heff_tag_of(v_m_2448)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 3);
        heff_drop_cell(v_ru_24x1_2447_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2449 = heff_field(v_m_2448, 0);
        heff_take_n(v_m_2448, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2447_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2449, v_a_242})});
      }
      default: return heff_nomatch(v_m_2448);
      }
    }
    default: return heff_nomatch(v_x1_2447);
    }
  }
  case TAG_SIs: {
    V v_x1_2451 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2451)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2452 = heff_field(v_x1_2451, 0);
      V v_ru_24x1_2451_24Just = heff_take_reuse_n(v_x1_2451, 1ULL, 1);
      switch (heff_tag_of(v_m_2452)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2451_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2453 = heff_field(v_m_2452, 0);
        heff_take_n(v_m_2452, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2451_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2453, v_a_242})});
      }
      default: return heff_nomatch(v_m_2452);
      }
    }
    default: return heff_nomatch(v_x1_2451);
    }
  }
  case TAG_SOpaque: {
    V v_x1_2454 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2454)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2455 = heff_field(v_x1_2454, 0);
      V v_ru_24x1_2454_24Just = heff_take_reuse_n(v_x1_2454, 1ULL, 1);
      switch (heff_tag_of(v_m_2455)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_2454_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2456 = heff_field(v_m_2455, 0);
        heff_take_n(v_m_2455, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2454_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2456, v_a_242})});
      }
      default: return heff_nomatch(v_m_2455);
      }
    }
    default: return heff_nomatch(v_x1_2454);
    }
  }
  case TAG_SAbandon: {
    V v_x1_2457 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2457)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2458 = heff_field(v_x1_2457, 0);
      V v_ru_24x1_2457_24Just = heff_take_reuse_n(v_x1_2457, 1ULL, 1);
      switch (heff_tag_of(v_m_2458)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_2457_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2459 = heff_field(v_m_2458, 0);
        heff_take_n(v_m_2458, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2457_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2459, v_a_242})});
      }
      default: return heff_nomatch(v_m_2458);
      }
    }
    default: return heff_nomatch(v_x1_2457);
    }
  }
  case TAG_SRec: {
    V v_x1_2461 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2462 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24Just = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      switch (heff_tag_of(v_m_2462)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2461_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2463 = heff_field(v_m_2462, 0);
        heff_take_n(v_m_2462, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2461_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2463, v_a_242})});
      }
      default: return heff_nomatch(v_m_2462);
      }
    }
    default: return heff_nomatch(v_x1_2461);
    }
  }
  case TAG_SFix: {
    V v_x1_2466 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2466)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2467 = heff_field(v_x1_2466, 0);
      V v_ru_24x1_2466_24Just = heff_take_reuse_n(v_x1_2466, 1ULL, 1);
      switch (heff_tag_of(v_m_2467)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2466_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2468 = heff_field(v_m_2467, 0);
        heff_take_n(v_m_2467, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2466_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2468, v_a_242})});
      }
      default: return heff_nomatch(v_m_2467);
      }
    }
    default: return heff_nomatch(v_x1_2466);
    }
  }
  case TAG_SImplicit: {
    V v_n_2469 = heff_field(v_a_242, 0);
    V v_inner_2470 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 3ULL, 2);
    heff_drop(v_names_240);
    heff_drop(v_i_241);
    return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2469, v_inner_2470})});
  }
  case TAG_SPrim: {
    V v_x1_2472 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2472)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2473 = heff_field(v_x1_2472, 0);
      V v_ru_24x1_2472_24Just = heff_take_reuse_n(v_x1_2472, 1ULL, 1);
      switch (heff_tag_of(v_m_2473)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2472_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2474 = heff_field(v_m_2473, 0);
        heff_take_n(v_m_2473, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2472_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2474, v_a_242})});
      }
      default: return heff_nomatch(v_m_2473);
      }
    }
    default: return heff_nomatch(v_x1_2472);
    }
  }
  case TAG_SMetaApp: {
    V v_x1_2478 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2478)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2479 = heff_field(v_x1_2478, 0);
      V v_ru_24x1_2478_24Just = heff_take_reuse_n(v_x1_2478, 1ULL, 1);
      switch (heff_tag_of(v_m_2479)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 3);
        heff_drop_cell(v_ru_24x1_2478_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2480 = heff_field(v_m_2479, 0);
        heff_take_n(v_m_2479, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2478_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2480, v_a_242})});
      }
      default: return heff_nomatch(v_m_2479);
      }
    }
    default: return heff_nomatch(v_x1_2478);
    }
  }
  case TAG_SLitInt: {
    V v_x1_2482 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2482)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2483 = heff_field(v_x1_2482, 0);
      V v_ru_24x1_2482_24Just = heff_take_reuse_n(v_x1_2482, 1ULL, 1);
      switch (heff_tag_of(v_m_2483)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2482_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2484 = heff_field(v_m_2483, 0);
        heff_take_n(v_m_2483, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2482_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2484, v_a_242})});
      }
      default: return heff_nomatch(v_m_2483);
      }
    }
    default: return heff_nomatch(v_x1_2482);
    }
  }
  case TAG_SLitFloat: {
    V v_x1_2486 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2486)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2487 = heff_field(v_x1_2486, 0);
      V v_ru_24x1_2486_24Just = heff_take_reuse_n(v_x1_2486, 1ULL, 1);
      switch (heff_tag_of(v_m_2487)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2486_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2488 = heff_field(v_m_2487, 0);
        heff_take_n(v_m_2487, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2486_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2488, v_a_242})});
      }
      default: return heff_nomatch(v_m_2487);
      }
    }
    default: return heff_nomatch(v_x1_2486);
    }
  }
  case TAG_SLitString: {
    V v_x1_2490 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2490)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2491 = heff_field(v_x1_2490, 0);
      V v_ru_24x1_2490_24Just = heff_take_reuse_n(v_x1_2490, 1ULL, 1);
      switch (heff_tag_of(v_m_2491)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2490_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2492 = heff_field(v_m_2491, 0);
        heff_take_n(v_m_2491, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2490_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2492, v_a_242})});
      }
      default: return heff_nomatch(v_m_2491);
      }
    }
    default: return heff_nomatch(v_x1_2490);
    }
  }
  case TAG_SLitBytes: {
    V v_x1_2494 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2494)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2495 = heff_field(v_x1_2494, 0);
      V v_ru_24x1_2494_24Just = heff_take_reuse_n(v_x1_2494, 1ULL, 1);
      switch (heff_tag_of(v_m_2495)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2494_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2496 = heff_field(v_m_2495, 0);
        heff_take_n(v_m_2495, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2494_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2496, v_a_242})});
      }
      default: return heff_nomatch(v_m_2495);
      }
    }
    default: return heff_nomatch(v_x1_2494);
    }
  }
  case TAG_SLitRune: {
    V v_x1_2498 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2498)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2499 = heff_field(v_x1_2498, 0);
      V v_ru_24x1_2498_24Just = heff_take_reuse_n(v_x1_2498, 1ULL, 1);
      switch (heff_tag_of(v_m_2499)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2498_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_24100 = heff_field(v_m_2499, 0);
        heff_take_n(v_m_2499, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2498_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_24100, v_a_242})});
      }
      default: return heff_nomatch(v_m_2499);
      }
    }
    default: return heff_nomatch(v_x1_2498);
    }
  }
  case TAG_SLitFixed: {
    V v_x1_24103 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_24103)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_24104 = heff_field(v_x1_24103, 0);
      V v_ru_24x1_24103_24Just = heff_take_reuse_n(v_x1_24103, 1ULL, 1);
      switch (heff_tag_of(v_m_24104)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_24103_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_24105 = heff_field(v_m_24104, 0);
        heff_take_n(v_m_24104, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_24103_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_24105, v_a_242})});
      }
      default: return heff_nomatch(v_m_24104);
      }
    }
    default: return heff_nomatch(v_x1_24103);
    }
  }
  case TAG_SLitFloat32: {
    V v_x1_24107 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_24107)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_24108 = heff_field(v_x1_24107, 0);
      V v_ru_24x1_24107_24Just = heff_take_reuse_n(v_x1_24107, 1ULL, 1);
      switch (heff_tag_of(v_m_24108)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_24107_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_24109 = heff_field(v_m_24108, 0);
        heff_take_n(v_m_24108, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_24107_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_24109, v_a_242})});
      }
      default: return heff_nomatch(v_m_24108);
      }
    }
    default: return heff_nomatch(v_x1_24107);
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2esyntax_2epsurface_2eimplicitName_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eimplicitName(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str15, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str18, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str21, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str23, 0, "");
Clo g_heff_2esyntax_2epsurface_2eopHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eopHead_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2eopHead(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str0);
  }
  case TAG_SGlobal: {
    V v_x_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_242);
  }
  case TAG_SCode: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str1);
  }
  case TAG_SApp: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str2);
  }
  case TAG_SLam: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str3);
  }
  case TAG_SCons: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str4);
  }
  case TAG_SProj: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str5);
  }
  case TAG_STag: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str6);
  }
  case TAG_SMatch: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str7);
  }
  case TAG_SSpecialize: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str8);
  }
  case TAG_SIs: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str9);
  }
  case TAG_SOpaque: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str10);
  }
  case TAG_SAbandon: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str11);
  }
  case TAG_SRec: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str12);
  }
  case TAG_SFix: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str13);
  }
  case TAG_SImplicit: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str14);
  }
  case TAG_SPrim: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str15);
  }
  case TAG_SMetaApp: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str16);
  }
  case TAG_SLitInt: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str17);
  }
  case TAG_SLitFloat: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str18);
  }
  case TAG_SLitString: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str19);
  }
  case TAG_SLitBytes: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str20);
  }
  case TAG_SLitRune: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str21);
  }
  case TAG_SLitFixed: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str22);
  }
  case TAG_SLitFloat32: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str23);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epsurface_2eopHead_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epsurface_2eopHead(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2epsurface_2eimplicitGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eimplicitGroup_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2eimplicitGroup(V v_names_240, V v_u_241, V v_rest_242, V v_ctx_243) {
top: ;
  switch (heff_tag_of(v_rest_242)) {
  case TAG_SU: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SDecode: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SFunction: {
    V v_rest2_247 = heff_dup(heff_field(v_rest_242, 1));
    V v_rest3_248 = heff_dup(heff_field(v_rest_242, 2));
    V v_rest4_249 = heff_dup(heff_field(v_rest_242, 3));
    V v_rest5_2410 = heff_dup(heff_field(v_rest_242, 4));
    switch (heff_tag_of(v_rest2_247)) {
    case TAG_SU: {
      V v_u_27_2411 = heff_field(v_rest2_247, 0);
      heff_take_n(v_rest2_247, 1ULL, 1);
      switch (heff_tag_of(v_rest3_248)) {
      case TAG_MkAbs: {
        V v_y_2412 = heff_field(v_rest3_248, 0);
        V v_b_2413 = heff_field(v_rest3_248, 1);
        V v_ru_24rest3_248_24MkAbs = heff_take_reuse_n(v_rest3_248, 3ULL, 2);
        switch (heff_tag_of(v_rest4_249)) {
        case TAG_Expl: {
          heff_drop(v_rest5_2410);
          heff_drop(v_u_27_2411);
          heff_drop(v_y_2412);
          heff_drop(v_b_2413);
          heff_drop_cell(v_ru_24rest3_248_24MkAbs, 2);
          return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_rest5_2410)) {
          case TAG_Nothing: {
            V v_t_2414;
            switch (heff_tag_of(v_u_241)) {
            case TAG_SmallU: {
              switch (heff_tag_of(v_u_27_2411)) {
              case TAG_SmallU: {
                v_t_2414 = NTAG(TAG_True);
                break;
              }
              case TAG_LargeU: {
                v_t_2414 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_u_27_2411);
              }
              break;
            }
            case TAG_LargeU: {
              switch (heff_tag_of(v_u_27_2411)) {
              case TAG_SmallU: {
                v_t_2414 = NTAG(TAG_False);
                break;
              }
              case TAG_LargeU: {
                v_t_2414 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_u_27_2411);
              }
              break;
            }
            default: heff_nomatch(v_u_241);
            }
            if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
              heff_drop_tag(v_rest_242, 5);
              heff_drop(v_t_2414);
              V v_t_2415 = heff_tag_at_n(v_ru_24rest3_248_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_y_2412), NTAG(TAG_Nil)});
              V v_t_2416 = (g_prelude_2e_2b_2b(v_names_240, v_t_2415));
              V t_0 = v_t_2416;
              V t_1 = v_u_241;
              V t_2 = v_b_2413;
              V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_2412, v_ctx_243});
              v_names_240 = t_0;
              v_u_241 = t_1;
              v_rest_242 = t_2;
              v_ctx_243 = t_3;
              goto top;
            } else {
              heff_drop(v_y_2412);
              heff_drop(v_b_2413);
              heff_drop_cell(v_ru_24rest3_248_24MkAbs, 2);
              heff_drop(v_t_2414);
              return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
            }
          }
          case TAG_Just: {
            heff_take_n(v_rest5_2410, 0ULL, 1);
            heff_drop(v_u_27_2411);
            heff_drop(v_y_2412);
            heff_drop(v_b_2413);
            heff_drop_cell(v_ru_24rest3_248_24MkAbs, 2);
            return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
          }
          default: return heff_nomatch(v_rest5_2410);
          }
        }
        case TAG_Inst: {
          heff_drop(v_rest5_2410);
          heff_drop(v_u_27_2411);
          heff_drop(v_y_2412);
          heff_drop(v_b_2413);
          heff_drop_cell(v_ru_24rest3_248_24MkAbs, 2);
          return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
        }
        default: return heff_nomatch(v_rest4_249);
        }
      }
      case TAG_AbsConst: {
        heff_take_n(v_rest3_248, 0ULL, 1);
        heff_drop(v_rest4_249);
        heff_drop(v_rest5_2410);
        heff_drop(v_u_27_2411);
        return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
      }
      default: return heff_nomatch(v_rest3_248);
      }
    }
    case TAG_SDecode: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SFunction: {
      heff_take_n(v_rest2_247, 0ULL, 5);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SRecord: {
      heff_take_n(v_rest2_247, 0ULL, 3);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SSum: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SIsTy: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimInt: {
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimFloat: {
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimString: {
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimRune: {
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimArray: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SFixed: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    default: return heff_nomatch(v_rest2_247);
    }
  }
  case TAG_SRecord: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SSum: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SIsTy: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimInt: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimFloat: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimString: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimRune: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimArray: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SFixed: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  default: return heff_nomatch(v_rest_242);
  }
}
V g_heff_2esyntax_2epsurface_2eimplicitGroup_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epsurface_2eimplicitGroup(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_str0, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_str2, 1, "(");
Clo g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_entry, 5, 0};

V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365(V v_c_240, V v_xs_241, V v_names_242, V v_i_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_xs_241);
    heff_drop(v_names_242);
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x6_244, 0);
    V v_rest_246 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_247 = (g_heff_2esyntax_2epsurface_2eimplicitName(heff_dup(v_names_242), heff_dup(v_i_243), heff_dup(v_a_245)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      V v_t_248 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_241), v_a_245));
      V v_cell_249 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = (g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps(v_c_240, v_xs_241, v_names_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_rest_246, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    case TAG_Just: {
      V v_imp_2411 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      heff_drop(v_a_245);
      V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 1, 2);
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x6_244_24Cons, 2);
        heff_drop_rec(v_imp_2411, 2);
        heff_drop(v_t_2412);
        V t_0 = v_c_240;
        V t_1 = v_xs_241;
        V t_2 = v_names_242;
        V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
        V t_4 = v_rest_246;
        v_c_240 = t_0;
        v_xs_241 = t_1;
        v_names_242 = t_2;
        v_i_243 = t_3;
        v_x6_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_2412);
        V v_t_2413 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), heff_take_field(v_imp_2411, 1)));
        V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_str0), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_str1)));
        V v_t_2415 = heff_strAppend(heff_get_n(v_imp_2411, 0, 2), v_t_2414);
        V v_cell_2416 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_str2), v_t_2415), heff_hole()});
        V v_u_2417 = (g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps(v_c_240, v_xs_241, v_names_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_rest_246, heff_dup(v_cell_2416)));
        heff_drop(v_u_2417);
        return v_cell_2416;
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str2, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str3, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str5, 1, ")");
Clo g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399(V v_c_240, V v_p_241, V v_xs_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_t_244, 0);
    V v_xs_246 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_248 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(0LL), heff_take_field(v_l_243, 0), heff_get_n(v_l_243, 2, 3)));
  V v_t_249 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str2), v_t_248));
  V v_s_2410 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str3), v_t_249);
  if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str4), heff_strAppend(v_s_2410, ((V)&g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str5)));
  } else {
    return v_s_2410;
  }
}
V g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str4, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str5, 1, "\012");
Clo g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439(V v_inner_240, V v_xs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_t_243 = heff_field(v_x4_242, 0);
    V v_x42_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_244)) {
    case TAG_MkPair: {
      V v_ys_245 = heff_field(v_x42_244, 0);
      V v_body_246 = heff_field(v_x42_244, 1);
      V v_x2_247 = (g_list_2ereplicate(heff_dup(heff_rfield(v_inner_240, 1)), ((V)&g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str0)));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str3); V a_1 = heff_dup(v_t_243); V b_2 = heff_arrayToList(heff_dup(v_ys_245)); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_xs_2412 = (g_list_2efoldl_24s1370882877x364361272(v_xs_241, heff_arrayToList(heff_dup(v_ys_245))));
      V v_t_2413 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_inner_240, MK_INT(0LL), v_xs_2412, heff_dup(v_body_246)));
      V v_t_2414 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str4), v_t_2413));
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str5), heff_strAppend(v_t_2410, v_t_2414));
    }
    default: return heff_nomatch(v_x42_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str11, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str12, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str13, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str14, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str15, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str16, 6, "String");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str17, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str18, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str19, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str20, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str21, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str22, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str23, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str24, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str25, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str26, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str27, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str28, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str29, 7, "Float32");
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam0(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam0, 2, 0};
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam1(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam1, 2, 0};
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam2(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam2, 2, 0};
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam4(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam4, 2, 0};
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam3(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam7(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam7, 2, 0};
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam6(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam5(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam8(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam8, 2, 0};
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam9(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam9, 2, 0};
Clo g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(V v_lit_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    V v_t_248 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam0_clo), NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){v_t_248, v_lit_240}), v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_249 = heff_field(v_x5_243, 0);
    V v_dom_2410 = heff_field(v_x5_243, 1);
    V v_cod_2411 = heff_field(v_x5_243, 2);
    V v_implicit_2412 = heff_field(v_x5_243, 3);
    V v_dflt_2413 = heff_field(v_x5_243, 4);
    V v_s_2421;
    switch (heff_tag_of(v_dflt_2413)) {
    case TAG_Nothing: {
      V v_t_2416 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam1_clo), NTAG(TAG_False)});
      v_s_2421 = (g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(heff_rec_n(2, shape_im__indent, (V[]){v_t_2416, v_lit_240}), v_xs_242, v_level_249, v_dom_2410, heff_dup(v_cod_2411), v_implicit_2412));
      break;
    }
    case TAG_Just: {
      V v_d_2417 = heff_field(v_dflt_2413, 0);
      V v_t_2420 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam2_clo), NTAG(TAG_False)});
      v_s_2421 = (g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133(heff_rec_n(2, shape_im__indent, (V[]){v_t_2420, v_lit_240}), v_xs_242, v_dom_2410, heff_dup(v_cod_2411), heff_dup(v_d_2417)));
      break;
    }
    default: heff_nomatch(v_dflt_2413);
    }
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str2), heff_strAppend(v_s_2421, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str3)));
    } else {
      return v_s_2421;
    }
  }
  case TAG_SRecord: {
    V v_fs_2424 = heff_field(v_x5_243, 1);
    V v_ds_2425 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_t_2426 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2424, 0)));
    V v_t_2427 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2424, 2)));
    V v_fs_2428 = (g_heff_2eutil_2edict_2ezipKV(v_t_2426, v_t_2427));
    V v_t_2429 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2435 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam3, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2425)}); V a_1 = v_t_2429; V a_2 = v_fs_2428; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2428); r_; });
    V v_t_2436 = heff_get_n(v_acc_2435, 1, 2);
    V v_t_2439;
    switch (heff_tag_of(v_t_2436)) {
    case TAG_Nil: {
      v_t_2439 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_t_2436, 0);
      V v_xs_2438 = heff_field(v_t_2436, 1);
      heff_take_n(v_t_2436, 3ULL, 2);
      v_t_2439 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str5); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
      break;
    }
    default: heff_nomatch(v_t_2436);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str6), heff_strAppend(v_t_2439, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str7)));
  }
  case TAG_SSum: {
    V v_vs_2440 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_t_2441 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2440, 0)));
    V v_t_2442 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2440, 2)));
    V v_t_2443 = (g_heff_2eutil_2edict_2ezipKV(v_t_2441, v_t_2442));
    V v_x2_2455 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam5, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2443));
    V v_t_2458;
    switch (heff_tag_of(v_x2_2455)) {
    case TAG_Nil: {
      v_t_2458 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2456 = heff_field(v_x2_2455, 0);
      V v_xs_2457 = heff_field(v_x2_2455, 1);
      heff_take_n(v_x2_2455, 3ULL, 2);
      v_t_2458 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str11); V a_1 = v_x_2456; V a_2 = v_xs_2457; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2457); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2455);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str12), heff_strAppend(v_t_2458, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str13)));
  }
  case TAG_SIsTy: {
    V v_t2_2459 = heff_field(v_x5_243, 0);
    V v_t_2462 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam8_clo), NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){v_t_2462, v_lit_240}), v_p_241, v_xs_242, v_t2_2459);
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str14);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str15);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str16);
  }
  case TAG_SPrimRune: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str17);
  }
  case TAG_SPrimArray: {
    V v_a_2463 = heff_field(v_x5_243, 0);
    V v_t_2466 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam9_clo), NTAG(TAG_False)});
    V v_t_2467 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){v_t_2466, v_lit_240}), MK_INT(2LL), v_xs_242, v_a_2463));
    V v_s_2468 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str18), v_t_2467);
    if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str19), heff_strAppend(v_s_2468, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str20)));
    } else {
      return v_s_2468;
    }
  }
  case TAG_SFixed: {
    V v_w_2470 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2470)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str21);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str22);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str23);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str24);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str25);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str26);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str27);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str28);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str29);
    }
    default: return heff_nomatch(v_w_2470);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  heff_drop(v_a_246);
  heff_drop(v_a_247);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam1(V self, V *args) {
  V v_a_2414 = args[0];
  V v_a_2415 = args[1];
  heff_drop(v_a_2414);
  heff_drop(v_a_2415);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam2(V self, V *args) {
  V v_a_2418 = args[0];
  V v_a_2419 = args[1];
  heff_drop(v_a_2418);
  heff_drop(v_a_2419);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam4(V self, V *args) {
  V v_a_2432 = args[0];
  V v_a_2433 = args[1];
  heff_drop(v_a_2432);
  heff_drop(v_a_2433);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam3(V self, V *args) {
  V v_acc_2430 = args[0];
  V v_f_2431 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam4_clo), NTAG(TAG_False)});
  return (g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(heff_rec_n(2, shape_im__indent, (V[]){v_t_2434, v_lit_240}), v_ds_2425, v_acc_2430, v_f_2431));
}
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam7(V self, V *args) {
  V v_a_2448 = args[0];
  V v_a_2449 = args[1];
  heff_drop(v_a_2448);
  heff_drop(v_a_2449);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam6(V self, V *args) {
  V v_t2_2447 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam7_clo), NTAG(TAG_False)});
  return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_t_2450, v_lit_240}); V a_1 = MK_INT(2LL); V a_2 = v_xs_242; V a_3 = v_t2_2447; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2447); r_; });
}
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam5(V self, V *args) {
  V v_v_2444 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2444)) {
  case TAG_MkPair: {
    V v_t_2445 = heff_field(v_v_2444, 0);
    V v_ts_2446 = heff_field(v_v_2444, 1);
    V v_ru_24v_2444_24MkPair = heff_take_reuse_n(v_v_2444, 3ULL, 2);
    V v_t_2451 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam6, 1, 2, (V[]){v_lit_240, v_xs_242}), heff_arrayToList(v_ts_2446)));
    V v_x2_2452 = heff_tag_at_n(v_ru_24v_2444_24MkPair, TAG_Cons, 2, (V[]){v_t_2445, v_t_2451});
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str8);
    }
    case TAG_Cons: {
      V v_x_2453 = heff_field(v_x2_2452, 0);
      V v_xs_2454 = heff_field(v_x2_2452, 1);
      heff_take_n(v_x2_2452, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_str9); V a_1 = v_x_2453; V a_2 = v_xs_2454; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2454); r_; });
    }
    default: return heff_nomatch(v_x2_2452);
    }
  }
  default: return heff_nomatch(v_v_2444);
  }
}
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam8(V self, V *args) {
  V v_a_2460 = args[0];
  V v_a_2461 = args[1];
  heff_drop(v_a_2460);
  heff_drop(v_a_2461);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
V g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456_lam9(V self, V *args) {
  V v_a_2464 = args[0];
  V v_a_2465 = args[1];
  heff_drop(v_a_2464);
  heff_drop(v_a_2465);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str1, 8, " : Type)");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str5, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str6, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str7, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str8, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str10, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str11, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str12, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str13, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str14, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str15, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str16, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str17, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str18, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str19, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str20, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str21, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str22, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str23, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str24, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str25, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str26, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str27, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str28, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str29, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str30, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str31, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str32, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str33, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str34, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str35, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str36, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str37, 1, "(");
Clo g_heff_2esyntax_2epsurface_2eformerParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eformerParam_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2eformerParam(V v_ns_240, V v_x_241, V v_dom_242) {
top: ;
  switch (heff_tag_of(v_dom_242)) {
  case TAG_SU: {
    V v_dom1_243 = heff_field(v_dom_242, 0);
    switch (heff_tag_of(v_dom1_243)) {
    case TAG_SmallU: {
      heff_drop(v_ns_240);
      if (heff_intLe_c(MK_INT(65LL), heff_strByteAt(heff_dup(v_x_241), MK_INT(0LL)))) {
        if (heff_intLe_c(heff_strByteAt(heff_dup(v_x_241), MK_INT(0LL)), MK_INT(90LL))) {
          return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str0), heff_strAppend(v_x_241, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str1)));
        } else {
          return v_x_241;
        }
      } else {
        return v_x_241;
      }
    }
    case TAG_LargeU: {
      V v_t_246 = (g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
      V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str2), heff_strAppend(v_t_246, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str3)));
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str4), heff_strAppend(v_x_241, v_t_247));
    }
    default: return heff_nomatch(v_dom1_243);
    }
  }
  case TAG_SDecode: {
    V v_t_249 = (g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str5), heff_strAppend(v_t_249, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str6)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str7), heff_strAppend(v_x_241, v_t_2410));
  }
  case TAG_SFunction: {
    V v_t_2416 = (g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str8), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str9)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str10), heff_strAppend(v_x_241, v_t_2417));
  }
  case TAG_SRecord: {
    V v_t_2421 = (g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str11), heff_strAppend(v_t_2421, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str12)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str13), heff_strAppend(v_x_241, v_t_2422));
  }
  case TAG_SSum: {
    V v_t_2424 = (g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str14), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str15)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str16), heff_strAppend(v_x_241, v_t_2425));
  }
  case TAG_SIsTy: {
    V v_t_2427 = (g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str17), heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str18)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str19), heff_strAppend(v_x_241, v_t_2428));
  }
  case TAG_SPrimInt: {
    V v_t_2429 = (g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str20), heff_strAppend(v_t_2429, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str21)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str22), heff_strAppend(v_x_241, v_t_2430));
  }
  case TAG_SPrimFloat: {
    V v_t_2431 = (g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2432 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str23), heff_strAppend(v_t_2431, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str24)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str25), heff_strAppend(v_x_241, v_t_2432));
  }
  case TAG_SPrimString: {
    V v_t_2433 = (g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str26), heff_strAppend(v_t_2433, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str27)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str28), heff_strAppend(v_x_241, v_t_2434));
  }
  case TAG_SPrimRune: {
    V v_t_2435 = (g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2436 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str29), heff_strAppend(v_t_2435, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str30)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str31), heff_strAppend(v_x_241, v_t_2436));
  }
  case TAG_SPrimArray: {
    V v_t_2438 = (g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str32), heff_strAppend(v_t_2438, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str33)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str34), heff_strAppend(v_x_241, v_t_2439));
  }
  case TAG_SFixed: {
    V v_t_2441 = (g_heff_2esyntax_2epsurface_2etyF_24s1965253604x732399456(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    V v_t_2442 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str35), heff_strAppend(v_t_2441, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str36)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str37), heff_strAppend(v_x_241, v_t_2442));
  }
  default: return heff_nomatch(v_dom_242);
  }
}
V g_heff_2esyntax_2epsurface_2eformerParam_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epsurface_2eformerParam(a[0], a[1], a2); heff_drop(a2); return r;
}