// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Bin 14227
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_MkArms 12052
#define TAG_MkArmsVals 35622
#define TAG_MkRes 5766
#define TAG_MkResVals 58586
#define TAG_MkSeen 11336
#define TAG_MkSeenVals 17452
#define TAG_MkTest 41567
#define TAG_Tip 31527
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_body 9524841
#define LBL_byKey 295543458
#define LBL_callers 780494982
#define LBL_callersOf 583887482
#define LBL_calls 295783919
#define LBL_consts 592362651
#define LBL_dirty 296951788
#define LBL_escapes 914714193
#define LBL_fix 310927
#define LBL_forwards 1228451848
#define LBL_gathered 1327153563
#define LBL_given 299725719
#define LBL_grown 299987669
#define LBL_ints 9732907
#define LBL_key 315609
#define LBL_marking 1071112247
#define LBL_marks 305024864
#define LBL_numeric 378927440
#define LBL_params 951713969
#define LBL_ranges 1008858625
#define LBL_tests 311609915
static uint32_t shape_fix__dirty__gathered[] = {LBL_fix, LBL_dirty, LBL_gathered};
static uint32_t shape_numeric__given__calls__ints__escapes[] = {LBL_numeric, LBL_given, LBL_calls, LBL_ints, LBL_escapes};
static uint32_t shape_params__consts__marking[] = {LBL_params, LBL_consts, LBL_marking};
static uint32_t shape_params__grown__marks[] = {LBL_params, LBL_grown, LBL_marks};
static uint32_t shape_params__numeric__forwards[] = {LBL_params, LBL_numeric, LBL_forwards};
V g_heff_2ecompile_2eranges_2eabsorb(V, V, V);
V g_heff_2ecompile_2eranges_2eabsorb_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eabsorb_clo;
V g_heff_2ecompile_2eranges_2eabsorbOne(V, V);
V g_heff_2ecompile_2eranges_2eabsorbOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eabsorbOne_clo;
V g_heff_2ecompile_2eranges_2eandR(V, V);
V g_heff_2ecompile_2eranges_2eandR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eandR_clo;
V g_heff_2ecompile_2eranges_2eanyRange_get(void);
V g_heff_2ecompile_2eranges_2earmSeen_24tok2(V, V, V);
V g_heff_2ecompile_2eranges_2earmSeen_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2earmSeen_24tok2_clo;
V g_heff_2ecompile_2eranges_2econdRefine(V, V, V, V);
V g_heff_2ecompile_2eranges_2econdRefine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2econdRefine_clo;
V g_heff_2ecompile_2eranges_2econdTests(V, V);
V g_heff_2ecompile_2eranges_2econdTests_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2econdTests_clo;
HeffT3 g_heff_2ecompile_2eranges_2econsArm_24cpr(V, V, V, V);
V g_heff_2ecompile_2eranges_2econstOne(V, V);
V g_heff_2ecompile_2eranges_2econstOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2econstOne_clo;
V g_heff_2ecompile_2eranges_2eemptyScan_get(void);
V g_heff_2ecompile_2eranges_2efnOf(V, V);
V g_heff_2ecompile_2eranges_2efnOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2efnOf_clo;
V g_heff_2ecompile_2eranges_2egatherDef(V, V);
V g_heff_2ecompile_2eranges_2egatherDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherDef_clo;
HeffT2 g_heff_2ecompile_2eranges_2egatherMany_24cpr(V, V, V, V);
V g_heff_2ecompile_2eranges_2egrownTo(V, V, V, V);
V g_heff_2ecompile_2eranges_2egrownTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egrownTo_clo;
HeffT2 g_heff_2ecompile_2eranges_2eheld_24cpr(V, V, V, V);
V g_heff_2ecompile_2eranges_2eisComparison(V);
V g_heff_2ecompile_2eranges_2eisComparison_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eisComparison_clo;
V g_heff_2ecompile_2eranges_2ejoin(V, V);
V g_heff_2ecompile_2eranges_2ejoin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoin_clo;
V g_heff_2ecompile_2eranges_2ejoinedFor(V, V, V, V);
V g_heff_2ecompile_2eranges_2ejoinedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoinedFor_clo;
V g_heff_2ecompile_2eranges_2emarksWith(V, V, V);
V g_heff_2ecompile_2eranges_2emarksWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emarksWith_clo;
V g_heff_2ecompile_2eranges_2ematterOne(V, V, V);
V g_heff_2ecompile_2eranges_2ematterOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ematterOne_clo;
V g_heff_2ecompile_2eranges_2emattering(V, V, V);
V g_heff_2ecompile_2eranges_2emattering_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emattering_clo;
V g_heff_2ecompile_2eranges_2emeet(V, V);
V g_heff_2ecompile_2eranges_2emeet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emeet_clo;
V g_heff_2ecompile_2eranges_2enarrowOnce(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowOnce_clo;
V g_heff_2ecompile_2eranges_2enarrowTo(V, V, V);
V g_heff_2ecompile_2eranges_2enarrowTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowTo_clo;
V g_heff_2ecompile_2eranges_2enarrowWith(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowWith_clo;
V g_heff_2ecompile_2eranges_2eoperandRange(V, V, V);
V g_heff_2ecompile_2eranges_2eoperandRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eoperandRange_clo;
HeffT2 g_heff_2ecompile_2eranges_2eplaceOf_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2eprimRange(V, V);
V g_heff_2ecompile_2eranges_2eprimRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eprimRange_clo;
V g_heff_2ecompile_2eranges_2erangesEq(V, V);
V g_heff_2ecompile_2eranges_2erangesEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangesEq_clo;
V g_heff_2ecompile_2eranges_2erefine(V, V, V, V);
V g_heff_2ecompile_2eranges_2erefine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erefine_clo;
V g_heff_2ecompile_2eranges_2erootGo(V, V, V);
V g_heff_2ecompile_2eranges_2erootGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erootGo_clo;
V g_heff_2ecompile_2eranges_2erootTo(V, V, V);
V g_heff_2ecompile_2eranges_2erootTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erootTo_clo;
V g_heff_2ecompile_2eranges_2eroundOf(V, V, V, V);
V g_heff_2ecompile_2eranges_2eroundOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eroundOf_clo;
V g_heff_2ecompile_2eranges_2erounds(V, V, V, V);
V g_heff_2ecompile_2eranges_2erounds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erounds_clo;
V g_heff_2ecompile_2eranges_2estartParams(V, V);
V g_heff_2ecompile_2eranges_2estartParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2estartParams_clo;
V g_heff_2ecompile_2eranges_2etestOf(V, V);
V g_heff_2ecompile_2eranges_2etestOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etestOf_clo;
V g_heff_2ecompile_2eranges_2etrimHigh(V, V);
V g_heff_2ecompile_2eranges_2etrimHigh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimHigh_clo;
V g_heff_2ecompile_2eranges_2etrimHigh_24tok1(V, V, V);
V g_heff_2ecompile_2eranges_2etrimHigh_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimHigh_24tok1_clo;
V g_heff_2ecompile_2eranges_2etrimHigh_24tok2(V, V, V);
V g_heff_2ecompile_2eranges_2etrimHigh_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimHigh_24tok2_clo;
V g_heff_2ecompile_2eranges_2etrimLow(V, V);
V g_heff_2ecompile_2eranges_2etrimLow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimLow_clo;
V g_heff_2ecompile_2eranges_2ewalkArms(V, V, V, V, V);
V g_heff_2ecompile_2eranges_2ewalkArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkArms_clo;
HeffT3 g_heff_2ecompile_2eranges_2ewalkArms_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eranges_2ewalkCond(V, V, V, V);
V g_heff_2ecompile_2eranges_2ewalkCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkCond_clo;
V g_heff_2ecompile_2eranges_2ewalkGo(V, V, V);
V g_heff_2ecompile_2eranges_2ewalkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkGo_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewalkMany_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithRange_clo;
V g_heff_2ecompile_2eranges_2ewithTest(V, V, V);
V g_heff_2ecompile_2eranges_2ewithTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithTest_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewordOf_24cpr(V, V, V);
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s37738078x926874390(V, V, V, V);
V g_list_2efoldl_24s37738078x926874390_entry(V self, V *a);
extern Clo g_list_2efoldl_24s37738078x926874390_clo;
V g_list_2efoldl_24s405709498x1837254440(V, V);
V g_list_2efoldl_24s405709498x1837254440_entry(V self, V *a);
extern Clo g_list_2efoldl_24s405709498x1837254440_clo;
V g_list_2efoldl_24s518632429x1911716206(V, V);
V g_list_2efoldl_24s518632429x1911716206_entry(V self, V *a);
extern Clo g_list_2efoldl_24s518632429x1911716206_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1792553290x233563724(V);
V g_list_2emap_24s1792553290x233563724_entry(V self, V *a);
extern Clo g_list_2emap_24s1792553290x233563724_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s258116700x992061112(V, V);
V g_list_2emap_24s258116700x992061112_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_clo;
V g_list_2ezipWith_24s1026658656x682908126(V, V);
V g_list_2ezipWith_24s1026658656x682908126_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1026658656x682908126_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s1604775524x1614188687(V, V, V);
V g_list_2ezipWith_24s1604775524x1614188687_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1604775524x1614188687_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2emap_2edelete_24s1614046289x1611773644(V, V);
V g_std_2emap_2edelete_24s1614046289x1611773644_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s1614046289x1611773644_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2eranges_2emeet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emeet_entry, 2, 0};

V g_heff_2ecompile_2eranges_2emeet(V v_r_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_r_240)) {
  case TAG_Unreached: {
    heff_drop(v_s_241);
    return NTAG(TAG_Unreached);
  }
  case TAG_Within: {
    V v_a_242 = heff_field(v_r_240, 0);
    V v_b_243 = heff_field(v_r_240, 1);
    V v_ru_24r_240_24Within = heff_take_reuse_n(v_r_240, 3ULL, 2);
    switch (heff_tag_of(v_s_241)) {
    case TAG_Unreached: {
      heff_drop(v_a_242);
      heff_drop(v_b_243);
      heff_drop_cell(v_ru_24r_240_24Within, 2);
      return NTAG(TAG_Unreached);
    }
    case TAG_Within: {
      V v_c_244 = heff_field(v_s_241, 0);
      V v_d_245 = heff_field(v_s_241, 1);
      heff_take_n(v_s_241, 3ULL, 2);
      V v_x1_249;
      switch (heff_tag_of(v_a_242)) {
      case TAG_Nothing: {
        v_x1_249 = v_c_244;
        break;
      }
      case TAG_Just: {
        V v_a_246 = heff_field(v_a_242, 0);
        V v_ru_24a_242_24Just = heff_take_reuse_n(v_a_242, 1ULL, 1);
        switch (heff_tag_of(v_c_244)) {
        case TAG_Nothing: {
          v_x1_249 = heff_tag_at_n(v_ru_24a_242_24Just, TAG_Just, 1, (V[]){v_a_246});
          break;
        }
        case TAG_Just: {
          V v_b_247 = heff_field(v_c_244, 0);
          heff_take_n(v_c_244, 1ULL, 1);
          V v_t_248;
          if (heff_intLt_c_lent(v_a_246, v_b_247, 0)) {
            heff_drop(v_a_246);
            v_t_248 = v_b_247;
          } else {
            heff_drop(v_b_247);
            v_t_248 = v_a_246;
          }
          v_x1_249 = heff_tag_at_n(v_ru_24a_242_24Just, TAG_Just, 1, (V[]){v_t_248});
          break;
        }
        default: heff_nomatch(v_c_244);
        }
        break;
      }
      default: heff_nomatch(v_a_242);
      }
      V v_x2_2413;
      switch (heff_tag_of(v_b_243)) {
      case TAG_Nothing: {
        v_x2_2413 = v_d_245;
        break;
      }
      case TAG_Just: {
        V v_a_2410 = heff_field(v_b_243, 0);
        V v_ru_24b_243_24Just = heff_take_reuse_n(v_b_243, 1ULL, 1);
        switch (heff_tag_of(v_d_245)) {
        case TAG_Nothing: {
          v_x2_2413 = heff_tag_at_n(v_ru_24b_243_24Just, TAG_Just, 1, (V[]){v_a_2410});
          break;
        }
        case TAG_Just: {
          V v_b_2411 = heff_field(v_d_245, 0);
          heff_take_n(v_d_245, 1ULL, 1);
          V v_t_2412;
          if (heff_intLt_c_lent(v_a_2410, v_b_2411, 0)) {
            heff_drop(v_b_2411);
            v_t_2412 = v_a_2410;
          } else {
            heff_drop(v_a_2410);
            v_t_2412 = v_b_2411;
          }
          v_x2_2413 = heff_tag_at_n(v_ru_24b_243_24Just, TAG_Just, 1, (V[]){v_t_2412});
          break;
        }
        default: heff_nomatch(v_d_245);
        }
        break;
      }
      default: heff_nomatch(v_b_243);
      }
      switch (heff_tag_of(v_x1_249)) {
      case TAG_Nothing: {
        return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_x1_249, v_x2_2413});
      }
      case TAG_Just: {
        V v_lo_2414 = heff_dup(heff_field(v_x1_249, 0));
        switch (heff_tag_of(v_x2_2413)) {
        case TAG_Nothing: {
          heff_drop(v_lo_2414);
          return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_x1_249, v_x2_2413});
        }
        case TAG_Just: {
          V v_hi_2415 = heff_field(v_x2_2413, 0);
          heff_take_n(v_x2_2413, 1ULL, 1);
          heff_drop_tag(v_x1_249, 1);
          if (heff_intLt_c_lent(v_hi_2415, v_lo_2414, 0)) {
            heff_drop_cell(v_ru_24r_240_24Within, 2);
            heff_drop(v_lo_2414);
            heff_drop(v_hi_2415);
            return NTAG(TAG_Unreached);
          } else {
            return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_lo_2414}), heff_tag_n(TAG_Just, 1, (V[]){v_hi_2415})});
          }
        }
        default: return heff_nomatch(v_x2_2413);
        }
      }
      default: return heff_nomatch(v_x1_249);
      }
    }
    default: return heff_nomatch(v_s_241);
    }
  }
  default: return heff_nomatch(v_r_240);
  }
}
V g_heff_2ecompile_2eranges_2emeet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2emeet(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2eandR_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eandR_entry, 2, 0};

V g_heff_2ecompile_2eranges_2eandR(V v_a_240, V v_b_241) {
top: ;
  V v_t_248;
  switch (heff_tag_of(v_a_240)) {
  case TAG_Unreached: {
    v_t_248 = NTAG(TAG_False);
    break;
  }
  case TAG_Within: {
    V v_lo_242 = heff_dup(heff_field(v_a_240, 0));
    switch (heff_tag_of(v_lo_242)) {
    case TAG_Nothing: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_a_244 = heff_field(v_lo_242, 0);
      heff_take_n(v_lo_242, 1ULL, 1);
      if (heff_intLe_c(MK_INT(0LL), v_a_244)) {
        switch (heff_tag_of(v_b_241)) {
        case TAG_Unreached: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_Within: {
          V v_lo_245 = heff_dup(heff_field(v_b_241, 0));
          switch (heff_tag_of(v_lo_245)) {
          case TAG_Nothing: {
            v_t_248 = NTAG(TAG_False);
            break;
          }
          case TAG_Just: {
            V v_a_247 = heff_field(v_lo_245, 0);
            heff_take_n(v_lo_245, 1ULL, 1);
            v_t_248 = heff_bool(heff_intLe_c_lent(MK_INT(0LL), v_a_247, 1));
            heff_drop(v_a_247);
            break;
          }
          default: heff_nomatch(v_lo_245);
          }
          break;
        }
        default: heff_nomatch(v_b_241);
        }
      } else {
        v_t_248 = NTAG(TAG_False);
      }
      break;
    }
    default: heff_nomatch(v_lo_242);
    }
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    HEFF_LAST return g_heff_2ecompile_2eranges_2emeet(v_a_240, v_b_241);
  } else {
    heff_drop(v_t_248);
    switch (heff_tag_of(v_a_240)) {
    case TAG_Unreached: {
      switch (heff_tag_of(v_b_241)) {
      case TAG_Unreached: {
        return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
      case TAG_Within: {
        V v_lo_249 = heff_dup(heff_field(v_b_241, 0));
        switch (heff_tag_of(v_lo_249)) {
        case TAG_Nothing: {
          switch (heff_tag_of(v_b_241)) {
          case TAG_Within: {
            heff_take_n(v_b_241, 0ULL, 2);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          default: return heff_nomatch(v_b_241);
          }
        }
        case TAG_Just: {
          V v_a_2413 = heff_field(v_lo_249, 0);
          V v_ru_24lo_249_24Just = heff_take_reuse_n(v_lo_249, 1ULL, 1);
          if (heff_intLe_c(MK_INT(0LL), v_a_2413)) {
            V v_t_2416;
            switch (heff_tag_of(v_b_241)) {
            case TAG_Unreached: {
              v_t_2416 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Within: {
              V v_hi_2415 = heff_field(v_b_241, 1);
              heff_take_n(v_b_241, 2ULL, 2);
              v_t_2416 = v_hi_2415;
              break;
            }
            default: heff_nomatch(v_b_241);
            }
            return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24lo_249_24Just, TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2416});
          } else {
            heff_drop_tag(v_b_241, 2);
            heff_drop_cell(v_ru_24lo_249_24Just, 1);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
        }
        default: return heff_nomatch(v_lo_249);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    case TAG_Within: {
      V v_lo_2417 = heff_dup(heff_field(v_a_240, 0));
      switch (heff_tag_of(v_lo_2417)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Within: {
          V v_ru_24a_240_24Within = heff_take_reuse_n(v_a_240, 0ULL, 2);
          switch (heff_tag_of(v_b_241)) {
          case TAG_Unreached: {
            heff_drop_cell(v_ru_24a_240_24Within, 2);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          case TAG_Within: {
            V v_lo_2421 = heff_dup(heff_field(v_b_241, 0));
            switch (heff_tag_of(v_lo_2421)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24a_240_24Within, 2);
              switch (heff_tag_of(v_b_241)) {
              case TAG_Within: {
                heff_take_n(v_b_241, 0ULL, 2);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
              default: return heff_nomatch(v_b_241);
              }
            }
            case TAG_Just: {
              V v_a_2425 = heff_field(v_lo_2421, 0);
              heff_take_n(v_lo_2421, 1ULL, 1);
              if (heff_intLe_c(MK_INT(0LL), v_a_2425)) {
                V v_t_2428;
                switch (heff_tag_of(v_b_241)) {
                case TAG_Unreached: {
                  v_t_2428 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Within: {
                  V v_hi_2427 = heff_field(v_b_241, 1);
                  heff_take_n(v_b_241, 2ULL, 2);
                  v_t_2428 = v_hi_2427;
                  break;
                }
                default: heff_nomatch(v_b_241);
                }
                return heff_tag_at_n(v_ru_24a_240_24Within, TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2428});
              } else {
                heff_drop_tag(v_b_241, 2);
                heff_drop_cell(v_ru_24a_240_24Within, 2);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
            }
            default: return heff_nomatch(v_lo_2421);
            }
          }
          default: return heff_nomatch(v_b_241);
          }
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      case TAG_Just: {
        V v_a_2429 = heff_field(v_lo_2417, 0);
        V v_ru_24lo_2417_24Just = heff_take_reuse_n(v_lo_2417, 1ULL, 1);
        if (heff_intLe_c(MK_INT(0LL), v_a_2429)) {
          heff_drop(v_b_241);
          V v_t_2432;
          switch (heff_tag_of(v_a_240)) {
          case TAG_Unreached: {
            v_t_2432 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Within: {
            V v_hi_2431 = heff_field(v_a_240, 1);
            heff_take_n(v_a_240, 2ULL, 2);
            v_t_2432 = v_hi_2431;
            break;
          }
          default: heff_nomatch(v_a_240);
          }
          return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24lo_2417_24Just, TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2432});
        } else {
          heff_drop_tag(v_a_240, 2);
          switch (heff_tag_of(v_b_241)) {
          case TAG_Unreached: {
            heff_drop_cell(v_ru_24lo_2417_24Just, 1);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          case TAG_Within: {
            V v_lo_2433 = heff_dup(heff_field(v_b_241, 0));
            switch (heff_tag_of(v_lo_2433)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24lo_2417_24Just, 1);
              switch (heff_tag_of(v_b_241)) {
              case TAG_Within: {
                heff_take_n(v_b_241, 0ULL, 2);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
              default: return heff_nomatch(v_b_241);
              }
            }
            case TAG_Just: {
              V v_a_2437 = heff_field(v_lo_2433, 0);
              heff_take_n(v_lo_2433, 1ULL, 1);
              if (heff_intLe_c(MK_INT(0LL), v_a_2437)) {
                V v_t_2440;
                switch (heff_tag_of(v_b_241)) {
                case TAG_Unreached: {
                  v_t_2440 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Within: {
                  V v_hi_2439 = heff_field(v_b_241, 1);
                  heff_take_n(v_b_241, 2ULL, 2);
                  v_t_2440 = v_hi_2439;
                  break;
                }
                default: heff_nomatch(v_b_241);
                }
                return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24lo_2417_24Just, TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2440});
              } else {
                heff_drop_tag(v_b_241, 2);
                heff_drop_cell(v_ru_24lo_2417_24Just, 1);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
            }
            default: return heff_nomatch(v_lo_2433);
            }
          }
          default: return heff_nomatch(v_b_241);
          }
        }
      }
      default: return heff_nomatch(v_lo_2417);
      }
    }
    default: return heff_nomatch(v_a_240);
    }
  }
}
V g_heff_2ecompile_2eranges_2eandR_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2eandR(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str0, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str1, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str2, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str3, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str4, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str5, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str6, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str7, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str8, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str9, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str10, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str11, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str12, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str13, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str14, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str15, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str16, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str17, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str18, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str19, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str20, 5, "intLe");
Clo g_heff_2ecompile_2eranges_2eisComparison_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eisComparison_entry, 1, 0};

V g_heff_2ecompile_2eranges_2eisComparison(V v_p_240) {
top: ;
  V v_t_241;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str0), 2)) {
    v_t_241 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str1);
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str2), 2)) {
      v_t_241 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str3);
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str4), 2)) {
        v_t_241 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str5);
      } else {
        v_t_241 = heff_dup(v_p_240);
      }
    }
  }
  if (heff_strEq_c(v_t_241, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str6))) {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  } else {
    V v_t_2410;
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str7), 2)) {
      v_t_2410 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str8);
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str9), 2)) {
        v_t_2410 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str10);
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str11), 2)) {
          v_t_2410 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str12);
        } else {
          v_t_2410 = heff_dup(v_p_240);
        }
      }
    }
    V v_t_249 = heff_strEq(v_t_2410, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str13));
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_2411;
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str14), 2)) {
        heff_drop(v_p_240);
        v_t_2411 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str15);
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str16), 2)) {
          heff_drop(v_p_240);
          v_t_2411 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str17);
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str18), 2)) {
            heff_drop(v_p_240);
            v_t_2411 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str19);
          } else {
            v_t_2411 = v_p_240;
          }
        }
      }
      return heff_strEq(v_t_2411, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str20));
    }
    default: return heff_nomatch(v_t_249);
    }
  }
}
V g_heff_2ecompile_2eranges_2eisComparison_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2eisComparison(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eranges_2eheld_24cpr_str0, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eheld_24cpr_str1, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eheld_24cpr_str2, 5, "intEq");

HeffT2 g_heff_2ecompile_2eranges_2eheld_24cpr(V v_p_240, V v_yes_241, V v_ra_242, V v_rb_243) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eheld_24cpr_str0), 2)) {
    if ((heff_dup(v_yes_241) == NTAG(TAG_True))) {
      V v_t_247;
      switch (heff_tag_of(v_rb_243)) {
      case TAG_Unreached: {
        v_t_247 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_hi_245 = heff_dup(heff_field(v_rb_243, 1));
        switch (heff_tag_of(v_hi_245)) {
        case TAG_Nothing: {
          v_t_247 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_a_246 = heff_field(v_hi_245, 0);
          V v_ru_24hi_245_24Just = heff_take_reuse_n(v_hi_245, 1ULL, 1);
          v_t_247 = heff_tag_at_n(v_ru_24hi_245_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_246, MK_INT(-1LL))});
          break;
        }
        default: heff_nomatch(v_hi_245);
        }
        break;
      }
      default: heff_nomatch(v_rb_243);
      }
      V v_t_248 = heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), v_t_247});
      V v_f_249 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), v_t_248));
      V v_t_2413;
      switch (heff_tag_of(v_ra_242)) {
      case TAG_Unreached: {
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_lo_2410 = heff_field(v_ra_242, 0);
        heff_take_n(v_ra_242, 1ULL, 2);
        switch (heff_tag_of(v_lo_2410)) {
        case TAG_Nothing: {
          v_t_2413 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_a_2412 = heff_field(v_lo_2410, 0);
          V v_ru_24lo_2410_24Just = heff_take_reuse_n(v_lo_2410, 1ULL, 1);
          v_t_2413 = heff_tag_at_n(v_ru_24lo_2410_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2412, MK_INT(1LL))});
          break;
        }
        default: heff_nomatch(v_lo_2410);
        }
        break;
      }
      default: heff_nomatch(v_ra_242);
      }
      V v_t_2414 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2413, NTAG(TAG_Nothing)});
      V v_f_2415 = (g_heff_2ecompile_2eranges_2emeet(v_rb_243, v_t_2414));
      return ((HeffT2){{v_f_249, v_f_2415}});
    } else {
      V v_t_2418;
      switch (heff_tag_of(v_rb_243)) {
      case TAG_Unreached: {
        v_t_2418 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_lo_2416 = heff_dup(heff_field(v_rb_243, 0));
        v_t_2418 = v_lo_2416;
        break;
      }
      default: heff_nomatch(v_rb_243);
      }
      V v_t_2419 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2418, NTAG(TAG_Nothing)});
      V v_f_2420 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), v_t_2419));
      V v_t_2423;
      switch (heff_tag_of(v_ra_242)) {
      case TAG_Unreached: {
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_hi_2422 = heff_field(v_ra_242, 1);
        heff_take_n(v_ra_242, 2ULL, 2);
        v_t_2423 = v_hi_2422;
        break;
      }
      default: heff_nomatch(v_ra_242);
      }
      V v_t_2424 = heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), v_t_2423});
      V v_f_2425 = (g_heff_2ecompile_2eranges_2emeet(v_rb_243, v_t_2424));
      return ((HeffT2){{v_f_2420, v_f_2425}});
    }
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eheld_24cpr_str1), 2)) {
      if ((heff_dup(v_yes_241) == NTAG(TAG_True))) {
        V v_t_2428;
        switch (heff_tag_of(v_rb_243)) {
        case TAG_Unreached: {
          v_t_2428 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Within: {
          V v_hi_2427 = heff_dup(heff_field(v_rb_243, 1));
          v_t_2428 = v_hi_2427;
          break;
        }
        default: heff_nomatch(v_rb_243);
        }
        V v_t_2429 = heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), v_t_2428});
        V v_f_2430 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), v_t_2429));
        V v_t_2433;
        switch (heff_tag_of(v_ra_242)) {
        case TAG_Unreached: {
          v_t_2433 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Within: {
          V v_lo_2431 = heff_field(v_ra_242, 0);
          heff_take_n(v_ra_242, 1ULL, 2);
          v_t_2433 = v_lo_2431;
          break;
        }
        default: heff_nomatch(v_ra_242);
        }
        V v_t_2434 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2433, NTAG(TAG_Nothing)});
        V v_f_2435 = (g_heff_2ecompile_2eranges_2emeet(v_rb_243, v_t_2434));
        return ((HeffT2){{v_f_2430, v_f_2435}});
      } else {
        V v_t_2439;
        switch (heff_tag_of(v_rb_243)) {
        case TAG_Unreached: {
          v_t_2439 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Within: {
          V v_lo_2436 = heff_dup(heff_field(v_rb_243, 0));
          switch (heff_tag_of(v_lo_2436)) {
          case TAG_Nothing: {
            v_t_2439 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_a_2438 = heff_field(v_lo_2436, 0);
            V v_ru_24lo_2436_24Just = heff_take_reuse_n(v_lo_2436, 1ULL, 1);
            v_t_2439 = heff_tag_at_n(v_ru_24lo_2436_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2438, MK_INT(1LL))});
            break;
          }
          default: heff_nomatch(v_lo_2436);
          }
          break;
        }
        default: heff_nomatch(v_rb_243);
        }
        V v_t_2440 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2439, NTAG(TAG_Nothing)});
        V v_f_2441 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), v_t_2440));
        V v_t_2445;
        switch (heff_tag_of(v_ra_242)) {
        case TAG_Unreached: {
          v_t_2445 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Within: {
          V v_hi_2443 = heff_field(v_ra_242, 1);
          heff_take_n(v_ra_242, 2ULL, 2);
          switch (heff_tag_of(v_hi_2443)) {
          case TAG_Nothing: {
            v_t_2445 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_a_2444 = heff_field(v_hi_2443, 0);
            V v_ru_24hi_2443_24Just = heff_take_reuse_n(v_hi_2443, 1ULL, 1);
            v_t_2445 = heff_tag_at_n(v_ru_24hi_2443_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2444, MK_INT(-1LL))});
            break;
          }
          default: heff_nomatch(v_hi_2443);
          }
          break;
        }
        default: heff_nomatch(v_ra_242);
        }
        V v_t_2446 = heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), v_t_2445});
        V v_f_2447 = (g_heff_2ecompile_2eranges_2emeet(v_rb_243, v_t_2446));
        return ((HeffT2){{v_f_2441, v_f_2447}});
      }
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eheld_24cpr_str2), 2)) {
        if ((heff_dup(v_yes_241) == NTAG(TAG_True))) {
          V v_f_2448 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), heff_dup(v_rb_243)));
          V v_f_2449 = (g_heff_2ecompile_2eranges_2emeet(v_ra_242, v_rb_243));
          return ((HeffT2){{v_f_2448, v_f_2449}});
        } else {
          V v_f_2455;
          switch (heff_tag_of(v_rb_243)) {
          case TAG_Unreached: {
            v_f_2455 = heff_dup(v_ra_242);
            break;
          }
          case TAG_Within: {
            V v_s1_2450 = heff_dup(heff_field(v_rb_243, 0));
            V v_s2_2451 = heff_dup(heff_field(v_rb_243, 1));
            switch (heff_tag_of(v_s1_2450)) {
            case TAG_Nothing: {
              heff_drop(v_s2_2451);
              v_f_2455 = heff_dup(v_ra_242);
              break;
            }
            case TAG_Just: {
              V v_v_2452 = heff_field(v_s1_2450, 0);
              V v_ru_24s1_2450_24Just = heff_take_reuse_n(v_s1_2450, 1ULL, 1);
              switch (heff_tag_of(v_s2_2451)) {
              case TAG_Nothing: {
                heff_drop(v_v_2452);
                heff_drop_cell(v_ru_24s1_2450_24Just, 1);
                v_f_2455 = heff_dup(v_ra_242);
                break;
              }
              case TAG_Just: {
                V v_w_2453 = heff_field(v_s2_2451, 0);
                heff_take_n(v_s2_2451, 1ULL, 1);
                if (heff_intEq_c_lent(v_v_2452, v_w_2453, 2)) {
                  V v_t_2454 = (g_heff_2ecompile_2eranges_2etrimLow(heff_dup(v_v_2452), heff_dup(v_ra_242)));
                  v_f_2455 = (g_heff_2ecompile_2eranges_2etrimHigh_24tok1(v_ru_24s1_2450_24Just, v_v_2452, v_t_2454));
                } else {
                  heff_drop(v_v_2452);
                  heff_drop_cell(v_ru_24s1_2450_24Just, 1);
                  v_f_2455 = heff_dup(v_ra_242);
                }
                break;
              }
              default: heff_nomatch(v_s2_2451);
              }
              break;
            }
            default: heff_nomatch(v_s1_2450);
            }
            break;
          }
          default: heff_nomatch(v_rb_243);
          }
          V v_f_2461;
          switch (heff_tag_of(v_ra_242)) {
          case TAG_Unreached: {
            v_f_2461 = v_rb_243;
            break;
          }
          case TAG_Within: {
            V v_s1_2456 = heff_field(v_ra_242, 0);
            V v_s2_2457 = heff_field(v_ra_242, 1);
            V v_ru_24ra_242_24Within = heff_take_reuse_n(v_ra_242, 3ULL, 2);
            switch (heff_tag_of(v_s1_2456)) {
            case TAG_Nothing: {
              heff_drop(v_s2_2457);
              heff_drop_cell(v_ru_24ra_242_24Within, 2);
              v_f_2461 = v_rb_243;
              break;
            }
            case TAG_Just: {
              V v_v_2458 = heff_field(v_s1_2456, 0);
              heff_take_n(v_s1_2456, 1ULL, 1);
              switch (heff_tag_of(v_s2_2457)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24ra_242_24Within, 2);
                heff_drop(v_v_2458);
                v_f_2461 = v_rb_243;
                break;
              }
              case TAG_Just: {
                V v_w_2459 = heff_field(v_s2_2457, 0);
                heff_take_n(v_s2_2457, 1ULL, 1);
                if (heff_intEq_c_lent(v_v_2458, v_w_2459, 2)) {
                  V v_t_2460 = (g_heff_2ecompile_2eranges_2etrimLow(heff_dup(v_v_2458), v_rb_243));
                  v_f_2461 = (g_heff_2ecompile_2eranges_2etrimHigh_24tok2(v_ru_24ra_242_24Within, v_v_2458, v_t_2460));
                } else {
                  heff_drop_cell(v_ru_24ra_242_24Within, 2);
                  heff_drop(v_v_2458);
                  v_f_2461 = v_rb_243;
                }
                break;
              }
              default: heff_nomatch(v_s2_2457);
              }
              break;
            }
            default: heff_nomatch(v_s1_2456);
            }
            break;
          }
          default: heff_nomatch(v_ra_242);
          }
          return ((HeffT2){{v_f_2455, v_f_2461}});
        }
      } else {
        return ((HeffT2){{v_ra_242, v_rb_243}});
      }
    }
  }
}
Clo g_heff_2ecompile_2eranges_2erootTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erootTo_entry, 3, 0};

V g_heff_2ecompile_2eranges_2erootTo(V v_env_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_Just: {
    V v_h_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    if (heff_intLe_c_lent(MK_INT(0LL), v_h_243, 1)) {
      HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_env_240, 0), v_x_241));
      V v_t_248;
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          V v_x_247 = v_field_246;
          v_t_248 = v_x_247;
        } else {
          heff_drop(v_field_246);
          v_t_248 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
        }
      }
      V v_t_249;
      if (heff_intLt_c_lent(v_h_243, MK_INT(2LL), 2)) {
        v_t_249 = heff_dup(v_h_243);
      } else {
        v_t_249 = heff_intAdd(heff_intDiv(heff_dup(v_h_243), MK_INT(2LL)), MK_INT(1LL));
      }
      V v_t_2410 = (g_heff_2ecompile_2eranges_2erootGo(heff_dup(v_h_243), MK_INT(0LL), v_t_249));
      V v_t_2411 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_intSub(MK_INT(0LL), v_t_2410)});
      V v_t_2412;
      if (heff_intLt_c_lent(v_h_243, MK_INT(2LL), 2)) {
        v_t_2412 = heff_dup(v_h_243);
      } else {
        v_t_2412 = heff_intAdd(heff_intDiv(heff_dup(v_h_243), MK_INT(2LL)), MK_INT(1LL));
      }
      V v_t_2413 = (g_heff_2ecompile_2eranges_2erootGo(v_h_243, MK_INT(0LL), v_t_2412));
      V v_t_2414 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2411, heff_tag_n(TAG_Just, 1, (V[]){v_t_2413})});
      V v_t_2415 = (g_heff_2ecompile_2eranges_2emeet(v_t_248, v_t_2414));
      HEFF_LAST return g_heff_2ecompile_2eranges_2ewithRange(v_env_240, v_x_241, v_t_2415);
    } else {
      heff_drop(v_x_241);
      heff_drop(v_h_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return v_env_240;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eranges_2erootTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2erootTo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eranges_2erefine_str0, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2erefine_str1, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2erefine_str2, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2erefine_str3, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2erefine_str4, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2erefine_str5, 5, "intLe");
Clo g_heff_2ecompile_2eranges_2erefine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erefine_entry, 4, 0};

V g_heff_2ecompile_2eranges_2erefine(V v_c_240, V v_env_241, V v_x3_242, V v_yes_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkTest: {
    V v_p_244 = heff_field(v_x3_242, 0);
    V v_a_245 = heff_field(v_x3_242, 1);
    V v_b_246 = heff_field(v_x3_242, 2);
    V v_t_247;
    if (heff_strEq_c_lent(v_p_244, ((V)&g_heff_2ecompile_2eranges_2erefine_str0), 2)) {
      v_t_247 = ((V)&g_heff_2ecompile_2eranges_2erefine_str1);
    } else {
      if (heff_strEq_c_lent(v_p_244, ((V)&g_heff_2ecompile_2eranges_2erefine_str2), 2)) {
        v_t_247 = ((V)&g_heff_2ecompile_2eranges_2erefine_str3);
      } else {
        if (heff_strEq_c_lent(v_p_244, ((V)&g_heff_2ecompile_2eranges_2erefine_str4), 2)) {
          v_t_247 = ((V)&g_heff_2ecompile_2eranges_2erefine_str5);
        } else {
          v_t_247 = heff_dup(v_p_244);
        }
      }
    }
    V v_t_248 = (g_heff_2ecompile_2eranges_2eoperandRange(heff_dup(v_c_240), heff_dup(v_env_241), heff_dup(v_a_245)));
    V v_t_249 = (g_heff_2ecompile_2eranges_2eoperandRange(v_c_240, heff_dup(v_env_241), heff_dup(v_b_246)));
    HeffT2 v_t_2410 = ({ V a_0 = v_t_247; V a_1 = v_yes_243; V a_2 = v_t_248; V a_3 = v_t_249; HeffT2 r_ = (g_heff_2ecompile_2eranges_2eheld_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_ra_2413 = v_field_2411;
      V v_rb_2414 = v_field_2412;
      V v_t_2415 = (g_heff_2ecompile_2eranges_2enarrowTo(v_env_241, v_a_245, v_ra_2413));
      return (g_heff_2ecompile_2eranges_2enarrowTo(v_t_2415, v_b_246, v_rb_2414));
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eranges_2erefine_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eranges_2erefine(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eranges_2econdTests_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2econdTests_entry, 2, 0};

V g_heff_2ecompile_2eranges_2econdTests(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_CFalse: {
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_CRel: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_b_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CRel = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    heff_drop_rec(v_env_240, 2);
    V v_t_245 = (g_heff_2ecompile_2eranges_2eisComparison(heff_dup(v_p_242)));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24CRel, TAG_MkTest, 3, (V[]){v_p_242, v_a_243, v_b_244}), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_p_242);
      heff_drop(v_a_243);
      heff_drop(v_b_244);
      heff_drop_cell(v_ru_24x2_241_24CRel, 3);
      heff_drop(v_t_245);
      return NTAG(TAG_Nil);
    }
  }
  case TAG_CTest: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      V v_x_247 = heff_field(v_x21_246, 0);
      heff_take_n(v_x21_246, 1ULL, 1);
      HeffT2 v_t_248 = ({ V b_0 = heff_get_n(v_env_240, 1, 2); V a_1 = v_x_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_247); r_; });
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_t_2411 = v_field_2410;
          return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
        } else {
          heff_drop(v_field_2410);
          return NTAG(TAG_Nil);
        }
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_246, 0ULL, 1);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELam: {
      heff_take_n(v_x21_246, 0ULL, 2);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      heff_take_n(v_x21_246, 0ULL, 2);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELet: {
      heff_take_n(v_x21_246, 0ULL, 3);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ERecord: {
      heff_take_n(v_x21_246, 0ULL, 2);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EProj: {
      heff_take_n(v_x21_246, 0ULL, 4);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      heff_take_n(v_x21_246, 0ULL, 3);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      heff_take_n(v_x21_246, 0ULL, 2);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_246, 0ULL, 1);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x21_246, 0ULL, 2);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ECall: {
      heff_take_n(v_x21_246, 0ULL, 2);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      heff_take_n(v_x21_246, 0ULL, 1);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_246, 0ULL, 1);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EStr: {
      heff_take_n(v_x21_246, 0ULL, 1);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_246, 0ULL, 1);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_246, 0ULL, 2);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_246, 0ULL, 1);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EBool: {
      heff_take_n(v_x21_246, 0ULL, 1);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESet: {
      heff_take_n(v_x21_246, 0ULL, 3);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EValues: {
      heff_take_n(v_x21_246, 0ULL, 1);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFix: {
      heff_take_n(v_x21_246, 0ULL, 2);
      heff_drop_rec(v_env_240, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_CNot: {
    V v_k_2450 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V t_0 = v_env_240;
    V t_1 = v_k_2450;
    v_env_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2451 = heff_field(v_x2_241, 0);
    V v_b_2452 = heff_field(v_x2_241, 1);
    V v_k_2453 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2454 = (g_heff_2ecompile_2eranges_2econdTests(heff_dup(v_env_240), v_a_2451));
    V v_t_2455 = (g_heff_2ecompile_2eranges_2econdTests(heff_dup(v_env_240), v_b_2452));
    V v_t_2456 = (g_heff_2ecompile_2eranges_2econdTests(v_env_240, v_k_2453));
    V v_t_2457 = (g_prelude_2e_2b_2b(v_t_2455, v_t_2456));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2454, v_t_2457);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eranges_2econdTests_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2econdTests(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2etestOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2etestOf_entry, 2, 0};

V g_heff_2ecompile_2eranges_2etestOf(V v_env_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EVar = heff_take_reuse_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_env_240, 1, 2); V a_1 = v_x_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_242); r_; });
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_it1_246 = v_field_245;
        switch (heff_tag_of(v_it1_246)) {
        case TAG_MkTest: {
          V v_p_247 = heff_field(v_it1_246, 0);
          V v_a_248 = heff_field(v_it1_246, 1);
          V v_b_249 = heff_field(v_it1_246, 2);
          heff_take_n(v_it1_246, 7ULL, 3);
          return heff_tag_at_n(v_ru_24e_241_24EVar, TAG_Just, 1, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_247, v_a_248, v_b_249})});
        }
        default: return heff_nomatch(v_it1_246);
        }
      } else {
        heff_drop_cell(v_ru_24e_241_24EVar, 1);
        heff_drop(v_field_245);
        return NTAG(TAG_Nothing);
      }
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    V v_p_2430 = heff_field(v_e_241, 0);
    V v_e2_2431 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    heff_drop_rec(v_env_240, 2);
    switch (heff_tag_of(v_e2_2431)) {
    case TAG_Nil: {
      heff_drop(v_p_2430);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_a_2432 = heff_field(v_e2_2431, 0);
      V v_e22_2433 = heff_field(v_e2_2431, 1);
      heff_take_n(v_e2_2431, 3ULL, 2);
      switch (heff_tag_of(v_e22_2433)) {
      case TAG_Nil: {
        heff_drop(v_p_2430);
        heff_drop(v_a_2432);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_b_2434 = heff_field(v_e22_2433, 0);
        V v_e222_2435 = heff_field(v_e22_2433, 1);
        heff_take_n(v_e22_2433, 3ULL, 2);
        switch (heff_tag_of(v_e222_2435)) {
        case TAG_Nil: {
          V v_t_2436 = (g_heff_2ecompile_2eranges_2eisComparison(heff_dup(v_p_2430)));
          if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
            heff_drop(v_t_2436);
            return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_2430, v_a_2432, v_b_2434})});
          } else {
            heff_drop(v_p_2430);
            heff_drop(v_a_2432);
            heff_drop(v_b_2434);
            heff_drop(v_t_2436);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2435, 0ULL, 2);
          heff_drop(v_p_2430);
          heff_drop(v_a_2432);
          heff_drop(v_b_2434);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_e222_2435);
        }
      }
      default: return heff_nomatch(v_e22_2433);
      }
    }
    default: return heff_nomatch(v_e2_2431);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EBool: {
    V v_k_2448 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EBool = heff_take_reuse_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return heff_tag_at_n(v_ru_24e_241_24EBool, TAG_Just, 1, (V[]){v_k_2448});
  }
  case TAG_ESet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EValues: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eranges_2etestOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2etestOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2econdRefine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2econdRefine_entry, 4, 0};

V g_heff_2ecompile_2eranges_2econdRefine(V v_c_240, V v_env_241, V v_x3_242, V v_yes_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_CTrue: {
    heff_drop(v_c_240);
    heff_drop(v_yes_243);
    return v_env_241;
  }
  case TAG_CFalse: {
    heff_drop(v_c_240);
    heff_drop(v_yes_243);
    return v_env_241;
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x3_242, 0);
    V v_a_245 = heff_field(v_x3_242, 1);
    V v_b_246 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24CRel = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_247 = (g_heff_2ecompile_2eranges_2eisComparison(heff_dup(v_p_244)));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      return ({ V a_0 = v_c_240; V a_1 = v_env_241; V b_2 = heff_tag_at_n(v_ru_24x3_242_24CRel, TAG_MkTest, 3, (V[]){v_p_244, v_a_245, v_b_246}); V a_3 = v_yes_243; V r_ = (g_heff_2ecompile_2eranges_2erefine(a_0, a_1, b_2, a_3)); heff_drop(b_2); heff_drop(v_yes_243); r_; });
    } else {
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      heff_drop(v_p_244);
      heff_drop(v_a_245);
      heff_drop(v_b_246);
      heff_drop_cell(v_ru_24x3_242_24CRel, 3);
      heff_drop(v_t_247);
      return v_env_241;
    }
  }
  case TAG_CTest: {
    V v_x31_248 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_248)) {
    case TAG_EVar: {
      V v_x_249 = heff_field(v_x31_248, 0);
      heff_take_n(v_x31_248, 1ULL, 1);
      HeffT2 v_t_2410 = ({ V a_0 = heff_rfield(v_env_241, 1); V a_1 = v_x_249; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_x_249); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_t_2413 = v_field_2412;
          return ({ V a_0 = v_c_240; V a_1 = v_env_241; V a_2 = v_t_2413; V a_3 = v_yes_243; V r_ = (g_heff_2ecompile_2eranges_2erefine(a_0, a_1, a_2, a_3)); heff_drop(v_t_2413); heff_drop(v_yes_243); r_; });
        } else {
          heff_drop(v_c_240);
          heff_drop(v_yes_243);
          heff_drop(v_field_2412);
          return v_env_241;
        }
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_248, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_ELam: {
      heff_take_n(v_x31_248, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EApp: {
      heff_take_n(v_x31_248, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_ELet: {
      heff_take_n(v_x31_248, 0ULL, 3);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_ERecord: {
      heff_take_n(v_x31_248, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EProj: {
      heff_take_n(v_x31_248, 0ULL, 4);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_ETag: {
      heff_take_n(v_x31_248, 0ULL, 3);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_x31_248, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_248, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x31_248, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_ECall: {
      heff_take_n(v_x31_248, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_248, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_248, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_248, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_248, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_248, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_248, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EAbandon: {
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EBool: {
      heff_take_n(v_x31_248, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_ESet: {
      heff_take_n(v_x31_248, 0ULL, 3);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EValues: {
      heff_take_n(v_x31_248, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_248, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop(v_yes_243);
      return v_env_241;
    }
    default: return heff_nomatch(v_x31_248);
    }
  }
  case TAG_CNot: {
    V v_k_2452 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_2453 = heff_bool(!(heff_dup(v_yes_243) == NTAG(TAG_True)));
    heff_drop(v_yes_243);
    V t_0 = v_c_240;
    V t_1 = v_env_241;
    V t_2 = v_k_2452;
    V t_3 = v_t_2453;
    v_c_240 = t_0;
    v_env_241 = t_1;
    v_x3_242 = t_2;
    v_yes_243 = t_3;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2454 = heff_field(v_x3_242, 0);
    V v_b_2455 = heff_field(v_x3_242, 1);
    V v_x33_2456 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    switch (heff_tag_of(v_x33_2456)) {
    case TAG_CTrue: {
      switch (heff_tag_of(v_b_2455)) {
      case TAG_CTrue: {
        if ((heff_dup(v_yes_243) == NTAG(TAG_True))) {
          heff_drop(v_c_240);
          heff_drop(v_yes_243);
          heff_drop(v_a_2454);
          return v_env_241;
        } else {
          heff_drop(v_yes_243);
          V v_t_2457 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), v_env_241, v_a_2454, NTAG(TAG_False)));
          V t_0 = v_c_240;
          V t_1 = v_t_2457;
          V t_2 = v_x33_2456;
          V t_3 = NTAG(TAG_False);
          v_c_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_yes_243 = t_3;
          goto top;
        }
      }
      case TAG_CFalse: {
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        return v_env_241;
      }
      case TAG_CRel: {
        heff_take_n(v_b_2455, 0ULL, 3);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        return v_env_241;
      }
      case TAG_CTest: {
        heff_take_n(v_b_2455, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        return v_env_241;
      }
      case TAG_CNot: {
        heff_take_n(v_b_2455, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        return v_env_241;
      }
      case TAG_CIf: {
        heff_take_n(v_b_2455, 0ULL, 3);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        return v_env_241;
      }
      default: return heff_nomatch(v_b_2455);
      }
    }
    case TAG_CFalse: {
      if ((heff_dup(v_yes_243) == NTAG(TAG_True))) {
        heff_drop(v_yes_243);
        V v_t_2466 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), v_env_241, v_a_2454, NTAG(TAG_True)));
        V t_0 = v_c_240;
        V t_1 = v_t_2466;
        V t_2 = v_b_2455;
        V t_3 = NTAG(TAG_True);
        v_c_240 = t_0;
        v_env_241 = t_1;
        v_x3_242 = t_2;
        v_yes_243 = t_3;
        goto top;
      } else {
        heff_drop(v_yes_243);
        switch (heff_tag_of(v_b_2455)) {
        case TAG_CTrue: {
          V v_t_2467 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), v_env_241, v_a_2454, NTAG(TAG_False)));
          V t_0 = v_c_240;
          V t_1 = v_t_2467;
          V t_2 = v_x33_2456;
          V t_3 = NTAG(TAG_False);
          v_c_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_yes_243 = t_3;
          goto top;
        }
        case TAG_CFalse: {
          heff_drop(v_c_240);
          heff_drop(v_a_2454);
          return v_env_241;
        }
        case TAG_CRel: {
          heff_take_n(v_b_2455, 0ULL, 3);
          heff_drop(v_c_240);
          heff_drop(v_a_2454);
          return v_env_241;
        }
        case TAG_CTest: {
          heff_take_n(v_b_2455, 0ULL, 1);
          heff_drop(v_c_240);
          heff_drop(v_a_2454);
          return v_env_241;
        }
        case TAG_CNot: {
          heff_take_n(v_b_2455, 0ULL, 1);
          heff_drop(v_c_240);
          heff_drop(v_a_2454);
          return v_env_241;
        }
        case TAG_CIf: {
          heff_take_n(v_b_2455, 0ULL, 3);
          heff_drop(v_c_240);
          heff_drop(v_a_2454);
          return v_env_241;
        }
        default: return heff_nomatch(v_b_2455);
        }
      }
    }
    case TAG_CRel: {
      switch (heff_tag_of(v_b_2455)) {
      case TAG_CTrue: {
        if ((heff_dup(v_yes_243) == NTAG(TAG_True))) {
          heff_drop(v_c_240);
          heff_drop(v_yes_243);
          heff_drop(v_a_2454);
          heff_drop_tag(v_x33_2456, 3);
          return v_env_241;
        } else {
          heff_drop(v_yes_243);
          V v_t_2479 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), v_env_241, v_a_2454, NTAG(TAG_False)));
          V t_0 = v_c_240;
          V t_1 = v_t_2479;
          V t_2 = v_x33_2456;
          V t_3 = NTAG(TAG_False);
          v_c_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_yes_243 = t_3;
          goto top;
        }
      }
      case TAG_CFalse: {
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 3);
        return v_env_241;
      }
      case TAG_CRel: {
        heff_take_n(v_b_2455, 0ULL, 3);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 3);
        return v_env_241;
      }
      case TAG_CTest: {
        heff_take_n(v_b_2455, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 3);
        return v_env_241;
      }
      case TAG_CNot: {
        heff_take_n(v_b_2455, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 3);
        return v_env_241;
      }
      case TAG_CIf: {
        heff_take_n(v_b_2455, 0ULL, 3);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 3);
        return v_env_241;
      }
      default: return heff_nomatch(v_b_2455);
      }
    }
    case TAG_CTest: {
      switch (heff_tag_of(v_b_2455)) {
      case TAG_CTrue: {
        if ((heff_dup(v_yes_243) == NTAG(TAG_True))) {
          heff_drop(v_c_240);
          heff_drop(v_yes_243);
          heff_drop(v_a_2454);
          heff_drop_tag(v_x33_2456, 1);
          return v_env_241;
        } else {
          heff_drop(v_yes_243);
          V v_t_2489 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), v_env_241, v_a_2454, NTAG(TAG_False)));
          V t_0 = v_c_240;
          V t_1 = v_t_2489;
          V t_2 = v_x33_2456;
          V t_3 = NTAG(TAG_False);
          v_c_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_yes_243 = t_3;
          goto top;
        }
      }
      case TAG_CFalse: {
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 1);
        return v_env_241;
      }
      case TAG_CRel: {
        heff_take_n(v_b_2455, 0ULL, 3);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 1);
        return v_env_241;
      }
      case TAG_CTest: {
        heff_take_n(v_b_2455, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 1);
        return v_env_241;
      }
      case TAG_CNot: {
        heff_take_n(v_b_2455, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 1);
        return v_env_241;
      }
      case TAG_CIf: {
        heff_take_n(v_b_2455, 0ULL, 3);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 1);
        return v_env_241;
      }
      default: return heff_nomatch(v_b_2455);
      }
    }
    case TAG_CNot: {
      switch (heff_tag_of(v_b_2455)) {
      case TAG_CTrue: {
        if ((heff_dup(v_yes_243) == NTAG(TAG_True))) {
          heff_drop(v_c_240);
          heff_drop(v_yes_243);
          heff_drop(v_a_2454);
          heff_drop_tag(v_x33_2456, 1);
          return v_env_241;
        } else {
          heff_drop(v_yes_243);
          V v_t_2499 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), v_env_241, v_a_2454, NTAG(TAG_False)));
          V t_0 = v_c_240;
          V t_1 = v_t_2499;
          V t_2 = v_x33_2456;
          V t_3 = NTAG(TAG_False);
          v_c_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_yes_243 = t_3;
          goto top;
        }
      }
      case TAG_CFalse: {
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 1);
        return v_env_241;
      }
      case TAG_CRel: {
        heff_take_n(v_b_2455, 0ULL, 3);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 1);
        return v_env_241;
      }
      case TAG_CTest: {
        heff_take_n(v_b_2455, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 1);
        return v_env_241;
      }
      case TAG_CNot: {
        heff_take_n(v_b_2455, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 1);
        return v_env_241;
      }
      case TAG_CIf: {
        heff_take_n(v_b_2455, 0ULL, 3);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 1);
        return v_env_241;
      }
      default: return heff_nomatch(v_b_2455);
      }
    }
    case TAG_CIf: {
      switch (heff_tag_of(v_b_2455)) {
      case TAG_CTrue: {
        if ((heff_dup(v_yes_243) == NTAG(TAG_True))) {
          heff_drop(v_c_240);
          heff_drop(v_yes_243);
          heff_drop(v_a_2454);
          heff_drop_tag(v_x33_2456, 3);
          return v_env_241;
        } else {
          heff_drop(v_yes_243);
          V v_t_24111 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), v_env_241, v_a_2454, NTAG(TAG_False)));
          V t_0 = v_c_240;
          V t_1 = v_t_24111;
          V t_2 = v_x33_2456;
          V t_3 = NTAG(TAG_False);
          v_c_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_yes_243 = t_3;
          goto top;
        }
      }
      case TAG_CFalse: {
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 3);
        return v_env_241;
      }
      case TAG_CRel: {
        heff_take_n(v_b_2455, 0ULL, 3);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 3);
        return v_env_241;
      }
      case TAG_CTest: {
        heff_take_n(v_b_2455, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 3);
        return v_env_241;
      }
      case TAG_CNot: {
        heff_take_n(v_b_2455, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 3);
        return v_env_241;
      }
      case TAG_CIf: {
        heff_take_n(v_b_2455, 0ULL, 3);
        heff_drop(v_c_240);
        heff_drop(v_yes_243);
        heff_drop(v_a_2454);
        heff_drop_tag(v_x33_2456, 3);
        return v_env_241;
      }
      default: return heff_nomatch(v_b_2455);
      }
    }
    default: return heff_nomatch(v_x33_2456);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eranges_2econdRefine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2econdRefine(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ecompile_2eranges_2egatherMany_24cpr(V v_go_240, V v_env_241, V v_st_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_env_241);
    return ((HeffT2){{NTAG(TAG_Nil), v_st_242}});
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_es_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_x1_246 = heff_tr(heff_call(heff_dup(v_go_240), 3, (V[]){heff_dup(v_env_241), v_st_242, v_e_244}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_MkSeen: {
      V v_r_247 = heff_field(v_x1_246, 0);
      V v_st_248 = heff_field(v_x1_246, 1);
      heff_take_n(v_x1_246, 3ULL, 2);
      HeffT2 v_t_249 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_go_240, v_env_241, v_st_248, v_es_245));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_rs_2412 = v_field_2410;
        V v_st_2413 = v_field_2411;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_r_247, v_rs_2412}), v_st_2413}});
      }
    }
    case TAG_MkSeenVals: {
      V v_st_2415 = heff_field(v_x1_246, 1);
      heff_take_n(v_x1_246, 2ULL, 2);
      HeffT2 v_t_2416 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_go_240, v_env_241, v_st_2415, v_es_245));
      {
        V v_field_2417 = v_t_2416.f[0];
        V v_field_2418 = v_t_2416.f[1];
        V v_rs_2419 = v_field_2417;
        V v_st_2420 = v_field_2418;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_rs_2419}), v_st_2420}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}

HeffT3 g_heff_2ecompile_2eranges_2econsArm_24cpr(V v_tag_240, V v_vs_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkRes: {
    V v_r_244 = heff_field(v_x3_242, 0);
    V v_b_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkRes = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_MkArms: {
      V v_rr_246 = heff_field(v_x4_243, 0);
      V v_arms_247 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      V v_f_248 = (g_heff_2ecompile_2eranges_2ejoin(v_r_244, v_rr_246));
      V v_t_249 = heff_tag_at_n(v_ru_24x3_242_24MkRes, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tag_240, v_vs_241, v_b_245}), v_arms_247});
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_248, v_t_249}});
    }
    case TAG_MkArmsVals: {
      V v_qs_2410 = heff_field(v_x4_243, 0);
      V v_arms_2411 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_r_244)) {
      case TAG_Unreached: {
        V v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24MkRes, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tag_240, v_vs_241, v_b_245}), v_arms_2411});
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_qs_2410, v_t_2412}});
      }
      case TAG_Within: {
        heff_take_n(v_r_244, 0ULL, 2);
        heff_drop(v_qs_2410);
        V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24MkRes, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tag_240, v_vs_241, v_b_245}), v_arms_2411});
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_t_2415}});
      }
      default: return ((HeffT3){{heff_nomatch(v_r_244)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x4_243)}});
    }
  }
  case TAG_MkResVals: {
    V v_rs_2416 = heff_field(v_x3_242, 0);
    V v_b_2417 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkResVals = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_MkArms: {
      V v_rr_2418 = heff_field(v_x4_243, 0);
      V v_arms_2419 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_rr_2418)) {
      case TAG_Unreached: {
        V v_t_2420 = heff_tag_at_n(v_ru_24x3_242_24MkResVals, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tag_240, v_vs_241, v_b_2417}), v_arms_2419});
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_rs_2416, v_t_2420}});
      }
      case TAG_Within: {
        heff_take_n(v_rr_2418, 0ULL, 2);
        heff_drop(v_rs_2416);
        V v_t_2423 = heff_tag_at_n(v_ru_24x3_242_24MkResVals, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tag_240, v_vs_241, v_b_2417}), v_arms_2419});
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_t_2423}});
      }
      default: return ((HeffT3){{heff_nomatch(v_rr_2418)}});
      }
    }
    case TAG_MkArmsVals: {
      V v_qs_2424 = heff_field(v_x4_243, 0);
      V v_arms_2425 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      V v_f_2426 = (g_list_2ezipWith_24s1026658656x682908126(v_rs_2416, v_qs_2424));
      V v_t_2427 = heff_tag_at_n(v_ru_24x3_242_24MkResVals, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tag_240, v_vs_241, v_b_2417}), v_arms_2425});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_2426, v_t_2427}});
    }
    default: return ((HeffT3){{heff_nomatch(v_x4_243)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_242)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eranges_2ewalkArms_24cpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewalkArms_24cpr_str1, 5, "False");

HeffT3 g_heff_2ecompile_2eranges_2ewalkArms_24cpr(V v_c_240, V v_go_241, V v_env_242, V v_t_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_go_241);
    heff_drop(v_env_242);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Unreached), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_MkArm: {
      V v_tag_247 = heff_field(v_x51_245, 0);
      V v_vs_248 = heff_field(v_x51_245, 1);
      V v_b_249 = heff_field(v_x51_245, 2);
      V v_t_2411;
      switch (heff_tag_of(v_t_243)) {
      case TAG_Nothing: {
        v_t_2411 = heff_dup(v_env_242);
        break;
      }
      case TAG_Just: {
        V v_k_2410 = heff_field(v_t_243, 0);
        if (heff_strEq_c_lent(v_tag_247, ((V)&g_heff_2ecompile_2eranges_2ewalkArms_24cpr_str0), 2)) {
          v_t_2411 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), heff_dup(v_env_242), heff_dup(v_k_2410), NTAG(TAG_True)));
        } else {
          if (heff_strEq_c_lent(v_tag_247, ((V)&g_heff_2ecompile_2eranges_2ewalkArms_24cpr_str1), 2)) {
            v_t_2411 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), heff_dup(v_env_242), heff_dup(v_k_2410), NTAG(TAG_False)));
          } else {
            v_t_2411 = heff_dup(v_env_242);
          }
        }
        break;
      }
      default: heff_nomatch(v_t_243);
      }
      V v_t_2412 = heff_tr(heff_call(heff_dup(v_go_241), 2, (V[]){v_t_2411, heff_dup(v_b_249)}));
      V v_t_2413 = (g_heff_2ecompile_2eranges_2ewalkArms(v_c_240, v_go_241, v_env_242, v_t_243, v_rest_246));
      return (g_heff_2ecompile_2eranges_2econsArm_24cpr(heff_dup(v_tag_247), heff_dup(v_vs_248), v_t_2412, v_t_2413));
    }
    default: return ((HeffT3){{heff_nomatch(v_x51_245)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x5_244)}});
  }
}
V g_heff_2ecompile_2eranges_2ewalkGo_lam0(V self, V *args);
V g_heff_2ecompile_2eranges_2ewalkGo_lam1(V self, V *args);
V g_heff_2ecompile_2eranges_2ewalkGo_lam2(V self, V *args);
Clo g_heff_2ecompile_2eranges_2ewalkGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewalkGo_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ewalkGo(V v_c_240, V v_env_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EVar = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_c_240, 3);
    HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_env_241, 0, 2); V a_1 = v_x_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_248;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        v_t_248 = v_x_247;
      } else {
        heff_drop(v_field_246);
        v_t_248 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
    }
    return heff_tag_n(TAG_MkRes, 2, (V[]){v_t_248, heff_tag_at_n(v_ru_24e_242_24EVar, TAG_EVar, 1, (V[]){v_x_243})});
  }
  case TAG_EGlobal: {
    V v_g_249 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EGlobal = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_env_241, 2);
    HeffT2 v_t_2410 = ({ V b_0 = heff_get_n(v_c_240, 1, 3); V a_1 = v_g_249; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2414;
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_x_2413 = v_field_2412;
        v_t_2414 = heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2413)}), heff_tag_n(TAG_Just, 1, (V[]){v_x_2413})});
      } else {
        heff_drop(v_field_2412);
        v_t_2414 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
    }
    return heff_tag_n(TAG_MkRes, 2, (V[]){v_t_2414, heff_tag_at_n(v_ru_24e_242_24EGlobal, TAG_EGlobal, 1, (V[]){v_g_249})});
  }
  case TAG_ELam: {
    V v_xs_2415 = heff_field(v_e_242, 0);
    V v_b_2416 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_x1_2417 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(v_c_240, v_env_241, v_b_2416));
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_MkRes: {
      V v_e_2419 = heff_field(v_x1_2417, 1);
      V v_ru_24x1_2417_24MkRes = heff_take_reuse_n(v_x1_2417, 2ULL, 2);
      return heff_tag_at_n(v_ru_24x1_2417_24MkRes, TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_2415, v_e_2419})});
    }
    case TAG_MkResVals: {
      V v_e_2421 = heff_field(v_x1_2417, 1);
      V v_ru_24x1_2417_24MkResVals = heff_take_reuse_n(v_x1_2417, 2ULL, 2);
      return heff_tag_at_n(v_ru_24x1_2417_24MkResVals, TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_2415, v_e_2421})});
    }
    default: return heff_nomatch(v_x1_2417);
    }
  }
  case TAG_EApp: {
    V v_f_2422 = heff_field(v_e_242, 0);
    V v_args_2423 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_2425 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_t_2424, v_env_241, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_2422), v_args_2423})));
    {
      V v_field_2426 = v_t_2425.f[0];
      V v_field_2427 = v_t_2425.f[1];
      V v_rs_2428 = v_field_2426;
      heff_drop(v_rs_2428);
      V v_es_2429 = v_field_2427;
      V v_t_2432;
      switch (heff_tag_of(v_es_2429)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24e_242_24EApp, 2);
        v_t_2432 = v_f_2422;
        break;
      }
      case TAG_Cons: {
        V v_g_2430 = heff_field(v_es_2429, 0);
        V v_args_2431 = heff_field(v_es_2429, 1);
        heff_take_n(v_es_2429, 3ULL, 2);
        heff_drop(v_f_2422);
        v_t_2432 = heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_g_2430, v_args_2431});
        break;
      }
      default: heff_nomatch(v_es_2429);
      }
      return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_t_2432});
    }
  }
  case TAG_ELet: {
    V v_x_2433 = heff_field(v_e_242, 0);
    V v_a_2434 = heff_field(v_e_242, 1);
    V v_b_2435 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_x1_2436 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(heff_dup(v_c_240), heff_dup(v_env_241), heff_dup(v_a_2434)));
    V v_k_2446 = heff_clo_n(g_heff_2ecompile_2eranges_2ewalkGo_lam0, 2, 5, (V[]){v_env_241, v_x_2433, v_a_2434, v_c_240, v_b_2435});
    switch (heff_tag_of(v_x1_2436)) {
    case TAG_MkRes: {
      V v_r_2447 = heff_field(v_x1_2436, 0);
      V v_e_2448 = heff_field(v_x1_2436, 1);
      heff_take_n(v_x1_2436, 3ULL, 2);
      return heff_tail(v_k_2446, 2, (V[]){v_r_2447, v_e_2448});
    }
    case TAG_MkResVals: {
      V v_e_2450 = heff_field(v_x1_2436, 1);
      heff_take_n(v_x1_2436, 2ULL, 2);
      return heff_tail(v_k_2446, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_2450});
    }
    default: return heff_nomatch(v_x1_2436);
    }
  }
  case TAG_ERecord: {
    V v_fs_2451 = heff_field(v_e_242, 0);
    V v_ts_2452 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){v_c_240}));
    V v_t_2454 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2451)));
    HeffT2 v_t_2455 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_t_2453, v_env_241, v_t_2454));
    {
      V v_field_2456 = v_t_2455.f[0];
      V v_field_2457 = v_t_2455.f[1];
      V v_rs_2458 = v_field_2456;
      heff_drop(v_rs_2458);
      V v_es_2459 = v_field_2457;
      V v_t_2460 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2451, v_es_2459));
      return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, (V[]){v_t_2460, v_ts_2452})});
    }
  }
  case TAG_EProj: {
    V v_a_2461 = heff_field(v_e_242, 0);
    V v_l_2462 = heff_field(v_e_242, 1);
    V v_sh_2463 = heff_field(v_e_242, 2);
    V v_t_2464 = heff_field(v_e_242, 3);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 15ULL, 4);
    V v_x1_2465 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(v_c_240, v_env_241, v_a_2461));
    switch (heff_tag_of(v_x1_2465)) {
    case TAG_MkRes: {
      V v_e_2467 = heff_field(v_x1_2465, 1);
      V v_ru_24x1_2465_24MkRes = heff_take_reuse_n(v_x1_2465, 2ULL, 2);
      return heff_tag_at_n(v_ru_24x1_2465_24MkRes, TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 4, (V[]){v_e_2467, v_l_2462, v_sh_2463, v_t_2464})});
    }
    case TAG_MkResVals: {
      V v_e_2469 = heff_field(v_x1_2465, 1);
      V v_ru_24x1_2465_24MkResVals = heff_take_reuse_n(v_x1_2465, 2ULL, 2);
      return heff_tag_at_n(v_ru_24x1_2465_24MkResVals, TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 4, (V[]){v_e_2469, v_l_2462, v_sh_2463, v_t_2464})});
    }
    default: return heff_nomatch(v_x1_2465);
    }
  }
  case TAG_ETag: {
    V v_t_2470 = heff_field(v_e_242, 0);
    V v_args_2471 = heff_field(v_e_242, 1);
    V v_ts_2472 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2473 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_2474 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_t_2473, v_env_241, v_args_2471));
    {
      V v_field_2475 = v_t_2474.f[0];
      V v_field_2476 = v_t_2474.f[1];
      V v_rs_2477 = v_field_2475;
      heff_drop(v_rs_2477);
      V v_es_2478 = v_field_2476;
      return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_tag_at_n(v_ru_24e_242_24ETag, TAG_ETag, 3, (V[]){v_t_2470, v_es_2478, v_ts_2472})});
    }
  }
  case TAG_EMatch: {
    V v_s_2479 = heff_field(v_e_242, 0);
    V v_arms_2480 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_x1_2481 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(heff_dup(v_c_240), heff_dup(v_env_241), heff_dup(v_s_2479)));
    V v_k_2494 = heff_clo_n(g_heff_2ecompile_2eranges_2ewalkGo_lam1, 2, 4, (V[]){v_c_240, v_env_241, v_s_2479, v_arms_2480});
    switch (heff_tag_of(v_x1_2481)) {
    case TAG_MkRes: {
      V v_r_2495 = heff_field(v_x1_2481, 0);
      V v_e_2496 = heff_field(v_x1_2481, 1);
      heff_take_n(v_x1_2481, 3ULL, 2);
      return heff_tail(v_k_2494, 2, (V[]){v_r_2495, v_e_2496});
    }
    case TAG_MkResVals: {
      V v_e_2498 = heff_field(v_x1_2481, 1);
      heff_take_n(v_x1_2481, 2ULL, 2);
      return heff_tail(v_k_2494, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_2498});
    }
    default: return heff_nomatch(v_x1_2481);
    }
  }
  case TAG_EPrim: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242});
  }
  case TAG_EPrimCall: {
    V v_p_24100 = heff_field(v_e_242, 0);
    V v_args_24101 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_24102 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_24103 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_t_24102, v_env_241, v_args_24101));
    {
      V v_field_24104 = v_t_24103.f[0];
      V v_field_24105 = v_t_24103.f[1];
      V v_rs_24106 = v_field_24104;
      V v_es_24107 = v_field_24105;
      V v_t_24108 = (g_heff_2ecompile_2eranges_2eprimRange(v_p_24100, v_rs_24106));
      V v_t_24109 = (g_heff_2ecompile_2eranges_2eprimRange(v_p_24100, v_rs_24106));
      HeffT2 v_t_24110 = ({ V a_0 = v_p_24100; V a_1 = v_rs_24106; V a_2 = v_t_24109; HeffT2 r_ = (g_heff_2ecompile_2eranges_2ewordOf_24cpr(a_0, a_1, a_2)); heff_drop(v_rs_24106); r_; });
      V v_t_24114;
      {
        V v_field_24112 = v_t_24110.f[1];
        int64_t v_tag_24111 = ((int64_t)v_t_24110.f[0]);
        if ((v_tag_24111 == ((int64_t)0ULL))) {
          heff_drop(v_p_24100);
          V v_x_24113 = v_field_24112;
          v_t_24114 = v_x_24113;
        } else {
          heff_drop(v_field_24112);
          v_t_24114 = v_p_24100;
        }
      }
      return heff_tag_n(TAG_MkRes, 2, (V[]){v_t_24108, heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_t_24114, v_es_24107})});
    }
  }
  case TAG_ECall: {
    V v_g_24115 = heff_field(v_e_242, 0);
    V v_args_24116 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_24117 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_24118 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_t_24117, v_env_241, v_args_24116));
    {
      V v_field_24119 = v_t_24118.f[0];
      V v_field_24120 = v_t_24118.f[1];
      V v_rs_24121 = v_field_24119;
      heff_drop(v_rs_24121);
      V v_es_24122 = v_field_24120;
      return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_g_24115, v_es_24122})});
    }
  }
  case TAG_EInt: {
    V v_n_24123 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EInt = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    V v_t_24124 = heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_n_24123)}), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_n_24123)})});
    return heff_tag_n(TAG_MkRes, 2, (V[]){v_t_24124, heff_tag_at_n(v_ru_24e_242_24EInt, TAG_EInt, 1, (V[]){v_n_24123})});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242});
  }
  case TAG_EStr: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkRes, 2, (V[]){NTAG(TAG_Unreached), NTAG(TAG_EAbandon)});
  }
  case TAG_EBool: {
    V v_k_24131 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EBool = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_24132 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){heff_dup(v_c_240)}));
    V v_t_24133 = (g_heff_2ecompile_2eranges_2ewalkCond(v_c_240, v_t_24132, v_env_241, v_k_24131));
    return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_tag_at_n(v_ru_24e_242_24EBool, TAG_EBool, 1, (V[]){v_t_24133})});
  }
  case TAG_ESet: {
    V v_xs_24134 = heff_field(v_e_242, 0);
    V v_a_24135 = heff_field(v_e_242, 1);
    V v_b_24136 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_x1_24137 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(heff_dup(v_c_240), heff_dup(v_env_241), v_a_24135));
    V v_k_24147 = heff_clo_n(g_heff_2ecompile_2eranges_2ewalkGo_lam2, 2, 4, (V[]){v_xs_24134, v_env_241, v_c_240, v_b_24136});
    switch (heff_tag_of(v_x1_24137)) {
    case TAG_MkRes: {
      V v_e_24149 = heff_field(v_x1_24137, 1);
      heff_take_n(v_x1_24137, 2ULL, 2);
      return heff_tail(v_k_24147, 2, (V[]){NTAG(TAG_Nil), v_e_24149});
    }
    case TAG_MkResVals: {
      V v_rs_24150 = heff_field(v_x1_24137, 0);
      V v_e_24151 = heff_field(v_x1_24137, 1);
      heff_take_n(v_x1_24137, 3ULL, 2);
      return heff_tail(v_k_24147, 2, (V[]){v_rs_24150, v_e_24151});
    }
    default: return heff_nomatch(v_x1_24137);
    }
  }
  case TAG_EValues: {
    V v_es_24152 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EValues = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_24153 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_24154 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_t_24153, v_env_241, v_es_24152));
    {
      V v_field_24155 = v_t_24154.f[0];
      V v_field_24156 = v_t_24154.f[1];
      V v_rs_24157 = v_field_24155;
      V v_es_24158 = v_field_24156;
      return heff_tag_n(TAG_MkResVals, 2, (V[]){v_rs_24157, heff_tag_at_n(v_ru_24e_242_24EValues, TAG_EValues, 1, (V[]){v_es_24158})});
    }
  }
  case TAG_EFix: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eranges_2ewalkGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewalkGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eranges_2ewalkGo_lam0(V self, V *args) {
  V v_ra_2437 = args[0];
  V v_a1_2438 = args[1];
  V v_env_241 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  V v_a_2434 = heff_env(self)[2];
  V v_c_240 = heff_env(self)[3];
  V v_b_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2439 = (g_heff_2ecompile_2eranges_2ewithRange(v_env_241, heff_dup(v_x_2433), v_ra_2437));
  V v_t_2440 = (g_heff_2ecompile_2eranges_2ewithTest(v_t_2439, heff_dup(v_x_2433), v_a_2434));
  V v_x2_2441 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(v_c_240, v_t_2440, v_b_2435));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkRes: {
    V v_r_2442 = heff_field(v_x2_2441, 0);
    V v_e_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkRes = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2441_24MkRes, TAG_MkRes, 2, (V[]){v_r_2442, heff_tag_n(TAG_ELet, 3, (V[]){v_x_2433, v_a1_2438, v_e_2443})});
  }
  case TAG_MkResVals: {
    V v_rs_2444 = heff_field(v_x2_2441, 0);
    V v_e_2445 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkResVals = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2441_24MkResVals, TAG_MkResVals, 2, (V[]){v_rs_2444, heff_tag_n(TAG_ELet, 3, (V[]){v_x_2433, v_a1_2438, v_e_2445})});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2eranges_2ewalkGo_lam1(V self, V *args) {
  V v_x_2482 = args[0];
  V v_s1_2483 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  V v_s_2479 = heff_env(self)[2];
  V v_arms_2480 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2482);
  V v_t_2484 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){heff_dup(v_c_240)}));
  V v_t_2485 = (g_heff_2ecompile_2eranges_2etestOf(heff_dup(v_env_241), v_s_2479));
  HeffT3 v_t_2486 = ({ V a_0 = v_c_240; V a_1 = v_t_2484; V a_2 = v_env_241; V a_3 = v_t_2485; V a_4 = v_arms_2480; HeffT3 r_ = (g_heff_2ecompile_2eranges_2ewalkArms_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2485); heff_drop(v_arms_2480); r_; });
  {
    V v_field_2488 = v_t_2486.f[1];
    V v_field_2489 = v_t_2486.f[2];
    int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
    if ((v_tag_2487 == ((int64_t)0ULL))) {
      V v_r_2490 = v_field_2488;
      V v_arms_2491 = v_field_2489;
      return heff_tag_n(TAG_MkRes, 2, (V[]){v_r_2490, heff_tag_n(TAG_EMatch, 2, (V[]){v_s1_2483, v_arms_2491})});
    } else {
      V v_rs_2492 = v_field_2488;
      V v_arms_2493 = v_field_2489;
      return heff_tag_n(TAG_MkResVals, 2, (V[]){v_rs_2492, heff_tag_n(TAG_EMatch, 2, (V[]){v_s1_2483, v_arms_2493})});
    }
  }
}
V g_heff_2ecompile_2eranges_2ewalkGo_lam2(V self, V *args) {
  V v_rs_24138 = args[0];
  V v_a1_24139 = args[1];
  V v_xs_24134 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_b_24136 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24140 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_24134), v_rs_24138));
  V v_t_24141 = ({ V a_0 = v_env_241; V a_1 = v_t_24140; V r_ = (g_list_2efoldl_24s518632429x1911716206(a_0, a_1)); heff_drop(v_t_24140); r_; });
  V v_x2_24142 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(v_c_240, v_t_24141, v_b_24136));
  switch (heff_tag_of(v_x2_24142)) {
  case TAG_MkRes: {
    V v_r_24143 = heff_field(v_x2_24142, 0);
    V v_e_24144 = heff_field(v_x2_24142, 1);
    V v_ru_24x2_24142_24MkRes = heff_take_reuse_n(v_x2_24142, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24142_24MkRes, TAG_MkRes, 2, (V[]){v_r_24143, heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24134, v_a1_24139, v_e_24144})});
  }
  case TAG_MkResVals: {
    V v_rs_24145 = heff_field(v_x2_24142, 0);
    V v_e_24146 = heff_field(v_x2_24142, 1);
    V v_ru_24x2_24142_24MkResVals = heff_take_reuse_n(v_x2_24142, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24142_24MkResVals, TAG_MkResVals, 2, (V[]){v_rs_24145, heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24134, v_a1_24139, v_e_24146})});
  }
  default: return heff_nomatch(v_x2_24142);
  }
}
Clo g_heff_2ecompile_2eranges_2econstOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2econstOne_entry, 2, 0};

V g_heff_2ecompile_2eranges_2econstOne(V v_m_240, V v_d_241) {
top: ;
  V v_body_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_get_n(v_d_241, 0, 3);
  switch (heff_tag_of(v_body_242)) {
  case TAG_EVar: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ELam: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EApp: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_body_242, 0ULL, 4);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EInt: {
    V v_n_2429 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    return (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_key_243, v_n_2429));
  }
  case TAG_EFloat: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EBool: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ESet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EValues: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2ecompile_2eranges_2econstOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2econstOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2eabsorbOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eabsorbOne_entry, 2, 0};

V g_heff_2ecompile_2eranges_2eabsorbOne(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_g_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 0, 3);
    HeffT2 v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_g_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_old_248 = v_field_247;
        V v_t_249 = (g_list_2ezipWith_24s1026658656x682908126(heff_dup(v_old_248), heff_dup(v_rs_243)));
        V v_t_2410 = ({ V a_0 = v_old_248; V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2eranges_2erangesEq(a_0, a_1)); heff_drop(v_t_249); r_; });
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_old_248);
          heff_drop(v_t_2410);
          return v_s_240;
        } else {
          heff_drop(v_t_2410);
          V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 0, 3);
          V v_t_2412 = (g_list_2ezipWith_24s1026658656x682908126(heff_dup(v_old_248), heff_dup(v_rs_243)));
          V v_t_2413 = (g_heff_2ecompile_2eranges_2egrownTo(heff_dup(heff_rfield(v_s_240, 0)), v_g_242, heff_dup(v_old_248), v_t_2412));
          V v_t_2414 = (g_std_2emap_2einsert_24s93785294x875597928(v_t_2411, heff_dup(v_g_242), v_t_2413));
          V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 1, 3);
          V v_new_2416 = (g_list_2ezipWith_24s1026658656x682908126(heff_dup(v_old_248), heff_dup(v_rs_243)));
          V v_d_2417 = (g_list_2emap_24s258116700x992061112(MK_INT(0LL), heff_dup(v_old_248)));
          V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 1, 3);
          HeffT2 v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = v_g_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_2418); r_; });
          V v_t_2423;
          {
            V v_field_2421 = v_t_2419.f[1];
            int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
            if ((v_tag_2420 == ((int64_t)0ULL))) {
              heff_drop(v_d_2417);
              V v_x_2422 = v_field_2421;
              v_t_2423 = v_x_2422;
            } else {
              heff_drop(v_field_2421);
              v_t_2423 = v_d_2417;
            }
          }
          V v_t_2424 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2423, v_old_248));
          V v_t_2425 = (g_list_2ezipWith_24s1604775524x1614188687(MK_INT(1LL), v_t_2424, v_new_2416));
          V v_t_2426 = (g_std_2emap_2einsert_24s93785294x875597928(v_t_2415, heff_dup(v_g_242), v_t_2425));
          V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 2, 3);
          V v_t_2428 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_s_240, 1), heff_dup(v_g_242), NTAG(TAG_MkUnit)));
          return ({ V rv_0 = heff_rec_n(3, shape_params__grown__marks, (V[]){v_t_2414, v_t_2426, v_t_2427}); V rv_1 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_s_240, 4ULL, 3, shape_fix__dirty__gathered, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        }
      } else {
        heff_drop(v_field_247);
        return v_s_240;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eranges_2eabsorbOne_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2eabsorbOne(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eranges_2eabsorb_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eabsorb_entry, 3, 0};

V g_heff_2ecompile_2eranges_2eabsorb(V v_key_240, V v_s_241, V v_st_242) {
top: ;
  V v_marks_243 = heff_take_field(v_st_242, 1);
  V v_calls_244 = heff_get_n(v_st_242, 0, 2);
  V v_fix_245 = heff_take_field(v_s_241, 0);
  V v_dirty_246 = heff_take_field(v_s_241, 1);
  V v_gathered_247 = heff_get_n(v_s_241, 2, 3);
  V v_t_248 = ({ V a_0 = heff_dup(v_key_240); V a_1 = heff_take_field(v_fix_245, 2); V a_2 = v_marks_243; V r_ = (g_heff_2ecompile_2eranges_2emarksWith(a_0, a_1, a_2)); heff_drop(v_marks_243); r_; });
  V v_t_249 = ({ V rv_2 = v_t_248; V rr_ = heff_rec_reuse_nf(v_fix_245, 3ULL, 3, shape_params__grown__marks, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2410 = (g_std_2emap_2edelete_24s1614046289x1611773644(v_dirty_246, v_key_240));
  V v_t_2411 = (g_std_2emap_2einsert_24s93785294x875597928(v_gathered_247, v_key_240, heff_dup(v_calls_244)));
  V v_t_2412 = ({ V a_0 = v_calls_244; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_calls_244); r_; });
  return ({ V a_0 = heff_rec_n(3, shape_fix__dirty__gathered, (V[]){v_t_249, v_t_2410, v_t_2411}); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s405709498x1837254440(a_0, a_1)); heff_drop(v_t_2412); r_; });
}
V g_heff_2ecompile_2eranges_2eabsorb_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2eabsorb(a[0], a[1], a[2]);
}

static V g_heff_2ecompile_2eranges_2eemptyScan_val;
static HEFF_ONCE g_heff_2ecompile_2eranges_2eemptyScan_st;
static V g_heff_2ecompile_2eranges_2eemptyScan_init(void) {
  return heff_rec_n(5, shape_numeric__given__calls__ints__escapes, (V[]){heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_False), heff_dup(g_std_2emap_2eempty_get())});
}
V g_heff_2ecompile_2eranges_2eemptyScan_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eranges_2eemptyScan_st)) return g_heff_2ecompile_2eranges_2eemptyScan_val;
  return heff_global(&g_heff_2ecompile_2eranges_2eemptyScan_val, &g_heff_2ecompile_2eranges_2eemptyScan_st, g_heff_2ecompile_2eranges_2eemptyScan_init);
}
V g_heff_2ecompile_2eranges_2efnOf_lam0(V self, V *args);
V g_heff_2ecompile_2eranges_2efnOf_lam1(V self, V *args);
V g_heff_2ecompile_2eranges_2efnOf_lam2(V self, V *args);
Clo g_heff_2ecompile_2eranges_2efnOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2efnOf_entry, 2, 0};

V g_heff_2ecompile_2eranges_2efnOf(V v_xs_240, V v_s_241) {
top: ;
  V v_numeric_242 = heff_take_field(v_s_241, 0);
  V v_given_243 = heff_get_n(v_s_241, 1, 5);
  V v_t_249 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eranges_2efnOf_lam0, 1, 1, (V[]){v_numeric_242}), heff_dup(v_xs_240)));
  V v_t_2417 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2efnOf_lam1, 2, 1, (V[]){heff_dup(v_xs_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
  V v_t_2430 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2efnOf_lam2, 2, 1, (V[]){heff_dup(v_xs_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_given_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_given_243); r_; });
  return heff_rec_n(3, shape_params__numeric__forwards, (V[]){v_xs_240, v_t_2417, v_t_2430});
}
V g_heff_2ecompile_2eranges_2efnOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2efnOf(a[0], a[1]);
}
V g_heff_2ecompile_2eranges_2efnOf_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_numeric_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_245 = ({ V a_0 = v_numeric_242; V a_1 = v_x_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_numeric_242); heff_drop(v_x_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_246 == ((int64_t)0ULL)) && ({ V v_x_248 = heff_dup(v_field_247); int c_ = 1; heff_drop(v_x_248); c_; })));
    heff_drop(v_field_247);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2eranges_2efnOf_lam1(V self, V *args) {
  V v_is_2410 = args[0];
  V v_x_2411 = args[1];
  V v_xs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2412 = ({ V a_0 = v_x_2411; V a_1 = MK_INT(0LL); V a_2 = v_xs_240; HeffT2 r_ = (g_heff_2ecompile_2eranges_2eplaceOf_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_j_2415 = v_field_2414;
      V v_t_2416 = (g_list_2eany_24s688114072x773797180(heff_dup(v_j_2415), v_is_2410));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_j_2415);
        heff_drop(v_t_2416);
        return v_is_2410;
      } else {
        heff_drop(v_t_2416);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_j_2415, v_is_2410});
      }
    } else {
      heff_drop(v_field_2414);
      return v_is_2410;
    }
  }
}
V g_heff_2ecompile_2eranges_2efnOf_lam2(V self, V *args) {
  V v_acc_2418 = args[0];
  V v_p_2419 = args[1];
  V v_xs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422;
  switch (heff_tag_of(v_p_2419)) {
  case TAG_MkPair: {
    V v_y_2421 = heff_dup(heff_field(v_p_2419, 1));
    v_t_2422 = v_y_2421;
    break;
  }
  default: heff_nomatch(v_p_2419);
  }
  HeffT2 v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = MK_INT(0LL); V a_2 = v_xs_240; HeffT2 r_ = (g_heff_2ecompile_2eranges_2eplaceOf_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
  {
    V v_field_2425 = v_t_2423.f[1];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    if ((v_tag_2424 == ((int64_t)0ULL))) {
      V v_j_2426 = v_field_2425;
      V v_t_2429;
      switch (heff_tag_of(v_p_2419)) {
      case TAG_MkPair: {
        V v_x_2427 = heff_field(v_p_2419, 0);
        heff_take_n(v_p_2419, 1ULL, 2);
        v_t_2429 = v_x_2427;
        break;
      }
      default: heff_nomatch(v_p_2419);
      }
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_j_2426}), v_acc_2418});
    } else {
      heff_drop(v_p_2419);
      heff_drop(v_field_2425);
      return v_acc_2418;
    }
  }
}
V g_heff_2ecompile_2eranges_2ematterOne_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2ematterOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ematterOne_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ematterOne(V v_m_240, V v_fn_241, V v_is_242) {
top: ;
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2ematterOne_lam0, 2, 1, (V[]){heff_dup(v_m_240)}); V a_1 = v_is_242; V b_2 = heff_get_n(v_fn_241, 2, 3); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ecompile_2eranges_2ematterOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2ematterOne(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eranges_2ematterOne_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_p_244 = args[1];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_p_244, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2410;
  switch (heff_tag_of(v_t_247)) {
  case TAG_MkPair: {
    V v_y_249 = heff_field(v_t_247, 1);
    heff_take_n(v_t_247, 2ULL, 2);
    v_t_2410 = v_y_249;
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2413;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_dup(heff_field(v_p_244, 0));
    v_t_2413 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2416;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 2);
    v_t_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  HeffT2 v_t_2417 = ({ V a_0 = v_m_240; V a_1 = v_t_2416; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_m_240); heff_drop(v_t_2416); r_; });
  V v_t_2421;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2419;
      v_t_2421 = v_x_2420;
    } else {
      heff_drop(v_field_2419);
      v_t_2421 = NTAG(TAG_Nil);
    }
  }
  V v_t_2422 = ({ V a_0 = v_t_2410; V a_1 = v_t_2421; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_t_2421); r_; });
  if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
    heff_drop(v_t_2422);
    V v_t_2425;
    switch (heff_tag_of(v_p_244)) {
    case TAG_MkPair: {
      V v_y_2424 = heff_field(v_p_244, 1);
      heff_take_n(v_p_244, 2ULL, 2);
      v_t_2425 = v_y_2424;
      break;
    }
    default: heff_nomatch(v_p_244);
    }
    V v_t_2426 = (g_list_2eany_24s688114072x773797180(heff_dup(v_t_2425), v_acc_243));
    if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
      heff_drop(v_t_2425);
      heff_drop(v_t_2426);
      return v_acc_243;
    } else {
      heff_drop(v_t_2426);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_acc_243});
    }
  } else {
    heff_drop(v_p_244);
    heff_drop(v_t_2422);
    return v_acc_243;
  }
}
V g_heff_2ecompile_2eranges_2emattering_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2emattering_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emattering_entry, 3, 0};

V g_heff_2ecompile_2eranges_2emattering(V v_fws_240, V v_box_24n_241, V v_m_242) {
  int64_t v_n_241 = heff_unbox_word(v_box_24n_241);
top: ;
  if ((v_n_241 <= ((int64_t)0ULL))) {
    return v_m_242;
  } else {
    V v_next_2420 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2emattering_lam0, 2, 1, (V[]){heff_dup(v_m_242)}), heff_dup(v_m_242), v_fws_240));
    V v_t_2421 = (g_std_2emap_2etoListOnto(v_next_2420, NTAG(TAG_Nil)));
    V v_t_2422 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2421; V r_ = (g_list_2efoldl_24s37738078x926874390(a_0, a_1, a_2, a_3)); heff_drop(v_t_2421); r_; });
    V v_t_2423 = ({ V a_0 = v_m_242; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_242); r_; });
    V v_t_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2423; V r_ = (g_list_2efoldl_24s37738078x926874390(a_0, a_1, a_2, a_3)); heff_drop(v_t_2423); r_; });
    if (heff_intEq_c(v_t_2422, v_t_2424)) {
      return v_next_2420;
    } else {
      V t_0 = v_fws_240;
      int64_t t_1 = (v_n_241 - ((int64_t)1ULL));
      V t_2 = v_next_2420;
      v_fws_240 = t_0;
      v_n_241 = t_1;
      v_m_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eranges_2emattering_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2emattering(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eranges_2emattering_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_p_244 = args[1];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_p_244, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2410;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_y_249 = heff_dup(heff_field(v_p_244, 1));
    v_t_2410 = v_y_249;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2413;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_p_244, 0);
    heff_take_n(v_p_244, 1ULL, 2);
    v_t_2413 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  HeffT2 v_t_2414 = ({ V a_0 = v_m_242; V a_1 = v_t_2413; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_2413); r_; });
  V v_t_2418;
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2417 = v_field_2416;
      v_t_2418 = v_x_2417;
    } else {
      heff_drop(v_field_2416);
      v_t_2418 = NTAG(TAG_Nil);
    }
  }
  V v_t_2419 = ({ V a_0 = v_m_242; V a_1 = v_t_2410; V a_2 = v_t_2418; V r_ = (g_heff_2ecompile_2eranges_2ematterOne(a_0, a_1, a_2)); heff_drop(v_m_242); r_; });
  return (g_std_2emap_2einsert_24s93785294x875597928(v_acc_243, v_t_247, v_t_2419));
}
V g_heff_2ecompile_2eranges_2estartParams_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2estartParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2estartParams_entry, 2, 0};

V g_heff_2ecompile_2eranges_2estartParams(V v_fns_240, V v_ms_241) {
top: ;
  V v_t_242 = (g_std_2emap_2etoListOnto(v_ms_241, NTAG(TAG_Nil)));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2estartParams_lam0, 2, 1, (V[]){heff_dup(v_fns_240)}); V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2ecompile_2eranges_2estartParams_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2estartParams(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eranges_2estartParams_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x3_244 = args[1];
  V v_fns_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_244)) {
  case TAG_MkPair: {
    V v_k_245 = heff_field(v_x3_244, 0);
    V v_x32_246 = heff_field(v_x3_244, 1);
    heff_take_n(v_x3_244, 3ULL, 2);
    switch (heff_tag_of(v_x32_246)) {
    case TAG_Nil: {
      heff_drop(v_fns_240);
      heff_drop(v_k_245);
      return v_acc_243;
    }
    case TAG_Cons: {
      heff_take_n(v_x32_246, 0ULL, 2);
      HeffT2 v_t_249 = ({ V a_0 = v_fns_240; V a_1 = v_k_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_fns_240); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_fn_2412 = v_field_2411;
          V v_t_2413 = (g_list_2emap_24s1792553290x233563724(heff_get_n(v_fn_2412, 0, 3)));
          return (g_std_2emap_2einsert_24s93785294x875597928(v_acc_243, v_k_245, v_t_2413));
        } else {
          heff_drop(v_k_245);
          heff_drop(v_field_2411);
          return v_acc_243;
        }
      }
    }
    default: return heff_nomatch(v_x32_246);
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
Clo g_heff_2ecompile_2eranges_2erounds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erounds_entry, 4, 0};

V g_heff_2ecompile_2eranges_2erounds(V v_consts_240, V v_sc_241, V v_box_24n_242, V v_s_243) {
  int64_t v_n_242 = heff_unbox_word(v_box_24n_242);
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_s_243, 1));
  V v_t_2410;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Tip: {
    v_t_2410 = MK_INT(0LL);
    break;
  }
  case TAG_Bin: {
    V v_h_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 5);
    v_t_2410 = v_h_245;
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  if (heff_intEq_c(v_t_2410, MK_INT(0LL))) {
    heff_drop(v_consts_240);
    heff_drop(v_sc_241);
    return heff_tag_n(TAG_Just, 1, (V[]){v_s_243});
  } else {
    if ((v_n_242 <= ((int64_t)0ULL))) {
      heff_drop(v_consts_240);
      heff_drop(v_sc_241);
      heff_drop_rec(v_s_243, 3);
      return NTAG(TAG_Nothing);
    } else {
      V v_t_2411 = (g_std_2emap_2etoListOnto(heff_rfield(v_s_243, 1), NTAG(TAG_Nil)));
      V v_t_2412 = (g_list_2emap_24s1937570095x2110149801(v_t_2411));
      V v_t_2413 = ({ V a_0 = heff_dup(v_consts_240); V a_1 = heff_dup(v_sc_241); V a_2 = v_s_243; V a_3 = v_t_2412; V r_ = (g_heff_2ecompile_2eranges_2eroundOf(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
      V t_0 = v_consts_240;
      V t_1 = v_sc_241;
      int64_t t_2 = (v_n_242 - ((int64_t)1ULL));
      V t_3 = v_t_2413;
      v_consts_240 = t_0;
      v_sc_241 = t_1;
      v_n_242 = t_2;
      v_s_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eranges_2erounds_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2erounds(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eranges_2ejoinedFor_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2ejoinedFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ejoinedFor_entry, 4, 0};

V g_heff_2ecompile_2eranges_2ejoinedFor(V v_sc_240, V v_gathered_241, V v_old_242, V v_g_243) {
top: ;
  V v_t_244 = (g_list_2emap_24s1792553290x233563724(v_old_242));
  HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_sc_240, 2, 4); V a_1 = v_g_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_249;
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_247;
      v_t_249 = v_x_248;
    } else {
      heff_drop(v_field_247);
      v_t_249 = NTAG(TAG_Nil);
    }
  }
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2ejoinedFor_lam0, 2, 2, (V[]){heff_dup(v_gathered_241), heff_dup(v_g_243)}); V a_1 = v_t_244; V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
}
V g_heff_2ecompile_2eranges_2ejoinedFor_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2eranges_2ejoinedFor(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eranges_2ejoinedFor_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_k_2411 = args[1];
  V v_gathered_241 = heff_env(self)[0];
  V v_g_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2412 = ({ V a_0 = v_gathered_241; V a_1 = v_k_2411; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_gathered_241); heff_drop(v_k_2411); r_; });
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_calls_2415 = v_field_2414;
      HeffT2 v_t_2416 = ({ V a_0 = v_calls_2415; V a_1 = v_g_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_calls_2415); heff_drop(v_g_243); r_; });
      {
        V v_field_2418 = v_t_2416.f[1];
        int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          V v_rs_2419 = v_field_2418;
          return (g_list_2ezipWith_24s1026658656x682908126(v_acc_2410, v_rs_2419));
        } else {
          heff_drop(v_field_2418);
          return v_acc_2410;
        }
      }
    } else {
      heff_drop(v_g_243);
      heff_drop(v_field_2414);
      return v_acc_2410;
    }
  }
}
V g_heff_2ecompile_2eranges_2enarrowOnce_lam0(V self, V *args);
V g_heff_2ecompile_2eranges_2enarrowOnce_lam1(V self, V *args);
Clo g_heff_2ecompile_2eranges_2enarrowOnce_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enarrowOnce_entry, 4, 0};

V g_heff_2ecompile_2eranges_2enarrowOnce(V v_consts_240, V v_sc_241, V v_nw_242, V v_keys_243) {
top: ;
  V v_t_2412 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2enarrowOnce_lam0, 2, 3, (V[]){heff_dup(v_sc_241), heff_dup(v_nw_242), v_consts_240}), heff_dup(heff_rfield(v_nw_242, 1)), v_keys_243));
  V v_m_2420 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2enarrowOnce_lam1, 2, 1, (V[]){heff_dup(v_sc_241)}), heff_dup(g_std_2emap_2eempty_get()), v_keys_243));
  V v_t_2421 = ({ V a_0 = v_m_2420; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2420); r_; });
  V v_t_2422 = (g_list_2emap_24s1937570095x2110149801(v_t_2421));
  return ({ V a_0 = v_sc_241; V a_1 = v_nw_242; V a_2 = v_t_2412; V a_3 = v_t_2422; V r_ = (g_heff_2ecompile_2eranges_2enarrowWith(a_0, a_1, a_2, a_3)); heff_drop(v_t_2422); r_; });
}
V g_heff_2ecompile_2eranges_2enarrowOnce_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eranges_2enarrowOnce(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eranges_2enarrowOnce_lam0(V self, V *args) {
  V v_m_244 = args[0];
  V v_k_245 = args[1];
  V v_sc_241 = heff_env(self)[0];
  V v_nw_242 = heff_env(self)[1];
  V v_consts_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_sc_241, 0, 4); V a_1 = v_k_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_d_249 = v_field_248;
      V v_t_2410 = heff_rec_n(3, shape_params__consts__marking, (V[]){heff_get_n(v_nw_242, 0, 3), v_consts_240, NTAG(TAG_False)});
      V v_t_2411 = (g_heff_2ecompile_2eranges_2egatherDef(v_t_2410, v_d_249));
      return (g_std_2emap_2einsert_24s93785294x875597928(v_m_244, v_k_245, heff_get_n(v_t_2411, 0, 2)));
    } else {
      heff_drop(v_k_245);
      heff_drop_rec(v_nw_242, 3);
      heff_drop(v_consts_240);
      heff_drop(v_field_248);
      return v_m_244;
    }
  }
}
V g_heff_2ecompile_2eranges_2enarrowOnce_lam1(V self, V *args) {
  V v_m_2413 = args[0];
  V v_k_2414 = args[1];
  V v_sc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = ({ V b_0 = heff_get_n(v_sc_241, 1, 4); V a_1 = v_k_2414; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k_2414); r_; });
  V v_t_2419;
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2417;
      v_t_2419 = v_x_2418;
    } else {
      heff_drop(v_field_2417);
      v_t_2419 = NTAG(TAG_Nil);
    }
  }
  return ({ V a_0 = v_m_2413; V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_t_2419); r_; });
}
Clo g_heff_2ecompile_2eranges_2earmSeen_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2earmSeen_24tok2_entry, 3, 0};

V g_heff_2ecompile_2eranges_2earmSeen_24tok2(V v_tok_240, V v_x1_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_MkSeen: {
    V v_r_243 = heff_field(v_x1_241, 0);
    V v_st_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_x2_245 = heff_tr(heff_call(v_k_242, 1, (V[]){v_st_244}));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkSeen: {
      V v_rr_246 = heff_field(v_x2_245, 0);
      V v_st_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2eranges_2ejoin(v_r_243, v_rr_246));
      return heff_tag_at_n(v_tok_240, TAG_MkSeen, 2, (V[]){v_t_248, v_st_247});
    }
    case TAG_MkSeenVals: {
      V v_qs_249 = heff_field(v_x2_245, 0);
      V v_st_2410 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      switch (heff_tag_of(v_r_243)) {
      case TAG_Unreached: {
        return heff_tag_at_n(v_tok_240, TAG_MkSeenVals, 2, (V[]){v_qs_249, v_st_2410});
      }
      case TAG_Within: {
        heff_take_n(v_r_243, 0ULL, 2);
        heff_drop(v_qs_249);
        return heff_tag_at_n(v_tok_240, TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2410});
      }
      default: return heff_nomatch(v_r_243);
      }
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  case TAG_MkSeenVals: {
    V v_rs_2413 = heff_field(v_x1_241, 0);
    V v_st_2414 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_x2_2415 = heff_tr(heff_call(v_k_242, 1, (V[]){v_st_2414}));
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_MkSeen: {
      V v_r_2416 = heff_field(v_x2_2415, 0);
      V v_st_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      switch (heff_tag_of(v_r_2416)) {
      case TAG_Unreached: {
        return heff_tag_at_n(v_tok_240, TAG_MkSeenVals, 2, (V[]){v_rs_2413, v_st_2417});
      }
      case TAG_Within: {
        heff_take_n(v_r_2416, 0ULL, 2);
        heff_drop(v_rs_2413);
        return heff_tag_at_n(v_tok_240, TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2417});
      }
      default: return heff_nomatch(v_r_2416);
      }
    }
    case TAG_MkSeenVals: {
      V v_qs_2420 = heff_field(v_x2_2415, 0);
      V v_st_2421 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      V v_t_2422 = (g_list_2ezipWith_24s1026658656x682908126(v_rs_2413, v_qs_2420));
      return heff_tag_at_n(v_tok_240, TAG_MkSeenVals, 2, (V[]){v_t_2422, v_st_2421});
    }
    default: return heff_nomatch(v_x2_2415);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2eranges_2earmSeen_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2earmSeen_24tok2(a[0], a[1], a[2]);
}