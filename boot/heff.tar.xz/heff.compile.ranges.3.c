// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Bin 14227
#define TAG_MkArm 55352
#define TAG_MkRes 5766
#define TAG_MkSeen 11336
#define TAG_MkTest 41567
#define TAG_Tip 31527
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_byKey 295543458
#define LBL_callers 780494982
#define LBL_callersOf 583887482
#define LBL_calls 295783919
#define LBL_consts 592362651
#define LBL_dirty 296951788
#define LBL_escapes 914714193
#define LBL_fix 310927
#define LBL_forwards 1228451848
#define LBL_gathered 1327153563
#define LBL_given 299725719
#define LBL_grown 299987669
#define LBL_ints 9732907
#define LBL_marking 1071112247
#define LBL_marks 305024864
#define LBL_numeric 378927440
#define LBL_params 951713969
#define LBL_ranges 1008858625
static uint32_t shape_fix__dirty__gathered[] = {LBL_fix, LBL_dirty, LBL_gathered};
static uint32_t shape_numeric__given__calls__ints__escapes[] = {LBL_numeric, LBL_given, LBL_calls, LBL_ints, LBL_escapes};
static uint32_t shape_params__consts__marking[] = {LBL_params, LBL_consts, LBL_marking};
static uint32_t shape_params__grown__marks[] = {LBL_params, LBL_grown, LBL_marks};
static uint32_t shape_params__numeric__forwards[] = {LBL_params, LBL_numeric, LBL_forwards};
V g_heff_2ecompile_2eranges_2eabsorb(V, V, V);
V g_heff_2ecompile_2eranges_2eabsorb_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eabsorb_clo;
V g_heff_2ecompile_2eranges_2eabsorbOne(V, V);
V g_heff_2ecompile_2eranges_2eabsorbOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eabsorbOne_clo;
V g_heff_2ecompile_2eranges_2eandR(V, V);
V g_heff_2ecompile_2eranges_2eandR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eandR_clo;
V g_heff_2ecompile_2eranges_2eanyRange_get(void);
V g_heff_2ecompile_2eranges_2eemptyScan_get(void);
V g_heff_2ecompile_2eranges_2efnOf(V, V);
V g_heff_2ecompile_2eranges_2efnOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2efnOf_clo;
V g_heff_2ecompile_2eranges_2egatherDef(V, V);
V g_heff_2ecompile_2eranges_2egatherDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherDef_clo;
HeffT2 g_heff_2ecompile_2eranges_2egatherMany_24cpr(V, V, V, V);
V g_heff_2ecompile_2eranges_2egrownTo(V, V, V, V);
V g_heff_2ecompile_2eranges_2egrownTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egrownTo_clo;
HeffT2 g_heff_2ecompile_2eranges_2eheld_24cpr(V, V, V, V);
V g_heff_2ecompile_2eranges_2eisComparison(V);
V g_heff_2ecompile_2eranges_2eisComparison_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eisComparison_clo;
V g_heff_2ecompile_2eranges_2ejoin(V, V);
V g_heff_2ecompile_2eranges_2ejoin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoin_clo;
V g_heff_2ecompile_2eranges_2ejoinedFor(V, V, V, V);
V g_heff_2ecompile_2eranges_2ejoinedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoinedFor_clo;
V g_heff_2ecompile_2eranges_2emarksWith(V, V, V);
V g_heff_2ecompile_2eranges_2emarksWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emarksWith_clo;
V g_heff_2ecompile_2eranges_2ematterOne(V, V, V);
V g_heff_2ecompile_2eranges_2ematterOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ematterOne_clo;
V g_heff_2ecompile_2eranges_2emattering(V, V, V);
V g_heff_2ecompile_2eranges_2emattering_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emattering_clo;
V g_heff_2ecompile_2eranges_2emeet(V, V);
V g_heff_2ecompile_2eranges_2emeet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emeet_clo;
V g_heff_2ecompile_2eranges_2enarrowOnce(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowOnce_clo;
V g_heff_2ecompile_2eranges_2enarrowTo(V, V, V);
V g_heff_2ecompile_2eranges_2enarrowTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowTo_clo;
V g_heff_2ecompile_2eranges_2enarrowWith(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowWith_clo;
V g_heff_2ecompile_2eranges_2eoperandRange(V, V, V);
V g_heff_2ecompile_2eranges_2eoperandRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eoperandRange_clo;
HeffT2 g_heff_2ecompile_2eranges_2eplaceOf_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2erangesEq(V, V);
V g_heff_2ecompile_2eranges_2erangesEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangesEq_clo;
V g_heff_2ecompile_2eranges_2erefine(V, V, V, V);
V g_heff_2ecompile_2eranges_2erefine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erefine_clo;
V g_heff_2ecompile_2eranges_2erootGo(V, V, V);
V g_heff_2ecompile_2eranges_2erootGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erootGo_clo;
V g_heff_2ecompile_2eranges_2erootTo(V, V, V);
V g_heff_2ecompile_2eranges_2erootTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erootTo_clo;
V g_heff_2ecompile_2eranges_2eroundOf(V, V, V, V);
V g_heff_2ecompile_2eranges_2eroundOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eroundOf_clo;
V g_heff_2ecompile_2eranges_2erounds(V, V, V, V);
V g_heff_2ecompile_2eranges_2erounds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erounds_clo;
V g_heff_2ecompile_2eranges_2estartParams(V, V);
V g_heff_2ecompile_2eranges_2estartParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2estartParams_clo;
V g_heff_2ecompile_2eranges_2etestOf(V, V);
V g_heff_2ecompile_2eranges_2etestOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etestOf_clo;
HeffT2 g_heff_2ecompile_2eranges_2etestOf_24cpr(V, V);
V g_heff_2ecompile_2eranges_2etrimHigh(V, V);
V g_heff_2ecompile_2eranges_2etrimHigh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimHigh_clo;
V g_heff_2ecompile_2eranges_2etrimLow(V, V);
V g_heff_2ecompile_2eranges_2etrimLow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimLow_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewalkArms_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eranges_2ewalkGo(V, V, V);
V g_heff_2ecompile_2eranges_2ewalkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkGo_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewalkGo_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithRange_clo;
V g_list_2eany_24s120814613x1439363162(V, V);
V g_list_2eany_24s120814613x1439363162_entry(V self, V *a);
extern Clo g_list_2eany_24s120814613x1439363162_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s37738078x926874390(V, V, V, V);
V g_list_2efoldl_24s37738078x926874390_entry(V self, V *a);
extern Clo g_list_2efoldl_24s37738078x926874390_clo;
V g_list_2efoldl_24s405709498x1837254440(V, V);
V g_list_2efoldl_24s405709498x1837254440_entry(V self, V *a);
extern Clo g_list_2efoldl_24s405709498x1837254440_clo;
V g_list_2efoldl_24s477184376x1963488659(V, V);
V g_list_2efoldl_24s477184376x1963488659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s477184376x1963488659_clo;
V g_list_2emap_24s1792553290x233563724(V);
V g_list_2emap_24s1792553290x233563724_entry(V self, V *a);
extern Clo g_list_2emap_24s1792553290x233563724_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s258116700x992061112(V, V);
V g_list_2emap_24s258116700x992061112_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_clo;
V g_list_2ezipWith_24s1026658656x682908126(V, V);
V g_list_2ezipWith_24s1026658656x682908126_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1026658656x682908126_clo;
V g_list_2ezipWith_24s1604775524x1614188687(V, V, V);
V g_list_2ezipWith_24s1604775524x1614188687_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1604775524x1614188687_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_std_2emap_2edelete_24s339308281x1667047697(V, V);
V g_std_2emap_2edelete_24s339308281x1667047697_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s339308281x1667047697_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2eranges_2emeet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emeet_entry, 2, 0};

V g_heff_2ecompile_2eranges_2emeet(V v_r_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_r_240)) {
  case TAG_Unreached: {
    heff_drop(v_s_241);
    return NTAG(TAG_Unreached);
  }
  case TAG_Within: {
    V v_a_242 = heff_field(v_r_240, 0);
    V v_b_243 = heff_field(v_r_240, 1);
    V v_ru_24r_240_24Within = heff_take_reuse_n(v_r_240, 3ULL, 2);
    switch (heff_tag_of(v_s_241)) {
    case TAG_Unreached: {
      heff_drop(v_a_242);
      heff_drop(v_b_243);
      heff_drop_cell(v_ru_24r_240_24Within, 2);
      return NTAG(TAG_Unreached);
    }
    case TAG_Within: {
      V v_c_244 = heff_field(v_s_241, 0);
      V v_d_245 = heff_field(v_s_241, 1);
      heff_take_n(v_s_241, 3ULL, 2);
      V v_x1_2410;
      switch (heff_tag_of(v_a_242)) {
      case TAG_Nothing: {
        v_x1_2410 = v_c_244;
        break;
      }
      case TAG_Just: {
        V v_a_246 = heff_field(v_a_242, 0);
        V v_ru_24a_242_24Just = heff_take_reuse_n(v_a_242, 1ULL, 1);
        switch (heff_tag_of(v_c_244)) {
        case TAG_Nothing: {
          v_x1_2410 = heff_tag_at_n(v_ru_24a_242_24Just, TAG_Just, 1, (V[]){v_a_246});
          break;
        }
        case TAG_Just: {
          V v_b_247 = heff_field(v_c_244, 0);
          heff_take_n(v_c_244, 1ULL, 1);
          V v_t_249;
          if (heff_intLt_c_lent(v_a_246, v_b_247, 0)) {
            heff_drop(v_a_246);
            v_t_249 = v_b_247;
          } else {
            heff_drop(v_b_247);
            v_t_249 = v_a_246;
          }
          v_x1_2410 = heff_tag_at_n(v_ru_24a_242_24Just, TAG_Just, 1, (V[]){v_t_249});
          break;
        }
        default: heff_nomatch(v_c_244);
        }
        break;
      }
      default: heff_nomatch(v_a_242);
      }
      V v_x2_2415;
      switch (heff_tag_of(v_b_243)) {
      case TAG_Nothing: {
        v_x2_2415 = v_d_245;
        break;
      }
      case TAG_Just: {
        V v_a_2411 = heff_field(v_b_243, 0);
        V v_ru_24b_243_24Just = heff_take_reuse_n(v_b_243, 1ULL, 1);
        switch (heff_tag_of(v_d_245)) {
        case TAG_Nothing: {
          v_x2_2415 = heff_tag_at_n(v_ru_24b_243_24Just, TAG_Just, 1, (V[]){v_a_2411});
          break;
        }
        case TAG_Just: {
          V v_b_2412 = heff_field(v_d_245, 0);
          heff_take_n(v_d_245, 1ULL, 1);
          V v_t_2414;
          if (heff_intLt_c_lent(v_a_2411, v_b_2412, 0)) {
            heff_drop(v_b_2412);
            v_t_2414 = v_a_2411;
          } else {
            heff_drop(v_a_2411);
            v_t_2414 = v_b_2412;
          }
          v_x2_2415 = heff_tag_at_n(v_ru_24b_243_24Just, TAG_Just, 1, (V[]){v_t_2414});
          break;
        }
        default: heff_nomatch(v_d_245);
        }
        break;
      }
      default: heff_nomatch(v_b_243);
      }
      switch (heff_tag_of(v_x1_2410)) {
      case TAG_Nothing: {
        return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_x1_2410, v_x2_2415});
      }
      case TAG_Just: {
        V v_lo_2416 = heff_dup(heff_field(v_x1_2410, 0));
        switch (heff_tag_of(v_x2_2415)) {
        case TAG_Nothing: {
          heff_drop(v_lo_2416);
          return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_x1_2410, v_x2_2415});
        }
        case TAG_Just: {
          V v_hi_2417 = heff_field(v_x2_2415, 0);
          heff_take_n(v_x2_2415, 1ULL, 1);
          heff_drop_tag(v_x1_2410, 1);
          if (heff_intLt_c_lent(v_hi_2417, v_lo_2416, 0)) {
            heff_drop_cell(v_ru_24r_240_24Within, 2);
            heff_drop(v_lo_2416);
            heff_drop(v_hi_2417);
            return NTAG(TAG_Unreached);
          } else {
            return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_lo_2416}), heff_tag_n(TAG_Just, 1, (V[]){v_hi_2417})});
          }
        }
        default: return heff_nomatch(v_x2_2415);
        }
      }
      default: return heff_nomatch(v_x1_2410);
      }
    }
    default: return heff_nomatch(v_s_241);
    }
  }
  default: return heff_nomatch(v_r_240);
  }
}
V g_heff_2ecompile_2eranges_2emeet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2emeet(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2eandR_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eandR_entry, 2, 0};

V g_heff_2ecompile_2eranges_2eandR(V v_a_240, V v_b_241) {
top: ;
  V v_t_249;
  switch (heff_tag_of(v_a_240)) {
  case TAG_Unreached: {
    v_t_249 = NTAG(TAG_False);
    break;
  }
  case TAG_Within: {
    V v_lo_242 = heff_dup(heff_field(v_a_240, 0));
    switch (heff_tag_of(v_lo_242)) {
    case TAG_Nothing: {
      v_t_249 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_a_244 = heff_field(v_lo_242, 0);
      heff_take_n(v_lo_242, 1ULL, 1);
      if (heff_intLe_c(MK_INT(0LL), v_a_244)) {
        switch (heff_tag_of(v_b_241)) {
        case TAG_Unreached: {
          v_t_249 = NTAG(TAG_False);
          break;
        }
        case TAG_Within: {
          V v_lo_246 = heff_dup(heff_field(v_b_241, 0));
          switch (heff_tag_of(v_lo_246)) {
          case TAG_Nothing: {
            v_t_249 = NTAG(TAG_False);
            break;
          }
          case TAG_Just: {
            V v_a_248 = heff_field(v_lo_246, 0);
            heff_take_n(v_lo_246, 1ULL, 1);
            v_t_249 = heff_intLe(MK_INT(0LL), v_a_248);
            break;
          }
          default: heff_nomatch(v_lo_246);
          }
          break;
        }
        default: heff_nomatch(v_b_241);
        }
      } else {
        v_t_249 = NTAG(TAG_False);
      }
      break;
    }
    default: heff_nomatch(v_lo_242);
    }
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    HEFF_LAST return g_heff_2ecompile_2eranges_2emeet(v_a_240, v_b_241);
  } else {
    heff_drop(v_t_249);
    switch (heff_tag_of(v_a_240)) {
    case TAG_Unreached: {
      switch (heff_tag_of(v_b_241)) {
      case TAG_Unreached: {
        return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
      case TAG_Within: {
        V v_lo_2410 = heff_dup(heff_field(v_b_241, 0));
        switch (heff_tag_of(v_lo_2410)) {
        case TAG_Nothing: {
          heff_drop_tag(v_b_241, 2);
          return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
        }
        case TAG_Just: {
          V v_a_2412 = heff_field(v_lo_2410, 0);
          V v_ru_24lo_2410_24Just = heff_take_reuse_n(v_lo_2410, 1ULL, 1);
          if (heff_intLe_c(MK_INT(0LL), v_a_2412)) {
            V v_t_2416;
            switch (heff_tag_of(v_b_241)) {
            case TAG_Unreached: {
              v_t_2416 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Within: {
              V v_hi_2415 = heff_field(v_b_241, 1);
              heff_take_n(v_b_241, 2ULL, 2);
              v_t_2416 = v_hi_2415;
              break;
            }
            default: heff_nomatch(v_b_241);
            }
            return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24lo_2410_24Just, TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2416});
          } else {
            heff_drop_tag(v_b_241, 2);
            heff_drop_cell(v_ru_24lo_2410_24Just, 1);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
        }
        default: return heff_nomatch(v_lo_2410);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    case TAG_Within: {
      V v_lo_2417 = heff_dup(heff_field(v_a_240, 0));
      switch (heff_tag_of(v_lo_2417)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_240, 2);
        switch (heff_tag_of(v_b_241)) {
        case TAG_Unreached: {
          return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
        }
        case TAG_Within: {
          V v_lo_2419 = heff_dup(heff_field(v_b_241, 0));
          switch (heff_tag_of(v_lo_2419)) {
          case TAG_Nothing: {
            heff_drop_tag(v_b_241, 2);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          case TAG_Just: {
            V v_a_2421 = heff_field(v_lo_2419, 0);
            V v_ru_24lo_2419_24Just = heff_take_reuse_n(v_lo_2419, 1ULL, 1);
            if (heff_intLe_c(MK_INT(0LL), v_a_2421)) {
              V v_t_2425;
              switch (heff_tag_of(v_b_241)) {
              case TAG_Unreached: {
                v_t_2425 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Within: {
                V v_hi_2424 = heff_field(v_b_241, 1);
                heff_take_n(v_b_241, 2ULL, 2);
                v_t_2425 = v_hi_2424;
                break;
              }
              default: heff_nomatch(v_b_241);
              }
              return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24lo_2419_24Just, TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2425});
            } else {
              heff_drop_tag(v_b_241, 2);
              heff_drop_cell(v_ru_24lo_2419_24Just, 1);
              return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
            }
          }
          default: return heff_nomatch(v_lo_2419);
          }
        }
        default: return heff_nomatch(v_b_241);
        }
      }
      case TAG_Just: {
        V v_a_2426 = heff_field(v_lo_2417, 0);
        V v_ru_24lo_2417_24Just = heff_take_reuse_n(v_lo_2417, 1ULL, 1);
        if (heff_intLe_c(MK_INT(0LL), v_a_2426)) {
          heff_drop(v_b_241);
          V v_t_2430;
          switch (heff_tag_of(v_a_240)) {
          case TAG_Unreached: {
            v_t_2430 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Within: {
            V v_hi_2429 = heff_field(v_a_240, 1);
            heff_take_n(v_a_240, 2ULL, 2);
            v_t_2430 = v_hi_2429;
            break;
          }
          default: heff_nomatch(v_a_240);
          }
          return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24lo_2417_24Just, TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2430});
        } else {
          heff_drop_tag(v_a_240, 2);
          switch (heff_tag_of(v_b_241)) {
          case TAG_Unreached: {
            heff_drop_cell(v_ru_24lo_2417_24Just, 1);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          case TAG_Within: {
            V v_lo_2431 = heff_dup(heff_field(v_b_241, 0));
            switch (heff_tag_of(v_lo_2431)) {
            case TAG_Nothing: {
              heff_drop_tag(v_b_241, 2);
              heff_drop_cell(v_ru_24lo_2417_24Just, 1);
              return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
            }
            case TAG_Just: {
              V v_a_2433 = heff_field(v_lo_2431, 0);
              heff_take_n(v_lo_2431, 1ULL, 1);
              if (heff_intLe_c(MK_INT(0LL), v_a_2433)) {
                V v_t_2437;
                switch (heff_tag_of(v_b_241)) {
                case TAG_Unreached: {
                  v_t_2437 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Within: {
                  V v_hi_2436 = heff_field(v_b_241, 1);
                  heff_take_n(v_b_241, 2ULL, 2);
                  v_t_2437 = v_hi_2436;
                  break;
                }
                default: heff_nomatch(v_b_241);
                }
                return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24lo_2417_24Just, TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2437});
              } else {
                heff_drop_tag(v_b_241, 2);
                heff_drop_cell(v_ru_24lo_2417_24Just, 1);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
            }
            default: return heff_nomatch(v_lo_2431);
            }
          }
          default: return heff_nomatch(v_b_241);
          }
        }
      }
      default: return heff_nomatch(v_lo_2417);
      }
    }
    default: return heff_nomatch(v_a_240);
    }
  }
}
V g_heff_2ecompile_2eranges_2eandR_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2eandR(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str0, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str1, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str2, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str3, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str4, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str5, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str6, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str7, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str8, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str9, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str10, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str11, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str12, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str13, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str14, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str15, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str16, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str17, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str18, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str19, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eisComparison_str20, 5, "intLe");
Clo g_heff_2ecompile_2eranges_2eisComparison_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eisComparison_entry, 1, 0};

V g_heff_2ecompile_2eranges_2eisComparison(V v_p_240) {
top: ;
  V v_t_244;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str0), 2)) {
    v_t_244 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str1);
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str2), 2)) {
      v_t_244 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str3);
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str4), 2)) {
        v_t_244 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str5);
      } else {
        v_t_244 = heff_dup(v_p_240);
      }
    }
  }
  if (heff_strEq_c(v_t_244, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str6))) {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  } else {
    V v_t_249;
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str7), 2)) {
      v_t_249 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str8);
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str9), 2)) {
        v_t_249 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str10);
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str11), 2)) {
          v_t_249 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str12);
        } else {
          v_t_249 = heff_dup(v_p_240);
        }
      }
    }
    if (heff_strEq_c(v_t_249, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str13))) {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    } else {
      V v_t_2414;
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str14), 2)) {
        heff_drop(v_p_240);
        v_t_2414 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str15);
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str16), 2)) {
          heff_drop(v_p_240);
          v_t_2414 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str17);
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str18), 2)) {
            heff_drop(v_p_240);
            v_t_2414 = ((V)&g_heff_2ecompile_2eranges_2eisComparison_str19);
          } else {
            v_t_2414 = v_p_240;
          }
        }
      }
      return heff_strEq(v_t_2414, ((V)&g_heff_2ecompile_2eranges_2eisComparison_str20));
    }
  }
}
V g_heff_2ecompile_2eranges_2eisComparison_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2eisComparison(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eranges_2eheld_24cpr_str0, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eheld_24cpr_str1, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eheld_24cpr_str2, 5, "intEq");

HeffT2 g_heff_2ecompile_2eranges_2eheld_24cpr(V v_p_240, V v_yes_241, V v_ra_242, V v_rb_243) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eheld_24cpr_str0), 2)) {
    if ((heff_dup(v_yes_241) == NTAG(TAG_True))) {
      V v_t_248;
      switch (heff_tag_of(v_rb_243)) {
      case TAG_Unreached: {
        v_t_248 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_hi_246 = heff_dup(heff_field(v_rb_243, 1));
        switch (heff_tag_of(v_hi_246)) {
        case TAG_Nothing: {
          v_t_248 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_a_247 = heff_field(v_hi_246, 0);
          V v_ru_24hi_246_24Just = heff_take_reuse_n(v_hi_246, 1ULL, 1);
          v_t_248 = heff_tag_at_n(v_ru_24hi_246_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_247, MK_INT(-1LL))});
          break;
        }
        default: heff_nomatch(v_hi_246);
        }
        break;
      }
      default: heff_nomatch(v_rb_243);
      }
      V v_t_249 = heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), v_t_248});
      V v_f_2410 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), v_t_249));
      V v_t_2414;
      switch (heff_tag_of(v_ra_242)) {
      case TAG_Unreached: {
        v_t_2414 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_lo_2411 = heff_field(v_ra_242, 0);
        heff_take_n(v_ra_242, 1ULL, 2);
        switch (heff_tag_of(v_lo_2411)) {
        case TAG_Nothing: {
          v_t_2414 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_a_2413 = heff_field(v_lo_2411, 0);
          V v_ru_24lo_2411_24Just = heff_take_reuse_n(v_lo_2411, 1ULL, 1);
          v_t_2414 = heff_tag_at_n(v_ru_24lo_2411_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2413, MK_INT(1LL))});
          break;
        }
        default: heff_nomatch(v_lo_2411);
        }
        break;
      }
      default: heff_nomatch(v_ra_242);
      }
      V v_t_2415 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2414, NTAG(TAG_Nothing)});
      V v_f_2416 = (g_heff_2ecompile_2eranges_2emeet(v_rb_243, v_t_2415));
      return ((HeffT2){{v_f_2410, v_f_2416}});
    } else {
      V v_t_2419;
      switch (heff_tag_of(v_rb_243)) {
      case TAG_Unreached: {
        v_t_2419 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_lo_2417 = heff_dup(heff_field(v_rb_243, 0));
        v_t_2419 = v_lo_2417;
        break;
      }
      default: heff_nomatch(v_rb_243);
      }
      V v_t_2420 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2419, NTAG(TAG_Nothing)});
      V v_f_2421 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), v_t_2420));
      V v_t_2424;
      switch (heff_tag_of(v_ra_242)) {
      case TAG_Unreached: {
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_hi_2423 = heff_field(v_ra_242, 1);
        heff_take_n(v_ra_242, 2ULL, 2);
        v_t_2424 = v_hi_2423;
        break;
      }
      default: heff_nomatch(v_ra_242);
      }
      V v_t_2425 = heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), v_t_2424});
      V v_f_2426 = (g_heff_2ecompile_2eranges_2emeet(v_rb_243, v_t_2425));
      return ((HeffT2){{v_f_2421, v_f_2426}});
    }
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eheld_24cpr_str1), 2)) {
      if ((heff_dup(v_yes_241) == NTAG(TAG_True))) {
        V v_t_2430;
        switch (heff_tag_of(v_rb_243)) {
        case TAG_Unreached: {
          v_t_2430 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Within: {
          V v_hi_2429 = heff_dup(heff_field(v_rb_243, 1));
          v_t_2430 = v_hi_2429;
          break;
        }
        default: heff_nomatch(v_rb_243);
        }
        V v_t_2431 = heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), v_t_2430});
        V v_f_2432 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), v_t_2431));
        V v_t_2435;
        switch (heff_tag_of(v_ra_242)) {
        case TAG_Unreached: {
          v_t_2435 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Within: {
          V v_lo_2433 = heff_field(v_ra_242, 0);
          heff_take_n(v_ra_242, 1ULL, 2);
          v_t_2435 = v_lo_2433;
          break;
        }
        default: heff_nomatch(v_ra_242);
        }
        V v_t_2436 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2435, NTAG(TAG_Nothing)});
        V v_f_2437 = (g_heff_2ecompile_2eranges_2emeet(v_rb_243, v_t_2436));
        return ((HeffT2){{v_f_2432, v_f_2437}});
      } else {
        V v_t_2441;
        switch (heff_tag_of(v_rb_243)) {
        case TAG_Unreached: {
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Within: {
          V v_lo_2438 = heff_dup(heff_field(v_rb_243, 0));
          switch (heff_tag_of(v_lo_2438)) {
          case TAG_Nothing: {
            v_t_2441 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_a_2440 = heff_field(v_lo_2438, 0);
            V v_ru_24lo_2438_24Just = heff_take_reuse_n(v_lo_2438, 1ULL, 1);
            v_t_2441 = heff_tag_at_n(v_ru_24lo_2438_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2440, MK_INT(1LL))});
            break;
          }
          default: heff_nomatch(v_lo_2438);
          }
          break;
        }
        default: heff_nomatch(v_rb_243);
        }
        V v_t_2442 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2441, NTAG(TAG_Nothing)});
        V v_f_2443 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), v_t_2442));
        V v_t_2447;
        switch (heff_tag_of(v_ra_242)) {
        case TAG_Unreached: {
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Within: {
          V v_hi_2445 = heff_field(v_ra_242, 1);
          heff_take_n(v_ra_242, 2ULL, 2);
          switch (heff_tag_of(v_hi_2445)) {
          case TAG_Nothing: {
            v_t_2447 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_a_2446 = heff_field(v_hi_2445, 0);
            V v_ru_24hi_2445_24Just = heff_take_reuse_n(v_hi_2445, 1ULL, 1);
            v_t_2447 = heff_tag_at_n(v_ru_24hi_2445_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2446, MK_INT(-1LL))});
            break;
          }
          default: heff_nomatch(v_hi_2445);
          }
          break;
        }
        default: heff_nomatch(v_ra_242);
        }
        V v_t_2448 = heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), v_t_2447});
        V v_f_2449 = (g_heff_2ecompile_2eranges_2emeet(v_rb_243, v_t_2448));
        return ((HeffT2){{v_f_2443, v_f_2449}});
      }
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eheld_24cpr_str2), 2)) {
        if ((heff_dup(v_yes_241) == NTAG(TAG_True))) {
          V v_f_2451 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), heff_dup(v_rb_243)));
          V v_f_2452 = (g_heff_2ecompile_2eranges_2emeet(v_ra_242, v_rb_243));
          return ((HeffT2){{v_f_2451, v_f_2452}});
        } else {
          V v_f_2459;
          switch (heff_tag_of(v_rb_243)) {
          case TAG_Unreached: {
            v_f_2459 = heff_dup(v_ra_242);
            break;
          }
          case TAG_Within: {
            V v_s1_2453 = heff_dup(heff_field(v_rb_243, 0));
            V v_s2_2454 = heff_dup(heff_field(v_rb_243, 1));
            switch (heff_tag_of(v_s1_2453)) {
            case TAG_Nothing: {
              heff_drop(v_s2_2454);
              v_f_2459 = heff_dup(v_ra_242);
              break;
            }
            case TAG_Just: {
              V v_v_2455 = heff_field(v_s1_2453, 0);
              heff_take_n(v_s1_2453, 1ULL, 1);
              switch (heff_tag_of(v_s2_2454)) {
              case TAG_Nothing: {
                heff_drop(v_v_2455);
                v_f_2459 = heff_dup(v_ra_242);
                break;
              }
              case TAG_Just: {
                V v_w_2456 = heff_field(v_s2_2454, 0);
                heff_take_n(v_s2_2454, 1ULL, 1);
                if (heff_intEq_c_lent(v_v_2455, v_w_2456, 2)) {
                  V v_t_2458 = (g_heff_2ecompile_2eranges_2etrimLow(heff_dup(v_v_2455), heff_dup(v_ra_242)));
                  v_f_2459 = (g_heff_2ecompile_2eranges_2etrimHigh(v_v_2455, v_t_2458));
                } else {
                  heff_drop(v_v_2455);
                  v_f_2459 = heff_dup(v_ra_242);
                }
                break;
              }
              default: heff_nomatch(v_s2_2454);
              }
              break;
            }
            default: heff_nomatch(v_s1_2453);
            }
            break;
          }
          default: heff_nomatch(v_rb_243);
          }
          V v_f_2466;
          switch (heff_tag_of(v_ra_242)) {
          case TAG_Unreached: {
            v_f_2466 = v_rb_243;
            break;
          }
          case TAG_Within: {
            V v_s1_2460 = heff_field(v_ra_242, 0);
            V v_s2_2461 = heff_field(v_ra_242, 1);
            heff_take_n(v_ra_242, 3ULL, 2);
            switch (heff_tag_of(v_s1_2460)) {
            case TAG_Nothing: {
              heff_drop(v_s2_2461);
              v_f_2466 = v_rb_243;
              break;
            }
            case TAG_Just: {
              V v_v_2462 = heff_field(v_s1_2460, 0);
              heff_take_n(v_s1_2460, 1ULL, 1);
              switch (heff_tag_of(v_s2_2461)) {
              case TAG_Nothing: {
                heff_drop(v_v_2462);
                v_f_2466 = v_rb_243;
                break;
              }
              case TAG_Just: {
                V v_w_2463 = heff_field(v_s2_2461, 0);
                heff_take_n(v_s2_2461, 1ULL, 1);
                if (heff_intEq_c_lent(v_v_2462, v_w_2463, 2)) {
                  V v_t_2465 = (g_heff_2ecompile_2eranges_2etrimLow(heff_dup(v_v_2462), v_rb_243));
                  v_f_2466 = (g_heff_2ecompile_2eranges_2etrimHigh(v_v_2462, v_t_2465));
                } else {
                  heff_drop(v_v_2462);
                  v_f_2466 = v_rb_243;
                }
                break;
              }
              default: heff_nomatch(v_s2_2461);
              }
              break;
            }
            default: heff_nomatch(v_s1_2460);
            }
            break;
          }
          default: heff_nomatch(v_ra_242);
          }
          return ((HeffT2){{v_f_2459, v_f_2466}});
        }
      } else {
        return ((HeffT2){{v_ra_242, v_rb_243}});
      }
    }
  }
}
Clo g_heff_2ecompile_2eranges_2erootTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erootTo_entry, 3, 0};

V g_heff_2ecompile_2eranges_2erootTo(V v_env_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_Just: {
    V v_h_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    if (heff_intLe_c_lent(MK_INT(0LL), v_h_243, 1)) {
      HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_env_240, 0), v_x_241));
      V v_t_2410;
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          V v_x_249 = v_field_247;
          v_t_2410 = v_x_249;
        } else {
          heff_drop(v_field_247);
          v_t_2410 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
        }
      }
      V v_t_2412;
      if (heff_intLt_c_lent(v_h_243, MK_INT(2LL), 2)) {
        v_t_2412 = heff_dup(v_h_243);
      } else {
        v_t_2412 = heff_intAdd(heff_intDiv(heff_dup(v_h_243), MK_INT(2LL)), MK_INT(1LL));
      }
      V v_t_2413 = (g_heff_2ecompile_2eranges_2erootGo(heff_dup(v_h_243), MK_INT(0LL), v_t_2412));
      V v_t_2414 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_intSub(MK_INT(0LL), v_t_2413)});
      V v_t_2416;
      if (heff_intLt_c_lent(v_h_243, MK_INT(2LL), 2)) {
        v_t_2416 = heff_dup(v_h_243);
      } else {
        v_t_2416 = heff_intAdd(heff_intDiv(heff_dup(v_h_243), MK_INT(2LL)), MK_INT(1LL));
      }
      V v_t_2417 = (g_heff_2ecompile_2eranges_2erootGo(v_h_243, MK_INT(0LL), v_t_2416));
      V v_t_2418 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2414, heff_tag_n(TAG_Just, 1, (V[]){v_t_2417})});
      V v_t_2419 = (g_heff_2ecompile_2eranges_2emeet(v_t_2410, v_t_2418));
      HEFF_LAST return g_heff_2ecompile_2eranges_2ewithRange(v_env_240, v_x_241, v_t_2419);
    } else {
      heff_drop(v_x_241);
      heff_drop(v_h_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return v_env_240;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eranges_2erootTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2erootTo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eranges_2erefine_str0, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2erefine_str1, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2erefine_str2, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2erefine_str3, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2erefine_str4, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2erefine_str5, 5, "intLe");
Clo g_heff_2ecompile_2eranges_2erefine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erefine_entry, 4, 0};

V g_heff_2ecompile_2eranges_2erefine(V v_c_240, V v_env_241, V v_x3_242, V v_yes_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkTest: {
    V v_p_244 = heff_field(v_x3_242, 0);
    V v_a_245 = heff_field(v_x3_242, 1);
    V v_b_246 = heff_field(v_x3_242, 2);
    V v_t_2410;
    if (heff_strEq_c_lent(v_p_244, ((V)&g_heff_2ecompile_2eranges_2erefine_str0), 2)) {
      v_t_2410 = ((V)&g_heff_2ecompile_2eranges_2erefine_str1);
    } else {
      if (heff_strEq_c_lent(v_p_244, ((V)&g_heff_2ecompile_2eranges_2erefine_str2), 2)) {
        v_t_2410 = ((V)&g_heff_2ecompile_2eranges_2erefine_str3);
      } else {
        if (heff_strEq_c_lent(v_p_244, ((V)&g_heff_2ecompile_2eranges_2erefine_str4), 2)) {
          v_t_2410 = ((V)&g_heff_2ecompile_2eranges_2erefine_str5);
        } else {
          v_t_2410 = heff_dup(v_p_244);
        }
      }
    }
    V v_t_2411 = (g_heff_2ecompile_2eranges_2eoperandRange(heff_dup(v_c_240), heff_dup(v_env_241), heff_dup(v_a_245)));
    V v_t_2412 = (g_heff_2ecompile_2eranges_2eoperandRange(v_c_240, heff_dup(v_env_241), heff_dup(v_b_246)));
    HeffT2 v_t_2413 = ({ V a_0 = v_t_2410; V a_1 = v_yes_243; V a_2 = v_t_2411; V a_3 = v_t_2412; HeffT2 r_ = (g_heff_2ecompile_2eranges_2eheld_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_ra_2416 = v_field_2414;
      V v_rb_2417 = v_field_2415;
      V v_t_2418 = (g_heff_2ecompile_2eranges_2enarrowTo(v_env_241, v_a_245, v_ra_2416));
      return (g_heff_2ecompile_2eranges_2enarrowTo(v_t_2418, v_b_246, v_rb_2417));
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eranges_2erefine_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eranges_2erefine(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eranges_2etestOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2etestOf_entry, 2, 0};

V g_heff_2ecompile_2eranges_2etestOf(V v_env_240, V v_e_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2eranges_2etestOf_24cpr(v_env_240, v_e_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eranges_2etestOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2etestOf(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eranges_2egatherMany_24cpr(V v_go_240, V v_env_241, V v_st_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_env_241);
    return ((HeffT2){{NTAG(TAG_Nil), v_st_242}});
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_es_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_x1_246 = heff_tr(heff_call(heff_dup(v_go_240), 3, (V[]){heff_dup(v_env_241), v_st_242, v_e_244}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_MkSeen: {
      V v_r_247 = heff_field(v_x1_246, 0);
      V v_st_248 = heff_field(v_x1_246, 1);
      heff_take_n(v_x1_246, 3ULL, 2);
      HeffT2 v_t_249 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_go_240, v_env_241, v_st_248, v_es_245));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_rs_2412 = v_field_2410;
        V v_st_2413 = v_field_2411;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_r_247, v_rs_2412}), v_st_2413}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eranges_2ewalkArms_24cpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewalkArms_24cpr_str1, 5, "False");

HeffT2 g_heff_2ecompile_2eranges_2ewalkArms_24cpr(V v_c_240, V v_go_241, V v_env_242, V v_t_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_go_241);
    heff_drop(v_env_242);
    return ((HeffT2){{NTAG(TAG_Unreached), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_MkArm: {
      V v_tag_247 = heff_field(v_x51_245, 0);
      V v_vs_248 = heff_field(v_x51_245, 1);
      V v_b_249 = heff_field(v_x51_245, 2);
      heff_take_n(v_x51_245, 7ULL, 3);
      V v_t_2413;
      switch (heff_tag_of(v_t_243)) {
      case TAG_Nothing: {
        v_t_2413 = heff_dup(v_env_242);
        break;
      }
      case TAG_Just: {
        V v_t_2410 = heff_field(v_t_243, 0);
        if (heff_strEq_c_lent(v_tag_247, ((V)&g_heff_2ecompile_2eranges_2ewalkArms_24cpr_str0), 2)) {
          v_t_2413 = ({ V a_0 = heff_dup(v_c_240); V a_1 = heff_dup(v_env_242); V a_2 = v_t_2410; V b_3 = NTAG(TAG_True); V r_ = (g_heff_2ecompile_2eranges_2erefine(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
        } else {
          if (heff_strEq_c_lent(v_tag_247, ((V)&g_heff_2ecompile_2eranges_2ewalkArms_24cpr_str1), 2)) {
            v_t_2413 = ({ V a_0 = heff_dup(v_c_240); V a_1 = heff_dup(v_env_242); V a_2 = v_t_2410; V b_3 = NTAG(TAG_False); V r_ = (g_heff_2ecompile_2eranges_2erefine(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
          } else {
            v_t_2413 = heff_dup(v_env_242);
          }
        }
        break;
      }
      default: heff_nomatch(v_t_243);
      }
      V v_x3_2414 = heff_tr(heff_call(heff_dup(v_go_241), 2, (V[]){v_t_2413, v_b_249}));
      HeffT2 v_t_2415 = (g_heff_2ecompile_2eranges_2ewalkArms_24cpr(v_c_240, v_go_241, v_env_242, v_t_243, v_rest_246));
      {
        V v_field_2416 = v_t_2415.f[0];
        V v_field_2417 = v_t_2415.f[1];
        switch (heff_tag_of(v_x3_2414)) {
        case TAG_MkRes: {
          V v_r_2418 = heff_field(v_x3_2414, 0);
          V v_b_2419 = heff_field(v_x3_2414, 1);
          heff_take_n(v_x3_2414, 3ULL, 2);
          V v_rr_2420 = v_field_2416;
          V v_arms_2421 = v_field_2417;
          V v_f_2422 = (g_heff_2ecompile_2eranges_2ejoin(v_r_2418, v_rr_2420));
          V v_t_2423 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tag_247, v_vs_248, v_b_2419}), v_arms_2421});
          return ((HeffT2){{v_f_2422, v_t_2423}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x3_2414)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x51_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x5_244)}});
  }
}
Clo g_heff_2ecompile_2eranges_2ewalkGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewalkGo_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ewalkGo(V v_c_240, V v_env_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, v_env_241, v_e_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkRes, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2eranges_2ewalkGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewalkGo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eranges_2eabsorbOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eabsorbOne_entry, 2, 0};

V g_heff_2ecompile_2eranges_2eabsorbOne(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_g_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 0, 3);
    HeffT2 v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_g_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_old_249 = v_field_247;
        V v_t_2410 = (g_list_2ezipWith_24s1026658656x682908126(heff_dup(v_old_249), heff_dup(v_rs_243)));
        V v_t_2411 = ({ V a_0 = v_old_249; V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2eranges_2erangesEq(a_0, a_1)); heff_drop(v_t_2410); r_; });
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_old_249);
          heff_drop(v_t_2411);
          return v_s_240;
        } else {
          heff_drop(v_t_2411);
          V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 0, 3);
          V v_t_2413 = (g_list_2ezipWith_24s1026658656x682908126(heff_dup(v_old_249), heff_dup(v_rs_243)));
          V v_t_2414 = (g_heff_2ecompile_2eranges_2egrownTo(heff_dup(heff_rfield(v_s_240, 0)), v_g_242, heff_dup(v_old_249), v_t_2413));
          V v_t_2415 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_t_2412, heff_dup(v_g_242), v_t_2414));
          V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 1, 3);
          V v_new_2417 = (g_list_2ezipWith_24s1026658656x682908126(heff_dup(v_old_249), heff_dup(v_rs_243)));
          V v_d_2418 = (g_list_2emap_24s258116700x992061112(MK_INT(0LL), heff_dup(v_old_249)));
          V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 1, 3);
          HeffT2 v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = v_g_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_2419); r_; });
          V v_t_2425;
          {
            V v_field_2422 = v_t_2420.f[1];
            int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
            if ((v_tag_2421 == ((int64_t)0ULL))) {
              heff_drop(v_d_2418);
              V v_x_2424 = v_field_2422;
              v_t_2425 = v_x_2424;
            } else {
              heff_drop(v_field_2422);
              v_t_2425 = v_d_2418;
            }
          }
          V v_t_2426 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2425, v_old_249));
          V v_t_2427 = (g_list_2ezipWith_24s1604775524x1614188687(MK_INT(1LL), v_t_2426, v_new_2417));
          V v_t_2428 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_t_2416, heff_dup(v_g_242), v_t_2427));
          V v_t_2429 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 2, 3);
          V v_t_2430 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_s_240, 1), heff_dup(v_g_242), NTAG(TAG_MkUnit)));
          return ({ V rv_0 = heff_rec_n(3, shape_params__grown__marks, (V[]){v_t_2415, v_t_2428, v_t_2429}); V rv_1 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_s_240, 4ULL, 3, shape_fix__dirty__gathered, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        }
      } else {
        heff_drop(v_field_247);
        return v_s_240;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eranges_2eabsorbOne_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2eabsorbOne(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eranges_2eabsorb_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eabsorb_entry, 3, 0};

V g_heff_2ecompile_2eranges_2eabsorb(V v_key_240, V v_s_241, V v_st_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_241, 0)), 0, 3);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_241, 0)), 1, 3);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_241, 0)), 2, 3);
  V v_t_246 = (g_heff_2ecompile_2eranges_2emarksWith(heff_dup(v_key_240), v_t_245, heff_rfield(v_st_242, 1)));
  V v_t_247 = (g_std_2emap_2edelete_24s339308281x1667047697(heff_take_field(v_s_241, 1), v_key_240));
  V v_t_248 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_get_n(v_s_241, 2, 3), v_key_240, heff_dup(heff_rfield(v_st_242, 0))));
  V v_t_249 = heff_rec_n(3, shape_fix__dirty__gathered, (V[]){heff_rec_n(3, shape_params__grown__marks, (V[]){v_t_243, v_t_244, v_t_246}), v_t_247, v_t_248});
  V v_t_2410 = ({ V b_0 = heff_get_n(v_st_242, 0, 2); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  return ({ V a_0 = v_t_249; V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s405709498x1837254440(a_0, a_1)); heff_drop(v_t_2410); r_; });
}
V g_heff_2ecompile_2eranges_2eabsorb_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2eabsorb(a[0], a[1], a[2]);
}

static V g_heff_2ecompile_2eranges_2eemptyScan_val;
static HEFF_ONCE g_heff_2ecompile_2eranges_2eemptyScan_st;
static V g_heff_2ecompile_2eranges_2eemptyScan_init(void) {
  return heff_rec_n(5, shape_numeric__given__calls__ints__escapes, (V[]){heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_False), heff_dup(g_std_2emap_2eempty_get())});
}
V g_heff_2ecompile_2eranges_2eemptyScan_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eranges_2eemptyScan_st)) return g_heff_2ecompile_2eranges_2eemptyScan_val;
  return heff_global(&g_heff_2ecompile_2eranges_2eemptyScan_val, &g_heff_2ecompile_2eranges_2eemptyScan_st, g_heff_2ecompile_2eranges_2eemptyScan_init);
}
V g_heff_2ecompile_2eranges_2efnOf_lam0(V self, V *args);
V g_heff_2ecompile_2eranges_2efnOf_lam1(V self, V *args);
V g_heff_2ecompile_2eranges_2efnOf_lam2(V self, V *args);
Clo g_heff_2ecompile_2eranges_2efnOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2efnOf_entry, 2, 0};

V g_heff_2ecompile_2eranges_2efnOf(V v_xs_240, V v_s_241) {
top: ;
  V v_t_248 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eranges_2efnOf_lam0, 1, 1, (V[]){heff_dup(v_s_241)}), heff_dup(v_xs_240)));
  V v_t_2417 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2efnOf_lam1, 2, 1, (V[]){heff_dup(v_xs_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_t_2431 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2efnOf_lam2, 2, 1, (V[]){heff_dup(v_xs_240)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get_n(v_s_241, 1, 5); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  return heff_rec_n(3, shape_params__numeric__forwards, (V[]){v_xs_240, v_t_2417, v_t_2431});
}
V g_heff_2ecompile_2eranges_2efnOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2efnOf(a[0], a[1]);
}
V g_heff_2ecompile_2eranges_2efnOf_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_s_241, 0, 5); V a_1 = v_x_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_242); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_244 == ((int64_t)0ULL)) && ({ V v_x_247 = heff_dup(v_field_245); int c_ = 1; heff_drop(v_x_247); c_; })));
    heff_drop(v_field_245);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2eranges_2efnOf_lam1(V self, V *args) {
  V v_is_249 = args[0];
  V v_x_2410 = args[1];
  V v_xs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2411 = ({ V a_0 = v_x_2410; V a_1 = MK_INT(0LL); V a_2 = v_xs_240; HeffT2 r_ = (g_heff_2ecompile_2eranges_2eplaceOf_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2410); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_j_2415 = v_field_2413;
      V v_t_2416 = (g_list_2eany_24s120814613x1439363162(heff_dup(v_j_2415), v_is_249));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_j_2415);
        heff_drop(v_t_2416);
        return v_is_249;
      } else {
        heff_drop(v_t_2416);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_j_2415, v_is_249});
      }
    } else {
      heff_drop(v_field_2413);
      return v_is_249;
    }
  }
}
V g_heff_2ecompile_2eranges_2efnOf_lam2(V self, V *args) {
  V v_acc_2418 = args[0];
  V v_p_2419 = args[1];
  V v_xs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422;
  switch (heff_tag_of(v_p_2419)) {
  case TAG_MkPair: {
    V v_y_2421 = heff_dup(heff_field(v_p_2419, 1));
    v_t_2422 = v_y_2421;
    break;
  }
  default: heff_nomatch(v_p_2419);
  }
  HeffT2 v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = MK_INT(0LL); V a_2 = v_xs_240; HeffT2 r_ = (g_heff_2ecompile_2eranges_2eplaceOf_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
  {
    V v_field_2425 = v_t_2423.f[1];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    if ((v_tag_2424 == ((int64_t)0ULL))) {
      V v_j_2427 = v_field_2425;
      V v_t_2430;
      switch (heff_tag_of(v_p_2419)) {
      case TAG_MkPair: {
        V v_x_2428 = heff_field(v_p_2419, 0);
        heff_take_n(v_p_2419, 1ULL, 2);
        v_t_2430 = v_x_2428;
        break;
      }
      default: heff_nomatch(v_p_2419);
      }
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_j_2427}), v_acc_2418});
    } else {
      heff_drop(v_p_2419);
      heff_drop(v_field_2425);
      return v_acc_2418;
    }
  }
}
V g_heff_2ecompile_2eranges_2ematterOne_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2ematterOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ematterOne_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ematterOne(V v_m_240, V v_fn_241, V v_is_242) {
top: ;
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2ematterOne_lam0, 2, 1, (V[]){heff_dup(v_m_240)}); V a_1 = v_is_242; V b_2 = heff_get_n(v_fn_241, 2, 3); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ecompile_2eranges_2ematterOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2ematterOne(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eranges_2ematterOne_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_p_244 = args[1];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_p_244, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2410;
  switch (heff_tag_of(v_t_247)) {
  case TAG_MkPair: {
    V v_y_249 = heff_field(v_t_247, 1);
    heff_take_n(v_t_247, 2ULL, 2);
    v_t_2410 = v_y_249;
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2413;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_dup(heff_field(v_p_244, 0));
    v_t_2413 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2416;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 2);
    v_t_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  HeffT2 v_t_2417 = ({ V a_0 = v_m_240; V a_1 = v_t_2416; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_m_240); heff_drop(v_t_2416); r_; });
  V v_t_2422;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x_2421 = v_field_2419;
      v_t_2422 = v_x_2421;
    } else {
      heff_drop(v_field_2419);
      v_t_2422 = NTAG(TAG_Nil);
    }
  }
  V v_t_2423 = ({ V a_0 = v_t_2410; V a_1 = v_t_2422; V r_ = (g_list_2eany_24s120814613x1439363162(a_0, a_1)); heff_drop(v_t_2422); r_; });
  if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
    heff_drop(v_t_2423);
    V v_t_2426;
    switch (heff_tag_of(v_p_244)) {
    case TAG_MkPair: {
      V v_y_2425 = heff_field(v_p_244, 1);
      heff_take_n(v_p_244, 2ULL, 2);
      v_t_2426 = v_y_2425;
      break;
    }
    default: heff_nomatch(v_p_244);
    }
    V v_t_2427 = (g_list_2eany_24s120814613x1439363162(heff_dup(v_t_2426), v_acc_243));
    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
      heff_drop(v_t_2426);
      heff_drop(v_t_2427);
      return v_acc_243;
    } else {
      heff_drop(v_t_2427);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_acc_243});
    }
  } else {
    heff_drop(v_p_244);
    heff_drop(v_t_2423);
    return v_acc_243;
  }
}
V g_heff_2ecompile_2eranges_2emattering_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2emattering_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emattering_entry, 3, 0};

V g_heff_2ecompile_2eranges_2emattering(V v_fws_240, V v_box_24n_241, V v_m_242) {
  int64_t v_n_241 = heff_unbox_word(v_box_24n_241);
top: ;
  if ((v_n_241 <= ((int64_t)0ULL))) {
    return v_m_242;
  } else {
    V v_next_2422 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2emattering_lam0, 2, 1, (V[]){heff_dup(v_m_242)}), heff_dup(v_m_242), v_fws_240));
    V v_t_2423 = (g_std_2emap_2etoListOnto(v_next_2422, NTAG(TAG_Nil)));
    V v_t_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2423; V r_ = (g_list_2efoldl_24s37738078x926874390(a_0, a_1, a_2, a_3)); heff_drop(v_t_2423); r_; });
    V v_t_2425 = ({ V a_0 = v_m_242; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_242); r_; });
    V v_t_2426 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2425; V r_ = (g_list_2efoldl_24s37738078x926874390(a_0, a_1, a_2, a_3)); heff_drop(v_t_2425); r_; });
    if (heff_intEq_c(v_t_2424, v_t_2426)) {
      return v_next_2422;
    } else {
      V t_0 = v_fws_240;
      int64_t t_1 = (v_n_241 - ((int64_t)1ULL));
      V t_2 = v_next_2422;
      v_fws_240 = t_0;
      v_n_241 = t_1;
      v_m_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eranges_2emattering_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2emattering(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eranges_2emattering_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_p_245 = args[1];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_dup(heff_field(v_p_245, 0));
    v_t_248 = v_x_246;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_2411;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_y_2410 = heff_dup(heff_field(v_p_245, 1));
    v_t_2411 = v_y_2410;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_2414;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_p_245, 0);
    heff_take_n(v_p_245, 1ULL, 2);
    v_t_2414 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  HeffT2 v_t_2415 = ({ V a_0 = v_m_242; V a_1 = v_t_2414; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_t_2420;
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2417;
      v_t_2420 = v_x_2419;
    } else {
      heff_drop(v_field_2417);
      v_t_2420 = NTAG(TAG_Nil);
    }
  }
  V v_t_2421 = ({ V a_0 = v_m_242; V a_1 = v_t_2411; V a_2 = v_t_2420; V r_ = (g_heff_2ecompile_2eranges_2ematterOne(a_0, a_1, a_2)); heff_drop(v_m_242); r_; });
  return (g_std_2emap_2einsert_24s1305793909x1049798133(v_acc_244, v_t_248, v_t_2421));
}
V g_heff_2ecompile_2eranges_2estartParams_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2estartParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2estartParams_entry, 2, 0};

V g_heff_2ecompile_2eranges_2estartParams(V v_fns_240, V v_ms_241) {
top: ;
  V v_t_242 = (g_std_2emap_2etoListOnto(v_ms_241, NTAG(TAG_Nil)));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2estartParams_lam0, 2, 1, (V[]){heff_dup(v_fns_240)}); V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2ecompile_2eranges_2estartParams_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2estartParams(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eranges_2estartParams_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x3_244 = args[1];
  V v_fns_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_244)) {
  case TAG_MkPair: {
    V v_k_245 = heff_field(v_x3_244, 0);
    V v_x32_246 = heff_field(v_x3_244, 1);
    heff_take_n(v_x3_244, 3ULL, 2);
    switch (heff_tag_of(v_x32_246)) {
    case TAG_Nil: {
      heff_drop(v_fns_240);
      heff_drop(v_k_245);
      return v_acc_243;
    }
    case TAG_Cons: {
      heff_take_n(v_x32_246, 0ULL, 2);
      HeffT2 v_t_249 = ({ V a_0 = v_fns_240; V a_1 = v_k_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_fns_240); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_fn_2413 = v_field_2411;
          V v_t_2414 = (g_list_2emap_24s1792553290x233563724(heff_get_n(v_fn_2413, 0, 3)));
          return (g_std_2emap_2einsert_24s1305793909x1049798133(v_acc_243, v_k_245, v_t_2414));
        } else {
          heff_drop(v_k_245);
          heff_drop(v_field_2411);
          return v_acc_243;
        }
      }
    }
    default: return heff_nomatch(v_x32_246);
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
Clo g_heff_2ecompile_2eranges_2erounds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erounds_entry, 4, 0};

V g_heff_2ecompile_2eranges_2erounds(V v_consts_240, V v_sc_241, V v_box_24n_242, V v_s_243) {
  int64_t v_n_242 = heff_unbox_word(v_box_24n_242);
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_s_243, 1));
  V v_t_2410;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Tip: {
    v_t_2410 = MK_INT(0LL);
    break;
  }
  case TAG_Bin: {
    V v_h_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 5);
    v_t_2410 = v_h_245;
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  if (heff_intEq_c(v_t_2410, MK_INT(0LL))) {
    heff_drop(v_consts_240);
    heff_drop(v_sc_241);
    return heff_tag_n(TAG_Just, 1, (V[]){v_s_243});
  } else {
    if ((v_n_242 <= ((int64_t)0ULL))) {
      heff_drop(v_consts_240);
      heff_drop(v_sc_241);
      heff_drop_rec(v_s_243, 3);
      return NTAG(TAG_Nothing);
    } else {
      V v_t_2413 = (g_std_2emap_2etoListOnto(heff_rfield(v_s_243, 1), NTAG(TAG_Nil)));
      V v_t_2414 = (g_list_2emap_24s1937570095x2110149801(v_t_2413));
      V v_t_2415 = ({ V a_0 = heff_dup(v_consts_240); V a_1 = heff_dup(v_sc_241); V a_2 = v_s_243; V a_3 = v_t_2414; V r_ = (g_heff_2ecompile_2eranges_2eroundOf(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
      V t_0 = v_consts_240;
      V t_1 = v_sc_241;
      int64_t t_2 = (v_n_242 - ((int64_t)1ULL));
      V t_3 = v_t_2415;
      v_consts_240 = t_0;
      v_sc_241 = t_1;
      v_n_242 = t_2;
      v_s_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eranges_2erounds_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2erounds(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eranges_2ejoinedFor_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2ejoinedFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ejoinedFor_entry, 4, 0};

V g_heff_2ecompile_2eranges_2ejoinedFor(V v_sc_240, V v_gathered_241, V v_old_242, V v_g_243) {
top: ;
  V v_t_244 = (g_list_2emap_24s1792553290x233563724(v_old_242));
  HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_sc_240, 2, 4); V a_1 = v_g_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2410;
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_247;
      v_t_2410 = v_x_249;
    } else {
      heff_drop(v_field_247);
      v_t_2410 = NTAG(TAG_Nil);
    }
  }
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2ejoinedFor_lam0, 2, 2, (V[]){heff_dup(v_gathered_241), heff_dup(v_g_243)}); V a_1 = v_t_244; V a_2 = v_t_2410; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
}
V g_heff_2ecompile_2eranges_2ejoinedFor_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2eranges_2ejoinedFor(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eranges_2ejoinedFor_lam0(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_k_2412 = args[1];
  V v_gathered_241 = heff_env(self)[0];
  V v_g_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2413 = ({ V a_0 = v_gathered_241; V a_1 = v_k_2412; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_gathered_241); heff_drop(v_k_2412); r_; });
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_calls_2417 = v_field_2415;
      HeffT2 v_t_2418 = ({ V a_0 = v_calls_2417; V a_1 = v_g_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_calls_2417); heff_drop(v_g_243); r_; });
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          V v_rs_2422 = v_field_2420;
          return (g_list_2ezipWith_24s1026658656x682908126(v_acc_2411, v_rs_2422));
        } else {
          heff_drop(v_field_2420);
          return v_acc_2411;
        }
      }
    } else {
      heff_drop(v_g_243);
      heff_drop(v_field_2415);
      return v_acc_2411;
    }
  }
}
V g_heff_2ecompile_2eranges_2enarrowOnce_lam0(V self, V *args);
V g_heff_2ecompile_2eranges_2enarrowOnce_lam1(V self, V *args);
Clo g_heff_2ecompile_2eranges_2enarrowOnce_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enarrowOnce_entry, 4, 0};

V g_heff_2ecompile_2eranges_2enarrowOnce(V v_consts_240, V v_sc_241, V v_nw_242, V v_keys_243) {
top: ;
  V v_t_2413 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2enarrowOnce_lam0, 2, 3, (V[]){heff_dup(v_sc_241), heff_dup(v_nw_242), v_consts_240}), heff_dup(heff_rfield(v_nw_242, 1)), v_keys_243));
  V v_m_2422 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2enarrowOnce_lam1, 2, 1, (V[]){heff_dup(v_sc_241)}), heff_dup(g_std_2emap_2eempty_get()), v_keys_243));
  V v_t_2423 = ({ V a_0 = v_m_2422; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2422); r_; });
  V v_t_2424 = (g_list_2emap_24s1937570095x2110149801(v_t_2423));
  return ({ V a_0 = v_sc_241; V a_1 = v_nw_242; V a_2 = v_t_2413; V a_3 = v_t_2424; V r_ = (g_heff_2ecompile_2eranges_2enarrowWith(a_0, a_1, a_2, a_3)); heff_drop(v_t_2424); r_; });
}
V g_heff_2ecompile_2eranges_2enarrowOnce_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eranges_2enarrowOnce(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eranges_2enarrowOnce_lam0(V self, V *args) {
  V v_m_244 = args[0];
  V v_k_245 = args[1];
  V v_sc_241 = heff_env(self)[0];
  V v_nw_242 = heff_env(self)[1];
  V v_consts_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_sc_241, 0, 4); V a_1 = v_k_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_d_2410 = v_field_248;
      V v_t_2411 = heff_rec_n(3, shape_params__consts__marking, (V[]){heff_get_n(v_nw_242, 0, 3), v_consts_240, NTAG(TAG_False)});
      V v_t_2412 = (g_heff_2ecompile_2eranges_2egatherDef(v_t_2411, v_d_2410));
      return (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_244, v_k_245, heff_get_n(v_t_2412, 0, 2)));
    } else {
      heff_drop(v_k_245);
      heff_drop_rec(v_nw_242, 3);
      heff_drop(v_consts_240);
      heff_drop(v_field_248);
      return v_m_244;
    }
  }
}
V g_heff_2ecompile_2eranges_2enarrowOnce_lam1(V self, V *args) {
  V v_m_2414 = args[0];
  V v_k_2415 = args[1];
  V v_sc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_sc_241, 1, 4); V a_1 = v_k_2415; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k_2415); r_; });
  V v_t_2421;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2418;
      v_t_2421 = v_x_2420;
    } else {
      heff_drop(v_field_2418);
      v_t_2421 = NTAG(TAG_Nil);
    }
  }
  return ({ V a_0 = v_m_2414; V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s477184376x1963488659(a_0, a_1)); heff_drop(v_t_2421); r_; });
}