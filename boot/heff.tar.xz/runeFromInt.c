// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static V prim_runeFromInt_entry(V self, V *a) { (void)self; return heff_runeFromInt(a[0]); }
static Clo prim_runeFromInt_clo = {{0x80000000u, K_CLO, 0}, prim_runeFromInt_entry, 1, 0};
V g_runeFromInt_get(void);

static V g_runeFromInt_val;
static HEFF_ONCE g_runeFromInt_st;
static V g_runeFromInt_init(void) {
  return ((V)&prim_runeFromInt_clo);
}
V g_runeFromInt_get(void) {
  if (HEFF_DONE(g_runeFromInt_st)) return g_runeFromInt_val;
  return heff_global(&g_runeFromInt_val, &g_runeFromInt_st, g_runeFromInt_init);
}