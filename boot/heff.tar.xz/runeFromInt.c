// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static V prim_runeFromInt_entry(V self, V *a) { (void)self; return heff_runeFromInt(a[0]); }
static Clo prim_runeFromInt_clo = {{0x80000000u, K_CLO, 0}, prim_runeFromInt_entry, 1, 0};
V g_runeFromInt_get(void);

static V g_runeFromInt_val;
static int g_runeFromInt_st;
static V g_runeFromInt_init(void) {
  return ((V)&prim_runeFromInt_clo);
}
V g_runeFromInt_get(void) {
  if (g_runeFromInt_st == 2) return g_runeFromInt_val;
  if (g_runeFromInt_st == 1) heff_fail("defined by itself");
  g_runeFromInt_st = 1;
  g_runeFromInt_val = heff_tr(g_runeFromInt_init());
  g_runeFromInt_st = 2;
  return g_runeFromInt_val;
}