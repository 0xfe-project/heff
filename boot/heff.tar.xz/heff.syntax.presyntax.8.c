// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IPrim 59489
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_guard 300063423
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_stmts 311127493
static uint32_t shape_bind__pure[] = {LBL_bind, LBL_pure};
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2earmStmts(V);
V g_heff_2esyntax_2epresyntax_2earmStmts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmStmts_clo;
V g_heff_2esyntax_2epresyntax_2eboolOf(V);
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo;
V g_heff_2esyntax_2epresyntax_2ebytesTerm(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecoNames_get(void);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo;
V g_heff_2esyntax_2epresyntax_2econdT(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econdT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econdT_clo;
V g_heff_2esyntax_2epresyntax_2econtrolT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econtrolT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econtrolT_clo;
V g_heff_2esyntax_2epresyntax_2eforT(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2etryT(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryT_clo;
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_clo;
V g_heff_2esyntax_2epresyntax_2ewhileT(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileT_clo;
V g_heff_2esyntax_2epresyntax_2ewithT(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithT_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s930586707x1164893977(V, V);
V g_list_2eany_24s930586707x1164893977_entry(V self, V *a);
extern Clo g_list_2eany_24s930586707x1164893977_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s249042484x1701682908(V);
V g_list_2emap_24s249042484x1701682908_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_clo;
V g_list_2emap_24s272223926x273382154(V);
V g_list_2emap_24s272223926x273382154_entry(V self, V *a);
extern Clo g_list_2emap_24s272223926x273382154_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecoNames_str0, 4, "bind");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecoNames_str1, 4, "pure");

static V g_heff_2esyntax_2epresyntax_2ecoNames_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2ecoNames_st;
static V g_heff_2esyntax_2epresyntax_2ecoNames_init(void) {
  return heff_rec_n(2, shape_bind__pure, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecoNames_str0), ((V)&g_heff_2esyntax_2epresyntax_2ecoNames_str1)});
}
V g_heff_2esyntax_2epresyntax_2ecoNames_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2ecoNames_st)) return g_heff_2esyntax_2epresyntax_2ecoNames_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2ecoNames_val, &g_heff_2esyntax_2epresyntax_2ecoNames_st, g_heff_2esyntax_2epresyntax_2ecoNames_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str3, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str4, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str5, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str6, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str7, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str8, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str9, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str10, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str11, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str12, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str13, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str14, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str15, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str16, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str17, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str18, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str19, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str20, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str21, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str22, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str23, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str24, 14, "prelude.typeOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str25, 57, "` is not a `let mut` variable: only one is set, `let mut ");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str26, 5, " = e`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str27, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str28, 4, "True");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str29, 4, "True");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str30, 5, "False");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str31, 5, "False");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str32, 64, "`break` is in a loop only: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str33, 52, "nothing after `break` runs: it is the last statement");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str34, 52, "nothing after `break` runs: it is the last statement");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str35, 67, "`continue` is in a loop only: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str36, 55, "nothing after `continue` runs: it is the last statement");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str37, 55, "nothing after `continue` runs: it is the last statement");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str38, 53, "nothing after `return` runs: it is the last statement");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str39, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str40, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econtrolT_str41, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2econtrolT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2econtrolT_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2econtrolT(V v_t_240, V v_cx_241, V v_e_242, V v_rest_243, V v_end_244) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_At: {
    V v_e1_245 = heff_dup(heff_field(v_e_242, 0));
    V v_sp_246 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_e1_245)) {
    case TAG_EVar: {
      V v_ru_24e1_245_24EVar = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_248 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_248}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        V v_y_2413 = v_field_2411;
        V v_xsp_2414 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_2415 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24EVar, TAG_EVar, 1, (V[]){v_t_2416}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_2418 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str0), heff_dup(v_xsp_2414)}), heff_dup(v_rest_2415)});
        V v_t_2421;
        switch (heff_tag_of(v_rest_2415)) {
        case TAG_At: {
          V v_s_2420 = heff_field(v_rest_2415, 1);
          heff_take_n(v_rest_2415, 2ULL, 2);
          v_t_2421 = v_s_2420;
          break;
        }
        default: heff_nomatch(v_rest_2415);
        }
        V v_t_2422 = ({ V rv_1 = heff_get_n(v_t_2421, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2414, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_t_2422}), NTAG(TAG_Nil)});
        V v_t_2424 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2413, v_t_2423})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_2412; V a_2 = v_t_2424; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
      }
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_245_24EImplicitVar = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_2426 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_2427 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2426}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_2428 = v_t_2427.f[0];
        V v_field_2429 = v_t_2427.f[1];
        V v_x_2430 = v_field_2428;
        V v_y_2431 = v_field_2429;
        V v_xsp_2432 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_2433 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_2434 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24EImplicitVar, TAG_EVar, 1, (V[]){v_t_2434}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_2436 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str1), heff_dup(v_xsp_2432)}), heff_dup(v_rest_2433)});
        V v_t_2439;
        switch (heff_tag_of(v_rest_2433)) {
        case TAG_At: {
          V v_s_2438 = heff_field(v_rest_2433, 1);
          heff_take_n(v_rest_2433, 2ULL, 2);
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_rest_2433);
        }
        V v_t_2440 = ({ V rv_1 = heff_get_n(v_t_2439, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2432, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2436, v_t_2440}), NTAG(TAG_Nil)});
        V v_t_2442 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2435, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2431, v_t_2441})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_2430; V a_2 = v_t_2442; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2430); r_; });
      }
    }
    case TAG_ETag: {
      V v_ru_24e1_245_24ETag = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_2444 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_2445 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2444}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_2446 = v_t_2445.f[0];
        V v_field_2447 = v_t_2445.f[1];
        V v_x_2448 = v_field_2446;
        V v_y_2449 = v_field_2447;
        V v_xsp_2450 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_2451 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_2452 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_2453 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24ETag, TAG_EVar, 1, (V[]){v_t_2452}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_2454 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str2), heff_dup(v_xsp_2450)}), heff_dup(v_rest_2451)});
        V v_t_2457;
        switch (heff_tag_of(v_rest_2451)) {
        case TAG_At: {
          V v_s_2456 = heff_field(v_rest_2451, 1);
          heff_take_n(v_rest_2451, 2ULL, 2);
          v_t_2457 = v_s_2456;
          break;
        }
        default: heff_nomatch(v_rest_2451);
        }
        V v_t_2458 = ({ V rv_1 = heff_get_n(v_t_2457, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2450, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2454, v_t_2458}), NTAG(TAG_Nil)});
        V v_t_2460 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2453, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2449, v_t_2459})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_2448; V a_2 = v_t_2460; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2448); r_; });
      }
    }
    case TAG_EInt: {
      V v_ru_24e1_245_24EInt = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_2462 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_2463 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2462}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_2464 = v_t_2463.f[0];
        V v_field_2465 = v_t_2463.f[1];
        V v_x_2466 = v_field_2464;
        V v_y_2467 = v_field_2465;
        V v_xsp_2468 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_2469 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_2470 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24EInt, TAG_EVar, 1, (V[]){v_t_2470}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_2472 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str3), heff_dup(v_xsp_2468)}), heff_dup(v_rest_2469)});
        V v_t_2475;
        switch (heff_tag_of(v_rest_2469)) {
        case TAG_At: {
          V v_s_2474 = heff_field(v_rest_2469, 1);
          heff_take_n(v_rest_2469, 2ULL, 2);
          v_t_2475 = v_s_2474;
          break;
        }
        default: heff_nomatch(v_rest_2469);
        }
        V v_t_2476 = ({ V rv_1 = heff_get_n(v_t_2475, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2468, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2472, v_t_2476}), NTAG(TAG_Nil)});
        V v_t_2478 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2471, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2467, v_t_2477})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_2466; V a_2 = v_t_2478; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2466); r_; });
      }
    }
    case TAG_EFloat: {
      V v_ru_24e1_245_24EFloat = heff_take_reuse_na(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_2480 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_2481 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2480}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_2482 = v_t_2481.f[0];
        V v_field_2483 = v_t_2481.f[1];
        V v_x_2484 = v_field_2482;
        V v_y_2485 = v_field_2483;
        V v_xsp_2486 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_2487 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_2488 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24EFloat, TAG_EVar, 1, (V[]){v_t_2488}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_2490 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str4), heff_dup(v_xsp_2486)}), heff_dup(v_rest_2487)});
        V v_t_2493;
        switch (heff_tag_of(v_rest_2487)) {
        case TAG_At: {
          V v_s_2492 = heff_field(v_rest_2487, 1);
          heff_take_n(v_rest_2487, 2ULL, 2);
          v_t_2493 = v_s_2492;
          break;
        }
        default: heff_nomatch(v_rest_2487);
        }
        V v_t_2494 = ({ V rv_1 = heff_get_n(v_t_2493, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2486, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2490, v_t_2494}), NTAG(TAG_Nil)});
        V v_t_2496 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2489, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2485, v_t_2495})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_2484; V a_2 = v_t_2496; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2484); r_; });
      }
    }
    case TAG_EString: {
      V v_ru_24e1_245_24EString = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_2498 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_2499 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2498}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24100 = v_t_2499.f[0];
        V v_field_24101 = v_t_2499.f[1];
        V v_x_24102 = v_field_24100;
        V v_y_24103 = v_field_24101;
        V v_xsp_24104 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24105 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24106 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24107 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24EString, TAG_EVar, 1, (V[]){v_t_24106}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24108 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str5), heff_dup(v_xsp_24104)}), heff_dup(v_rest_24105)});
        V v_t_24111;
        switch (heff_tag_of(v_rest_24105)) {
        case TAG_At: {
          V v_s_24110 = heff_field(v_rest_24105, 1);
          heff_take_n(v_rest_24105, 2ULL, 2);
          v_t_24111 = v_s_24110;
          break;
        }
        default: heff_nomatch(v_rest_24105);
        }
        V v_t_24112 = ({ V rv_1 = heff_get_n(v_t_24111, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24104, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24113 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24108, v_t_24112}), NTAG(TAG_Nil)});
        V v_t_24114 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24107, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24103, v_t_24113})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24102; V a_2 = v_t_24114; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24102); r_; });
      }
    }
    case TAG_EBinary: {
      V v_ru_24e1_245_24EBinary = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24116 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24117 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24116}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24118 = v_t_24117.f[0];
        V v_field_24119 = v_t_24117.f[1];
        V v_x_24120 = v_field_24118;
        V v_y_24121 = v_field_24119;
        V v_xsp_24122 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24123 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24124 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24125 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24EBinary, TAG_EVar, 1, (V[]){v_t_24124}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24126 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str6), heff_dup(v_xsp_24122)}), heff_dup(v_rest_24123)});
        V v_t_24129;
        switch (heff_tag_of(v_rest_24123)) {
        case TAG_At: {
          V v_s_24128 = heff_field(v_rest_24123, 1);
          heff_take_n(v_rest_24123, 2ULL, 2);
          v_t_24129 = v_s_24128;
          break;
        }
        default: heff_nomatch(v_rest_24123);
        }
        V v_t_24130 = ({ V rv_1 = heff_get_n(v_t_24129, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24122, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24131 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24126, v_t_24130}), NTAG(TAG_Nil)});
        V v_t_24132 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24125, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24121, v_t_24131})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24120; V a_2 = v_t_24132; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24120); r_; });
      }
    }
    case TAG_ERune: {
      V v_ru_24e1_245_24ERune = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24134 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24135 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24134}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24136 = v_t_24135.f[0];
        V v_field_24137 = v_t_24135.f[1];
        V v_x_24138 = v_field_24136;
        V v_y_24139 = v_field_24137;
        V v_xsp_24140 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24141 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24142 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24ERune, TAG_EVar, 1, (V[]){v_t_24142}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24144 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str7), heff_dup(v_xsp_24140)}), heff_dup(v_rest_24141)});
        V v_t_24147;
        switch (heff_tag_of(v_rest_24141)) {
        case TAG_At: {
          V v_s_24146 = heff_field(v_rest_24141, 1);
          heff_take_n(v_rest_24141, 2ULL, 2);
          v_t_24147 = v_s_24146;
          break;
        }
        default: heff_nomatch(v_rest_24141);
        }
        V v_t_24148 = ({ V rv_1 = heff_get_n(v_t_24147, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24140, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24149 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24144, v_t_24148}), NTAG(TAG_Nil)});
        V v_t_24150 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24143, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24139, v_t_24149})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24138; V a_2 = v_t_24150; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24138); r_; });
      }
    }
    case TAG_EWord: {
      V v_ru_24e1_245_24EWord = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24152 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24153 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24152}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24154 = v_t_24153.f[0];
        V v_field_24155 = v_t_24153.f[1];
        V v_x_24156 = v_field_24154;
        V v_y_24157 = v_field_24155;
        V v_xsp_24158 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24159 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24160 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24161 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24EWord, TAG_EVar, 1, (V[]){v_t_24160}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24162 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str8), heff_dup(v_xsp_24158)}), heff_dup(v_rest_24159)});
        V v_t_24165;
        switch (heff_tag_of(v_rest_24159)) {
        case TAG_At: {
          V v_s_24164 = heff_field(v_rest_24159, 1);
          heff_take_n(v_rest_24159, 2ULL, 2);
          v_t_24165 = v_s_24164;
          break;
        }
        default: heff_nomatch(v_rest_24159);
        }
        V v_t_24166 = ({ V rv_1 = heff_get_n(v_t_24165, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24158, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24167 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24162, v_t_24166}), NTAG(TAG_Nil)});
        V v_t_24168 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24161, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24157, v_t_24167})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24156; V a_2 = v_t_24168; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24156); r_; });
      }
    }
    case TAG_EApp: {
      V v_ru_24e1_245_24EApp = heff_take_reuse_n(v_e1_245, 0ULL, 2);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24171 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24172 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24171}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24173 = v_t_24172.f[0];
        V v_field_24174 = v_t_24172.f[1];
        V v_x_24175 = v_field_24173;
        V v_y_24176 = v_field_24174;
        V v_xsp_24177 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24178 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24179 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24180 = heff_tag_at_n(v_ru_24e1_245_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24179}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24181 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str9), heff_dup(v_xsp_24177)}), heff_dup(v_rest_24178)});
        V v_t_24184;
        switch (heff_tag_of(v_rest_24178)) {
        case TAG_At: {
          V v_s_24183 = heff_field(v_rest_24178, 1);
          heff_take_n(v_rest_24178, 2ULL, 2);
          v_t_24184 = v_s_24183;
          break;
        }
        default: heff_nomatch(v_rest_24178);
        }
        V v_t_24185 = ({ V rv_1 = heff_get_n(v_t_24184, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24177, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24186 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24181, v_t_24185}), NTAG(TAG_Nil)});
        V v_t_24187 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24180, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24176, v_t_24186})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24175; V a_2 = v_t_24187; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24175); r_; });
      }
    }
    case TAG_EProject: {
      V v_ru_24e1_245_24EProject = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24189 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24190 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24189}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24191 = v_t_24190.f[0];
        V v_field_24192 = v_t_24190.f[1];
        V v_x_24193 = v_field_24191;
        V v_y_24194 = v_field_24192;
        V v_xsp_24195 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24196 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24197 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24198 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24EProject, TAG_EVar, 1, (V[]){v_t_24197}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24199 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str10), heff_dup(v_xsp_24195)}), heff_dup(v_rest_24196)});
        V v_t_24202;
        switch (heff_tag_of(v_rest_24196)) {
        case TAG_At: {
          V v_s_24201 = heff_field(v_rest_24196, 1);
          heff_take_n(v_rest_24196, 2ULL, 2);
          v_t_24202 = v_s_24201;
          break;
        }
        default: heff_nomatch(v_rest_24196);
        }
        V v_t_24203 = ({ V rv_1 = heff_get_n(v_t_24202, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24195, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24204 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24199, v_t_24203}), NTAG(TAG_Nil)});
        V v_t_24205 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24198, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24194, v_t_24204})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24193; V a_2 = v_t_24205; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24193); r_; });
      }
    }
    case TAG_ENamed: {
      V v_ru_24e1_245_24ENamed = heff_take_reuse_n(v_e1_245, 0ULL, 2);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24208 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24209 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24208}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24210 = v_t_24209.f[0];
        V v_field_24211 = v_t_24209.f[1];
        V v_x_24212 = v_field_24210;
        V v_y_24213 = v_field_24211;
        V v_xsp_24214 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24215 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24216 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24217 = heff_tag_at_n(v_ru_24e1_245_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24216}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24218 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str11), heff_dup(v_xsp_24214)}), heff_dup(v_rest_24215)});
        V v_t_24221;
        switch (heff_tag_of(v_rest_24215)) {
        case TAG_At: {
          V v_s_24220 = heff_field(v_rest_24215, 1);
          heff_take_n(v_rest_24215, 2ULL, 2);
          v_t_24221 = v_s_24220;
          break;
        }
        default: heff_nomatch(v_rest_24215);
        }
        V v_t_24222 = ({ V rv_1 = heff_get_n(v_t_24221, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24214, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24223 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24218, v_t_24222}), NTAG(TAG_Nil)});
        V v_t_24224 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24217, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24213, v_t_24223})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24212; V a_2 = v_t_24224; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24212); r_; });
      }
    }
    case TAG_EPi: {
      V v_ru_24e1_245_24EPi = heff_take_reuse_n(v_e1_245, 0ULL, 2);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24227 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24228 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24227}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24229 = v_t_24228.f[0];
        V v_field_24230 = v_t_24228.f[1];
        V v_x_24231 = v_field_24229;
        V v_y_24232 = v_field_24230;
        V v_xsp_24233 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24234 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24235 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24236 = heff_tag_at_n(v_ru_24e1_245_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24235}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24237 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str12), heff_dup(v_xsp_24233)}), heff_dup(v_rest_24234)});
        V v_t_24240;
        switch (heff_tag_of(v_rest_24234)) {
        case TAG_At: {
          V v_s_24239 = heff_field(v_rest_24234, 1);
          heff_take_n(v_rest_24234, 2ULL, 2);
          v_t_24240 = v_s_24239;
          break;
        }
        default: heff_nomatch(v_rest_24234);
        }
        V v_t_24241 = ({ V rv_1 = heff_get_n(v_t_24240, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24233, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24237, v_t_24241}), NTAG(TAG_Nil)});
        V v_t_24243 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24236, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24232, v_t_24242})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24231; V a_2 = v_t_24243; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24231); r_; });
      }
    }
    case TAG_ELam: {
      V v_ru_24e1_245_24ELam = heff_take_reuse_n(v_e1_245, 0ULL, 2);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24246 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24247 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24246}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24248 = v_t_24247.f[0];
        V v_field_24249 = v_t_24247.f[1];
        V v_x_24250 = v_field_24248;
        V v_y_24251 = v_field_24249;
        V v_xsp_24252 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24253 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24254 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24255 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24254}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24256 = heff_tag_at_n(v_ru_24e1_245_24ELam, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str13), heff_dup(v_xsp_24252)}), heff_dup(v_rest_24253)});
        V v_t_24259;
        switch (heff_tag_of(v_rest_24253)) {
        case TAG_At: {
          V v_s_24258 = heff_field(v_rest_24253, 1);
          heff_take_n(v_rest_24253, 2ULL, 2);
          v_t_24259 = v_s_24258;
          break;
        }
        default: heff_nomatch(v_rest_24253);
        }
        V v_t_24260 = ({ V rv_1 = heff_get_n(v_t_24259, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24252, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24261 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24256, v_t_24260}), NTAG(TAG_Nil)});
        V v_t_24262 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24255, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24251, v_t_24261})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24250; V a_2 = v_t_24262; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24250); r_; });
      }
    }
    case TAG_EAnn: {
      V v_ru_24e1_245_24EAnn = heff_take_reuse_n(v_e1_245, 0ULL, 2);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24265 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24266 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24265}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24267 = v_t_24266.f[0];
        V v_field_24268 = v_t_24266.f[1];
        V v_x_24269 = v_field_24267;
        V v_y_24270 = v_field_24268;
        V v_xsp_24271 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24272 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24273 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24274 = heff_tag_at_n(v_ru_24e1_245_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24273}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24275 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str14), heff_dup(v_xsp_24271)}), heff_dup(v_rest_24272)});
        V v_t_24278;
        switch (heff_tag_of(v_rest_24272)) {
        case TAG_At: {
          V v_s_24277 = heff_field(v_rest_24272, 1);
          heff_take_n(v_rest_24272, 2ULL, 2);
          v_t_24278 = v_s_24277;
          break;
        }
        default: heff_nomatch(v_rest_24272);
        }
        V v_t_24279 = ({ V rv_1 = heff_get_n(v_t_24278, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24271, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24280 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24275, v_t_24279}), NTAG(TAG_Nil)});
        V v_t_24281 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24274, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24270, v_t_24280})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24269; V a_2 = v_t_24281; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24269); r_; });
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_245, 0ULL, 4);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24286 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24287 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24286}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24288 = v_t_24287.f[0];
        V v_field_24289 = v_t_24287.f[1];
        V v_x_24290 = v_field_24288;
        V v_y_24291 = v_field_24289;
        V v_xsp_24292 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24293 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24294 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24295 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24294}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24296 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str15), heff_dup(v_xsp_24292)}), heff_dup(v_rest_24293)});
        V v_t_24299;
        switch (heff_tag_of(v_rest_24293)) {
        case TAG_At: {
          V v_s_24298 = heff_field(v_rest_24293, 1);
          heff_take_n(v_rest_24293, 2ULL, 2);
          v_t_24299 = v_s_24298;
          break;
        }
        default: heff_nomatch(v_rest_24293);
        }
        V v_t_24300 = ({ V rv_1 = heff_get_n(v_t_24299, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24292, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24301 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24296, v_t_24300}), NTAG(TAG_Nil)});
        V v_t_24302 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24295, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24291, v_t_24301})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24290; V a_2 = v_t_24302; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24290); r_; });
      }
    }
    case TAG_ESig: {
      V v_ru_24e1_245_24ESig = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24304 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24305 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24304}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24306 = v_t_24305.f[0];
        V v_field_24307 = v_t_24305.f[1];
        V v_x_24308 = v_field_24306;
        V v_y_24309 = v_field_24307;
        V v_xsp_24310 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24311 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24312 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24313 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24ESig, TAG_EVar, 1, (V[]){v_t_24312}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24314 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str16), heff_dup(v_xsp_24310)}), heff_dup(v_rest_24311)});
        V v_t_24317;
        switch (heff_tag_of(v_rest_24311)) {
        case TAG_At: {
          V v_s_24316 = heff_field(v_rest_24311, 1);
          heff_take_n(v_rest_24311, 2ULL, 2);
          v_t_24317 = v_s_24316;
          break;
        }
        default: heff_nomatch(v_rest_24311);
        }
        V v_t_24318 = ({ V rv_1 = heff_get_n(v_t_24317, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24310, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24319 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24314, v_t_24318}), NTAG(TAG_Nil)});
        V v_t_24320 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24313, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24309, v_t_24319})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24308; V a_2 = v_t_24320; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24308); r_; });
      }
    }
    case TAG_ESum: {
      V v_ru_24e1_245_24ESum = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24322 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24323 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24322}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24324 = v_t_24323.f[0];
        V v_field_24325 = v_t_24323.f[1];
        V v_x_24326 = v_field_24324;
        V v_y_24327 = v_field_24325;
        V v_xsp_24328 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24329 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24330 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24331 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24ESum, TAG_EVar, 1, (V[]){v_t_24330}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24332 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str17), heff_dup(v_xsp_24328)}), heff_dup(v_rest_24329)});
        V v_t_24335;
        switch (heff_tag_of(v_rest_24329)) {
        case TAG_At: {
          V v_s_24334 = heff_field(v_rest_24329, 1);
          heff_take_n(v_rest_24329, 2ULL, 2);
          v_t_24335 = v_s_24334;
          break;
        }
        default: heff_nomatch(v_rest_24329);
        }
        V v_t_24336 = ({ V rv_1 = heff_get_n(v_t_24335, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24328, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24337 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24332, v_t_24336}), NTAG(TAG_Nil)});
        V v_t_24338 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24331, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24327, v_t_24337})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24326; V a_2 = v_t_24338; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24326); r_; });
      }
    }
    case TAG_EStruct: {
      V v_ru_24e1_245_24EStruct = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24340 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24341 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24340}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24342 = v_t_24341.f[0];
        V v_field_24343 = v_t_24341.f[1];
        V v_x_24344 = v_field_24342;
        V v_y_24345 = v_field_24343;
        V v_xsp_24346 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24347 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24348 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24349 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24EStruct, TAG_EVar, 1, (V[]){v_t_24348}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24350 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str18), heff_dup(v_xsp_24346)}), heff_dup(v_rest_24347)});
        V v_t_24353;
        switch (heff_tag_of(v_rest_24347)) {
        case TAG_At: {
          V v_s_24352 = heff_field(v_rest_24347, 1);
          heff_take_n(v_rest_24347, 2ULL, 2);
          v_t_24353 = v_s_24352;
          break;
        }
        default: heff_nomatch(v_rest_24347);
        }
        V v_t_24354 = ({ V rv_1 = heff_get_n(v_t_24353, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24346, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24355 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24350, v_t_24354}), NTAG(TAG_Nil)});
        V v_t_24356 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24349, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24345, v_t_24355})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24344; V a_2 = v_t_24356; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24344); r_; });
      }
    }
    case TAG_EUpdate: {
      V v_ru_24e1_245_24EUpdate = heff_take_reuse_n(v_e1_245, 0ULL, 2);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24359 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24360 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24359}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24361 = v_t_24360.f[0];
        V v_field_24362 = v_t_24360.f[1];
        V v_x_24363 = v_field_24361;
        V v_y_24364 = v_field_24362;
        V v_xsp_24365 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24366 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24367 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24368 = heff_tag_at_n(v_ru_24e1_245_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24367}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24369 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str19), heff_dup(v_xsp_24365)}), heff_dup(v_rest_24366)});
        V v_t_24372;
        switch (heff_tag_of(v_rest_24366)) {
        case TAG_At: {
          V v_s_24371 = heff_field(v_rest_24366, 1);
          heff_take_n(v_rest_24366, 2ULL, 2);
          v_t_24372 = v_s_24371;
          break;
        }
        default: heff_nomatch(v_rest_24366);
        }
        V v_t_24373 = ({ V rv_1 = heff_get_n(v_t_24372, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24365, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24374 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24369, v_t_24373}), NTAG(TAG_Nil)});
        V v_t_24375 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24368, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24364, v_t_24374})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24363; V a_2 = v_t_24375; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24363); r_; });
      }
    }
    case TAG_EMatch: {
      V v_s_24376 = heff_field(v_e1_245, 0);
      V v_alts_24377 = heff_field(v_e1_245, 1);
      heff_take_n(v_e1_245, 3ULL, 2);
      heff_drop_tag(v_e_242, 2);
      V v_t_24378 = (g_list_2emap_24s272223926x273382154(v_alts_24377));
      return (g_heff_2esyntax_2epresyntax_2econdT(v_t_240, v_cx_241, v_sp_246, v_s_24376, v_t_24378, v_rest_243, v_end_244));
    }
    case TAG_ELetIn: {
      V v_ru_24e1_245_24ELetIn = heff_take_reuse_n(v_e1_245, 0ULL, 2);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24381 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24382 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24381}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24383 = v_t_24382.f[0];
        V v_field_24384 = v_t_24382.f[1];
        V v_x_24385 = v_field_24383;
        V v_y_24386 = v_field_24384;
        V v_xsp_24387 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24388 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24389 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24390 = heff_tag_at_n(v_ru_24e1_245_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24389}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24391 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str20), heff_dup(v_xsp_24387)}), heff_dup(v_rest_24388)});
        V v_t_24394;
        switch (heff_tag_of(v_rest_24388)) {
        case TAG_At: {
          V v_s_24393 = heff_field(v_rest_24388, 1);
          heff_take_n(v_rest_24388, 2ULL, 2);
          v_t_24394 = v_s_24393;
          break;
        }
        default: heff_nomatch(v_rest_24388);
        }
        V v_t_24395 = ({ V rv_1 = heff_get_n(v_t_24394, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24387, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24396 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24391, v_t_24395}), NTAG(TAG_Nil)});
        V v_t_24397 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24390, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24386, v_t_24396})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24385; V a_2 = v_t_24397; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24385); r_; });
      }
    }
    case TAG_EDo: {
      V v_ru_24e1_245_24EDo = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24399 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24400 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24399}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24401 = v_t_24400.f[0];
        V v_field_24402 = v_t_24400.f[1];
        V v_x_24403 = v_field_24401;
        V v_y_24404 = v_field_24402;
        V v_xsp_24405 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24406 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24407 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24408 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24EDo, TAG_EVar, 1, (V[]){v_t_24407}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24409 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str21), heff_dup(v_xsp_24405)}), heff_dup(v_rest_24406)});
        V v_t_24412;
        switch (heff_tag_of(v_rest_24406)) {
        case TAG_At: {
          V v_s_24411 = heff_field(v_rest_24406, 1);
          heff_take_n(v_rest_24406, 2ULL, 2);
          v_t_24412 = v_s_24411;
          break;
        }
        default: heff_nomatch(v_rest_24406);
        }
        V v_t_24413 = ({ V rv_1 = heff_get_n(v_t_24412, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24405, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24409, v_t_24413}), NTAG(TAG_Nil)});
        V v_t_24415 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24408, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24404, v_t_24414})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24403; V a_2 = v_t_24415; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24403); r_; });
      }
    }
    case TAG_ELocal: {
      V v_ru_24e1_245_24ELocal = heff_take_reuse_n(v_e1_245, 0ULL, 2);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24418 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24419 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24418}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24420 = v_t_24419.f[0];
        V v_field_24421 = v_t_24419.f[1];
        V v_x_24422 = v_field_24420;
        V v_y_24423 = v_field_24421;
        V v_xsp_24424 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24425 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24426 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24427 = heff_tag_at_n(v_ru_24e1_245_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24426}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24428 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str22), heff_dup(v_xsp_24424)}), heff_dup(v_rest_24425)});
        V v_t_24431;
        switch (heff_tag_of(v_rest_24425)) {
        case TAG_At: {
          V v_s_24430 = heff_field(v_rest_24425, 1);
          heff_take_n(v_rest_24425, 2ULL, 2);
          v_t_24431 = v_s_24430;
          break;
        }
        default: heff_nomatch(v_rest_24425);
        }
        V v_t_24432 = ({ V rv_1 = heff_get_n(v_t_24431, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24424, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24428, v_t_24432}), NTAG(TAG_Nil)});
        V v_t_24434 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24427, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24423, v_t_24433})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24422; V a_2 = v_t_24434; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24422); r_; });
      }
    }
    case TAG_EInvalid: {
      V v_ru_24e1_245_24EInvalid = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24436 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24437 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24436}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24438 = v_t_24437.f[0];
        V v_field_24439 = v_t_24437.f[1];
        V v_x_24440 = v_field_24438;
        V v_y_24441 = v_field_24439;
        V v_xsp_24442 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24443 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24444 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24EInvalid, TAG_EVar, 1, (V[]){v_t_24444}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24446 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str23), heff_dup(v_xsp_24442)}), heff_dup(v_rest_24443)});
        V v_t_24449;
        switch (heff_tag_of(v_rest_24443)) {
        case TAG_At: {
          V v_s_24448 = heff_field(v_rest_24443, 1);
          heff_take_n(v_rest_24443, 2ULL, 2);
          v_t_24449 = v_s_24448;
          break;
        }
        default: heff_nomatch(v_rest_24443);
        }
        V v_t_24450 = ({ V rv_1 = heff_get_n(v_t_24449, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24442, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24446, v_t_24450}), NTAG(TAG_Nil)});
        V v_t_24452 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24445, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24441, v_t_24451})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24440; V a_2 = v_t_24452; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24440); r_; });
      }
    }
    case TAG_EAssign: {
      V v_x_24453 = heff_field(v_e1_245, 0);
      V v_xsp_24454 = heff_field(v_e1_245, 1);
      V v_v_24455 = heff_field(v_e1_245, 2);
      heff_take_n(v_e1_245, 7ULL, 3);
      heff_drop_tag(v_e_242, 2);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24456 = (g_list_2eany_24s930586707x1164893977(v_x_24453, heff_rfield(v_cx_241, 1)));
      if ((heff_dup(v_t_24456) == NTAG(TAG_True))) {
        heff_drop(v_t_24456);
        V v_t_24457 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
        HeffT2 v_t_24458 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24457}), NTAG(TAG_Nil), v_v_24455));
        {
          V v_field_24459 = v_t_24458.f[0];
          V v_field_24460 = v_t_24458.f[1];
          V v_x_24461 = v_field_24459;
          V v_y_24462 = v_field_24460;
          V v_t_24463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str24)}), heff_dup(v_xsp_24454)});
          V v_t_24464 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24453)}), heff_dup(v_xsp_24454)});
          V v_t_24465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24464, NTAG(TAG_Nil)});
          V v_t_24466 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24463, v_t_24465));
          V v_t_24469;
          switch (heff_tag_of(v_y_24462)) {
          case TAG_At: {
            V v_s_24468 = heff_dup(heff_field(v_y_24462, 1));
            v_t_24469 = v_s_24468;
            break;
          }
          default: heff_nomatch(v_y_24462);
          }
          V v_v_24470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_y_24462, v_t_24466}), v_t_24469});
          V v_body_24471 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
          V v_t_24472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_24453}), heff_dup(v_xsp_24454)});
          V v_t_24475;
          switch (heff_tag_of(v_body_24471)) {
          case TAG_At: {
            V v_s_24474 = heff_dup(heff_field(v_body_24471, 1));
            v_t_24475 = v_s_24474;
            break;
          }
          default: heff_nomatch(v_body_24471);
          }
          V v_t_24476 = ({ V rv_0 = heff_dup(heff_rfield(v_xsp_24454, 0)); V rr_ = heff_rec_reuse_nf(v_t_24475, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_24477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_24472, heff_dup(v_body_24471)}), v_t_24476});
          V v_t_24480;
          switch (heff_tag_of(v_body_24471)) {
          case TAG_At: {
            V v_s_24479 = heff_field(v_body_24471, 1);
            heff_take_n(v_body_24471, 2ULL, 2);
            v_t_24480 = v_s_24479;
            break;
          }
          default: heff_nomatch(v_body_24471);
          }
          V v_t_24481 = ({ V rv_1 = heff_get_n(v_t_24480, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24454, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24482 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_24470, v_t_24477}), v_t_24481});
          return ({ V a_0 = v_cx_241; V a_1 = v_x_24461; V a_2 = v_t_24482; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24461); r_; });
        }
      } else {
        heff_drop_rec(v_t_240, 1);
        heff_drop_rec(v_cx_241, 5);
        heff_drop(v_rest_243);
        heff_drop(v_end_244);
        heff_drop(v_v_24455);
        heff_drop(v_t_24456);
        V v_t_24483 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str25), heff_strAppend(heff_dup(v_x_24453), ((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str26)));
        V v_t_24484 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str27), heff_strAppend(v_x_24453, v_t_24483));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24484}), v_xsp_24454});
      }
    }
    case TAG_EWhile: {
      V v_c_24485 = heff_field(v_e1_245, 0);
      V v_body_24486 = heff_field(v_e1_245, 1);
      heff_take_n(v_e1_245, 3ULL, 2);
      heff_drop_tag(v_e_242, 2);
      return (g_heff_2esyntax_2epresyntax_2ewhileT(v_t_240, v_cx_241, v_sp_246, v_c_24485, v_body_24486, v_rest_243, v_end_244));
    }
    case TAG_EFor: {
      V v_p_24487 = heff_field(v_e1_245, 0);
      V v_c_24488 = heff_field(v_e1_245, 1);
      V v_body_24489 = heff_field(v_e1_245, 2);
      heff_take_n(v_e1_245, 7ULL, 3);
      heff_drop_tag(v_e_242, 2);
      return (g_heff_2esyntax_2epresyntax_2eforT(v_t_240, v_cx_241, v_sp_246, v_p_24487, v_c_24488, v_body_24489, v_rest_243, v_end_244));
    }
    case TAG_EIfThen: {
      V v_c_24490 = heff_field(v_e1_245, 0);
      V v_a_24491 = heff_field(v_e1_245, 1);
      V v_ru_24e1_245_24EIfThen = heff_take_reuse_n(v_e1_245, 3ULL, 2);
      heff_drop_tag(v_e_242, 2);
      V v_t_24492 = (g_heff_2esyntax_2epresyntax_2eboolOf(v_c_24490));
      V v_t_24493 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str28), heff_dup(v_sp_246), NTAG(TAG_Nil)});
      V v_t_24494 = heff_tag_at_n(v_ru_24e1_245_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str29)}), heff_dup(v_sp_246)});
      V v_x1_24495 = ({ V a_0 = v_t_24494; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_24498;
      switch (heff_tag_of(v_x1_24495)) {
      case TAG_At: {
        V v_s_24497 = heff_field(v_x1_24495, 1);
        heff_take_n(v_x1_24495, 2ULL, 2);
        v_t_24498 = v_s_24497;
        break;
      }
      default: heff_nomatch(v_x1_24495);
      }
      V v_t_24499 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_246, 0)); V rr_ = heff_rec_reuse_nf(v_t_24498, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_24500 = (g_heff_2esyntax_2epresyntax_2earmStmts(v_a_24491));
      V v_t_24501 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24493, v_t_24499}), v_t_24500});
      V v_t_24502 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str30), heff_dup(v_sp_246), NTAG(TAG_Nil)});
      V v_t_24503 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str31)}), heff_dup(v_sp_246)});
      V v_x1_24504 = ({ V a_0 = v_t_24503; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_24507;
      switch (heff_tag_of(v_x1_24504)) {
      case TAG_At: {
        V v_s_24506 = heff_field(v_x1_24504, 1);
        heff_take_n(v_x1_24504, 2ULL, 2);
        v_t_24507 = v_s_24506;
        break;
      }
      default: heff_nomatch(v_x1_24504);
      }
      V v_t_24508 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_246, 0)); V rr_ = heff_rec_reuse_nf(v_t_24507, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_24509 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24502, v_t_24508}), NTAG(TAG_Nil)});
      V v_t_24510 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24509, NTAG(TAG_Nil)});
      return (g_heff_2esyntax_2epresyntax_2econdT(v_t_240, v_cx_241, v_sp_246, v_t_24492, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24501, v_t_24510}), v_rest_243, v_end_244));
    }
    case TAG_EBreak: {
      heff_drop_rec(v_t_240, 1);
      heff_drop_tag(v_e_242, 2);
      heff_drop(v_end_244);
      V v_t_24511 = heff_dup(heff_rfield(v_cx_241, 2));
      switch (heff_tag_of(v_t_24511)) {
      case TAG_Nothing: {
        heff_drop_rec(v_cx_241, 5);
        switch (heff_tag_of(v_rest_243)) {
        case TAG_Nil: {
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str32)}), v_sp_246});
        }
        case TAG_Cons: {
          V v_s_24512 = heff_field(v_rest_243, 0);
          V v_ru_24rest_243_24Cons = heff_take_reuse_n(v_rest_243, 1ULL, 2);
          heff_drop_rec(v_sp_246, 2);
          V v_t_24516;
          switch (heff_tag_of(v_s_24512)) {
          case TAG_At: {
            V v_s_24515 = heff_field(v_s_24512, 1);
            heff_take_n(v_s_24512, 2ULL, 2);
            v_t_24516 = v_s_24515;
            break;
          }
          default: heff_nomatch(v_s_24512);
          }
          return heff_tag_at_n(v_ru_24rest_243_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str33)}), v_t_24516});
        }
        default: return heff_nomatch(v_rest_243);
        }
      }
      case TAG_Just: {
        V v_x11_24517 = heff_field(v_t_24511, 0);
        V v_ru_24t_24511_24Just = heff_take_reuse_n(v_t_24511, 1ULL, 1);
        switch (heff_tag_of(v_x11_24517)) {
        case TAG_MkPair: {
          V v_b_24519 = heff_field(v_x11_24517, 1);
          V v_ru_24x11_24517_24MkPair = heff_take_reuse_n(v_x11_24517, 2ULL, 2);
          switch (heff_tag_of(v_rest_243)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24t_24511_24Just, 1);
            heff_drop_cell(v_ru_24x11_24517_24MkPair, 2);
            return (g_heff_2esyntax_2epresyntax_2ejumpCall(v_cx_241, v_sp_246, v_b_24519));
          }
          case TAG_Cons: {
            V v_s_24520 = heff_field(v_rest_243, 0);
            heff_take_n(v_rest_243, 1ULL, 2);
            heff_drop_rec(v_cx_241, 5);
            heff_drop_rec(v_sp_246, 2);
            heff_drop(v_b_24519);
            V v_t_24524;
            switch (heff_tag_of(v_s_24520)) {
            case TAG_At: {
              V v_s_24523 = heff_field(v_s_24520, 1);
              heff_take_n(v_s_24520, 2ULL, 2);
              v_t_24524 = v_s_24523;
              break;
            }
            default: heff_nomatch(v_s_24520);
            }
            return heff_tag_at_n(v_ru_24x11_24517_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24t_24511_24Just, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str34)}), v_t_24524});
          }
          default: return heff_nomatch(v_rest_243);
          }
        }
        default: return heff_nomatch(v_x11_24517);
        }
      }
      default: return heff_nomatch(v_t_24511);
      }
    }
    case TAG_EContinue: {
      heff_drop_rec(v_t_240, 1);
      heff_drop_tag(v_e_242, 2);
      heff_drop(v_end_244);
      V v_t_24525 = heff_dup(heff_rfield(v_cx_241, 2));
      switch (heff_tag_of(v_t_24525)) {
      case TAG_Nothing: {
        heff_drop_rec(v_cx_241, 5);
        switch (heff_tag_of(v_rest_243)) {
        case TAG_Nil: {
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str35)}), v_sp_246});
        }
        case TAG_Cons: {
          V v_s_24526 = heff_field(v_rest_243, 0);
          V v_ru_24rest_243_24Cons = heff_take_reuse_n(v_rest_243, 1ULL, 2);
          heff_drop_rec(v_sp_246, 2);
          V v_t_24530;
          switch (heff_tag_of(v_s_24526)) {
          case TAG_At: {
            V v_s_24529 = heff_field(v_s_24526, 1);
            heff_take_n(v_s_24526, 2ULL, 2);
            v_t_24530 = v_s_24529;
            break;
          }
          default: heff_nomatch(v_s_24526);
          }
          return heff_tag_at_n(v_ru_24rest_243_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str36)}), v_t_24530});
        }
        default: return heff_nomatch(v_rest_243);
        }
      }
      case TAG_Just: {
        V v_x11_24531 = heff_field(v_t_24525, 0);
        V v_ru_24t_24525_24Just = heff_take_reuse_n(v_t_24525, 1ULL, 1);
        switch (heff_tag_of(v_x11_24531)) {
        case TAG_MkPair: {
          V v_c_24532 = heff_field(v_x11_24531, 0);
          V v_ru_24x11_24531_24MkPair = heff_take_reuse_n(v_x11_24531, 1ULL, 2);
          switch (heff_tag_of(v_rest_243)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24t_24525_24Just, 1);
            heff_drop_cell(v_ru_24x11_24531_24MkPair, 2);
            return (g_heff_2esyntax_2epresyntax_2ejumpCall(v_cx_241, v_sp_246, v_c_24532));
          }
          case TAG_Cons: {
            V v_s_24534 = heff_field(v_rest_243, 0);
            heff_take_n(v_rest_243, 1ULL, 2);
            heff_drop_rec(v_cx_241, 5);
            heff_drop_rec(v_sp_246, 2);
            heff_drop(v_c_24532);
            V v_t_24538;
            switch (heff_tag_of(v_s_24534)) {
            case TAG_At: {
              V v_s_24537 = heff_field(v_s_24534, 1);
              heff_take_n(v_s_24534, 2ULL, 2);
              v_t_24538 = v_s_24537;
              break;
            }
            default: heff_nomatch(v_s_24534);
            }
            return heff_tag_at_n(v_ru_24x11_24531_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24t_24525_24Just, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str37)}), v_t_24538});
          }
          default: return heff_nomatch(v_rest_243);
          }
        }
        default: return heff_nomatch(v_x11_24531);
        }
      }
      default: return heff_nomatch(v_t_24525);
      }
    }
    case TAG_EReturn: {
      V v_v_24539 = heff_field(v_e1_245, 0);
      V v_ru_24e1_245_24EReturn = heff_take_reuse_n(v_e1_245, 1ULL, 1);
      heff_drop_rec(v_t_240, 1);
      heff_drop_tag(v_e_242, 2);
      heff_drop(v_end_244);
      switch (heff_tag_of(v_rest_243)) {
      case TAG_Nil: {
        V v_t_24540 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
        HeffT2 v_t_24541 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24540}), NTAG(TAG_Nil), v_v_24539));
        {
          V v_field_24542 = v_t_24541.f[0];
          V v_field_24543 = v_t_24541.f[1];
          V v_x_24544 = v_field_24542;
          V v_y_24545 = v_field_24543;
          V v_t_24546 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 1, 2);
          V v_t_24547 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24EReturn, TAG_EVar, 1, (V[]){v_t_24546}), heff_dup(v_sp_246)});
          V v_t_24548 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_24545, NTAG(TAG_Nil)});
          V v_t_24549 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24547, v_t_24548));
          V v_t_24550 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_241), v_sp_246, heff_dup(heff_rfield(v_cx_241, 4)), v_t_24549));
          return ({ V a_0 = v_cx_241; V a_1 = v_x_24544; V a_2 = v_t_24550; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24544); r_; });
        }
      }
      case TAG_Cons: {
        V v_s_24551 = heff_field(v_rest_243, 0);
        V v_ru_24rest_243_24Cons = heff_take_reuse_n(v_rest_243, 1ULL, 2);
        heff_drop_rec(v_cx_241, 5);
        heff_drop_rec(v_sp_246, 2);
        heff_drop(v_v_24539);
        V v_t_24555;
        switch (heff_tag_of(v_s_24551)) {
        case TAG_At: {
          V v_s_24554 = heff_field(v_s_24551, 1);
          heff_take_n(v_s_24551, 2ULL, 2);
          v_t_24555 = v_s_24554;
          break;
        }
        default: heff_nomatch(v_s_24551);
        }
        return heff_tag_at_n(v_ru_24rest_243_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24EReturn, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str38)}), v_t_24555});
      }
      default: return heff_nomatch(v_rest_243);
      }
    }
    case TAG_ENest: {
      V v_ru_24e1_245_24ENest = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24557 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24558 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24557}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24559 = v_t_24558.f[0];
        V v_field_24560 = v_t_24558.f[1];
        V v_x_24561 = v_field_24559;
        V v_y_24562 = v_field_24560;
        V v_xsp_24563 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24564 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24565 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24566 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24ENest, TAG_EVar, 1, (V[]){v_t_24565}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24567 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str39), heff_dup(v_xsp_24563)}), heff_dup(v_rest_24564)});
        V v_t_24570;
        switch (heff_tag_of(v_rest_24564)) {
        case TAG_At: {
          V v_s_24569 = heff_field(v_rest_24564, 1);
          heff_take_n(v_rest_24564, 2ULL, 2);
          v_t_24570 = v_s_24569;
          break;
        }
        default: heff_nomatch(v_rest_24564);
        }
        V v_t_24571 = ({ V rv_1 = heff_get_n(v_t_24570, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24563, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24572 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24567, v_t_24571}), NTAG(TAG_Nil)});
        V v_t_24573 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24566, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24562, v_t_24572})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24561; V a_2 = v_t_24573; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24561); r_; });
      }
    }
    case TAG_ELazy: {
      V v_ru_24e1_245_24ELazy = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24575 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24576 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24575}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24577 = v_t_24576.f[0];
        V v_field_24578 = v_t_24576.f[1];
        V v_x_24579 = v_field_24577;
        V v_y_24580 = v_field_24578;
        V v_xsp_24581 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24582 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24583 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24584 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24ELazy, TAG_EVar, 1, (V[]){v_t_24583}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24585 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str40), heff_dup(v_xsp_24581)}), heff_dup(v_rest_24582)});
        V v_t_24588;
        switch (heff_tag_of(v_rest_24582)) {
        case TAG_At: {
          V v_s_24587 = heff_field(v_rest_24582, 1);
          heff_take_n(v_rest_24582, 2ULL, 2);
          v_t_24588 = v_s_24587;
          break;
        }
        default: heff_nomatch(v_rest_24582);
        }
        V v_t_24589 = ({ V rv_1 = heff_get_n(v_t_24588, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24581, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24590 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24585, v_t_24589}), NTAG(TAG_Nil)});
        V v_t_24591 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24584, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24580, v_t_24590})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24579; V a_2 = v_t_24591; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24579); r_; });
      }
    }
    case TAG_ETuple: {
      V v_ru_24e1_245_24ETuple = heff_take_reuse_n(v_e1_245, 0ULL, 1);
      heff_drop_rec(v_sp_246, 2);
      V v_t_24593 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
      HeffT2 v_t_24594 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_24593}), NTAG(TAG_Nil), v_e_242));
      {
        V v_field_24595 = v_t_24594.f[0];
        V v_field_24596 = v_t_24594.f[1];
        V v_x_24597 = v_field_24595;
        V v_y_24598 = v_field_24596;
        V v_xsp_24599 = heff_dup(heff_rfield(v_cx_241, 3));
        V v_rest_24600 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
        V v_t_24601 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
        V v_t_24602 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_245_24ETuple, TAG_EVar, 1, (V[]){v_t_24601}), heff_dup(heff_rfield(v_cx_241, 3))});
        V v_t_24603 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2econtrolT_str41), heff_dup(v_xsp_24599)}), heff_dup(v_rest_24600)});
        V v_t_24606;
        switch (heff_tag_of(v_rest_24600)) {
        case TAG_At: {
          V v_s_24605 = heff_field(v_rest_24600, 1);
          heff_take_n(v_rest_24600, 2ULL, 2);
          v_t_24606 = v_s_24605;
          break;
        }
        default: heff_nomatch(v_rest_24600);
        }
        V v_t_24607 = ({ V rv_1 = heff_get_n(v_t_24606, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24599, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24608 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24603, v_t_24607}), NTAG(TAG_Nil)});
        V v_t_24609 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24602, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24598, v_t_24608})));
        return ({ V a_0 = v_cx_241; V a_1 = v_x_24597; V a_2 = v_t_24609; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24597); r_; });
      }
    }
    case TAG_ETry: {
      V v_e11_24610 = heff_field(v_e1_245, 0);
      heff_take_n(v_e1_245, 1ULL, 1);
      heff_drop_tag(v_e_242, 2);
      switch (heff_tag_of(v_e11_24610)) {
      case TAG_MkTry: {
        V v_err_24611 = heff_field(v_e11_24610, 0);
        V v_body_24612 = heff_field(v_e11_24610, 1);
        V v_h_24613 = heff_field(v_e11_24610, 2);
        V v_ru_24e11_24610_24MkTry = heff_take_reuse_n(v_e11_24610, 7ULL, 3);
        HeffT2 v_t_24614 = (g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr(heff_dup(v_cx_241), heff_dup(v_h_24613)));
        {
          V v_field_24616 = v_t_24614.f[1];
          int64_t v_tag_24615 = ((int64_t)v_t_24614.f[0]);
          if ((v_tag_24615 == ((int64_t)0ULL))) {
            heff_drop_rec(v_t_240, 1);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_rest_243);
            heff_drop(v_end_244);
            heff_drop_rec(v_sp_246, 2);
            heff_drop(v_err_24611);
            heff_drop(v_body_24612);
            heff_drop(v_h_24613);
            heff_drop_cell(v_ru_24e11_24610_24MkTry, 3);
            V v_wrong_24618 = v_field_24616;
            return v_wrong_24618;
          } else {
            heff_drop(v_field_24616);
            return (g_heff_2esyntax_2epresyntax_2etryT(v_t_240, v_cx_241, v_sp_246, heff_tag_at_n(v_ru_24e11_24610_24MkTry, TAG_MkTry, 3, (V[]){v_err_24611, v_body_24612, v_h_24613}), v_rest_243, v_end_244));
          }
        }
      }
      default: return heff_nomatch(v_e11_24610);
      }
    }
    case TAG_EWith: {
      V v_w_24619 = heff_field(v_e1_245, 0);
      V v_x_24620 = heff_field(v_e1_245, 1);
      V v_xsp_24621 = heff_field(v_e1_245, 2);
      V v_body_24622 = heff_field(v_e1_245, 3);
      heff_take_n(v_e1_245, 15ULL, 4);
      heff_drop_tag(v_e_242, 2);
      return (g_heff_2esyntax_2epresyntax_2ewithT(v_t_240, v_cx_241, v_sp_246, v_w_24619, v_x_24620, v_xsp_24621, v_body_24622, v_rest_243, v_end_244));
    }
    default: return heff_nomatch(v_e1_245);
    }
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2esyntax_2epresyntax_2econtrolT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2econtrolT(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str2, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str3, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str4, 9, "floatBits");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str5, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str6, 17, "prelude.utf8Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str7, 18, "prelude.utf16Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_str8, 18, "prelude.utf32Bytes");
Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesPart_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ebytesPart(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkSegment: {
      V v_v_244 = heff_field(v_x21_242, 0);
      V v_x212_245 = heff_field(v_x21_242, 1);
      V v_size_246 = heff_field(v_x21_242, 2);
      V v_little_247 = heff_field(v_x21_242, 3);
      V v_signed_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 31ULL, 5);
      switch (heff_tag_of(v_x212_245)) {
      case TAG_SegmentInteger: {
        V v_t_249 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_246, MK_INT(8LL), heff_dup(v_sp_243)));
        int64_t v_t_2410;
        if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
          heff_drop(v_little_247);
          v_t_2410 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        int64_t v_t_2411;
        if ((heff_dup(v_signed_248) == NTAG(TAG_True))) {
          heff_drop(v_signed_248);
          v_t_2411 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_248);
          v_t_2411 = ((int64_t)0ULL);
        }
        V v_t_2412 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_2410 + v_t_2411))});
        V v_t_2413 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_243)})});
        V v_x1_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
        V v_t_2424;
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_IsInferable: {
          V v_i_2415 = heff_field(v_x1_2414, 0);
          V v_ru_24x1_2414_24IsInferable = heff_take_reuse_n(v_x1_2414, 1ULL, 1);
          V v_t_2418;
          switch (heff_tag_of(v_i_2415)) {
          case TAG_At: {
            V v_s_2417 = heff_dup(heff_field(v_i_2415, 1));
            v_t_2418 = v_s_2417;
            break;
          }
          default: heff_nomatch(v_i_2415);
          }
          v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2414_24IsInferable, TAG_CInf, 1, (V[]){v_i_2415}), v_t_2418});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2419 = heff_field(v_x1_2414, 0);
          heff_take_n(v_x1_2414, 1ULL, 1);
          v_t_2424 = v_c_2419;
          break;
        }
        case TAG_IsType: {
          V v_t_2420 = heff_field(v_x1_2414, 0);
          V v_ru_24x1_2414_24IsType = heff_take_reuse_n(v_x1_2414, 1ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_At: {
            V v_s_2422 = heff_dup(heff_field(v_t_2420, 1));
            v_t_2423 = v_s_2422;
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2414_24IsType, TAG_CType, 1, (V[]){v_t_2420}), v_t_2423});
          break;
        }
        default: heff_nomatch(v_x1_2414);
        }
        V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_243)}), v_t_2425});
        V v_args_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2426});
        V v_t_2428 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2427));
        V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str0)}), heff_dup(v_sp_243)});
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2429, v_t_2428}), heff_dup(v_sp_243)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2430}), v_sp_243});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_247);
        heff_drop(v_signed_248);
        switch (heff_tag_of(v_size_246)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_243);
          V v_x1_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
          switch (heff_tag_of(v_x1_2431)) {
          case TAG_IsInferable: {
            V v_i_2432 = heff_field(v_x1_2431, 0);
            heff_take_n(v_x1_2431, 1ULL, 1);
            V v_t_2435;
            switch (heff_tag_of(v_i_2432)) {
            case TAG_At: {
              V v_s_2434 = heff_dup(heff_field(v_i_2432, 1));
              v_t_2435 = v_s_2434;
              break;
            }
            default: heff_nomatch(v_i_2432);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2432}), v_t_2435});
          }
          case TAG_IsCheckable: {
            V v_c_2436 = heff_field(v_x1_2431, 0);
            heff_take_n(v_x1_2431, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            return v_c_2436;
          }
          case TAG_IsType: {
            V v_t_2437 = heff_field(v_x1_2431, 0);
            heff_take_n(v_x1_2431, 1ULL, 1);
            V v_t_2440;
            switch (heff_tag_of(v_t_2437)) {
            case TAG_At: {
              V v_s_2439 = heff_dup(heff_field(v_t_2437, 1));
              v_t_2440 = v_s_2439;
              break;
            }
            default: heff_nomatch(v_t_2437);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2437}), v_t_2440});
          }
          default: return heff_nomatch(v_x1_2431);
          }
        }
        case TAG_SizeNumber: {
          V v_t_2442 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_246, heff_dup(v_sp_243)));
          V v_x1_2443 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
          V v_t_2453;
          switch (heff_tag_of(v_x1_2443)) {
          case TAG_IsInferable: {
            V v_i_2444 = heff_field(v_x1_2443, 0);
            heff_take_n(v_x1_2443, 1ULL, 1);
            V v_t_2447;
            switch (heff_tag_of(v_i_2444)) {
            case TAG_At: {
              V v_s_2446 = heff_dup(heff_field(v_i_2444, 1));
              v_t_2447 = v_s_2446;
              break;
            }
            default: heff_nomatch(v_i_2444);
            }
            v_t_2453 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2444}), v_t_2447});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_2448 = heff_field(v_x1_2443, 0);
            heff_take_n(v_x1_2443, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            v_t_2453 = v_c_2448;
            break;
          }
          case TAG_IsType: {
            V v_t_2449 = heff_field(v_x1_2443, 0);
            heff_take_n(v_x1_2443, 1ULL, 1);
            V v_t_2452;
            switch (heff_tag_of(v_t_2449)) {
            case TAG_At: {
              V v_s_2451 = heff_dup(heff_field(v_t_2449, 1));
              v_t_2452 = v_s_2451;
              break;
            }
            default: heff_nomatch(v_t_2449);
            }
            v_t_2453 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2449}), v_t_2452});
            break;
          }
          default: heff_nomatch(v_x1_2443);
          }
          V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
          V v_args_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_t_2454});
          V v_t_2456 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2455));
          V v_t_2457 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str1)}), heff_dup(v_sp_243)});
          V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2457, v_t_2456}), heff_dup(v_sp_243)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2458}), v_sp_243});
        }
        case TAG_SizeName: {
          V v_t_2462 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_246, heff_dup(v_sp_243)));
          V v_x1_2463 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
          V v_t_2473;
          switch (heff_tag_of(v_x1_2463)) {
          case TAG_IsInferable: {
            V v_i_2464 = heff_field(v_x1_2463, 0);
            heff_take_n(v_x1_2463, 1ULL, 1);
            V v_t_2467;
            switch (heff_tag_of(v_i_2464)) {
            case TAG_At: {
              V v_s_2466 = heff_dup(heff_field(v_i_2464, 1));
              v_t_2467 = v_s_2466;
              break;
            }
            default: heff_nomatch(v_i_2464);
            }
            v_t_2473 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2464}), v_t_2467});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_2468 = heff_field(v_x1_2463, 0);
            heff_take_n(v_x1_2463, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            v_t_2473 = v_c_2468;
            break;
          }
          case TAG_IsType: {
            V v_t_2469 = heff_field(v_x1_2463, 0);
            heff_take_n(v_x1_2463, 1ULL, 1);
            V v_t_2472;
            switch (heff_tag_of(v_t_2469)) {
            case TAG_At: {
              V v_s_2471 = heff_dup(heff_field(v_t_2469, 1));
              v_t_2472 = v_s_2471;
              break;
            }
            default: heff_nomatch(v_t_2469);
            }
            v_t_2473 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2469}), v_t_2472});
            break;
          }
          default: heff_nomatch(v_x1_2463);
          }
          V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, NTAG(TAG_Nil)});
          V v_args_2475 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, v_t_2474});
          V v_t_2476 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2475));
          V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str2)}), heff_dup(v_sp_243)});
          V v_t_2478 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2477, v_t_2476}), heff_dup(v_sp_243)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2478}), v_sp_243});
        }
        default: return heff_nomatch(v_size_246);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_size_246);
        heff_drop(v_little_247);
        heff_drop(v_signed_248);
        V v_x1_2479 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
        V v_t_2489;
        switch (heff_tag_of(v_x1_2479)) {
        case TAG_IsInferable: {
          V v_i_2480 = heff_field(v_x1_2479, 0);
          heff_take_n(v_x1_2479, 1ULL, 1);
          V v_t_2483;
          switch (heff_tag_of(v_i_2480)) {
          case TAG_At: {
            V v_s_2482 = heff_dup(heff_field(v_i_2480, 1));
            v_t_2483 = v_s_2482;
            break;
          }
          default: heff_nomatch(v_i_2480);
          }
          v_t_2489 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2480}), v_t_2483});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2484 = heff_field(v_x1_2479, 0);
          heff_take_n(v_x1_2479, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2489 = v_c_2484;
          break;
        }
        case TAG_IsType: {
          V v_t_2485 = heff_field(v_x1_2479, 0);
          heff_take_n(v_x1_2479, 1ULL, 1);
          V v_t_2488;
          switch (heff_tag_of(v_t_2485)) {
          case TAG_At: {
            V v_s_2487 = heff_dup(heff_field(v_t_2485, 1));
            v_t_2488 = v_s_2487;
            break;
          }
          default: heff_nomatch(v_t_2485);
          }
          v_t_2489 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2485}), v_t_2488});
          break;
        }
        default: heff_nomatch(v_x1_2479);
        }
        V v_args_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, NTAG(TAG_Nil)});
        V v_t_2491 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2490));
        V v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str3)}), heff_dup(v_sp_243)});
        V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2492, v_t_2491}), heff_dup(v_sp_243)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2493}), v_sp_243});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_signed_248);
        V v_t_2494 = (g_heff_2esyntax_2epresyntax_2esizeTerm(heff_dup(v_size_246), MK_INT(64LL), heff_dup(v_sp_243)));
        int64_t v_t_2495;
        if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
          heff_drop(v_little_247);
          v_t_2495 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_247);
          v_t_2495 = ((int64_t)0ULL);
        }
        V v_t_2496 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_2495 + ((int64_t)0ULL)))});
        V v_t_2497 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2496, heff_dup(v_sp_243)})});
        V v_t_2498 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_246, MK_INT(64LL), heff_dup(v_sp_243)));
        V v_x1_2499 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
        V v_t_24109;
        switch (heff_tag_of(v_x1_2499)) {
        case TAG_IsInferable: {
          V v_i_24100 = heff_field(v_x1_2499, 0);
          V v_ru_24x1_2499_24IsInferable = heff_take_reuse_n(v_x1_2499, 1ULL, 1);
          V v_t_24103;
          switch (heff_tag_of(v_i_24100)) {
          case TAG_At: {
            V v_s_24102 = heff_dup(heff_field(v_i_24100, 1));
            v_t_24103 = v_s_24102;
            break;
          }
          default: heff_nomatch(v_i_24100);
          }
          v_t_24109 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2499_24IsInferable, TAG_CInf, 1, (V[]){v_i_24100}), v_t_24103});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_24104 = heff_field(v_x1_2499, 0);
          heff_take_n(v_x1_2499, 1ULL, 1);
          v_t_24109 = v_c_24104;
          break;
        }
        case TAG_IsType: {
          V v_t_24105 = heff_field(v_x1_2499, 0);
          V v_ru_24x1_2499_24IsType = heff_take_reuse_n(v_x1_2499, 1ULL, 1);
          V v_t_24108;
          switch (heff_tag_of(v_t_24105)) {
          case TAG_At: {
            V v_s_24107 = heff_dup(heff_field(v_t_24105, 1));
            v_t_24108 = v_s_24107;
            break;
          }
          default: heff_nomatch(v_t_24105);
          }
          v_t_24109 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2499_24IsType, TAG_CType, 1, (V[]){v_t_24105}), v_t_24108});
          break;
        }
        default: heff_nomatch(v_x1_2499);
        }
        V v_t_24110 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24109, NTAG(TAG_Nil)});
        V v_args_24111 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2498, v_t_24110});
        V v_t_24112 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24111));
        V v_t_24113 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str4)}), heff_dup(v_sp_243)});
        V v_t_24114 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24113, v_t_24112}), heff_dup(v_sp_243)});
        V v_t_24115 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24114}), heff_dup(v_sp_243)});
        V v_t_24116 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24115, NTAG(TAG_Nil)});
        V v_t_24117 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2497, heff_dup(v_sp_243)}), v_t_24116});
        V v_args_24118 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2494, v_t_24117});
        V v_t_24119 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24118));
        V v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str5)}), heff_dup(v_sp_243)});
        V v_t_24121 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24120, v_t_24119}), heff_dup(v_sp_243)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24121}), v_sp_243});
      }
      case TAG_SegmentUtf: {
        V v_x2121_24122 = heff_field(v_x212_245, 0);
        V v_ru_24x212_245_24SegmentUtf = heff_take_reuse_n(v_x212_245, 1ULL, 1);
        heff_drop(v_size_246);
        heff_drop(v_signed_248);
        if (heff_intEq_c_lent(v_x2121_24122, MK_INT(8LL), 2)) {
          heff_drop(v_little_247);
          heff_drop(v_x2121_24122);
          V v_t_24124 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm(v_r_240, v_v_244, heff_dup(v_sp_243)));
          V v_args_24125 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24124, NTAG(TAG_Nil)});
          V v_t_24126 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24125));
          V v_t_24127 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str6)}), heff_dup(v_sp_243)});
          V v_t_24128 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24127, v_t_24126}), heff_dup(v_sp_243)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x212_245_24SegmentUtf, TAG_CInf, 1, (V[]){v_t_24128}), v_sp_243});
        } else {
          if (heff_intEq_c(v_x2121_24122, MK_INT(16LL))) {
            int64_t v_t_24130;
            if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
              heff_drop(v_little_247);
              v_t_24130 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_247);
              v_t_24130 = ((int64_t)0ULL);
            }
            V v_t_24131 = heff_tag_at_n(v_ru_24x212_245_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24130 + ((int64_t)0ULL)))});
            V v_t_24132 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24131, heff_dup(v_sp_243)})});
            V v_t_24133 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm(v_r_240, v_v_244, heff_dup(v_sp_243)));
            V v_t_24134 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24133, NTAG(TAG_Nil)});
            V v_args_24135 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24132, heff_dup(v_sp_243)}), v_t_24134});
            V v_t_24136 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24135));
            V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str7)}), heff_dup(v_sp_243)});
            V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24137, v_t_24136}), heff_dup(v_sp_243)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24138}), v_sp_243});
          } else {
            int64_t v_t_24139;
            if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
              heff_drop(v_little_247);
              v_t_24139 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_247);
              v_t_24139 = ((int64_t)0ULL);
            }
            V v_t_24140 = heff_tag_at_n(v_ru_24x212_245_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24139 + ((int64_t)0ULL)))});
            V v_t_24141 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24140, heff_dup(v_sp_243)})});
            V v_t_24142 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm(v_r_240, v_v_244, heff_dup(v_sp_243)));
            V v_t_24143 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24142, NTAG(TAG_Nil)});
            V v_args_24144 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24141, heff_dup(v_sp_243)}), v_t_24143});
            V v_t_24145 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24144));
            V v_t_24146 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_str8)}), heff_dup(v_sp_243)});
            V v_t_24147 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24146, v_t_24145}), heff_dup(v_sp_243)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24147}), v_sp_243});
          }
        }
      }
      default: return heff_nomatch(v_x212_245);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesPart(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_SetPath: {
      V v_path_243 = heff_field(v_x21_241, 0);
      V v_e_244 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24SetPath = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_244));
      V v_t_2419;
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_249 = v_field_247;
          v_t_2419 = v_c_249;
        } else {
          if ((v_tag_246 == ((int64_t)1ULL))) {
            V v_i_2411 = v_field_247;
            V v_t_2414;
            switch (heff_tag_of(v_i_2411)) {
            case TAG_At: {
              V v_s_2413 = heff_dup(heff_field(v_i_2411, 1));
              v_t_2414 = v_s_2413;
              break;
            }
            default: heff_nomatch(v_i_2411);
            }
            v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2411}), v_t_2414});
          } else {
            V v_t_2415 = v_field_247;
            V v_t_2418;
            switch (heff_tag_of(v_t_2415)) {
            case TAG_At: {
              V v_s_2417 = heff_dup(heff_field(v_t_2415, 1));
              v_t_2418 = v_s_2417;
              break;
            }
            default: heff_nomatch(v_t_2415);
            }
            v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2415}), v_t_2418});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24SetPath, TAG_SetPath, 2, (V[]){v_path_243, v_t_2419}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_CInf: {
    V v_i_242 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_242)) {
    case TAG_At: {
      V v_n_243 = heff_field(v_i_242, 0);
      V v_sp_244 = heff_field(v_i_242, 1);
      heff_take_n(v_i_242, 3ULL, 2);
      v_t_245 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(v_sp_244, v_n_243));
      break;
    }
    default: heff_nomatch(v_i_242);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CInf, TAG_CInf, 1, (V[]){v_t_245}), v_sp_240});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CType = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CType, TAG_CType, 1, (V[]){v_t_249}), v_sp_240});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_241, 0);
    V v_xsp_2411 = heff_field(v_n_241, 1);
    V v_b_2412 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24CLam = heff_take_reuse_n(v_n_241, 7ULL, 3);
    V v_t_2415;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      heff_take_n(v_b_2412, 3ULL, 2);
      v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2414, v_n_2413));
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_xsp_2411, v_t_2415}), v_sp_240});
  }
  case TAG_CImplicitLam: {
    V v_x_2416 = heff_field(v_n_241, 0);
    V v_xsp_2417 = heff_field(v_n_241, 1);
    V v_b_2418 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24CImplicitLam = heff_take_reuse_n(v_n_241, 7ULL, 3);
    V v_t_2421;
    switch (heff_tag_of(v_b_2418)) {
    case TAG_At: {
      V v_n_2419 = heff_field(v_b_2418, 0);
      V v_sp_2420 = heff_field(v_b_2418, 1);
      heff_take_n(v_b_2418, 3ULL, 2);
      v_t_2421 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2420, v_n_2419));
      break;
    }
    default: heff_nomatch(v_b_2418);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2416, v_xsp_2417, v_t_2421}), v_sp_240});
  }
  case TAG_CAnnLam: {
    V v_t_2426 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2427 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2426, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2427, v_sp_240});
  }
  case TAG_CTag: {
    V v_t_2431 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2432 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2431, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2432, v_sp_240});
  }
  case TAG_CStruct: {
    V v_fs_2433 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CStruct = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2434 = (g_list_2emap_24s249042484x1701682908(v_fs_2433));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CStruct, TAG_CStruct, 1, (V[]){v_t_2434}), v_sp_240});
  }
  case TAG_CMatch: {
    V v_t_2437 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2438 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2437, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2438, v_sp_240});
  }
  case TAG_CLetIn: {
    V v_t_2441 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2442 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2441, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_sp_240});
  }
  case TAG_CLocal: {
    V v_t_2445 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2446 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2445, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2446, v_sp_240});
  }
  case TAG_CAbandon: {
    V v_t_2447 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2448 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2447, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2448, v_sp_240});
  }
  case TAG_CNominal: {
    V v_t_2450 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2451 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2450, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(a[0], a[1]);
}