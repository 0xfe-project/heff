// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_std_2epath_2elower_2elow_240(V, V);
V g_std_2epath_2elower_2elow_240_entry(V self, V *a);
extern Clo g_std_2epath_2elower_2elow_240_clo;
Clo g_std_2epath_2elower_2elow_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2elower_2elow_240_entry, 2, 0};

V g_std_2epath_2elower_2elow_240(V v_s_240, V v_i_241) {
top: ;
  if ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)))) {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) <= ((int64_t)90ULL))) {
      int64_t v_t_244 = (heff_unbox_word(heff_strByteAt(v_s_240, v_i_241)) + ((int64_t)32ULL));
      return heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_244))));
    } else {
      return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
    }
  } else {
    return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
  }
}
V g_std_2epath_2elower_2elow_240_entry(V self, V *a) {
  (void)self;
  return g_std_2epath_2elower_2elow_240(a[0], a[1]);
}