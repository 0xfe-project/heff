// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_std_2epath_2elower_2elow_240(V, V);
V g_std_2epath_2elower_2elow_240_entry(V self, V *a);
extern Clo g_std_2epath_2elower_2elow_240_clo;
Clo g_std_2epath_2elower_2elow_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2elower_2elow_240_entry, 2, 0};

V g_std_2epath_2elower_2elow_240(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLe(MK_INT(65LL), heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_intLe(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(90LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_t_244 = heff_intAdd(heff_strCharCode(v_s_240, v_i_241), MK_INT(32LL));
      return heff_strFromCharCode(v_t_244);
    }
    case TAG_False: {
      return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_False: {
    return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2epath_2elower_2elow_240_entry(V self, V *a) {
  (void)self;
  return g_std_2epath_2elower_2elow_240(a[0], a[1]);
}