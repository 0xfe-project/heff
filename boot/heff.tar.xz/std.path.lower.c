// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_std_2epath_2elower_2elow_240(V, V);
V g_std_2epath_2elower_2elow_240_entry(V self, V *a);
extern Clo g_std_2epath_2elower_2elow_240_clo;
Clo g_std_2epath_2elower_2elow_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2elower_2elow_240_entry, 2, 0};

V g_std_2epath_2elower_2elow_240(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(MK_INT(65LL), heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)))) {
    if (heff_intLe_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(90LL))) {
      V v_t_244 = heff_intAdd(heff_strCharCode(v_s_240, v_i_241), MK_INT(32LL));
      return heff_strFromCharCode(v_t_244);
    } else {
      return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
    }
  } else {
    return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
  }
}
V g_std_2epath_2elower_2elow_240_entry(V self, V *a) {
  (void)self;
  return g_std_2epath_2elower_2elow_240(a[0], a[1]);
}