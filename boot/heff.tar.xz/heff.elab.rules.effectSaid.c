// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241(V, V, V, V);
V g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241_clo;
V g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241_entry, 4, 0};

V g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241(V v_p_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_w_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_w_244)}));
    return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241_lam0, 1, 5, (V[]){v_p_240, v_rest_245, v_z_242, v_w_244, v_z_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_w_244 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_t_249;
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
    heff_drop(v_x_247);
    v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_w_244, v_x_248});
  } else {
    heff_drop(v_x_247);
    heff_drop(v_w_244);
    v_t_249 = v_x_248;
  }
  V f_ = v_z_243;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_w_244 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241(v_p_240, v_rest_245, v_z_242, heff_clo_n(g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241_lam1, 1, 3, (V[]){v_x_247, v_w_244, v_z_243})));
}