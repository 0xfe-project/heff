// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Added 2732
#define TAG_Bin 14227
#define TAG_Left 13886
#define TAG_Removed 39854
#define TAG_Right 62770
#define TAG_Same 22203
#define TAG_Tip 31527
#define LBL_edits 297717699
#define LBL_x 338
static uint32_t shape_x__edits[] = {LBL_x, LBL_edits};
V g_heff_2ediff_2ediagonals(V, V, V, V, V, V, V);
V g_heff_2ediff_2ediagonals_entry(V self, V *a);
extern Clo g_heff_2ediff_2ediagonals_clo;
V g_heff_2ediff_2ediffBy(V, V, V);
V g_heff_2ediff_2ediffBy_entry(V self, V *a);
extern Clo g_heff_2ediff_2ediffBy_clo;
V g_heff_2ediff_2eisBlankCode(V);
V g_heff_2ediff_2eisBlankCode_entry(V self, V *a);
extern Clo g_heff_2ediff_2eisBlankCode_clo;
V g_heff_2ediff_2eisWordCode(V);
V g_heff_2ediff_2eisWordCode_entry(V self, V *a);
extern Clo g_heff_2ediff_2eisWordCode_clo;
V g_heff_2ediff_2ejoinEdit(V, V);
V g_heff_2ediff_2ejoinEdit_entry(V self, V *a);
extern Clo g_heff_2ediff_2ejoinEdit_clo;
V g_heff_2ediff_2ejoinRunsGo(V, V);
V g_heff_2ediff_2ejoinRunsGo_entry(V self, V *a);
extern Clo g_heff_2ediff_2ejoinRunsGo_clo;
V g_heff_2ediff_2erounds(V, V, V, V, V);
V g_heff_2ediff_2erounds_entry(V self, V *a);
extern Clo g_heff_2ediff_2erounds_clo;
V g_heff_2ediff_2erunEnd_24s1727631165x667442256(V, V);
V g_heff_2ediff_2erunEnd_24s1727631165x667442256_entry(V self, V *a);
extern Clo g_heff_2ediff_2erunEnd_24s1727631165x667442256_clo;
V g_heff_2ediff_2erunEnd_24s1757338005x572581804(V, V);
V g_heff_2ediff_2erunEnd_24s1757338005x572581804_entry(V self, V *a);
extern Clo g_heff_2ediff_2erunEnd_24s1757338005x572581804_clo;
V g_heff_2ediff_2esnake(V, V, V, V, V, V);
V g_heff_2ediff_2esnake_entry(V self, V *a);
extern Clo g_heff_2ediff_2esnake_clo;
V g_heff_2ediff_2estepOnto(V, V, V, V, V);
V g_heff_2ediff_2estepOnto_entry(V self, V *a);
extern Clo g_heff_2ediff_2estepOnto_clo;
V g_heff_2ediff_2etokenEnd(V, V);
V g_heff_2ediff_2etokenEnd_entry(V self, V *a);
extern Clo g_heff_2ediff_2etokenEnd_clo;
V g_heff_2ediff_2ewordsFrom(V, V, V);
V g_heff_2ediff_2ewordsFrom_entry(V self, V *a);
extern Clo g_heff_2ediff_2ewordsFrom_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
Clo g_heff_2ediff_2esnake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ediff_2esnake_entry, 6, 0};

V g_heff_2ediff_2esnake(V v_eq_240, V v_xs_241, V v_ys_242, V v_x_243, V v_y_244, V v_acc_245) {
top: ;
  V v_t_246 = heff_intLt(heff_dup(v_x_243), heff_arrayLength(heff_dup(v_xs_241)));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    V v_t_247 = heff_intLt(heff_dup(v_y_244), heff_arrayLength(heff_dup(v_ys_242)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      V v_t_248 = heff_arrayIndex(heff_dup(v_xs_241), heff_dup(v_x_243));
      V v_t_249 = heff_arrayIndex(heff_dup(v_ys_242), heff_dup(v_y_244));
      V v_t_2410 = heff_tr(heff_apply(heff_dup(v_eq_240), 2, (V[]){v_t_248, v_t_249}));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        V v_t_2411 = heff_arrayIndex(heff_dup(v_xs_241), heff_dup(v_x_243));
        V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_Same, 1, (V[]){v_t_2411}), v_acc_245});
        V t_0 = v_eq_240;
        V t_1 = v_xs_241;
        V t_2 = v_ys_242;
        V t_3 = heff_intAdd(v_x_243, MK_INT(1LL));
        V t_4 = heff_intAdd(v_y_244, MK_INT(1LL));
        V t_5 = v_t_2412;
        v_eq_240 = t_0;
        v_xs_241 = t_1;
        v_ys_242 = t_2;
        v_x_243 = t_3;
        v_y_244 = t_4;
        v_acc_245 = t_5;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_eq_240);
        heff_drop(v_xs_241);
        heff_drop(v_ys_242);
        heff_drop(v_y_244);
        return heff_rec(2, shape_x__edits, (V[]){v_x_243, v_acc_245});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_False: {
      heff_drop(v_eq_240);
      heff_drop(v_xs_241);
      heff_drop(v_ys_242);
      heff_drop(v_y_244);
      return heff_rec(2, shape_x__edits, (V[]){v_x_243, v_acc_245});
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_False: {
    heff_drop(v_eq_240);
    heff_drop(v_xs_241);
    heff_drop(v_ys_242);
    heff_drop(v_y_244);
    return heff_rec(2, shape_x__edits, (V[]){v_x_243, v_acc_245});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ediff_2esnake_entry(V self, V *a) {
  (void)self;
  return g_heff_2ediff_2esnake(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ediff_2estepOnto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ediff_2estepOnto_entry, 5, 0};

V g_heff_2ediff_2estepOnto(V v_eq_240, V v_xs_241, V v_ys_242, V v_k_243, V v_v_244) {
top: ;
  V v_above_245 = (g_map_2elookup_24s567992785x1569911877(heff_intAdd(heff_dup(v_k_243), MK_INT(1LL)), v_v_244));
  V v_below_246 = (g_map_2elookup_24s567992785x1569911877(heff_intSub(heff_dup(v_k_243), MK_INT(1LL)), v_v_244));
  V v_canAdd_249;
  switch (heff_tag_of(v_above_245)) {
  case TAG_Nothing: {
    v_canAdd_249 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_p_247 = heff_dup(heff_field(v_above_245, 0));
    V v_t_248 = heff_intSub(heff_get(v_p_247, LBL_x), heff_intAdd(heff_dup(v_k_243), MK_INT(1LL)));
    v_canAdd_249 = heff_intLt(v_t_248, heff_arrayLength(heff_dup(v_ys_242)));
    break;
  }
  default: heff_nomatch(v_above_245);
  }
  V v_canRemove_2411;
  switch (heff_tag_of(v_below_246)) {
  case TAG_Nothing: {
    v_canRemove_2411 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_p_2410 = heff_dup(heff_field(v_below_246, 0));
    v_canRemove_2411 = heff_intLt(heff_get(v_p_2410, LBL_x), heff_arrayLength(heff_dup(v_xs_241)));
    break;
  }
  default: heff_nomatch(v_below_246);
  }
  V v_t_2412;
  switch (heff_tag_of(v_canAdd_249)) {
  case TAG_True: {
    v_t_2412 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    switch (heff_tag_of(v_canRemove_2411)) {
    case TAG_True: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_canRemove_2411);
    }
    break;
  }
  default: heff_nomatch(v_canAdd_249);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_eq_240);
    heff_drop(v_xs_241);
    heff_drop(v_ys_242);
    heff_drop(v_k_243);
    heff_drop(v_above_245);
    heff_drop(v_below_246);
    heff_drop(v_canAdd_249);
    heff_drop(v_canRemove_2411);
    return NTAG(TAG_Nothing);
  }
  case TAG_False: {
    V v_t_2417;
    switch (heff_tag_of(v_canRemove_2411)) {
    case TAG_True: {
      switch (heff_tag_of(v_canAdd_249)) {
      case TAG_True: {
        V v_t_2414;
        switch (heff_tag_of(v_below_246)) {
        case TAG_Nothing: {
          v_t_2414 = MK_INT(-1LL);
          break;
        }
        case TAG_Just: {
          V v_p_2413 = heff_dup(heff_field(v_below_246, 0));
          v_t_2414 = heff_get(v_p_2413, LBL_x);
          break;
        }
        default: heff_nomatch(v_below_246);
        }
        V v_t_2416;
        switch (heff_tag_of(v_above_245)) {
        case TAG_Nothing: {
          v_t_2416 = MK_INT(-1LL);
          break;
        }
        case TAG_Just: {
          V v_p_2415 = heff_dup(heff_field(v_above_245, 0));
          v_t_2416 = heff_get(v_p_2415, LBL_x);
          break;
        }
        default: heff_nomatch(v_above_245);
        }
        v_t_2417 = heff_intLt(v_t_2414, v_t_2416);
        break;
      }
      case TAG_False: {
        v_t_2417 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_canAdd_249);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_canAdd_249);
      v_t_2417 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_canRemove_2411);
    }
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      heff_drop(v_below_246);
      switch (heff_tag_of(v_above_245)) {
      case TAG_Nothing: {
        heff_drop(v_eq_240);
        heff_drop(v_xs_241);
        heff_drop(v_ys_242);
        heff_drop(v_k_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_p_2418 = heff_field(v_above_245, 0);
        V v_ru_24above_245_24Just = heff_take_reuse_n(v_above_245, 1ULL, 1);
        V v_t_2419 = heff_intSub(heff_get(heff_dup(v_p_2418), LBL_x), heff_dup(v_k_243));
        V v_t_2420 = heff_intSub(heff_get(heff_dup(v_p_2418), LBL_x), heff_intAdd(v_k_243, MK_INT(1LL)));
        V v_t_2421 = heff_arrayIndex(heff_dup(v_ys_242), v_t_2420);
        V v_t_2422 = heff_tag(TAG_Cons, 2, (V[]){heff_tag_at(v_ru_24above_245_24Just, TAG_Added, 1, (V[]){v_t_2421}), heff_get(heff_dup(v_p_2418), LBL_edits)});
        return heff_tag(TAG_Just, 1, (V[]){(g_heff_2ediff_2esnake(v_eq_240, v_xs_241, v_ys_242, heff_get(v_p_2418, LBL_x), v_t_2419, v_t_2422))});
      }
      default: return heff_nomatch(v_above_245);
      }
    }
    case TAG_False: {
      heff_drop(v_above_245);
      switch (heff_tag_of(v_below_246)) {
      case TAG_Nothing: {
        heff_drop(v_eq_240);
        heff_drop(v_xs_241);
        heff_drop(v_ys_242);
        heff_drop(v_k_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_p_2423 = heff_field(v_below_246, 0);
        V v_ru_24below_246_24Just = heff_take_reuse_n(v_below_246, 1ULL, 1);
        V v_t_2424 = heff_intAdd(heff_get(heff_dup(v_p_2423), LBL_x), MK_INT(1LL));
        V v_t_2425 = heff_intAdd(heff_get(heff_dup(v_p_2423), LBL_x), MK_INT(1LL));
        V v_t_2426 = heff_arrayIndex(heff_dup(v_xs_241), heff_get(heff_dup(v_p_2423), LBL_x));
        V v_t_2427 = heff_tag(TAG_Cons, 2, (V[]){heff_tag_at(v_ru_24below_246_24Just, TAG_Removed, 1, (V[]){v_t_2426}), heff_get(v_p_2423, LBL_edits)});
        return heff_tag(TAG_Just, 1, (V[]){(g_heff_2ediff_2esnake(v_eq_240, v_xs_241, v_ys_242, v_t_2424, heff_intSub(v_t_2425, v_k_243), v_t_2427))});
      }
      default: return heff_nomatch(v_below_246);
      }
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ediff_2estepOnto_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ediff_2estepOnto(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[4]); return r;
}
Clo g_heff_2ediff_2ediagonals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ediff_2ediagonals_entry, 7, 0};

V g_heff_2ediff_2ediagonals(V v_eq_240, V v_xs_241, V v_ys_242, V v_d_243, V v_k_244, V v_v_245, V v_acc_246) {
top: ;
  V v_t_247 = heff_intLt(heff_dup(v_d_243), heff_dup(v_k_244));
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_eq_240);
    heff_drop(v_xs_241);
    heff_drop(v_ys_242);
    heff_drop(v_d_243);
    heff_drop(v_k_244);
    return heff_tag(TAG_Right, 1, (V[]){v_acc_246});
  }
  case TAG_False: {
    V v_t_248 = (g_heff_2ediff_2estepOnto(heff_dup(v_eq_240), heff_dup(v_xs_241), heff_dup(v_ys_242), heff_dup(v_k_244), v_v_245));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      V t_0 = v_eq_240;
      V t_1 = v_xs_241;
      V t_2 = v_ys_242;
      V t_3 = v_d_243;
      V t_4 = heff_intAdd(v_k_244, MK_INT(2LL));
      V t_5 = v_v_245;
      V t_6 = v_acc_246;
      v_eq_240 = t_0;
      v_xs_241 = t_1;
      v_ys_242 = t_2;
      v_d_243 = t_3;
      v_k_244 = t_4;
      v_v_245 = t_5;
      v_acc_246 = t_6;
      goto top;
    }
    case TAG_Just: {
      V v_p_249 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      V v_t_2410 = heff_intLe(heff_arrayLength(heff_dup(v_xs_241)), heff_get(heff_dup(v_p_249), LBL_x));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        V v_t_2411 = heff_intSub(heff_get(heff_dup(v_p_249), LBL_x), heff_dup(v_k_244));
        V v_t_2412 = heff_intLe(heff_arrayLength(heff_dup(v_ys_242)), v_t_2411);
        switch (heff_tag_of(v_t_2412)) {
        case TAG_True: {
          heff_drop(v_eq_240);
          heff_drop(v_xs_241);
          heff_drop(v_ys_242);
          heff_drop(v_d_243);
          heff_drop(v_k_244);
          heff_drop(v_acc_246);
          return heff_tag_at(v_ru_24t_248_24Just, TAG_Left, 1, (V[]){heff_get(v_p_249, LBL_edits)});
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_248_24Just, 1);
          V v_t_2413 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(v_k_244), v_p_249, v_acc_246));
          V t_0 = v_eq_240;
          V t_1 = v_xs_241;
          V t_2 = v_ys_242;
          V t_3 = v_d_243;
          V t_4 = heff_intAdd(v_k_244, MK_INT(2LL));
          V t_5 = v_v_245;
          V t_6 = v_t_2413;
          v_eq_240 = t_0;
          v_xs_241 = t_1;
          v_ys_242 = t_2;
          v_d_243 = t_3;
          v_k_244 = t_4;
          v_v_245 = t_5;
          v_acc_246 = t_6;
          goto top;
        }
        default: return heff_nomatch(v_t_2412);
        }
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24t_248_24Just, 1);
        V v_t_2414 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(v_k_244), v_p_249, v_acc_246));
        V t_0 = v_eq_240;
        V t_1 = v_xs_241;
        V t_2 = v_ys_242;
        V t_3 = v_d_243;
        V t_4 = heff_intAdd(v_k_244, MK_INT(2LL));
        V t_5 = v_v_245;
        V t_6 = v_t_2414;
        v_eq_240 = t_0;
        v_xs_241 = t_1;
        v_ys_242 = t_2;
        v_d_243 = t_3;
        v_k_244 = t_4;
        v_v_245 = t_5;
        v_acc_246 = t_6;
        goto top;
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ediff_2ediagonals_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ediff_2ediagonals(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[5]); return r;
}
Clo g_heff_2ediff_2erounds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ediff_2erounds_entry, 5, 0};

V g_heff_2ediff_2erounds(V v_eq_240, V v_xs_241, V v_ys_242, V v_d_243, V v_v_244) {
top: ;
  V v_t_245 = ({ V a_0 = heff_dup(v_eq_240); V a_1 = heff_dup(v_xs_241); V a_2 = heff_dup(v_ys_242); V a_3 = heff_dup(v_d_243); V a_4 = heff_intSub(MK_INT(0LL), heff_dup(v_d_243)); V a_5 = v_v_244; V a_6 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2ediff_2ediagonals(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_v_244); r_; });
  switch (heff_tag_of(v_t_245)) {
  case TAG_Left: {
    V v_edits_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    heff_drop(v_eq_240);
    heff_drop(v_xs_241);
    heff_drop(v_ys_242);
    heff_drop(v_d_243);
    return (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_edits_246));
  }
  case TAG_Right: {
    V v_v_27_247 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V t_0 = v_eq_240;
    V t_1 = v_xs_241;
    V t_2 = v_ys_242;
    V t_3 = heff_intAdd(v_d_243, MK_INT(1LL));
    V t_4 = v_v_27_247;
    v_eq_240 = t_0;
    v_xs_241 = t_1;
    v_ys_242 = t_2;
    v_d_243 = t_3;
    v_v_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ediff_2erounds_entry(V self, V *a) {
  (void)self;
  return g_heff_2ediff_2erounds(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ediff_2ediffBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ediff_2ediffBy_entry, 3, 0};

V g_heff_2ediff_2ediffBy(V v_eq_240, V v_as_241, V v_bs_242) {
top: ;
  V v_xs_243 = heff_arrayFromList(v_as_241);
  V v_ys_244 = heff_arrayFromList(v_bs_242);
  V v_start_245 = (g_heff_2ediff_2esnake(heff_dup(v_eq_240), heff_dup(v_xs_243), heff_dup(v_ys_244), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_246 = heff_intLe(heff_arrayLength(heff_dup(v_xs_243)), heff_get(heff_dup(v_start_245), LBL_x));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    V v_t_247 = heff_intSub(heff_get(heff_dup(v_start_245), LBL_x), MK_INT(0LL));
    V v_t_248 = heff_intLe(heff_arrayLength(heff_dup(v_ys_244)), v_t_247);
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_eq_240);
      heff_drop(v_xs_243);
      heff_drop(v_ys_244);
      return (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(v_start_245, LBL_edits)));
    }
    case TAG_False: {
      V v_t_249 = heff_tag(TAG_Bin, 5, (V[]){MK_INT(1LL), MK_INT(0LL), v_start_245, NTAG(TAG_Tip), NTAG(TAG_Tip)});
      return (g_heff_2ediff_2erounds(v_eq_240, v_xs_243, v_ys_244, MK_INT(1LL), v_t_249));
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_False: {
    V v_t_2410 = heff_tag(TAG_Bin, 5, (V[]){MK_INT(1LL), MK_INT(0LL), v_start_245, NTAG(TAG_Tip), NTAG(TAG_Tip)});
    return (g_heff_2ediff_2erounds(v_eq_240, v_xs_243, v_ys_244, MK_INT(1LL), v_t_2410));
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ediff_2ediffBy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ediff_2ediffBy(a[0], a[1], a[2]);
}
Clo g_heff_2ediff_2eisWordCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ediff_2eisWordCode_entry, 1, 0};

V g_heff_2ediff_2eisWordCode(V v_c_240) {
top: ;
  V v_t_241 = heff_intLe(MK_INT(97LL), heff_dup(v_c_240));
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    v_t_242 = heff_intLe(heff_dup(v_c_240), MK_INT(122LL));
    break;
  }
  case TAG_False: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_c_240);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    V v_t_243 = heff_intLe(MK_INT(65LL), heff_dup(v_c_240));
    V v_t_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      v_t_244 = heff_intLe(heff_dup(v_c_240), MK_INT(90LL));
      break;
    }
    case TAG_False: {
      v_t_244 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_c_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_245 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
      V v_t_246;
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        v_t_246 = heff_intLe(heff_dup(v_c_240), MK_INT(57LL));
        break;
      }
      case TAG_False: {
        v_t_246 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_c_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_247 = heff_intEq(heff_dup(v_c_240), MK_INT(95LL));
        switch (heff_tag_of(v_t_247)) {
        case TAG_True: {
          heff_drop(v_c_240);
          return NTAG(TAG_True);
        }
        case TAG_False: {
          V v_t_248 = heff_intEq(heff_dup(v_c_240), MK_INT(173LL));
          switch (heff_tag_of(v_t_248)) {
          case TAG_True: {
            heff_drop(v_c_240);
            return NTAG(TAG_True);
          }
          case TAG_False: {
            V v_t_249 = heff_intLe(MK_INT(192LL), heff_dup(v_c_240));
            V v_t_2410;
            switch (heff_tag_of(v_t_249)) {
            case TAG_True: {
              v_t_2410 = heff_intLe(heff_dup(v_c_240), MK_INT(214LL));
              break;
            }
            case TAG_False: {
              v_t_2410 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_t_249);
            }
            switch (heff_tag_of(v_t_2410)) {
            case TAG_True: {
              heff_drop(v_c_240);
              return NTAG(TAG_True);
            }
            case TAG_False: {
              V v_t_2411 = heff_intLe(MK_INT(216LL), heff_dup(v_c_240));
              V v_t_2412;
              switch (heff_tag_of(v_t_2411)) {
              case TAG_True: {
                v_t_2412 = heff_intLe(heff_dup(v_c_240), MK_INT(246LL));
                break;
              }
              case TAG_False: {
                v_t_2412 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_t_2411);
              }
              switch (heff_tag_of(v_t_2412)) {
              case TAG_True: {
                heff_drop(v_c_240);
                return NTAG(TAG_True);
              }
              case TAG_False: {
                V v_t_2413 = heff_intLe(MK_INT(248LL), heff_dup(v_c_240));
                V v_t_2414;
                switch (heff_tag_of(v_t_2413)) {
                case TAG_True: {
                  v_t_2414 = heff_intLe(heff_dup(v_c_240), MK_INT(710LL));
                  break;
                }
                case TAG_False: {
                  v_t_2414 = NTAG(TAG_False);
                  break;
                }
                default: heff_nomatch(v_t_2413);
                }
                switch (heff_tag_of(v_t_2414)) {
                case TAG_True: {
                  heff_drop(v_c_240);
                  return NTAG(TAG_True);
                }
                case TAG_False: {
                  V v_t_2415 = heff_intLe(MK_INT(712LL), heff_dup(v_c_240));
                  switch (heff_tag_of(v_t_2415)) {
                  case TAG_True: {
                    V v_t_2416 = heff_intLe(heff_dup(v_c_240), MK_INT(727LL));
                    switch (heff_tag_of(v_t_2416)) {
                    case TAG_True: {
                      heff_drop(v_c_240);
                      return NTAG(TAG_True);
                    }
                    case TAG_False: {
                      V v_t_2417 = heff_intLe(MK_INT(734LL), heff_dup(v_c_240));
                      switch (heff_tag_of(v_t_2417)) {
                      case TAG_True: {
                        V v_t_2418 = heff_intLe(heff_dup(v_c_240), MK_INT(767LL));
                        switch (heff_tag_of(v_t_2418)) {
                        case TAG_True: {
                          heff_drop(v_c_240);
                          return NTAG(TAG_True);
                        }
                        case TAG_False: {
                          V v_t_2419 = heff_intLe(MK_INT(7680LL), heff_dup(v_c_240));
                          switch (heff_tag_of(v_t_2419)) {
                          case TAG_True: {
                            return heff_intLe(v_c_240, MK_INT(7935LL));
                          }
                          case TAG_False: {
                            heff_drop(v_c_240);
                            return NTAG(TAG_False);
                          }
                          default: return heff_nomatch(v_t_2419);
                          }
                        }
                        default: return heff_nomatch(v_t_2418);
                        }
                      }
                      case TAG_False: {
                        V v_t_2420 = heff_intLe(MK_INT(7680LL), heff_dup(v_c_240));
                        switch (heff_tag_of(v_t_2420)) {
                        case TAG_True: {
                          return heff_intLe(v_c_240, MK_INT(7935LL));
                        }
                        case TAG_False: {
                          heff_drop(v_c_240);
                          return NTAG(TAG_False);
                        }
                        default: return heff_nomatch(v_t_2420);
                        }
                      }
                      default: return heff_nomatch(v_t_2417);
                      }
                    }
                    default: return heff_nomatch(v_t_2416);
                    }
                  }
                  case TAG_False: {
                    V v_t_2421 = heff_intLe(MK_INT(734LL), heff_dup(v_c_240));
                    switch (heff_tag_of(v_t_2421)) {
                    case TAG_True: {
                      V v_t_2422 = heff_intLe(heff_dup(v_c_240), MK_INT(767LL));
                      switch (heff_tag_of(v_t_2422)) {
                      case TAG_True: {
                        heff_drop(v_c_240);
                        return NTAG(TAG_True);
                      }
                      case TAG_False: {
                        V v_t_2423 = heff_intLe(MK_INT(7680LL), heff_dup(v_c_240));
                        switch (heff_tag_of(v_t_2423)) {
                        case TAG_True: {
                          return heff_intLe(v_c_240, MK_INT(7935LL));
                        }
                        case TAG_False: {
                          heff_drop(v_c_240);
                          return NTAG(TAG_False);
                        }
                        default: return heff_nomatch(v_t_2423);
                        }
                      }
                      default: return heff_nomatch(v_t_2422);
                      }
                    }
                    case TAG_False: {
                      V v_t_2424 = heff_intLe(MK_INT(7680LL), heff_dup(v_c_240));
                      switch (heff_tag_of(v_t_2424)) {
                      case TAG_True: {
                        return heff_intLe(v_c_240, MK_INT(7935LL));
                      }
                      case TAG_False: {
                        heff_drop(v_c_240);
                        return NTAG(TAG_False);
                      }
                      default: return heff_nomatch(v_t_2424);
                      }
                    }
                    default: return heff_nomatch(v_t_2421);
                    }
                  }
                  default: return heff_nomatch(v_t_2415);
                  }
                }
                default: return heff_nomatch(v_t_2414);
                }
              }
              default: return heff_nomatch(v_t_2412);
              }
            }
            default: return heff_nomatch(v_t_2410);
            }
          }
          default: return heff_nomatch(v_t_248);
          }
        }
        default: return heff_nomatch(v_t_247);
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ediff_2eisWordCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ediff_2eisWordCode(a[0]);
}
Clo g_heff_2ediff_2eisBlankCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ediff_2eisBlankCode_entry, 1, 0};

V g_heff_2ediff_2eisBlankCode(V v_c_240) {
top: ;
  V v_t_241 = heff_intEq(heff_dup(v_c_240), MK_INT(32LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_c_240);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    V v_t_242 = heff_intEq(heff_dup(v_c_240), MK_INT(9LL));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_c_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_243 = heff_intEq(heff_dup(v_c_240), MK_INT(11LL));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_c_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_244 = heff_intEq(heff_dup(v_c_240), MK_INT(12LL));
        switch (heff_tag_of(v_t_244)) {
        case TAG_True: {
          heff_drop(v_c_240);
          return NTAG(TAG_True);
        }
        case TAG_False: {
          V v_t_245 = heff_intEq(heff_dup(v_c_240), MK_INT(160LL));
          switch (heff_tag_of(v_t_245)) {
          case TAG_True: {
            heff_drop(v_c_240);
            return NTAG(TAG_True);
          }
          case TAG_False: {
            V v_t_246 = heff_intEq(heff_dup(v_c_240), MK_INT(5760LL));
            switch (heff_tag_of(v_t_246)) {
            case TAG_True: {
              heff_drop(v_c_240);
              return NTAG(TAG_True);
            }
            case TAG_False: {
              V v_t_247 = heff_intLe(MK_INT(8192LL), heff_dup(v_c_240));
              switch (heff_tag_of(v_t_247)) {
              case TAG_True: {
                V v_t_248 = heff_intLe(heff_dup(v_c_240), MK_INT(8202LL));
                switch (heff_tag_of(v_t_248)) {
                case TAG_True: {
                  heff_drop(v_c_240);
                  return NTAG(TAG_True);
                }
                case TAG_False: {
                  V v_t_249 = heff_intEq(heff_dup(v_c_240), MK_INT(8232LL));
                  switch (heff_tag_of(v_t_249)) {
                  case TAG_True: {
                    heff_drop(v_c_240);
                    return NTAG(TAG_True);
                  }
                  case TAG_False: {
                    V v_t_2410 = heff_intEq(heff_dup(v_c_240), MK_INT(8233LL));
                    switch (heff_tag_of(v_t_2410)) {
                    case TAG_True: {
                      heff_drop(v_c_240);
                      return NTAG(TAG_True);
                    }
                    case TAG_False: {
                      V v_t_2411 = heff_intEq(heff_dup(v_c_240), MK_INT(8239LL));
                      switch (heff_tag_of(v_t_2411)) {
                      case TAG_True: {
                        heff_drop(v_c_240);
                        return NTAG(TAG_True);
                      }
                      case TAG_False: {
                        V v_t_2412 = heff_intEq(heff_dup(v_c_240), MK_INT(8287LL));
                        switch (heff_tag_of(v_t_2412)) {
                        case TAG_True: {
                          heff_drop(v_c_240);
                          return NTAG(TAG_True);
                        }
                        case TAG_False: {
                          V v_t_2413 = heff_intEq(heff_dup(v_c_240), MK_INT(12288LL));
                          switch (heff_tag_of(v_t_2413)) {
                          case TAG_True: {
                            heff_drop(v_c_240);
                            return NTAG(TAG_True);
                          }
                          case TAG_False: {
                            return heff_intEq(v_c_240, MK_INT(65279LL));
                          }
                          default: return heff_nomatch(v_t_2413);
                          }
                        }
                        default: return heff_nomatch(v_t_2412);
                        }
                      }
                      default: return heff_nomatch(v_t_2411);
                      }
                    }
                    default: return heff_nomatch(v_t_2410);
                    }
                  }
                  default: return heff_nomatch(v_t_249);
                  }
                }
                default: return heff_nomatch(v_t_248);
                }
              }
              case TAG_False: {
                V v_t_2414 = heff_intEq(heff_dup(v_c_240), MK_INT(8232LL));
                switch (heff_tag_of(v_t_2414)) {
                case TAG_True: {
                  heff_drop(v_c_240);
                  return NTAG(TAG_True);
                }
                case TAG_False: {
                  V v_t_2415 = heff_intEq(heff_dup(v_c_240), MK_INT(8233LL));
                  switch (heff_tag_of(v_t_2415)) {
                  case TAG_True: {
                    heff_drop(v_c_240);
                    return NTAG(TAG_True);
                  }
                  case TAG_False: {
                    V v_t_2416 = heff_intEq(heff_dup(v_c_240), MK_INT(8239LL));
                    switch (heff_tag_of(v_t_2416)) {
                    case TAG_True: {
                      heff_drop(v_c_240);
                      return NTAG(TAG_True);
                    }
                    case TAG_False: {
                      V v_t_2417 = heff_intEq(heff_dup(v_c_240), MK_INT(8287LL));
                      switch (heff_tag_of(v_t_2417)) {
                      case TAG_True: {
                        heff_drop(v_c_240);
                        return NTAG(TAG_True);
                      }
                      case TAG_False: {
                        V v_t_2418 = heff_intEq(heff_dup(v_c_240), MK_INT(12288LL));
                        switch (heff_tag_of(v_t_2418)) {
                        case TAG_True: {
                          heff_drop(v_c_240);
                          return NTAG(TAG_True);
                        }
                        case TAG_False: {
                          return heff_intEq(v_c_240, MK_INT(65279LL));
                        }
                        default: return heff_nomatch(v_t_2418);
                        }
                      }
                      default: return heff_nomatch(v_t_2417);
                      }
                    }
                    default: return heff_nomatch(v_t_2416);
                    }
                  }
                  default: return heff_nomatch(v_t_2415);
                  }
                }
                default: return heff_nomatch(v_t_2414);
                }
              }
              default: return heff_nomatch(v_t_247);
              }
            }
            default: return heff_nomatch(v_t_246);
            }
          }
          default: return heff_nomatch(v_t_245);
          }
        }
        default: return heff_nomatch(v_t_244);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ediff_2eisBlankCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ediff_2eisBlankCode(a[0]);
}
Clo g_heff_2ediff_2erunEnd_24s1757338005x572581804_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ediff_2erunEnd_24s1757338005x572581804_entry, 2, 0};

V g_heff_2ediff_2erunEnd_24s1757338005x572581804(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLt(heff_dup(v_i_241), heff_strLength(heff_dup(v_s_240)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = (g_heff_2ediff_2eisWordCode(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241))));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_s_240);
      return v_i_241;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_False: {
    heff_drop(v_s_240);
    return v_i_241;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ediff_2erunEnd_24s1757338005x572581804_entry(V self, V *a) {
  (void)self;
  return g_heff_2ediff_2erunEnd_24s1757338005x572581804(a[0], a[1]);
}
Clo g_heff_2ediff_2erunEnd_24s1727631165x667442256_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ediff_2erunEnd_24s1727631165x667442256_entry, 2, 0};

V g_heff_2ediff_2erunEnd_24s1727631165x667442256(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLt(heff_dup(v_i_241), heff_strLength(heff_dup(v_s_240)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = (g_heff_2ediff_2eisBlankCode(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241))));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_s_240);
      return v_i_241;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_False: {
    heff_drop(v_s_240);
    return v_i_241;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ediff_2erunEnd_24s1727631165x667442256_entry(V self, V *a) {
  (void)self;
  return g_heff_2ediff_2erunEnd_24s1727631165x667442256(a[0], a[1]);
}
Clo g_heff_2ediff_2etokenEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ediff_2etokenEnd_entry, 2, 0};

V g_heff_2ediff_2etokenEnd(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(10LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    return heff_intAdd(v_i_241, MK_INT(1LL));
  }
  case TAG_False: {
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(13LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_t_244 = heff_intLt(heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_strLength(heff_dup(v_s_240)));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        V v_t_245 = heff_strCharCode(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
        V v_t_246 = heff_intEq(v_t_245, MK_INT(10LL));
        switch (heff_tag_of(v_t_246)) {
        case TAG_True: {
          heff_drop(v_s_240);
          return heff_intAdd(v_i_241, MK_INT(2LL));
        }
        case TAG_False: {
          V v_t_247 = (g_heff_2ediff_2eisWordCode(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241))));
          switch (heff_tag_of(v_t_247)) {
          case TAG_True: {
            HEFF_LAST return g_heff_2ediff_2erunEnd_24s1757338005x572581804(v_s_240, v_i_241);
          }
          case TAG_False: {
            V v_t_248 = (g_heff_2ediff_2eisBlankCode(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241))));
            switch (heff_tag_of(v_t_248)) {
            case TAG_True: {
              HEFF_LAST return g_heff_2ediff_2erunEnd_24s1727631165x667442256(v_s_240, v_i_241);
            }
            case TAG_False: {
              heff_drop(v_s_240);
              return heff_intAdd(v_i_241, MK_INT(1LL));
            }
            default: return heff_nomatch(v_t_248);
            }
          }
          default: return heff_nomatch(v_t_247);
          }
        }
        default: return heff_nomatch(v_t_246);
        }
      }
      case TAG_False: {
        V v_t_249 = (g_heff_2ediff_2eisWordCode(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241))));
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          HEFF_LAST return g_heff_2ediff_2erunEnd_24s1757338005x572581804(v_s_240, v_i_241);
        }
        case TAG_False: {
          V v_t_2410 = (g_heff_2ediff_2eisBlankCode(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241))));
          switch (heff_tag_of(v_t_2410)) {
          case TAG_True: {
            HEFF_LAST return g_heff_2ediff_2erunEnd_24s1727631165x667442256(v_s_240, v_i_241);
          }
          case TAG_False: {
            heff_drop(v_s_240);
            return heff_intAdd(v_i_241, MK_INT(1LL));
          }
          default: return heff_nomatch(v_t_2410);
          }
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    case TAG_False: {
      V v_t_2411 = (g_heff_2ediff_2eisWordCode(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241))));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        HEFF_LAST return g_heff_2ediff_2erunEnd_24s1757338005x572581804(v_s_240, v_i_241);
      }
      case TAG_False: {
        V v_t_2412 = (g_heff_2ediff_2eisBlankCode(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241))));
        switch (heff_tag_of(v_t_2412)) {
        case TAG_True: {
          HEFF_LAST return g_heff_2ediff_2erunEnd_24s1727631165x667442256(v_s_240, v_i_241);
        }
        case TAG_False: {
          heff_drop(v_s_240);
          return heff_intAdd(v_i_241, MK_INT(1LL));
        }
        default: return heff_nomatch(v_t_2412);
        }
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ediff_2etokenEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2ediff_2etokenEnd(a[0], a[1]);
}
Clo g_heff_2ediff_2ewordsFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ediff_2ewordsFrom_entry, 3, 0};

V g_heff_2ediff_2ewordsFrom(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_242));
  }
  case TAG_False: {
    V v_t_244 = (g_heff_2ediff_2etokenEnd(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_245 = (g_heff_2ediff_2etokenEnd(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_i_241, v_t_245), v_acc_242});
    V t_0 = v_s_240;
    V t_1 = v_t_244;
    V t_2 = v_t_246;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ediff_2ewordsFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ediff_2ewordsFrom(a[0], a[1], a[2]);
}
Clo g_heff_2ediff_2ejoinEdit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ediff_2ejoinEdit_entry, 2, 0};

V g_heff_2ediff_2ejoinEdit(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Same: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Same = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Same: {
      V v_b_243 = heff_field(v_x2_241, 0);
      V v_ru_24x2_241_24Same = heff_take_reuse_n(v_x2_241, 1ULL, 1);
      V v_t_244 = heff_tag_at(v_ru_24x1_240_24Same, TAG_Same, 1, (V[]){heff_strAppend(v_a_242, v_b_243)});
      return heff_tag_at(v_ru_24x2_241_24Same, TAG_Just, 1, (V[]){v_t_244});
    }
    case TAG_Removed: {
      heff_take_n(v_x2_241, 0ULL, 1);
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24x1_240_24Same, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Added: {
      heff_take_n(v_x2_241, 0ULL, 1);
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24x1_240_24Same, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Removed: {
    V v_a_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Removed = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Same: {
      heff_take_n(v_x2_241, 0ULL, 1);
      heff_drop(v_a_247);
      heff_drop_cell(v_ru_24x1_240_24Removed, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Removed: {
      V v_b_249 = heff_field(v_x2_241, 0);
      V v_ru_24x2_241_24Removed = heff_take_reuse_n(v_x2_241, 1ULL, 1);
      V v_t_2410 = heff_tag_at(v_ru_24x1_240_24Removed, TAG_Removed, 1, (V[]){heff_strAppend(v_a_247, v_b_249)});
      return heff_tag_at(v_ru_24x2_241_24Removed, TAG_Just, 1, (V[]){v_t_2410});
    }
    case TAG_Added: {
      heff_take_n(v_x2_241, 0ULL, 1);
      heff_drop(v_a_247);
      heff_drop_cell(v_ru_24x1_240_24Removed, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Added: {
    V v_a_2412 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Added = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Same: {
      heff_take_n(v_x2_241, 0ULL, 1);
      heff_drop(v_a_2412);
      heff_drop_cell(v_ru_24x1_240_24Added, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Removed: {
      heff_take_n(v_x2_241, 0ULL, 1);
      heff_drop(v_a_2412);
      heff_drop_cell(v_ru_24x1_240_24Added, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Added: {
      V v_b_2415 = heff_field(v_x2_241, 0);
      V v_ru_24x2_241_24Added = heff_take_reuse_n(v_x2_241, 1ULL, 1);
      V v_t_2416 = heff_tag_at(v_ru_24x1_240_24Added, TAG_Added, 1, (V[]){heff_strAppend(v_a_2412, v_b_2415)});
      return heff_tag_at(v_ru_24x2_241_24Added, TAG_Just, 1, (V[]){v_t_2416});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ediff_2ejoinEdit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ediff_2ejoinEdit(a[0], a[1]);
}
Clo g_heff_2ediff_2ejoinRunsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ediff_2ejoinRunsGo_entry, 2, 0};

V g_heff_2ediff_2ejoinRunsGo(V v_e_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_f_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ediff_2ejoinEdit(heff_dup(v_e_240), heff_dup(v_f_242)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_240, (g_heff_2ediff_2ejoinRunsGo(v_f_242, v_rest_243))});
    }
    case TAG_Just: {
      V v_g_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      heff_drop(v_e_240);
      heff_drop(v_f_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_g_245;
      V t_1 = v_rest_243;
      v_e_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ediff_2ejoinRunsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ediff_2ejoinRunsGo(a[0], a[1]);
}