// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define LBL_byName 571997869
#define LBL_ctx 308385
#define LBL_def 308863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_inner 301714032
#define LBL_keys 9783995
#define LBL_large 304101205
#define LBL_n 328
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_params 951713969
#define LBL_rest 9992347
#define LBL_values 1123329101
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
static uint32_t shape_names__rest__ctx[] = {LBL_names, LBL_rest, LBL_ctx};
static uint32_t shape_params__names__def__large[] = {LBL_params, LBL_names, LBL_def, LBL_large};
V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps(V, V, V, V, V, V);
V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps_clo;
V g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161(V, V, V, V);
V g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_clo;
V g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(V, V, V, V, V, V);
V g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_clo;
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_clo;
V g_heff_2esyntax_2epsurface_2eformerAt(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eformerAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eformerAt_clo;
V g_heff_2esyntax_2epsurface_2eformerOf(V, V, V);
V g_heff_2esyntax_2epsurface_2eformerOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eformerOf_clo;
V g_heff_2esyntax_2epsurface_2eimplicitGroup(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eimplicitGroup_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eimplicitGroup_clo;
V g_heff_2esyntax_2epsurface_2eimplicitName(V, V, V);
V g_heff_2esyntax_2epsurface_2eimplicitName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eimplicitName_clo;
V g_heff_2esyntax_2epsurface_2elistItems(V);
V g_heff_2esyntax_2epsurface_2elistItems_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2elistItems_clo;
V g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(V, V, V, V);
V g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_clo;
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_clo;
V g_heff_2esyntax_2epsurface_2eunIsTy(V);
V g_heff_2esyntax_2epsurface_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eunIsTy_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2esyntax_2epsurface_2elistItems_str0, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elistItems_str1, 4, "Cons");
Clo g_heff_2esyntax_2epsurface_2elistItems_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2elistItems_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2elistItems(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    V v_x11_2411 = heff_field(v_x1_240, 0);
    V v_ts_2412 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24STag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x11_2411), ((V)&g_heff_2esyntax_2epsurface_2elistItems_str0))) {
      heff_drop(v_x11_2411);
      heff_drop_cell(v_ru_24x1_240_24STag, 2);
      if (heff_intEq_c(heff_arrayLength(v_ts_2412), MK_INT(0LL))) {
        return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
      } else {
        return NTAG(TAG_Nothing);
      }
    } else {
      if (heff_strEq_c(v_x11_2411, ((V)&g_heff_2esyntax_2epsurface_2elistItems_str1))) {
        if (heff_intEq_c(heff_arrayLength(heff_dup(v_ts_2412)), MK_INT(2LL))) {
          if (heff_intLt_c(MK_INT(0LL), heff_arrayLength(heff_dup(v_ts_2412)))) {
            V v_t_2418 = heff_arrayIndex(heff_dup(v_ts_2412), MK_INT(0LL));
            V v_x3_2421;
            if (heff_intLt_c(MK_INT(1LL), heff_arrayLength(heff_dup(v_ts_2412)))) {
              V v_t_2420 = heff_arrayIndex(v_ts_2412, MK_INT(1LL));
              v_x3_2421 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
            } else {
              heff_drop(v_ts_2412);
              v_x3_2421 = NTAG(TAG_Nothing);
            }
            V v_x2_2423;
            switch (heff_tag_of(v_x3_2421)) {
            case TAG_Nothing: {
              v_x2_2423 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_x_2422 = heff_field(v_x3_2421, 0);
              heff_take_n(v_x3_2421, 1ULL, 1);
              v_x2_2423 = (g_heff_2esyntax_2epsurface_2elistItems(v_x_2422));
              break;
            }
            default: heff_nomatch(v_x3_2421);
            }
            switch (heff_tag_of(v_x2_2423)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x1_240_24STag, 2);
              heff_drop(v_t_2418);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_ts_2424 = heff_field(v_x2_2423, 0);
              V v_ru_24x2_2423_24Just = heff_take_reuse_n(v_x2_2423, 1ULL, 1);
              return heff_tag_at_n(v_ru_24x2_2423_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24STag, TAG_Cons, 2, (V[]){v_t_2418, v_ts_2424})});
            }
            default: return heff_nomatch(v_x2_2423);
            }
          } else {
            heff_drop(v_ts_2412);
            heff_drop_cell(v_ru_24x1_240_24STag, 2);
            return NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_ts_2412);
          heff_drop_cell(v_ru_24x1_240_24STag, 2);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_ts_2412);
        heff_drop_cell(v_ru_24x1_240_24STag, 2);
        return NTAG(TAG_Nothing);
      }
    }
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIs: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epsurface_2elistItems_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2elistItems(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str0, 5, ") -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str1, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str3, 6, "}} -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str4, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str5, 2, "{{");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str6, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str7, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str8, 6, "}} -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str9, 6, "{{_ : ");
Clo g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_entry, 6, 0};

V g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(V v_c_240, V v_xs_241, V v_level_242, V v_dom_243, V v_x6_244, V v_implicit_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkAbs: {
    V v_x_246 = heff_field(v_x6_244, 0);
    V v_b_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24MkAbs = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_implicit_245)) {
    case TAG_Expl: {
      V v_t_248 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_249 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), v_xs_241}); V a_3 = v_b_247; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_247); r_; });
      V v_t_2410 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str0), v_t_249));
      V v_t_2411 = heff_strAppend(v_x_246, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str1), v_t_2410));
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str2), v_t_2411);
    }
    case TAG_Impl: {
      V v_t_2438;
      switch (heff_tag_of(v_dom_243)) {
      case TAG_SU: {
        V v_u_2412 = heff_field(v_dom_243, 0);
        V v_t_2413 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = (g_heff_2esyntax_2epsurface_2eimplicitGroup(v_t_2413, v_u_2412, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})));
        break;
      }
      case TAG_SDecode: {
        V v_t_2415 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2415, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SFunction: {
        V v_t_2421 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2421, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SRecord: {
        V v_t_2425 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2425, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SSum: {
        V v_t_2427 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2427, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SIsTy: {
        V v_t_2429 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2429, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimInt: {
        V v_t_2430 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2430, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimFloat: {
        V v_t_2431 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2431, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimString: {
        V v_t_2432 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2432, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimRune: {
        V v_t_2433 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2433, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimArray: {
        V v_t_2435 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2435, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SFixed: {
        V v_t_2437 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2438 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2437, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      default: heff_nomatch(v_dom_243);
      }
      return (g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161(v_c_240, v_xs_241, v_dom_243, v_t_2438));
    }
    case TAG_Inst: {
      V v_t_2439 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2440 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), v_xs_241}); V a_3 = v_b_247; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_247); r_; });
      V v_t_2441 = heff_strAppend(v_t_2439, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str3), v_t_2440));
      V v_t_2442 = heff_strAppend(v_x_246, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str4), v_t_2441));
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str5), v_t_2442);
    }
    default: return heff_nomatch(v_implicit_245);
    }
  }
  case TAG_AbsConst: {
    V v_b_2443 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    switch (heff_tag_of(v_implicit_245)) {
    case TAG_Expl: {
      V v_t_2444 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2445 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2443; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_2443); r_; });
      return heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str6), v_t_2445));
    }
    case TAG_Impl: {
      V v_t_2446 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2447 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2443; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_2443); r_; });
      return heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str7), v_t_2447));
    }
    case TAG_Inst: {
      V v_t_2448 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      V v_t_2449 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2443; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_2443); r_; });
      V v_t_2450 = heff_strAppend(v_t_2448, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str8), v_t_2449));
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str9), v_t_2450);
    }
    default: return heff_nomatch(v_implicit_245);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V a5 = a[5]; V r = g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(a[0], a[1], a2, a3, a[4], a5); heff_drop(a2); heff_drop(a3); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_str1, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_str2, 3, " : ");
Clo g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(V v_c_240, V v_ds_241, V v_acc_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_l_244 = heff_field(v_x5_243, 0);
    V v_t_245 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkPair = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x5_243_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_l_244), heff_dup(heff_rfield(v_acc_242, 0))});
    V v_t_247 = ({ V a_0 = heff_dup(v_c_240); V a_1 = MK_INT(0LL); V a_2 = heff_dup(heff_rfield(v_acc_242, 0)); V a_3 = v_t_245; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
    V v_t_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_l_244), heff_rfield(v_ds_241, 1)));
    V v_x4_2414;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop_rec(v_ds_241, 3);
      v_x4_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_i_249 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      V v_xs_2410 = heff_get_n(v_ds_241, 2, 3);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_249))) {
        if (heff_intLt_c(heff_dup(v_i_249), heff_arrayLength(heff_dup(v_xs_2410)))) {
          V v_t_2413 = heff_arrayIndex(v_xs_2410, v_i_249);
          v_x4_2414 = heff_tag_at_n(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){v_t_2413});
        } else {
          heff_drop(v_i_249);
          heff_drop_cell(v_ru_24t_248_24Just, 1);
          heff_drop(v_xs_2410);
          v_x4_2414 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_i_249);
        heff_drop_cell(v_ru_24t_248_24Just, 1);
        heff_drop(v_xs_2410);
        v_x4_2414 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2417;
    switch (heff_tag_of(v_x4_2414)) {
    case TAG_Nothing: {
      heff_drop(v_c_240);
      v_t_2417 = ((V)&g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_str0);
      break;
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_x4_2414, 0);
      heff_take_n(v_x4_2414, 1ULL, 1);
      V v_t_2416 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(0LL), heff_dup(heff_rfield(v_acc_242, 0)), v_d_2415));
      v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_str1), v_t_2416);
      break;
    }
    default: heff_nomatch(v_x4_2414);
    }
    V v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_str2), heff_strAppend(v_t_247, v_t_2417));
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_l_244, v_t_2418), NTAG(TAG_Nil)});
    V v_t_2420 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_242, 1, 2), v_t_2419));
    return heff_rec_n(2, shape_names__out, (V[]){v_t_246, v_t_2420});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps_str0, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps_str2, 1, "(");
Clo g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps_entry, 6, 0};

V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps(V v_c_240, V v_xs_241, V v_names_242, V v_i_243, V v_x6_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_xs_241);
    heff_drop(v_names_242);
    heff_drop(v_i_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x6_244, 0);
    V v_rest_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_248 = (g_heff_2esyntax_2epsurface_2eimplicitName(heff_dup(v_names_242), heff_dup(v_i_243), heff_dup(v_a_246)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      V v_t_249 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_241), v_a_246));
      V v_cell_2410 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_c_240;
      V t_1 = v_xs_241;
      V t_2 = v_names_242;
      V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
      V t_4 = v_rest_247;
      V t_5 = v_cell_2410;
      v_c_240 = t_0;
      v_xs_241 = t_1;
      v_names_242 = t_2;
      v_i_243 = t_3;
      v_x6_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    case TAG_Just: {
      V v_imp_2412 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      heff_drop(v_a_246);
      V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 1, 2);
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x6_244_24Cons, 2);
        heff_drop_rec(v_imp_2412, 2);
        heff_drop(v_t_2413);
        V t_0 = v_c_240;
        V t_1 = v_xs_241;
        V t_2 = v_names_242;
        V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
        V t_4 = v_rest_247;
        V t_5 = v_d_245;
        v_c_240 = t_0;
        v_xs_241 = t_1;
        v_names_242 = t_2;
        v_i_243 = t_3;
        v_x6_244 = t_4;
        v_d_245 = t_5;
        goto top;
      } else {
        heff_drop(v_t_2413);
        V v_t_2414 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), heff_take_field(v_imp_2412, 1)));
        V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps_str0), heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps_str1)));
        V v_t_2416 = heff_strAppend(heff_get_n(v_imp_2412, 0, 2), v_t_2415);
        V v_cell_2417 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps_str2), v_t_2416), heff_hole()});
        V v_u_2418 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2417));
        heff_drop(v_u_2418);
        V t_0 = v_c_240;
        V t_1 = v_xs_241;
        V t_2 = v_names_242;
        V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
        V t_4 = v_rest_247;
        V t_5 = v_cell_2417;
        v_c_240 = t_0;
        v_xs_241 = t_1;
        v_names_242 = t_2;
        v_i_243 = t_3;
        v_x6_244 = t_4;
        v_d_245 = t_5;
        goto top;
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2esyntax_2epsurface_2eformerAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eformerAt_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2eformerAt(V v_params_240, V v_ns_241, V v_b_242, V v_large_243) {
top: ;
  switch (heff_tag_of(v_b_242)) {
  case TAG_SLocal: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SGlobal: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SCode: {
    V v_d_246 = heff_field(v_b_242, 0);
    heff_take_n(v_b_242, 1ULL, 1);
    V v_t_247 = (g_heff_2esyntax_2epsurface_2eunIsTy(v_d_246));
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, v_t_247, v_large_243});
  }
  case TAG_SApp: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLam: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SCons: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SProj: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_STag: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SMatch: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SSpecialize: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SIs: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SOpaque: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SAbandon: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SRec: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SFix: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SImplicit: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SPrim: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SMetaApp: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitInt: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFloat: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitString: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitBytes: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitRune: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFixed: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFloat32: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  default: return heff_nomatch(v_b_242);
  }
}
V g_heff_2esyntax_2epsurface_2eformerAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eformerAt(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str1, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str2, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str3, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str5, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str6, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str7, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str9, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str10, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str11, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str13, 2, "  ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str15, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str16, 7, " where\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str17, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str18, 7, "theory ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str20, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str21, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str22, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str24, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str27, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str28, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str29, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str30, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str31, 5, "data ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str33, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str34, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str35, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str37, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str38, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str39, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str41, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str42, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str43, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str45, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str46, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str47, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str49, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str50, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str51, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str53, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str54, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str55, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str57, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str58, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_str59, 5, "type ");
V g_heff_2esyntax_2epsurface_2eformerOf_lam0(V self, V *args);
V g_heff_2esyntax_2epsurface_2eformerOf_lam2(V self, V *args);
V g_heff_2esyntax_2epsurface_2eformerOf_lam1(V self, V *args);
Clo g_heff_2esyntax_2epsurface_2eformerOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eformerOf_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2eformerOf(V v_c_240, V v_name_241, V v_tf_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_tf_242, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    V v_ru_24t_243_24SU = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_245 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SU, 1);
      heff_drop(v_t_245);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_245);
      V v_t_246 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str0), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_247 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str1), heff_strAppend(v_t_247, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str2)));
      V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str3), heff_strAppend(v_t_246, v_t_248));
      return heff_tag_at_n(v_ru_24t_243_24SU, TAG_Just, 1, (V[]){v_t_249});
    }
  }
  case TAG_SDecode: {
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_2411 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SDecode, 1);
      heff_drop(v_t_2411);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2411);
      V v_t_2412 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str4), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2413 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str5), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str6)));
      V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str7), heff_strAppend(v_t_2412, v_t_2414));
      return heff_tag_at_n(v_ru_24t_243_24SDecode, TAG_Just, 1, (V[]){v_t_2415});
    }
  }
  case TAG_SFunction: {
    heff_take_n(v_t_243, 0ULL, 5);
    V v_t_2421 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2421);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2421);
      V v_t_2422 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str8), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2423 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2424 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str9), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str10)));
      V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str11), heff_strAppend(v_t_2422, v_t_2424));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2425});
    }
  }
  case TAG_SRecord: {
    V v_fs_2427 = heff_field(v_t_243, 1);
    V v_ds_2428 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 6ULL, 3);
    V v_t_2429 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_t_2429);
      V v_t_2430 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str12), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2431 = heff_arrayToList(heff_take_field(v_fs_2427, 0));
      V v_t_2432 = heff_arrayToList(heff_get_n(v_fs_2427, 2, 3));
      V v_fs_2433 = (g_heff_2eutil_2edict_2ezipKV(v_t_2431, v_t_2432));
      V v_t_2434 = heff_rec_n(2, shape_names__out, (V[]){heff_get_n(v_tf_242, 1, 4), NTAG(TAG_Nil)});
      V v_acc_2437 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epsurface_2eformerOf_lam0, 2, 2, (V[]){v_c_240, v_ds_2428}); V a_1 = v_t_2434; V a_2 = v_fs_2433; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2433); r_; });
      V v_x2_2438 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str13), heff_get_n(v_acc_2437, 1, 2)));
      V v_t_2441;
      switch (heff_tag_of(v_x2_2438)) {
      case TAG_Nil: {
        v_t_2441 = ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str14);
        break;
      }
      case TAG_Cons: {
        V v_x_2439 = heff_field(v_x2_2438, 0);
        V v_xs_2440 = heff_field(v_x2_2438, 1);
        heff_take_n(v_x2_2438, 3ULL, 2);
        v_t_2441 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str15); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2438);
      }
      V v_t_2442 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str16), heff_strAppend(v_t_2441, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str17)));
      V v_t_2443 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str18), heff_strAppend(v_t_2430, v_t_2442));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2443});
    } else {
      heff_drop_rec(v_fs_2427, 3);
      heff_drop(v_ds_2428);
      heff_drop(v_t_2429);
      V v_t_2444 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str19), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2445 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2446 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str20), heff_strAppend(v_t_2445, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str21)));
      V v_t_2447 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str22), heff_strAppend(v_t_2444, v_t_2446));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2447});
    }
  }
  case TAG_SSum: {
    V v_vs_2448 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2449 = heff_dup(heff_rfield(v_tf_242, 3));
    if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_rec(v_vs_2448, 3);
      heff_drop_cell(v_ru_24t_243_24SSum, 1);
      heff_drop(v_t_2449);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2449);
      V v_t_2450 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str23), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2451 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2448, 0)));
      V v_t_2452 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2448, 2)));
      V v_x1_2453 = (g_heff_2eutil_2edict_2ezipKV(v_t_2451, v_t_2452));
      V v_t_2456;
      switch (heff_tag_of(v_x1_2453)) {
      case TAG_Nil: {
        v_t_2456 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x1_2453, 0ULL, 2);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x1_2453);
      }
      V v_t_2472;
      if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
        heff_drop(v_c_240);
        heff_drop_rec(v_tf_242, 4);
        heff_drop_rec(v_vs_2448, 3);
        heff_drop(v_t_2456);
        v_t_2472 = ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str24);
      } else {
        heff_drop(v_t_2456);
        V v_t_2457 = heff_arrayToList(heff_take_field(v_vs_2448, 0));
        V v_t_2458 = heff_arrayToList(heff_get_n(v_vs_2448, 2, 3));
        V v_t_2459 = (g_heff_2eutil_2edict_2ezipKV(v_t_2457, v_t_2458));
        V v_x2_2468 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eformerOf_lam1, 1, 2, (V[]){v_c_240, v_tf_242}), v_t_2459));
        V v_t_2471;
        switch (heff_tag_of(v_x2_2468)) {
        case TAG_Nil: {
          v_t_2471 = ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str27);
          break;
        }
        case TAG_Cons: {
          V v_x_2469 = heff_field(v_x2_2468, 0);
          V v_xs_2470 = heff_field(v_x2_2468, 1);
          heff_take_n(v_x2_2468, 3ULL, 2);
          v_t_2471 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str28); V a_1 = v_x_2469; V a_2 = v_xs_2470; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2470); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2468);
        }
        v_t_2472 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str29), v_t_2471);
      }
      V v_t_2473 = heff_strAppend(v_t_2450, heff_strAppend(v_t_2472, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str30)));
      return heff_tag_at_n(v_ru_24t_243_24SSum, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str31), v_t_2473)});
    }
  }
  case TAG_SIsTy: {
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_2475 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2475) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SIsTy, 1);
      heff_drop(v_t_2475);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2475);
      V v_t_2476 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str32), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2477 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2478 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str33), heff_strAppend(v_t_2477, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str34)));
      V v_t_2479 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str35), heff_strAppend(v_t_2476, v_t_2478));
      return heff_tag_at_n(v_ru_24t_243_24SIsTy, TAG_Just, 1, (V[]){v_t_2479});
    }
  }
  case TAG_SPrimInt: {
    V v_t_2480 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2480) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2480);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2480);
      V v_t_2481 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str36), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2482 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2483 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str37), heff_strAppend(v_t_2482, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str38)));
      V v_t_2484 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str39), heff_strAppend(v_t_2481, v_t_2483));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2484});
    }
  }
  case TAG_SPrimFloat: {
    V v_t_2485 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2485) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2485);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2485);
      V v_t_2486 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str40), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2487 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2488 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str41), heff_strAppend(v_t_2487, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str42)));
      V v_t_2489 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str43), heff_strAppend(v_t_2486, v_t_2488));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2489});
    }
  }
  case TAG_SPrimString: {
    V v_t_2490 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2490) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2490);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2490);
      V v_t_2491 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str44), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2492 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2493 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str45), heff_strAppend(v_t_2492, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str46)));
      V v_t_2494 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str47), heff_strAppend(v_t_2491, v_t_2493));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2494});
    }
  }
  case TAG_SPrimRune: {
    V v_t_2495 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2495) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2495);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2495);
      V v_t_2496 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str48), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2497 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2498 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str49), heff_strAppend(v_t_2497, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str50)));
      V v_t_2499 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str51), heff_strAppend(v_t_2496, v_t_2498));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2499});
    }
  }
  case TAG_SPrimArray: {
    V v_ru_24t_243_24SPrimArray = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_24101 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_24101) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SPrimArray, 1);
      heff_drop(v_t_24101);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_24101);
      V v_t_24102 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str52), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_24103 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_24104 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str53), heff_strAppend(v_t_24103, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str54)));
      V v_t_24105 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str55), heff_strAppend(v_t_24102, v_t_24104));
      return heff_tag_at_n(v_ru_24t_243_24SPrimArray, TAG_Just, 1, (V[]){v_t_24105});
    }
  }
  case TAG_SFixed: {
    V v_ru_24t_243_24SFixed = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_24107 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_24107) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SFixed, 1);
      heff_drop(v_t_24107);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_24107);
      V v_t_24108 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str56), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_24109 = ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_24110 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str57), heff_strAppend(v_t_24109, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str58)));
      V v_t_24111 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_str59), heff_strAppend(v_t_24108, v_t_24110));
      return heff_tag_at_n(v_ru_24t_243_24SFixed, TAG_Just, 1, (V[]){v_t_24111});
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2esyntax_2epsurface_2eformerOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eformerOf(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2epsurface_2eformerOf_lam0(V self, V *args) {
  V v_acc_2435 = args[0];
  V v_f_2436 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_ds_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(v_c_240, v_ds_2428, v_acc_2435, v_f_2436));
}
V g_heff_2esyntax_2epsurface_2eformerOf_lam2(V self, V *args) {
  V v_t2_2463 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_tf_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_c_240; V a_1 = MK_INT(2LL); V a_2 = heff_get_n(v_tf_242, 1, 4); V a_3 = v_t2_2463; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2463); r_; });
}
V g_heff_2esyntax_2epsurface_2eformerOf_lam1(V self, V *args) {
  V v_v_2460 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_tf_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2460)) {
  case TAG_MkPair: {
    V v_t_2461 = heff_field(v_v_2460, 0);
    V v_ts_2462 = heff_field(v_v_2460, 1);
    V v_ru_24v_2460_24MkPair = heff_take_reuse_n(v_v_2460, 3ULL, 2);
    V v_t_2464 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eformerOf_lam2, 1, 2, (V[]){v_c_240, v_tf_242}), heff_arrayToList(v_ts_2462)));
    V v_x2_2465 = heff_tag_at_n(v_ru_24v_2460_24MkPair, TAG_Cons, 2, (V[]){v_t_2461, v_t_2464});
    switch (heff_tag_of(v_x2_2465)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str25);
    }
    case TAG_Cons: {
      V v_x_2466 = heff_field(v_x2_2465, 0);
      V v_xs_2467 = heff_field(v_x2_2465, 1);
      heff_take_n(v_x2_2465, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eformerOf_str26); V a_1 = v_x_2466; V a_2 = v_xs_2467; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2467); r_; });
    }
    default: return heff_nomatch(v_x2_2465);
    }
  }
  default: return heff_nomatch(v_v_2460);
  }
}