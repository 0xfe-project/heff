// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AssocNone 34711
#define TAG_Looser 37443
#define TAG_Same 22203
#define TAG_Tighter 5275
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define LBL_above 293969847
#define LBL_assoc 294479919
#define LBL_at 9882
#define LBL_groups 709681407
#define LBL_id 10114
#define LBL_loosest 581880769
#define LBL_ops 319788
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_id__assoc__ops__loosest__at[] = {LBL_id, LBL_assoc, LBL_ops, LBL_loosest, LBL_at};
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2eappendF_24dps(V, V, V);
V g_heff_2esyntax_2efixity_2eappendF_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_24dps_clo;
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
HeffT2 g_heff_2esyntax_2efixity_2efindG_24cpr(V, V);
HeffT2 g_heff_2esyntax_2efixity_2efindG_24s1761050079x731378582_24cpr(V, V);
HeffT2 g_heff_2esyntax_2efixity_2egroupOrName_24cpr(V, V);
V g_heff_2esyntax_2efixity_2elosers(V, V);
V g_heff_2esyntax_2efixity_2elosers_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2elosers_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByE_24dps(V, V);
V g_heff_2esyntax_2efixity_2enubByE_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_24dps_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2efixity_2enubByG_24dps(V, V);
V g_heff_2esyntax_2efixity_2enubByG_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_24dps_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_heff_2esyntax_2efixity_2etighterGo(V, V, V, V);
V g_heff_2esyntax_2efixity_2etighterGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2etighterGo_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2ekeepIf_24s1166238673x178798903(V, V);
V g_list_2ekeepIf_24s1166238673x178798903_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1166238673x178798903_clo;
V g_list_2ekeepIf_24s1613584875x1342487326(V, V);
V g_list_2ekeepIf_24s1613584875x1342487326_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1613584875x1342487326_clo;
V g_list_2emap_24f189927396x2059034600(V);
V g_list_2emap_24f189927396x2059034600_entry(V self, V *a);
extern Clo g_list_2emap_24f189927396x2059034600_clo;
V g_list_2emap_24f719546030x1732151491(V, V);
V g_list_2emap_24f719546030x1732151491_entry(V self, V *a);
extern Clo g_list_2emap_24f719546030x1732151491_clo;
HEFF_REC_LIT(g_heff_2esyntax_2efixity_2eemptyFixities_lit0, 2, shape_groups__above, NTAG(TAG_Nil), NTAG(TAG_Nil));

static V g_heff_2esyntax_2efixity_2eemptyFixities_val;
static HEFF_ONCE g_heff_2esyntax_2efixity_2eemptyFixities_st;
static V g_heff_2esyntax_2efixity_2eemptyFixities_init(void) {
  return ((V)&g_heff_2esyntax_2efixity_2eemptyFixities_lit0);
}
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efixity_2eemptyFixities_st)) return g_heff_2esyntax_2efixity_2eemptyFixities_val;
  return heff_global(&g_heff_2esyntax_2efixity_2eemptyFixities_val, &g_heff_2esyntax_2efixity_2eemptyFixities_st, g_heff_2esyntax_2efixity_2eemptyFixities_init);
}
Clo g_heff_2esyntax_2efixity_2enubByG_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2enubByG_entry, 1, 0};

V g_heff_2esyntax_2efixity_2enubByG(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_g_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_list_2ekeepIf_24s1613584875x1342487326(v_g_241, v_rest_242));
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_g_241, heff_hole()});
    V v_u_245 = (g_heff_2esyntax_2efixity_2enubByG_24dps(v_t_243, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2enubByG(a[0]);
}
Clo g_heff_2esyntax_2efixity_2enubByG_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2enubByG_24dps_entry, 2, 0};

V g_heff_2esyntax_2efixity_2enubByG_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_g_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s1613584875x1342487326(v_g_242, v_rest_243));
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_g_242, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_t_244;
    V t_1 = v_u_246;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efixity_2enubByG_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efixity_2enubByG_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2efixity_2enubByE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2enubByE_entry, 1, 0};

V g_heff_2esyntax_2efixity_2enubByE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_list_2ekeepIf_24s1166238673x178798903(v_p_241, v_rest_242));
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_p_241, heff_hole()});
    V v_u_245 = (g_heff_2esyntax_2efixity_2enubByE_24dps(v_t_243, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2enubByE(a[0]);
}
Clo g_heff_2esyntax_2efixity_2enubByE_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2enubByE_24dps_entry, 2, 0};

V g_heff_2esyntax_2efixity_2enubByE_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s1166238673x178798903(v_p_242, v_rest_243));
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_p_242, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_t_244;
    V t_1 = v_u_246;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efixity_2enubByE_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efixity_2enubByE_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2efixity_2eappendF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2eappendF_entry, 2, 0};

V g_heff_2esyntax_2efixity_2eappendF(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_245 = ({ V a_0 = v_xs_243; V a_1 = v_ys_241; V a_2 = v_cell_244; V r_ = (g_heff_2esyntax_2efixity_2eappendF_24dps(a_0, a_1, a_2)); heff_drop(v_ys_241); r_; });
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2eappendF(a[0], a[1]);
}
Clo g_heff_2esyntax_2efixity_2eappendF_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2eappendF_24dps_entry, 3, 0};

V g_heff_2esyntax_2efixity_2eappendF_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_241));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_u_246;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efixity_2eappendF_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2efixity_2eappendF_24dps(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}

HeffT2 g_heff_2esyntax_2efixity_2efindG_24cpr(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_g_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_g_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_g_242)}});
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_rest_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2efixity_2egroupOrName_24cpr_str0, 0, "");
V g_heff_2esyntax_2efixity_2egroupOrName_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2efixity_2egroupOrName_24cpr(V v_f_240, V v_op_241) {
top: ;
  HeffT2 v_t_243 = ({ V b_0 = heff_clo_n(g_heff_2esyntax_2efixity_2egroupOrName_24cpr_lam0, 1, 1, (V[]){heff_dup(v_op_241)}); V b_1 = heff_get_n(v_f_240, 0, 2); HeffT2 r_ = (g_heff_2esyntax_2efixity_2efindG_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_op_241);
      V v_g_246 = v_field_245;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_g_246}});
    } else {
      heff_drop(v_field_245);
      if ((((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_op_241, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_op_241, MK_INT(0LL), 2)) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_op_241, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_op_241, MK_INT(0LL), 2)) <= ((int64_t)90ULL))) || (heff_unbox_word(heff_strByteAt_lent(v_op_241, MK_INT(0LL), 2)) == ((int64_t)95ULL))))) {
        V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_op_241), NTAG(TAG_Nil)});
        V v_t_248 = heff_rec_n(5, shape_id__assoc__ops__loosest__at, (V[]){v_op_241, NTAG(TAG_AssocNone), v_t_247, NTAG(TAG_False), ((V)&g_heff_2esyntax_2efixity_2egroupOrName_24cpr_str0)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_248}});
      } else {
        heff_drop(v_op_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
V g_heff_2esyntax_2efixity_2egroupOrName_24cpr_lam0(V self, V *args) {
  V v_g_242 = args[0];
  V v_op_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_op_241; V b_1 = heff_get_n(v_g_242, 2, 5); V r_ = (g_list_2eany_24s1006624359x760861690(a_0, b_1)); heff_drop(v_op_241); heff_drop(b_1); r_; });
}

HeffT2 g_heff_2esyntax_2efixity_2efindG_24s1761050079x731378582_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_g_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_g_242, 0)), heff_dup(v_lit_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_g_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_rest_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2esyntax_2efixity_2elosers_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2elosers_entry, 2, 0};

V g_heff_2esyntax_2efixity_2elosers(V v_f_240, V v_head_241) {
top: ;
  V v_above_242 = heff_take_field(v_f_240, 1);
  V v_groups_243 = heff_get_n(v_f_240, 0, 2);
  V v_t_244 = (g_list_2emap_24f719546030x1732151491(v_head_241, v_above_242));
  HeffT2 v_t_245 = (g_heff_2esyntax_2efixity_2efindG_24s1761050079x731378582_24cpr(v_head_241, v_groups_243));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_t_2410;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_g_248 = v_field_247;
      V v_t_249 = heff_get_n(v_g_248, 3, 5);
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_groups_243);
        heff_drop(v_t_249);
        v_t_2410 = NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_249);
        v_t_2410 = (g_list_2emap_24f189927396x2059034600(v_groups_243));
      }
    } else {
      heff_drop(v_field_247);
      v_t_2410 = (g_list_2emap_24f189927396x2059034600(v_groups_243));
    }
    HEFF_LAST return g_heff_2esyntax_2efixity_2eappendF(v_t_244, v_t_2410);
  }
}
V g_heff_2esyntax_2efixity_2elosers_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efixity_2elosers(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2efixity_2etighterGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2etighterGo_entry, 4, 0};

V g_heff_2esyntax_2efixity_2etighterGo(V v_f_240, V v_to_241, V v_x3_242, V v_seen_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_243);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_head_244 = heff_field(v_x3_242, 0);
    V v_tail_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = (g_list_2eany_24s1006624359x760861690(v_head_244, v_seen_243));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_head_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_f_240;
      V t_1 = v_to_241;
      V t_2 = v_tail_245;
      V t_3 = v_seen_243;
      v_f_240 = t_0;
      v_to_241 = t_1;
      v_x3_242 = t_2;
      v_seen_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_246);
      V v_xs_247 = (g_heff_2esyntax_2efixity_2elosers(heff_dup(v_f_240), v_head_244));
      V v_t_248 = ({ V a_0 = v_to_241; V a_1 = v_xs_247; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_247); r_; });
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_seen_243);
        heff_drop(v_head_244);
        heff_drop(v_tail_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_248);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_248);
        V v_t_249 = (g_heff_2esyntax_2efixity_2elosers(heff_dup(v_f_240), v_head_244));
        V v_t_2410 = (g_heff_2esyntax_2efixity_2eappendF(v_tail_245, v_t_249));
        V t_0 = v_f_240;
        V t_1 = v_to_241;
        V t_2 = v_t_2410;
        V t_3 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_head_244, v_seen_243});
        v_f_240 = t_0;
        v_to_241 = t_1;
        v_x3_242 = t_2;
        v_seen_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efixity_2etighterGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2efixity_2etighterGo(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2efixity_2erelate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2erelate_entry, 3, 0};

V g_heff_2esyntax_2efixity_2erelate(V v_f_240, V v_op_241, V v_op_27_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2efixity_2egroupOrName_24cpr(heff_dup(v_f_240), heff_dup(v_op_241)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_op_241);
      V v_g_246 = v_field_245;
      V v_id_247 = heff_take_field(v_g_246, 0);
      V v_assoc_248 = heff_get_n(v_g_246, 1, 5);
      HeffT2 v_t_249 = (g_heff_2esyntax_2efixity_2egroupOrName_24cpr(heff_dup(v_f_240), heff_dup(v_op_27_242)));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          heff_drop(v_op_27_242);
          V v_g_27_2412 = v_field_2411;
          if (heff_strEq_c(heff_dup(v_id_247), heff_dup(heff_rfield(v_g_27_2412, 0)))) {
            heff_drop(v_f_240);
            heff_drop(v_id_247);
            heff_drop_rec(v_g_27_2412, 5);
            return heff_tag_n(TAG_Same, 1, (V[]){v_assoc_248});
          } else {
            heff_drop(v_assoc_248);
            V v_from_2413 = heff_dup(v_id_247);
            V v_to_2414 = heff_dup(heff_rfield(v_g_27_2412, 0));
            V v_xs_2415 = (g_heff_2esyntax_2efixity_2elosers(heff_dup(v_f_240), v_from_2413));
            V v_t_2416 = ({ V a_0 = v_to_2414; V a_1 = v_xs_2415; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_2415); r_; });
            if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
              heff_drop(v_f_240);
              heff_drop(v_id_247);
              heff_drop_rec(v_g_27_2412, 5);
              heff_drop(v_from_2413);
              heff_drop(v_to_2414);
              heff_drop(v_t_2416);
              return NTAG(TAG_Tighter);
            } else {
              heff_drop(v_t_2416);
              V v_ys_2417 = (g_heff_2esyntax_2efixity_2elosers(heff_dup(v_f_240), v_from_2413));
              V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_from_2413, NTAG(TAG_Nil)});
              V v_t_2419 = ({ V a_0 = v_f_240; V a_1 = v_to_2414; V a_2 = v_ys_2417; V a_3 = v_t_2418; V r_ = (g_heff_2esyntax_2efixity_2etighterGo(a_0, a_1, a_2, a_3)); heff_drop(v_to_2414); r_; });
              if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
                heff_drop(v_f_240);
                heff_drop(v_id_247);
                heff_drop_rec(v_g_27_2412, 5);
                heff_drop(v_t_2419);
                return NTAG(TAG_Tighter);
              } else {
                heff_drop(v_t_2419);
                V v_from_2420 = heff_get_n(v_g_27_2412, 0, 5);
                V v_to_2421 = v_id_247;
                V v_xs_2422 = (g_heff_2esyntax_2efixity_2elosers(heff_dup(v_f_240), v_from_2420));
                V v_t_2423 = ({ V a_0 = v_to_2421; V a_1 = v_xs_2422; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_2422); r_; });
                if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
                  heff_drop(v_f_240);
                  heff_drop(v_from_2420);
                  heff_drop(v_to_2421);
                  heff_drop(v_t_2423);
                  return NTAG(TAG_Looser);
                } else {
                  heff_drop(v_t_2423);
                  V v_ys_2424 = (g_heff_2esyntax_2efixity_2elosers(heff_dup(v_f_240), v_from_2420));
                  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_from_2420, NTAG(TAG_Nil)});
                  V v_t_2426 = ({ V a_0 = v_f_240; V a_1 = v_to_2421; V a_2 = v_ys_2424; V a_3 = v_t_2425; V r_ = (g_heff_2esyntax_2efixity_2etighterGo(a_0, a_1, a_2, a_3)); heff_drop(v_f_240); heff_drop(v_to_2421); r_; });
                  if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
                    heff_drop(v_t_2426);
                    return NTAG(TAG_Looser);
                  } else {
                    heff_drop(v_t_2426);
                    return NTAG(TAG_Unrelated);
                  }
                }
              }
            }
          }
        } else {
          heff_drop(v_f_240);
          heff_drop(v_id_247);
          heff_drop(v_assoc_248);
          heff_drop(v_field_2411);
          return heff_tag_n(TAG_Undeclared, 1, (V[]){v_op_27_242});
        }
      }
    } else {
      heff_drop(v_f_240);
      heff_drop(v_op_27_242);
      heff_drop(v_field_245);
      return heff_tag_n(TAG_Undeclared, 1, (V[]){v_op_241});
    }
  }
}
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2erelate(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str0, 2, "->");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str1, 1, "@");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str2, 1, ":");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str3, 1, "=");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str4, 1, "|");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str5, 2, "<-");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str6, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str7, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str8, 2, "=>");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str9, 1, ".");
HEFF_TAG_LIT(g_heff_2esyntax_2efixity_2ereserved_lit10, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efixity_2ereserved_str9), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2esyntax_2efixity_2ereserved_lit11, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efixity_2ereserved_str8), ((V)&g_heff_2esyntax_2efixity_2ereserved_lit10));
HEFF_TAG_LIT(g_heff_2esyntax_2efixity_2ereserved_lit12, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efixity_2ereserved_str7), ((V)&g_heff_2esyntax_2efixity_2ereserved_lit11));
HEFF_TAG_LIT(g_heff_2esyntax_2efixity_2ereserved_lit13, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efixity_2ereserved_str6), ((V)&g_heff_2esyntax_2efixity_2ereserved_lit12));
HEFF_TAG_LIT(g_heff_2esyntax_2efixity_2ereserved_lit14, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efixity_2ereserved_str5), ((V)&g_heff_2esyntax_2efixity_2ereserved_lit13));
HEFF_TAG_LIT(g_heff_2esyntax_2efixity_2ereserved_lit15, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efixity_2ereserved_str4), ((V)&g_heff_2esyntax_2efixity_2ereserved_lit14));
HEFF_TAG_LIT(g_heff_2esyntax_2efixity_2ereserved_lit16, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efixity_2ereserved_str3), ((V)&g_heff_2esyntax_2efixity_2ereserved_lit15));
HEFF_TAG_LIT(g_heff_2esyntax_2efixity_2ereserved_lit17, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efixity_2ereserved_str2), ((V)&g_heff_2esyntax_2efixity_2ereserved_lit16));
HEFF_TAG_LIT(g_heff_2esyntax_2efixity_2ereserved_lit18, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efixity_2ereserved_str1), ((V)&g_heff_2esyntax_2efixity_2ereserved_lit17));
HEFF_TAG_LIT(g_heff_2esyntax_2efixity_2ereserved_lit19, TAG_Cons, 2, ((V)&g_heff_2esyntax_2efixity_2ereserved_str0), ((V)&g_heff_2esyntax_2efixity_2ereserved_lit18));

static V g_heff_2esyntax_2efixity_2ereserved_val;
static HEFF_ONCE g_heff_2esyntax_2efixity_2ereserved_st;
static V g_heff_2esyntax_2efixity_2ereserved_init(void) {
  return ((V)&g_heff_2esyntax_2efixity_2ereserved_lit19);
}
V g_heff_2esyntax_2efixity_2ereserved_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efixity_2ereserved_st)) return g_heff_2esyntax_2efixity_2ereserved_val;
  return heff_global(&g_heff_2esyntax_2efixity_2ereserved_val, &g_heff_2esyntax_2efixity_2ereserved_st, g_heff_2esyntax_2efixity_2ereserved_init);
}