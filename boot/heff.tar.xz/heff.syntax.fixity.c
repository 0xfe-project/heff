// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Looser 37443
#define TAG_Same 22203
#define TAG_Tighter 5275
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define LBL_above 293969847
#define LBL_assoc 294479919
#define LBL_groups 709681407
#define LBL_id 10114
#define LBL_loosest 581880769
#define LBL_ops 319788
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2eappendF_24dps(V, V, V);
V g_heff_2esyntax_2efixity_2eappendF_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_24dps_clo;
V g_heff_2esyntax_2efixity_2ebothLoosest(V, V, V);
V g_heff_2esyntax_2efixity_2ebothLoosest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2ebothLoosest_clo;
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
V g_heff_2esyntax_2efixity_2efindG(V, V);
V g_heff_2esyntax_2efixity_2efindG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2efindG_clo;
V g_heff_2esyntax_2efixity_2efindG_24s1415082471x15891933(V, V);
V g_heff_2esyntax_2efixity_2efindG_24s1415082471x15891933_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2efindG_24s1415082471x15891933_clo;
V g_heff_2esyntax_2efixity_2elosers(V, V);
V g_heff_2esyntax_2efixity_2elosers_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2elosers_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByE_24dps(V, V);
V g_heff_2esyntax_2efixity_2enubByE_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_24dps_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2efixity_2enubByG_24dps(V, V);
V g_heff_2esyntax_2efixity_2enubByG_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_24dps_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_heff_2esyntax_2efixity_2etighterGo(V, V, V, V);
V g_heff_2esyntax_2efixity_2etighterGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2etighterGo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter_24s1596967535x1519602627(V, V);
V g_list_2efilter_24s1596967535x1519602627_entry(V self, V *a);
extern Clo g_list_2efilter_24s1596967535x1519602627_clo;
V g_list_2efilter_24s1828661527x837139534(V, V);
V g_list_2efilter_24s1828661527x837139534_entry(V self, V *a);
extern Clo g_list_2efilter_24s1828661527x837139534_clo;
V g_list_2emap_24f1881659548x1623692567(V, V);
V g_list_2emap_24f1881659548x1623692567_entry(V self, V *a);
extern Clo g_list_2emap_24f1881659548x1623692567_clo;
V g_list_2emap_24f88106788x1680212182(V);
V g_list_2emap_24f88106788x1680212182_entry(V self, V *a);
extern Clo g_list_2emap_24f88106788x1680212182_clo;

static V g_heff_2esyntax_2efixity_2eemptyFixities_val;
static HEFF_ONCE g_heff_2esyntax_2efixity_2eemptyFixities_st;
static V g_heff_2esyntax_2efixity_2eemptyFixities_init(void) {
  return heff_rec_n(2, shape_groups__above, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efixity_2eemptyFixities_st)) return g_heff_2esyntax_2efixity_2eemptyFixities_val;
  return heff_global(&g_heff_2esyntax_2efixity_2eemptyFixities_val, &g_heff_2esyntax_2efixity_2eemptyFixities_st, g_heff_2esyntax_2efixity_2eemptyFixities_init);
}
Clo g_heff_2esyntax_2efixity_2enubByG_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2enubByG_entry, 1, 0};

V g_heff_2esyntax_2efixity_2enubByG(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_g_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_g_241), heff_hole()});
    V v_t_244 = (g_list_2efilter_24s1828661527x837139534(v_g_241, v_rest_242));
    V v_u_245 = (g_heff_2esyntax_2efixity_2enubByG_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2enubByG(a[0]);
}
Clo g_heff_2esyntax_2efixity_2enubByG_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2enubByG_24dps_entry, 2, 0};

V g_heff_2esyntax_2efixity_2enubByG_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_g_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_g_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2efilter_24s1828661527x837139534(v_g_242, v_rest_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efixity_2enubByG_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2enubByG_24dps(a[0], a[1]);
}
Clo g_heff_2esyntax_2efixity_2enubByE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2enubByE_entry, 1, 0};

V g_heff_2esyntax_2efixity_2enubByE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_p_241), heff_hole()});
    V v_t_244 = (g_list_2efilter_24s1596967535x1519602627(v_p_241, v_rest_242));
    V v_u_245 = (g_heff_2esyntax_2efixity_2enubByE_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2enubByE(a[0]);
}
Clo g_heff_2esyntax_2efixity_2enubByE_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2enubByE_24dps_entry, 2, 0};

V g_heff_2esyntax_2efixity_2enubByE_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_p_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2efilter_24s1596967535x1519602627(v_p_242, v_rest_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efixity_2enubByE_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2enubByE_24dps(a[0], a[1]);
}
Clo g_heff_2esyntax_2efixity_2eappendF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2eappendF_entry, 2, 0};

V g_heff_2esyntax_2efixity_2eappendF(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2esyntax_2efixity_2eappendF_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2eappendF(a[0], a[1]);
}
Clo g_heff_2esyntax_2efixity_2eappendF_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2eappendF_24dps_entry, 3, 0};

V g_heff_2esyntax_2efixity_2eappendF_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efixity_2eappendF_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2eappendF_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2efixity_2efindG_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2efindG_entry, 2, 0};

V g_heff_2esyntax_2efixity_2efindG(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_g_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_g_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_g_242)});
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_rest_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efixity_2efindG_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efixity_2efindG(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2efixity_2ebothLoosest_lam0(V self, V *args);
V g_heff_2esyntax_2efixity_2ebothLoosest_lam1(V self, V *args);
Clo g_heff_2esyntax_2efixity_2ebothLoosest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2ebothLoosest_entry, 3, 0};

V g_heff_2esyntax_2efixity_2ebothLoosest(V v_f_240, V v_op_241, V v_op_27_242) {
top: ;
  V v_x1_245 = (g_heff_2esyntax_2efixity_2efindG(heff_clo_n(g_heff_2esyntax_2efixity_2ebothLoosest_lam0, 1, 1, (V[]){v_op_241}), heff_rfield(v_f_240, 0)));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nothing: {
    heff_drop_rec(v_f_240, 2);
    heff_drop(v_op_27_242);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_g_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    V v_t_247 = heff_get_n(v_g_246, 3, 5);
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_x1_2410 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2efixity_2ebothLoosest_lam1, 1, 1, (V[]){v_op_27_242}); V b_1 = heff_get_n(v_f_240, 0, 2); V r_ = (g_heff_2esyntax_2efixity_2efindG(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_x1_2410)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_g_2411 = heff_field(v_x1_2410, 0);
        heff_take_n(v_x1_2410, 1ULL, 1);
        return heff_get_n(v_g_2411, 3, 5);
      }
      default: return heff_nomatch(v_x1_2410);
      }
    } else {
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_op_27_242);
      heff_drop(v_t_247);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2efixity_2ebothLoosest_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2ebothLoosest(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2efixity_2ebothLoosest_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_op_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_op_241}));
  return ({ V a_0 = v_t_244; V b_1 = heff_get_n(v_g_243, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2efixity_2ebothLoosest_lam1(V self, V *args) {
  V v_g_248 = args[0];
  V v_op_27_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_op_27_242}));
  return ({ V a_0 = v_t_249; V b_1 = heff_get_n(v_g_248, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
Clo g_heff_2esyntax_2efixity_2efindG_24s1415082471x15891933_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2efindG_24s1415082471x15891933_entry, 2, 0};

V g_heff_2esyntax_2efixity_2efindG_24s1415082471x15891933(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_g_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_g_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_g_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_rest_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efixity_2efindG_24s1415082471x15891933_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efixity_2efindG_24s1415082471x15891933(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2efixity_2elosers_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2elosers_entry, 2, 0};

V g_heff_2esyntax_2efixity_2elosers(V v_f_240, V v_head_241) {
top: ;
  V v_t_242 = (g_list_2emap_24f1881659548x1623692567(heff_dup(v_head_241), heff_take_field(v_f_240, 1)));
  V v_x1_243 = (g_heff_2esyntax_2efixity_2efindG_24s1415082471x15891933(v_head_241, heff_rfield(v_f_240, 0)));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nothing: {
    v_t_246 = (g_list_2emap_24f88106788x1680212182(heff_get_n(v_f_240, 0, 2)));
    break;
  }
  case TAG_Just: {
    V v_g_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 1);
    V v_t_245 = heff_get_n(v_g_244, 3, 5);
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_t_245);
      v_t_246 = NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_245);
      v_t_246 = (g_list_2emap_24f88106788x1680212182(heff_get_n(v_f_240, 0, 2)));
    }
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  HEFF_LAST return g_heff_2esyntax_2efixity_2eappendF(v_t_242, v_t_246);
}
V g_heff_2esyntax_2efixity_2elosers_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2elosers(a[0], a[1]);
}
Clo g_heff_2esyntax_2efixity_2etighterGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2etighterGo_entry, 4, 0};

V g_heff_2esyntax_2efixity_2etighterGo(V v_f_240, V v_to_241, V v_x3_242, V v_seen_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_to_241);
    heff_drop(v_seen_243);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_head_244 = heff_field(v_x3_242, 0);
    V v_tail_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_head_244)}));
    V v_t_247 = (g_list_2eany(v_t_246, v_seen_243));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_head_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_f_240;
      V t_1 = v_to_241;
      V t_2 = v_tail_245;
      V t_3 = v_seen_243;
      v_f_240 = t_0;
      v_to_241 = t_1;
      v_x3_242 = t_2;
      v_seen_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_247);
      V v_xs_248 = (g_heff_2esyntax_2efixity_2elosers(heff_dup(v_f_240), heff_dup(v_head_244)));
      V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_to_241)}));
      V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_xs_248; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_248); r_; });
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_f_240);
        heff_drop(v_to_241);
        heff_drop(v_seen_243);
        heff_drop(v_head_244);
        heff_drop(v_tail_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2410);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2410);
        V v_t_2411 = (g_heff_2esyntax_2efixity_2elosers(heff_dup(v_f_240), heff_dup(v_head_244)));
        V v_t_2412 = (g_heff_2esyntax_2efixity_2eappendF(v_tail_245, v_t_2411));
        V t_0 = v_f_240;
        V t_1 = v_to_241;
        V t_2 = v_t_2412;
        V t_3 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_head_244, v_seen_243});
        v_f_240 = t_0;
        v_to_241 = t_1;
        v_x3_242 = t_2;
        v_seen_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efixity_2etighterGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2etighterGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2efixity_2erelate_lam0(V self, V *args);
V g_heff_2esyntax_2efixity_2erelate_lam1(V self, V *args);
Clo g_heff_2esyntax_2efixity_2erelate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efixity_2erelate_entry, 3, 0};

V g_heff_2esyntax_2efixity_2erelate(V v_f_240, V v_op_241, V v_op_27_242) {
top: ;
  V v_t_245 = (g_heff_2esyntax_2efixity_2efindG(heff_clo_n(g_heff_2esyntax_2efixity_2erelate_lam0, 1, 1, (V[]){heff_dup(v_op_241)}), heff_rfield(v_f_240, 0)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop_rec(v_f_240, 2);
    heff_drop(v_op_27_242);
    return heff_tag_n(TAG_Undeclared, 1, (V[]){v_op_241});
  }
  case TAG_Just: {
    V v_g_246 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    heff_drop(v_op_241);
    V v_t_249 = (g_heff_2esyntax_2efixity_2efindG(heff_clo_n(g_heff_2esyntax_2efixity_2erelate_lam1, 1, 1, (V[]){heff_dup(v_op_27_242)}), heff_rfield(v_f_240, 0)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop_rec(v_f_240, 2);
      heff_drop_rec(v_g_246, 5);
      return heff_tag_at_n(v_ru_24t_245_24Just, TAG_Undeclared, 1, (V[]){v_op_27_242});
    }
    case TAG_Just: {
      V v_g_27_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      heff_drop(v_op_27_242);
      if (heff_strEq_c(heff_dup(heff_rfield(v_g_246, 0)), heff_dup(heff_rfield(v_g_27_2410, 0)))) {
        heff_drop_rec(v_f_240, 2);
        heff_drop_rec(v_g_27_2410, 5);
        return heff_tag_at_n(v_ru_24t_245_24Just, TAG_Same, 1, (V[]){heff_get_n(v_g_246, 1, 5)});
      } else {
        heff_drop_cell(v_ru_24t_245_24Just, 1);
        V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_g_246, 0)), NTAG(TAG_Nil)});
        V v_t_2413 = (g_heff_2esyntax_2efixity_2etighterGo(heff_dup(v_f_240), heff_dup(heff_rfield(v_g_27_2410, 0)), v_t_2412, NTAG(TAG_Nil)));
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop_rec(v_f_240, 2);
          heff_drop_rec(v_g_246, 5);
          heff_drop_rec(v_g_27_2410, 5);
          heff_drop(v_t_2413);
          return NTAG(TAG_Tighter);
        } else {
          heff_drop(v_t_2413);
          V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_g_27_2410, 0, 5), NTAG(TAG_Nil)});
          V v_t_2415 = (g_heff_2esyntax_2efixity_2etighterGo(v_f_240, heff_get_n(v_g_246, 0, 5), v_t_2414, NTAG(TAG_Nil)));
          if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
            heff_drop(v_t_2415);
            return NTAG(TAG_Looser);
          } else {
            heff_drop(v_t_2415);
            return NTAG(TAG_Unrelated);
          }
        }
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efixity_2erelate(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2efixity_2erelate_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_op_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_op_241}));
  return ({ V a_0 = v_t_244; V b_1 = heff_get_n(v_g_243, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2efixity_2erelate_lam1(V self, V *args) {
  V v_g_247 = args[0];
  V v_op_27_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_op_27_242}));
  return ({ V a_0 = v_t_248; V b_1 = heff_get_n(v_g_247, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str0, 1, ".");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str1, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str2, 2, "=>");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str3, 2, "<-");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str4, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str5, 1, "=");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str6, 1, "|");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str7, 1, "~");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str8, 1, ":");
HEFF_LIT(g_heff_2esyntax_2efixity_2ereserved_str9, 2, "->");

static V g_heff_2esyntax_2efixity_2ereserved_val;
static HEFF_ONCE g_heff_2esyntax_2efixity_2ereserved_st;
static V g_heff_2esyntax_2efixity_2ereserved_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efixity_2ereserved_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efixity_2ereserved_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efixity_2ereserved_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efixity_2ereserved_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efixity_2ereserved_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efixity_2ereserved_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efixity_2ereserved_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efixity_2ereserved_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efixity_2ereserved_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efixity_2ereserved_str9), v_t_244});
}
V g_heff_2esyntax_2efixity_2ereserved_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efixity_2ereserved_st)) return g_heff_2esyntax_2efixity_2ereserved_val;
  return heff_global(&g_heff_2esyntax_2efixity_2ereserved_val, &g_heff_2esyntax_2efixity_2ereserved_st, g_heff_2esyntax_2efixity_2ereserved_init);
}