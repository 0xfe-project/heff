// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SMetaApp 2372
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9005
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_msp 317956
#define LBL_mty 317996
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_selfKey 62480824
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eunify_2eanyL(V, V);
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eanyL_clo;
V g_heff_2eelab_2eunify_2eappendL(V, V);
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_clo;
V g_heff_2eelab_2eunify_2ecatMaybes(V);
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_clo;
V g_heff_2eelab_2eunify_2econcatMapL(V, V);
V g_heff_2eelab_2eunify_2econcatMapL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2econcatMapL_clo;
V g_heff_2eelab_2eunify_2edistinct(V);
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2edistinct_clo;
V g_heff_2eelab_2eunify_2eeqPatArgs(V, V);
V g_heff_2eelab_2eunify_2eeqPatArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eeqPatArgs_clo;
V g_heff_2eelab_2eunify_2eiterateLift(V, V);
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eiterateLift_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo;
V g_heff_2eelab_2eunify_2emetasSpF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasSpF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasSpF_clo;
V g_heff_2eelab_2eunify_2emetasTermF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasTermF_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2epatSpine(V, V, V);
V g_heff_2eelab_2eunify_2epatSpine_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatSpine_clo;
HeffT2 g_heff_2eelab_2eunify_2epatSpine_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2epatVarsOf(V);
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatVarsOf_clo;
V g_heff_2eelab_2eunify_2epoisonMany(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_clo;
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_clo;
V g_heff_2eelab_2eunify_2esubstTyFields(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTyFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTyFields_clo;
V g_heff_2eelab_2eunify_2esubstTypeF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTypeF_clo;
V g_heff_2eelab_2eunify_2etraverseU_24s445996322x417629555(V, V);
V g_heff_2eelab_2eunify_2etraverseU_24s445996322x417629555_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraverseU_24s445996322x417629555_clo;
V g_heff_2eelab_2eunify_2euAlg(V, V);
V g_heff_2eelab_2eunify_2euAlg_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euAlg_clo;
V g_heff_2eelab_2eunify_2ezipL(V, V);
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_clo;
V g_heff_2eelab_2eunify_2ezipL_24dps(V, V, V);
V g_heff_2eelab_2eunify_2ezipL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_24dps_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s895450532x1092988905(V, V);
V g_list_2efoldl_24s895450532x1092988905_entry(V self, V *a);
extern Clo g_list_2efoldl_24s895450532x1092988905_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
HeffT2 g_map_2elookup_24s1338854231x236594845_24cpr(V, V);
HeffT2 g_map_2elookup_24s567992785x1569911877_24cpr(V, V);
Clo g_heff_2eelab_2eunify_2eeqPatArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eeqPatArgs_entry, 2, 0};

V g_heff_2eelab_2eunify_2eeqPatArgs(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      V v_t_2411;
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_l_248 = heff_field(v_a_244, 0);
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          V v_l_27_249 = heff_field(v_b_246, 0);
          v_t_2411 = heff_intEq(heff_dup(v_l_248), heff_dup(v_l_27_249));
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_2411);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eeqPatArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eunify_2eeqPatArgs(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2epatSpine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatSpine_entry, 3, 0};

V g_heff_2eelab_2eunify_2epatSpine(V v_selfKey_240, V v_mc_241, V v_x3_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2eelab_2eunify_2epatSpine_24cpr(v_selfKey_240, v_mc_241, v_x3_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2eelab_2eunify_2epatSpine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eunify_2epatSpine(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezipL_entry, 2, 0};

V g_heff_2eelab_2eunify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2eelab_2eunify_2ezipL_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ezipL(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2ezipL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezipL_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezipL_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ezipL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ezipL_24dps(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eunify_2emetasTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTermF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2emetasTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasTermF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasTermF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_v0_244) {
top: ;
  if (heff_intLe_c(heff_dup(v_depth_242), MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_v0_244);
    return NTAG(TAG_Nil);
  } else {
    V v_it_246 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, v_v0_244));
    switch (heff_tag_of(v_it_246)) {
    case TAG_VNeu: {
      V v_it1_247 = heff_field(v_it_246, 0);
      V v_sp_248 = heff_field(v_it_246, 1);
      heff_take_n(v_it_246, 3ULL, 5);
      switch (heff_tag_of(v_it1_247)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      case TAG_HMeta: {
        V v_m_2414 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 1);
        V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, v_sp_248}));
        return heff_tag_n(TAG_Cons, 2, (V[]){v_m_2414, v_t_2415});
      }
      case TAG_HError: {
        return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      default: return heff_nomatch(v_it1_247);
      }
    }
    case TAG_VCode: {
      V v_t_2416 = heff_field(v_it_246, 0);
      heff_take_n(v_it_246, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 1, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_t_2416});
    }
    case TAG_VLam: {
      V v_d_2417 = heff_field(v_it_246, 0);
      V v_c_2418 = heff_field(v_it_246, 1);
      heff_take_n(v_it_246, 3ULL, 2);
      V v_x1_2439;
      switch (heff_tag_of(v_c_2418)) {
      case TAG_MkClo: {
        V v_vs_2420 = heff_field(v_c_2418, 1);
        V v_body_2421 = heff_field(v_c_2418, 2);
        heff_take_n(v_c_2418, 6ULL, 3);
        v_x1_2439 = heff_tr(heff_call(v_body_2421, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2420, heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam0, 1, 2, (V[]){v_d_2417, heff_dup(v_len_243)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2438 = heff_field(v_c_2418, 0);
        heff_take_n(v_c_2418, 1ULL, 1);
        heff_drop(v_d_2417);
        v_x1_2439 = v_body_2438;
        break;
      }
      default: heff_nomatch(v_c_2418);
      }
      V v_t_2443;
      switch (heff_tag_of(v_x1_2439)) {
      case TAG_Nom: {
        V v_x_2440 = heff_field(v_x1_2439, 0);
        heff_take_n(v_x1_2439, 1ULL, 1);
        v_t_2443 = v_x_2440;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2439, 0ULL, 1);
        v_t_2443 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2442 = heff_field(v_x1_2439, 0);
        heff_take_n(v_x1_2439, 1ULL, 1);
        v_t_2443 = v_x_2442;
        break;
      }
      default: heff_nomatch(v_x1_2439);
      }
      return heff_tail(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2443});
    }
    case TAG_VCons: {
      V v_d_2444 = heff_field(v_it_246, 0);
      heff_take_n(v_it_246, 1ULL, 1);
      V v_t_2445 = heff_arrayToList(heff_get_n(v_d_2444, 2, 3));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam2, 1, 3, (V[]){v_r_240, v_depth_242, v_len_243}); V a_1 = v_t_2445; V r_ = (g_heff_2eelab_2eunify_2econcatMapL(a_0, a_1)); heff_drop(v_t_2445); r_; });
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_it_246);
    }
  }
}
V g_heff_2eelab_2eunify_2emetasTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2emetasTermF(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2emetasTermF_lam1(V self, V *args) {
  V v_u_2437 = args[0];
  V v_a_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2437);
  return v_a_2436;
}
V g_heff_2eelab_2eunify_2emetasTermF_lam0(V self, V *args) {
  V v_u_2422 = args[0];
  V v_d_2417 = heff_env(self)[0];
  V v_len_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2422);
  V v_t_2423 = heff_tr(heff_call(v_d_2417, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2424 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2423)));
  V v_a_2436;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2427 = heff_field(v_t_2424, 1);
    heff_take_n(v_t_2424, 2ULL, 4);
    heff_drop(v_t_2423);
    v_a_2436 = v_dom_2427;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2424, 0ULL, 3);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeInt: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeFloat: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeString: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeRune: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_NoRules: {
    v_a_2436 = v_t_2423;
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam1, 1, 1, (V[]){v_a_2436}), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2eunify_2emetasTermF_lam2(V self, V *args) {
  V v_x_2446 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_depth_242 = heff_env(self)[1];
  V v_len_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2450;
  switch (heff_tag_of(v_x_2446)) {
  case TAG_Nom: {
    V v_x_2447 = heff_field(v_x_2446, 0);
    heff_take_n(v_x_2446, 1ULL, 1);
    v_t_2450 = v_x_2447;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x_2446, 0ULL, 1);
    v_t_2450 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2449 = heff_field(v_x_2446, 0);
    heff_take_n(v_x_2446, 1ULL, 1);
    v_t_2450 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_x_2446);
  }
  V f_ = heff_get_n(v_r_240, 0, 3);
  heff_room[0] = heff_intSub(v_depth_242, MK_INT(1LL));
  heff_room[1] = v_len_243;
  heff_room[2] = v_t_2450;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
Clo g_heff_2eelab_2eunify_2emetasSpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasSpF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasSpF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_SpId: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_245 = heff_field(v_x5_244, 0);
    V v_a_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_245)}));
    V v_t_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_246)}));
    return (g_heff_2eelab_2eunify_2eappendL(v_t_247, v_t_248));
  }
  case TAG_SpProj: {
    V v_sp_249 = heff_field(v_x5_244, 0);
    return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, heff_dup(v_sp_249)});
  }
  case TAG_SpSpec: {
    V v_sp_2411 = heff_field(v_x5_244, 0);
    V v_a_2413 = heff_field(v_x5_244, 2);
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_2411)}));
    V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_2413)}));
    return (g_heff_2eelab_2eunify_2eappendL(v_t_2414, v_t_2415));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eunify_2emetasSpF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2eelab_2eunify_2emetasSpF(a[0], a1, a[2], a[3], a4); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2eelab_2eunify_2epoisonMany_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epoisonMany_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epoisonMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epoisonMany_entry, 6, 0};

V g_heff_2eelab_2eunify_2epoisonMany(V v_w_240, V v_ms_241, V v_uf_242, V v_ms_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_248 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_lam0, 1, 1, (V[]){heff_dup(v_ms_243)})})}));
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_248, heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_lam1, 1, 4, (V[]){v_ms_241, v_w_240, v_z_244, v_z_245})));
}
V g_heff_2eelab_2eunify_2epoisonMany_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2eunify_2epoisonMany(a[0], a[1], a2, a3, a[4], a[5]); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2eunify_2epoisonMany_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_ms_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_247 = ({ V a_0 = heff_take_field(v_c_246, 2); V a_1 = v_ms_243; V r_ = (g_list_2efoldl_24s895450532x1092988905(a_0, a_1)); heff_drop(v_ms_243); r_; });
  return ({ V rv_2 = v_ps_247; V rr_ = heff_rec_reuse_nf(v_c_246, 251ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eunify_2epoisonMany_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_Put, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tr(heff_call(v_ms_241, 1, (V[]){v_t_2410}));
  return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2411, v_z_244, v_z_245));
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTypeF_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2esubstTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTypeF_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTypeF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_245}));
    return heff_tag_at_n(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_246});
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_t_243, 0);
    V v_dom_248 = heff_field(v_t_243, 1);
    V v_t3_249 = heff_field(v_t_243, 2);
    V v_implicit_2410 = heff_field(v_t_243, 3);
    V v_dflt_2411 = heff_field(v_t_243, 4);
    V v_ru_24t_243_24SFunction = heff_take_reuse_n(v_t_243, 31ULL, 5);
    switch (heff_tag_of(v_t3_249)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_t3_249, 0);
      V v_b_2413 = heff_field(v_t3_249, 1);
      heff_take_n(v_t3_249, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2413}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2414, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2412, v_t_2415}), v_implicit_2410, v_dflt_2411});
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_t3_249, 0);
      heff_take_n(v_t3_249, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_b_2416}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2417, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2418}), v_implicit_2410, v_dflt_2411});
    }
    default: return heff_nomatch(v_t3_249);
    }
  }
  case TAG_SRecord: {
    V v_level_2419 = heff_field(v_t_243, 0);
    V v_ft_2420 = heff_field(v_t_243, 1);
    V v_ds_2421 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SRecord = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2422 = heff_arrayToList(heff_take_field(v_ft_2420, 2));
    V v_t_2423 = (g_heff_2eelab_2eunify_2esubstTyFields(v_r_240, v_d_242, MK_INT(0LL), v_t_2422));
    V v_t_2424 = ({ V rv_2 = heff_arrayFromList(v_t_2423); V rr_ = heff_rec_reuse_nf(v_ft_2420, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SRecord, TAG_SRecord, 3, (V[]){v_level_2419, v_t_2424, v_ds_2421});
  }
  case TAG_SSum: {
    V v_vs_2425 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_d_242}));
    V v_xs_2427 = heff_take_field(v_vs_2425, 2);
    V v_t_2432 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2427, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTypeF_lam0, 1, 2, (V[]){v_xs_2427, v_f_2426}));
    V v_t_2433 = ({ V rv_2 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_vs_2425, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2433});
  }
  case TAG_SIsTy: {
    V v_a_2434 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_2434}));
    return heff_tag_at_n(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2435});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2esubstTypeF(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam1(V self, V *args) {
  V v_i_2430 = args[0];
  V v_xs_2429 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_arrayIndex(v_xs_2429, v_i_2430);
  V f_ = v_f_2426;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam0(V self, V *args) {
  V v_i_2428 = args[0];
  V v_xs_2427 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2429 = heff_arrayIndex(v_xs_2427, v_i_2428);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2429, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTypeF_lam1, 1, 2, (V[]){v_xs_2429, v_f_2426}));
}
Clo g_heff_2eelab_2eunify_2eiterateLift_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eiterateLift_entry, 2, 0};

V g_heff_2eelab_2eunify_2eiterateLift(V v_i_240, V v_rr_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_i_240), MK_INT(0LL))) {
    heff_drop(v_i_240);
    return v_rr_241;
  } else {
    V v_t_243 = heff_intAdd(heff_dup(heff_rfield(v_rr_241, 0)), MK_INT(1LL));
    V v_t_244 = heff_intAdd(heff_dup(heff_rfield(v_rr_241, 1)), MK_INT(1LL));
    V v_t_245 = (g_map_2einsert_24s1689409319x1710080871(heff_take_field(v_rr_241, 0), heff_take_field(v_rr_241, 1), heff_get_n(v_rr_241, 2, 3)));
    V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
    V t_1 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_243, v_t_244, v_t_245});
    v_i_240 = t_0;
    v_rr_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eiterateLift(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eunify_2elamsU_str0, 1, "x");
Clo g_heff_2eelab_2eunify_2elamsU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2elamsU_entry, 2, 0};

V g_heff_2eelab_2eunify_2elamsU(V v_k_240, V v_body_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    return v_body_241;
  } else {
    V v_t_243 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
    V v_t_244 = heff_tag_n(TAG_SLam, 2, (V[]){v_t_243, heff_tag_n(TAG_MkAbs, 2, (V[]){((V)&g_heff_2eelab_2eunify_2elamsU_str0), v_body_241})});
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = v_t_244;
    v_k_240 = t_0;
    v_body_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2elamsU(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2emsEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emsEv_entry, 1, 0};

V g_heff_2eelab_2eunify_2emsEv(V v_p_240) {
top: ;
  return heff_tag_n(TAG_InL, 1, (V[]){v_p_240});
}
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emsEv(a[0]);
}
Clo g_heff_2eelab_2eunify_2euAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euAlg_entry, 2, 0};

V g_heff_2eelab_2eunify_2euAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_InL: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InL = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_Get: {
      V v_k_243 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_244 = heff_tr(heff_call(v_k_243, 1, (V[]){heff_dup(v_p_241)}));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_t_244}), v_p_241});
    }
    case TAG_Put: {
      V v_c2_245 = heff_field(v_t_242, 0);
      V v_x_246 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24Put = heff_take_reuse_n(v_t_242, 3ULL, 2);
      heff_drop(v_p_241);
      return heff_tag_at_n(v_ru_24t_242_24Put, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_x_246}), v_c2_245});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_InR: {
    V v_q_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InR = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_q_247)) {
    case TAG_Throw: {
      V v_err_248 = heff_field(v_q_247, 0);
      heff_take_n(v_q_247, 1ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Left, 1, (V[]){v_err_248}), v_p_241});
    }
    case TAG_Catch: {
      V v_m_249 = heff_field(v_q_247, 0);
      V v_h_2410 = heff_field(v_q_247, 1);
      V v_ru_24q_247_24Catch = heff_take_reuse_n(v_q_247, 3ULL, 2);
      V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x21_2412 = heff_field(v_x2_2411, 0);
        V v_st_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_Left: {
          V v_e_2414 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24InR, 1);
          heff_drop_cell(v_ru_24q_247_24Catch, 2);
          return heff_tail(v_h_2410, 2, (V[]){v_e_2414, v_st_2413});
        }
        case TAG_Right: {
          V v_x_2415 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop(v_h_2410);
          return heff_tag_at_n(v_ru_24q_247_24Catch, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Right, 1, (V[]){v_x_2415}), v_st_2413});
        }
        default: return heff_nomatch(v_x21_2412);
        }
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_q_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2euAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euAlg(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam0, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam2, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam8, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam14(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam14, 2, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam15(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam15, 2, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam17(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam17, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam18(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_entry, 7, 0};

V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198(V v_g_240, V v_m_241, V v_pr_242, V v_m_27_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam0_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam1, 1, 7, (V[]){v_hd_245, v_sp_244, v_k_246, v_pr_242, v_g_240, v_m_241, v_m_27_243})});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam2(V self, V *args) {
  V v_c_2411 = args[0];
  return heff_get_n(v_c_2411, 7, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam4(V self, V *args) {
  V v_a_2428 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2428)) {
  case TAG_PVar: {
    V v_l_2429 = heff_field(v_a_2428, 0);
    heff_take_n(v_a_2428, 1ULL, 1);
    HeffT2 v_t_2430 = ({ V a_0 = v_l_2429; V b_1 = heff_get_n(v_pr_242, 2, 3); HeffT2 r_ = (g_map_2elookup_24s1338854231x236594845_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_2432 = v_t_2430.f[1];
      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2431 == ((int64_t)0ULL)) ? ({ V v_x_2434 = heff_dup(v_field_2432); int c_ = 0; heff_drop(v_x_2434); c_; }) : 1));
      heff_drop(v_field_2432);
      return v_ret_24bool;
    }
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_a_2428);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam6(V self, V *args) {
  V v_i_2438 = args[0];
  V v_a_2439 = args[1];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2439)) {
  case TAG_PVar: {
    V v_l_2440 = heff_field(v_a_2439, 0);
    V v_ru_24a_2439_24PVar = heff_take_reuse_n(v_a_2439, 1ULL, 1);
    HeffT2 v_t_2441 = ({ V a_0 = v_l_2440; V b_1 = heff_get_n(v_pr_242, 2, 3); HeffT2 r_ = (g_map_2elookup_24s1338854231x236594845_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_2443 = v_t_2441.f[1];
      int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
      if ((v_tag_2442 == ((int64_t)0ULL))) {
        V v_x_2445 = v_field_2443;
        heff_drop(v_x_2445);
        return heff_tag_at_n(v_ru_24a_2439_24PVar, TAG_Just, 1, (V[]){v_i_2438});
      } else {
        heff_drop(v_i_2438);
        heff_drop_cell(v_ru_24a_2439_24PVar, 1);
        heff_drop(v_field_2443);
        return NTAG(TAG_Nothing);
      }
    }
  }
  case TAG_PSelf: {
    heff_drop(v_i_2438);
    heff_drop_rec(v_pr_242, 3);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_a_2439);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam7(V self, V *args) {
  V v_x_2448 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_v_2449 = ({ V a_0 = v_x_2448; V a_1 = v_sp_244; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_244); r_; });
  return (g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(v_g_240, v_m_241, v_pr_242, v_v_2449, v_hd_245, v_k_246));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_args_2427 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_m_27_243 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_sp_244 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2437 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2427));
  V v_t_2446 = (g_heff_2eelab_2eunify_2emapWithIndexL(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam6, 2, 1, (V[]){heff_dup(v_pr_242)}), v_args_2427));
  V v_t_2447 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2446));
  return (g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890(heff_dup(v_g_240), heff_dup(v_m_241), v_m_27_243, v_x_2436, v_t_2437, v_t_2447, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam7, 1, 6, (V[]){v_sp_244, v_g_240, v_m_241, v_pr_242, v_hd_245, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam8(V self, V *args) {
  V v_c_2451 = args[0];
  return heff_get_n(v_c_2451, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_k_2450 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2455 = ({ V a_0 = v_m_27_243; V a_1 = v_x_2454; HeffT2 r_ = (g_map_2elookup_24s567992785x1569911877_24cpr(a_0, a_1)); heff_drop(v_x_2454); r_; });
  {
    V v_field_2457 = v_t_2455.f[1];
    int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
    if ((v_tag_2456 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_245, 3);
      V v_e_2459 = v_field_2457;
      V f_ = v_k_2450;
      args[0] = v_e_2459;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2457);
      V v_t_2460 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2461}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2462;
      heff_room[1] = v_k_2450;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam13(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k_2473 = args[1];
  V v_pr_242 = heff_env(self)[0];
  V v_l_27_2471 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2472);
  V v_t_2474 = heff_intSub(heff_get_n(v_pr_242, 1, 3), v_l_27_2471);
  V f_ = v_k_2473;
  args[0] = heff_intSub(v_t_2474, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam14(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k2_2476 = args[1];
  V v_t_2477 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tr(heff_call(heff_take_field(v_hd_2475, 2), 1, (V[]){v_t_2478}));
  V f_ = heff_get_n(v_hd_2475, 1, 3);
  args[0] = v_t_2479;
  args[1] = v_k2_2476;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam15(V self, V *args) {
  V v_hd_2480 = args[0];
  V v_k2_2481 = args[1];
  V v_t_2482 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tr(heff_call(heff_take_field(v_hd_2480, 2), 1, (V[]){v_t_2483}));
  V f_ = heff_get_n(v_hd_2480, 1, 3);
  args[0] = v_t_2484;
  args[1] = v_k2_2481;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam12(V self, V *args) {
  V v_a_2465 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2465)) {
  case TAG_PVar: {
    V v_l_2466 = heff_field(v_a_2465, 0);
    heff_take_n(v_a_2465, 1ULL, 1);
    HeffT2 v_t_2467 = (g_map_2elookup_24s567992785x1569911877_24cpr(v_l_2466, heff_rfield(v_pr_242, 2)));
    {
      V v_field_2469 = v_t_2467.f[1];
      int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
      if ((v_tag_2468 == ((int64_t)0ULL))) {
        V v_l_27_2471 = v_field_2469;
        return heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam13, 2, 2, (V[]){v_pr_242, v_l_27_2471});
      } else {
        heff_drop_rec(v_pr_242, 3);
        heff_drop(v_field_2469);
        return ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam14_clo);
      }
    }
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    return ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam15_clo);
  }
  default: return heff_nomatch(v_a_2465);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam16(V self, V *args) {
  V v_x_2486 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_x_2464 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2487 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_27_243, heff_arrayFromList(v_x_2486), v_x_2464});
  V f_ = v_k_246;
  args[0] = v_t_2487;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam11(V self, V *args) {
  V v_x_2464 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_args_2427 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_m_27_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2485 = (g_heff_2eelab_2eunify_2etraverseU_24s445996322x417629555(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam12, 1, 1, (V[]){v_pr_242}), v_args_2427));
  V f_ = v_c_2485;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam16, 1, 3, (V[]){v_m_27_243, v_x_2464, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam10(V self, V *args) {
  V v_x_2463 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_args_2427 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(v_g_240, v_m_241, heff_dup(v_pr_242), heff_get_n(v_x_2463, 0, 6), heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam11, 1, 5, (V[]){v_pr_242, v_args_2427, v_hd_245, v_m_27_243, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam17(V self, V *args) {
  V v_c_2489 = args[0];
  return heff_get_n(v_c_2489, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam18(V self, V *args) {
  V v_x_2492 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_k_2488 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2493 = ({ V a_0 = v_m_27_243; V a_1 = v_x_2492; HeffT2 r_ = (g_map_2elookup_24s567992785x1569911877_24cpr(a_0, a_1)); heff_drop(v_x_2492); r_; });
  {
    V v_field_2495 = v_t_2493.f[1];
    int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
    if ((v_tag_2494 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_245, 3);
      V v_e_2497 = v_field_2495;
      V f_ = v_k_2488;
      args[0] = v_e_2497;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2495);
      V v_t_2498 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2498})});
      V v_t_24100 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2499}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_24100;
      heff_room[1] = v_k_2488;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_pr_242 = heff_env(self)[4];
  V v_g_240 = heff_env(self)[5];
  V v_m_241 = heff_env(self)[6];
  V v_m_27_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT2 v_t_2415 = ({ V a_0 = v_x_2414; V a_1 = v_x_2410; V a_2 = heff_dup(v_sp_244); HeffT2 r_ = (g_heff_2eelab_2eunify_2epatSpine_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2414); heff_drop(v_x_2410); r_; });
  V v_t_2423;
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_items_2419 = v_field_2417;
      V v_t_2420 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2419)));
      V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2420); r_; });
      if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
        heff_drop(v_t_2421);
        V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2419));
        v_t_2423 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2422});
      } else {
        heff_drop(v_items_2419);
        heff_drop(v_t_2421);
        v_t_2423 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_field_2417);
      v_t_2423 = NTAG(TAG_Nothing);
    }
  }
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Nothing: {
    heff_drop(v_sp_244);
    heff_drop_rec(v_pr_242, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_m_27_243);
    V v_t_2424 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2425}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2426;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_args_2427 = heff_field(v_t_2423, 0);
    V v_ru_24t_2423_24Just = heff_take_reuse_n(v_t_2423, 1ULL, 1);
    V v_t_2435 = (g_heff_2eelab_2eunify_2eanyL(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam4, 1, 1, (V[]){heff_dup(v_pr_242)}), v_args_2427));
    if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
      heff_drop(v_t_2435);
      V v_k_2450 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam5, 1, 8, (V[]){v_args_2427, v_pr_242, v_g_240, v_m_241, heff_dup(v_m_27_243), heff_dup(v_hd_245), v_sp_244, v_k_246});
      V v_t_2452 = heff_tag_at_n(v_ru_24t_2423_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam8_clo)})});
      V v_t_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2452}));
      V f_ = heff_dup(heff_rfield(v_hd_245, 1));
      heff_room[0] = v_t_2453;
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam9, 1, 3, (V[]){v_m_27_243, v_k_2450, v_hd_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_244);
      heff_drop(v_t_2435);
      V v_k_2488 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam10, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, heff_dup(v_hd_245), v_args_2427, heff_dup(v_m_27_243), v_k_246});
      V v_t_2490 = heff_tag_at_n(v_ru_24t_2423_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam17_clo)})});
      V v_t_2491 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2490}));
      V f_ = heff_dup(heff_rfield(v_hd_245, 1));
      heff_room[0] = v_t_2491;
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam18, 1, 3, (V[]){v_m_27_243, v_k_2488, v_hd_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_t_2423);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_m_241 = heff_env(self)[5];
  V v_m_27_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam2_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam3, 1, 8, (V[]){v_x_2410, v_sp_244, v_hd_245, v_k_246, v_pr_242, v_g_240, v_m_241, v_m_27_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}