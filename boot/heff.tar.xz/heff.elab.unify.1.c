// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Escapes 7836
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MentionsError 719
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SOpaque 44226
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_msp 317956
#define LBL_mty 317996
#define LBL_poisoned 1215742945
#define LBL_ren 322325
#define LBL_ret 322331
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_co_2e_3c_2b_3e_24s419270740x1449981722_get(void);
V g_heff_2eelab_2econversion_2eeqHead(V, V);
V g_heff_2eelab_2econversion_2eeqHead_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2eeqHead_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eunify_2eappendL_24dps(V, V, V);
V g_heff_2eelab_2eunify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_24dps_clo;
V g_heff_2eelab_2eunify_2eappendL_24tok2(V, V, V);
V g_heff_2eelab_2eunify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_24tok2_clo;
V g_heff_2eelab_2eunify_2eappsRev(V);
V g_heff_2eelab_2eunify_2eappsRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappsRev_clo;
HeffT2 g_heff_2eelab_2eunify_2eappsRev_24cpr(V);
V g_heff_2eelab_2eunify_2econcatMapL(V, V);
V g_heff_2eelab_2eunify_2econcatMapL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2econcatMapL_clo;
V g_heff_2eelab_2eunify_2eiterateLift(V, V);
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eiterateLift_clo;
V g_heff_2eelab_2eunify_2eiterateLift_24scalars(V, V, V, V);
V g_heff_2eelab_2eunify_2eiterateLift_24scalars_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eiterateLift_24scalars_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2emetasTermF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasTermF_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2epatSpine(V, V, V);
V g_heff_2eelab_2eunify_2epatSpine_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatSpine_clo;
HeffT2 g_heff_2eelab_2eunify_2epatSpine_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_clo;
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_clo;
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo;
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_clo;
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_clo;
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_clo;
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(V, V, V, V);
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_clo;
V g_heff_2eelab_2eunify_2euAlg(V, V);
V g_heff_2eelab_2eunify_2euAlg_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euAlg_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_clo;
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_get(void);
V g_heff_2eelab_2eunify_2ezipL_24dps(V, V, V);
V g_heff_2eelab_2eunify_2ezipL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_24dps_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s868530262x539343671(V, V);
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a);
extern Clo g_list_2efoldl_24s868530262x539343671_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(V, V);
Clo g_heff_2eelab_2eunify_2epatSpine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatSpine_entry, 3, 0};

V g_heff_2eelab_2eunify_2epatSpine(V v_selfKey_240, V v_mc_241, V v_x3_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2eelab_2eunify_2epatSpine_24cpr(v_selfKey_240, v_mc_241, v_x3_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2eelab_2eunify_2epatSpine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eunify_2epatSpine(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2ezipL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezipL_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezipL_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ezipL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ezipL_24dps(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eunify_2emetasTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTermF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2emetasTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasTermF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasTermF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_v0_244) {
top: ;
  V v_msp_245 = heff_take_field(v_r_240, 2);
  V v_mty_246 = heff_take_field(v_r_240, 1);
  V v_mel_247 = heff_get_n(v_r_240, 0, 3);
  if (heff_intLe_c_lent(v_depth_242, MK_INT(0LL), 2)) {
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_v0_244);
    heff_drop(v_msp_245);
    heff_drop(v_mty_246);
    heff_drop(v_mel_247);
    return NTAG(TAG_Nil);
  } else {
    V v_it_248 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, v_v0_244));
    switch (heff_tag_of(v_it_248)) {
    case TAG_VNeu: {
      V v_it1_249 = heff_field(v_it_248, 0);
      V v_sp_2410 = heff_field(v_it_248, 1);
      heff_take_n(v_it_248, 3ULL, 5);
      heff_drop(v_mty_246);
      heff_drop(v_mel_247);
      switch (heff_tag_of(v_it1_249)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_249, 0ULL, 1);
        return heff_tail(v_msp_245, 3, (V[]){v_depth_242, v_len_243, v_sp_2410});
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_249, 0ULL, 1);
        return heff_tail(v_msp_245, 3, (V[]){v_depth_242, v_len_243, v_sp_2410});
      }
      case TAG_HMeta: {
        V v_m_2416 = heff_field(v_it1_249, 0);
        heff_take_n(v_it1_249, 1ULL, 1);
        V v_t_2417 = heff_tr(heff_call(v_msp_245, 3, (V[]){v_depth_242, v_len_243, v_sp_2410}));
        return heff_tag_n(TAG_Cons, 2, (V[]){v_m_2416, v_t_2417});
      }
      case TAG_HError: {
        return heff_tail(v_msp_245, 3, (V[]){v_depth_242, v_len_243, v_sp_2410});
      }
      default: return heff_nomatch(v_it1_249);
      }
    }
    case TAG_VCode: {
      V v_t_2418 = heff_field(v_it_248, 0);
      heff_take_n(v_it_248, 1ULL, 1);
      heff_drop(v_msp_245);
      heff_drop(v_mel_247);
      return heff_tail(v_mty_246, 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_t_2418});
    }
    case TAG_VLam: {
      V v_d_2419 = heff_field(v_it_248, 0);
      V v_c_2420 = heff_field(v_it_248, 1);
      heff_take_n(v_it_248, 3ULL, 2);
      heff_drop(v_msp_245);
      heff_drop(v_mty_246);
      V v_x1_2441;
      switch (heff_tag_of(v_c_2420)) {
      case TAG_MkClo: {
        V v_vs_2422 = heff_field(v_c_2420, 1);
        V v_body_2423 = heff_field(v_c_2420, 2);
        heff_take_n(v_c_2420, 6ULL, 3);
        v_x1_2441 = heff_tr(heff_call(v_body_2423, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2422, heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam0, 1, 2, (V[]){v_d_2419, heff_dup(v_len_243)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2440 = heff_field(v_c_2420, 0);
        heff_take_n(v_c_2420, 1ULL, 1);
        heff_drop(v_d_2419);
        v_x1_2441 = v_body_2440;
        break;
      }
      default: heff_nomatch(v_c_2420);
      }
      V v_t_2445;
      switch (heff_tag_of(v_x1_2441)) {
      case TAG_Nom: {
        V v_x_2442 = heff_field(v_x1_2441, 0);
        heff_take_n(v_x1_2441, 1ULL, 1);
        v_t_2445 = v_x_2442;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2441, 0ULL, 1);
        v_t_2445 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2444 = heff_field(v_x1_2441, 0);
        heff_take_n(v_x1_2441, 1ULL, 1);
        v_t_2445 = v_x_2444;
        break;
      }
      default: heff_nomatch(v_x1_2441);
      }
      return heff_tail(v_mel_247, 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2445});
    }
    case TAG_VCons: {
      V v_d_2446 = heff_field(v_it_248, 0);
      heff_take_n(v_it_248, 1ULL, 1);
      heff_drop(v_msp_245);
      heff_drop(v_mty_246);
      V v_t_2447 = heff_arrayToList(heff_get_n(v_d_2446, 2, 3));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam2, 1, 3, (V[]){v_mel_247, v_depth_242, v_len_243}); V a_1 = v_t_2447; V r_ = (g_heff_2eelab_2eunify_2econcatMapL(a_0, a_1)); heff_drop(v_t_2447); r_; });
    }
    case TAG_VOpaque: {
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      heff_drop(v_msp_245);
      heff_drop(v_mty_246);
      heff_drop(v_mel_247);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_it_248);
    }
  }
}
V g_heff_2eelab_2eunify_2emetasTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2emetasTermF(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2emetasTermF_lam1(V self, V *args) {
  V v_u_2439 = args[0];
  V v_a_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2439);
  return v_a_2438;
}
V g_heff_2eelab_2eunify_2emetasTermF_lam0(V self, V *args) {
  V v_u_2424 = args[0];
  V v_d_2419 = heff_env(self)[0];
  V v_len_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2424);
  V v_t_2425 = heff_tr(heff_call(v_d_2419, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2426 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2425)));
  V v_a_2438;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2429 = heff_field(v_t_2426, 1);
    heff_take_n(v_t_2426, 2ULL, 4);
    heff_drop(v_t_2425);
    v_a_2438 = v_dom_2429;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2426, 0ULL, 3);
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeInt: {
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeFloat: {
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeString: {
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeRune: {
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_NoRules: {
    v_a_2438 = v_t_2425;
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam1, 1, 1, (V[]){v_a_2438}), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2eunify_2emetasTermF_lam2(V self, V *args) {
  V v_x_2448 = args[0];
  V v_mel_247 = heff_env(self)[0];
  V v_depth_242 = heff_env(self)[1];
  V v_len_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2452;
  switch (heff_tag_of(v_x_2448)) {
  case TAG_Nom: {
    V v_x_2449 = heff_field(v_x_2448, 0);
    heff_take_n(v_x_2448, 1ULL, 1);
    v_t_2452 = v_x_2449;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x_2448, 0ULL, 1);
    v_t_2452 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2451 = heff_field(v_x_2448, 0);
    heff_take_n(v_x_2448, 1ULL, 1);
    v_t_2452 = v_x_2451;
    break;
  }
  default: heff_nomatch(v_x_2448);
  }
  V f_ = v_mel_247;
  heff_room[0] = heff_intSub(v_depth_242, MK_INT(1LL));
  heff_room[1] = v_len_243;
  heff_room[2] = v_t_2452;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
Clo g_heff_2eelab_2eunify_2eiterateLift_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eiterateLift_24scalars_entry, 4, 0};

V g_heff_2eelab_2eunify_2eiterateLift_24scalars(V v_i_240, V v_dom_241, V v_cod_242, V v_ren_243) {
top: ;
  if (heff_intLe_c_lent(v_i_240, MK_INT(0LL), 2)) {
    heff_drop(v_i_240);
    return heff_rec_n(3, shape_dom__cod__ren, (V[]){v_dom_241, v_cod_242, v_ren_243});
  } else {
    V v_t_244 = (g_std_2emap_2einsert_24s170109517x1206653089(v_ren_243, heff_dup(v_dom_241), heff_dup(v_cod_242)));
    V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
    V t_1 = heff_intAdd(v_dom_241, MK_INT(1LL));
    V t_2 = heff_intAdd(v_cod_242, MK_INT(1LL));
    V t_3 = v_t_244;
    v_i_240 = t_0;
    v_dom_241 = t_1;
    v_cod_242 = t_2;
    v_ren_243 = t_3;
    goto top;
  }
}
V g_heff_2eelab_2eunify_2eiterateLift_24scalars_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eiterateLift_24scalars(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eunify_2eiterateLift_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eiterateLift_entry, 2, 0};

V g_heff_2eelab_2eunify_2eiterateLift(V v_i_240, V v_rr_241) {
top: ;
  V v_dom_242 = heff_take_field(v_rr_241, 0);
  V v_cod_243 = heff_take_field(v_rr_241, 1);
  V v_ren_244 = heff_get_n(v_rr_241, 2, 3);
  return (g_heff_2eelab_2eunify_2eiterateLift_24scalars(v_i_240, v_dom_242, v_cod_243, v_ren_244));
}
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eiterateLift(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eunify_2elamsU_str0, 1, "x");
Clo g_heff_2eelab_2eunify_2elamsU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2elamsU_entry, 2, 0};

V g_heff_2eelab_2eunify_2elamsU(V v_k_240, V v_body_241) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return v_body_241;
  } else {
    V v_t_242 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
    V v_t_243 = heff_tag_n(TAG_SLam, 2, (V[]){v_t_242, heff_tag_n(TAG_MkAbs, 2, (V[]){((V)&g_heff_2eelab_2eunify_2elamsU_str0), v_body_241})});
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = v_t_243;
    v_k_240 = t_0;
    v_body_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2elamsU(a[0], a[1]);
}

HeffT2 g_heff_2eelab_2eunify_2eappsRev_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_SpApp: {
    V v_s_241 = heff_field(v_x1_240, 0);
    V v_a_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2eelab_2eunify_2eappsRev_24cpr(v_s_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_argv_246 = v_field_245;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_a_242, v_argv_246})}});
      } else {
        heff_drop(v_a_242);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_field_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SpProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SpSpec: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2eelab_2eunify_2eappsRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eappsRev_entry, 1, 0};

V g_heff_2eelab_2eunify_2eappsRev(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2eunify_2eappsRev_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2eelab_2eunify_2eappsRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eappsRev(a[0]);
}
Clo g_heff_2eelab_2eunify_2emsEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emsEv_entry, 1, 0};

V g_heff_2eelab_2eunify_2emsEv(V v_p_240) {
top: ;
  return heff_tag_n(TAG_InL, 1, (V[]){v_p_240});
}
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emsEv(a[0]);
}
Clo g_heff_2eelab_2eunify_2euAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euAlg_entry, 2, 0};

V g_heff_2eelab_2eunify_2euAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_InL: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InL = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_Get: {
      V v_k_243 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_244 = heff_tr(heff_call(v_k_243, 1, (V[]){heff_dup(v_p_241)}));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_t_244}), v_p_241});
    }
    case TAG_Put: {
      V v_c2_245 = heff_field(v_t_242, 0);
      V v_x_246 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24Put = heff_take_reuse_n(v_t_242, 3ULL, 2);
      heff_drop(v_p_241);
      return heff_tag_at_n(v_ru_24t_242_24Put, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_x_246}), v_c2_245});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_InR: {
    V v_q_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InR = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_q_247)) {
    case TAG_Throw: {
      V v_err_248 = heff_field(v_q_247, 0);
      heff_take_n(v_q_247, 1ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Left, 1, (V[]){v_err_248}), v_p_241});
    }
    case TAG_Catch: {
      V v_m_249 = heff_field(v_q_247, 0);
      V v_h_2410 = heff_field(v_q_247, 1);
      V v_ru_24q_247_24Catch = heff_take_reuse_n(v_q_247, 3ULL, 2);
      V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x21_2412 = heff_field(v_x2_2411, 0);
        V v_st_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_Left: {
          V v_e_2414 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24InR, 1);
          heff_drop_cell(v_ru_24q_247_24Catch, 2);
          return heff_tail(v_h_2410, 2, (V[]){v_e_2414, v_st_2413});
        }
        case TAG_Right: {
          V v_x_2415 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop(v_h_2410);
          return heff_tag_at_n(v_ru_24q_247_24Catch, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Right, 1, (V[]){v_x_2415}), v_st_2413});
        }
        default: return heff_nomatch(v_x21_2412);
        }
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_q_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2euAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euAlg(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(V v_g_240, V v_m_241, V v_pr_242, V v_v0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam0, 1, 1, (V[]){v_v0_243})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam1, 1, 5, (V[]){v_pr_242, v_hd_244, v_g_240, v_m_241, v_k_245})});
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_v0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_v0_243; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2418 = (g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2417));
  V f_ = v_t_2418;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = (g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2421));
  V f_ = v_t_2422;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2429 = (g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2428));
  V f_ = v_t_2429;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SCode, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SLam, 2, (V[]){v_x_2435, v_x_2451});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_fty_2432 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_body_2433 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2436 = heff_tr(heff_call(v_fty_2432, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2437 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2436)));
  V v_t_2449;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2440 = heff_field(v_t_2437, 1);
    heff_take_n(v_t_2437, 2ULL, 4);
    heff_drop(v_t_2436);
    v_t_2449 = v_dom_2440;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2437, 0ULL, 3);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeInt: {
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeFloat: {
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeString: {
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeRune: {
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_NoRules: {
    v_t_2449 = v_t_2436;
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_c_2450 = (g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421(v_g_240, v_m_241, v_pr_242, v_t_2449, v_body_2433));
  V f_ = v_c_2450;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam7, 1, 2, (V[]){v_k_245, v_x_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam11(V self, V *args) {
  V v_x_2466 = args[0];
  V v_k_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2465;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2466});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam10(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2463 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(v_g_240, v_m_241, v_pr_242, v_v_2463, v_hd_2464, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam11, 1, 1, (V[]){v_k_2465})));
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam12(V self, V *args) {
  V v_x_2468 = args[0];
  V v_k_2460 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2460;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2457, v_x_2468});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam9(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k_2460 = args[1];
  V v_x_2458 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_k_2457 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2467;
  switch (heff_tag_of(v_x_2458)) {
  case TAG_Nom: {
    V v_v_2461 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    v_t_2467 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2461}));
    break;
  }
  case TAG_Describe: {
    V v_v_2462 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    v_t_2467 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2462}));
    break;
  }
  case TAG_Become: {
    V v_v_2463 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    v_t_2467 = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam10, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2463});
    break;
  }
  default: heff_nomatch(v_x_2458);
  }
  V f_ = v_t_2467;
  args[0] = v_hd_2459;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam12, 1, 2, (V[]){v_k_2460, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam8(V self, V *args) {
  V v_p_2456 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2456)) {
  case TAG_MkPair: {
    V v_k_2457 = heff_field(v_p_2456, 0);
    V v_x_2458 = heff_field(v_p_2456, 1);
    heff_take_n(v_p_2456, 3ULL, 2);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam9, 2, 5, (V[]){v_x_2458, v_g_240, v_m_241, v_pr_242, v_k_2457});
  }
  default: return heff_nomatch(v_p_2456);
  }
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam13(V self, V *args) {
  V v_x_2470 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2471 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2470)));
  V v_t_2472 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2470));
  V v_t_2473 = (g_list_2emap_24s1173914895x100384474(v_x_2470));
  V v_t_2474 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2471), v_t_2472, heff_arrayFromList(v_t_2473)});
  V v_x_2475 = heff_tag_n(TAG_SCons, 1, (V[]){v_t_2474});
  V f_ = v_k_245;
  args[0] = v_x_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VNeu: {
    V v_it1_2410 = heff_field(v_x_249, 0);
    V v_sp_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_HLocal: {
      V v_c_2416 = (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2416;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HGlobal: {
      V v_c_2420 = (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2420;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam3, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HMeta: {
      V v_m_27_2423 = heff_field(v_it1_2410, 0);
      V v_ru_24it1_2410_24HMeta = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
      if (heff_intEq_c_lent(v_m_27_2423, v_m_241, 0)) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2411);
        heff_drop(v_m_27_2423);
        V v_t_2424 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2425 = heff_tag_at_n(v_ru_24it1_2410_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2425}));
        V f_ = heff_get_n(v_hd_244, 1, 3);
        heff_room[0] = v_t_2426;
        heff_room[1] = v_k_245;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24it1_2410_24HMeta, 1);
        return (g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869(v_g_240, v_m_241, v_pr_242, v_m_27_2423, v_sp_2411, v_hd_244, v_k_245));
      }
    }
    case TAG_HError: {
      V v_c_2427 = (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2427;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  case TAG_VCode: {
    V v_t_2430 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(v_g_240, v_m_241, v_pr_242, v_t_2430, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam5, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VLam: {
    V v_fty_2432 = heff_field(v_x_249, 0);
    V v_body_2433 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_t_2434 = heff_tr(heff_call(heff_dup(v_fty_2432), 1, (V[]){NTAG(TAG_MkUnit)}));
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_t_2434, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam6, 1, 7, (V[]){v_fty_2432, v_g_240, v_m_241, v_pr_242, v_body_2433, v_hd_244, v_k_245})));
  }
  case TAG_VCons: {
    V v_d_2452 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_keys_2453 = heff_take_field(v_d_2452, 0);
    V v_values_2454 = heff_get_n(v_d_2452, 2, 3);
    V v_t_2455 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2453), heff_arrayToList(v_values_2454)));
    V v_c_2469 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam8, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2455));
    V f_ = v_c_2469;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam13, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VOpaque: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SOpaque);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam5(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam5, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam12(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam12, 1, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam14(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam14, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam7(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_entry, 7, 0};

V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(V v_g_240, V v_cs_241, V v_m_242, V v_args_243, V v_rhs_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
  V v_t_248 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(MK_INT(0LL), heff_dup(v_args_243)));
  V v_t_249 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s868530262x539343671(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_pr_2410 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_get_n(v_cs_241, 0, 2), v_t_247, v_t_249});
  V v_t_2412 = heff_tr(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(heff_dup(v_g_240), heff_dup(v_m_242), v_pr_2410, v_rhs_244, heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam0, 1, 1, (V[]){heff_dup(v_z_245)})));
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam1, 1, 1, (V[]){heff_dup(v_z_245)})})});
  V v_t_2454 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2453}));
  return heff_tail(heff_dup(heff_rfield(v_z_245, 1)), 2, (V[]){v_t_2454, heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam7, 1, 5, (V[]){v_z_246, v_args_243, v_g_240, v_m_242, v_z_245})});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_z_245, 0, 3);
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2419 = heff_take_field(v_hd_2417, 1);
  V v_malg_2420 = heff_get_n(v_hd_2417, 2, 3);
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2422 = heff_tr(heff_call(v_malg_2420, 1, (V[]){v_t_2421}));
  V f_ = v_bind_2419;
  args[0] = v_t_2422;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam3(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k2_2427 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2428 = heff_take_field(v_hd_2426, 1);
  V v_malg_2429 = heff_get_n(v_hd_2426, 2, 3);
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2431 = heff_tr(heff_call(v_malg_2429, 1, (V[]){v_t_2430}));
  V f_ = v_bind_2428;
  args[0] = v_t_2431;
  args[1] = v_k2_2427;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam4(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k2_2438 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2439 = heff_take_field(v_hd_2437, 1);
  V v_malg_2440 = heff_get_n(v_hd_2437, 2, 3);
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2442 = heff_tr(heff_call(v_malg_2440, 1, (V[]){v_t_2441}));
  V f_ = v_bind_2439;
  args[0] = v_t_2442;
  args[1] = v_k2_2438;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  heff_drop(v_hd_2443);
  V f_ = v_k_2444;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam6(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k2_2447 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2448 = heff_take_field(v_hd_2446, 1);
  V v_malg_2449 = heff_get_n(v_hd_2446, 2, 3);
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2451 = heff_tr(heff_call(v_malg_2449, 1, (V[]){v_t_2450}));
  V f_ = v_bind_2448;
  args[0] = v_t_2451;
  args[1] = v_k2_2447;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam1(V self, V *args) {
  V v_s_2413 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2452;
  switch (heff_tag_of(v_s_2413)) {
  case TAG_UnequalTys: {
    v_t_2452 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam2, 2, 1, (V[]){v_s_2413});
    break;
  }
  case TAG_UnequalEls: {
    v_t_2452 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam3, 2, 1, (V[]){v_s_2413});
    break;
  }
  case TAG_UnequalNeus: {
    v_t_2452 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam4, 2, 1, (V[]){v_s_2413});
    break;
  }
  case TAG_MentionsError: {
    v_t_2452 = ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam5_clo);
    break;
  }
  case TAG_Escapes: {
    v_t_2452 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam6, 2, 1, (V[]){v_s_2413});
    break;
  }
  default: heff_nomatch(v_s_2413);
  }
  V f_ = v_t_2452;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_get_n(v_z_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam9(V self, V *args) {
  V v_c_2465 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2466 = ({ V b_0 = heff_get_n(v_c_2465, 2, 8); V a_1 = v_m_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2468 = v_t_2466.f[1];
    int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2467 == ((int64_t)0ULL)) && ({ V v_x_2469 = heff_dup(v_field_2468); int c_ = 1; heff_drop(v_x_2469); c_; })));
    heff_drop(v_field_2468);
    return v_ret_24bool;
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam12(V self, V *args) {
  V v_c_2475 = args[0];
  return heff_get_n(v_c_2475, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam13(V self, V *args) {
  V v_x_2478 = args[0];
  V v_v_2463 = heff_env(self)[0];
  V v_hd_2473 = heff_env(self)[1];
  V v_k_2474 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2479 = ({ V a_0 = v_x_2478; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2478); r_; });
  V v_t_2480 = heff_tr(heff_call(heff_get_n(v_t_2479, 0, 3), 3, (V[]){MK_INT(20LL), MK_INT(0LL), v_v_2463}));
  return ({ V a_0 = v_t_2480; V a_1 = v_hd_2473; V a_2 = v_k_2474; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2480); r_; });
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam11(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k_2474 = args[1];
  V v_v_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam12_clo)})});
  V v_t_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2473, 2)), 1, (V[]){v_t_2476}));
  V f_ = heff_dup(heff_rfield(v_hd_2473, 1));
  args[0] = v_t_2477;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam13, 1, 3, (V[]){v_v_2463, v_hd_2473, v_k_2474});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam14(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k_2482 = args[1];
  heff_drop(v_hd_2481);
  V f_ = v_k_2482;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam15(V self, V *args) {
  V v_x_2484 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_t_2458 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2484);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(v_m_242, v_t_2458, v_z_245, v_z_246));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam10(V self, V *args) {
  V v_x_2472 = args[0];
  V v_v_2463 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_t_2458 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2483;
  if ((heff_dup(v_x_2472) == NTAG(TAG_True))) {
    heff_drop(v_x_2472);
    v_t_2483 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam11, 2, 1, (V[]){v_v_2463});
  } else {
    heff_drop(v_x_2472);
    heff_drop(v_v_2463);
    v_t_2483 = ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam14_clo);
  }
  V f_ = v_t_2483;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam15, 1, 4, (V[]){v_m_242, v_t_2458, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam8(V self, V *args) {
  V v_x_2464 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_v_2463 = heff_env(self)[2];
  V v_t_2458 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2464);
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam9, 1, 1, (V[]){heff_dup(v_m_242)})})});
  V v_t_2471 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2470}));
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_2471;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam10, 1, 5, (V[]){v_v_2463, v_z_245, v_m_242, v_t_2458, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam7(V self, V *args) {
  V v_x_2455 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2455)) {
  case TAG_Nothing: {
    heff_drop(v_args_243);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    heff_drop_rec(v_z_245, 3);
    V f_ = v_z_246;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_body_2456 = heff_field(v_x_2455, 0);
    V v_ru_24x_2455_24Just = heff_take_reuse_n(v_x_2455, 1ULL, 1);
    V v_t_2457 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_243); r_; });
    V v_t_2458 = (g_heff_2eelab_2eunify_2elamsU(v_t_2457, v_body_2456));
    V v_x1_2459 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2458), NTAG(TAG_LNil)));
    V v_v_2463;
    switch (heff_tag_of(v_x1_2459)) {
    case TAG_Nom: {
      V v_x_2460 = heff_field(v_x1_2459, 0);
      heff_take_n(v_x1_2459, 1ULL, 1);
      v_v_2463 = v_x_2460;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2459, 0ULL, 1);
      v_v_2463 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2462 = heff_field(v_x1_2459, 0);
      heff_take_n(v_x1_2459, 1ULL, 1);
      v_v_2463 = v_x_2462;
      break;
    }
    default: heff_nomatch(v_x1_2459);
    }
    return (g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1(v_ru_24x_2455_24Just, heff_dup(v_m_242), heff_dup(v_v_2463), heff_dup(v_t_2458), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam8, 1, 5, (V[]){v_m_242, v_z_245, v_v_2463, v_t_2458, v_z_246})));
  }
  default: return heff_nomatch(v_x_2455);
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam4, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam7(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam7, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam0, 1, 1, (V[]){v_a0_242})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam1, 1, 5, (V[]){v_b0_243, v_hd_244, v_cs_241, v_k_245, v_g_240})});
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_b0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2410, 3, 8); V a_1 = v_b0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam4(V self, V *args) {
  V v_c_2460 = args[0];
  return heff_get_n(v_c_2460, 3, 8);
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam7(V self, V *args) {
  V v_c_2467 = args[0];
  return heff_get_n(v_c_2467, 3, 8);
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam8(V self, V *args) {
  V v_x_2470 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2471 = ({ V a_0 = v_x_2470; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2470); r_; });
  V v_t_2472 = heff_tr(heff_call(heff_get_n(v_t_2471, 1, 3), 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_241, 0, 2), v_x_2413}));
  return ({ V a_0 = v_t_2472; V a_1 = v_hd_244; V a_2 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2472); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam6(V self, V *args) {
  V v_x_2466 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2466);
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam7_clo)})});
  V v_t_2469 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2468}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2469;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam8, 1, 4, (V[]){v_cs_241, v_x_2413, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam5(V self, V *args) {
  V v_x_2463 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2464 = ({ V a_0 = v_x_2463; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2463); r_; });
  V v_t_2465 = heff_tr(heff_call(heff_get_n(v_t_2464, 1, 3), 3, (V[]){MK_INT(20LL), heff_dup(heff_rfield(v_cs_241, 0)), v_x_249}));
  return ({ V a_0 = v_t_2465; V a_1 = heff_dup(v_hd_244); V a_2 = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam6, 1, 4, (V[]){v_hd_244, v_cs_241, v_x_2413, v_k_245}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2465); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2436;
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2415 = heff_dup(heff_field(v_x_249, 0));
    switch (heff_tag_of(v_h_2415)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2415);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2459;
  if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
    heff_drop(v_t_2436);
    v_t_2459 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2436);
    switch (heff_tag_of(v_x_2413)) {
    case TAG_VU: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2438 = heff_dup(heff_field(v_x_2413, 0));
      switch (heff_tag_of(v_h_2438)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2459 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2438);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
  }
  if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
    heff_drop(v_g_240);
    heff_drop(v_t_2459);
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam4_clo)})});
    V v_t_2462 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2461}));
    V f_ = heff_dup(heff_rfield(v_hd_244, 1));
    heff_room[0] = v_t_2462;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam5, 1, 5, (V[]){v_cs_241, v_x_249, v_hd_244, v_x_2413, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2459);
    V v_t_2495;
    switch (heff_tag_of(v_x_249)) {
    case TAG_VU: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2474 = heff_dup(heff_field(v_x_249, 0));
      V v_sp_2475 = heff_dup(heff_field(v_x_249, 1));
      switch (heff_tag_of(v_t1_2474)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2474, 0ULL, 1);
        heff_drop(v_sp_2475);
        v_t_2495 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2474, 0ULL, 1);
        heff_drop(v_sp_2475);
        v_t_2495 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2481 = heff_field(v_t1_2474, 0);
        V v_ru_24t1_2474_24HMeta = heff_take_reuse_n(v_t1_2474, 1ULL, 1);
        v_t_2495 = heff_tag_at_n(v_ru_24t1_2474_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2481, v_sp_2475})});
        break;
      }
      case TAG_HError: {
        heff_drop(v_sp_2475);
        v_t_2495 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t1_2474);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VRecord: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFixed: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    switch (heff_tag_of(v_t_2495)) {
    case TAG_Nothing: {
      V v_t_24118;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        V v_t1_2497 = heff_dup(heff_field(v_x_2413, 0));
        V v_sp_2498 = heff_dup(heff_field(v_x_2413, 1));
        switch (heff_tag_of(v_t1_2497)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_2497, 0ULL, 1);
          heff_drop(v_sp_2498);
          v_t_24118 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_2497, 0ULL, 1);
          heff_drop(v_sp_2498);
          v_t_24118 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HMeta: {
          V v_m_24104 = heff_field(v_t1_2497, 0);
          V v_ru_24t1_2497_24HMeta = heff_take_reuse_n(v_t1_2497, 1ULL, 1);
          v_t_24118 = heff_tag_at_n(v_ru_24t1_2497_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24104, v_sp_2498})});
          break;
        }
        case TAG_HError: {
          heff_drop(v_sp_2498);
          v_t_24118 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t1_2497);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VRecord: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      switch (heff_tag_of(v_t_24118)) {
      case TAG_Nothing: {
        return (g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634(v_g_240, v_cs_241, v_x_249, v_x_2413, v_hd_244, v_k_245));
      }
      case TAG_Just: {
        V v_it1_24119 = heff_field(v_t_24118, 0);
        V v_ru_24t_24118_24Just = heff_take_reuse_n(v_t_24118, 1ULL, 1);
        switch (heff_tag_of(v_it1_24119)) {
        case TAG_MkPair: {
          V v_m_24120 = heff_field(v_it1_24119, 0);
          V v_sp_24121 = heff_field(v_it1_24119, 1);
          heff_take_n(v_it1_24119, 3ULL, 2);
          V v_rhs_24141;
          switch (heff_tag_of(v_x_249)) {
          case TAG_VU: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VDecode: {
            V v_el_24127 = heff_field(v_x_249, 4);
            heff_take_n(v_x_249, 16ULL, 5);
            heff_drop_cell(v_ru_24t_24118_24Just, 1);
            v_rhs_24141 = heff_tr(heff_call(v_el_24127, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VRecord: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VSum: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimInt: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimFloat: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimString: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimRune: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimArray: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VFixed: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          default: heff_nomatch(v_x_249);
          }
          V v_self_24161;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_VU: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VDecode: {
            V v_el_24147 = heff_field(v_x_2413, 4);
            heff_take_n(v_x_2413, 16ULL, 5);
            v_self_24161 = heff_tr(heff_call(v_el_24147, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VRecord: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VSum: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimInt: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimFloat: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimString: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimRune: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimArray: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VFixed: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          return (g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(v_g_240, v_cs_241, v_m_24120, v_sp_24121, v_rhs_24141, v_self_24161, v_hd_244, v_k_245));
        }
        default: return heff_nomatch(v_it1_24119);
        }
      }
      default: return heff_nomatch(v_t_24118);
      }
    }
    case TAG_Just: {
      V v_it1_24162 = heff_field(v_t_2495, 0);
      V v_ru_24t_2495_24Just = heff_take_reuse_n(v_t_2495, 1ULL, 1);
      switch (heff_tag_of(v_it1_24162)) {
      case TAG_MkPair: {
        V v_m_24163 = heff_field(v_it1_24162, 0);
        V v_sp_24164 = heff_field(v_it1_24162, 1);
        heff_take_n(v_it1_24162, 3ULL, 2);
        V v_rhs_24184;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VU: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VDecode: {
          V v_el_24170 = heff_field(v_x_2413, 4);
          heff_take_n(v_x_2413, 16ULL, 5);
          heff_drop_cell(v_ru_24t_2495_24Just, 1);
          v_rhs_24184 = heff_tr(heff_call(v_el_24170, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VRecord: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VSum: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimInt: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimFloat: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimString: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimRune: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimArray: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VFixed: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        V v_self_24204;
        switch (heff_tag_of(v_x_249)) {
        case TAG_VU: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VDecode: {
          V v_el_24190 = heff_field(v_x_249, 4);
          heff_take_n(v_x_249, 16ULL, 5);
          v_self_24204 = heff_tr(heff_call(v_el_24190, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VRecord: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VSum: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimInt: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimFloat: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimString: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimRune: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimArray: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VFixed: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        default: heff_nomatch(v_x_249);
        }
        return (g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(v_g_240, v_cs_241, v_m_24163, v_sp_24164, v_rhs_24184, v_self_24204, v_hd_244, v_k_245));
      }
      default: return heff_nomatch(v_it1_24162);
      }
    }
    default: return heff_nomatch(v_t_2495);
    }
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_b0_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam2, 1, 1, (V[]){v_b0_243})})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam3, 1, 5, (V[]){v_x_249, v_hd_244, v_cs_241, v_k_245, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam1, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam17(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam18(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam21(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam21, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam22(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam23(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam20(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam19(V self, V *args);
Clo g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_entry, 6, 0};

V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243, V v_h_27_244, V v_sp_27_245) {
top: ;
  V v_t_2418;
  switch (heff_tag_of(v_h_242)) {
  case TAG_HLocal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HGlobal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HMeta: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HError: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_h_242);
  }
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_g_240);
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    heff_drop(v_t_2418);
    return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam0_clo);
  } else {
    heff_drop(v_t_2418);
    switch (heff_tag_of(v_sp_243)) {
    case TAG_SpId: {
      heff_drop(v_g_240);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        V v_t_2421 = (g_heff_2eelab_2econversion_2eeqHead(v_h_242, v_h_27_244));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_cs_241);
          heff_drop(v_h_242);
          heff_drop(v_h_27_244);
          heff_drop(v_t_2421);
          return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam1_clo);
        } else {
          heff_drop(v_t_2421);
          return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam2, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
        }
      }
      case TAG_SpApp: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam3, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam4, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam5, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpApp: {
      V v_sq_2455 = heff_dup(heff_field(v_sp_243, 0));
      V v_v_2456 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2455);
        heff_drop(v_v_2456);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam6, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        V v_sq_27_2463 = heff_field(v_sp_27_245, 0);
        V v_v_27_2464 = heff_field(v_sp_27_245, 1);
        heff_take_n(v_sp_27_245, 3ULL, 2);
        heff_drop_tag(v_sp_243, 2);
        V v_c_2465 = (g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(heff_dup(v_g_240), heff_dup(v_cs_241), v_h_242, v_sq_2455, v_h_27_244, v_sq_27_2463));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam7, 2, 5, (V[]){v_c_2465, v_g_240, v_cs_241, v_v_2456, v_v_27_2464});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2455);
        heff_drop(v_v_2456);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam9, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2455);
        heff_drop(v_v_2456);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam10, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpProj: {
      V v_sq_2487 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_2488 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2487);
        heff_drop(v_x_2488);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam11, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2487);
        heff_drop(v_x_2488);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam12, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        V v_sq_27_24103 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_24104 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_c_24105 = (g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(v_g_240, heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_2487, heff_dup(v_h_27_244), v_sq_27_24103));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam13, 2, 8, (V[]){v_c_24105, v_x_2488, v_x_27_24104, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2487);
        heff_drop(v_x_2488);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam15, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpSpec: {
      V v_sq_24120 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_24121 = heff_dup(heff_field(v_sp_243, 1));
      V v_v_24122 = heff_dup(heff_field(v_sp_243, 2));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24120);
        heff_drop(v_x_24121);
        heff_drop(v_v_24122);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam16, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24120);
        heff_drop(v_x_24121);
        heff_drop(v_v_24122);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam17, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24120);
        heff_drop(v_x_24121);
        heff_drop(v_v_24122);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam18, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        V v_sq_27_24145 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_24146 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_v_27_24147 = heff_dup(heff_field(v_sp_27_245, 2));
        V v_c_24148 = (g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_24120, heff_dup(v_h_27_244), v_sq_27_24145));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam19, 2, 11, (V[]){v_c_24148, v_x_24121, v_x_27_24146, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_g_240, v_v_24122, v_v_27_24147});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    default: return heff_nomatch(v_sp_243);
    }
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_2426 = heff_take_field(v_hd_2424, 1);
  V v_malg_2427 = heff_get_n(v_hd_2424, 2, 3);
  V v_t_2428 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2429 = heff_tr(heff_call(v_malg_2427, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})}));
  V f_ = v_bind_2426;
  args[0] = v_t_2429;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam3(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_2434 = heff_take_field(v_hd_2432, 1);
  V v_malg_2435 = heff_get_n(v_hd_2432, 2, 3);
  V v_t_2436 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2437 = heff_tr(heff_call(v_malg_2435, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})}));
  V f_ = v_bind_2434;
  args[0] = v_t_2437;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam4(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_2442 = heff_take_field(v_hd_2440, 1);
  V v_malg_2443 = heff_get_n(v_hd_2440, 2, 3);
  V v_t_2444 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2445 = heff_tr(heff_call(v_malg_2443, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})}));
  V f_ = v_bind_2442;
  args[0] = v_t_2445;
  args[1] = v_k2_2441;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam5(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k2_2450 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_2451 = heff_take_field(v_hd_2449, 1);
  V v_malg_2452 = heff_get_n(v_hd_2449, 2, 3);
  V v_t_2453 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2454 = heff_tr(heff_call(v_malg_2452, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})}));
  V f_ = v_bind_2451;
  args[0] = v_t_2454;
  args[1] = v_k2_2450;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam6(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k2_2458 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_2459 = heff_take_field(v_hd_2457, 1);
  V v_malg_2460 = heff_get_n(v_hd_2457, 2, 3);
  V v_t_2461 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2462 = heff_tr(heff_call(v_malg_2460, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})}));
  V f_ = v_bind_2459;
  args[0] = v_t_2462;
  args[1] = v_k2_2458;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam8(V self, V *args) {
  V v_x_2468 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_2456 = heff_env(self)[2];
  V v_v_27_2464 = heff_env(self)[3];
  V v_hd_2466 = heff_env(self)[4];
  V v_k_2467 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2468);
  V v_t_2469 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2e_3c_2b_3e_24s419270740x1449981722_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_get()), v_g_240, v_cs_241, v_v_2456, v_v_27_2464));
  V f_ = v_t_2469;
  heff_room[0] = v_hd_2466;
  heff_room[1] = v_k_2467;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam7(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_c_2465 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_v_2456 = heff_env(self)[3];
  V v_v_27_2464 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2465;
  args[0] = heff_dup(v_hd_2466);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam8, 1, 6, (V[]){v_g_240, v_cs_241, v_v_2456, v_v_27_2464, v_hd_2466, v_k_2467});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam9(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k2_2473 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_2474 = heff_take_field(v_hd_2472, 1);
  V v_malg_2475 = heff_get_n(v_hd_2472, 2, 3);
  V v_t_2476 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2477 = heff_tr(heff_call(v_malg_2475, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})}));
  V f_ = v_bind_2474;
  args[0] = v_t_2477;
  args[1] = v_k2_2473;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam10(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k2_2482 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_2483 = heff_take_field(v_hd_2481, 1);
  V v_malg_2484 = heff_get_n(v_hd_2481, 2, 3);
  V v_t_2485 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2486 = heff_tr(heff_call(v_malg_2484, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})}));
  V f_ = v_bind_2483;
  args[0] = v_t_2486;
  args[1] = v_k2_2482;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam11(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k2_2490 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_2491 = heff_take_field(v_hd_2489, 1);
  V v_malg_2492 = heff_get_n(v_hd_2489, 2, 3);
  V v_t_2493 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2494 = heff_tr(heff_call(v_malg_2492, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})}));
  V f_ = v_bind_2491;
  args[0] = v_t_2494;
  args[1] = v_k2_2490;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam12(V self, V *args) {
  V v_hd_2497 = args[0];
  V v_k2_2498 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_2499 = heff_take_field(v_hd_2497, 1);
  V v_malg_24100 = heff_get_n(v_hd_2497, 2, 3);
  V v_t_24101 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24102 = heff_tr(heff_call(v_malg_24100, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24101})}));
  V f_ = v_bind_2499;
  args[0] = v_t_24102;
  args[1] = v_k2_2498;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam14(V self, V *args) {
  V v_x_24108 = args[0];
  V v_x_2488 = heff_env(self)[0];
  V v_x_27_24104 = heff_env(self)[1];
  V v_k_24107 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_hd_24106 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_24108);
  if (heff_strEq_c(v_x_2488, v_x_27_24104)) {
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 2);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 2);
    heff_drop_rec(v_hd_24106, 3);
    V f_ = v_k_24107;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_24109 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    V v_t_24110 = heff_tr(heff_call(heff_take_field(v_hd_24106, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24109})}));
    V f_ = heff_get_n(v_hd_24106, 1, 3);
    heff_room[0] = v_t_24110;
    heff_room[1] = v_k_24107;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam13(V self, V *args) {
  V v_hd_24106 = args[0];
  V v_k_24107 = args[1];
  V v_c_24105 = heff_env(self)[0];
  V v_x_2488 = heff_env(self)[1];
  V v_x_27_24104 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_24105;
  args[0] = heff_dup(v_hd_24106);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam14, 1, 9, (V[]){v_x_2488, v_x_27_24104, v_k_24107, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_24106});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam15(V self, V *args) {
  V v_hd_24114 = args[0];
  V v_k2_24115 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_24116 = heff_take_field(v_hd_24114, 1);
  V v_malg_24117 = heff_get_n(v_hd_24114, 2, 3);
  V v_t_24118 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24119 = heff_tr(heff_call(v_malg_24117, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24118})}));
  V f_ = v_bind_24116;
  args[0] = v_t_24119;
  args[1] = v_k2_24115;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam16(V self, V *args) {
  V v_hd_24123 = args[0];
  V v_k2_24124 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_24125 = heff_take_field(v_hd_24123, 1);
  V v_malg_24126 = heff_get_n(v_hd_24123, 2, 3);
  V v_t_24127 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24128 = heff_tr(heff_call(v_malg_24126, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24127})}));
  V f_ = v_bind_24125;
  args[0] = v_t_24128;
  args[1] = v_k2_24124;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam17(V self, V *args) {
  V v_hd_24131 = args[0];
  V v_k2_24132 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_24133 = heff_take_field(v_hd_24131, 1);
  V v_malg_24134 = heff_get_n(v_hd_24131, 2, 3);
  V v_t_24135 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24136 = heff_tr(heff_call(v_malg_24134, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24135})}));
  V f_ = v_bind_24133;
  args[0] = v_t_24136;
  args[1] = v_k2_24132;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam18(V self, V *args) {
  V v_hd_24139 = args[0];
  V v_k2_24140 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_24141 = heff_take_field(v_hd_24139, 1);
  V v_malg_24142 = heff_get_n(v_hd_24139, 2, 3);
  V v_t_24143 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24144 = heff_tr(heff_call(v_malg_24142, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24143})}));
  V f_ = v_bind_24141;
  args[0] = v_t_24144;
  args[1] = v_k2_24140;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam21(V self, V *args) {
  V v_hd_24152 = args[0];
  V v_k_24153 = args[1];
  heff_drop(v_hd_24152);
  V f_ = v_k_24153;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam22(V self, V *args) {
  V v_hd_24154 = args[0];
  V v_k2_24155 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_24156 = heff_take_field(v_hd_24154, 1);
  V v_malg_24157 = heff_get_n(v_hd_24154, 2, 3);
  V v_t_24158 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24159 = heff_tr(heff_call(v_malg_24157, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24158})}));
  V f_ = v_bind_24156;
  args[0] = v_t_24159;
  args[1] = v_k2_24155;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam23(V self, V *args) {
  V v_x_24161 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_24122 = heff_env(self)[2];
  V v_v_27_24147 = heff_env(self)[3];
  V v_hd_24149 = heff_env(self)[4];
  V v_k_24150 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24161);
  V v_t_24162 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2e_3c_2b_3e_24s419270740x1449981722_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_get()), v_g_240, v_cs_241, v_v_24122, v_v_27_24147));
  V f_ = v_t_24162;
  heff_room[0] = v_hd_24149;
  heff_room[1] = v_k_24150;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam20(V self, V *args) {
  V v_x_24151 = args[0];
  V v_x_24121 = heff_env(self)[0];
  V v_x_27_24146 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_h_242 = heff_env(self)[3];
  V v_sp_243 = heff_env(self)[4];
  V v_h_27_244 = heff_env(self)[5];
  V v_sp_27_245 = heff_env(self)[6];
  V v_hd_24149 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_24122 = heff_env(self)[9];
  V v_v_27_24147 = heff_env(self)[10];
  V v_k_24150 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_24151);
  V v_t_24160;
  if (heff_strEq_c(v_x_24121, v_x_27_24146)) {
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 3);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 3);
    v_t_24160 = ((V)&g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam21_clo);
  } else {
    v_t_24160 = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam22, 2, 5, (V[]){heff_dup(v_cs_241), v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
  }
  V f_ = v_t_24160;
  heff_room[0] = heff_dup(v_hd_24149);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam23, 1, 6, (V[]){v_g_240, v_cs_241, v_v_24122, v_v_27_24147, v_hd_24149, v_k_24150});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam19(V self, V *args) {
  V v_hd_24149 = args[0];
  V v_k_24150 = args[1];
  V v_c_24148 = heff_env(self)[0];
  V v_x_24121 = heff_env(self)[1];
  V v_x_27_24146 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_24122 = heff_env(self)[9];
  V v_v_27_24147 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_24148;
  args[0] = heff_dup(v_hd_24149);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam20, 1, 12, (V[]){v_x_24121, v_x_27_24146, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_24149, v_g_240, v_v_24122, v_v_27_24147, v_k_24150});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam4, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam7(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam7, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam0, 1, 1, (V[]){v_a0_242})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam1, 1, 5, (V[]){v_b0_243, v_hd_244, v_cs_241, v_k_245, v_g_240})});
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_b0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2410, 3, 8); V a_1 = v_b0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam4(V self, V *args) {
  V v_c_2460 = args[0];
  return heff_get_n(v_c_2460, 3, 8);
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam7(V self, V *args) {
  V v_c_2467 = args[0];
  return heff_get_n(v_c_2467, 3, 8);
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam8(V self, V *args) {
  V v_x_2470 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2471 = ({ V a_0 = v_x_2470; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2470); r_; });
  V v_t_2472 = heff_tr(heff_call(heff_get_n(v_t_2471, 1, 3), 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_241, 0, 2), v_x_2413}));
  return ({ V a_0 = v_t_2472; V a_1 = v_hd_244; V a_2 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2472); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam6(V self, V *args) {
  V v_x_2466 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2466);
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam7_clo)})});
  V v_t_2469 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2468}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2469;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam8, 1, 4, (V[]){v_cs_241, v_x_2413, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam5(V self, V *args) {
  V v_x_2463 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2464 = ({ V a_0 = v_x_2463; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2463); r_; });
  V v_t_2465 = heff_tr(heff_call(heff_get_n(v_t_2464, 1, 3), 3, (V[]){MK_INT(20LL), heff_dup(heff_rfield(v_cs_241, 0)), v_x_249}));
  return ({ V a_0 = v_t_2465; V a_1 = heff_dup(v_hd_244); V a_2 = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam6, 1, 4, (V[]){v_hd_244, v_cs_241, v_x_2413, v_k_245}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2465); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2436;
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2415 = heff_dup(heff_field(v_x_249, 0));
    switch (heff_tag_of(v_h_2415)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2415);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2459;
  if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
    heff_drop(v_t_2436);
    v_t_2459 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2436);
    switch (heff_tag_of(v_x_2413)) {
    case TAG_VU: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2438 = heff_dup(heff_field(v_x_2413, 0));
      switch (heff_tag_of(v_h_2438)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2459 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2438);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
  }
  if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
    heff_drop(v_g_240);
    heff_drop(v_t_2459);
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam4_clo)})});
    V v_t_2462 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2461}));
    V f_ = heff_dup(heff_rfield(v_hd_244, 1));
    heff_room[0] = v_t_2462;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam5, 1, 5, (V[]){v_cs_241, v_x_249, v_hd_244, v_x_2413, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2459);
    V v_t_2495;
    switch (heff_tag_of(v_x_249)) {
    case TAG_VU: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2474 = heff_dup(heff_field(v_x_249, 0));
      V v_sp_2475 = heff_dup(heff_field(v_x_249, 1));
      switch (heff_tag_of(v_t1_2474)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2474, 0ULL, 1);
        heff_drop(v_sp_2475);
        v_t_2495 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2474, 0ULL, 1);
        heff_drop(v_sp_2475);
        v_t_2495 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2481 = heff_field(v_t1_2474, 0);
        V v_ru_24t1_2474_24HMeta = heff_take_reuse_n(v_t1_2474, 1ULL, 1);
        v_t_2495 = heff_tag_at_n(v_ru_24t1_2474_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2481, v_sp_2475})});
        break;
      }
      case TAG_HError: {
        heff_drop(v_sp_2475);
        v_t_2495 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t1_2474);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VRecord: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFixed: {
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    switch (heff_tag_of(v_t_2495)) {
    case TAG_Nothing: {
      V v_t_24118;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        V v_t1_2497 = heff_dup(heff_field(v_x_2413, 0));
        V v_sp_2498 = heff_dup(heff_field(v_x_2413, 1));
        switch (heff_tag_of(v_t1_2497)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_2497, 0ULL, 1);
          heff_drop(v_sp_2498);
          v_t_24118 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_2497, 0ULL, 1);
          heff_drop(v_sp_2498);
          v_t_24118 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HMeta: {
          V v_m_24104 = heff_field(v_t1_2497, 0);
          V v_ru_24t1_2497_24HMeta = heff_take_reuse_n(v_t1_2497, 1ULL, 1);
          v_t_24118 = heff_tag_at_n(v_ru_24t1_2497_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24104, v_sp_2498})});
          break;
        }
        case TAG_HError: {
          heff_drop(v_sp_2498);
          v_t_24118 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t1_2497);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VRecord: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      switch (heff_tag_of(v_t_24118)) {
      case TAG_Nothing: {
        return (g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457(v_g_240, v_cs_241, v_x_249, v_x_2413, v_hd_244, v_k_245));
      }
      case TAG_Just: {
        V v_it1_24119 = heff_field(v_t_24118, 0);
        V v_ru_24t_24118_24Just = heff_take_reuse_n(v_t_24118, 1ULL, 1);
        switch (heff_tag_of(v_it1_24119)) {
        case TAG_MkPair: {
          V v_m_24120 = heff_field(v_it1_24119, 0);
          V v_sp_24121 = heff_field(v_it1_24119, 1);
          heff_take_n(v_it1_24119, 3ULL, 2);
          V v_rhs_24141;
          switch (heff_tag_of(v_x_249)) {
          case TAG_VU: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VDecode: {
            V v_el_24127 = heff_field(v_x_249, 4);
            heff_take_n(v_x_249, 16ULL, 5);
            heff_drop_cell(v_ru_24t_24118_24Just, 1);
            v_rhs_24141 = heff_tr(heff_call(v_el_24127, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VRecord: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VSum: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimInt: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimFloat: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimString: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimRune: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimArray: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VFixed: {
            v_rhs_24141 = heff_tag_at_n(v_ru_24t_24118_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          default: heff_nomatch(v_x_249);
          }
          V v_self_24161;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_VU: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VDecode: {
            V v_el_24147 = heff_field(v_x_2413, 4);
            heff_take_n(v_x_2413, 16ULL, 5);
            v_self_24161 = heff_tr(heff_call(v_el_24147, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VRecord: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VSum: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimInt: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimFloat: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimString: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimRune: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimArray: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VFixed: {
            v_self_24161 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          return (g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(v_g_240, v_cs_241, v_m_24120, v_sp_24121, v_rhs_24141, v_self_24161, v_hd_244, v_k_245));
        }
        default: return heff_nomatch(v_it1_24119);
        }
      }
      default: return heff_nomatch(v_t_24118);
      }
    }
    case TAG_Just: {
      V v_it1_24162 = heff_field(v_t_2495, 0);
      V v_ru_24t_2495_24Just = heff_take_reuse_n(v_t_2495, 1ULL, 1);
      switch (heff_tag_of(v_it1_24162)) {
      case TAG_MkPair: {
        V v_m_24163 = heff_field(v_it1_24162, 0);
        V v_sp_24164 = heff_field(v_it1_24162, 1);
        heff_take_n(v_it1_24162, 3ULL, 2);
        V v_rhs_24184;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VU: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VDecode: {
          V v_el_24170 = heff_field(v_x_2413, 4);
          heff_take_n(v_x_2413, 16ULL, 5);
          heff_drop_cell(v_ru_24t_2495_24Just, 1);
          v_rhs_24184 = heff_tr(heff_call(v_el_24170, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VRecord: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VSum: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimInt: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimFloat: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimString: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimRune: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimArray: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VFixed: {
          v_rhs_24184 = heff_tag_at_n(v_ru_24t_2495_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        V v_self_24204;
        switch (heff_tag_of(v_x_249)) {
        case TAG_VU: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VDecode: {
          V v_el_24190 = heff_field(v_x_249, 4);
          heff_take_n(v_x_249, 16ULL, 5);
          v_self_24204 = heff_tr(heff_call(v_el_24190, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VRecord: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VSum: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimInt: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimFloat: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimString: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimRune: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimArray: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VFixed: {
          v_self_24204 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        default: heff_nomatch(v_x_249);
        }
        return (g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(v_g_240, v_cs_241, v_m_24163, v_sp_24164, v_rhs_24184, v_self_24204, v_hd_244, v_k_245));
      }
      default: return heff_nomatch(v_it1_24162);
      }
    }
    default: return heff_nomatch(v_t_2495);
    }
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_b0_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam2, 1, 1, (V[]){v_b0_243})})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam3, 1, 5, (V[]){v_x_249, v_hd_244, v_cs_241, v_k_245, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2eunify_2eappendL_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eappendL_24tok2_entry, 3, 0};

V g_heff_2eelab_2eunify_2eappendL_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_heff_2eelab_2eunify_2eappendL_24dps(v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2eunify_2eappendL_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eappendL_24tok2(a[0], a[1], a[2]);
}