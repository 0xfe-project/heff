// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_end 310101
#define LBL_line 9817275
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
static uint32_t shape_line__col[] = {LBL_line, LBL_col};
V g_heff_2erender_2ecutLine(V, V, V);
V g_heff_2erender_2ecutLine_entry(V self, V *a);
extern Clo g_heff_2erender_2ecutLine_clo;
V g_heff_2erender_2efileDiag(V, V, V, V);
V g_heff_2erender_2efileDiag_entry(V self, V *a);
extern Clo g_heff_2erender_2efileDiag_clo;
V g_heff_2erender_2efirstLines(V, V, V, V, V);
V g_heff_2erender_2efirstLines_entry(V self, V *a);
extern Clo g_heff_2erender_2efirstLines_clo;
V g_heff_2erender_2egutterOf(V, V, V);
V g_heff_2erender_2egutterOf_entry(V self, V *a);
extern Clo g_heff_2erender_2egutterOf_clo;
V g_heff_2erender_2einsideLine(V, V, V, V, V);
V g_heff_2erender_2einsideLine_entry(V self, V *a);
extern Clo g_heff_2erender_2einsideLine_clo;
V g_heff_2erender_2einsideRange(V, V, V, V, V, V);
V g_heff_2erender_2einsideRange_entry(V self, V *a);
extern Clo g_heff_2erender_2einsideRange_clo;
V g_heff_2erender_2elineColGo(V, V, V, V);
V g_heff_2erender_2elineColGo_entry(V self, V *a);
extern Clo g_heff_2erender_2elineColGo_clo;
V g_heff_2erender_2elineStartFrom(V, V, V);
V g_heff_2erender_2elineStartFrom_entry(V self, V *a);
extern Clo g_heff_2erender_2elineStartFrom_clo;
V g_heff_2erender_2elineText(V, V);
V g_heff_2erender_2elineText_entry(V self, V *a);
extern Clo g_heff_2erender_2elineText_clo;
V g_heff_2erender_2elinesPretty(V, V, V, V);
V g_heff_2erender_2elinesPretty_entry(V self, V *a);
extern Clo g_heff_2erender_2elinesPretty_clo;
V g_heff_2erender_2elinesPrettyAt(V, V, V, V, V, V);
V g_heff_2erender_2elinesPrettyAt_entry(V self, V *a);
extern Clo g_heff_2erender_2elinesPrettyAt_clo;
V g_heff_2erender_2elongSpan_get(void);
V g_heff_2erender_2emiddleLines(V, V, V, V, V, V);
V g_heff_2erender_2emiddleLines_entry(V self, V *a);
extern Clo g_heff_2erender_2emiddleLines_clo;
V g_heff_2erender_2enumDigits(V);
V g_heff_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2erender_2enumDigits_clo;
V g_heff_2erender_2eoneLine(V, V, V, V, V, V);
V g_heff_2erender_2eoneLine_entry(V self, V *a);
extern Clo g_heff_2erender_2eoneLine_clo;
V g_heff_2erender_2eprtCode(V);
V g_heff_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2erender_2eprtCode_clo;
V g_heff_2erender_2erenderDiag(V, V, V);
V g_heff_2erender_2erenderDiag_entry(V self, V *a);
extern Clo g_heff_2erender_2erenderDiag_clo;
V g_heff_2erender_2erepeated(V, V);
V g_heff_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2erender_2erepeated_clo;
V g_heff_2erender_2espacesBefore(V, V);
V g_heff_2erender_2espacesBefore_entry(V self, V *a);
extern Clo g_heff_2erender_2espacesBefore_clo;
V g_heff_2erender_2espanLines(V, V, V, V, V, V);
V g_heff_2erender_2espanLines_entry(V self, V *a);
extern Clo g_heff_2erender_2espanLines_clo;
V g_prelude_2econcatList(V, V);
V g_prelude_2econcatList_entry(V self, V *a);
extern Clo g_prelude_2econcatList_clo;
V g_prelude_2efoldl_24s1939305664x1902528268(V, V, V);
V g_prelude_2efoldl_24s1939305664x1902528268_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1939305664x1902528268_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2elineColGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2erender_2elineColGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2elineColGo_entry, 4, 0};

V g_heff_2erender_2elineColGo(V v_src_240, V v_i_241, V v_l_242, V v_start_243) {
top: ;
  V v_t_244 = (g_prelude_2eindexFrom(((V)&g_heff_2erender_2elineColGo_str0), heff_dup(v_src_240), heff_dup(v_start_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_src_240);
    return heff_rec(2, shape_line__col, (V[]){v_l_242, heff_intSub(v_i_241, v_start_243)});
  }
  case TAG_Just: {
    V v_nl_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_t_246 = heff_intLe(heff_dup(v_i_241), heff_dup(v_nl_245));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_src_240);
      heff_drop(v_nl_245);
      return heff_rec(2, shape_line__col, (V[]){v_l_242, heff_intSub(v_i_241, v_start_243)});
    }
    case TAG_False: {
      heff_drop(v_start_243);
      V t_0 = v_src_240;
      V t_1 = v_i_241;
      V t_2 = heff_intAdd(v_l_242, MK_INT(1LL));
      V t_3 = heff_intAdd(v_nl_245, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_l_242 = t_2;
      v_start_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2erender_2elineColGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2elineColGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2erender_2enumDigits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2enumDigits_entry, 1, 0};

V g_heff_2erender_2enumDigits(V v_x_240) {
top: ;
  V v_t_241 = heff_intLt(heff_dup(v_x_240), MK_INT(10LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_x_240);
    return MK_INT(1LL);
  }
  case TAG_False: {
    V v_t_242 = heff_intDiv(v_x_240, MK_INT(10LL));
    V v_t_243 = (g_heff_2erender_2enumDigits(v_t_242));
    return heff_intAdd(MK_INT(1LL), v_t_243);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2erender_2enumDigits_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2enumDigits(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2erepeated_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2erender_2erepeated_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2erepeated_entry, 2, 0};

V g_heff_2erender_2erepeated(V v_k_240, V v_c_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_k_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_k_240);
    heff_drop(v_c_241);
    return ((V)&g_heff_2erender_2erepeated_str0);
  }
  case TAG_False: {
    return heff_strAppend(heff_dup(v_c_241), (g_heff_2erender_2erepeated(heff_intSub(v_k_240, MK_INT(1LL)), v_c_241)));
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2erender_2erepeated_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2erepeated(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2elineStartFrom_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2erender_2elineStartFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2elineStartFrom_entry, 3, 0};

V g_heff_2erender_2elineStartFrom(V v_src_240, V v_l_241, V v_start_242) {
top: ;
  V v_t_243 = (g_prelude_2eindexFrom(((V)&g_heff_2erender_2elineStartFrom_str0), heff_dup(v_src_240), v_start_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_l_241);
    return heff_strLength(v_src_240);
  }
  case TAG_Just: {
    V v_nl_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = heff_intEq(heff_dup(v_l_241), MK_INT(1LL));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_src_240);
      heff_drop(v_l_241);
      return heff_intAdd(v_nl_244, MK_INT(1LL));
    }
    case TAG_False: {
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_l_241, MK_INT(1LL));
      V t_2 = heff_intAdd(v_nl_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_l_241 = t_1;
      v_start_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2erender_2elineStartFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2elineStartFrom(a[0], a[1], a[2]);
}

static V g_heff_2erender_2elongSpan_val;
static int g_heff_2erender_2elongSpan_st;
static V g_heff_2erender_2elongSpan_init(void) {
  return MK_INT(6LL);
}
V g_heff_2erender_2elongSpan_get(void) {
  if (g_heff_2erender_2elongSpan_st == 2) return g_heff_2erender_2elongSpan_val;
  if (g_heff_2erender_2elongSpan_st == 1) heff_fail("defined by itself");
  g_heff_2erender_2elongSpan_st = 1;
  g_heff_2erender_2elongSpan_val = heff_tr(g_heff_2erender_2elongSpan_init());
  g_heff_2erender_2elongSpan_st = 2;
  return g_heff_2erender_2elongSpan_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2elineText_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2erender_2elineText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2elineText_entry, 2, 0};

V g_heff_2erender_2elineText(V v_src_240, V v_l_241) {
top: ;
  V v_t_242 = heff_intEq(heff_dup(v_l_241), MK_INT(0LL));
  V v_t_243;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    v_t_243 = MK_INT(0LL);
    break;
  }
  case TAG_False: {
    v_t_243 = (g_heff_2erender_2elineStartFrom(heff_dup(v_src_240), heff_dup(v_l_241), MK_INT(0LL)));
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_244 = heff_intEq(heff_dup(v_l_241), MK_INT(0LL));
  V v_start_245;
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_l_241);
    v_start_245 = MK_INT(0LL);
    break;
  }
  case TAG_False: {
    v_start_245 = (g_heff_2erender_2elineStartFrom(heff_dup(v_src_240), v_l_241, MK_INT(0LL)));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_246 = (g_prelude_2eindexFrom(((V)&g_heff_2erender_2elineText_str0), heff_dup(v_src_240), v_start_245));
  V v_t_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_t_248 = heff_strLength(heff_dup(v_src_240));
    break;
  }
  case TAG_Just: {
    V v_nl_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_t_248 = v_nl_247;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_strSlice(v_src_240, v_t_243, v_t_248);
}
V g_heff_2erender_2elineText_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2elineText(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2egutterOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erender_2egutterOf_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2egutterOf_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 50, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2egutterOf_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 48, 109}};
Clo g_heff_2erender_2egutterOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2egutterOf_entry, 3, 0};

V g_heff_2erender_2egutterOf(V v_color_240, V v_w_241, V v_l_242) {
top: ;
  V v_t_243 = heff_intShow(heff_intAdd(heff_dup(v_l_242), MK_INT(1LL)));
  V v_t_244 = (g_heff_2erender_2enumDigits(heff_intAdd(v_l_242, MK_INT(1LL))));
  V v_t_245 = (g_heff_2erender_2erepeated(heff_intSub(v_w_241, v_t_244), ((V)&g_heff_2erender_2egutterOf_str0)));
  V v_s_246 = heff_strAppend(v_t_243, heff_strAppend(v_t_245, ((V)&g_heff_2erender_2egutterOf_str1)));
  switch (heff_tag_of(v_color_240)) {
  case TAG_True: {
    V v_t_247 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2egutterOf_str2));
    return heff_strAppend(v_t_247, heff_strAppend(v_s_246, heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2egutterOf_str3))));
  }
  case TAG_False: {
    return v_s_246;
  }
  default: return heff_nomatch(v_color_240);
  }
}
V g_heff_2erender_2egutterOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erender_2egutterOf(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2einsideLine_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2einsideLine_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2einsideLine_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2einsideLine_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 48, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2einsideLine_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2einsideLine_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2einsideLine_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_heff_2erender_2einsideLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2einsideLine_entry, 5, 0};

V g_heff_2erender_2einsideLine(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_l_244) {
top: ;
  V v_t_245 = (g_heff_2erender_2egutterOf(v_color_240, v_w_243, heff_dup(v_l_244)));
  V v_t_247;
  switch (heff_tag_of(v_color_240)) {
  case TAG_True: {
    V v_t_246 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), heff_strAppend(((V)&g_heff_2erender_2einsideLine_str0), heff_strAppend(v_code_241, ((V)&g_heff_2erender_2einsideLine_str1))));
    v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2erender_2einsideLine_str2), heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2einsideLine_str3))));
    break;
  }
  case TAG_False: {
    heff_drop(v_code_241);
    v_t_247 = ((V)&g_heff_2erender_2einsideLine_str4);
    break;
  }
  default: heff_nomatch(v_color_240);
  }
  return heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2erender_2einsideLine_str5), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2erender_2einsideLine_str6), (g_heff_2erender_2elineText(v_src_242, v_l_244))))));
}
V g_heff_2erender_2einsideLine_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erender_2einsideLine(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2ecutLine_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 46, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2ecutLine_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2ecutLine_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 50, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2ecutLine_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 48, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2ecutLine_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2ecutLine_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2ecutLine_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2ecutLine_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 48, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2ecutLine_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2ecutLine_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_heff_2erender_2ecutLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2ecutLine_entry, 3, 0};

V g_heff_2erender_2ecutLine(V v_color_240, V v_code_241, V v_w_242) {
top: ;
  V v_s_243 = heff_strAppend(((V)&g_heff_2erender_2ecutLine_str0), (g_heff_2erender_2erepeated(heff_intSub(v_w_242, MK_INT(1LL)), ((V)&g_heff_2erender_2ecutLine_str1))));
  V v_t_245;
  switch (heff_tag_of(v_color_240)) {
  case TAG_True: {
    V v_t_244 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2ecutLine_str2));
    v_t_245 = heff_strAppend(v_t_244, heff_strAppend(v_s_243, heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2ecutLine_str3))));
    break;
  }
  case TAG_False: {
    v_t_245 = v_s_243;
    break;
  }
  default: heff_nomatch(v_color_240);
  }
  V v_t_247;
  switch (heff_tag_of(v_color_240)) {
  case TAG_True: {
    V v_t_246 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), heff_strAppend(((V)&g_heff_2erender_2ecutLine_str4), heff_strAppend(v_code_241, ((V)&g_heff_2erender_2ecutLine_str5))));
    v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2erender_2ecutLine_str6), heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2ecutLine_str7))));
    break;
  }
  case TAG_False: {
    heff_drop(v_code_241);
    v_t_247 = ((V)&g_heff_2erender_2ecutLine_str8);
    break;
  }
  default: heff_nomatch(v_color_240);
  }
  return heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2erender_2ecutLine_str9), v_t_247));
}
V g_heff_2erender_2ecutLine_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erender_2ecutLine(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2erender_2einsideRange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2einsideRange_entry, 6, 0};

V g_heff_2erender_2einsideRange(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_l_244, V v_le_245) {
top: ;
  V v_t_246 = heff_intLt(heff_dup(v_le_245), heff_dup(v_l_244));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_code_241);
    heff_drop(v_src_242);
    heff_drop(v_w_243);
    heff_drop(v_l_244);
    heff_drop(v_le_245);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    V v_t_247 = (g_heff_2erender_2einsideLine(v_color_240, heff_dup(v_code_241), heff_dup(v_src_242), heff_dup(v_w_243), heff_dup(v_l_244)));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_247, (g_heff_2erender_2einsideRange(v_color_240, v_code_241, v_src_242, v_w_243, heff_intAdd(v_l_244, MK_INT(1LL)), v_le_245))});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2erender_2einsideRange_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erender_2einsideRange(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); return r;
}
Clo g_heff_2erender_2emiddleLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2emiddleLines_entry, 6, 0};

V g_heff_2erender_2emiddleLines(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_ls_244, V v_le_245) {
top: ;
  V v_t_246 = heff_intAdd(heff_intSub(heff_dup(v_le_245), heff_dup(v_ls_244)), MK_INT(1LL));
  V v_t_247 = heff_intLt(heff_dup(g_heff_2erender_2elongSpan_get()), v_t_246);
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_t_248 = (g_heff_2erender_2einsideLine(v_color_240, heff_dup(v_code_241), heff_dup(v_src_242), heff_dup(v_w_243), heff_intAdd(v_ls_244, MK_INT(1LL))));
    V v_t_249 = (g_heff_2erender_2ecutLine(v_color_240, heff_dup(v_code_241), heff_dup(v_w_243)));
    V v_t_2410 = (g_heff_2erender_2einsideLine(v_color_240, v_code_241, v_src_242, v_w_243, heff_intSub(v_le_245, MK_INT(1LL))));
    V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_248, heff_tag(TAG_Cons, 2, (V[]){v_t_249, v_t_2411})});
  }
  case TAG_False: {
    HEFF_LAST return g_heff_2erender_2einsideRange(v_color_240, v_code_241, v_src_242, v_w_243, heff_intAdd(v_ls_244, MK_INT(1LL)), heff_intSub(v_le_245, MK_INT(1LL)));
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2erender_2emiddleLines_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erender_2emiddleLines(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2espacesBefore_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2erender_2espacesBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2espacesBefore_entry, 2, 0};

V g_heff_2erender_2espacesBefore(V v_src_240, V v_s_241) {
top: ;
  V v_l_242 = heff_get(heff_dup(v_s_241), LBL_line);
  V v_t_243 = heff_intEq(heff_dup(v_l_242), MK_INT(0LL));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_l_242);
    v_t_244 = MK_INT(0LL);
    break;
  }
  case TAG_False: {
    v_t_244 = (g_heff_2erender_2elineStartFrom(heff_dup(v_src_240), v_l_242, MK_INT(0LL)));
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_l_245 = heff_get(heff_dup(v_s_241), LBL_line);
  V v_t_246 = heff_intEq(heff_dup(v_l_245), MK_INT(0LL));
  V v_t_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_l_245);
    v_t_247 = MK_INT(0LL);
    break;
  }
  case TAG_False: {
    v_t_247 = (g_heff_2erender_2elineStartFrom(heff_dup(v_src_240), v_l_245, MK_INT(0LL)));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_248 = heff_intAdd(v_t_247, heff_get(v_s_241, LBL_col));
  V v_s_249 = heff_strSlice(v_src_240, v_t_244, v_t_248);
  V v_t_2410 = (g_prelude_2eskipSpaces(heff_dup(v_s_249), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2411 = heff_intSub(heff_strLength(heff_dup(v_s_249)), MK_INT(1LL));
  V v_t_2412 = (g_prelude_2eskipSpaces(heff_dup(v_s_249), v_t_2411, MK_INT(-1LL)));
  V v_t_2413 = heff_strSlice(v_s_249, v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
  return heff_strEq(v_t_2413, ((V)&g_heff_2erender_2espacesBefore_str0));
}
V g_heff_2erender_2espacesBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2espacesBefore(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efirstLines_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efirstLines_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efirstLines_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2efirstLines_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 48, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efirstLines_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efirstLines_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efirstLines_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2efirstLines_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efirstLines_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erender_2efirstLines_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2efirstLines_str10 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 50, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2efirstLines_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 48, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efirstLines_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efirstLines_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {94}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efirstLines_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efirstLines_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2efirstLines_str16 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 48, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erender_2efirstLines_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
Clo g_heff_2erender_2efirstLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2efirstLines_entry, 5, 0};

V g_heff_2erender_2efirstLines(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_s_244) {
top: ;
  V v_t_245 = (g_heff_2erender_2espacesBefore(heff_dup(v_src_242), heff_dup(v_s_244)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    V v_t_246 = (g_heff_2erender_2egutterOf(v_color_240, v_w_243, heff_get(heff_dup(v_s_244), LBL_line)));
    V v_t_248;
    switch (heff_tag_of(v_color_240)) {
    case TAG_True: {
      V v_t_247 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), heff_strAppend(((V)&g_heff_2erender_2efirstLines_str0), heff_strAppend(v_code_241, ((V)&g_heff_2erender_2efirstLines_str1))));
      v_t_248 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2erender_2efirstLines_str2), heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2efirstLines_str3))));
      break;
    }
    case TAG_False: {
      heff_drop(v_code_241);
      v_t_248 = ((V)&g_heff_2erender_2efirstLines_str4);
      break;
    }
    default: heff_nomatch(v_color_240);
    }
    V v_t_249 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2erender_2efirstLines_str5), heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2erender_2efirstLines_str6), (g_heff_2erender_2elineText(v_src_242, heff_get(v_s_244, LBL_line)))))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  }
  case TAG_False: {
    V v_t_2410 = (g_heff_2erender_2egutterOf(v_color_240, heff_dup(v_w_243), heff_get(heff_dup(v_s_244), LBL_line)));
    V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2erender_2efirstLines_str7), (g_heff_2erender_2elineText(v_src_242, heff_get(heff_dup(v_s_244), LBL_line)))));
    V v_t_2412 = (g_heff_2erender_2erepeated(v_w_243, ((V)&g_heff_2erender_2efirstLines_str8)));
    V v_s_2413 = heff_strAppend(v_t_2412, ((V)&g_heff_2erender_2efirstLines_str9));
    V v_t_2415;
    switch (heff_tag_of(v_color_240)) {
    case TAG_True: {
      V v_t_2414 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2efirstLines_str10));
      v_t_2415 = heff_strAppend(v_t_2414, heff_strAppend(v_s_2413, heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2efirstLines_str11))));
      break;
    }
    case TAG_False: {
      v_t_2415 = v_s_2413;
      break;
    }
    default: heff_nomatch(v_color_240);
    }
    V v_t_2416 = heff_intAdd(heff_get(v_s_244, LBL_col), MK_INT(1LL));
    V v_t_2417 = (g_heff_2erender_2erepeated(v_t_2416, ((V)&g_heff_2erender_2efirstLines_str12)));
    V v_s_2418 = heff_strAppend(v_t_2417, ((V)&g_heff_2erender_2efirstLines_str13));
    V v_t_2420;
    switch (heff_tag_of(v_color_240)) {
    case TAG_True: {
      V v_t_2419 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), heff_strAppend(((V)&g_heff_2erender_2efirstLines_str14), heff_strAppend(v_code_241, ((V)&g_heff_2erender_2efirstLines_str15))));
      v_t_2420 = heff_strAppend(v_t_2419, heff_strAppend(v_s_2418, heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2efirstLines_str16))));
      break;
    }
    case TAG_False: {
      heff_drop(v_code_241);
      v_t_2420 = v_s_2418;
      break;
    }
    default: heff_nomatch(v_color_240);
    }
    V v_t_2421 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2erender_2efirstLines_str17), v_t_2420));
    V v_t_2422 = heff_tag(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2411, v_t_2422});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2erender_2efirstLines_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erender_2efirstLines(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2espanLines_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erender_2espanLines_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2espanLines_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 50, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2espanLines_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 48, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2espanLines_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2espanLines_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2espanLines_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {94}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2espanLines_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2espanLines_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2espanLines_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 48, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2espanLines_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2espanLines_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2espanLines_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2erender_2espanLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2espanLines_entry, 6, 0};

V g_heff_2erender_2espanLines(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_s_244, V v_e_245) {
top: ;
  V v_t_246 = (g_heff_2erender_2efirstLines(v_color_240, heff_dup(v_code_241), heff_dup(v_src_242), heff_dup(v_w_243), heff_dup(v_s_244)));
  V v_t_247 = (g_heff_2erender_2emiddleLines(v_color_240, heff_dup(v_code_241), heff_dup(v_src_242), heff_dup(v_w_243), heff_get(v_s_244, LBL_line), heff_get(heff_dup(v_e_245), LBL_line)));
  V v_t_248 = (g_heff_2erender_2einsideLine(v_color_240, heff_dup(v_code_241), v_src_242, heff_dup(v_w_243), heff_get(heff_dup(v_e_245), LBL_line)));
  V v_t_249 = (g_heff_2erender_2erepeated(v_w_243, ((V)&g_heff_2erender_2espanLines_str0)));
  V v_s_2410 = heff_strAppend(v_t_249, ((V)&g_heff_2erender_2espanLines_str1));
  V v_t_2412;
  switch (heff_tag_of(v_color_240)) {
  case TAG_True: {
    V v_t_2411 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2espanLines_str2));
    v_t_2412 = heff_strAppend(v_t_2411, heff_strAppend(v_s_2410, heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2espanLines_str3))));
    break;
  }
  case TAG_False: {
    v_t_2412 = v_s_2410;
    break;
  }
  default: heff_nomatch(v_color_240);
  }
  V v_t_2413 = heff_intAdd(heff_get(v_e_245, LBL_col), MK_INT(1LL));
  V v_t_2414 = (g_heff_2erender_2erepeated(v_t_2413, ((V)&g_heff_2erender_2espanLines_str4)));
  V v_s_2415 = heff_strAppend(((V)&g_heff_2erender_2espanLines_str5), heff_strAppend(v_t_2414, ((V)&g_heff_2erender_2espanLines_str6)));
  V v_t_2417;
  switch (heff_tag_of(v_color_240)) {
  case TAG_True: {
    V v_t_2416 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), heff_strAppend(((V)&g_heff_2erender_2espanLines_str7), heff_strAppend(v_code_241, ((V)&g_heff_2erender_2espanLines_str8))));
    v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(v_s_2415, heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2espanLines_str9))));
    break;
  }
  case TAG_False: {
    heff_drop(v_code_241);
    v_t_2417 = v_s_2415;
    break;
  }
  default: heff_nomatch(v_color_240);
  }
  V v_t_2418 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2erender_2espanLines_str10), v_t_2417));
  V v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  V v_t_2420 = (g_prelude_2econcatList(v_t_247, heff_tag(TAG_Cons, 2, (V[]){v_t_248, v_t_2419})));
  V v_x2_2421 = (g_prelude_2econcatList(v_t_246, v_t_2420));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_Nil: {
    return ((V)&g_heff_2erender_2espanLines_str11);
  }
  case TAG_Cons: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_xs_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2erender_2espanLines_str12); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2erender_2espanLines_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erender_2espanLines(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eoneLine_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eoneLine_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eoneLine_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {94}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eoneLine_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eoneLine_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2eoneLine_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 48, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eoneLine_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eoneLine_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eoneLine_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_heff_2erender_2eoneLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2eoneLine_entry, 6, 0};

V g_heff_2erender_2eoneLine(V v_color_240, V v_code_241, V v_src_242, V v_sp_243, V v_w_244, V v_l_245) {
top: ;
  V v_t_246 = (g_heff_2erender_2egutterOf(v_color_240, heff_dup(v_w_244), heff_dup(v_l_245)));
  V v_t_247 = (g_heff_2erender_2elineText(heff_dup(v_src_242), heff_dup(v_l_245)));
  V v_t_248 = (g_heff_2erender_2egutterOf(v_color_240, v_w_244, heff_dup(v_l_245)));
  V v_t_249 = heff_intEq(heff_dup(v_l_245), MK_INT(0LL));
  V v_a_2410;
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    v_a_2410 = MK_INT(0LL);
    break;
  }
  case TAG_False: {
    v_a_2410 = (g_heff_2erender_2elineStartFrom(heff_dup(v_src_242), heff_dup(v_l_245), MK_INT(0LL)));
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_b_2411 = heff_get(heff_dup(v_sp_243), LBL_start);
  V v_t_2412 = heff_intLe(heff_dup(v_a_2410), heff_dup(v_b_2411));
  V v_t_2413;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_a_2410);
    v_t_2413 = v_b_2411;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_2411);
    v_t_2413 = v_a_2410;
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_t_2414 = heff_intEq(heff_dup(v_l_245), MK_INT(0LL));
  V v_t_2415;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    v_t_2415 = MK_INT(0LL);
    break;
  }
  case TAG_False: {
    v_t_2415 = (g_heff_2erender_2elineStartFrom(heff_dup(v_src_242), heff_dup(v_l_245), MK_INT(0LL)));
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_t_2416 = (g_heff_2erender_2erepeated(heff_intSub(v_t_2413, v_t_2415), ((V)&g_heff_2erender_2eoneLine_str0)));
  V v_t_2417 = heff_intEq(heff_dup(v_l_245), MK_INT(0LL));
  V v_start_2418;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    v_start_2418 = MK_INT(0LL);
    break;
  }
  case TAG_False: {
    v_start_2418 = (g_heff_2erender_2elineStartFrom(heff_dup(v_src_242), heff_dup(v_l_245), MK_INT(0LL)));
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  V v_t_2419 = (g_prelude_2eindexFrom(((V)&g_heff_2erender_2eoneLine_str1), heff_dup(v_src_242), v_start_2418));
  V v_a_2421;
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Nothing: {
    v_a_2421 = heff_strLength(heff_dup(v_src_242));
    break;
  }
  case TAG_Just: {
    V v_nl_2420 = heff_field(v_t_2419, 0);
    heff_take_n(v_t_2419, 1ULL, 1);
    v_a_2421 = v_nl_2420;
    break;
  }
  default: heff_nomatch(v_t_2419);
  }
  V v_b_2422 = heff_get(heff_dup(v_sp_243), LBL_end);
  V v_t_2423 = heff_intLe(heff_dup(v_a_2421), heff_dup(v_b_2422));
  V v_t_2424;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    heff_drop(v_b_2422);
    v_t_2424 = v_a_2421;
    break;
  }
  case TAG_False: {
    heff_drop(v_a_2421);
    v_t_2424 = v_b_2422;
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_t_2425 = heff_intEq(heff_dup(v_l_245), MK_INT(0LL));
  V v_a_2426;
  switch (heff_tag_of(v_t_2425)) {
  case TAG_True: {
    heff_drop(v_src_242);
    heff_drop(v_l_245);
    v_a_2426 = MK_INT(0LL);
    break;
  }
  case TAG_False: {
    v_a_2426 = (g_heff_2erender_2elineStartFrom(v_src_242, v_l_245, MK_INT(0LL)));
    break;
  }
  default: heff_nomatch(v_t_2425);
  }
  V v_b_2427 = heff_get(v_sp_243, LBL_start);
  V v_t_2428 = heff_intLe(heff_dup(v_a_2426), heff_dup(v_b_2427));
  V v_t_2429;
  switch (heff_tag_of(v_t_2428)) {
  case TAG_True: {
    heff_drop(v_a_2426);
    v_t_2429 = v_b_2427;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_2427);
    v_t_2429 = v_a_2426;
    break;
  }
  default: heff_nomatch(v_t_2428);
  }
  V v_b_2430 = heff_intSub(v_t_2424, v_t_2429);
  V v_t_2431 = heff_intLe(MK_INT(1LL), heff_dup(v_b_2430));
  V v_t_2432;
  switch (heff_tag_of(v_t_2431)) {
  case TAG_True: {
    v_t_2432 = v_b_2430;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_2430);
    v_t_2432 = MK_INT(1LL);
    break;
  }
  default: heff_nomatch(v_t_2431);
  }
  V v_s_2433 = (g_heff_2erender_2erepeated(v_t_2432, ((V)&g_heff_2erender_2eoneLine_str2)));
  V v_t_2435;
  switch (heff_tag_of(v_color_240)) {
  case TAG_True: {
    V v_t_2434 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), heff_strAppend(((V)&g_heff_2erender_2eoneLine_str3), heff_strAppend(v_code_241, ((V)&g_heff_2erender_2eoneLine_str4))));
    v_t_2435 = heff_strAppend(v_t_2434, heff_strAppend(v_s_2433, heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2eoneLine_str5))));
    break;
  }
  case TAG_False: {
    heff_drop(v_code_241);
    v_t_2435 = v_s_2433;
    break;
  }
  default: heff_nomatch(v_color_240);
  }
  return heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2erender_2eoneLine_str6), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2erender_2eoneLine_str7), heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2erender_2eoneLine_str8), heff_strAppend(v_t_2416, v_t_2435)))))));
}
V g_heff_2erender_2eoneLine_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erender_2eoneLine(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); return r;
}
Clo g_heff_2erender_2elinesPrettyAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2elinesPrettyAt_entry, 6, 0};

V g_heff_2erender_2elinesPrettyAt(V v_color_240, V v_code_241, V v_src_242, V v_sp_243, V v_s_244, V v_e_245) {
top: ;
  V v_t_246 = heff_intEq(heff_get(heff_dup(v_s_244), LBL_line), heff_get(heff_dup(v_e_245), LBL_line));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_e_245);
    V v_t_247 = heff_intAdd(heff_get(heff_dup(v_s_244), LBL_line), MK_INT(1LL));
    V v_t_248 = (g_heff_2erender_2enumDigits(v_t_247));
    HEFF_LAST return g_heff_2erender_2eoneLine(v_color_240, v_code_241, v_src_242, v_sp_243, v_t_248, heff_get(v_s_244, LBL_line));
  }
  case TAG_False: {
    heff_drop(v_sp_243);
    V v_t_249 = heff_intAdd(heff_get(heff_dup(v_e_245), LBL_line), MK_INT(1LL));
    V v_t_2410 = (g_heff_2erender_2enumDigits(v_t_249));
    HEFF_LAST return g_heff_2erender_2espanLines(v_color_240, v_code_241, v_src_242, v_t_2410, v_s_244, v_e_245);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2erender_2elinesPrettyAt_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erender_2elinesPrettyAt(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); return r;
}
Clo g_heff_2erender_2elinesPretty_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2elinesPretty_entry, 4, 0};

V g_heff_2erender_2elinesPretty(V v_color_240, V v_code_241, V v_src_242, V v_sp_243) {
top: ;
  V v_t_244 = (g_heff_2erender_2elineColGo(heff_dup(v_src_242), heff_get(heff_dup(v_sp_243), LBL_start), MK_INT(0LL), MK_INT(0LL)));
  V v_a_245 = heff_get(heff_dup(v_sp_243), LBL_start);
  V v_b_246 = heff_intSub(heff_get(heff_dup(v_sp_243), LBL_end), MK_INT(1LL));
  V v_t_247 = heff_intLe(heff_dup(v_a_245), heff_dup(v_b_246));
  V v_i_248;
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_a_245);
    v_i_248 = v_b_246;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_246);
    v_i_248 = v_a_245;
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_249 = (g_heff_2erender_2elineColGo(heff_dup(v_src_242), v_i_248, MK_INT(0LL), MK_INT(0LL)));
  return (g_heff_2erender_2elinesPrettyAt(v_color_240, v_code_241, v_src_242, v_sp_243, v_t_244, v_t_249));
}
V g_heff_2erender_2elinesPretty_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erender_2elinesPretty(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erender_2eprtCode_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {101, 114, 114, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2erender_2eprtCode_str1 = {{0x80000000u, K_STR, 0}, 7, 7, {119, 97, 114, 110, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erender_2eprtCode_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {100, 101, 98, 117, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprtCode_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprtCode_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {87}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprtCode_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {68}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprtCode_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprtCode_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprtCode_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
Clo g_heff_2erender_2eprtCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2eprtCode_entry, 1, 0};

V g_heff_2erender_2eprtCode(V v_d_240) {
top: ;
  V v_t_241 = heff_get(heff_dup(v_d_240), LBL_severity);
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SError: {
    v_t_242 = ((V)&g_heff_2erender_2eprtCode_str0);
    break;
  }
  case TAG_SWarning: {
    v_t_242 = ((V)&g_heff_2erender_2eprtCode_str1);
    break;
  }
  case TAG_SDebug: {
    v_t_242 = ((V)&g_heff_2erender_2eprtCode_str2);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_243 = heff_get(heff_dup(v_d_240), LBL_severity);
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SError: {
    v_t_244 = ((V)&g_heff_2erender_2eprtCode_str3);
    break;
  }
  case TAG_SWarning: {
    v_t_244 = ((V)&g_heff_2erender_2eprtCode_str4);
    break;
  }
  case TAG_SDebug: {
    v_t_244 = ((V)&g_heff_2erender_2eprtCode_str5);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = (g_heff_2erender_2enumDigits(heff_get(heff_dup(v_d_240), LBL_code)));
  V v_t_246 = (g_heff_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_245), ((V)&g_heff_2erender_2eprtCode_str6)));
  V v_t_247 = heff_intShow(heff_get(v_d_240, LBL_code));
  return heff_strAppend(v_t_242, heff_strAppend(((V)&g_heff_2erender_2eprtCode_str7), heff_strAppend(v_t_244, heff_strAppend(v_t_246, heff_strAppend(v_t_247, ((V)&g_heff_2erender_2eprtCode_str8))))));
}
V g_heff_2erender_2eprtCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2eprtCode(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2erender_2erenderDiag_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {49, 59, 51, 49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2erender_2erenderDiag_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {49, 59, 51, 51}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2erender_2erenderDiag_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {49, 59, 51, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2erenderDiag_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2erenderDiag_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erender_2erenderDiag_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 48, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2erender_2erenderDiag_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {49, 59, 51, 49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2erender_2erenderDiag_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {49, 59, 51, 51}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2erender_2erenderDiag_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {49, 59, 51, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2erenderDiag_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2erenderDiag_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erender_2erenderDiag_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2erenderDiag_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2erender_2erenderDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2erenderDiag_entry, 3, 0};

V g_heff_2erender_2erenderDiag(V v_color_240, V v_src_241, V v_d_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_d_242), LBL_severity);
  V v_code_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SError: {
    v_code_244 = ((V)&g_heff_2erender_2erenderDiag_str0);
    break;
  }
  case TAG_SWarning: {
    v_code_244 = ((V)&g_heff_2erender_2erenderDiag_str1);
    break;
  }
  case TAG_SDebug: {
    v_code_244 = ((V)&g_heff_2erender_2erenderDiag_str2);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_s_245 = (g_heff_2erender_2eprtCode(heff_dup(v_d_242)));
  V v_t_247;
  switch (heff_tag_of(v_color_240)) {
  case TAG_True: {
    V v_t_246 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), heff_strAppend(((V)&g_heff_2erender_2erenderDiag_str3), heff_strAppend(v_code_244, ((V)&g_heff_2erender_2erenderDiag_str4))));
    v_t_247 = heff_strAppend(v_t_246, heff_strAppend(v_s_245, heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2erender_2erenderDiag_str5))));
    break;
  }
  case TAG_False: {
    heff_drop(v_code_244);
    v_t_247 = v_s_245;
    break;
  }
  default: heff_nomatch(v_color_240);
  }
  V v_t_248 = heff_get(heff_dup(v_d_242), LBL_severity);
  V v_t_249;
  switch (heff_tag_of(v_t_248)) {
  case TAG_SError: {
    v_t_249 = ((V)&g_heff_2erender_2erenderDiag_str6);
    break;
  }
  case TAG_SWarning: {
    v_t_249 = ((V)&g_heff_2erender_2erenderDiag_str7);
    break;
  }
  case TAG_SDebug: {
    v_t_249 = ((V)&g_heff_2erender_2erenderDiag_str8);
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2410 = (g_heff_2erender_2elinesPretty(v_color_240, v_t_249, v_src_241, heff_get(heff_dup(v_d_242), LBL_span)));
  V v_t_2411 = heff_get(heff_dup(v_d_242), LBL_note);
  V v_t_2413;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    v_t_2413 = ((V)&g_heff_2erender_2erenderDiag_str9);
    break;
  }
  case TAG_Just: {
    V v_n_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 1);
    v_t_2413 = heff_strAppend(((V)&g_heff_2erender_2erenderDiag_str10), v_n_2412);
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  return heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2erender_2erenderDiag_str11), heff_strAppend(heff_get(v_d_242, LBL_msg), heff_strAppend(((V)&g_heff_2erender_2erenderDiag_str12), heff_strAppend(v_t_2410, v_t_2413)))));
}
V g_heff_2erender_2erenderDiag_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erender_2erenderDiag(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efileDiag_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efileDiag_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efileDiag_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erender_2efileDiag_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {10, 10}};
Clo g_heff_2erender_2efileDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2efileDiag_entry, 4, 0};

V g_heff_2erender_2efileDiag(V v_color_240, V v_path_241, V v_src_242, V v_d_243) {
top: ;
  V v_t_244 = heff_get(heff_get(heff_dup(v_d_243), LBL_span), LBL_start);
  V v_t_245 = (g_heff_2erender_2elineColGo(heff_dup(v_src_242), v_t_244, MK_INT(0LL), MK_INT(0LL)));
  V v_t_246 = heff_intAdd(heff_get(v_t_245, LBL_line), MK_INT(1LL));
  V v_t_247 = heff_get(heff_get(heff_dup(v_d_243), LBL_span), LBL_start);
  V v_t_248 = (g_heff_2erender_2elineColGo(heff_dup(v_src_242), v_t_247, MK_INT(0LL), MK_INT(0LL)));
  V v_t_249 = heff_intAdd(heff_get(v_t_248, LBL_col), MK_INT(1LL));
  V v_t_2410 = (g_heff_2erender_2erenderDiag(v_color_240, v_src_242, v_d_243));
  return heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2erender_2efileDiag_str0), heff_strAppend(heff_intShow(v_t_246), heff_strAppend(((V)&g_heff_2erender_2efileDiag_str1), heff_strAppend(heff_intShow(v_t_249), heff_strAppend(((V)&g_heff_2erender_2efileDiag_str2), heff_strAppend(v_t_2410, ((V)&g_heff_2erender_2efileDiag_str3))))))));
}
V g_heff_2erender_2efileDiag_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erender_2efileDiag(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}