// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2elineColGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2erender_2elineColGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2elineColGo_entry, 4, 0};

V g_heff_2erender_2elineColGo(V v_src_240, V v_i_241, V v_l_242, V v_start_243) {
top: ;
  V v_t_244 = (g_prelude_2eindexFrom(((V)&g_heff_2erender_2elineColGo_str0), heff_dup(v_src_240), heff_dup(v_start_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_src_240);
    heff_drop(v_t_244);
    return heff_rec(2, shape_167_45, (V[]){v_l_242, heff_intSub(v_i_241, v_start_243)});
  }
  case TAG_Just: {
    V v_nl_245 = heff_field(v_t_244, 0);
    heff_take(v_t_244, 1ULL);
    V v_t_246 = heff_intLe(heff_dup(v_i_241), heff_dup(v_nl_245));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_src_240);
      heff_drop(v_nl_245);
      heff_drop(v_t_246);
      return heff_rec(2, shape_167_45, (V[]){v_l_242, heff_intSub(v_i_241, v_start_243)});
    }
    case TAG_False: {
      heff_drop(v_start_243);
      heff_drop(v_t_246);
      V t_0 = v_src_240;
      V t_1 = v_i_241;
      V t_2 = heff_intAdd(v_l_242, MK_INT(1LL));
      V t_3 = heff_intAdd(v_nl_245, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_l_242 = t_2;
      v_start_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2erender_2elineColGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2elineColGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2erender_2enumDigits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2enumDigits_entry, 1, 0};

V g_heff_2erender_2enumDigits(V v_x_240) {
top: ;
  V v_t_241 = heff_intLt(heff_dup(v_x_240), MK_INT(10LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_x_240);
    heff_drop(v_t_241);
    return MK_INT(1LL);
  }
  case TAG_False: {
    heff_drop(v_t_241);
    V v_t_242 = heff_intDiv(v_x_240, MK_INT(10LL));
    V v_t_243 = (g_heff_2erender_2enumDigits(v_t_242));
    return heff_intAdd(MK_INT(1LL), v_t_243);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2erender_2enumDigits_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2enumDigits(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2erepeated_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2erender_2erepeated_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2erepeated_entry, 2, 0};

V g_heff_2erender_2erepeated(V v_k_240, V v_c_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_k_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_k_240);
    heff_drop(v_c_241);
    heff_drop(v_t_242);
    return ((V)&g_heff_2erender_2erepeated_str0);
  }
  case TAG_False: {
    heff_drop(v_t_242);
    return heff_strAppend(heff_dup(v_c_241), (g_heff_2erender_2erepeated(heff_intSub(v_k_240, MK_INT(1LL)), v_c_241)));
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2erender_2erepeated_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2erepeated(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2elineStartFrom_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2erender_2elineStartFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2elineStartFrom_entry, 3, 0};

V g_heff_2erender_2elineStartFrom(V v_src_240, V v_l_241, V v_start_242) {
top: ;
  V v_t_243 = (g_prelude_2eindexFrom(((V)&g_heff_2erender_2elineStartFrom_str0), heff_dup(v_src_240), v_start_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_l_241);
    heff_drop(v_t_243);
    return heff_strLength(v_src_240);
  }
  case TAG_Just: {
    V v_nl_244 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    V v_t_245 = heff_intEq(heff_dup(v_l_241), MK_INT(1LL));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_src_240);
      heff_drop(v_l_241);
      heff_drop(v_t_245);
      return heff_intAdd(v_nl_244, MK_INT(1LL));
    }
    case TAG_False: {
      heff_drop(v_t_245);
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_l_241, MK_INT(1LL));
      V t_2 = heff_intAdd(v_nl_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_l_241 = t_1;
      v_start_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2erender_2elineStartFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2elineStartFrom(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprettyAt_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erender_2eprettyAt_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprettyAt_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprettyAt_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprettyAt_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprettyAt_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprettyAt_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {94}};
Clo g_heff_2erender_2eprettyAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2eprettyAt_entry, 6, 0};

V g_heff_2erender_2eprettyAt(V v_src_240, V v_sp_241, V v_w_242, V v_l_243, V v_lstart_244, V v_lend_245) {
top: ;
  V v_t_246 = heff_intShow(heff_intAdd(heff_dup(v_l_243), MK_INT(1LL)));
  V v_t_247 = (g_heff_2erender_2enumDigits(heff_intAdd(v_l_243, MK_INT(1LL))));
  V v_t_248 = (g_heff_2erender_2erepeated(heff_intSub(v_w_242, v_t_247), ((V)&g_heff_2erender_2eprettyAt_str0)));
  V v_gutter_249 = heff_strAppend(v_t_246, heff_strAppend(v_t_248, ((V)&g_heff_2erender_2eprettyAt_str1)));
  V v_b_2410 = heff_get(heff_dup(v_sp_241), LBL_start);
  V v_t_2411 = heff_intLe(heff_dup(v_lstart_244), heff_dup(v_b_2410));
  V v_t_2412;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    heff_drop(v_t_2411);
    v_t_2412 = v_b_2410;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_2410);
    heff_drop(v_t_2411);
    v_t_2412 = heff_dup(v_lstart_244);
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_ns_2413 = heff_intSub(v_t_2412, heff_dup(v_lstart_244));
  V v_b_2414 = heff_get(heff_dup(v_sp_241), LBL_end);
  V v_t_2415 = heff_intLe(heff_dup(v_lend_245), heff_dup(v_b_2414));
  V v_t_2416;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    heff_drop(v_b_2414);
    heff_drop(v_t_2415);
    v_t_2416 = heff_dup(v_lend_245);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2415);
    v_t_2416 = v_b_2414;
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_b_2417 = heff_get(v_sp_241, LBL_start);
  V v_t_2418 = heff_intLe(heff_dup(v_lstart_244), heff_dup(v_b_2417));
  V v_t_2419;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    heff_drop(v_t_2418);
    v_t_2419 = v_b_2417;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_2417);
    heff_drop(v_t_2418);
    v_t_2419 = heff_dup(v_lstart_244);
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_b_2420 = heff_intSub(v_t_2416, v_t_2419);
  V v_t_2421 = heff_intLe(MK_INT(1LL), heff_dup(v_b_2420));
  V v_nc_2422;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_True: {
    heff_drop(v_t_2421);
    v_nc_2422 = v_b_2420;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_2420);
    heff_drop(v_t_2421);
    v_nc_2422 = MK_INT(1LL);
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V v_t_2423 = (g_heff_2erender_2erepeated(v_ns_2413, ((V)&g_heff_2erender_2eprettyAt_str2)));
  return heff_strAppend(heff_dup(v_gutter_249), heff_strAppend(((V)&g_heff_2erender_2eprettyAt_str3), heff_strAppend(heff_strSlice(v_src_240, v_lstart_244, v_lend_245), heff_strAppend(((V)&g_heff_2erender_2eprettyAt_str4), heff_strAppend(v_gutter_249, heff_strAppend(((V)&g_heff_2erender_2eprettyAt_str5), heff_strAppend(v_t_2423, (g_heff_2erender_2erepeated(v_nc_2422, ((V)&g_heff_2erender_2eprettyAt_str6))))))))));
}
V g_heff_2erender_2eprettyAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2eprettyAt(a[0], a[1], a[2], a[3], a[4], a[5]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprettyLine_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2erender_2eprettyLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2eprettyLine_entry, 4, 0};

V g_heff_2erender_2eprettyLine(V v_src_240, V v_sp_241, V v_w_242, V v_l_243) {
top: ;
  V v_t_244 = heff_intEq(heff_dup(v_l_243), MK_INT(0LL));
  V v_t_245;
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    v_t_245 = MK_INT(0LL);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_244);
    v_t_245 = (g_heff_2erender_2elineStartFrom(heff_dup(v_src_240), heff_dup(v_l_243), MK_INT(0LL)));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_246 = heff_intEq(heff_dup(v_l_243), MK_INT(0LL));
  V v_start_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_t_246);
    v_start_247 = MK_INT(0LL);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_246);
    v_start_247 = (g_heff_2erender_2elineStartFrom(heff_dup(v_src_240), heff_dup(v_l_243), MK_INT(0LL)));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_248 = (g_prelude_2eindexFrom(((V)&g_heff_2erender_2eprettyLine_str0), heff_dup(v_src_240), v_start_247));
  V v_t_2410;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop(v_t_248);
    v_t_2410 = heff_strLength(heff_dup(v_src_240));
    break;
  }
  case TAG_Just: {
    V v_nl_249 = heff_field(v_t_248, 0);
    heff_take(v_t_248, 1ULL);
    v_t_2410 = v_nl_249;
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  return (g_heff_2erender_2eprettyAt(v_src_240, v_sp_241, v_w_242, v_l_243, v_t_245, v_t_2410));
}
V g_heff_2erender_2eprettyLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2eprettyLine(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2erender_2elineRange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2elineRange_entry, 5, 0};

V g_heff_2erender_2elineRange(V v_src_240, V v_sp_241, V v_w_242, V v_l_243, V v_le_244) {
top: ;
  V v_t_245 = heff_intLt(heff_dup(v_le_244), heff_dup(v_l_243));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_src_240);
    heff_drop(v_sp_241);
    heff_drop(v_w_242);
    heff_drop(v_l_243);
    heff_drop(v_le_244);
    heff_drop(v_t_245);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    heff_drop(v_t_245);
    V v_t_246 = (g_heff_2erender_2eprettyLine(heff_dup(v_src_240), heff_dup(v_sp_241), heff_dup(v_w_242), heff_dup(v_l_243)));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_246, (g_heff_2erender_2elineRange(v_src_240, v_sp_241, v_w_242, heff_intAdd(v_l_243, MK_INT(1LL)), v_le_244))});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2erender_2elineRange_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2elineRange(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2elinesPretty_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2erender_2elinesPretty_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2elinesPretty_entry, 2, 0};

V g_heff_2erender_2elinesPretty(V v_src_240, V v_sp_241) {
top: ;
  V v_t_242 = (g_heff_2erender_2elineColGo(heff_dup(v_src_240), heff_get(heff_dup(v_sp_241), LBL_start), MK_INT(0LL), MK_INT(0LL)));
  V v_a_243 = (g_heff_2erender_2enumDigits(heff_get(v_t_242, LBL_line)));
  V v_t_244 = (g_heff_2erender_2elineColGo(heff_dup(v_src_240), heff_get(heff_dup(v_sp_241), LBL_end), MK_INT(0LL), MK_INT(0LL)));
  V v_b_245 = (g_heff_2erender_2enumDigits(heff_get(v_t_244, LBL_line)));
  V v_t_246 = heff_intLe(heff_dup(v_a_243), heff_dup(v_b_245));
  V v_t_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_a_243);
    heff_drop(v_t_246);
    v_t_247 = v_b_245;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_245);
    heff_drop(v_t_246);
    v_t_247 = v_a_243;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_248 = (g_heff_2erender_2elineColGo(heff_dup(v_src_240), heff_get(heff_dup(v_sp_241), LBL_start), MK_INT(0LL), MK_INT(0LL)));
  V v_t_249 = (g_heff_2erender_2elineColGo(heff_dup(v_src_240), heff_get(heff_dup(v_sp_241), LBL_end), MK_INT(0LL), MK_INT(0LL)));
  V v_x2_2410 = (g_heff_2erender_2elineRange(v_src_240, v_sp_241, v_t_247, heff_get(v_t_248, LBL_line), heff_get(v_t_249, LBL_line)));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_x2_2410);
    return ((V)&g_heff_2erender_2elinesPretty_str0);
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take(v_x2_2410, 3ULL);
    return ({ V a_0 = v_x_2411; V a_1 = v_xs_2412; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2412); r_; });
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2erender_2elinesPretty_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2elinesPretty(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erender_2eprtCode_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {101, 114, 114, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2erender_2eprtCode_str1 = {{0x80000000u, K_STR, 0}, 7, 7, {119, 97, 114, 110, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erender_2eprtCode_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {100, 101, 98, 117, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprtCode_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprtCode_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {87}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprtCode_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {68}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprtCode_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprtCode_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2eprtCode_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
Clo g_heff_2erender_2eprtCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2eprtCode_entry, 1, 0};

V g_heff_2erender_2eprtCode(V v_d_240) {
top: ;
  V v_t_241 = heff_get(heff_dup(v_d_240), LBL_severity);
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SError: {
    heff_drop(v_t_241);
    v_t_242 = ((V)&g_heff_2erender_2eprtCode_str0);
    break;
  }
  case TAG_SWarning: {
    heff_drop(v_t_241);
    v_t_242 = ((V)&g_heff_2erender_2eprtCode_str1);
    break;
  }
  case TAG_SDebug: {
    heff_drop(v_t_241);
    v_t_242 = ((V)&g_heff_2erender_2eprtCode_str2);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_243 = heff_get(heff_dup(v_d_240), LBL_severity);
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SError: {
    heff_drop(v_t_243);
    v_t_244 = ((V)&g_heff_2erender_2eprtCode_str3);
    break;
  }
  case TAG_SWarning: {
    heff_drop(v_t_243);
    v_t_244 = ((V)&g_heff_2erender_2eprtCode_str4);
    break;
  }
  case TAG_SDebug: {
    heff_drop(v_t_243);
    v_t_244 = ((V)&g_heff_2erender_2eprtCode_str5);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = (g_heff_2erender_2enumDigits(heff_get(heff_dup(v_d_240), LBL_code)));
  V v_t_246 = (g_heff_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_245), ((V)&g_heff_2erender_2eprtCode_str6)));
  V v_t_247 = heff_intShow(heff_get(v_d_240, LBL_code));
  return heff_strAppend(v_t_242, heff_strAppend(((V)&g_heff_2erender_2eprtCode_str7), heff_strAppend(v_t_244, heff_strAppend(v_t_246, heff_strAppend(v_t_247, ((V)&g_heff_2erender_2eprtCode_str8))))));
}
V g_heff_2erender_2eprtCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2eprtCode(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efileDiag_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efileDiag_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erender_2efileDiag_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efileDiag_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efileDiag_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efileDiag_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erender_2efileDiag_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erender_2efileDiag_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {10, 10}};
Clo g_heff_2erender_2efileDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erender_2efileDiag_entry, 3, 0};

V g_heff_2erender_2efileDiag(V v_path_240, V v_src_241, V v_d_242) {
top: ;
  V v_t_243 = heff_get(heff_get(heff_dup(v_d_242), LBL_span), LBL_start);
  V v_t_244 = (g_heff_2erender_2elineColGo(heff_dup(v_src_241), v_t_243, MK_INT(0LL), MK_INT(0LL)));
  V v_t_245 = heff_intAdd(heff_get(v_t_244, LBL_line), MK_INT(1LL));
  V v_t_246 = heff_get(heff_get(heff_dup(v_d_242), LBL_span), LBL_start);
  V v_t_247 = (g_heff_2erender_2elineColGo(heff_dup(v_src_241), v_t_246, MK_INT(0LL), MK_INT(0LL)));
  V v_t_248 = heff_intAdd(heff_get(v_t_247, LBL_col), MK_INT(1LL));
  V v_t_249 = (g_heff_2erender_2eprtCode(heff_dup(v_d_242)));
  V v_t_2410 = (g_heff_2erender_2elinesPretty(v_src_241, heff_get(heff_dup(v_d_242), LBL_span)));
  V v_t_2411 = heff_get(heff_dup(v_d_242), LBL_note);
  V v_t_2413;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    heff_drop(v_t_2411);
    v_t_2413 = ((V)&g_heff_2erender_2efileDiag_str0);
    break;
  }
  case TAG_Just: {
    V v_n_2412 = heff_field(v_t_2411, 0);
    heff_take(v_t_2411, 1ULL);
    v_t_2413 = heff_strAppend(((V)&g_heff_2erender_2efileDiag_str1), v_n_2412);
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_t_2414 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2erender_2efileDiag_str2), heff_strAppend(heff_get(v_d_242, LBL_msg), heff_strAppend(((V)&g_heff_2erender_2efileDiag_str3), heff_strAppend(v_t_2410, v_t_2413)))));
  return heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2erender_2efileDiag_str4), heff_strAppend(heff_intShow(v_t_245), heff_strAppend(((V)&g_heff_2erender_2efileDiag_str5), heff_strAppend(heff_intShow(v_t_248), heff_strAppend(((V)&g_heff_2erender_2efileDiag_str6), heff_strAppend(v_t_2414, ((V)&g_heff_2erender_2efileDiag_str7))))))));
}
V g_heff_2erender_2efileDiag_entry(V self, V *a) {
  (void)self;
  return g_heff_2erender_2efileDiag(a[0], a[1], a[2]);
}