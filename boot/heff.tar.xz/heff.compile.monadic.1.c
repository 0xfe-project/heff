// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
V g_heff_2ecompile_2emonadic_2ebindAs(V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_clo;
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(V, V, V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_clo;
V g_heff_2ecompile_2emonadic_2ebindAtom(V, V);
V g_heff_2ecompile_2emonadic_2ebindAtom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAtom_clo;
V g_heff_2ecompile_2emonadic_2eflatLet(V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_clo;
V g_heff_2ecompile_2emonadic_2eflatLet_24dps(V, V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_24dps_clo;
V g_heff_2ecompile_2emonadic_2enorm(V);
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enorm_clo;
V g_heff_2ecompile_2emonadic_2eoperandsWith(V, V, V);
V g_heff_2ecompile_2emonadic_2eoperandsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eoperandsWith_clo;
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287(V);
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str0, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str1, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str2, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str3, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str4, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str5, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str6, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str7, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str8, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str9, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str10, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str11, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str12, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str13, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str14, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str15, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str16, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str17, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str18, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAtom_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam3(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam4(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam5(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam6(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam7(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam8(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam9(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam10(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam11(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam12(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam13(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam14(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam15(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam16(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam17(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam18(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam19(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAtom_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2ebindAtom(V v_e_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_2437;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
      heff_drop(v_t_2437);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2437);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam0, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EGlobal: {
    V v_t_2479;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2479 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2479 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2479 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2479 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2479 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2479 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2479 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2479 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2479 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2479 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2479 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2479 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2479 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2479 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2479 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2479 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2479 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2479 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2479 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2479 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_2479) == NTAG(TAG_True))) {
      heff_drop(v_t_2479);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2479);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam1, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ELam: {
    V v_t_24122;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24122 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24122 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24122 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24122 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24122 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24122 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24122 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24122 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24122 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24122) == NTAG(TAG_True))) {
      heff_drop(v_t_24122);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24122);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam2, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EApp: {
    V v_t_24165;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24165 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24165 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24165 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24165 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24165 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24165 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24165 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24165 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24165 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24165 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24165 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24165 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24165 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24165 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24165 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24165 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24165 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24165 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24165 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24165 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24165) == NTAG(TAG_True))) {
      heff_drop(v_t_24165);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24165);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam3, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ELet: {
    V v_y_24172 = heff_field(v_e_240, 0);
    V v_c_24173 = heff_field(v_e_240, 1);
    V v_d_24174 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_24175 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAtom(v_d_24174, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam4, 1, 3, (V[]){v_m_24175, v_y_24172, v_c_24173});
  }
  case TAG_ERecord: {
    V v_t_24216;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24216 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24216 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24216 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24216 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24216 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24216 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24216 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24216 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24216 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24216 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24216) == NTAG(TAG_True))) {
      heff_drop(v_t_24216);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24216);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam5, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EProj: {
    V v_t_24261;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24261 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24261 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24261 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24261 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24261 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24261 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24261 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24261 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24261 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24261 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24261 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24261 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24261 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24261 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24261 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24261 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24261 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24261 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24261 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24261 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24261) == NTAG(TAG_True))) {
      heff_drop(v_t_24261);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24261);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam6, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ETag: {
    V v_t_24305;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24305 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24305 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24305 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24305 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24305 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24305 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24305 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24305 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24305 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24305 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24305 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24305 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24305 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24305 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24305 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24305 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24305 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24305 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24305 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24305 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24305) == NTAG(TAG_True))) {
      heff_drop(v_t_24305);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24305);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam7, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EMatch: {
    V v_t_24348;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24348 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24348 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24348 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24348 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24348 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24348 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24348 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24348 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24348 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24348) == NTAG(TAG_True))) {
      heff_drop(v_t_24348);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24348);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam8, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EPrim: {
    V v_t_24390;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24390 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24390 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24390 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24390 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24390 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24390 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24390 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24390 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24390 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24390 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24390 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24390 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24390 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24390 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24390 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24390 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24390 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24390 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24390 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24390 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24390) == NTAG(TAG_True))) {
      heff_drop(v_t_24390);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24390);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam9, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EPrimCall: {
    V v_t_24433;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24433 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24433 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24433 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24433 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24433 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24433 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24433 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24433 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24433 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24433 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24433 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24433 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24433 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24433 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24433 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24433 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24433 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24433 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24433 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24433 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24433) == NTAG(TAG_True))) {
      heff_drop(v_t_24433);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24433);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam10, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ECall: {
    V v_t_24476;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24476 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24476 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24476 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24476 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24476 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24476 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24476 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24476 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24476 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24476 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24476 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24476 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24476 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24476 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24476 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24476 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24476 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24476 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24476 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24476 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24476) == NTAG(TAG_True))) {
      heff_drop(v_t_24476);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24476);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam11, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EInt: {
    V v_t_24518;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24518 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24518 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24518 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24518 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24518 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24518 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24518 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24518 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24518 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24518 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24518 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24518 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24518 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24518 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24518 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24518 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24518 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24518 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24518 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24518 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24518) == NTAG(TAG_True))) {
      heff_drop(v_t_24518);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24518);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam12, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFloat: {
    V v_t_24560;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24560 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24560 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24560 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24560 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24560 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24560 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24560 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24560 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24560 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24560 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24560 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24560 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24560 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24560 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24560 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24560 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24560 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24560 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24560 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24560 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24560) == NTAG(TAG_True))) {
      heff_drop(v_t_24560);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24560);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam13, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EStr: {
    V v_t_24602;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24602 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24602 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24602 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24602 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24602 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24602 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24602 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24602 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24602 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24602 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24602 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24602 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24602 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24602 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24602 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24602 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24602 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24602 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24602 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24602 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24602) == NTAG(TAG_True))) {
      heff_drop(v_t_24602);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24602);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam14, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EBytes: {
    V v_t_24644;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24644 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24644 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24644 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24644 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24644 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24644 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24644 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24644 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24644 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24644 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24644 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24644 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24644 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24644 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24644 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24644 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24644 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24644 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24644 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24644 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24644) == NTAG(TAG_True))) {
      heff_drop(v_t_24644);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24644);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam15, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFixed: {
    V v_t_24687;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24687 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24687 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24687 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24687 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24687 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24687 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24687 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24687 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24687 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24687 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24687 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24687 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24687 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24687 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24687 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24687 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24687 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24687 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24687 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24687 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24687) == NTAG(TAG_True))) {
      heff_drop(v_t_24687);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24687);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam16, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFloat32: {
    V v_t_24729;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24729 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24729 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24729 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24729 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24729 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24729 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24729 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24729 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24729 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24729 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24729 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24729 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24729 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24729 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24729 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24729 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24729 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24729 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24729 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24729 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24729) == NTAG(TAG_True))) {
      heff_drop(v_t_24729);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24729);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam17, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EAbandon: {
    V v_t_24770;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24770 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24770 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24770 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24770 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24770 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24770 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24770 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24770 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24770 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24770 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24770 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24770 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24770 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24770 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24770 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24770 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24770 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24770 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24770 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24770 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24770) == NTAG(TAG_True))) {
      heff_drop(v_t_24770);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24770);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam18, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFix: {
    V v_t_24813;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24813 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24813 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24813 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24813 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24813 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24813 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24813 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24813 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24813 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24813 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24813 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24813 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24813 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24813 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24813 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24813 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24813 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24813 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24813 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24813 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24813) == NTAG(TAG_True))) {
      heff_drop(v_t_24813);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24813);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam19, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAtom(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam0(V self, V *args) {
  V v_n_2438 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str0), heff_intShow(heff_dup(v_n_2438)));
  V v_m_2440 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2439)})}));
  V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){heff_intAdd(v_n_2438, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_n_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2439, v_e_240, v_x_2442}), v_n_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam1(V self, V *args) {
  V v_n_2480 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2481 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str1), heff_intShow(heff_dup(v_n_2480)));
  V v_m_2482 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2481)})}));
  V v_x2_2483 = heff_tr(heff_call(v_m_2482, 1, (V[]){heff_intAdd(v_n_2480, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2483)) {
  case TAG_MkPair: {
    V v_x_2484 = heff_field(v_x2_2483, 0);
    V v_n_2485 = heff_field(v_x2_2483, 1);
    V v_ru_24x2_2483_24MkPair = heff_take_reuse_n(v_x2_2483, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2481, v_e_240, v_x_2484}), v_n_2485});
  }
  default: return heff_nomatch(v_x2_2483);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam2(V self, V *args) {
  V v_n_24123 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24124 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str2), heff_intShow(heff_dup(v_n_24123)));
  V v_m_24125 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24124)})}));
  V v_x2_24126 = heff_tr(heff_call(v_m_24125, 1, (V[]){heff_intAdd(v_n_24123, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24126)) {
  case TAG_MkPair: {
    V v_x_24127 = heff_field(v_x2_24126, 0);
    V v_n_24128 = heff_field(v_x2_24126, 1);
    V v_ru_24x2_24126_24MkPair = heff_take_reuse_n(v_x2_24126, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24124, v_e_240, v_x_24127}), v_n_24128});
  }
  default: return heff_nomatch(v_x2_24126);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam3(V self, V *args) {
  V v_n_24166 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24167 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str3), heff_intShow(heff_dup(v_n_24166)));
  V v_m_24168 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24167)})}));
  V v_x2_24169 = heff_tr(heff_call(v_m_24168, 1, (V[]){heff_intAdd(v_n_24166, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24169)) {
  case TAG_MkPair: {
    V v_x_24170 = heff_field(v_x2_24169, 0);
    V v_n_24171 = heff_field(v_x2_24169, 1);
    V v_ru_24x2_24169_24MkPair = heff_take_reuse_n(v_x2_24169, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24169_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24167, v_e_240, v_x_24170}), v_n_24171});
  }
  default: return heff_nomatch(v_x2_24169);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam4(V self, V *args) {
  V v_n_24176 = args[0];
  V v_m_24175 = heff_env(self)[0];
  V v_y_24172 = heff_env(self)[1];
  V v_c_24173 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24177 = heff_tr(heff_call(v_m_24175, 1, (V[]){v_n_24176}));
  switch (heff_tag_of(v_x2_24177)) {
  case TAG_MkPair: {
    V v_x_24178 = heff_field(v_x2_24177, 0);
    V v_n_24179 = heff_field(v_x2_24177, 1);
    V v_ru_24x2_24177_24MkPair = heff_take_reuse_n(v_x2_24177, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24177_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_24172, v_c_24173, v_x_24178}), v_n_24179});
  }
  default: return heff_nomatch(v_x2_24177);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam5(V self, V *args) {
  V v_n_24217 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24218 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str4), heff_intShow(heff_dup(v_n_24217)));
  V v_m_24219 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24218)})}));
  V v_x2_24220 = heff_tr(heff_call(v_m_24219, 1, (V[]){heff_intAdd(v_n_24217, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24220)) {
  case TAG_MkPair: {
    V v_x_24221 = heff_field(v_x2_24220, 0);
    V v_n_24222 = heff_field(v_x2_24220, 1);
    V v_ru_24x2_24220_24MkPair = heff_take_reuse_n(v_x2_24220, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24220_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24218, v_e_240, v_x_24221}), v_n_24222});
  }
  default: return heff_nomatch(v_x2_24220);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam6(V self, V *args) {
  V v_n_24262 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24263 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str5), heff_intShow(heff_dup(v_n_24262)));
  V v_m_24264 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24263)})}));
  V v_x2_24265 = heff_tr(heff_call(v_m_24264, 1, (V[]){heff_intAdd(v_n_24262, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24265)) {
  case TAG_MkPair: {
    V v_x_24266 = heff_field(v_x2_24265, 0);
    V v_n_24267 = heff_field(v_x2_24265, 1);
    V v_ru_24x2_24265_24MkPair = heff_take_reuse_n(v_x2_24265, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24265_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24263, v_e_240, v_x_24266}), v_n_24267});
  }
  default: return heff_nomatch(v_x2_24265);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam7(V self, V *args) {
  V v_n_24306 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24307 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str6), heff_intShow(heff_dup(v_n_24306)));
  V v_m_24308 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24307)})}));
  V v_x2_24309 = heff_tr(heff_call(v_m_24308, 1, (V[]){heff_intAdd(v_n_24306, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24309)) {
  case TAG_MkPair: {
    V v_x_24310 = heff_field(v_x2_24309, 0);
    V v_n_24311 = heff_field(v_x2_24309, 1);
    V v_ru_24x2_24309_24MkPair = heff_take_reuse_n(v_x2_24309, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24309_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24307, v_e_240, v_x_24310}), v_n_24311});
  }
  default: return heff_nomatch(v_x2_24309);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam8(V self, V *args) {
  V v_n_24349 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24350 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str7), heff_intShow(heff_dup(v_n_24349)));
  V v_m_24351 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24350)})}));
  V v_x2_24352 = heff_tr(heff_call(v_m_24351, 1, (V[]){heff_intAdd(v_n_24349, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24352)) {
  case TAG_MkPair: {
    V v_x_24353 = heff_field(v_x2_24352, 0);
    V v_n_24354 = heff_field(v_x2_24352, 1);
    V v_ru_24x2_24352_24MkPair = heff_take_reuse_n(v_x2_24352, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24352_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24350, v_e_240, v_x_24353}), v_n_24354});
  }
  default: return heff_nomatch(v_x2_24352);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam9(V self, V *args) {
  V v_n_24391 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24392 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str8), heff_intShow(heff_dup(v_n_24391)));
  V v_m_24393 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24392)})}));
  V v_x2_24394 = heff_tr(heff_call(v_m_24393, 1, (V[]){heff_intAdd(v_n_24391, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24394)) {
  case TAG_MkPair: {
    V v_x_24395 = heff_field(v_x2_24394, 0);
    V v_n_24396 = heff_field(v_x2_24394, 1);
    V v_ru_24x2_24394_24MkPair = heff_take_reuse_n(v_x2_24394, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24394_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24392, v_e_240, v_x_24395}), v_n_24396});
  }
  default: return heff_nomatch(v_x2_24394);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam10(V self, V *args) {
  V v_n_24434 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24435 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str9), heff_intShow(heff_dup(v_n_24434)));
  V v_m_24436 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24435)})}));
  V v_x2_24437 = heff_tr(heff_call(v_m_24436, 1, (V[]){heff_intAdd(v_n_24434, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24437)) {
  case TAG_MkPair: {
    V v_x_24438 = heff_field(v_x2_24437, 0);
    V v_n_24439 = heff_field(v_x2_24437, 1);
    V v_ru_24x2_24437_24MkPair = heff_take_reuse_n(v_x2_24437, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24435, v_e_240, v_x_24438}), v_n_24439});
  }
  default: return heff_nomatch(v_x2_24437);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam11(V self, V *args) {
  V v_n_24477 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24478 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str10), heff_intShow(heff_dup(v_n_24477)));
  V v_m_24479 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24478)})}));
  V v_x2_24480 = heff_tr(heff_call(v_m_24479, 1, (V[]){heff_intAdd(v_n_24477, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24480)) {
  case TAG_MkPair: {
    V v_x_24481 = heff_field(v_x2_24480, 0);
    V v_n_24482 = heff_field(v_x2_24480, 1);
    V v_ru_24x2_24480_24MkPair = heff_take_reuse_n(v_x2_24480, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24478, v_e_240, v_x_24481}), v_n_24482});
  }
  default: return heff_nomatch(v_x2_24480);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam12(V self, V *args) {
  V v_n_24519 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24520 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str11), heff_intShow(heff_dup(v_n_24519)));
  V v_m_24521 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24520)})}));
  V v_x2_24522 = heff_tr(heff_call(v_m_24521, 1, (V[]){heff_intAdd(v_n_24519, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24522)) {
  case TAG_MkPair: {
    V v_x_24523 = heff_field(v_x2_24522, 0);
    V v_n_24524 = heff_field(v_x2_24522, 1);
    V v_ru_24x2_24522_24MkPair = heff_take_reuse_n(v_x2_24522, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24522_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24520, v_e_240, v_x_24523}), v_n_24524});
  }
  default: return heff_nomatch(v_x2_24522);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam13(V self, V *args) {
  V v_n_24561 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24562 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str12), heff_intShow(heff_dup(v_n_24561)));
  V v_m_24563 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24562)})}));
  V v_x2_24564 = heff_tr(heff_call(v_m_24563, 1, (V[]){heff_intAdd(v_n_24561, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24564)) {
  case TAG_MkPair: {
    V v_x_24565 = heff_field(v_x2_24564, 0);
    V v_n_24566 = heff_field(v_x2_24564, 1);
    V v_ru_24x2_24564_24MkPair = heff_take_reuse_n(v_x2_24564, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24564_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24562, v_e_240, v_x_24565}), v_n_24566});
  }
  default: return heff_nomatch(v_x2_24564);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam14(V self, V *args) {
  V v_n_24603 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24604 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str13), heff_intShow(heff_dup(v_n_24603)));
  V v_m_24605 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24604)})}));
  V v_x2_24606 = heff_tr(heff_call(v_m_24605, 1, (V[]){heff_intAdd(v_n_24603, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24606)) {
  case TAG_MkPair: {
    V v_x_24607 = heff_field(v_x2_24606, 0);
    V v_n_24608 = heff_field(v_x2_24606, 1);
    V v_ru_24x2_24606_24MkPair = heff_take_reuse_n(v_x2_24606, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24606_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24604, v_e_240, v_x_24607}), v_n_24608});
  }
  default: return heff_nomatch(v_x2_24606);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam15(V self, V *args) {
  V v_n_24645 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24646 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str14), heff_intShow(heff_dup(v_n_24645)));
  V v_m_24647 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24646)})}));
  V v_x2_24648 = heff_tr(heff_call(v_m_24647, 1, (V[]){heff_intAdd(v_n_24645, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24648)) {
  case TAG_MkPair: {
    V v_x_24649 = heff_field(v_x2_24648, 0);
    V v_n_24650 = heff_field(v_x2_24648, 1);
    V v_ru_24x2_24648_24MkPair = heff_take_reuse_n(v_x2_24648, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24648_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24646, v_e_240, v_x_24649}), v_n_24650});
  }
  default: return heff_nomatch(v_x2_24648);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam16(V self, V *args) {
  V v_n_24688 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24689 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str15), heff_intShow(heff_dup(v_n_24688)));
  V v_m_24690 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24689)})}));
  V v_x2_24691 = heff_tr(heff_call(v_m_24690, 1, (V[]){heff_intAdd(v_n_24688, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24691)) {
  case TAG_MkPair: {
    V v_x_24692 = heff_field(v_x2_24691, 0);
    V v_n_24693 = heff_field(v_x2_24691, 1);
    V v_ru_24x2_24691_24MkPair = heff_take_reuse_n(v_x2_24691, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24691_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24689, v_e_240, v_x_24692}), v_n_24693});
  }
  default: return heff_nomatch(v_x2_24691);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam17(V self, V *args) {
  V v_n_24730 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24731 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str16), heff_intShow(heff_dup(v_n_24730)));
  V v_m_24732 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24731)})}));
  V v_x2_24733 = heff_tr(heff_call(v_m_24732, 1, (V[]){heff_intAdd(v_n_24730, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24733)) {
  case TAG_MkPair: {
    V v_x_24734 = heff_field(v_x2_24733, 0);
    V v_n_24735 = heff_field(v_x2_24733, 1);
    V v_ru_24x2_24733_24MkPair = heff_take_reuse_n(v_x2_24733, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24733_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24731, v_e_240, v_x_24734}), v_n_24735});
  }
  default: return heff_nomatch(v_x2_24733);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam18(V self, V *args) {
  V v_n_24771 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24772 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str17), heff_intShow(heff_dup(v_n_24771)));
  V v_m_24773 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24772)})}));
  V v_x2_24774 = heff_tr(heff_call(v_m_24773, 1, (V[]){heff_intAdd(v_n_24771, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24774)) {
  case TAG_MkPair: {
    V v_x_24775 = heff_field(v_x2_24774, 0);
    V v_n_24776 = heff_field(v_x2_24774, 1);
    V v_ru_24x2_24774_24MkPair = heff_take_reuse_n(v_x2_24774, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24774_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24772, v_e_240, v_x_24775}), v_n_24776});
  }
  default: return heff_nomatch(v_x2_24774);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam19(V self, V *args) {
  V v_n_24814 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24815 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str18), heff_intShow(heff_dup(v_n_24814)));
  V v_m_24816 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24815)})}));
  V v_x2_24817 = heff_tr(heff_call(v_m_24816, 1, (V[]){heff_intAdd(v_n_24814, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24817)) {
  case TAG_MkPair: {
    V v_x_24818 = heff_field(v_x2_24817, 0);
    V v_n_24819 = heff_field(v_x2_24817, 1);
    V v_ru_24x2_24817_24MkPair = heff_take_reuse_n(v_x2_24817, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24817_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24815, v_e_240, v_x_24818}), v_n_24819});
  }
  default: return heff_nomatch(v_x2_24817);
  }
}
Clo g_heff_2ecompile_2emonadic_2eflatLet_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry, 4, 0};

V g_heff_2ecompile_2emonadic_2eflatLet_24dps(V v_x_240, V v_a_241, V v_b_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EGlobal: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ELam: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EApp: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ELet: {
    V v_y_2410 = heff_field(v_a_241, 0);
    V v_c_2411 = heff_field(v_a_241, 1);
    V v_d_2412 = heff_field(v_a_241, 2);
    V v_ru_24a_241_24ELet = heff_take_reuse_n(v_a_241, 7ULL, 3);
    V v_cell_2413 = heff_tag_at_n(v_ru_24a_241_24ELet, TAG_ELet, 3, (V[]){v_y_2410, v_c_2411, heff_hole()});
    V v_u_2414 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_x_240;
    V t_1 = v_d_2412;
    V t_2 = v_b_242;
    V t_3 = v_cell_2413;
    v_x_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EProj: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ETag: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EMatch: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EPrim: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EPrimCall: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ECall: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EInt: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFloat: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EStr: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EBytes: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFixed: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFloat32: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EAbandon: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFix: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2eflatLet_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam0(V self, V *args); static Clo g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam0, 1, 0};
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam2(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      V v_a_247 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_a_246));
      v_m_2412 = heff_clo_n(g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam1, 1, 3, (V[]){v_a_247, v_a_244, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam2, 1, 2, (V[]){v_m_2412, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287(a[0]);
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam1(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_a_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = heff_tr(heff_call(v_a_247, 1, (V[]){v_a_248}));
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkPair: {
    V v_a_2410 = heff_field(v_a_249, 0);
    V v_a_2411 = heff_field(v_a_249, 1);
    V v_ru_24a_249_24MkPair = heff_take_reuse_n(v_a_249, 3ULL, 2);
    return heff_tag_at_n(v_ru_24a_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_244, v_a_245, v_a_2410}), v_a_2411});
  }
  default: return heff_nomatch(v_a_249);
  }
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_m_2417 = (g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287(v_xs_243));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2416}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_n_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_x_2419}), v_n_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam5(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam4(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam3(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam6(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam8(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam7(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam9(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam10(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam13(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam12(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam11(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam14(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam15(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam16(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam17(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam18(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam19(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam20(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam21(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam22(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam23(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam24(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2enorm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2enorm_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2enorm(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam0, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam1, 1, 1, (V[]){v_x1_240});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x1_240, 0);
    V v_b_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_247 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_b_246));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam2, 1, 2, (V[]){v_m_247, v_xs_245});
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_x1_240, 0);
    V v_as_2413 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_2414 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_f_2412));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam3, 1, 2, (V[]){v_m_2414, v_as_2413});
  }
  case TAG_ELet: {
    V v_x_2423 = heff_field(v_x1_240, 0);
    V v_a_2424 = heff_field(v_x1_240, 1);
    V v_b_2425 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_m_2426 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_a_2424));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam6, 1, 3, (V[]){v_m_2426, v_b_2425, v_x_2423});
  }
  case TAG_ERecord: {
    V v_fs_2436 = heff_field(v_x1_240, 0);
    V v_ts_2437 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_2438 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2436)));
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_t_2438, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam7, 1, 2, (V[]){v_fs_2436, v_ts_2437})));
  }
  case TAG_EProj: {
    V v_e_2443 = heff_field(v_x1_240, 0);
    V v_l_2444 = heff_field(v_x1_240, 1);
    V v_sh_2445 = heff_field(v_x1_240, 2);
    V v_t_2446 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    V v_m_2447 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_e_2443));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam9, 1, 4, (V[]){v_m_2447, v_l_2444, v_sh_2445, v_t_2446});
  }
  case TAG_ETag: {
    V v_t_2453 = heff_field(v_x1_240, 0);
    V v_as_2454 = heff_field(v_x1_240, 1);
    V v_ts_2455 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_as_2454, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam10, 2, 2, (V[]){v_t_2453, v_ts_2455})));
  }
  case TAG_EMatch: {
    V v_s_2458 = heff_field(v_x1_240, 0);
    V v_arms_2459 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_2460 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_s_2458));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam11, 1, 2, (V[]){v_m_2460, v_arms_2459});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam14, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EPrimCall: {
    V v_p_2474 = heff_field(v_x1_240, 0);
    V v_as_2475 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_as_2475, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam15, 2, 1, (V[]){v_p_2474})));
  }
  case TAG_ECall: {
    V v_g_2478 = heff_field(v_x1_240, 0);
    V v_as_2479 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_as_2479, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam16, 2, 1, (V[]){v_g_2478})));
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam17, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam18, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam19, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam20, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam21, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam22, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam23, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EFix: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam24, 1, 1, (V[]){v_x1_240});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2enorm(a[0]);
}
V g_heff_2ecompile_2emonadic_2enorm_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_242});
}
V g_heff_2ecompile_2emonadic_2enorm_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_244});
}
V g_heff_2ecompile_2emonadic_2enorm_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_245, v_x_2410}), v_n_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam5(V self, V *args) {
  V v_as_27_2420 = args[0];
  V v_n_2421 = args[1];
  V v_f_27_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_27_2419, v_as_27_2420}), v_n_2421});
}
V g_heff_2ecompile_2emonadic_2enorm_lam4(V self, V *args) {
  V v_f_27_2419 = args[0];
  V v_as_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_as_2413, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam5, 2, 1, (V[]){v_f_27_2419})));
}
V g_heff_2ecompile_2emonadic_2enorm_lam3(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_as_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    heff_take_n(v_x2_2416, 3ULL, 2);
    V v_t_2422 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_x_2417, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam4, 1, 1, (V[]){v_as_2413})));
    V f_ = v_t_2422;
    args[0] = v_n_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam6(V self, V *args) {
  V v_n_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  V v_b_2425 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_n_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_n_2430 = heff_field(v_x2_2428, 1);
    V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
    V v_m_2431 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_b_2425));
    V v_x2_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2430}));
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_MkPair: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_n_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      V v_x_2435 = (g_heff_2ecompile_2emonadic_2eflatLet(v_x_2423, v_x_2429, v_x_2433));
      return heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){v_x_2435, v_n_2434});
    }
    default: return heff_nomatch(v_x2_2432);
    }
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam8(V self, V *args) {
  V v_n_2442 = args[0];
  V v_x_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2441, v_n_2442});
}
V g_heff_2ecompile_2emonadic_2enorm_lam7(V self, V *args) {
  V v_vs_2439 = args[0];
  V v_fs_2436 = heff_env(self)[0];
  V v_ts_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2436, v_vs_2439));
  V v_x_2441 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2440, v_ts_2437});
  return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam8, 1, 1, (V[]){v_x_2441});
}
V g_heff_2ecompile_2emonadic_2enorm_lam9(V self, V *args) {
  V v_n_2448 = args[0];
  V v_m_2447 = heff_env(self)[0];
  V v_l_2444 = heff_env(self)[1];
  V v_sh_2445 = heff_env(self)[2];
  V v_t_2446 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2449 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_n_2448}));
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_n_2451 = heff_field(v_x2_2449, 1);
    heff_take_n(v_x2_2449, 3ULL, 2);
    V v_t_2452 = (g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(v_l_2444, v_sh_2445, v_t_2446, v_x_2450));
    V f_ = v_t_2452;
    args[0] = v_n_2451;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam10(V self, V *args) {
  V v_as_27_2456 = args[0];
  V v_n_2457 = args[1];
  V v_t_2453 = heff_env(self)[0];
  V v_ts_2455 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2453, v_as_27_2456, v_ts_2455}), v_n_2457});
}
V g_heff_2ecompile_2emonadic_2enorm_lam13(V self, V *args) {
  V v_n_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_s_27_2465 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_n_2467}));
  switch (heff_tag_of(v_x2_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_field(v_x2_2468, 0);
    V v_n_2470 = heff_field(v_x2_2468, 1);
    V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_27_2465, v_x_2469}), v_n_2470});
  }
  default: return heff_nomatch(v_x2_2468);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam12(V self, V *args) {
  V v_s_27_2465 = args[0];
  V v_arms_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2466 = (g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287(v_arms_2459));
  return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam13, 1, 2, (V[]){v_m_2466, v_s_27_2465});
}
V g_heff_2ecompile_2emonadic_2enorm_lam11(V self, V *args) {
  V v_n_2461 = args[0];
  V v_m_2460 = heff_env(self)[0];
  V v_arms_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2462 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_n_2461}));
  switch (heff_tag_of(v_x2_2462)) {
  case TAG_MkPair: {
    V v_x_2463 = heff_field(v_x2_2462, 0);
    V v_n_2464 = heff_field(v_x2_2462, 1);
    heff_take_n(v_x2_2462, 3ULL, 2);
    V v_t_2471 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAtom(v_x_2463, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam12, 1, 1, (V[]){v_arms_2459})));
    V f_ = v_t_2471;
    args[0] = v_n_2464;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2462);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam14(V self, V *args) {
  V v_n_2473 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2473});
}
V g_heff_2ecompile_2emonadic_2enorm_lam15(V self, V *args) {
  V v_as_27_2476 = args[0];
  V v_n_2477 = args[1];
  V v_p_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2474, v_as_27_2476}), v_n_2477});
}
V g_heff_2ecompile_2emonadic_2enorm_lam16(V self, V *args) {
  V v_as_27_2480 = args[0];
  V v_n_2481 = args[1];
  V v_g_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2478, v_as_27_2480}), v_n_2481});
}
V g_heff_2ecompile_2emonadic_2enorm_lam17(V self, V *args) {
  V v_n_2483 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2483});
}
V g_heff_2ecompile_2emonadic_2enorm_lam18(V self, V *args) {
  V v_n_2485 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2485});
}
V g_heff_2ecompile_2emonadic_2enorm_lam19(V self, V *args) {
  V v_n_2487 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2487});
}
V g_heff_2ecompile_2emonadic_2enorm_lam20(V self, V *args) {
  V v_n_2489 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2489});
}
V g_heff_2ecompile_2emonadic_2enorm_lam21(V self, V *args) {
  V v_n_2492 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2492});
}
V g_heff_2ecompile_2emonadic_2enorm_lam22(V self, V *args) {
  V v_n_2494 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2494});
}
V g_heff_2ecompile_2emonadic_2enorm_lam23(V self, V *args) {
  V v_n_2495 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2495});
}
V g_heff_2ecompile_2emonadic_2enorm_lam24(V self, V *args) {
  V v_n_2498 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2498});
}