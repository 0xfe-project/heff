// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_ArrayIndexIn 58029
#define TAG_BocGiven 26228
#define TAG_BocNew 29139
#define TAG_BocTaken 53948
#define TAG_BocWhen 59622
#define TAG_CustodianDue 8759
#define TAG_CustodyIn 58670
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FuelTick 47424
#define TAG_FuelTicks 28388
#define TAG_IntShl 35657
#define TAG_IntShr 35663
#define TAG_Keep 49586
#define TAG_Panic 15447
#define TAG_Perform 19235
#define TAG_PerformAt 64592
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s1079778092x1188272986(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1079778092x1188272986_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1079778092x1188272986_clo;
V g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429(V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_clo;
V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373(V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_clo;
V g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757(V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_clo;
V g_heff_2ecompile_2emonadic_2ebindAs_24s2143175432x1815073428(V, V, V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_24s2143175432x1815073428_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_24s2143175432x1815073428_clo;
V g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024(V, V, V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_clo;
V g_heff_2ecompile_2emonadic_2ebindAs_24s830768518x1268082316(V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_24s830768518x1268082316_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_24s830768518x1268082316_clo;
V g_heff_2ecompile_2emonadic_2ebindAtom(V, V);
V g_heff_2ecompile_2emonadic_2ebindAtom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAtom_clo;
V g_heff_2ecompile_2emonadic_2ebindScrut(V, V);
V g_heff_2ecompile_2emonadic_2ebindScrut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindScrut_clo;
V g_heff_2ecompile_2emonadic_2econdN_24s377306777x479528235(V, V);
V g_heff_2ecompile_2emonadic_2econdN_24s377306777x479528235_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2econdN_24s377306777x479528235_clo;
V g_heff_2ecompile_2emonadic_2eflatLet(V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_clo;
V g_heff_2ecompile_2emonadic_2eflatLet_24dps(V, V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_24dps_clo;
V g_heff_2ecompile_2emonadic_2einPlace(V);
V g_heff_2ecompile_2emonadic_2einPlace_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2einPlace_clo;
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(V);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_clo;
V g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(V);
V g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905_clo;
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335(V, V);
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_clo;
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497(V, V);
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_clo;
V g_heff_2ecompile_2emonadic_2equiet(V);
V g_heff_2ecompile_2emonadic_2equiet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2equiet_clo;
V g_heff_2ecompile_2emonadic_2evalue(V);
V g_heff_2ecompile_2emonadic_2evalue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2evalue_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s1366771983x151845067(V);
V g_list_2eall_24s1366771983x151845067_entry(V self, V *a);
extern Clo g_list_2eall_24s1366771983x151845067_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_prelude_2etraverse_24s1700321227x1313876518(V);
V g_prelude_2etraverse_24s1700321227x1313876518_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1700321227x1313876518_clo;
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str0, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAtom_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam2(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAtom_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2ebindAtom(V v_e_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_ELet: {
    V v_y_242 = heff_field(v_e_240, 0);
    V v_c_243 = heff_field(v_e_240, 1);
    V v_d_244 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_245 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAtom(v_d_244, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam0, 1, 3, (V[]){v_m_245, v_y_242, v_c_243});
  }
  case TAG_ESet: {
    V v_ys_2410 = heff_field(v_e_240, 0);
    V v_c_2411 = heff_field(v_e_240, 1);
    V v_d_2412 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2413 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAtom(v_d_2412, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam1, 1, 3, (V[]){v_m_2413, v_ys_2410, v_c_2411});
  }
  default: {
    V v_t_2457;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
      heff_drop(v_t_2457);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2457);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam2, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAtom(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_y_242 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_242, v_c_243, v_x_248}), v_n_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ys_2410 = heff_env(self)[1];
  V v_c_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_2410, v_c_2411, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam2(V self, V *args) {
  V v_n_2458 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2459 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str0), heff_intShow(heff_dup(v_n_2458)));
  heff_clo_take(self, 2);
  V v_m_2460 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2459)})}));
  V v_x2_2461 = heff_tr(heff_call(v_m_2460, 1, (V[]){heff_intAdd(v_n_2458, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2461)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x2_2461, 0);
    V v_n_2463 = heff_field(v_x2_2461, 1);
    V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2461_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2459, v_e_240, v_x_2462}), v_n_2463});
  }
  default: return heff_nomatch(v_x2_2461);
  }
}
Clo g_heff_2ecompile_2emonadic_2eflatLet_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry, 4, 0};

V g_heff_2ecompile_2emonadic_2eflatLet_24dps(V v_x_240, V v_a_241, V v_b_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EGlobal: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ELam: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EApp: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ELet: {
    V v_y_2410 = heff_field(v_a_241, 0);
    V v_c_2411 = heff_field(v_a_241, 1);
    V v_d_2412 = heff_field(v_a_241, 2);
    V v_ru_24a_241_24ELet = heff_take_reuse_n(v_a_241, 7ULL, 3);
    V v_cell_2413 = heff_tag_re_n(v_ru_24a_241_24ELet, TAG_ELet, 3, 3ULL, (V[]){v_y_2410, v_c_2411, heff_hole()});
    V v_u_2414 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_cell_2413);
    V t_0 = v_x_240;
    V t_1 = v_d_2412;
    V t_2 = v_b_242;
    V t_3 = v_u_2414;
    v_x_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EProj: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ETag: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EMatch: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EPrim: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EPrimCall: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ECall: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EInt: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFloat: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EStr: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EBytes: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFixed: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFloat32: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EAbandon: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EBool: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ESet: {
    V v_ys_2439 = heff_field(v_a_241, 0);
    V v_c_2440 = heff_field(v_a_241, 1);
    V v_d_2441 = heff_field(v_a_241, 2);
    V v_ru_24a_241_24ESet = heff_take_reuse_n(v_a_241, 7ULL, 3);
    V v_cell_2442 = heff_tag_re_n(v_ru_24a_241_24ESet, TAG_ESet, 3, 3ULL, (V[]){v_ys_2439, v_c_2440, heff_hole()});
    V v_u_2443 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_cell_2442);
    V t_0 = v_x_240;
    V t_1 = v_d_2441;
    V t_2 = v_b_242;
    V t_3 = v_u_2443;
    v_x_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_EValues: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFix: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2emonadic_2eflatLet_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_str0, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_lam2(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429(V v_e_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_ELet: {
    V v_y_242 = heff_field(v_e_240, 0);
    V v_c_243 = heff_field(v_e_240, 1);
    V v_d_244 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_245 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429(v_d_244, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_lam0, 1, 3, (V[]){v_m_245, v_y_242, v_c_243});
  }
  case TAG_ESet: {
    V v_ys_2410 = heff_field(v_e_240, 0);
    V v_c_2411 = heff_field(v_e_240, 1);
    V v_d_2412 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2413 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429(v_d_2412, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_lam1, 1, 3, (V[]){v_m_2413, v_ys_2410, v_c_2411});
  }
  default: {
    V v_t_2418 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2418);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_lam2, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_y_242 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_242, v_c_243, v_x_248}), v_n_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ys_2410 = heff_env(self)[1];
  V v_c_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_2410, v_c_2411, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_lam2(V self, V *args) {
  V v_n_2419 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2420 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429_str0), heff_intShow(heff_dup(v_n_2419)));
  heff_clo_take(self, 2);
  V v_m_2421 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2420)})}));
  V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){heff_intAdd(v_n_2419, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    V v_n_2424 = heff_field(v_x2_2422, 1);
    V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2420, v_e_240, v_x_2423}), v_n_2424});
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_lam0(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497(V v_x3_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x3_240)) {
  case TAG_Nil: {
    return heff_tail(v_k_241, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x3_240, 0);
    V v_rest_243 = heff_field(v_x3_240, 1);
    heff_take_n(v_x3_240, 3ULL, 2);
    V v_m_244 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_a_242));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_lam0, 1, 3, (V[]){v_m_244, v_rest_243, v_k_241});
  }
  default: return heff_nomatch(v_x3_240);
  }
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_lam2(V self, V *args) {
  V v_rest_27_2410 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_a_27_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_27_249, v_rest_27_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_lam1(V self, V *args) {
  V v_a_27_249 = args[0];
  V v_rest_243 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497(v_rest_243, heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_lam2, 1, 2, (V[]){v_k_241, v_a_27_249})));
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_rest_243 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    V v_t_2411 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs_24s1448523198x1279392429(v_x_247, heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497_lam1, 1, 2, (V[]){v_rest_243, v_k_241})));
    V f_ = v_t_2411;
    args[0] = v_n_248;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_str0, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam4(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam3(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373(V v_lit_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_ELet: {
    V v_y_242 = heff_field(v_e_241, 0);
    V v_c_243 = heff_field(v_e_241, 1);
    V v_d_244 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_245 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373(v_lit_240, v_d_244));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam0, 1, 3, (V[]){v_m_245, v_y_242, v_c_243});
  }
  case TAG_ESet: {
    V v_ys_2410 = heff_field(v_e_241, 0);
    V v_c_2411 = heff_field(v_e_241, 1);
    V v_d_2412 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2413 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373(v_lit_240, v_d_2412));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam1, 1, 3, (V[]){v_m_2413, v_ys_2410, v_c_2411});
  }
  default: {
    V v_t_2418 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_241));
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      HEFF_LAST return g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497(v_lit_240, heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam2, 2, 1, (V[]){v_e_241}));
    } else {
      heff_drop(v_t_2418);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam3, 1, 2, (V[]){v_lit_240, v_e_241});
    }
  }
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_y_242 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_242, v_c_243, v_x_248}), v_n_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ys_2410 = heff_env(self)[1];
  V v_c_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_2410, v_c_2411, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam2(V self, V *args) {
  V v_a_2419 = args[0];
  V v_a_2420 = args[1];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_a_2419}), v_a_2420});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam4(V self, V *args) {
  V v_a_2423 = args[0];
  V v_a_2424 = args[1];
  V v_x_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_2422}), v_a_2423});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2425, v_a_2424});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam3(V self, V *args) {
  V v_n_2421 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_x_2422 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_str0), heff_intShow(heff_dup(v_n_2421)));
  heff_clo_take(self, 2);
  V v_m_2426 = heff_tr(g_heff_2ecompile_2emonadic_2eoperandsWith_24s56694961x1845510497(v_lit_240, heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s1927221030x1718227373_lam4, 2, 1, (V[]){heff_dup(v_x_2422)})));
  V v_x2_2427 = heff_tr(heff_call(v_m_2426, 1, (V[]){heff_intAdd(v_n_2421, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    V v_n_2429 = heff_field(v_x2_2427, 1);
    V v_ru_24x2_2427_24MkPair = heff_take_reuse_n(v_x2_2427, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2427_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2422, v_e_241, v_x_2428}), v_n_2429});
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_str0, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_lam3(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_entry, 4, 0};

V g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024(V v_lit_240, V v_lit_241, V v_lit_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_ELet: {
    V v_y_244 = heff_field(v_e_243, 0);
    V v_c_245 = heff_field(v_e_243, 1);
    V v_d_246 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_m_247 = (g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024(v_lit_240, v_lit_241, v_lit_242, v_d_246));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_lam0, 1, 3, (V[]){v_m_247, v_y_244, v_c_245});
  }
  case TAG_ESet: {
    V v_ys_2412 = heff_field(v_e_243, 0);
    V v_c_2413 = heff_field(v_e_243, 1);
    V v_d_2414 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_m_2415 = (g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024(v_lit_240, v_lit_241, v_lit_242, v_d_2414));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_lam1, 1, 3, (V[]){v_m_2415, v_ys_2412, v_c_2413});
  }
  default: {
    V v_t_2420 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
      heff_drop(v_t_2420);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_lam2, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2420);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_lam3, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_y_244 = heff_env(self)[1];
  V v_c_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_244, v_c_245, v_x_2410}), v_n_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_lam1(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_ys_2412 = heff_env(self)[1];
  V v_c_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_2412, v_c_2413, v_x_2418}), v_n_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_lam2(V self, V *args) {
  V v_a_2421 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2421});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_lam3(V self, V *args) {
  V v_n_2422 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_x_2423 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s5065382x1587547024_str0), heff_intShow(heff_dup(v_n_2422)));
  heff_clo_take(self, 4);
  V v_t_2424 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2423)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2423, v_e_243, v_t_2424}), heff_intAdd(v_n_2422, MK_INT(1LL))});
}
Clo g_heff_2ecompile_2emonadic_2equiet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2equiet_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2equiet(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    HEFF_LAST return g_list_2eall_24s1366771983x151845067(v_fs_2410);
  }
  case TAG_EProj: {
    V v_e_2412 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2412;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2417 = heff_field(v_x1_240, 1);
    return (g_list_2eall(((V)&g_heff_2ecompile_2emonadic_2equiet_clo), v_args_2417));
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EPrimCall: {
    V v_p_2422 = heff_field(v_x1_240, 0);
    V v_args_2423 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_p_2422)) {
    case TAG_IntShl: {
      return NTAG(TAG_False);
    }
    case TAG_IntShr: {
      return NTAG(TAG_False);
    }
    case TAG_ArrayIndex: {
      return NTAG(TAG_False);
    }
    case TAG_ArrayGenerate: {
      return NTAG(TAG_False);
    }
    case TAG_Keep: {
      return NTAG(TAG_False);
    }
    case TAG_Panic: {
      return NTAG(TAG_False);
    }
    case TAG_Perform: {
      return NTAG(TAG_False);
    }
    case TAG_PerformAt: {
      return NTAG(TAG_False);
    }
    case TAG_BocWhen: {
      return NTAG(TAG_False);
    }
    case TAG_BocNew: {
      return NTAG(TAG_False);
    }
    case TAG_BocTaken: {
      return NTAG(TAG_False);
    }
    case TAG_BocGiven: {
      return NTAG(TAG_False);
    }
    case TAG_ArrayIndexIn: {
      return NTAG(TAG_False);
    }
    case TAG_FuelTick: {
      return NTAG(TAG_False);
    }
    case TAG_FuelTicks: {
      return NTAG(TAG_False);
    }
    case TAG_CustodianDue: {
      return NTAG(TAG_False);
    }
    case TAG_CustodyIn: {
      return NTAG(TAG_False);
    }
    default: {
      return (g_list_2eall(((V)&g_heff_2ecompile_2emonadic_2equiet_clo), v_args_2423));
    }
    }
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EBool: {
    V v_c_2434 = heff_field(v_x1_240, 0);
    V v_t_2435 = (g_heff_2ecompile_2eir_2econdOnto(v_c_2434, NTAG(TAG_Nil)));
    return ({ V a_0 = ((V)&g_heff_2ecompile_2emonadic_2equiet_clo); V a_1 = v_t_2435; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2435); r_; });
  }
  case TAG_ESet: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2evalue(v_x1_240);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2emonadic_2equiet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2emonadic_2equiet(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_str0, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_lam2(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757(V v_e_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_ELet: {
    V v_y_242 = heff_field(v_e_240, 0);
    V v_c_243 = heff_field(v_e_240, 1);
    V v_d_244 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_245 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757(v_d_244, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_lam0, 1, 3, (V[]){v_m_245, v_y_242, v_c_243});
  }
  case TAG_ESet: {
    V v_ys_2410 = heff_field(v_e_240, 0);
    V v_c_2411 = heff_field(v_e_240, 1);
    V v_d_2412 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2413 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757(v_d_2412, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_lam1, 1, 3, (V[]){v_m_2413, v_ys_2410, v_c_2411});
  }
  default: {
    V v_t_2418 = (g_heff_2ecompile_2emonadic_2equiet(v_e_240));
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2418);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_lam2, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_y_242 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_242, v_c_243, v_x_248}), v_n_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ys_2410 = heff_env(self)[1];
  V v_c_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_2410, v_c_2411, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_lam2(V self, V *args) {
  V v_n_2419 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2420 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757_str0), heff_intShow(heff_dup(v_n_2419)));
  heff_clo_take(self, 2);
  V v_m_2421 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2420)})}));
  V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){heff_intAdd(v_n_2419, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    V v_n_2424 = heff_field(v_x2_2422, 1);
    V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2420, v_e_240, v_x_2423}), v_n_2424});
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_lam0(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335(V v_x3_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x3_240)) {
  case TAG_Nil: {
    return heff_tail(v_k_241, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x3_240, 0);
    V v_rest_243 = heff_field(v_x3_240, 1);
    heff_take_n(v_x3_240, 3ULL, 2);
    V v_m_244 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_a_242));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_lam0, 1, 3, (V[]){v_m_244, v_rest_243, v_k_241});
  }
  default: return heff_nomatch(v_x3_240);
  }
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_lam2(V self, V *args) {
  V v_rest_27_2410 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_a_27_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_27_249, v_rest_27_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_lam1(V self, V *args) {
  V v_a_27_249 = args[0];
  V v_rest_243 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335(v_rest_243, heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_lam2, 1, 2, (V[]){v_k_241, v_a_27_249})));
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_rest_243 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    V v_t_2411 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs_24s1968048250x1501081757(v_x_247, heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335_lam1, 1, 2, (V[]){v_rest_243, v_k_241})));
    V f_ = v_t_2411;
    args[0] = v_n_248;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam3(V self, V *args);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam4(V self, V *args);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam5(V self, V *args);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam8(V self, V *args);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam7(V self, V *args);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam6(V self, V *args);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam9(V self, V *args);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam10(V self, V *args);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam11(V self, V *args); static Clo g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam11, 2, 0};
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam12(V self, V *args); static Clo g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam12, 2, 0};
Clo g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EApp: {
    V v_f_241 = heff_field(v_x2_240, 0);
    V v_args_242 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_243 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_f_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam0, 1, 2, (V[]){v_m_243, v_args_242});
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_x2_240, 0);
    V v_a_2410 = heff_field(v_x2_240, 1);
    V v_b_2411 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_2412 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_a_2410));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam1, 1, 3, (V[]){v_m_2412, v_b_2411, v_x_249});
  }
  case TAG_ERecord: {
    V v_fs_2422 = heff_field(v_x2_240, 0);
    V v_ts_2423 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ERecord = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2424 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24x2_240_24ERecord, heff_dup(v_fs_2422)));
    return (g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335(v_t_2424, heff_clo_n(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam2, 1, 2, (V[]){v_fs_2422, v_ts_2423})));
  }
  case TAG_EProj: {
    V v_e_2429 = heff_field(v_x2_240, 0);
    V v_l_2430 = heff_field(v_x2_240, 1);
    V v_sh_2431 = heff_field(v_x2_240, 2);
    V v_t_2432 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_m_2433 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_e_2429));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam4, 1, 4, (V[]){v_m_2433, v_l_2430, v_sh_2431, v_t_2432});
  }
  case TAG_ETag: {
    V v_t_2439 = heff_field(v_x2_240, 0);
    V v_args_2440 = heff_field(v_x2_240, 1);
    V v_ts_2441 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335(v_args_2440, heff_clo_n(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam5, 2, 2, (V[]){v_t_2439, v_ts_2441})));
  }
  case TAG_EMatch: {
    V v_s_2444 = heff_field(v_x2_240, 0);
    V v_arms_2445 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2446 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_s_2444));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam6, 1, 2, (V[]){v_m_2446, v_arms_2445});
  }
  case TAG_EPrimCall: {
    V v_x21_2458 = heff_field(v_x2_240, 0);
    V v_args_2459 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335(v_args_2459, heff_clo_n(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam9, 2, 1, (V[]){v_x21_2458})));
  }
  case TAG_ECall: {
    V v_g_2462 = heff_field(v_x2_240, 0);
    V v_args_2463 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335(v_args_2463, heff_clo_n(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam10, 2, 1, (V[]){v_g_2462})));
  }
  case TAG_EBool: {
    V v_c_2466 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    return (g_heff_2ecompile_2emonadic_2econdN_24s377306777x479528235(v_c_2466, ((V)&g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam11_clo)));
  }
  case TAG_EValues: {
    V v_es_2469 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith_24s1895455084x714840335(v_es_2469, ((V)&g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam12_clo)));
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2etraversePartsM_24s1079778092x1188272986(v_x2_240);
  }
  }
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(a[0]);
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_args_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_n_244}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_n_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs_24s830768518x1268082316(v_args_242, v_x_246));
    V f_ = v_t_248;
    args[0] = v_n_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam1(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_b_2411 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_t_2417 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_b_2411));
    V v_x2_2418 = heff_tr(heff_call(v_t_2417, 1, (V[]){v_n_2416}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_n_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      V v_x_2421 = (g_heff_2ecompile_2emonadic_2eflatLet(v_x_249, v_x_2415, v_x_2419));
      return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){v_x_2421, v_n_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam3(V self, V *args) {
  V v_n_2428 = args[0];
  V v_x_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2427, v_n_2428});
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam2(V self, V *args) {
  V v_vs_2425 = args[0];
  V v_fs_2422 = heff_env(self)[0];
  V v_ts_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2422, v_vs_2425));
  V v_x_2427 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2426, v_ts_2423});
  return heff_clo_n(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam3, 1, 1, (V[]){v_x_2427});
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam4(V self, V *args) {
  V v_n_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_l_2430 = heff_env(self)[1];
  V v_sh_2431 = heff_env(self)[2];
  V v_t_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_n_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_n_2437 = heff_field(v_x2_2435, 1);
    heff_take_n(v_x2_2435, 3ULL, 2);
    V v_t_2438 = (g_heff_2ecompile_2emonadic_2ebindAs_24s2143175432x1815073428(v_l_2430, v_sh_2431, v_t_2432, v_x_2436));
    V f_ = v_t_2438;
    args[0] = v_n_2437;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam5(V self, V *args) {
  V v_args_27_2442 = args[0];
  V v_n_2443 = args[1];
  V v_t_2439 = heff_env(self)[0];
  V v_ts_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2439, v_args_27_2442, v_ts_2441}), v_n_2443});
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam8(V self, V *args) {
  V v_n_2453 = args[0];
  V v_m_2452 = heff_env(self)[0];
  V v_s_27_2451 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2454 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_n_2453}));
  switch (heff_tag_of(v_x2_2454)) {
  case TAG_MkPair: {
    V v_x_2455 = heff_field(v_x2_2454, 0);
    V v_n_2456 = heff_field(v_x2_2454, 1);
    V v_ru_24x2_2454_24MkPair = heff_take_reuse_n(v_x2_2454, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2454_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_27_2451, v_x_2455}), v_n_2456});
  }
  default: return heff_nomatch(v_x2_2454);
  }
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam7(V self, V *args) {
  V v_s_27_2451 = args[0];
  V v_arms_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2452 = (g_prelude_2etraverse_24s1700321227x1313876518(v_arms_2445));
  return heff_clo_n(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam8, 1, 2, (V[]){v_m_2452, v_s_27_2451});
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam6(V self, V *args) {
  V v_n_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_arms_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_n_2450 = heff_field(v_x2_2448, 1);
    heff_take_n(v_x2_2448, 3ULL, 2);
    V v_t_2457 = heff_tr(g_heff_2ecompile_2emonadic_2ebindScrut(v_x_2449, heff_clo_n(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam7, 1, 1, (V[]){v_arms_2445})));
    V f_ = v_t_2457;
    args[0] = v_n_2450;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam9(V self, V *args) {
  V v_args_27_2460 = args[0];
  V v_n_2461 = args[1];
  V v_x21_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_x21_2458, v_args_27_2460}), v_n_2461});
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam10(V self, V *args) {
  V v_args_27_2464 = args[0];
  V v_n_2465 = args[1];
  V v_g_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2462, v_args_27_2464}), v_n_2465});
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam11(V self, V *args) {
  V v_c2_2467 = args[0];
  V v_n_2468 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_c2_2467}), v_n_2468});
}
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_lam12(V self, V *args) {
  V v_es_27_2470 = args[0];
  V v_n_2471 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_es_27_2470}), v_n_2471});
}