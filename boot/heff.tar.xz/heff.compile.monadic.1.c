// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_clo;
V g_heff_2ecompile_2emonadic_2ebindAs(V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_clo;
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(V, V, V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_clo;
V g_heff_2ecompile_2emonadic_2ebindAtom(V, V);
V g_heff_2ecompile_2emonadic_2ebindAtom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAtom_clo;
V g_heff_2ecompile_2emonadic_2ebindScrut(V, V);
V g_heff_2ecompile_2emonadic_2ebindScrut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindScrut_clo;
V g_heff_2ecompile_2emonadic_2econdN(V, V, V);
V g_heff_2ecompile_2emonadic_2econdN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2econdN_clo;
V g_heff_2ecompile_2emonadic_2eflatLet(V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_clo;
V g_heff_2ecompile_2emonadic_2eflatLet_24dps(V, V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_24dps_clo;
V g_heff_2ecompile_2emonadic_2enorm(V);
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enorm_clo;
V g_heff_2ecompile_2emonadic_2eoperandsWith(V, V, V);
V g_heff_2ecompile_2emonadic_2eoperandsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eoperandsWith_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_prelude_2etraverse_24s1566634931x762466996(V);
V g_prelude_2etraverse_24s1566634931x762466996_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1566634931x762466996_clo;
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str0, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str1, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str2, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str3, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str4, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str5, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str6, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str7, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str8, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str9, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str10, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str11, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str12, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str13, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str14, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str15, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str16, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str17, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str18, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str19, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str20, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAtom_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam3(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam4(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam5(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam6(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam7(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam8(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam9(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam10(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam11(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam12(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam13(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam14(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam15(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam16(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam17(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam18(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam19(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam20(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam21(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam22(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAtom_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2ebindAtom(V v_e_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_2442;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
      heff_drop(v_t_2442);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2442);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam0, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EGlobal: {
    V v_t_2489;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2489 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2489 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2489 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2489 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2489 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2489 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2489 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2489 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2489 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_2489) == NTAG(TAG_True))) {
      heff_drop(v_t_2489);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2489);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam1, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ELam: {
    V v_t_24137;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24137 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24137 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24137 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24137 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24137 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24137 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24137 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24137 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24137 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24137 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24137) == NTAG(TAG_True))) {
      heff_drop(v_t_24137);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24137);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam2, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EApp: {
    V v_t_24185;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24185 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24185 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24185 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24185 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24185 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24185 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24185 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24185 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24185 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24185) == NTAG(TAG_True))) {
      heff_drop(v_t_24185);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24185);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam3, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ELet: {
    V v_y_24192 = heff_field(v_e_240, 0);
    V v_c_24193 = heff_field(v_e_240, 1);
    V v_d_24194 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_24195 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAtom(v_d_24194, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam4, 1, 3, (V[]){v_m_24195, v_y_24192, v_c_24193});
  }
  case TAG_ERecord: {
    V v_t_24241;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24241 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24241 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24241 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24241 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24241 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24241 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24241 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24241 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24241 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24241 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24241) == NTAG(TAG_True))) {
      heff_drop(v_t_24241);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24241);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam5, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EProj: {
    V v_t_24291;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24291 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24291 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24291 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24291 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24291 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24291 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24291 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24291 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24291 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24291 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24291) == NTAG(TAG_True))) {
      heff_drop(v_t_24291);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24291);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam6, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ETag: {
    V v_t_24340;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24340 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24340 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24340 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24340 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24340 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24340 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24340 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24340 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24340 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24340 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24340) == NTAG(TAG_True))) {
      heff_drop(v_t_24340);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24340);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam7, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EMatch: {
    V v_t_24388;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24388 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24388 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24388 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24388 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24388 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24388 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24388 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24388 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24388 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24388 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24388) == NTAG(TAG_True))) {
      heff_drop(v_t_24388);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24388);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam8, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EPrim: {
    V v_t_24435;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24435 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24435 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24435 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24435 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24435 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24435 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24435 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24435 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24435 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24435 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24435) == NTAG(TAG_True))) {
      heff_drop(v_t_24435);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24435);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam9, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EPrimCall: {
    V v_t_24483;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24483 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24483 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24483 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24483 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24483 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24483 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24483 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24483 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24483 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24483 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24483) == NTAG(TAG_True))) {
      heff_drop(v_t_24483);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24483);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam10, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ECall: {
    V v_t_24531;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24531 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24531 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24531 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24531 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24531 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24531 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24531 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24531 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24531 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24531 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24531) == NTAG(TAG_True))) {
      heff_drop(v_t_24531);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24531);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam11, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EInt: {
    V v_t_24578;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24578 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24578 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24578 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24578 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24578 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24578 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24578 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24578 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24578 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24578 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24578) == NTAG(TAG_True))) {
      heff_drop(v_t_24578);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24578);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam12, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFloat: {
    V v_t_24625;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24625 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24625 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24625 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24625 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24625 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24625 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24625 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24625 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24625 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24625 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24625) == NTAG(TAG_True))) {
      heff_drop(v_t_24625);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24625);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam13, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EStr: {
    V v_t_24672;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24672 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24672 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24672 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24672 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24672 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24672 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24672 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24672 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24672 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24672 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24672) == NTAG(TAG_True))) {
      heff_drop(v_t_24672);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24672);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam14, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EBytes: {
    V v_t_24719;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24719 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24719 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24719 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24719 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24719 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24719 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24719 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24719 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24719 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24719 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24719) == NTAG(TAG_True))) {
      heff_drop(v_t_24719);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24719);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam15, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFixed: {
    V v_t_24767;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24767 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24767 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24767 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24767 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24767 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24767 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24767 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24767 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24767 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24767 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24767) == NTAG(TAG_True))) {
      heff_drop(v_t_24767);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24767);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam16, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFloat32: {
    V v_t_24814;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24814 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24814 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24814 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24814 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24814 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24814 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24814 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24814 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24814 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24814 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24814) == NTAG(TAG_True))) {
      heff_drop(v_t_24814);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24814);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam17, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EAbandon: {
    V v_t_24860;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24860 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24860 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24860 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24860 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24860 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24860 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24860 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24860 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24860 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24860 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24860) == NTAG(TAG_True))) {
      heff_drop(v_t_24860);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24860);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam18, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EBool: {
    V v_t_24907;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24907 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24907 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24907 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24907 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24907 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24907 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24907 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24907 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24907 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24907 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24907) == NTAG(TAG_True))) {
      heff_drop(v_t_24907);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24907);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam19, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ESet: {
    V v_ys_24914 = heff_field(v_e_240, 0);
    V v_c_24915 = heff_field(v_e_240, 1);
    V v_d_24916 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_24917 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAtom(v_d_24916, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam20, 1, 3, (V[]){v_m_24917, v_ys_24914, v_c_24915});
  }
  case TAG_EValues: {
    V v_t_24962;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24962 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24962 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24962 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24962 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24962 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24962 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24962 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24962 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24962 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24962 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24962) == NTAG(TAG_True))) {
      heff_drop(v_t_24962);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24962);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam21, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFix: {
    V v_t_241010;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_241010 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_241010 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_241010 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_241010 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_241010 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_241010 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_241010 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_241010 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_241010 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_241010 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_241010) == NTAG(TAG_True))) {
      heff_drop(v_t_241010);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_241010);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam22, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAtom(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam0(V self, V *args) {
  V v_n_2443 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2444 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str0), heff_intShow(heff_dup(v_n_2443)));
  V v_m_2445 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2444)})}));
  V v_x2_2446 = heff_tr(heff_call(v_m_2445, 1, (V[]){heff_intAdd(v_n_2443, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2446)) {
  case TAG_MkPair: {
    V v_x_2447 = heff_field(v_x2_2446, 0);
    V v_n_2448 = heff_field(v_x2_2446, 1);
    V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2444, v_e_240, v_x_2447}), v_n_2448});
  }
  default: return heff_nomatch(v_x2_2446);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam1(V self, V *args) {
  V v_n_2490 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2491 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str1), heff_intShow(heff_dup(v_n_2490)));
  V v_m_2492 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2491)})}));
  V v_x2_2493 = heff_tr(heff_call(v_m_2492, 1, (V[]){heff_intAdd(v_n_2490, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_MkPair: {
    V v_x_2494 = heff_field(v_x2_2493, 0);
    V v_n_2495 = heff_field(v_x2_2493, 1);
    V v_ru_24x2_2493_24MkPair = heff_take_reuse_n(v_x2_2493, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2493_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2491, v_e_240, v_x_2494}), v_n_2495});
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam2(V self, V *args) {
  V v_n_24138 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24139 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str2), heff_intShow(heff_dup(v_n_24138)));
  V v_m_24140 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24139)})}));
  V v_x2_24141 = heff_tr(heff_call(v_m_24140, 1, (V[]){heff_intAdd(v_n_24138, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24141)) {
  case TAG_MkPair: {
    V v_x_24142 = heff_field(v_x2_24141, 0);
    V v_n_24143 = heff_field(v_x2_24141, 1);
    V v_ru_24x2_24141_24MkPair = heff_take_reuse_n(v_x2_24141, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24141_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24139, v_e_240, v_x_24142}), v_n_24143});
  }
  default: return heff_nomatch(v_x2_24141);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam3(V self, V *args) {
  V v_n_24186 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24187 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str3), heff_intShow(heff_dup(v_n_24186)));
  V v_m_24188 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24187)})}));
  V v_x2_24189 = heff_tr(heff_call(v_m_24188, 1, (V[]){heff_intAdd(v_n_24186, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24189)) {
  case TAG_MkPair: {
    V v_x_24190 = heff_field(v_x2_24189, 0);
    V v_n_24191 = heff_field(v_x2_24189, 1);
    V v_ru_24x2_24189_24MkPair = heff_take_reuse_n(v_x2_24189, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24187, v_e_240, v_x_24190}), v_n_24191});
  }
  default: return heff_nomatch(v_x2_24189);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam4(V self, V *args) {
  V v_n_24196 = args[0];
  V v_m_24195 = heff_env(self)[0];
  V v_y_24192 = heff_env(self)[1];
  V v_c_24193 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24197 = heff_tr(heff_call(v_m_24195, 1, (V[]){v_n_24196}));
  switch (heff_tag_of(v_x2_24197)) {
  case TAG_MkPair: {
    V v_x_24198 = heff_field(v_x2_24197, 0);
    V v_n_24199 = heff_field(v_x2_24197, 1);
    V v_ru_24x2_24197_24MkPair = heff_take_reuse_n(v_x2_24197, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_24192, v_c_24193, v_x_24198}), v_n_24199});
  }
  default: return heff_nomatch(v_x2_24197);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam5(V self, V *args) {
  V v_n_24242 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24243 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str4), heff_intShow(heff_dup(v_n_24242)));
  V v_m_24244 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24243)})}));
  V v_x2_24245 = heff_tr(heff_call(v_m_24244, 1, (V[]){heff_intAdd(v_n_24242, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24245)) {
  case TAG_MkPair: {
    V v_x_24246 = heff_field(v_x2_24245, 0);
    V v_n_24247 = heff_field(v_x2_24245, 1);
    V v_ru_24x2_24245_24MkPair = heff_take_reuse_n(v_x2_24245, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24243, v_e_240, v_x_24246}), v_n_24247});
  }
  default: return heff_nomatch(v_x2_24245);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam6(V self, V *args) {
  V v_n_24292 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24293 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str5), heff_intShow(heff_dup(v_n_24292)));
  V v_m_24294 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24293)})}));
  V v_x2_24295 = heff_tr(heff_call(v_m_24294, 1, (V[]){heff_intAdd(v_n_24292, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24295)) {
  case TAG_MkPair: {
    V v_x_24296 = heff_field(v_x2_24295, 0);
    V v_n_24297 = heff_field(v_x2_24295, 1);
    V v_ru_24x2_24295_24MkPair = heff_take_reuse_n(v_x2_24295, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24295_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24293, v_e_240, v_x_24296}), v_n_24297});
  }
  default: return heff_nomatch(v_x2_24295);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam7(V self, V *args) {
  V v_n_24341 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24342 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str6), heff_intShow(heff_dup(v_n_24341)));
  V v_m_24343 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24342)})}));
  V v_x2_24344 = heff_tr(heff_call(v_m_24343, 1, (V[]){heff_intAdd(v_n_24341, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24344)) {
  case TAG_MkPair: {
    V v_x_24345 = heff_field(v_x2_24344, 0);
    V v_n_24346 = heff_field(v_x2_24344, 1);
    V v_ru_24x2_24344_24MkPair = heff_take_reuse_n(v_x2_24344, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24344_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24342, v_e_240, v_x_24345}), v_n_24346});
  }
  default: return heff_nomatch(v_x2_24344);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam8(V self, V *args) {
  V v_n_24389 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24390 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str7), heff_intShow(heff_dup(v_n_24389)));
  V v_m_24391 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24390)})}));
  V v_x2_24392 = heff_tr(heff_call(v_m_24391, 1, (V[]){heff_intAdd(v_n_24389, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24392)) {
  case TAG_MkPair: {
    V v_x_24393 = heff_field(v_x2_24392, 0);
    V v_n_24394 = heff_field(v_x2_24392, 1);
    V v_ru_24x2_24392_24MkPair = heff_take_reuse_n(v_x2_24392, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24390, v_e_240, v_x_24393}), v_n_24394});
  }
  default: return heff_nomatch(v_x2_24392);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam9(V self, V *args) {
  V v_n_24436 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24437 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str8), heff_intShow(heff_dup(v_n_24436)));
  V v_m_24438 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24437)})}));
  V v_x2_24439 = heff_tr(heff_call(v_m_24438, 1, (V[]){heff_intAdd(v_n_24436, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24439)) {
  case TAG_MkPair: {
    V v_x_24440 = heff_field(v_x2_24439, 0);
    V v_n_24441 = heff_field(v_x2_24439, 1);
    V v_ru_24x2_24439_24MkPair = heff_take_reuse_n(v_x2_24439, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24437, v_e_240, v_x_24440}), v_n_24441});
  }
  default: return heff_nomatch(v_x2_24439);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam10(V self, V *args) {
  V v_n_24484 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24485 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str9), heff_intShow(heff_dup(v_n_24484)));
  V v_m_24486 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24485)})}));
  V v_x2_24487 = heff_tr(heff_call(v_m_24486, 1, (V[]){heff_intAdd(v_n_24484, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24487)) {
  case TAG_MkPair: {
    V v_x_24488 = heff_field(v_x2_24487, 0);
    V v_n_24489 = heff_field(v_x2_24487, 1);
    V v_ru_24x2_24487_24MkPair = heff_take_reuse_n(v_x2_24487, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24487_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24485, v_e_240, v_x_24488}), v_n_24489});
  }
  default: return heff_nomatch(v_x2_24487);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam11(V self, V *args) {
  V v_n_24532 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24533 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str10), heff_intShow(heff_dup(v_n_24532)));
  V v_m_24534 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24533)})}));
  V v_x2_24535 = heff_tr(heff_call(v_m_24534, 1, (V[]){heff_intAdd(v_n_24532, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24535)) {
  case TAG_MkPair: {
    V v_x_24536 = heff_field(v_x2_24535, 0);
    V v_n_24537 = heff_field(v_x2_24535, 1);
    V v_ru_24x2_24535_24MkPair = heff_take_reuse_n(v_x2_24535, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24535_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24533, v_e_240, v_x_24536}), v_n_24537});
  }
  default: return heff_nomatch(v_x2_24535);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam12(V self, V *args) {
  V v_n_24579 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24580 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str11), heff_intShow(heff_dup(v_n_24579)));
  V v_m_24581 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24580)})}));
  V v_x2_24582 = heff_tr(heff_call(v_m_24581, 1, (V[]){heff_intAdd(v_n_24579, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24582)) {
  case TAG_MkPair: {
    V v_x_24583 = heff_field(v_x2_24582, 0);
    V v_n_24584 = heff_field(v_x2_24582, 1);
    V v_ru_24x2_24582_24MkPair = heff_take_reuse_n(v_x2_24582, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24582_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24580, v_e_240, v_x_24583}), v_n_24584});
  }
  default: return heff_nomatch(v_x2_24582);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam13(V self, V *args) {
  V v_n_24626 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24627 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str12), heff_intShow(heff_dup(v_n_24626)));
  V v_m_24628 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24627)})}));
  V v_x2_24629 = heff_tr(heff_call(v_m_24628, 1, (V[]){heff_intAdd(v_n_24626, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24629)) {
  case TAG_MkPair: {
    V v_x_24630 = heff_field(v_x2_24629, 0);
    V v_n_24631 = heff_field(v_x2_24629, 1);
    V v_ru_24x2_24629_24MkPair = heff_take_reuse_n(v_x2_24629, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24629_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24627, v_e_240, v_x_24630}), v_n_24631});
  }
  default: return heff_nomatch(v_x2_24629);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam14(V self, V *args) {
  V v_n_24673 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24674 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str13), heff_intShow(heff_dup(v_n_24673)));
  V v_m_24675 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24674)})}));
  V v_x2_24676 = heff_tr(heff_call(v_m_24675, 1, (V[]){heff_intAdd(v_n_24673, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24676)) {
  case TAG_MkPair: {
    V v_x_24677 = heff_field(v_x2_24676, 0);
    V v_n_24678 = heff_field(v_x2_24676, 1);
    V v_ru_24x2_24676_24MkPair = heff_take_reuse_n(v_x2_24676, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24676_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24674, v_e_240, v_x_24677}), v_n_24678});
  }
  default: return heff_nomatch(v_x2_24676);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam15(V self, V *args) {
  V v_n_24720 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24721 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str14), heff_intShow(heff_dup(v_n_24720)));
  V v_m_24722 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24721)})}));
  V v_x2_24723 = heff_tr(heff_call(v_m_24722, 1, (V[]){heff_intAdd(v_n_24720, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24723)) {
  case TAG_MkPair: {
    V v_x_24724 = heff_field(v_x2_24723, 0);
    V v_n_24725 = heff_field(v_x2_24723, 1);
    V v_ru_24x2_24723_24MkPair = heff_take_reuse_n(v_x2_24723, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24723_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24721, v_e_240, v_x_24724}), v_n_24725});
  }
  default: return heff_nomatch(v_x2_24723);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam16(V self, V *args) {
  V v_n_24768 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24769 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str15), heff_intShow(heff_dup(v_n_24768)));
  V v_m_24770 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24769)})}));
  V v_x2_24771 = heff_tr(heff_call(v_m_24770, 1, (V[]){heff_intAdd(v_n_24768, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24771)) {
  case TAG_MkPair: {
    V v_x_24772 = heff_field(v_x2_24771, 0);
    V v_n_24773 = heff_field(v_x2_24771, 1);
    V v_ru_24x2_24771_24MkPair = heff_take_reuse_n(v_x2_24771, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24771_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24769, v_e_240, v_x_24772}), v_n_24773});
  }
  default: return heff_nomatch(v_x2_24771);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam17(V self, V *args) {
  V v_n_24815 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24816 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str16), heff_intShow(heff_dup(v_n_24815)));
  V v_m_24817 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24816)})}));
  V v_x2_24818 = heff_tr(heff_call(v_m_24817, 1, (V[]){heff_intAdd(v_n_24815, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24818)) {
  case TAG_MkPair: {
    V v_x_24819 = heff_field(v_x2_24818, 0);
    V v_n_24820 = heff_field(v_x2_24818, 1);
    V v_ru_24x2_24818_24MkPair = heff_take_reuse_n(v_x2_24818, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24818_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24816, v_e_240, v_x_24819}), v_n_24820});
  }
  default: return heff_nomatch(v_x2_24818);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam18(V self, V *args) {
  V v_n_24861 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24862 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str17), heff_intShow(heff_dup(v_n_24861)));
  V v_m_24863 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24862)})}));
  V v_x2_24864 = heff_tr(heff_call(v_m_24863, 1, (V[]){heff_intAdd(v_n_24861, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24864)) {
  case TAG_MkPair: {
    V v_x_24865 = heff_field(v_x2_24864, 0);
    V v_n_24866 = heff_field(v_x2_24864, 1);
    V v_ru_24x2_24864_24MkPair = heff_take_reuse_n(v_x2_24864, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24864_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24862, v_e_240, v_x_24865}), v_n_24866});
  }
  default: return heff_nomatch(v_x2_24864);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam19(V self, V *args) {
  V v_n_24908 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24909 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str18), heff_intShow(heff_dup(v_n_24908)));
  V v_m_24910 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24909)})}));
  V v_x2_24911 = heff_tr(heff_call(v_m_24910, 1, (V[]){heff_intAdd(v_n_24908, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24911)) {
  case TAG_MkPair: {
    V v_x_24912 = heff_field(v_x2_24911, 0);
    V v_n_24913 = heff_field(v_x2_24911, 1);
    V v_ru_24x2_24911_24MkPair = heff_take_reuse_n(v_x2_24911, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24911_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24909, v_e_240, v_x_24912}), v_n_24913});
  }
  default: return heff_nomatch(v_x2_24911);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam20(V self, V *args) {
  V v_n_24918 = args[0];
  V v_m_24917 = heff_env(self)[0];
  V v_ys_24914 = heff_env(self)[1];
  V v_c_24915 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24919 = heff_tr(heff_call(v_m_24917, 1, (V[]){v_n_24918}));
  switch (heff_tag_of(v_x2_24919)) {
  case TAG_MkPair: {
    V v_x_24920 = heff_field(v_x2_24919, 0);
    V v_n_24921 = heff_field(v_x2_24919, 1);
    V v_ru_24x2_24919_24MkPair = heff_take_reuse_n(v_x2_24919, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24919_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_24914, v_c_24915, v_x_24920}), v_n_24921});
  }
  default: return heff_nomatch(v_x2_24919);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam21(V self, V *args) {
  V v_n_24963 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24964 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str19), heff_intShow(heff_dup(v_n_24963)));
  V v_m_24965 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24964)})}));
  V v_x2_24966 = heff_tr(heff_call(v_m_24965, 1, (V[]){heff_intAdd(v_n_24963, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24966)) {
  case TAG_MkPair: {
    V v_x_24967 = heff_field(v_x2_24966, 0);
    V v_n_24968 = heff_field(v_x2_24966, 1);
    V v_ru_24x2_24966_24MkPair = heff_take_reuse_n(v_x2_24966, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24966_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24964, v_e_240, v_x_24967}), v_n_24968});
  }
  default: return heff_nomatch(v_x2_24966);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam22(V self, V *args) {
  V v_n_241011 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_241012 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str20), heff_intShow(heff_dup(v_n_241011)));
  V v_m_241013 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_241012)})}));
  V v_x2_241014 = heff_tr(heff_call(v_m_241013, 1, (V[]){heff_intAdd(v_n_241011, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_241014)) {
  case TAG_MkPair: {
    V v_x_241015 = heff_field(v_x2_241014, 0);
    V v_n_241016 = heff_field(v_x2_241014, 1);
    V v_ru_24x2_241014_24MkPair = heff_take_reuse_n(v_x2_241014, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_241014_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241012, v_e_240, v_x_241015}), v_n_241016});
  }
  default: return heff_nomatch(v_x2_241014);
  }
}
Clo g_heff_2ecompile_2emonadic_2eflatLet_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry, 4, 0};

V g_heff_2ecompile_2emonadic_2eflatLet_24dps(V v_x_240, V v_a_241, V v_b_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EGlobal: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ELam: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EApp: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ELet: {
    V v_y_2410 = heff_field(v_a_241, 0);
    V v_c_2411 = heff_field(v_a_241, 1);
    V v_d_2412 = heff_field(v_a_241, 2);
    V v_ru_24a_241_24ELet = heff_take_reuse_n(v_a_241, 7ULL, 3);
    V v_cell_2413 = heff_tag_at_n(v_ru_24a_241_24ELet, TAG_ELet, 3, (V[]){v_y_2410, v_c_2411, heff_hole()});
    V v_u_2414 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_x_240;
    V t_1 = v_d_2412;
    V t_2 = v_b_242;
    V t_3 = v_cell_2413;
    v_x_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EProj: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ETag: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EMatch: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EPrim: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EPrimCall: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ECall: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EInt: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFloat: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EStr: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EBytes: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFixed: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFloat32: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EAbandon: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EBool: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ESet: {
    V v_ys_2439 = heff_field(v_a_241, 0);
    V v_c_2440 = heff_field(v_a_241, 1);
    V v_d_2441 = heff_field(v_a_241, 2);
    V v_ru_24a_241_24ESet = heff_take_reuse_n(v_a_241, 7ULL, 3);
    V v_cell_2442 = heff_tag_at_n(v_ru_24a_241_24ESet, TAG_ESet, 3, (V[]){v_ys_2439, v_c_2440, heff_hole()});
    V v_u_2443 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_2442));
    heff_drop(v_u_2443);
    V t_0 = v_x_240;
    V t_1 = v_d_2441;
    V t_2 = v_b_242;
    V t_3 = v_cell_2442;
    v_x_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_EValues: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFix: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2eflatLet_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2emonadic_2econdN_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2econdN_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2econdN_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2econdN_lam3(V self, V *args);
V g_heff_2ecompile_2emonadic_2econdN_lam5(V self, V *args);
V g_heff_2ecompile_2emonadic_2econdN_lam4(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2econdN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2econdN_entry, 3, 0};

V g_heff_2ecompile_2emonadic_2econdN(V v_go_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    heff_drop(v_go_240);
    return heff_tail(v_k_242, 1, (V[]){v_x2_241});
  }
  case TAG_CFalse: {
    heff_drop(v_go_240);
    return heff_tail(v_k_242, 1, (V[]){v_x2_241});
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x2_241, 0);
    V v_a_244 = heff_field(v_x2_241, 1);
    V v_b_245 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_245), NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2emonadic_2eoperandsWith(v_go_240, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_244), v_t_246}), heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam0, 1, 4, (V[]){v_k_242, v_p_243, v_a_244, v_b_245}));
  }
  case TAG_CTest: {
    V v_e_2414 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2415 = heff_tr(heff_call(v_go_240, 1, (V[]){v_e_2414}));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam1, 1, 2, (V[]){v_m_2415, v_k_242});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V t_0 = v_go_240;
    V t_1 = v_c_2422;
    V t_2 = heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam3, 1, 1, (V[]){v_k_242});
    v_go_240 = t_0;
    v_x2_241 = t_1;
    v_k_242 = t_2;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2424 = heff_field(v_x2_241, 0);
    V v_b_2425 = heff_field(v_x2_241, 1);
    V v_c_2426 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V t_0 = heff_dup(v_go_240);
    V t_1 = v_a_2424;
    V t_2 = heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam4, 1, 4, (V[]){v_go_240, v_b_2425, v_c_2426, v_k_242});
    v_go_240 = t_0;
    v_x2_241 = t_1;
    v_k_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2emonadic_2econdN_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2econdN(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2emonadic_2econdN_lam0(V self, V *args) {
  V v_vs_247 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_a_244 = heff_env(self)[2];
  V v_b_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_vs_247)) {
  case TAG_Nil: {
    V f_ = v_k_242;
    args[0] = heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_a_244, v_b_245});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_a2_248 = heff_field(v_vs_247, 0);
    V v_it2_249 = heff_field(v_vs_247, 1);
    heff_take_n(v_vs_247, 3ULL, 2);
    switch (heff_tag_of(v_it2_249)) {
    case TAG_Nil: {
      heff_drop(v_a2_248);
      V f_ = v_k_242;
      args[0] = heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_a_244, v_b_245});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_b2_2410 = heff_field(v_it2_249, 0);
      V v_it22_2411 = heff_field(v_it2_249, 1);
      heff_take_n(v_it2_249, 3ULL, 2);
      switch (heff_tag_of(v_it22_2411)) {
      case TAG_Nil: {
        heff_drop(v_a_244);
        heff_drop(v_b_245);
        V f_ = v_k_242;
        args[0] = heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_a2_248, v_b2_2410});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        heff_take_n(v_it22_2411, 0ULL, 2);
        heff_drop(v_a2_248);
        heff_drop(v_b2_2410);
        V f_ = v_k_242;
        args[0] = heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_a_244, v_b_245});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_it22_2411);
      }
    }
    default: return heff_nomatch(v_it2_249);
    }
  }
  default: return heff_nomatch(v_vs_247);
  }
}
V g_heff_2ecompile_2emonadic_2econdN_lam2(V self, V *args) {
  V v_e2_2420 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_CTest, 1, (V[]){v_e2_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2emonadic_2econdN_lam1(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    heff_take_n(v_x2_2417, 3ULL, 2);
    V v_t_2421 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_x_2418, heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam2, 1, 1, (V[]){v_k_242})));
    V f_ = v_t_2421;
    args[0] = v_n_2419;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2emonadic_2econdN_lam3(V self, V *args) {
  V v_c2_2423 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_CNot, 1, (V[]){v_c2_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2emonadic_2econdN_lam5(V self, V *args) {
  V v_n_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_c_2426 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_a2_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_n_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_n_2432 = heff_field(v_x2_2430, 1);
    heff_take_n(v_x2_2430, 3ULL, 2);
    V v_m_2433 = (g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508(v_go_240, v_c_2426));
    V v_x2_2434 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_n_2432}));
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_MkPair: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      V v_n_2436 = heff_field(v_x2_2434, 1);
      heff_take_n(v_x2_2434, 3ULL, 2);
      V f_ = v_k_242;
      heff_room[0] = heff_tag_n(TAG_CIf, 3, (V[]){v_a2_2427, v_x_2431, v_x_2435});
      heff_room[1] = v_n_2436;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_x2_2434);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecompile_2emonadic_2econdN_lam4(V self, V *args) {
  V v_a2_2427 = args[0];
  V v_go_240 = heff_env(self)[0];
  V v_b_2425 = heff_env(self)[1];
  V v_c_2426 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_m_2428 = (g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508(heff_dup(v_go_240), v_b_2425));
  return heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam5, 1, 5, (V[]){v_m_2428, v_go_240, v_c_2426, v_k_242, v_a2_2427});
}
V g_heff_2ecompile_2emonadic_2enorm_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam5(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam4(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam3(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam6(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam8(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam7(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam9(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam10(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam13(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam12(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam11(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam14(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam15(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam16(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam17(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam18(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam19(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam20(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam21(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam22(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam23(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam24(V self, V *args); static Clo g_heff_2ecompile_2emonadic_2enorm_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2enorm_lam24, 2, 0};
V g_heff_2ecompile_2emonadic_2enorm_lam25(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam26(V self, V *args); static Clo g_heff_2ecompile_2emonadic_2enorm_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2enorm_lam26, 2, 0};
V g_heff_2ecompile_2emonadic_2enorm_lam27(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2enorm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2enorm_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2enorm(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam0, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam1, 1, 1, (V[]){v_x1_240});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x1_240, 0);
    V v_b_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_247 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_b_246));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam2, 1, 2, (V[]){v_m_247, v_xs_245});
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_x1_240, 0);
    V v_args_2413 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_2414 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_f_2412));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam3, 1, 2, (V[]){v_m_2414, v_args_2413});
  }
  case TAG_ELet: {
    V v_x_2423 = heff_field(v_x1_240, 0);
    V v_a_2424 = heff_field(v_x1_240, 1);
    V v_b_2425 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_m_2426 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_a_2424));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam6, 1, 3, (V[]){v_m_2426, v_b_2425, v_x_2423});
  }
  case TAG_ERecord: {
    V v_fs_2436 = heff_field(v_x1_240, 0);
    V v_ts_2437 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2438 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24x1_240_24ERecord, heff_dup(v_fs_2436)));
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_t_2438, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam7, 1, 2, (V[]){v_fs_2436, v_ts_2437})));
  }
  case TAG_EProj: {
    V v_e_2443 = heff_field(v_x1_240, 0);
    V v_l_2444 = heff_field(v_x1_240, 1);
    V v_sh_2445 = heff_field(v_x1_240, 2);
    V v_t_2446 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    V v_m_2447 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_e_2443));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam9, 1, 4, (V[]){v_m_2447, v_l_2444, v_sh_2445, v_t_2446});
  }
  case TAG_ETag: {
    V v_t_2453 = heff_field(v_x1_240, 0);
    V v_args_2454 = heff_field(v_x1_240, 1);
    V v_ts_2455 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_args_2454, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam10, 2, 2, (V[]){v_t_2453, v_ts_2455})));
  }
  case TAG_EMatch: {
    V v_s_2458 = heff_field(v_x1_240, 0);
    V v_arms_2459 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_2460 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_s_2458));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam11, 1, 2, (V[]){v_m_2460, v_arms_2459});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam14, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EPrimCall: {
    V v_p_2474 = heff_field(v_x1_240, 0);
    V v_args_2475 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_args_2475, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam15, 2, 1, (V[]){v_p_2474})));
  }
  case TAG_ECall: {
    V v_g_2478 = heff_field(v_x1_240, 0);
    V v_args_2479 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_args_2479, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam16, 2, 1, (V[]){v_g_2478})));
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam17, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam18, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam19, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam20, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam21, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam22, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam23, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EBool: {
    V v_c_2496 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return (g_heff_2ecompile_2emonadic_2econdN(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_c_2496, ((V)&g_heff_2ecompile_2emonadic_2enorm_lam24_clo)));
  }
  case TAG_ESet: {
    V v_xs_2499 = heff_field(v_x1_240, 0);
    V v_a_24100 = heff_field(v_x1_240, 1);
    V v_b_24101 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_m_24102 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_a_24100));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam25, 1, 3, (V[]){v_m_24102, v_b_24101, v_xs_2499});
  }
  case TAG_EValues: {
    V v_es_24111 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_es_24111, ((V)&g_heff_2ecompile_2emonadic_2enorm_lam26_clo)));
  }
  case TAG_EFix: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam27, 1, 1, (V[]){v_x1_240});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2enorm(a[0]);
}
V g_heff_2ecompile_2emonadic_2enorm_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_242});
}
V g_heff_2ecompile_2emonadic_2enorm_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_244});
}
V g_heff_2ecompile_2emonadic_2enorm_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_245, v_x_2410}), v_n_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam5(V self, V *args) {
  V v_args_27_2420 = args[0];
  V v_n_2421 = args[1];
  V v_f_27_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_27_2419, v_args_27_2420}), v_n_2421});
}
V g_heff_2ecompile_2emonadic_2enorm_lam4(V self, V *args) {
  V v_f_27_2419 = args[0];
  V v_args_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_args_2413, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam5, 2, 1, (V[]){v_f_27_2419})));
}
V g_heff_2ecompile_2emonadic_2enorm_lam3(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_args_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    heff_take_n(v_x2_2416, 3ULL, 2);
    V v_t_2422 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_x_2417, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam4, 1, 1, (V[]){v_args_2413})));
    V f_ = v_t_2422;
    args[0] = v_n_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam6(V self, V *args) {
  V v_n_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  V v_b_2425 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_n_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_n_2430 = heff_field(v_x2_2428, 1);
    V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
    V v_m_2431 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_b_2425));
    V v_x2_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2430}));
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_MkPair: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_n_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      V v_x_2435 = (g_heff_2ecompile_2emonadic_2eflatLet(v_x_2423, v_x_2429, v_x_2433));
      return heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){v_x_2435, v_n_2434});
    }
    default: return heff_nomatch(v_x2_2432);
    }
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam8(V self, V *args) {
  V v_n_2442 = args[0];
  V v_x_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2441, v_n_2442});
}
V g_heff_2ecompile_2emonadic_2enorm_lam7(V self, V *args) {
  V v_vs_2439 = args[0];
  V v_fs_2436 = heff_env(self)[0];
  V v_ts_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2436, v_vs_2439));
  V v_x_2441 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2440, v_ts_2437});
  return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam8, 1, 1, (V[]){v_x_2441});
}
V g_heff_2ecompile_2emonadic_2enorm_lam9(V self, V *args) {
  V v_n_2448 = args[0];
  V v_m_2447 = heff_env(self)[0];
  V v_l_2444 = heff_env(self)[1];
  V v_sh_2445 = heff_env(self)[2];
  V v_t_2446 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2449 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_n_2448}));
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_n_2451 = heff_field(v_x2_2449, 1);
    heff_take_n(v_x2_2449, 3ULL, 2);
    V v_t_2452 = (g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(v_l_2444, v_sh_2445, v_t_2446, v_x_2450));
    V f_ = v_t_2452;
    args[0] = v_n_2451;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam10(V self, V *args) {
  V v_args_27_2456 = args[0];
  V v_n_2457 = args[1];
  V v_t_2453 = heff_env(self)[0];
  V v_ts_2455 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2453, v_args_27_2456, v_ts_2455}), v_n_2457});
}
V g_heff_2ecompile_2emonadic_2enorm_lam13(V self, V *args) {
  V v_n_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_s_27_2465 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_n_2467}));
  switch (heff_tag_of(v_x2_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_field(v_x2_2468, 0);
    V v_n_2470 = heff_field(v_x2_2468, 1);
    V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_27_2465, v_x_2469}), v_n_2470});
  }
  default: return heff_nomatch(v_x2_2468);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam12(V self, V *args) {
  V v_s_27_2465 = args[0];
  V v_arms_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2466 = (g_prelude_2etraverse_24s1566634931x762466996(v_arms_2459));
  return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam13, 1, 2, (V[]){v_m_2466, v_s_27_2465});
}
V g_heff_2ecompile_2emonadic_2enorm_lam11(V self, V *args) {
  V v_n_2461 = args[0];
  V v_m_2460 = heff_env(self)[0];
  V v_arms_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2462 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_n_2461}));
  switch (heff_tag_of(v_x2_2462)) {
  case TAG_MkPair: {
    V v_x_2463 = heff_field(v_x2_2462, 0);
    V v_n_2464 = heff_field(v_x2_2462, 1);
    heff_take_n(v_x2_2462, 3ULL, 2);
    V v_t_2471 = heff_tr(g_heff_2ecompile_2emonadic_2ebindScrut(v_x_2463, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam12, 1, 1, (V[]){v_arms_2459})));
    V f_ = v_t_2471;
    args[0] = v_n_2464;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2462);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam14(V self, V *args) {
  V v_n_2473 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2473});
}
V g_heff_2ecompile_2emonadic_2enorm_lam15(V self, V *args) {
  V v_args_27_2476 = args[0];
  V v_n_2477 = args[1];
  V v_p_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2474, v_args_27_2476}), v_n_2477});
}
V g_heff_2ecompile_2emonadic_2enorm_lam16(V self, V *args) {
  V v_args_27_2480 = args[0];
  V v_n_2481 = args[1];
  V v_g_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2478, v_args_27_2480}), v_n_2481});
}
V g_heff_2ecompile_2emonadic_2enorm_lam17(V self, V *args) {
  V v_n_2483 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2483});
}
V g_heff_2ecompile_2emonadic_2enorm_lam18(V self, V *args) {
  V v_n_2485 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2485});
}
V g_heff_2ecompile_2emonadic_2enorm_lam19(V self, V *args) {
  V v_n_2487 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2487});
}
V g_heff_2ecompile_2emonadic_2enorm_lam20(V self, V *args) {
  V v_n_2489 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2489});
}
V g_heff_2ecompile_2emonadic_2enorm_lam21(V self, V *args) {
  V v_n_2492 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2492});
}
V g_heff_2ecompile_2emonadic_2enorm_lam22(V self, V *args) {
  V v_n_2494 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2494});
}
V g_heff_2ecompile_2emonadic_2enorm_lam23(V self, V *args) {
  V v_n_2495 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2495});
}
V g_heff_2ecompile_2emonadic_2enorm_lam24(V self, V *args) {
  V v_c2_2497 = args[0];
  V v_n_2498 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_c2_2497}), v_n_2498});
}
V g_heff_2ecompile_2emonadic_2enorm_lam25(V self, V *args) {
  V v_n_24103 = args[0];
  V v_m_24102 = heff_env(self)[0];
  V v_b_24101 = heff_env(self)[1];
  V v_xs_2499 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24104 = heff_tr(heff_call(v_m_24102, 1, (V[]){v_n_24103}));
  switch (heff_tag_of(v_x2_24104)) {
  case TAG_MkPair: {
    V v_x_24105 = heff_field(v_x2_24104, 0);
    V v_n_24106 = heff_field(v_x2_24104, 1);
    V v_ru_24x2_24104_24MkPair = heff_take_reuse_n(v_x2_24104, 3ULL, 2);
    V v_m_24107 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_b_24101));
    V v_x2_24108 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_n_24106}));
    switch (heff_tag_of(v_x2_24108)) {
    case TAG_MkPair: {
      V v_x_24109 = heff_field(v_x2_24108, 0);
      V v_n_24110 = heff_field(v_x2_24108, 1);
      heff_take_n(v_x2_24108, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24104_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2499, v_x_24105, v_x_24109}), v_n_24110});
    }
    default: return heff_nomatch(v_x2_24108);
    }
  }
  default: return heff_nomatch(v_x2_24104);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam26(V self, V *args) {
  V v_es_27_24112 = args[0];
  V v_n_24113 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_es_27_24112}), v_n_24113});
}
V g_heff_2ecompile_2emonadic_2enorm_lam27(V self, V *args) {
  V v_n_24116 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24116});
}