// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
V g_heff_2ecompile_2emonadic_2ebindAs(V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_clo;
V g_heff_2ecompile_2emonadic_2ebindAtom(V, V);
V g_heff_2ecompile_2emonadic_2ebindAtom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAtom_clo;
V g_heff_2ecompile_2emonadic_2eflatLet(V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_clo;
V g_heff_2ecompile_2emonadic_2eflatLet_24dps(V, V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_24dps_clo;
V g_heff_2ecompile_2emonadic_2enorm(V);
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enorm_clo;
V g_heff_2ecompile_2emonadic_2eoperandsWith(V, V, V);
V g_heff_2ecompile_2emonadic_2eoperandsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eoperandsWith_clo;
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287(V);
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str0, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str1, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str2, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str3, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str4, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str5, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str6, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str7, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str8, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str9, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str10, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str11, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str12, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str13, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str14, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str15, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str16, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str17, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str18, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAtom_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam3(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam4(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam5(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam6(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam7(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam8(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam9(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam10(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam11(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam12(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam13(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam14(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam15(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam16(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam17(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam18(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam19(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAtom_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2ebindAtom(V v_e_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_2436;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop(v_t_2436);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2436);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam0, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EGlobal: {
    V v_t_2477;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2477 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2477 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2477 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2477 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2477 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2477 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2477 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2477 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2477 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2477 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_2477) == NTAG(TAG_True))) {
      heff_drop(v_t_2477);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2477);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam1, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ELam: {
    V v_t_24119;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24119 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24119 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24119 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24119 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24119 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24119 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24119 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24119 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24119 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24119) == NTAG(TAG_True))) {
      heff_drop(v_t_24119);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24119);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam2, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EApp: {
    V v_t_24161;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24161 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24161 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24161 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24161 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24161 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24161 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24161 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24161 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24161 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24161) == NTAG(TAG_True))) {
      heff_drop(v_t_24161);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24161);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam3, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ELet: {
    V v_y_24168 = heff_field(v_e_240, 0);
    V v_c_24169 = heff_field(v_e_240, 1);
    V v_d_24170 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_24171 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAtom(v_d_24170, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam4, 1, 3, (V[]){v_m_24171, v_y_24168, v_c_24169});
  }
  case TAG_ERecord: {
    V v_t_24211;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24211 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24211 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24211 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24211 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24211 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24211 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24211 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24211 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24211 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24211) == NTAG(TAG_True))) {
      heff_drop(v_t_24211);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24211);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam5, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EProj: {
    V v_t_24255;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24255 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24255 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24255 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24255 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24255 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24255 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24255 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24255 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24255 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24255) == NTAG(TAG_True))) {
      heff_drop(v_t_24255);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24255);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam6, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ETag: {
    V v_t_24297;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24297 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24297 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24297 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24297 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24297 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24297 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24297 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24297 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24297 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24297 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24297 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24297 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24297 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24297 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24297 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24297 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24297 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24297 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24297 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24297 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24297) == NTAG(TAG_True))) {
      heff_drop(v_t_24297);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24297);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam7, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EMatch: {
    V v_t_24339;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24339 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24339 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24339 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24339 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24339 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24339 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24339 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24339 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24339 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24339) == NTAG(TAG_True))) {
      heff_drop(v_t_24339);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24339);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam8, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EPrim: {
    V v_t_24380;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24380 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24380 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24380 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24380 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24380 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24380 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24380 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24380 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24380 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24380 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24380) == NTAG(TAG_True))) {
      heff_drop(v_t_24380);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24380);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam9, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EPrimCall: {
    V v_t_24422;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24422 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24422 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24422 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24422 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24422 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24422 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24422 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24422 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24422 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24422 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24422 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24422 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24422 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24422 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24422 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24422 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24422 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24422 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24422 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24422 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24422) == NTAG(TAG_True))) {
      heff_drop(v_t_24422);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24422);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam10, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ECall: {
    V v_t_24464;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24464 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24464 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24464 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24464 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24464 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24464 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24464 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24464 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24464 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24464 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24464 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24464 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24464 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24464 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24464 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24464 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24464 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24464 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24464 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24464 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24464) == NTAG(TAG_True))) {
      heff_drop(v_t_24464);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24464);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam11, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EInt: {
    V v_t_24505;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24505 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24505 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24505 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24505 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24505 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24505 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24505 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24505 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24505 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24505 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24505 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24505 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24505 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24505 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24505 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24505 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24505 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24505 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24505 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24505 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24505) == NTAG(TAG_True))) {
      heff_drop(v_t_24505);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24505);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam12, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFloat: {
    V v_t_24546;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24546 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24546 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24546 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24546 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24546 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24546 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24546 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24546 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24546 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24546 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24546 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24546 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24546 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24546 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24546 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24546 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24546 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24546 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24546 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24546 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24546) == NTAG(TAG_True))) {
      heff_drop(v_t_24546);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24546);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam13, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EStr: {
    V v_t_24587;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24587 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24587 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24587 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24587 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24587 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24587 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24587 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24587 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24587 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24587 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24587 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24587 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24587 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24587 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24587 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24587 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24587 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24587 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24587 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24587 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24587) == NTAG(TAG_True))) {
      heff_drop(v_t_24587);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24587);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam14, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EBytes: {
    V v_t_24628;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24628 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24628 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24628 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24628 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24628 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24628 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24628 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24628 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24628 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24628 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24628 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24628 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24628 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24628 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24628 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24628 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24628 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24628 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24628 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24628 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24628) == NTAG(TAG_True))) {
      heff_drop(v_t_24628);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24628);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam15, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFixed: {
    V v_t_24670;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24670 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24670 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24670 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24670 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24670 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24670 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24670 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24670 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24670 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24670 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24670 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24670 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24670 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24670 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24670 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24670 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24670 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24670 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24670 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24670 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24670) == NTAG(TAG_True))) {
      heff_drop(v_t_24670);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24670);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam16, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFloat32: {
    V v_t_24711;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24711 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24711 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24711 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24711 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24711 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24711 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24711 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24711 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24711 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24711 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24711 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24711 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24711 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24711 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24711 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24711 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24711 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24711 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24711 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24711 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24711) == NTAG(TAG_True))) {
      heff_drop(v_t_24711);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24711);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam17, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EAbandon: {
    V v_t_24751;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24751 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24751 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24751 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24751 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24751 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24751 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24751 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24751 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24751 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24751 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24751 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24751 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24751 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24751 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24751 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24751 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24751 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24751 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24751 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24751 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24751) == NTAG(TAG_True))) {
      heff_drop(v_t_24751);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24751);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam18, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFix: {
    V v_t_24793;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24793 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24793 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24793 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24793 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24793 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24793 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24793 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24793 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24793 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24793 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24793 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24793 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24793 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24793 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24793 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_24793 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24793 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24793 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24793 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24793 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_24793) == NTAG(TAG_True))) {
      heff_drop(v_t_24793);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24793);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam19, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAtom(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam0(V self, V *args) {
  V v_n_2437 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2438 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str0), heff_intShow(heff_dup(v_n_2437)));
  V v_m_2439 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2438)})}));
  V v_x2_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){heff_intAdd(v_n_2437, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_x_2441 = heff_field(v_x2_2440, 0);
    V v_n_2442 = heff_field(v_x2_2440, 1);
    V v_ru_24x2_2440_24MkPair = heff_take_reuse_n(v_x2_2440, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2438, v_e_240, v_x_2441}), v_n_2442});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam1(V self, V *args) {
  V v_n_2478 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2479 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str1), heff_intShow(heff_dup(v_n_2478)));
  V v_m_2480 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2479)})}));
  V v_x2_2481 = heff_tr(heff_call(v_m_2480, 1, (V[]){heff_intAdd(v_n_2478, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2481)) {
  case TAG_MkPair: {
    V v_x_2482 = heff_field(v_x2_2481, 0);
    V v_n_2483 = heff_field(v_x2_2481, 1);
    V v_ru_24x2_2481_24MkPair = heff_take_reuse_n(v_x2_2481, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2479, v_e_240, v_x_2482}), v_n_2483});
  }
  default: return heff_nomatch(v_x2_2481);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam2(V self, V *args) {
  V v_n_24120 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24121 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str2), heff_intShow(heff_dup(v_n_24120)));
  V v_m_24122 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24121)})}));
  V v_x2_24123 = heff_tr(heff_call(v_m_24122, 1, (V[]){heff_intAdd(v_n_24120, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24123)) {
  case TAG_MkPair: {
    V v_x_24124 = heff_field(v_x2_24123, 0);
    V v_n_24125 = heff_field(v_x2_24123, 1);
    V v_ru_24x2_24123_24MkPair = heff_take_reuse_n(v_x2_24123, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24123_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24121, v_e_240, v_x_24124}), v_n_24125});
  }
  default: return heff_nomatch(v_x2_24123);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam3(V self, V *args) {
  V v_n_24162 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24163 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str3), heff_intShow(heff_dup(v_n_24162)));
  V v_m_24164 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24163)})}));
  V v_x2_24165 = heff_tr(heff_call(v_m_24164, 1, (V[]){heff_intAdd(v_n_24162, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24165)) {
  case TAG_MkPair: {
    V v_x_24166 = heff_field(v_x2_24165, 0);
    V v_n_24167 = heff_field(v_x2_24165, 1);
    V v_ru_24x2_24165_24MkPair = heff_take_reuse_n(v_x2_24165, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24165_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24163, v_e_240, v_x_24166}), v_n_24167});
  }
  default: return heff_nomatch(v_x2_24165);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam4(V self, V *args) {
  V v_n_24172 = args[0];
  V v_m_24171 = heff_env(self)[0];
  V v_y_24168 = heff_env(self)[1];
  V v_c_24169 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24173 = heff_tr(heff_call(v_m_24171, 1, (V[]){v_n_24172}));
  switch (heff_tag_of(v_x2_24173)) {
  case TAG_MkPair: {
    V v_x_24174 = heff_field(v_x2_24173, 0);
    V v_n_24175 = heff_field(v_x2_24173, 1);
    V v_ru_24x2_24173_24MkPair = heff_take_reuse_n(v_x2_24173, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24173_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_24168, v_c_24169, v_x_24174}), v_n_24175});
  }
  default: return heff_nomatch(v_x2_24173);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam5(V self, V *args) {
  V v_n_24212 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24213 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str4), heff_intShow(heff_dup(v_n_24212)));
  V v_m_24214 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24213)})}));
  V v_x2_24215 = heff_tr(heff_call(v_m_24214, 1, (V[]){heff_intAdd(v_n_24212, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24215)) {
  case TAG_MkPair: {
    V v_x_24216 = heff_field(v_x2_24215, 0);
    V v_n_24217 = heff_field(v_x2_24215, 1);
    V v_ru_24x2_24215_24MkPair = heff_take_reuse_n(v_x2_24215, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24215_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24213, v_e_240, v_x_24216}), v_n_24217});
  }
  default: return heff_nomatch(v_x2_24215);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam6(V self, V *args) {
  V v_n_24256 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24257 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str5), heff_intShow(heff_dup(v_n_24256)));
  V v_m_24258 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24257)})}));
  V v_x2_24259 = heff_tr(heff_call(v_m_24258, 1, (V[]){heff_intAdd(v_n_24256, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24259)) {
  case TAG_MkPair: {
    V v_x_24260 = heff_field(v_x2_24259, 0);
    V v_n_24261 = heff_field(v_x2_24259, 1);
    V v_ru_24x2_24259_24MkPair = heff_take_reuse_n(v_x2_24259, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24259_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24257, v_e_240, v_x_24260}), v_n_24261});
  }
  default: return heff_nomatch(v_x2_24259);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam7(V self, V *args) {
  V v_n_24298 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24299 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str6), heff_intShow(heff_dup(v_n_24298)));
  V v_m_24300 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24299)})}));
  V v_x2_24301 = heff_tr(heff_call(v_m_24300, 1, (V[]){heff_intAdd(v_n_24298, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24301)) {
  case TAG_MkPair: {
    V v_x_24302 = heff_field(v_x2_24301, 0);
    V v_n_24303 = heff_field(v_x2_24301, 1);
    V v_ru_24x2_24301_24MkPair = heff_take_reuse_n(v_x2_24301, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24301_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24299, v_e_240, v_x_24302}), v_n_24303});
  }
  default: return heff_nomatch(v_x2_24301);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam8(V self, V *args) {
  V v_n_24340 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24341 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str7), heff_intShow(heff_dup(v_n_24340)));
  V v_m_24342 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24341)})}));
  V v_x2_24343 = heff_tr(heff_call(v_m_24342, 1, (V[]){heff_intAdd(v_n_24340, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24343)) {
  case TAG_MkPair: {
    V v_x_24344 = heff_field(v_x2_24343, 0);
    V v_n_24345 = heff_field(v_x2_24343, 1);
    V v_ru_24x2_24343_24MkPair = heff_take_reuse_n(v_x2_24343, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24341, v_e_240, v_x_24344}), v_n_24345});
  }
  default: return heff_nomatch(v_x2_24343);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam9(V self, V *args) {
  V v_n_24381 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24382 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str8), heff_intShow(heff_dup(v_n_24381)));
  V v_m_24383 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24382)})}));
  V v_x2_24384 = heff_tr(heff_call(v_m_24383, 1, (V[]){heff_intAdd(v_n_24381, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24384)) {
  case TAG_MkPair: {
    V v_x_24385 = heff_field(v_x2_24384, 0);
    V v_n_24386 = heff_field(v_x2_24384, 1);
    V v_ru_24x2_24384_24MkPair = heff_take_reuse_n(v_x2_24384, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24384_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24382, v_e_240, v_x_24385}), v_n_24386});
  }
  default: return heff_nomatch(v_x2_24384);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam10(V self, V *args) {
  V v_n_24423 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24424 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str9), heff_intShow(heff_dup(v_n_24423)));
  V v_m_24425 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24424)})}));
  V v_x2_24426 = heff_tr(heff_call(v_m_24425, 1, (V[]){heff_intAdd(v_n_24423, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24426)) {
  case TAG_MkPair: {
    V v_x_24427 = heff_field(v_x2_24426, 0);
    V v_n_24428 = heff_field(v_x2_24426, 1);
    V v_ru_24x2_24426_24MkPair = heff_take_reuse_n(v_x2_24426, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24424, v_e_240, v_x_24427}), v_n_24428});
  }
  default: return heff_nomatch(v_x2_24426);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam11(V self, V *args) {
  V v_n_24465 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24466 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str10), heff_intShow(heff_dup(v_n_24465)));
  V v_m_24467 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24466)})}));
  V v_x2_24468 = heff_tr(heff_call(v_m_24467, 1, (V[]){heff_intAdd(v_n_24465, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24468)) {
  case TAG_MkPair: {
    V v_x_24469 = heff_field(v_x2_24468, 0);
    V v_n_24470 = heff_field(v_x2_24468, 1);
    V v_ru_24x2_24468_24MkPair = heff_take_reuse_n(v_x2_24468, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24466, v_e_240, v_x_24469}), v_n_24470});
  }
  default: return heff_nomatch(v_x2_24468);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam12(V self, V *args) {
  V v_n_24506 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24507 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str11), heff_intShow(heff_dup(v_n_24506)));
  V v_m_24508 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24507)})}));
  V v_x2_24509 = heff_tr(heff_call(v_m_24508, 1, (V[]){heff_intAdd(v_n_24506, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24509)) {
  case TAG_MkPair: {
    V v_x_24510 = heff_field(v_x2_24509, 0);
    V v_n_24511 = heff_field(v_x2_24509, 1);
    V v_ru_24x2_24509_24MkPair = heff_take_reuse_n(v_x2_24509, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24509_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24507, v_e_240, v_x_24510}), v_n_24511});
  }
  default: return heff_nomatch(v_x2_24509);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam13(V self, V *args) {
  V v_n_24547 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24548 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str12), heff_intShow(heff_dup(v_n_24547)));
  V v_m_24549 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24548)})}));
  V v_x2_24550 = heff_tr(heff_call(v_m_24549, 1, (V[]){heff_intAdd(v_n_24547, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24550)) {
  case TAG_MkPair: {
    V v_x_24551 = heff_field(v_x2_24550, 0);
    V v_n_24552 = heff_field(v_x2_24550, 1);
    V v_ru_24x2_24550_24MkPair = heff_take_reuse_n(v_x2_24550, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24550_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24548, v_e_240, v_x_24551}), v_n_24552});
  }
  default: return heff_nomatch(v_x2_24550);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam14(V self, V *args) {
  V v_n_24588 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24589 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str13), heff_intShow(heff_dup(v_n_24588)));
  V v_m_24590 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24589)})}));
  V v_x2_24591 = heff_tr(heff_call(v_m_24590, 1, (V[]){heff_intAdd(v_n_24588, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24591)) {
  case TAG_MkPair: {
    V v_x_24592 = heff_field(v_x2_24591, 0);
    V v_n_24593 = heff_field(v_x2_24591, 1);
    V v_ru_24x2_24591_24MkPair = heff_take_reuse_n(v_x2_24591, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24591_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24589, v_e_240, v_x_24592}), v_n_24593});
  }
  default: return heff_nomatch(v_x2_24591);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam15(V self, V *args) {
  V v_n_24629 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24630 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str14), heff_intShow(heff_dup(v_n_24629)));
  V v_m_24631 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24630)})}));
  V v_x2_24632 = heff_tr(heff_call(v_m_24631, 1, (V[]){heff_intAdd(v_n_24629, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24632)) {
  case TAG_MkPair: {
    V v_x_24633 = heff_field(v_x2_24632, 0);
    V v_n_24634 = heff_field(v_x2_24632, 1);
    V v_ru_24x2_24632_24MkPair = heff_take_reuse_n(v_x2_24632, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24632_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24630, v_e_240, v_x_24633}), v_n_24634});
  }
  default: return heff_nomatch(v_x2_24632);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam16(V self, V *args) {
  V v_n_24671 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24672 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str15), heff_intShow(heff_dup(v_n_24671)));
  V v_m_24673 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24672)})}));
  V v_x2_24674 = heff_tr(heff_call(v_m_24673, 1, (V[]){heff_intAdd(v_n_24671, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24674)) {
  case TAG_MkPair: {
    V v_x_24675 = heff_field(v_x2_24674, 0);
    V v_n_24676 = heff_field(v_x2_24674, 1);
    V v_ru_24x2_24674_24MkPair = heff_take_reuse_n(v_x2_24674, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24674_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24672, v_e_240, v_x_24675}), v_n_24676});
  }
  default: return heff_nomatch(v_x2_24674);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam17(V self, V *args) {
  V v_n_24712 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24713 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str16), heff_intShow(heff_dup(v_n_24712)));
  V v_m_24714 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24713)})}));
  V v_x2_24715 = heff_tr(heff_call(v_m_24714, 1, (V[]){heff_intAdd(v_n_24712, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24715)) {
  case TAG_MkPair: {
    V v_x_24716 = heff_field(v_x2_24715, 0);
    V v_n_24717 = heff_field(v_x2_24715, 1);
    V v_ru_24x2_24715_24MkPair = heff_take_reuse_n(v_x2_24715, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24715_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24713, v_e_240, v_x_24716}), v_n_24717});
  }
  default: return heff_nomatch(v_x2_24715);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam18(V self, V *args) {
  V v_n_24752 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24753 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str17), heff_intShow(heff_dup(v_n_24752)));
  V v_m_24754 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24753)})}));
  V v_x2_24755 = heff_tr(heff_call(v_m_24754, 1, (V[]){heff_intAdd(v_n_24752, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24755)) {
  case TAG_MkPair: {
    V v_x_24756 = heff_field(v_x2_24755, 0);
    V v_n_24757 = heff_field(v_x2_24755, 1);
    V v_ru_24x2_24755_24MkPair = heff_take_reuse_n(v_x2_24755, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24755_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24753, v_e_240, v_x_24756}), v_n_24757});
  }
  default: return heff_nomatch(v_x2_24755);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam19(V self, V *args) {
  V v_n_24794 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24795 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str18), heff_intShow(heff_dup(v_n_24794)));
  V v_m_24796 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24795)})}));
  V v_x2_24797 = heff_tr(heff_call(v_m_24796, 1, (V[]){heff_intAdd(v_n_24794, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24797)) {
  case TAG_MkPair: {
    V v_x_24798 = heff_field(v_x2_24797, 0);
    V v_n_24799 = heff_field(v_x2_24797, 1);
    V v_ru_24x2_24797_24MkPair = heff_take_reuse_n(v_x2_24797, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24797_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24795, v_e_240, v_x_24798}), v_n_24799});
  }
  default: return heff_nomatch(v_x2_24797);
  }
}
Clo g_heff_2ecompile_2emonadic_2eflatLet_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry, 4, 0};

V g_heff_2ecompile_2emonadic_2eflatLet_24dps(V v_x_240, V v_a_241, V v_b_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EGlobal: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ELam: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EApp: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ELet: {
    V v_y_2410 = heff_field(v_a_241, 0);
    V v_c_2411 = heff_field(v_a_241, 1);
    V v_d_2412 = heff_field(v_a_241, 2);
    V v_ru_24a_241_24ELet = heff_take_reuse_n(v_a_241, 7ULL, 3);
    V v_cell_2413 = heff_tag_at_n(v_ru_24a_241_24ELet, TAG_ELet, 3, (V[]){v_y_2410, v_c_2411, heff_hole()});
    V v_u_2414 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_x_240;
    V t_1 = v_d_2412;
    V t_2 = v_b_242;
    V t_3 = v_cell_2413;
    v_x_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EProj: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ETag: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EMatch: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EPrim: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EPrimCall: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ECall: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EInt: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFloat: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EStr: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EBytes: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFixed: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFloat32: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EAbandon: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFix: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2eflatLet_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam0(V self, V *args); static Clo g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam0, 1, 0};
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam2(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      V v_a_247 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_a_246));
      v_m_2412 = heff_clo_n(g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam1, 1, 3, (V[]){v_a_247, v_a_244, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam2, 1, 2, (V[]){v_m_2412, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287(a[0]);
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam1(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_a_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = heff_tr(heff_call(v_a_247, 1, (V[]){v_a_248}));
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkPair: {
    V v_a_2410 = heff_field(v_a_249, 0);
    V v_a_2411 = heff_field(v_a_249, 1);
    V v_ru_24a_249_24MkPair = heff_take_reuse_n(v_a_249, 3ULL, 2);
    return heff_tag_at_n(v_ru_24a_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_244, v_a_245, v_a_2410}), v_a_2411});
  }
  default: return heff_nomatch(v_a_249);
  }
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_m_2417 = (g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287(v_xs_243));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2416}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_n_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_x_2419}), v_n_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam5(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam4(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam3(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam6(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam8(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam7(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam10(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam9(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam11(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam14(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam13(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam12(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam15(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam16(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam17(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam18(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam19(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam20(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam21(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam22(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam23(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam24(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam25(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2enorm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2enorm_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2enorm(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam0, 1, 1, (V[]){v_e_240});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam1, 1, 1, (V[]){v_e_240});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_e_240, 0);
    V v_b_246 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_m_247 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_b_246));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam2, 1, 2, (V[]){v_m_247, v_xs_245});
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_e_240, 0);
    V v_as_2413 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_m_2414 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_f_2412));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam3, 1, 2, (V[]){v_m_2414, v_as_2413});
  }
  case TAG_ELet: {
    V v_x_2423 = heff_field(v_e_240, 0);
    V v_a_2424 = heff_field(v_e_240, 1);
    V v_b_2425 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2426 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_a_2424));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam6, 1, 3, (V[]){v_m_2426, v_b_2425, v_x_2423});
  }
  case TAG_ERecord: {
    V v_fs_2436 = heff_field(v_e_240, 0);
    V v_ts_2437 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_t_2438 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2436)));
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_t_2438, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam7, 1, 2, (V[]){v_fs_2436, v_ts_2437})));
  }
  case TAG_EProj: {
    V v_e1_2443 = heff_field(v_e_240, 0);
    V v_l_2444 = heff_field(v_e_240, 1);
    V v_sh_2445 = heff_field(v_e_240, 2);
    V v_t_2446 = heff_field(v_e_240, 3);
    heff_take_n(v_e_240, 15ULL, 4);
    V v_m_2447 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_e1_2443));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam9, 1, 4, (V[]){v_m_2447, v_l_2444, v_sh_2445, v_t_2446});
  }
  case TAG_ETag: {
    V v_t_2455 = heff_field(v_e_240, 0);
    V v_as_2456 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_as_2456, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam11, 2, 1, (V[]){v_t_2455})));
  }
  case TAG_EMatch: {
    V v_s_2459 = heff_field(v_e_240, 0);
    V v_arms_2460 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_m_2461 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_s_2459));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam12, 1, 2, (V[]){v_m_2461, v_arms_2460});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam15, 1, 1, (V[]){v_e_240});
  }
  case TAG_EPrimCall: {
    V v_p_2475 = heff_field(v_e_240, 0);
    V v_as_2476 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_as_2476, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam16, 2, 1, (V[]){v_p_2475})));
  }
  case TAG_ECall: {
    V v_g_2479 = heff_field(v_e_240, 0);
    V v_as_2480 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_as_2480, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam17, 2, 1, (V[]){v_g_2479})));
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam18, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam19, 1, 1, (V[]){v_e_240});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam20, 1, 1, (V[]){v_e_240});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam21, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam22, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam23, 1, 1, (V[]){v_e_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam24, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFix: {
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam25, 1, 1, (V[]){v_e_240});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2enorm(a[0]);
}
V g_heff_2ecompile_2emonadic_2enorm_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_n_242});
}
V g_heff_2ecompile_2emonadic_2enorm_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_n_244});
}
V g_heff_2ecompile_2emonadic_2enorm_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_245, v_x_2410}), v_n_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam5(V self, V *args) {
  V v_as_27_2420 = args[0];
  V v_n_2421 = args[1];
  V v_f_27_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_27_2419, v_as_27_2420}), v_n_2421});
}
V g_heff_2ecompile_2emonadic_2enorm_lam4(V self, V *args) {
  V v_f_27_2419 = args[0];
  V v_as_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_as_2413, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam5, 2, 1, (V[]){v_f_27_2419})));
}
V g_heff_2ecompile_2emonadic_2enorm_lam3(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_as_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    heff_take_n(v_x2_2416, 3ULL, 2);
    V v_t_2422 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_x_2417, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam4, 1, 1, (V[]){v_as_2413})));
    V f_ = v_t_2422;
    args[0] = v_n_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam6(V self, V *args) {
  V v_n_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  V v_b_2425 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_n_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_n_2430 = heff_field(v_x2_2428, 1);
    V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
    V v_m_2431 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_b_2425));
    V v_x2_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2430}));
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_MkPair: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_n_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      V v_x_2435 = (g_heff_2ecompile_2emonadic_2eflatLet(v_x_2423, v_x_2429, v_x_2433));
      return heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){v_x_2435, v_n_2434});
    }
    default: return heff_nomatch(v_x2_2432);
    }
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam8(V self, V *args) {
  V v_n_2442 = args[0];
  V v_x_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2441, v_n_2442});
}
V g_heff_2ecompile_2emonadic_2enorm_lam7(V self, V *args) {
  V v_vs_2439 = args[0];
  V v_fs_2436 = heff_env(self)[0];
  V v_ts_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2436, v_vs_2439));
  V v_x_2441 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2440, v_ts_2437});
  return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam8, 1, 1, (V[]){v_x_2441});
}
V g_heff_2ecompile_2emonadic_2enorm_lam10(V self, V *args) {
  V v_e_27_2452 = args[0];
  V v_n_2453 = args[1];
  V v_l_2444 = heff_env(self)[0];
  V v_sh_2445 = heff_env(self)[1];
  V v_t_2446 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_27_2452, v_l_2444, v_sh_2445, v_t_2446}), v_n_2453});
}
V g_heff_2ecompile_2emonadic_2enorm_lam9(V self, V *args) {
  V v_n_2448 = args[0];
  V v_m_2447 = heff_env(self)[0];
  V v_l_2444 = heff_env(self)[1];
  V v_sh_2445 = heff_env(self)[2];
  V v_t_2446 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2449 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_n_2448}));
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_n_2451 = heff_field(v_x2_2449, 1);
    heff_take_n(v_x2_2449, 3ULL, 2);
    V v_t_2454 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_x_2450, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam10, 2, 3, (V[]){v_l_2444, v_sh_2445, v_t_2446})));
    V f_ = v_t_2454;
    args[0] = v_n_2451;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam11(V self, V *args) {
  V v_as_27_2457 = args[0];
  V v_n_2458 = args[1];
  V v_t_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_t_2455, v_as_27_2457}), v_n_2458});
}
V g_heff_2ecompile_2emonadic_2enorm_lam14(V self, V *args) {
  V v_n_2468 = args[0];
  V v_m_2467 = heff_env(self)[0];
  V v_s_27_2466 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2469 = heff_tr(heff_call(v_m_2467, 1, (V[]){v_n_2468}));
  switch (heff_tag_of(v_x2_2469)) {
  case TAG_MkPair: {
    V v_x_2470 = heff_field(v_x2_2469, 0);
    V v_n_2471 = heff_field(v_x2_2469, 1);
    V v_ru_24x2_2469_24MkPair = heff_take_reuse_n(v_x2_2469, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2469_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_27_2466, v_x_2470}), v_n_2471});
  }
  default: return heff_nomatch(v_x2_2469);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam13(V self, V *args) {
  V v_s_27_2466 = args[0];
  V v_arms_2460 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2467 = (g_heff_2ecompile_2emonadic_2etraverseN_24s1679798616x526561287(v_arms_2460));
  return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam14, 1, 2, (V[]){v_m_2467, v_s_27_2466});
}
V g_heff_2ecompile_2emonadic_2enorm_lam12(V self, V *args) {
  V v_n_2462 = args[0];
  V v_m_2461 = heff_env(self)[0];
  V v_arms_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2463 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_n_2462}));
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_MkPair: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    V v_n_2465 = heff_field(v_x2_2463, 1);
    heff_take_n(v_x2_2463, 3ULL, 2);
    V v_t_2472 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAtom(v_x_2464, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam13, 1, 1, (V[]){v_arms_2460})));
    V f_ = v_t_2472;
    args[0] = v_n_2465;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam15(V self, V *args) {
  V v_n_2474 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_n_2474});
}
V g_heff_2ecompile_2emonadic_2enorm_lam16(V self, V *args) {
  V v_as_27_2477 = args[0];
  V v_n_2478 = args[1];
  V v_p_2475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2475, v_as_27_2477}), v_n_2478});
}
V g_heff_2ecompile_2emonadic_2enorm_lam17(V self, V *args) {
  V v_as_27_2481 = args[0];
  V v_n_2482 = args[1];
  V v_g_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2479, v_as_27_2481}), v_n_2482});
}
V g_heff_2ecompile_2emonadic_2enorm_lam18(V self, V *args) {
  V v_n_2484 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_n_2484});
}
V g_heff_2ecompile_2emonadic_2enorm_lam19(V self, V *args) {
  V v_n_2486 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_n_2486});
}
V g_heff_2ecompile_2emonadic_2enorm_lam20(V self, V *args) {
  V v_n_2488 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_n_2488});
}
V g_heff_2ecompile_2emonadic_2enorm_lam21(V self, V *args) {
  V v_n_2490 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_n_2490});
}
V g_heff_2ecompile_2emonadic_2enorm_lam22(V self, V *args) {
  V v_n_2493 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_n_2493});
}
V g_heff_2ecompile_2emonadic_2enorm_lam23(V self, V *args) {
  V v_n_2495 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_n_2495});
}
V g_heff_2ecompile_2emonadic_2enorm_lam24(V self, V *args) {
  V v_n_2496 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_n_2496});
}
V g_heff_2ecompile_2emonadic_2enorm_lam25(V self, V *args) {
  V v_n_2499 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_n_2499});
}