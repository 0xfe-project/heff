// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CRel 55099
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_I64 19315
#define TAG_MkArm 55352
#define TAG_OfFixed 17267
#define TAG_OpEq 47278
#define TAG_OutCall 43778
#define TAG_OutOther 27005
#define TAG_OutRecord 63915
#define TAG_OutTag 45229
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Tip 31527
#define LBL_body 9524841
#define LBL_cons 9554936
#define LBL_group 299987609
#define LBL_index 301704428
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_labels 836724522
#define LBL_lets 9813631
#define LBL_name 9869138
#define LBL_numbered 1006183371
#define LBL_places 961367927
#define LBL_record 1012233084
#define LBL_tag 324116
#define LBL_tuple 312083426
#define LBL_tys 324872
#define LBL_vals 10107449
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_lets__vals[] = {LBL_lets, LBL_vals};
static uint32_t shape_tag__index__tys__places[] = {LBL_tag, LBL_index, LBL_tys, LBL_places};
V g_heff_2ecompile_2ecpr_2eapart(V, V, V, V);
V g_heff_2ecompile_2ecpr_2eapart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eapart_clo;
V g_heff_2ecompile_2ecpr_2eapartW(V, V, V, V);
V g_heff_2ecompile_2ecpr_2eapartW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eapartW_clo;
V g_heff_2ecompile_2ecpr_2earmBodyAs(V, V, V, V);
V g_heff_2ecompile_2ecpr_2earmBodyAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2earmBodyAs_clo;
V g_heff_2ecompile_2ecpr_2eboundAll(V, V);
V g_heff_2ecompile_2ecpr_2eboundAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eboundAll_clo;
V g_heff_2ecompile_2ecpr_2ebuiltOf(V, V, V);
V g_heff_2ecompile_2ecpr_2ebuiltOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebuiltOf_clo;
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2(V, V, V, V);
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_clo;
V g_heff_2ecompile_2ecpr_2ebuiltOut(V, V, V);
V g_heff_2ecompile_2ecpr_2ebuiltOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebuiltOut_clo;
V g_heff_2ecompile_2ecpr_2ecalledApart(V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2ecalledApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ecalledApart_clo;
V g_heff_2ecompile_2ecpr_2ecalledApart_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2ecalledApart_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ecalledApart_24tok2_clo;
V g_heff_2ecompile_2ecpr_2ecalledApart_24tok3(V, V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2ecalledApart_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ecalledApart_24tok3_clo;
V g_heff_2ecompile_2ecpr_2echosen(V, V, V);
V g_heff_2ecompile_2ecpr_2echosen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2echosen_clo;
V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(V, V, V, V);
V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_clo;
V g_heff_2ecompile_2ecpr_2edefWith(V, V, V);
V g_heff_2ecompile_2ecpr_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2edefWith_clo;
V g_heff_2ecompile_2ecpr_2edropCalling(V);
V g_heff_2ecompile_2ecpr_2edropCalling_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2edropCalling_clo;
HeffT2 g_heff_2ecompile_2ecpr_2efieldAt_24cpr(V, V, V);
V g_heff_2ecompile_2ecpr_2efitting(V);
V g_heff_2ecompile_2ecpr_2efitting_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2efitting_clo;
HeffT2 g_heff_2ecompile_2ecpr_2efreeAt_24cpr(V, V, V, V);
V g_heff_2ecompile_2ecpr_2ekeptGo(V, V);
V g_heff_2ecompile_2ecpr_2ekeptGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ekeptGo_clo;
V g_heff_2ecompile_2ecpr_2elabelAt(V, V, V);
V g_heff_2ecompile_2ecpr_2elabelAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2elabelAt_clo;
V g_heff_2ecompile_2ecpr_2eoutOnto(V, V);
V g_heff_2ecompile_2ecpr_2eoutOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eoutOnto_clo;
V g_heff_2ecompile_2ecpr_2eoutRw(V, V);
V g_heff_2ecompile_2ecpr_2eoutRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eoutRw_clo;
V g_heff_2ecompile_2ecpr_2erw(V, V);
V g_heff_2ecompile_2ecpr_2erw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2erw_clo;
V g_heff_2ecompile_2ecpr_2erwNode(V, V, V);
V g_heff_2ecompile_2ecpr_2erwNode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2erwNode_clo;
V g_heff_2ecompile_2ecpr_2esameLabels(V, V);
V g_heff_2ecompile_2ecpr_2esameLabels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esameLabels_clo;
V g_heff_2ecompile_2ecpr_2esitesW(V, V, V);
V g_heff_2ecompile_2ecpr_2esitesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esitesW_clo;
V g_heff_2ecompile_2ecpr_2ewrapperOf(V, V, V);
V g_heff_2ecompile_2ecpr_2ewrapperOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ewrapperOf_clo;
V g_heff_2ecompile_2eir_2earmFor(V, V);
V g_heff_2ecompile_2eir_2earmFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2earmFor_clo;
HeffT2 g_heff_2ecompile_2eir_2earmFor_24cpr(V, V);
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok1(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok1_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok3(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok3_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835(V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s558881959x1385112442_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f155552269x628597815(V, V, V);
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a);
extern Clo g_list_2efoldl_24f155552269x628597815_clo;
V g_list_2efoldl_24f2092936166x2062766724(V, V, V);
V g_list_2efoldl_24f2092936166x2062766724_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2092936166x2062766724_clo;
V g_list_2efoldl_24s1016340684x604821087(V, V);
V g_list_2efoldl_24s1016340684x604821087_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1016340684x604821087_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1980014771x775787011(V, V);
V g_list_2efoldl_24s1980014771x775787011_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1980014771x775787011_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s1902028738x441242582(V);
V g_list_2emap_24s1902028738x441242582_entry(V self, V *a);
extern Clo g_list_2emap_24s1902028738x441242582_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1023157662x1060337521_24cpr(V, V, V, V, V, V, V, V);
V g_prelude_2etraverse_24s75890152x1871550235(V, V, V, V);
V g_prelude_2etraverse_24s75890152x1871550235_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s75890152x1871550235_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;
Clo g_heff_2ecompile_2ecpr_2esameLabels_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esameLabels_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2esameLabels(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_args_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_a_244, v_b_246, 0)) {
        V t_0 = v_args_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecpr_2esameLabels_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2esameLabels(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2eoutOnto_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutOnto_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eoutOnto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eoutOnto_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eoutOnto(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_ELam: {
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_EApp: {
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_ERecord: {
    V v_fs_2411 = heff_field(v_x2_241, 0);
    V v_ts_2412 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2413 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2411)));
    V v_t_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fs_2411; V r_ = (g_list_2efoldl_24f2092936166x2062766724(a_0, a_1, a_2)); heff_drop(v_fs_2411); r_; });
    V v_t_2415 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2414, MK_INT(1LL))));
    V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2eoutOnto_lam0, 1, 1, (V[]){v_ts_2412}), v_t_2415));
    return heff_tag_at_n(v_ru_24x2_241_24ERecord, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OutRecord, 2, (V[]){v_t_2413, v_t_2417}), v_acc_240});
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_ETag: {
    V v_t_2422 = heff_field(v_x2_241, 0);
    V v_args_2423 = heff_field(v_x2_241, 1);
    V v_ts_2424 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2425 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2423; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2423); r_; });
    V v_t_2426 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2425, MK_INT(1LL))));
    V v_t_2428 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2eoutOnto_lam1, 1, 1, (V[]){v_ts_2424}), v_t_2426));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OutTag, 2, (V[]){v_t_2422, v_t_2428}), v_acc_240});
  }
  case TAG_EMatch: {
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x2_241_24EMatch, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_EPrimCall: {
    V v_ru_24x2_241_24EPrimCall = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x2_241_24EPrimCall, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_ECall: {
    V v_g_2434 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OutCall, 1, (V[]){v_g_2434}), v_acc_240});
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_EFloat: {
    heff_take_nf(v_x2_241, 0ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_EFixed: {
    V v_ru_24x2_241_24EFixed = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x2_241_24EFixed, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_EAbandon: {
    return v_acc_240;
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  case TAG_EFix: {
    V v_ru_24x2_241_24EFix = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x2_241_24EFix, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecpr_2eoutOnto_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eoutOnto(a[0], a[1]);
}
V g_heff_2ecompile_2ecpr_2eoutOnto_lam0(V self, V *args) {
  V v_i_2416 = args[0];
  V v_ts_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2416; V a_1 = v_ts_2412; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2412); r_; });
}
V g_heff_2ecompile_2ecpr_2eoutOnto_lam1(V self, V *args) {
  V v_i_2427 = args[0];
  V v_ts_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2427; V a_1 = v_ts_2424; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2424); r_; });
}
V g_heff_2ecompile_2ecpr_2edropCalling_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2edropCalling_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2edropCalling_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2edropCalling_entry, 1, 0};

V g_heff_2ecompile_2ecpr_2edropCalling(V v_m_240) {
top: ;
  V v_t_241 = (g_std_2eordmap_2etoListOnto(v_m_240, NTAG(TAG_Nil)));
  V v_ps_2413 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2ecpr_2edropCalling_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_t_241));
  return ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2413; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2413); r_; });
}
V g_heff_2ecompile_2ecpr_2edropCalling_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2edropCalling(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2edropCalling_lam1(V self, V *args) {
  V v_g_248 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = ({ V a_0 = v_m_240; V a_1 = v_g_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_m_240); heff_drop(v_g_248); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) && ({ V v_x_2412 = heff_dup(v_field_2411); int c_ = 1; heff_drop(v_x_2412); c_; })));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edropCalling_lam0(V self, V *args) {
  V v_p_242 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245;
  switch (heff_tag_of(v_p_242)) {
  case TAG_MkPair: {
    V v_y_244 = heff_field(v_p_242, 1);
    heff_take_n(v_p_242, 2ULL, 2);
    v_t_245 = v_y_244;
    break;
  }
  default: heff_nomatch(v_p_242);
  }
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_245));
  V v_t_247 = (g_list_2efoldl_24s1980014771x775787011(NTAG(TAG_Nil), v_t_246));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edropCalling_lam1, 1, 1, (V[]){v_m_240}); V a_1 = v_t_247; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_247); r_; });
}
Clo g_heff_2ecompile_2ecpr_2ekeptGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ekeptGo_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2ekeptGo(V v_m_240, V v_m2_241) {
top: ;
  V v_t_242 = (g_std_2eordmap_2esize(v_m2_241));
  V v_t_243 = (g_std_2eordmap_2esize(v_m_240));
  if (heff_intEq_c(v_t_242, v_t_243)) {
    heff_drop(v_m2_241);
    return v_m_240;
  } else {
    heff_drop(v_m_240);
    V v_t_244 = (g_heff_2ecompile_2ecpr_2edropCalling(v_m2_241));
    V t_0 = v_m2_241;
    V t_1 = v_t_244;
    v_m_240 = t_0;
    v_m2_241 = t_1;
    goto top;
  }
}
V g_heff_2ecompile_2ecpr_2ekeptGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ekeptGo(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2ecpr_2efreeAt_24cpr(V v_k_240, V v_used_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_k2_244 = heff_field(v_x4_243, 0);
    V v_ks_245 = heff_field(v_x4_243, 1);
    V v_t_246 = (g_heff_2ecompile_2erepr_2ereprEq(v_k_240, v_k2_244));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_x1_247 = (g_list_2eany_24s688114072x773797180(heff_dup(v_i_242), v_used_241));
      if (!(heff_dup(v_x1_247) == NTAG(TAG_True))) {
        heff_drop(v_x1_247);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_242}});
      } else {
        heff_drop(v_x1_247);
        V t_0 = v_k_240;
        V t_1 = v_used_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        V t_3 = v_ks_245;
        v_k_240 = t_0;
        v_used_241 = t_1;
        v_i_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    } else {
      heff_drop(v_t_246);
      V t_0 = v_k_240;
      V t_1 = v_used_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_ks_245;
      v_k_240 = t_0;
      v_used_241 = t_1;
      v_i_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
Clo g_heff_2ecompile_2ecpr_2efitting_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2efitting_entry, 1, 0};

V g_heff_2ecompile_2ecpr_2efitting(V v_lay_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_lay_240, 5)));
  if (heff_intLe_c(v_t_241, MK_INT(4LL))) {
    V v_t_242 = heff_dup(heff_rfield(v_lay_240, 1));
    V v_t_244;
    if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
      heff_drop(v_t_242);
      V v_t_243 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
      v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_dup(heff_rfield(v_lay_240, 2))});
    } else {
      heff_drop(v_t_242);
      v_t_244 = heff_dup(heff_rfield(v_lay_240, 2));
    }
    V v_t_245 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_244; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
    if (heff_intLe_c(v_t_245, MK_INT(4LL))) {
      V v_t_246 = heff_dup(heff_rfield(v_lay_240, 2));
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        heff_drop_rec(v_lay_240, 7);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        heff_take_n(v_t_246, 0ULL, 2);
        return heff_tag_n(TAG_Just, 1, (V[]){v_lay_240});
      }
      default: return heff_nomatch(v_t_246);
      }
    } else {
      heff_drop_rec(v_lay_240, 7);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop_rec(v_lay_240, 7);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2ecpr_2efitting_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2efitting(a[0]);
}
V g_heff_2ecompile_2ecpr_2eapartW_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eapartW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eapartW_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2eapartW(V v_lay_240, V v_x_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_lay_240, 7);
    return v_n_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EProj: {
      V v_e_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 4);
      V v_t_2450;
      switch (heff_tag_of(v_e_246)) {
      case TAG_EVar: {
        V v_y_2410 = heff_dup(heff_field(v_e_246, 0));
        if (heff_strEq_c_lent(v_x_241, v_y_2410, 2)) {
          V v_t_2411 = heff_dup(heff_rfield(v_lay_240, 3));
          if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
            heff_drop(v_t_2411);
            v_t_2450 = heff_intAdd(v_n_242, MK_INT(1LL));
          } else {
            heff_drop(v_t_2411);
            v_t_2450 = v_n_242;
          }
        } else {
          v_t_2450 = v_n_242;
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_ELam: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EApp: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_ELet: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_ERecord: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EProj: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_ETag: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EMatch: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EPrim: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_ECall: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EInt: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EFloat: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EStr: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EBytes: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EFixed: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EFloat32: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EAbandon: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EBool: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_ESet: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EValues: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EFix: {
        v_t_2450 = v_n_242;
        break;
      }
      default: heff_nomatch(v_e_246);
      }
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_t_2450;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e_246, v_rest_245});
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2451 = heff_field(v_x41_244, 0);
      V v_arms_2452 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_2498;
      switch (heff_tag_of(v_s_2451)) {
      case TAG_EVar: {
        V v_y_2453 = heff_dup(heff_field(v_s_2451, 0));
        if (heff_strEq_c_lent(v_x_241, v_y_2453, 2)) {
          if (!(heff_dup(heff_rfield(v_lay_240, 3)) == NTAG(TAG_True))) {
            V v_t_2459 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2ecpr_2eapartW_lam0, 1, 1, (V[]){heff_dup(v_arms_2452)}), heff_rfield(v_lay_240, 5)));
            if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
              heff_drop(v_t_2459);
              v_t_2498 = heff_intAdd(v_n_242, MK_INT(1LL));
            } else {
              heff_drop(v_t_2459);
              v_t_2498 = v_n_242;
            }
          } else {
            v_t_2498 = v_n_242;
          }
        } else {
          v_t_2498 = v_n_242;
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_ELam: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EApp: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_ELet: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_ERecord: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EProj: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_ETag: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EMatch: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EPrim: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_ECall: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EInt: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EFloat: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EStr: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EBytes: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EFixed: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EFloat32: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EAbandon: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EBool: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_ESet: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EValues: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EFix: {
        v_t_2498 = v_n_242;
        break;
      }
      default: heff_nomatch(v_s_2451);
      }
      V v_t_2499 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2452, v_rest_245));
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_t_2498;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_s_2451, v_t_2499});
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_24100 = (g_heff_2ecompile_2eir_2epartsOnto(v_x41_244, v_rest_245));
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_t_24100;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2eapartW_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2eapartW(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2eapartW_lam0(V self, V *args) {
  V v_c_2454 = args[0];
  V v_arms_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2455 = ({ V b_0 = heff_get_n(v_c_2454, 0, 4); V a_1 = v_arms_2452; HeffT2 r_ = (g_heff_2ecompile_2eir_2earmFor_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_arms_2452); r_; });
  {
    V v_field_2457 = v_t_2455.f[1];
    int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2456 == ((int64_t)0ULL)) && ({ V v_x11_2458 = heff_dup(v_field_2457); int c_ = 1; heff_drop(v_x11_2458); c_; })));
    heff_drop(v_field_2457);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2esitesW_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2esitesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esitesW_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2esitesW(V v_k_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_k_240);
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_ELet: {
      V v_x_245 = heff_field(v_x31_243, 0);
      V v_a_246 = heff_field(v_x31_243, 1);
      V v_b_247 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_k_248 = heff_dup(v_k_240);
      V v_acc_249 = v_acc_241;
      V v_x_2410 = v_x_245;
      V v_a_2411 = heff_dup(v_a_246);
      V v_b_2412 = heff_dup(v_b_247);
      V v_t_2464;
      switch (heff_tag_of(v_a_2411)) {
      case TAG_EVar: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_a_2411, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_a_2411, 0ULL, 4);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_a_2411, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_ECall: {
        V v_g_2436 = heff_field(v_a_2411, 0);
        V v_ru_24a_2411_24ECall = heff_take_reuse_n(v_a_2411, 1ULL, 2);
        V v_acc_2438 = v_acc_249;
        V v_x_2439 = v_x_2410;
        V v_b_2440 = v_b_2412;
        HeffT2 v_t_2441 = ({ V a_0 = v_k_248; V a_1 = v_g_2436; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_k_248); heff_drop(v_g_2436); r_; });
        {
          V v_field_2443 = v_t_2441.f[1];
          int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
          if ((v_tag_2442 == ((int64_t)0ULL))) {
            V v_lay_2444 = v_field_2443;
            V v_t_2445 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_2440), NTAG(TAG_Nil)});
            V v_x_2446 = (g_heff_2ecompile_2ecpr_2eapartW(heff_dup(v_lay_2444), v_x_2439, MK_INT(0LL), v_t_2445));
            V v_t_2447 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2446, 1));
            heff_drop(v_x_2446);
            if (((heff_dup(v_t_2447) == NTAG(TAG_True)) && ({ V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2440), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24129 = (g_heff_2ecompile_2ecpr_2eapartW(heff_dup(v_lay_2444), v_x_2439, MK_INT(0LL), heff_dup(v_t_2448))); int c_ = ({ V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2440), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24130 = (g_heff_2ecompile_2eir_2ecountW(v_x_2439, MK_INT(0LL), heff_dup(v_t_2449))); int c_ = heff_intEq_c_lent(v_t_24129, v_t_24130, 0); heff_drop(v_t_24130); c_; }); heff_drop(v_t_2449); c_; }); heff_drop(v_t_24129); c_; }); heff_drop(v_t_2448); c_; }))) {
              heff_drop(v_x_2439);
              heff_drop(v_b_2440);
              heff_drop(v_t_2447);
              v_t_2464 = heff_tag_at_n(v_ru_24a_2411_24ECall, TAG_Cons, 2, (V[]){heff_get_n(v_lay_2444, 6, 7), v_acc_2438});
            } else {
              heff_drop_cell(v_ru_24a_2411_24ECall, 2);
              heff_drop(v_x_2439);
              heff_drop(v_b_2440);
              heff_drop_rec(v_lay_2444, 7);
              heff_drop(v_t_2447);
              v_t_2464 = v_acc_2438;
            }
          } else {
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            heff_drop_cell(v_ru_24a_2411_24ECall, 2);
            heff_drop(v_x_2439);
            heff_drop(v_b_2440);
            heff_drop(v_field_2443);
            v_t_2464 = v_acc_2438;
          }
        }
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_a_2411, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      default: heff_nomatch(v_a_2411);
      }
      V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_246, heff_tag_n(TAG_Cons, 2, (V[]){v_b_247, v_rest_244})});
      V t_0 = v_k_240;
      V t_1 = v_t_2464;
      V t_2 = v_t_2465;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2466 = heff_field(v_x31_243, 0);
      V v_arms_2467 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EMatch = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_k_2468 = heff_dup(v_k_240);
      V v_acc_2469 = v_acc_241;
      V v_s_2470 = heff_dup(v_s_2466);
      V v_arms_2471 = heff_dup(v_arms_2467);
      V v_t_24126;
      switch (heff_tag_of(v_s_2470)) {
      case TAG_EVar: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_s_2470, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_s_2470, 0ULL, 4);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_s_2470, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_ECall: {
        V v_g_2495 = heff_field(v_s_2470, 0);
        heff_take_n(v_s_2470, 1ULL, 2);
        V v_acc_2497 = v_acc_2469;
        V v_arms_2498 = v_arms_2471;
        HeffT2 v_t_2499 = ({ V a_0 = v_k_2468; V a_1 = v_g_2495; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_k_2468); heff_drop(v_g_2495); r_; });
        {
          V v_field_24101 = v_t_2499.f[1];
          int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
          if ((v_tag_24100 == ((int64_t)0ULL))) {
            V v_lay_24102 = v_field_24101;
            V v_record_24103 = heff_take_field(v_lay_24102, 3);
            V v_cons_24104 = heff_take_field(v_lay_24102, 5);
            V v_group_24105 = heff_get_n(v_lay_24102, 6, 7);
            if (!(heff_dup(v_record_24103) == NTAG(TAG_True))) {
              heff_drop(v_record_24103);
              V v_t_24111 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2esitesW_lam0, 1, 1, (V[]){v_arms_2498}); V a_1 = v_cons_24104; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_cons_24104); r_; });
              if ((heff_dup(v_t_24111) == NTAG(TAG_True))) {
                heff_drop(v_t_24111);
                v_t_24126 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_group_24105, v_acc_2497});
              } else {
                heff_drop_cell(v_ru_24x3_242_24Cons, 2);
                heff_drop(v_group_24105);
                heff_drop(v_t_24111);
                v_t_24126 = v_acc_2497;
              }
            } else {
              heff_drop_cell(v_ru_24x3_242_24Cons, 2);
              heff_drop(v_arms_2498);
              heff_drop(v_record_24103);
              heff_drop(v_cons_24104);
              heff_drop(v_group_24105);
              v_t_24126 = v_acc_2497;
            }
          } else {
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            heff_drop(v_arms_2498);
            heff_drop(v_field_24101);
            v_t_24126 = v_acc_2497;
          }
        }
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_s_2470, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      default: heff_nomatch(v_s_2470);
      }
      V v_t_24127 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2467, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_t_24126;
      V t_2 = heff_tag_at_n(v_ru_24x31_243_24EMatch, TAG_Cons, 2, (V[]){v_s_2466, v_t_24127});
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_24128 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_24128;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2esitesW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2esitesW(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecpr_2esitesW_lam0(V self, V *args) {
  V v_c_24106 = args[0];
  V v_arms_2498 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24107 = ({ V b_0 = heff_get_n(v_c_24106, 0, 4); V a_1 = v_arms_2498; HeffT2 r_ = (g_heff_2ecompile_2eir_2earmFor_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_arms_2498); r_; });
  {
    V v_field_24109 = v_t_24107.f[1];
    int64_t v_tag_24108 = ((int64_t)v_t_24107.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24108 == ((int64_t)0ULL)) && ({ V v_x11_24110 = heff_dup(v_field_24109); int c_ = 1; heff_drop(v_x11_24110); c_; })));
    heff_drop(v_field_24109);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2ecpr_2elabelAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2elabelAt_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2elabelAt(V v_l_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_ks_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c_lent(v_l_240, v_k_243, 0)) {
      return v_i_241;
    } else {
      V t_0 = v_l_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ks_244;
      v_l_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2elabelAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2elabelAt(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2earmBodyAs_str0, 0, "");
V g_heff_2ecompile_2ecpr_2earmBodyAs_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2earmBodyAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2earmBodyAs_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2earmBodyAs(V v_lay_240, V v_vs_241, V v_c_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop_rec(v_c_242, 4);
    return NTAG(TAG_EAbandon);
  }
  case TAG_Just: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkArm: {
      V v_ws_246 = heff_field(v_x41_244, 1);
      V v_b_247 = heff_field(v_x41_244, 2);
      heff_take_n(v_x41_244, 6ULL, 3);
      V v_t_248 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_ws_246, heff_get_n(v_c_242, 3, 4)));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2earmBodyAs_lam0, 2, 2, (V[]){v_lay_240, heff_dup(v_vs_241)}); V a_1 = v_b_247; V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2earmBodyAs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2earmBodyAs(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2earmBodyAs_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_lay_240 = heff_env(self)[0];
  V v_vs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_dup(heff_field(v_x_2410, 0));
    v_t_2413 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_i_2416;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_y_2415 = heff_field(v_x_2410, 1);
    heff_take_n(v_x_2410, 2ULL, 2);
    v_i_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2417 = heff_get_n(v_lay_240, 1, 7);
  V v_t_2418;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_t_2417);
    v_t_2418 = heff_intAdd(v_i_2416, MK_INT(1LL));
  } else {
    heff_drop(v_t_2417);
    v_t_2418 = v_i_2416;
  }
  HeffT3 v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = v_vs_241; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_241); r_; });
  V v_t_2425;
  {
    V v_field_2421 = v_t_2419.f[1];
    V v_field_2422 = v_t_2419.f[2];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_x_2423 = v_field_2421;
      V v_x12_2424 = v_field_2422;
      heff_drop(v_x12_2424);
      v_t_2425 = v_x_2423;
    } else {
      heff_drop(v_field_2421);
      heff_drop(v_field_2422);
      v_t_2425 = ((V)&g_heff_2ecompile_2ecpr_2earmBodyAs_str0);
    }
  }
  return heff_tag_n(TAG_ELet, 3, (V[]){v_t_2413, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2425}), v_acc_249});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str1, 4, "True");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str2, 5, "False");
Clo g_heff_2ecompile_2ecpr_2echosen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2echosen_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2echosen(V v_vs_240, V v_way_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_way_241);
    return NTAG(TAG_EAbandon);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_tail(v_way_241, 1, (V[]){v_c_243});
    }
    case TAG_Cons: {
      V v_yes_247 = heff_tr(heff_call(heff_dup(v_way_241), 1, (V[]){heff_dup(v_c_243)}));
      V v_no_248 = heff_tr(g_heff_2ecompile_2ecpr_2echosen(v_vs_240, v_way_241, v_x32_244));
      V v_t_249 = heff_tag_n(TAG_OfFixed, 2, (V[]){NTAG(TAG_I64), NTAG(TAG_OpEq)});
      V v_t_2412;
      switch (heff_tag_of(v_vs_240)) {
      case TAG_Nil: {
        v_t_2412 = ((V)&g_heff_2ecompile_2ecpr_2echosen_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_vs_240, 0);
        v_t_2412 = heff_dup(v_x_2410);
        break;
      }
      default: heff_nomatch(v_vs_240);
      }
      V v_t_2413 = heff_tag_n(TAG_EFixed, 2, (V[]){NTAG(TAG_I64), heff_get_n(v_c_243, 1, 4)});
      V v_t_2414 = heff_tag_n(TAG_CRel, 3, (V[]){v_t_249, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2412}), v_t_2413});
      V v_t_2415 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_str1), NTAG(TAG_Nil), v_yes_247});
      V v_t_2416 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_str2), NTAG(TAG_Nil), v_no_248});
      V v_t_2417 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_t_2414}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2417})});
    }
    default: return heff_nomatch(v_x32_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2echosen_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2echosen(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2eapart_str0, 0, "");
V g_heff_2ecompile_2ecpr_2eapart_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eapart_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2eapart_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2eapart_lam3(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eapart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eapart_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2eapart(V v_lay_240, V v_x_241, V v_vs_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EProj: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_l_245 = heff_field(v_x4_243, 1);
    V v_sh_246 = heff_field(v_x4_243, 2);
    V v_t_247 = heff_field(v_x4_243, 3);
    V v_ru_24x4_243_24EProj = heff_take_reuse_n(v_x4_243, 15ULL, 4);
    V v_t_2447;
    switch (heff_tag_of(v_e_244)) {
    case TAG_EVar: {
      V v_y_248 = heff_dup(heff_field(v_e_244, 0));
      v_t_2447 = heff_bool(heff_strEq_c_lent(v_x_241, v_y_248, 0));
      heff_drop(v_y_248);
      break;
    }
    case TAG_EGlobal: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_244);
    }
    if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
      heff_drop(v_e_244);
      heff_drop(v_sh_246);
      heff_drop(v_t_247);
      heff_drop_cell(v_ru_24x4_243_24EProj, 4);
      heff_drop(v_t_2447);
      V v_i_2448 = ({ V a_0 = v_l_245; V a_1 = MK_INT(0LL); V a_2 = heff_rfield(v_lay_240, 4); V r_ = (g_heff_2ecompile_2ecpr_2elabelAt(a_0, a_1, a_2)); heff_drop(v_l_245); r_; });
      V v_t_2449 = heff_get_n(v_lay_240, 1, 7);
      V v_t_2450;
      if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
        heff_drop(v_t_2449);
        v_t_2450 = heff_intAdd(v_i_2448, MK_INT(1LL));
      } else {
        heff_drop(v_t_2449);
        v_t_2450 = v_i_2448;
      }
      HeffT3 v_t_2451 = (g_list_2edrop_24cpr(v_t_2450, v_vs_242));
      V v_t_2457;
      {
        V v_field_2453 = v_t_2451.f[1];
        V v_field_2454 = v_t_2451.f[2];
        int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
        if ((v_tag_2452 == ((int64_t)0ULL))) {
          V v_x_2455 = v_field_2453;
          V v_x12_2456 = v_field_2454;
          heff_drop(v_x12_2456);
          v_t_2457 = v_x_2455;
        } else {
          heff_drop(v_field_2453);
          heff_drop(v_field_2454);
          v_t_2457 = ((V)&g_heff_2ecompile_2ecpr_2eapart_str0);
        }
      }
      return heff_tag_n(TAG_EVar, 1, (V[]){v_t_2457});
    } else {
      heff_drop(v_t_2447);
      V v_t_2458 = heff_tr(g_heff_2ecompile_2ecpr_2eapart(v_lay_240, v_x_241, v_vs_242, v_e_244));
      return heff_tag_at_n(v_ru_24x4_243_24EProj, TAG_EProj, 4, (V[]){v_t_2458, v_l_245, v_sh_246, v_t_247});
    }
  }
  case TAG_EMatch: {
    V v_s_2459 = heff_field(v_x4_243, 0);
    V v_arms_2460 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EMatch = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_24100;
    switch (heff_tag_of(v_s_2459)) {
    case TAG_EVar: {
      V v_y_2461 = heff_dup(heff_field(v_s_2459, 0));
      v_t_24100 = heff_bool(heff_strEq_c_lent(v_x_241, v_y_2461, 0));
      heff_drop(v_y_2461);
      break;
    }
    case TAG_EGlobal: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2459);
    }
    if ((heff_dup(v_t_24100) == NTAG(TAG_True))) {
      heff_drop(v_s_2459);
      heff_drop(v_t_24100);
      V v_arms_24106 = (g_list_2emap_24tok2(v_ru_24x4_243_24EMatch, heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_lam0, 1, 3, (V[]){heff_dup(v_lay_240), heff_dup(v_x_241), heff_dup(v_vs_242)}), v_arms_2460));
      return (g_heff_2ecompile_2ecpr_2echosen(v_vs_242, heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_lam1, 1, 3, (V[]){v_arms_24106, heff_dup(v_lay_240), heff_dup(v_vs_242)}), heff_get_n(v_lay_240, 5, 7)));
    } else {
      heff_drop(v_t_24100);
      return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_lam2, 2, 3, (V[]){v_lay_240, heff_dup(v_x_241), heff_dup(v_vs_242)}), heff_tag_at_n(v_ru_24x4_243_24EMatch, TAG_EMatch, 2, (V[]){v_s_2459, v_arms_2460})));
    }
  }
  default: {
    return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_lam3, 2, 3, (V[]){v_lay_240, heff_dup(v_x_241), heff_dup(v_vs_242)}), v_x4_243));
  }
  }
}
V g_heff_2ecompile_2ecpr_2eapart_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2eapart(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2eapart_lam0(V self, V *args) {
  V v_x2_24101 = args[0];
  V v_lay_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x2_24101)) {
  case TAG_MkArm: {
    V v_t_24102 = heff_field(v_x2_24101, 0);
    V v_vs_24103 = heff_field(v_x2_24101, 1);
    V v_b_24104 = heff_field(v_x2_24101, 2);
    V v_ru_24x2_24101_24MkArm = heff_take_reuse_n(v_x2_24101, 7ULL, 3);
    V v_t_24105 = ({ V a_0 = v_lay_240; V a_1 = v_x_241; V a_2 = v_vs_242; V a_3 = v_b_24104; V r_ = heff_tr(g_heff_2ecompile_2ecpr_2eapart(a_0, a_1, a_2, a_3)); heff_drop(v_x_241); heff_drop(v_vs_242); r_; });
    return heff_tag_at_n(v_ru_24x2_24101_24MkArm, TAG_MkArm, 3, (V[]){v_t_24102, v_vs_24103, v_t_24105});
  }
  default: return heff_nomatch(v_x2_24101);
  }
}
V g_heff_2ecompile_2ecpr_2eapart_lam1(V self, V *args) {
  V v_c_24107 = args[0];
  V v_arms_24106 = heff_env(self)[0];
  V v_lay_240 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24108 = ({ V a_0 = heff_rfield(v_c_24107, 0); V a_1 = v_arms_24106; V r_ = (g_heff_2ecompile_2eir_2earmFor(a_0, a_1)); heff_drop(v_arms_24106); r_; });
  return ({ V a_0 = v_lay_240; V a_1 = v_vs_242; V a_2 = v_c_24107; V a_3 = v_t_24108; V r_ = (g_heff_2ecompile_2ecpr_2earmBodyAs(a_0, a_1, a_2, a_3)); heff_drop(v_vs_242); r_; });
}
V g_heff_2ecompile_2ecpr_2eapart_lam2(V self, V *args) {
  V v_x_24109 = args[0];
  V v_p_24110 = args[1];
  V v_lay_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24109);
  return ({ V a_0 = v_lay_240; V a_1 = v_x_241; V a_2 = v_vs_242; V a_3 = v_p_24110; V r_ = (g_heff_2ecompile_2ecpr_2eapart(a_0, a_1, a_2, a_3)); heff_drop(v_x_241); heff_drop(v_vs_242); r_; });
}
V g_heff_2ecompile_2ecpr_2eapart_lam3(V self, V *args) {
  V v_x_24111 = args[0];
  V v_p_24112 = args[1];
  V v_lay_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24111);
  return ({ V a_0 = v_lay_240; V a_1 = v_x_241; V a_2 = v_vs_242; V a_3 = v_p_24112; V r_ = (g_heff_2ecompile_2ecpr_2eapart(a_0, a_1, a_2, a_3)); heff_drop(v_x_241); heff_drop(v_vs_242); r_; });
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_str0, 3, "tag");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_str1, 5, "field");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_str2, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_str3, 4, "$cpr");
Clo g_heff_2ecompile_2ecpr_2ecalledApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ecalledApart_entry, 5, 0};

V g_heff_2ecompile_2ecpr_2ecalledApart(V v_lay_240, V v_g_241, V v_args_242, V v_k_243, V v_z_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_lay_240, 1));
  V v_t_247;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
    v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_dup(heff_rfield(v_lay_240, 2))});
  } else {
    heff_drop(v_t_245);
    v_t_247 = heff_dup(heff_rfield(v_lay_240, 2));
  }
  V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_247; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_248, MK_INT(1LL))));
  HeffT2 v_t_2410 = (g_prelude_2etraverse_24s1023157662x1060337521_24cpr(heff_dup(v_lay_240), MK_INT(0LL), ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_str0), ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_str1), ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_str2), MK_INT(1LL), v_t_249, v_z_244));
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    V v_x_2413 = v_field_2411;
    V v_n_2414 = v_field_2412;
    V v_t_2415 = heff_tag_n(TAG_ECall, 2, (V[]){heff_strAppend(v_g_241, ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_str3)), v_args_242});
    V v_t_2416 = heff_tr(heff_call(v_k_243, 1, (V[]){heff_dup(v_x_2413)}));
    V v_t_2417 = heff_tag_n(TAG_MkArm, 3, (V[]){heff_get_n(v_lay_240, 0, 7), v_x_2413, v_t_2416});
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_x_2419 = heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2415, v_t_2418});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_n_2414});
  }
}
V g_heff_2ecompile_2ecpr_2ecalledApart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ecalledApart(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2ecpr_2erwNode_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2erwNode_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2erwNode_lam3(V self, V *args);
V g_heff_2ecompile_2ecpr_2erwNode_lam2(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2erwNode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2erwNode_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2erwNode(V v_k_240, V v_e_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_ELet: {
    V v_x_243 = heff_field(v_e_241, 0);
    V v_a_244 = heff_field(v_e_241, 1);
    V v_b_245 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    switch (heff_tag_of(v_a_244)) {
    case TAG_ECall: {
      V v_g_246 = heff_field(v_a_244, 0);
      V v_args_247 = heff_field(v_a_244, 1);
      V v_ru_24a_244_24ECall = heff_take_reuse_n(v_a_244, 3ULL, 2);
      V v_x_248 = v_x_243;
      V v_g_249 = heff_dup(v_g_246);
      V v_args_2410 = v_args_247;
      V v_b_2411 = v_b_245;
      HeffT2 v_t_2412 = ({ V a_0 = v_k_240; V a_1 = v_g_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_246); r_; });
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_lay_2415 = v_field_2414;
          V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2411), NTAG(TAG_Nil)});
          V v_x_2417 = (g_heff_2ecompile_2ecpr_2eapartW(heff_dup(v_lay_2415), v_x_248, MK_INT(0LL), v_t_2416));
          V v_t_2418 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2417, 1));
          heff_drop(v_x_2417);
          if (((heff_dup(v_t_2418) == NTAG(TAG_True)) && ({ V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2411), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2447 = (g_heff_2ecompile_2ecpr_2eapartW(heff_dup(v_lay_2415), v_x_248, MK_INT(0LL), heff_dup(v_t_2419))); int c_ = ({ V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2411), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2448 = (g_heff_2ecompile_2eir_2ecountW(v_x_248, MK_INT(0LL), heff_dup(v_t_2420))); int c_ = heff_intEq_c_lent(v_t_2447, v_t_2448, 0); heff_drop(v_t_2448); c_; }); heff_drop(v_t_2420); c_; }); heff_drop(v_t_2447); c_; }); heff_drop(v_t_2419); c_; }))) {
            heff_drop_cell(v_ru_24a_244_24ECall, 2);
            heff_drop(v_t_2418);
            return (g_heff_2ecompile_2ecpr_2ecalledApart_24tok3(v_ru_24e_241_24ELet, heff_dup(v_lay_2415), v_g_249, v_args_2410, heff_clo_n(g_heff_2ecompile_2ecpr_2erwNode_lam0, 1, 3, (V[]){v_lay_2415, v_x_248, v_b_2411}), v_z_242));
          } else {
            heff_drop(v_lay_2415);
            heff_drop(v_t_2418);
            V v_t_2422 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_248, heff_tag_at_n(v_ru_24a_244_24ECall, TAG_ECall, 2, (V[]){v_g_249, v_args_2410}), v_b_2411});
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_z_242});
          }
        } else {
          heff_drop(v_field_2414);
          V v_t_2423 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_248, heff_tag_at_n(v_ru_24a_244_24ECall, TAG_ECall, 2, (V[]){v_g_249, v_args_2410}), v_b_2411});
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_z_242});
        }
      }
    }
    default: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_243, v_a_244, v_b_245}), v_z_242});
    }
    }
  }
  case TAG_EMatch: {
    V v_s_2424 = heff_field(v_e_241, 0);
    V v_arms_2425 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_s_2424)) {
    case TAG_ECall: {
      V v_g_2426 = heff_field(v_s_2424, 0);
      V v_args_2427 = heff_field(v_s_2424, 1);
      V v_ru_24s_2424_24ECall = heff_take_reuse_n(v_s_2424, 3ULL, 2);
      V v_g_2428 = heff_dup(v_g_2426);
      V v_args_2429 = v_args_2427;
      V v_arms_2430 = v_arms_2425;
      HeffT2 v_t_2431 = ({ V a_0 = v_k_240; V a_1 = v_g_2426; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_2426); r_; });
      {
        V v_field_2433 = v_t_2431.f[1];
        int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
        if ((v_tag_2432 == ((int64_t)0ULL))) {
          V v_lay_2434 = v_field_2433;
          if (!(heff_dup(heff_rfield(v_lay_2434, 3)) == NTAG(TAG_True))) {
            V v_t_2440 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2ecpr_2erwNode_lam1, 1, 1, (V[]){heff_dup(v_arms_2430)}), heff_rfield(v_lay_2434, 5)));
            if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
              heff_drop_cell(v_ru_24s_2424_24ECall, 2);
              heff_drop(v_t_2440);
              return (g_heff_2ecompile_2ecpr_2ecalledApart_24tok2(v_ru_24e_241_24EMatch, heff_dup(v_lay_2434), v_g_2428, v_args_2429, heff_clo_n(g_heff_2ecompile_2ecpr_2erwNode_lam2, 1, 2, (V[]){v_arms_2430, v_lay_2434}), v_z_242));
            } else {
              heff_drop_rec(v_lay_2434, 7);
              heff_drop(v_t_2440);
              V v_t_2444 = heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){heff_tag_at_n(v_ru_24s_2424_24ECall, TAG_ECall, 2, (V[]){v_g_2428, v_args_2429}), v_arms_2430});
              return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2444, v_z_242});
            }
          } else {
            heff_drop_rec(v_lay_2434, 7);
            V v_t_2445 = heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){heff_tag_at_n(v_ru_24s_2424_24ECall, TAG_ECall, 2, (V[]){v_g_2428, v_args_2429}), v_arms_2430});
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2445, v_z_242});
          }
        } else {
          heff_drop(v_field_2433);
          V v_t_2446 = heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){heff_tag_at_n(v_ru_24s_2424_24ECall, TAG_ECall, 2, (V[]){v_g_2428, v_args_2429}), v_arms_2430});
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2446, v_z_242});
        }
      }
    }
    default: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_2424, v_arms_2425}), v_z_242});
    }
    }
  }
  default: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_z_242});
  }
  }
}
V g_heff_2ecompile_2ecpr_2erwNode_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2erwNode(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2erwNode_lam0(V self, V *args) {
  V v_vs_2421 = args[0];
  V v_lay_2415 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_b_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lay_2415; V a_1 = v_x_248; V a_2 = v_vs_2421; V a_3 = v_b_2411; V r_ = (g_heff_2ecompile_2ecpr_2eapart(a_0, a_1, a_2, a_3)); heff_drop(v_x_248); heff_drop(v_vs_2421); r_; });
}
V g_heff_2ecompile_2ecpr_2erwNode_lam1(V self, V *args) {
  V v_c_2435 = args[0];
  V v_arms_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2436 = ({ V b_0 = heff_get_n(v_c_2435, 0, 4); V a_1 = v_arms_2430; HeffT2 r_ = (g_heff_2ecompile_2eir_2earmFor_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_arms_2430); r_; });
  {
    V v_field_2438 = v_t_2436.f[1];
    int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2437 == ((int64_t)0ULL)) && ({ V v_x11_2439 = heff_dup(v_field_2438); int c_ = 1; heff_drop(v_x11_2439); c_; })));
    heff_drop(v_field_2438);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2erwNode_lam3(V self, V *args) {
  V v_c_2442 = args[0];
  V v_arms_2430 = heff_env(self)[0];
  V v_lay_2434 = heff_env(self)[1];
  V v_vs_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2443 = ({ V a_0 = heff_rfield(v_c_2442, 0); V a_1 = v_arms_2430; V r_ = (g_heff_2ecompile_2eir_2earmFor(a_0, a_1)); heff_drop(v_arms_2430); r_; });
  return ({ V a_0 = v_lay_2434; V a_1 = v_vs_2441; V a_2 = v_c_2442; V a_3 = v_t_2443; V r_ = (g_heff_2ecompile_2ecpr_2earmBodyAs(a_0, a_1, a_2, a_3)); heff_drop(v_vs_2441); r_; });
}
V g_heff_2ecompile_2ecpr_2erwNode_lam2(V self, V *args) {
  V v_vs_2441 = args[0];
  V v_arms_2430 = heff_env(self)[0];
  V v_lay_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_vs_2441; V a_1 = heff_clo_n(g_heff_2ecompile_2ecpr_2erwNode_lam3, 1, 3, (V[]){v_arms_2430, heff_dup(v_lay_2434), heff_dup(v_vs_2441)}); V a_2 = heff_get_n(v_lay_2434, 5, 7); V r_ = (g_heff_2ecompile_2ecpr_2echosen(a_0, a_1, a_2)); heff_drop(v_vs_2441); r_; });
}
V g_heff_2ecompile_2ecpr_2erw_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2erw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2erw_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2erw(V v_k_240, V v_e_241) {
top: ;
  V v_m_244 = (g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam0, 2, 1, (V[]){heff_dup(v_k_240)}), v_e_241));
  return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam1, 1, 2, (V[]){v_m_244, heff_dup(v_k_240)});
}
V g_heff_2ecompile_2ecpr_2erw_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2erw(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2erw_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_p_243 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_242);
  return ({ V a_0 = v_k_240; V a_1 = v_p_243; V r_ = (g_heff_2ecompile_2ecpr_2erw(a_0, a_1)); heff_drop(v_k_240); r_; });
}
V g_heff_2ecompile_2ecpr_2erw_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    return ({ V a_0 = v_k_240; V a_1 = v_x_247; V a_2 = v_n_248; V r_ = (g_heff_2ecompile_2ecpr_2erwNode(a_0, a_1, a_2)); heff_drop(v_k_240); r_; });
  }
  default: return heff_nomatch(v_x2_246);
  }
}

HeffT2 g_heff_2ecompile_2ecpr_2efieldAt_24cpr(V v_i_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x2_241, 0);
    V v_ps_244 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_i_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_e_245 = heff_field(v_x3_242, 0);
      V v_es_246 = heff_field(v_x3_242, 1);
      if (heff_intEq_c_lent(v_p_243, v_i_240, 0)) {
        heff_drop(v_i_240);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_e_245)}});
      } else {
        V t_0 = v_i_240;
        V t_1 = v_ps_244;
        V t_2 = v_es_246;
        v_i_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2eboundAll_str0, 2, "f$");
V g_heff_2ecompile_2ecpr_2eboundAll_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eboundAll_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2eboundAll_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2eboundAll_lam3(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eboundAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eboundAll_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eboundAll(V v_b_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eboundAll_lam0, 1, 1, (V[]){v_b_240});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x2_241, 0);
    V v_es_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_b_245 = v_b_240;
    V v_e_246 = v_e_243;
    V v_t_247 = (g_heff_2ecompile_2eir_2eisValue(v_e_246));
    V v_m_2419;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_246, NTAG(TAG_Nil)});
      V v_t_249 = (g_prelude_2e_2b_2b(heff_take_field(v_b_245, 1), v_t_248));
      V v_x_2410 = ({ V rv_1 = v_t_249; V rr_ = heff_rec_reuse_nf(v_b_245, 1ULL, 2, shape_lets__vals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      v_m_2419 = heff_clo_n(g_heff_2ecompile_2ecpr_2eboundAll_lam1, 1, 1, (V[]){v_x_2410});
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_247);
      v_m_2419 = heff_clo_n(g_heff_2ecompile_2ecpr_2eboundAll_lam2, 1, 2, (V[]){v_e_246, v_b_245});
    }
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eboundAll_lam3, 1, 2, (V[]){v_m_2419, v_es_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecpr_2eboundAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eboundAll(a[0], a[1]);
}
V g_heff_2ecompile_2ecpr_2eboundAll_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_b_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_240, v_n_242});
}
V g_heff_2ecompile_2ecpr_2eboundAll_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_n_2411});
}
V g_heff_2ecompile_2ecpr_2eboundAll_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  V v_e_246 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = heff_strAppend(((V)&g_heff_2ecompile_2ecpr_2eboundAll_str0), heff_intShow(heff_dup(v_n_2412)));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2413), v_e_246}), NTAG(TAG_Nil)});
  V v_t_2415 = (g_prelude_2e_2b_2b(heff_take_field(v_b_245, 0), v_t_2414));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_2413}), NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(heff_get_n(v_b_245, 1, 2), v_t_2416));
  V v_x_2418 = heff_rec_n(2, shape_lets__vals, (V[]){v_t_2415, v_t_2417});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2418, heff_intAdd(v_n_2412, MK_INT(1LL))});
}
V g_heff_2ecompile_2ecpr_2eboundAll_lam3(V self, V *args) {
  V v_n_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_es_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2421 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_n_2420}));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_n_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    V v_t_2424 = (g_heff_2ecompile_2ecpr_2eboundAll(v_x_2422, v_es_244));
    V f_ = v_t_2424;
    args[0] = v_n_2423;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2ecpr_2ebuiltOut_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2ebuiltOut_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ebuiltOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ebuiltOut_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2ebuiltOut(V v_lay_240, V v_c_241, V v_es_242) {
top: ;
  V v_t_243 = heff_rec_n(2, shape_lets__vals, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_m_244 = (g_heff_2ecompile_2ecpr_2eboundAll(v_t_243, v_es_242));
  return heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOut_lam0, 1, 3, (V[]){v_m_244, v_lay_240, v_c_241});
}
V g_heff_2ecompile_2ecpr_2ebuiltOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ebuiltOut(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecpr_2ebuiltOut_lam1(V self, V *args) {
  V v_i_2424 = args[0];
  V v_k_2425 = args[1];
  V v_places_2418 = heff_env(self)[0];
  V v_es_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2426 = ({ V a_0 = v_i_2424; V a_1 = v_places_2418; V a_2 = v_es_2419; HeffT2 r_ = (g_heff_2ecompile_2ecpr_2efieldAt_24cpr(a_0, a_1, a_2)); heff_drop(v_places_2418); heff_drop(v_es_2419); r_; });
  {
    V v_field_2428 = v_t_2426.f[1];
    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
    if ((v_tag_2427 == ((int64_t)0ULL))) {
      heff_drop(v_k_2425);
      V v_x_2429 = v_field_2428;
      return v_x_2429;
    } else {
      heff_drop(v_field_2428);
      switch (heff_tag_of(v_k_2425)) {
      case TAG_RepV: {
        return heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_RepFix: {
        V v_w_2430 = heff_field(v_k_2425, 0);
        heff_take_n(v_k_2425, 1ULL, 1);
        return heff_tag_n(TAG_EFixed, 2, (V[]){v_w_2430, MK_INT(0LL)});
      }
      case TAG_RepF64: {
        return heff_tag_nf(TAG_EFloat, 1, 1u, (V[]){heff_word_f64((0.0))});
      }
      case TAG_RepInt: {
        return heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(0LL)});
      }
      default: return heff_nomatch(v_k_2425);
      }
    }
  }
}
V g_heff_2ecompile_2ecpr_2ebuiltOut_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_lay_240 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_lets_249 = heff_take_field(v_x_247, 0);
    V v_vals_2410 = heff_get_n(v_x_247, 1, 2);
    V v_ls_2411 = v_lets_249;
    V v_lay_2412 = v_lay_240;
    V v_tuple_2413 = heff_take_field(v_lay_2412, 0);
    V v_numbered_2414 = heff_take_field(v_lay_2412, 1);
    V v_kinds_2415 = heff_get_n(v_lay_2412, 2, 7);
    V v_c_2416 = v_c_241;
    V v_index_2417 = heff_take_field(v_c_2416, 1);
    V v_places_2418 = heff_get_n(v_c_2416, 3, 4);
    V v_es_2419 = v_vals_2410;
    V v_t_2421;
    if ((heff_dup(v_numbered_2414) == NTAG(TAG_True))) {
      V v_t_2420 = heff_tag_n(TAG_EFixed, 2, (V[]){NTAG(TAG_I64), v_index_2417});
      v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_index_2417);
      v_t_2421 = NTAG(TAG_Nil);
    }
    V v_t_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_kinds_2415));
    V v_t_2423 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2422, MK_INT(1LL))));
    V v_t_2431 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOut_lam1, 2, 2, (V[]){v_places_2418, v_es_2419}), v_t_2423, heff_dup(v_kinds_2415)));
    V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2431));
    V v_t_2434;
    if ((heff_dup(v_numbered_2414) == NTAG(TAG_True))) {
      heff_drop(v_numbered_2414);
      V v_t_2433 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
      v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_kinds_2415});
    } else {
      heff_drop(v_numbered_2414);
      v_t_2434 = v_kinds_2415;
    }
    V v_t_2435 = (g_list_2emap_24s1902028738x441242582(v_t_2434));
    V v_e_2436 = heff_tag_n(TAG_ETag, 3, (V[]){v_tuple_2413, v_t_2432, v_t_2435});
    V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ls_2411));
    V v_x_2438 = ({ V a_0 = v_e_2436; V a_1 = v_t_2437; V r_ = (g_list_2efoldl_24s1016340684x604821087(a_0, a_1)); heff_drop(v_t_2437); r_; });
    return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2438, v_n_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2eoutRw_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2eoutRw_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2eoutRw_str2, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2eoutRw_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eoutRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eoutRw_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eoutRw(V v_lay_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_ERecord: {
    V v_fs_242 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 1ULL, 2);
    HeffT2 v_t_244 = ({ V b_0 = ((V)&g_heff_2ecompile_2ecpr_2eoutRw_str0); V a_1 = heff_rfield(v_lay_240, 5); HeffT2 r_ = (g_list_2efind_24s558881959x1385112442_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_248;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        v_t_248 = v_x_247;
      } else {
        heff_drop(v_field_246);
        v_t_248 = heff_rec_n(4, shape_tag__index__tys__places, (V[]){((V)&g_heff_2ecompile_2ecpr_2eoutRw_str1), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
    }
    V v_t_249 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24e_241_24ERecord, v_fs_242));
    return (g_heff_2ecompile_2ecpr_2ebuiltOut(v_lay_240, v_t_248, v_t_249));
  }
  case TAG_ETag: {
    V v_t_2410 = heff_field(v_e_241, 0);
    V v_args_2411 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 3);
    HeffT2 v_t_2413 = (g_list_2efind_24s558881959x1385112442_24cpr(v_t_2410, heff_rfield(v_lay_240, 5)));
    V v_t_2417;
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        heff_drop(v_t_2410);
        V v_x_2416 = v_field_2415;
        v_t_2417 = v_x_2416;
      } else {
        heff_drop(v_field_2415);
        v_t_2417 = heff_rec_n(4, shape_tag__index__tys__places, (V[]){v_t_2410, MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
    }
    return (g_heff_2ecompile_2ecpr_2ebuiltOut(v_lay_240, v_t_2417, v_args_2411));
  }
  case TAG_ECall: {
    V v_g_2418 = heff_field(v_e_241, 0);
    V v_args_2419 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam0, 1, 2, (V[]){v_g_2418, v_args_2419});
  }
  default: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam1, 1, 1, (V[]){v_e_241});
  }
  }
}
V g_heff_2ecompile_2ecpr_2eoutRw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eoutRw(a[0], a[1]);
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam0(V self, V *args) {
  V v_n_2420 = args[0];
  V v_g_2418 = heff_env(self)[0];
  V v_args_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tag_n(TAG_ECall, 2, (V[]){heff_strAppend(v_g_2418, ((V)&g_heff_2ecompile_2ecpr_2eoutRw_str2)), v_args_2419});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, v_n_2420});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam1(V self, V *args) {
  V v_n_2422 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2422});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ebuiltOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ebuiltOf_str1, 0, "");
V g_heff_2ecompile_2ecpr_2ebuiltOf_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2ebuiltOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ebuiltOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ebuiltOf_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2ebuiltOf(V v_lay_240, V v_vs_241, V v_c_242) {
top: ;
  V v_places_243 = heff_take_field(v_c_242, 3);
  V v_tys_244 = heff_take_field(v_c_242, 2);
  V v_tag_245 = heff_get_n(v_c_242, 0, 4);
  V v_record_246 = heff_take_field(v_lay_240, 3);
  V v_numbered_247 = heff_take_field(v_lay_240, 1);
  V v_labels_248 = heff_get_n(v_lay_240, 4, 7);
  if ((heff_dup(v_record_246) == NTAG(TAG_True))) {
    heff_drop(v_tag_245);
    heff_drop(v_record_246);
    V v_t_2419 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOf_lam0, 2, 2, (V[]){v_numbered_247, heff_dup(v_vs_241)}), v_labels_248, v_places_243));
    return heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2419, v_tys_244});
  } else {
    heff_drop(v_record_246);
    heff_drop(v_labels_248);
    V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOf_lam1, 1, 2, (V[]){v_numbered_247, heff_dup(v_vs_241)}), v_places_243));
    return heff_tag_n(TAG_ETag, 3, (V[]){v_tag_245, v_t_2429, v_tys_244});
  }
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2ebuiltOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_lam0(V self, V *args) {
  V v_l_249 = args[0];
  V v_i_2410 = args[1];
  V v_numbered_247 = heff_env(self)[0];
  V v_vs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411;
  if ((heff_dup(v_numbered_247) == NTAG(TAG_True))) {
    heff_drop(v_numbered_247);
    v_t_2411 = heff_intAdd(v_i_2410, MK_INT(1LL));
  } else {
    heff_drop(v_numbered_247);
    v_t_2411 = v_i_2410;
  }
  HeffT3 v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = v_vs_241; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_241); r_; });
  V v_t_2418;
  {
    V v_field_2414 = v_t_2412.f[1];
    V v_field_2415 = v_t_2412.f[2];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x_2416 = v_field_2414;
      V v_x12_2417 = v_field_2415;
      heff_drop(v_x12_2417);
      v_t_2418 = v_x_2416;
    } else {
      heff_drop(v_field_2414);
      heff_drop(v_field_2415);
      v_t_2418 = ((V)&g_heff_2ecompile_2ecpr_2ebuiltOf_str0);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_l_249, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2418})});
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_lam1(V self, V *args) {
  V v_i_2420 = args[0];
  V v_numbered_247 = heff_env(self)[0];
  V v_vs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421;
  if ((heff_dup(v_numbered_247) == NTAG(TAG_True))) {
    heff_drop(v_numbered_247);
    v_t_2421 = heff_intAdd(v_i_2420, MK_INT(1LL));
  } else {
    heff_drop(v_numbered_247);
    v_t_2421 = v_i_2420;
  }
  HeffT3 v_t_2422 = ({ V a_0 = v_t_2421; V a_1 = v_vs_241; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_241); r_; });
  V v_t_2428;
  {
    V v_field_2424 = v_t_2422.f[1];
    V v_field_2425 = v_t_2422.f[2];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      V v_x_2426 = v_field_2424;
      V v_x12_2427 = v_field_2425;
      heff_drop(v_x12_2427);
      v_t_2428 = v_x_2426;
    } else {
      heff_drop(v_field_2424);
      heff_drop(v_field_2425);
      v_t_2428 = ((V)&g_heff_2ecompile_2ecpr_2ebuiltOf_str1);
    }
  }
  return heff_tag_n(TAG_EVar, 1, (V[]){v_t_2428});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str1, 4, "True");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str2, 5, "False");
Clo g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(V v_lit_240, V v_lit_241, V v_vs_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_EAbandon);
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x3_243, 0);
    V v_x32_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    switch (heff_tag_of(v_x32_245)) {
    case TAG_Nil: {
      HEFF_LAST return g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2(v_ru_24x3_243_24Cons, v_lit_240, v_lit_241, v_c_244);
    }
    case TAG_Cons: {
      V v_yes_248 = (g_heff_2ecompile_2ecpr_2ebuiltOf(heff_dup(v_lit_240), v_lit_241, heff_dup(v_c_244)));
      V v_no_249 = (g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(v_lit_240, v_lit_241, v_vs_242, v_x32_245));
      V v_t_2410 = heff_tag_n(TAG_OfFixed, 2, (V[]){NTAG(TAG_I64), NTAG(TAG_OpEq)});
      V v_t_2413;
      switch (heff_tag_of(v_vs_242)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_vs_242, 0);
        v_t_2413 = heff_dup(v_x_2411);
        break;
      }
      default: heff_nomatch(v_vs_242);
      }
      V v_t_2414 = heff_tag_n(TAG_EFixed, 2, (V[]){NTAG(TAG_I64), heff_get_n(v_c_244, 1, 4)});
      V v_t_2415 = heff_tag_n(TAG_CRel, 3, (V[]){v_t_2410, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2413}), v_t_2414});
      V v_t_2416 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str1), NTAG(TAG_Nil), v_yes_248});
      V v_t_2417 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str2), NTAG(TAG_Nil), v_no_249});
      V v_t_2418 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_t_2415}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2418})});
    }
    default: return heff_nomatch(v_x32_245);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_str1, 3, "tag");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_str2, 5, "field");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_str3, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_str4, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2ewrapperOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ewrapperOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ewrapperOf_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2ewrapperOf(V v_lay_240, V v_d_241, V v_xs_242) {
top: ;
  V v_m_243 = (g_prelude_2etraverse_24s75890152x1871550235(MK_INT(0LL), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_str0), MK_INT(1LL), v_xs_242));
  return heff_clo_n(g_heff_2ecompile_2ecpr_2ewrapperOf_lam0, 1, 3, (V[]){v_m_243, v_lay_240, v_d_241});
}
V g_heff_2ecompile_2ecpr_2ewrapperOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ewrapperOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecpr_2ewrapperOf_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_lay_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_n_244}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_n_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_dup(heff_rfield(v_lay_240, 1));
    V v_t_2410;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
      v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_dup(heff_rfield(v_lay_240, 2))});
    } else {
      heff_drop(v_t_248);
      v_t_2410 = heff_dup(heff_rfield(v_lay_240, 2));
    }
    V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2410; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2411, MK_INT(1LL))));
    HeffT2 v_t_2413 = (g_prelude_2etraverse_24s1023157662x1060337521_24cpr(heff_dup(v_lay_240), MK_INT(0LL), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_str1), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_str2), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_str3), MK_INT(1LL), v_t_2412, v_n_247));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_x_2416 = v_field_2414;
      V v_n_2417 = v_field_2415;
      V v_t_2418 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_str4));
      V v_t_2419 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_x_246)));
      V v_t_2420 = (g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(heff_dup(v_lay_240), v_x_2416, v_x_2416, heff_dup(heff_rfield(v_lay_240, 5))));
      V v_t_2421 = heff_tag_n(TAG_MkArm, 3, (V[]){heff_get_n(v_lay_240, 0, 7), v_x_2416, v_t_2420});
      V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
      V v_t_2423 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_t_2418, v_t_2419}), v_t_2422});
      V v_body_2424 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_246, v_t_2423});
      V v_t_2425 = ({ V rv_2 = v_body_2424; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_2425, v_n_2417});
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2edefWith_str0, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2edefWith_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam3(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam4(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam5(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam6(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2edefWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2edefWith_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2edefWith(V v_k_240, V v_d_241, V v_m_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_t_243, 0);
    V v_b_245 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_m_242)) {
    case TAG_Nothing: {
      heff_drop(v_xs_244);
      heff_drop(v_b_245);
      V v_t_246 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
      V v_t_247 = (g_heff_2ecompile_2eir_2enubI(v_t_246));
      V v_t_2413 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam0, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_247; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_247); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_m_2414 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
        return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam1, 1, 2, (V[]){v_m_2414, v_d_241});
      } else {
        heff_drop(v_t_2413);
        return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam2, 1, 1, (V[]){v_d_241});
      }
    }
    case TAG_Just: {
      V v_lay_2423 = heff_field(v_m_242, 0);
      V v_m_2424 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, v_b_245));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam3, 1, 4, (V[]){v_m_2424, heff_dup(v_lay_2423), v_d_241, v_xs_244});
    }
    default: return heff_nomatch(v_m_242);
    }
  }
  default: {
    heff_drop(v_t_243);
    V v_t_2440 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_2441 = (g_heff_2ecompile_2eir_2enubI(v_t_2440));
    V v_t_2447 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam4, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_2441; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2441); r_; });
    if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
      heff_drop(v_t_2447);
      V v_m_2448 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam5, 1, 2, (V[]){v_m_2448, v_d_241});
    } else {
      heff_drop(v_t_2447);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam6, 1, 1, (V[]){v_d_241});
    }
  }
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2edefWith(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2edefWith_lam0(V self, V *args) {
  V v_g_248 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = ({ V a_0 = v_k_240; V a_1 = v_g_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_248); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) && ({ V v_x_2412 = heff_dup(v_field_2411); int c_ = 1; heff_drop(v_x_2412); c_; })));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam1(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_t_2419 = ({ V rv_2 = v_x_2417; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2420, v_n_2418});
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam2(V self, V *args) {
  V v_n_2421 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_n_2421});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam3(V self, V *args) {
  V v_n_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  V v_lay_2423 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_xs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2426 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_n_2425}));
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_MkPair: {
    V v_x_2427 = heff_field(v_x2_2426, 0);
    V v_n_2428 = heff_field(v_x2_2426, 1);
    V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
    V v_m_2429 = (g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835(heff_dup(v_lay_2423), v_x_2427));
    V v_x2_2430 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_n_2428}));
    switch (heff_tag_of(v_x2_2430)) {
    case TAG_MkPair: {
      V v_x_2431 = heff_field(v_x2_2430, 0);
      V v_n_2432 = heff_field(v_x2_2430, 1);
      V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
      V v_m_2433 = (g_heff_2ecompile_2ecpr_2ewrapperOf(v_lay_2423, heff_dup(v_d_241), heff_dup(v_xs_244)));
      V v_x2_2434 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_n_2432}));
      switch (heff_tag_of(v_x2_2434)) {
      case TAG_MkPair: {
        V v_x_2435 = heff_field(v_x2_2434, 0);
        V v_n_2436 = heff_field(v_x2_2434, 1);
        V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
        V v_t_2437 = heff_strAppend(heff_take_field(v_d_241, 0), ((V)&g_heff_2ecompile_2ecpr_2edefWith_str0));
        V v_t_2438 = ({ V rv_0 = v_t_2437; V rv_2 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_244, v_x_2431}); V rr_ = heff_rec_reuse_nf(v_d_241, 2ULL, 3, shape_key__name__body, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2439 = heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_Cons, 2, (V[]){v_x_2435, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2434_24MkPair, TAG_Cons, 2, (V[]){v_t_2438, v_t_2439}), v_n_2436});
      }
      default: return heff_nomatch(v_x2_2434);
      }
    }
    default: return heff_nomatch(v_x2_2430);
    }
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam4(V self, V *args) {
  V v_g_2442 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2443 = ({ V a_0 = v_k_240; V a_1 = v_g_2442; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_2442); r_; });
  {
    V v_field_2445 = v_t_2443.f[1];
    int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2444 == ((int64_t)0ULL)) && ({ V v_x_2446 = heff_dup(v_field_2445); int c_ = 1; heff_drop(v_x_2446); c_; })));
    heff_drop(v_field_2445);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam5(V self, V *args) {
  V v_n_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    V v_t_2453 = ({ V rv_2 = v_x_2451; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){v_t_2454, v_n_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam6(V self, V *args) {
  V v_n_2455 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2456, v_n_2455});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_str1, 0, "");
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2(V v_tok_240, V v_lay_241, V v_vs_242, V v_c_243) {
top: ;
  V v_places_244 = heff_take_field(v_c_243, 3);
  V v_tys_245 = heff_take_field(v_c_243, 2);
  V v_tag_246 = heff_get_n(v_c_243, 0, 4);
  V v_record_247 = heff_take_field(v_lay_241, 3);
  V v_numbered_248 = heff_take_field(v_lay_241, 1);
  V v_labels_249 = heff_get_n(v_lay_241, 4, 7);
  if ((heff_dup(v_record_247) == NTAG(TAG_True))) {
    heff_drop(v_tag_246);
    heff_drop(v_record_247);
    V v_t_2420 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam0, 2, 2, (V[]){v_numbered_248, heff_dup(v_vs_242)}), v_labels_249, v_places_244));
    return heff_tag_at_n(v_tok_240, TAG_ERecord, 2, (V[]){v_t_2420, v_tys_245});
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_record_247);
    heff_drop(v_labels_249);
    V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam1, 1, 2, (V[]){v_numbered_248, heff_dup(v_vs_242)}), v_places_244));
    return heff_tag_n(TAG_ETag, 3, (V[]){v_tag_246, v_t_2430, v_tys_245});
  }
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam0(V self, V *args) {
  V v_l_2410 = args[0];
  V v_i_2411 = args[1];
  V v_numbered_248 = heff_env(self)[0];
  V v_vs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412;
  if ((heff_dup(v_numbered_248) == NTAG(TAG_True))) {
    heff_drop(v_numbered_248);
    v_t_2412 = heff_intAdd(v_i_2411, MK_INT(1LL));
  } else {
    heff_drop(v_numbered_248);
    v_t_2412 = v_i_2411;
  }
  HeffT3 v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_vs_242; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_242); r_; });
  V v_t_2419;
  {
    V v_field_2415 = v_t_2413.f[1];
    V v_field_2416 = v_t_2413.f[2];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_x_2417 = v_field_2415;
      V v_x12_2418 = v_field_2416;
      heff_drop(v_x12_2418);
      v_t_2419 = v_x_2417;
    } else {
      heff_drop(v_field_2415);
      heff_drop(v_field_2416);
      v_t_2419 = ((V)&g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_str0);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2410, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2419})});
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam1(V self, V *args) {
  V v_i_2421 = args[0];
  V v_numbered_248 = heff_env(self)[0];
  V v_vs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422;
  if ((heff_dup(v_numbered_248) == NTAG(TAG_True))) {
    heff_drop(v_numbered_248);
    v_t_2422 = heff_intAdd(v_i_2421, MK_INT(1LL));
  } else {
    heff_drop(v_numbered_248);
    v_t_2422 = v_i_2421;
  }
  HeffT3 v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = v_vs_242; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_242); r_; });
  V v_t_2429;
  {
    V v_field_2425 = v_t_2423.f[1];
    V v_field_2426 = v_t_2423.f[2];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    if ((v_tag_2424 == ((int64_t)0ULL))) {
      V v_x_2427 = v_field_2425;
      V v_x12_2428 = v_field_2426;
      heff_drop(v_x12_2428);
      v_t_2429 = v_x_2427;
    } else {
      heff_drop(v_field_2425);
      heff_drop(v_field_2426);
      v_t_2429 = ((V)&g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_str1);
    }
  }
  return heff_tag_n(TAG_EVar, 1, (V[]){v_t_2429});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_24tok2_str0, 3, "tag");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_24tok2_str1, 5, "field");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_24tok2_str2, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_24tok2_str3, 4, "$cpr");
Clo g_heff_2ecompile_2ecpr_2ecalledApart_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ecalledApart_24tok2_entry, 6, 0};

V g_heff_2ecompile_2ecpr_2ecalledApart_24tok2(V v_tok_240, V v_lay_241, V v_g_242, V v_args_243, V v_k_244, V v_z_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_lay_241, 1));
  V v_t_248;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_t_247 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
    v_t_248 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_247, heff_dup(heff_rfield(v_lay_241, 2))});
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_t_246);
    v_t_248 = heff_dup(heff_rfield(v_lay_241, 2));
  }
  V v_t_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_249, MK_INT(1LL))));
  HeffT2 v_t_2411 = (g_prelude_2etraverse_24s1023157662x1060337521_24cpr(heff_dup(v_lay_241), MK_INT(0LL), ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_24tok2_str0), ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_24tok2_str1), ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_24tok2_str2), MK_INT(1LL), v_t_2410, v_z_245));
  {
    V v_field_2412 = v_t_2411.f[0];
    V v_field_2413 = v_t_2411.f[1];
    V v_x_2414 = v_field_2412;
    V v_n_2415 = v_field_2413;
    V v_t_2416 = heff_tag_n(TAG_ECall, 2, (V[]){heff_strAppend(v_g_242, ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_24tok2_str3)), v_args_243});
    V v_t_2417 = heff_tr(heff_call(v_k_244, 1, (V[]){heff_dup(v_x_2414)}));
    V v_t_2418 = heff_tag_n(TAG_MkArm, 3, (V[]){heff_get_n(v_lay_241, 0, 7), v_x_2414, v_t_2417});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
    V v_x_2420 = heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2416, v_t_2419});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_n_2415});
  }
}
V g_heff_2ecompile_2ecpr_2ecalledApart_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ecalledApart_24tok2(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_24tok3_str0, 3, "tag");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_24tok3_str1, 5, "field");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_24tok3_str2, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_24tok3_str3, 4, "$cpr");
Clo g_heff_2ecompile_2ecpr_2ecalledApart_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ecalledApart_24tok3_entry, 6, 0};

V g_heff_2ecompile_2ecpr_2ecalledApart_24tok3(V v_tok_240, V v_lay_241, V v_g_242, V v_args_243, V v_k_244, V v_z_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_lay_241, 1));
  V v_t_248;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_t_247 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
    v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_dup(heff_rfield(v_lay_241, 2))});
  } else {
    heff_drop(v_t_246);
    v_t_248 = heff_dup(heff_rfield(v_lay_241, 2));
  }
  V v_t_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_249, MK_INT(1LL))));
  HeffT2 v_t_2411 = (g_prelude_2etraverse_24s1023157662x1060337521_24cpr(heff_dup(v_lay_241), MK_INT(0LL), ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_24tok3_str0), ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_24tok3_str1), ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_24tok3_str2), MK_INT(1LL), v_t_2410, v_z_245));
  {
    V v_field_2412 = v_t_2411.f[0];
    V v_field_2413 = v_t_2411.f[1];
    V v_x_2414 = v_field_2412;
    V v_n_2415 = v_field_2413;
    V v_t_2416 = heff_tag_n(TAG_ECall, 2, (V[]){heff_strAppend(v_g_242, ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_24tok3_str3)), v_args_243});
    V v_t_2417 = heff_tr(heff_call(v_k_244, 1, (V[]){heff_dup(v_x_2414)}));
    V v_t_2418 = heff_tag_at_n(v_tok_240, TAG_MkArm, 3, (V[]){heff_get_n(v_lay_241, 0, 7), v_x_2414, v_t_2417});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
    V v_x_2420 = heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2416, v_t_2419});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_n_2415});
  }
}
V g_heff_2ecompile_2ecpr_2ecalledApart_24tok3_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ecalledApart_24tok3(a[0], a[1], a[2], a[3], a[4], a[5]);
}