// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define LBL_aliases 1464806715
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_c 317
#define LBL_col 308218
#define LBL_decls 296817955
#define LBL_defines 1776893014
#define LBL_detail 611917692
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_field 298786068
#define LBL_fields 672433636
#define LBL_globals 352931696
#define LBL_key 315609
#define LBL_label 304085774
#define LBL_line 9817275
#define LBL_local 304503685
#define LBL_locals 849679763
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_type_5f 312202367
#define LBL_use 325633
#define LBL_uses 10094739
static uint32_t shape_c__name__span[] = {LBL_c, LBL_name, LBL_span};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_label__detail[] = {LBL_label, LBL_detail};
static uint32_t shape_locals__fields[] = {LBL_locals, LBL_fields};
static uint32_t shape_path__source__span[] = {LBL_path, LBL_source, LBL_span};
static uint32_t shape_path__source__span__defines[] = {LBL_path, LBL_source, LBL_span, LBL_defines};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name[] = {LBL_target, LBL_name};
static uint32_t shape_text__span[] = {LBL_text, LBL_span};
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eshowTySx(V, V);
V g_heff_2ebuild_2edriver_2eshowTySx_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eshowTySx_clo;
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(V, V);
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_clo;
V g_heff_2ebuild_2equery_2eallChars_24s624343939x922214358(V, V, V);
V g_heff_2ebuild_2equery_2eallChars_24s624343939x922214358_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s624343939x922214358_clo;
V g_heff_2ebuild_2equery_2eatLine(V, V);
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eatLine_clo;
V g_heff_2ebuild_2equery_2eatLocal(V, V);
V g_heff_2ebuild_2equery_2eatLocal_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eatLocal_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(V, V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_clo;
V g_heff_2ebuild_2equery_2ecompletionDetail(V, V);
V g_heff_2ebuild_2equery_2ecompletionDetail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionDetail_clo;
V g_heff_2ebuild_2equery_2ecompletionOf(V, V, V, V);
V g_heff_2ebuild_2equery_2ecompletionOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionOf_clo;
V g_heff_2ebuild_2equery_2ecompletionsAt(V, V);
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo;
V g_heff_2ebuild_2equery_2edeclSites(V, V);
V g_heff_2ebuild_2equery_2edeclSites_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edeclSites_clo;
V g_heff_2ebuild_2equery_2edefinesGo(V, V, V, V);
V g_heff_2ebuild_2equery_2edefinesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinesGo_clo;
V g_heff_2ebuild_2equery_2edefinitionAt(V, V);
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionAt_clo;
V g_heff_2ebuild_2equery_2edefinitionIn(V, V, V);
V g_heff_2ebuild_2equery_2edefinitionIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionIn_clo;
V g_heff_2ebuild_2equery_2eeqTarget(V, V);
V g_heff_2ebuild_2equery_2eeqTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eeqTarget_clo;
V g_heff_2ebuild_2equery_2eexpectedIn(V, V, V);
V g_heff_2ebuild_2equery_2eexpectedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexpectedIn_clo;
V g_heff_2ebuild_2equery_2efieldFound(V, V, V, V);
V g_heff_2ebuild_2equery_2efieldFound_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2efieldFound_clo;
V g_heff_2ebuild_2equery_2efieldUsesOf(V, V);
V g_heff_2ebuild_2equery_2efieldUsesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2efieldUsesOf_clo;
V g_heff_2ebuild_2equery_2efixityWords(V, V);
V g_heff_2ebuild_2equery_2efixityWords_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2efixityWords_clo;
V g_heff_2ebuild_2equery_2einfoAt(V, V);
V g_heff_2ebuild_2equery_2einfoAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einfoAt_clo;
V g_heff_2ebuild_2equery_2eisNameChar(V);
V g_heff_2ebuild_2equery_2eisNameChar_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eisNameChar_clo;
V g_heff_2ebuild_2equery_2eisTypedChar(V);
V g_heff_2ebuild_2equery_2eisTypedChar_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eisTypedChar_clo;
V g_heff_2ebuild_2equery_2elastDot(V, V);
V g_heff_2ebuild_2equery_2elastDot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elastDot_clo;
V g_heff_2ebuild_2equery_2elocalOccurrences(V, V);
V g_heff_2ebuild_2equery_2elocalOccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalOccurrences_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ebuild_2equery_2emoreIn(V, V, V);
V g_heff_2ebuild_2equery_2emoreIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2emoreIn_clo;
V g_heff_2ebuild_2equery_2enameClass(V);
V g_heff_2ebuild_2equery_2enameClass_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameClass_clo;
V g_heff_2ebuild_2equery_2enameInGo(V, V, V, V);
V g_heff_2ebuild_2equery_2enameInGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameInGo_clo;
V g_heff_2ebuild_2equery_2enubByStart(V);
V g_heff_2ebuild_2equery_2enubByStart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enubByStart_clo;
V g_heff_2ebuild_2equery_2enubByStart_24dps(V, V);
V g_heff_2ebuild_2equery_2enubByStart_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enubByStart_24dps_clo;
V g_heff_2ebuild_2equery_2eownNameOf(V, V);
V g_heff_2ebuild_2equery_2eownNameOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eownNameOf_clo;
V g_heff_2ebuild_2equery_2eprimitiveName(V, V);
V g_heff_2ebuild_2equery_2eprimitiveName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eprimitiveName_clo;
V g_heff_2ebuild_2equery_2espacesBefore(V, V);
V g_heff_2ebuild_2equery_2espacesBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesBefore_clo;
V g_heff_2ebuild_2equery_2espacesFrom(V, V);
V g_heff_2ebuild_2equery_2espacesFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesFrom_clo;
V g_heff_2ebuild_2equery_2esumTags(V);
V g_heff_2ebuild_2equery_2esumTags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esumTags_clo;
V g_heff_2ebuild_2equery_2esymbolWith(V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolWith_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolWith_clo;
V g_heff_2ebuild_2equery_2esymbolsGo_24dps(V, V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolsGo_24dps_clo;
V g_heff_2ebuild_2equery_2etypedFrom(V, V);
V g_heff_2ebuild_2equery_2etypedFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etypedFrom_clo;
V g_heff_2ebuild_2equery_2ewordAt(V, V, V);
V g_heff_2ebuild_2equery_2ewordAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordAt_clo;
V g_heff_2ebuild_2equery_2ewordsIn(V, V, V, V, V, V);
V g_heff_2ebuild_2equery_2ewordsIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordsIn_clo;
V g_heff_2ebuild_2equery_2ewordsOf(V, V, V, V);
V g_heff_2ebuild_2equery_2ewordsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordsOf_clo;
V g_heff_2eelab_2eglobals_2elookupName(V, V);
V g_heff_2eelab_2eglobals_2elookupName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2elookupName_clo;
V g_heff_2eelab_2elocals_2emkLocal(V, V);
V g_heff_2eelab_2elocals_2emkLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2emkLocal_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s2018073091x1385246979(V);
V g_list_2efilter_24s2018073091x1385246979_entry(V self, V *a);
extern Clo g_list_2efilter_24s2018073091x1385246979_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1715293669x1931437372(V, V, V, V);
V g_list_2efoldl_24f1715293669x1931437372_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1715293669x1931437372_clo;
V g_list_2efoldl_24s1026998256x1634433314(V, V);
V g_list_2efoldl_24s1026998256x1634433314_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1026998256x1634433314_clo;
V g_list_2efoldl_24s1106937552x2116104854(V, V, V);
V g_list_2efoldl_24s1106937552x2116104854_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1106937552x2116104854_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1620243413x998711352(V, V);
V g_list_2efoldl_24s1620243413x998711352_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1620243413x998711352_clo;
V g_list_2efoldl_24s1777318809x1106245647(V, V);
V g_list_2efoldl_24s1777318809x1106245647_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1777318809x1106245647_clo;
V g_list_2efoldl_24s189033563x26633104(V, V);
V g_list_2efoldl_24s189033563x26633104_entry(V self, V *a);
extern Clo g_list_2efoldl_24s189033563x26633104_clo;
V g_list_2efoldl_24s2134067310x2049132013(V, V);
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2134067310x2049132013_clo;
V g_list_2efoldl_24s302194196x751324068(V, V);
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a);
extern Clo g_list_2efoldl_24s302194196x751324068_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s491084544x100802329(V, V);
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s491084544x100802329_clo;
V g_list_2efoldl_24s54159557x1528472185(V, V);
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s54159557x1528472185_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1133029339x682401273(V);
V g_list_2emap_24f1133029339x682401273_entry(V self, V *a);
extern Clo g_list_2emap_24f1133029339x682401273_clo;
V g_list_2emap_24f2063070488x1806431062(V, V);
V g_list_2emap_24f2063070488x1806431062_entry(V self, V *a);
extern Clo g_list_2emap_24f2063070488x1806431062_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s173442543x1801751270(V);
V g_list_2emap_24s173442543x1801751270_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_clo;
V g_list_2emap_24s1996604328x2084368959(V);
V g_list_2emap_24s1996604328x2084368959_entry(V self, V *a);
extern Clo g_list_2emap_24s1996604328x2084368959_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2esortBy_24s1223185427x423554351(V);
V g_list_2esortBy_24s1223185427x423554351_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1223185427x423554351_clo;
V g_list_2esortBy_24s1768199906x1695529242(V);
V g_list_2esortBy_24s1768199906x1695529242_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1768199906x1695529242_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
Clo g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2eisNameChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eisNameChar_entry, 1, 0};

V g_heff_2ebuild_2equery_2eisNameChar(V v_c_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(v_c_240), MK_INT(95LL)) || (heff_intEq_c(heff_dup(v_c_240), MK_INT(39LL)) || (heff_intEq_c(heff_dup(v_c_240), MK_INT(47LL)) || (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(122LL)) || (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL))))) : (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))))))));
  heff_drop(v_c_240);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2eisNameChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eisNameChar(a[0]);
}
Clo g_heff_2ebuild_2equery_2enameInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enameInGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2enameInGo(V v_src_240, V v_x_241, V v_sp_242, V v_from_243) {
top: ;
  V v_t_244 = (g_prelude_2eindexFrom(heff_dup(v_x_241), heff_dup(v_src_240), v_from_243));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_src_240);
    heff_drop(v_x_241);
    return v_sp_242;
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_t_246 = heff_intAdd(heff_dup(v_p_245), heff_strLength(heff_dup(v_x_241)));
    if (heff_intLe_c(v_t_246, heff_dup(heff_rfield(v_sp_242, 1)))) {
      V v_t_248 = (g_heff_2ebuild_2equery_2ewordAt(heff_dup(v_src_240), heff_dup(v_p_245), heff_dup(v_x_241)));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_src_240);
        heff_drop_rec(v_sp_242, 2);
        heff_drop(v_t_248);
        V v_t_249 = heff_intAdd(heff_dup(v_p_245), heff_strLength(v_x_241));
        return heff_rec_n(2, shape_start__end, (V[]){v_p_245, v_t_249});
      } else {
        heff_drop(v_t_248);
        V t_0 = v_src_240;
        V t_1 = v_x_241;
        V t_2 = v_sp_242;
        V t_3 = heff_intAdd(v_p_245, MK_INT(1LL));
        v_src_240 = t_0;
        v_x_241 = t_1;
        v_sp_242 = t_2;
        v_from_243 = t_3;
        goto top;
      }
    } else {
      heff_drop(v_src_240);
      heff_drop(v_x_241);
      heff_drop(v_p_245);
      return v_sp_242;
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ebuild_2equery_2enameInGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2enameInGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2equery_2enubByStart_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2enubByStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enubByStart_entry, 1, 0};

V g_heff_2ebuild_2equery_2enubByStart(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_246 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2equery_2enubByStart_lam0, 1, 1, (V[]){v_x_241}), v_xs_242));
    V v_u_247 = (g_heff_2ebuild_2equery_2enubByStart_24dps(v_t_246, heff_dup(v_cell_243)));
    heff_drop(v_u_247);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2enubByStart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2enubByStart(a[0]);
}
V g_heff_2ebuild_2equery_2enubByStart_lam0(V self, V *args) {
  V v_y_244 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ret_24bool = heff_bool(!heff_intEq_c(heff_dup(heff_rfield(v_y_244, 0)), heff_dup(heff_rfield(v_x_241, 0))));
  heff_drop_rec(v_y_244, 2);
  heff_drop_rec(v_x_241, 2);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2enubByStart_24dps_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2enubByStart_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enubByStart_24dps_entry, 2, 0};

V g_heff_2ebuild_2equery_2enubByStart_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_248 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2equery_2enubByStart_24dps_lam0, 1, 1, (V[]){v_x_242}), v_xs_243));
    V t_0 = v_t_248;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2enubByStart_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2enubByStart_24dps(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2enubByStart_24dps_lam0(V self, V *args) {
  V v_y_246 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ret_24bool = heff_bool(!heff_intEq_c(heff_dup(heff_rfield(v_y_246, 0)), heff_dup(heff_rfield(v_x_242, 0))));
  heff_drop_rec(v_y_246, 2);
  heff_drop_rec(v_x_242, 2);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str2, 1, ":");
Clo g_heff_2ebuild_2equery_2eatLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eatLine_entry, 2, 0};

V g_heff_2ebuild_2equery_2eatLine(V v_src_240, V v_sp_241) {
top: ;
  V v_t_242 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2equery_2eatLine_str0), heff_dup(v_src_240), MK_INT(0LL)));
  V v_t_243 = (g_heff_2elsp_2erender_2elineColAt(heff_dup(v_src_240), heff_dup(heff_rfield(v_sp_241, 0)), MK_INT(0LL), MK_INT(0LL), v_t_242));
  V v_t_244 = heff_intAdd(heff_get_n(v_t_243, 0, 3), MK_INT(1LL));
  V v_t_245 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2equery_2eatLine_str1), heff_dup(v_src_240), MK_INT(0LL)));
  V v_t_246 = (g_heff_2elsp_2erender_2elineColAt(v_src_240, heff_get_n(v_sp_241, 0, 2), MK_INT(0LL), MK_INT(0LL), v_t_245));
  V v_t_247 = heff_intAdd(heff_get_n(v_t_246, 2, 3), MK_INT(1LL));
  V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2eatLine_str2), heff_intShow(v_t_247));
  return heff_strAppend(heff_intShow(v_t_244), v_t_248);
}
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eatLine(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2eisTypedChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eisTypedChar_entry, 1, 0};

V g_heff_2ebuild_2equery_2eisTypedChar(V v_c_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(v_c_240), MK_INT(95LL)) || (heff_intEq_c(heff_dup(v_c_240), MK_INT(39LL)) || (heff_intEq_c(heff_dup(v_c_240), MK_INT(46LL)) || (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(122LL)) || (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL))))) : (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))))))));
  heff_drop(v_c_240);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2eisTypedChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eisTypedChar(a[0]);
}
Clo g_heff_2ebuild_2equery_2elastDot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elastDot_entry, 2, 0};

V g_heff_2ebuild_2equery_2elastDot(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  } else {
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(46LL))) {
      heff_drop(v_s_240);
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ebuild_2equery_2elastDot_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2elastDot(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str2, 0, "");
Clo g_heff_2ebuild_2equery_2ecompletionDetail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionDetail_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecompletionDetail(V v_c_240, V v_x_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_243 = (g_heff_2eelab_2eglobals_2elookupName(v_t_242, heff_dup(v_x_241)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_g_244 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
    V v_k_245 = heff_strAppend(heff_take_field(v_c_240, 0), heff_strAppend(((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str0), v_x_241));
    V v_t_246 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_245), heff_rfield(v_g_244, 1)));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      V v_t_247 = (g_map_2elookup_24s1546226666x2146984184(v_k_245, heff_rfield(v_g_244, 2)));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_c_240, 13);
        heff_drop_rec(v_g_244, 7);
        return ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str1);
      }
      case TAG_Just: {
        V v_k2_248 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        V v_t_249 = ({ V a_0 = v_k2_248; V b_1 = heff_get_n(v_g_244, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_t_249)) {
        case TAG_Nothing: {
          heff_drop_rec(v_c_240, 13);
          return ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str2);
        }
        case TAG_Just: {
          V v_e_2410 = heff_field(v_t_249, 0);
          heff_take_n(v_t_249, 1ULL, 1);
          V v_t_2411 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
          V v_t_2412 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2410, 3, 4)));
          HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(v_t_2411, v_t_2412);
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_Just: {
      V v_e_2413 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      heff_drop_rec(v_g_244, 7);
      heff_drop(v_k_245);
      V v_t_2414 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
      V v_t_2415 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2413, 3, 4)));
      HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(v_t_2414, v_t_2415);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_Just: {
    V v_e_2416 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_x_241);
    V v_t_2417 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
    V v_t_2418 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2416, 3, 4)));
    HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(v_t_2417, v_t_2418);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2equery_2ecompletionDetail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecompletionDetail(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionOf_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionOf_str1, 1, ".");
Clo g_heff_2ebuild_2equery_2ecompletionOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionOf_entry, 4, 0};

V g_heff_2ebuild_2equery_2ecompletionOf(V v_c_240, V v_typed_241, V v_qualifier_242, V v_x_243) {
top: ;
  V v_t_244 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength(heff_dup(v_typed_241)));
  if (heff_strEq_c(v_t_244, v_typed_241)) {
    if (heff_strEq_c(heff_dup(v_qualifier_242), ((V)&g_heff_2ebuild_2equery_2ecompletionOf_str0))) {
      V v_x3_247 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2equery_2ecompletionOf_str1), heff_dup(v_x_243), MK_INT(0LL)));
      V v_x1_249;
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        v_x1_249 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_247, 0ULL, 1);
        v_x1_249 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_247);
      }
      if ((heff_dup(v_x1_249) == NTAG(TAG_True))) {
        heff_drop(v_c_240);
        heff_drop(v_qualifier_242);
        heff_drop(v_x_243);
        heff_drop(v_x1_249);
        return NTAG(TAG_Nothing);
      } else {
        heff_drop(v_x1_249);
        V v_t_2410 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength(heff_dup(v_qualifier_242)));
        V v_x2_2413;
        if (heff_strEq_c(v_t_2410, heff_dup(v_qualifier_242))) {
          V v_t_2412 = heff_strSlice(heff_dup(v_x_243), heff_strLength(v_qualifier_242), heff_strLength(heff_dup(v_x_243)));
          v_x2_2413 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
        } else {
          heff_drop(v_qualifier_242);
          v_x2_2413 = NTAG(TAG_Nothing);
        }
        V v_t_2415;
        switch (heff_tag_of(v_x2_2413)) {
        case TAG_Nothing: {
          v_t_2415 = heff_dup(v_x_243);
          break;
        }
        case TAG_Just: {
          V v_x_2414 = heff_field(v_x2_2413, 0);
          heff_take_n(v_x2_2413, 1ULL, 1);
          v_t_2415 = v_x_2414;
          break;
        }
        default: heff_nomatch(v_x2_2413);
        }
        V v_t_2416 = (g_heff_2ebuild_2equery_2ecompletionDetail(v_c_240, v_x_243));
        return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_label__detail, (V[]){v_t_2415, v_t_2416})});
      }
    } else {
      V v_t_2417 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength(heff_dup(v_qualifier_242)));
      V v_x2_2420;
      if (heff_strEq_c(v_t_2417, heff_dup(v_qualifier_242))) {
        V v_t_2419 = heff_strSlice(heff_dup(v_x_243), heff_strLength(v_qualifier_242), heff_strLength(heff_dup(v_x_243)));
        v_x2_2420 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2419});
      } else {
        heff_drop(v_qualifier_242);
        v_x2_2420 = NTAG(TAG_Nothing);
      }
      V v_t_2422;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nothing: {
        v_t_2422 = heff_dup(v_x_243);
        break;
      }
      case TAG_Just: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        heff_take_n(v_x2_2420, 1ULL, 1);
        v_t_2422 = v_x_2421;
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      V v_t_2423 = (g_heff_2ebuild_2equery_2ecompletionDetail(v_c_240, v_x_243));
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_label__detail, (V[]){v_t_2422, v_t_2423})});
    }
  } else {
    heff_drop(v_c_240);
    heff_drop(v_qualifier_242);
    heff_drop(v_x_243);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2equery_2ecompletionOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecompletionOf(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2equery_2eprimitiveName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eprimitiveName_entry, 2, 0};

V g_heff_2ebuild_2equery_2eprimitiveName(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLocal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCode: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCons: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIs: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SOpaque: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SAbandon: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SImplicit: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrim: {
    V v_ru_24x2_241_24SPrim = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x2_241_24SPrim, TAG_Just, 1, (V[]){v_k_240});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitString: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitRune: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2equery_2eprimitiveName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eprimitiveName(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str0, 0, "");
V g_heff_2ebuild_2equery_2ecompletionsAt_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2ecompletionsAt_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionsAt_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecompletionsAt(V v_c_240, V v_offset_241) {
top: ;
  V v_t_242 = (g_list_2emap_24s467798769x1763085075(heff_dup(heff_rfield(v_c_240, 7))));
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_244 = ({ V b_0 = heff_get_n(v_t_243, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = (g_list_2emap_24s1415906091x1371825187(v_t_244));
  V v_g_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_2411 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2ecompletionsAt_lam0, 2, 1, (V[]){heff_dup(v_g_246)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get_n(v_g_246, 0, 7); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2412 = (g_list_2emap_24s1996604328x2084368959(v_t_2411));
  V v_t_2413 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2412));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_245, v_t_2413));
  V v_t_2415 = (g_prelude_2e_2b_2b(v_t_242, v_t_2414));
  V v_t_2416 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2415));
  V v_t_2426 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2ecompletionsAt_lam1, 1, 2, (V[]){v_c_240, v_offset_241}), v_t_2416));
  V v_t_2427 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2426));
  return (g_list_2esortBy_24s1223185427x423554351(v_t_2427));
}
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecompletionsAt(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2ecompletionsAt_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_k_248 = args[1];
  V v_g_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = ({ V a_0 = heff_dup(v_k_248); V b_1 = heff_get_n(v_g_246, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    heff_drop(v_k_248);
    return v_acc_247;
  }
  case TAG_Just: {
    V v_e_2410 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_248, v_e_2410}), v_acc_247});
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ebuild_2equery_2ecompletionsAt_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_offset_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = (g_heff_2ebuild_2equery_2etypedFrom(heff_dup(heff_rfield(v_c_240, 3)), heff_dup(v_offset_241)));
  V v_t_2419 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_2418, heff_dup(v_offset_241));
  V v_t_2420 = (g_heff_2ebuild_2equery_2etypedFrom(heff_dup(heff_rfield(v_c_240, 3)), heff_dup(v_offset_241)));
  V v_typed_2421 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_2420, v_offset_241);
  V v_t_2422 = heff_intSub(heff_strLength(heff_dup(v_typed_2421)), MK_INT(1LL));
  V v_t_2423 = (g_heff_2ebuild_2equery_2elastDot(heff_dup(v_typed_2421), v_t_2422));
  V v_t_2425;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Nothing: {
    heff_drop(v_typed_2421);
    v_t_2425 = ((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str0);
    break;
  }
  case TAG_Just: {
    V v_i_2424 = heff_field(v_t_2423, 0);
    heff_take_n(v_t_2423, 1ULL, 1);
    v_t_2425 = heff_strSlice(v_typed_2421, MK_INT(0LL), heff_intAdd(v_i_2424, MK_INT(1LL)));
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  return (g_heff_2ebuild_2equery_2ecompletionOf(v_c_240, v_t_2419, v_t_2425, v_x_2417));
}
Clo g_heff_2ebuild_2equery_2esumTags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esumTags_entry, 1, 0};

V g_heff_2ebuild_2equery_2esumTags(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      return NTAG(TAG_Nil);
    }
    case TAG_EBytes: {
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELam: {
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      V v_alts_2428 = heff_field(v_x11_241, 0);
      V v_t_2429 = (g_list_2emap_24s173442543x1801751270(heff_dup(v_alts_2428)));
      HEFF_LAST return g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2429);
    }
    case TAG_EStruct: {
      return NTAG(TAG_Nil);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2esumTags_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2esumTags(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2edefinesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edefinesGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2edefinesGo(V v_k_240, V v_c_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_k_240);
    heff_drop(v_c_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_os_245 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_k_240);
      heff_drop(v_c_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x41_246 = heff_field(v_x4_243, 0);
      V v_sps_247 = heff_field(v_x4_243, 1);
      switch (heff_tag_of(v_x41_246)) {
      case TAG_MkPair: {
        V v_sp_249 = heff_field(v_x41_246, 1);
        if (heff_strEq_c(heff_dup(heff_rfield(v_o_244, 1)), heff_dup(v_k_240))) {
          heff_drop(v_k_240);
          V v_t_2411 = heff_rec_n(3, shape_c__name__span, (V[]){v_c_241, heff_dup(heff_rfield(v_o_244, 0)), heff_dup(v_sp_249)});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
        } else {
          V t_0 = v_k_240;
          V t_1 = v_c_241;
          V t_2 = v_os_245;
          V t_3 = v_sps_247;
          v_k_240 = t_0;
          v_c_241 = t_1;
          v_x3_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
      }
      default: return heff_nomatch(v_x41_246);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2edefinesGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ebuild_2equery_2edefinesGo(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ebuild_2equery_2edefinitionIn_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2edefinitionIn_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2edefinitionIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edefinitionIn_entry, 3, 0};

V g_heff_2ebuild_2equery_2edefinitionIn(V v_i_240, V v_k_241, V v_d_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_d_242, 0)), 1, 13);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_d_242, 0)), 3, 13);
  V v_c_245 = heff_dup(heff_rfield(v_d_242, 0));
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_245, 4))));
  V v_t_2410 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2edefinitionIn_lam0, 2, 1, (V[]){v_c_245}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_2415 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2edefinitionIn_lam1, 1, 2, (V[]){heff_dup(v_i_240), v_k_241}); V a_1 = v_t_2410; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2419;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    V v_sp_2416 = heff_take_field(v_d_242, 2);
    V v_t_2417 = heff_get_n(heff_get_n(v_d_242, 0, 3), 3, 13);
    v_t_2419 = (g_heff_2ebuild_2equery_2enameInGo(v_t_2417, heff_get_n(v_i_240, 1, 5), heff_dup(v_sp_2416), heff_get_n(v_sp_2416, 0, 2)));
    break;
  }
  case TAG_Just: {
    V v_s_2418 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    heff_drop_rec(v_i_240, 5);
    heff_drop_rec(v_d_242, 3);
    v_t_2419 = heff_get_n(v_s_2418, 2, 3);
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  return heff_rec_n(3, shape_path__source__span, (V[]){v_t_243, v_t_244, v_t_2419});
}
V g_heff_2ebuild_2equery_2edefinitionIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edefinitionIn(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2edefinitionIn_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = (g_heff_2ebuild_2equery_2edeclSites(v_c_245, v_x_248));
  return (g_prelude_2e_2b_2b(v_t_249, v_acc_247));
}
V g_heff_2ebuild_2equery_2edefinitionIn_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_i_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_take_field(v_i_240, 3);
  V v_t_2414;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_i_240, 1, 5)});
    v_t_2414 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_241, v_t_2413, NTAG(TAG_Nothing)});
  } else {
    heff_drop_rec(v_i_240, 5);
    heff_drop(v_t_2412);
    v_t_2414 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_241, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  }
  return (g_heff_2ebuild_2equery_2eeqTarget(heff_get_n(v_s_2411, 0, 3), v_t_2414));
}
V g_heff_2ebuild_2equery_2edefinitionAt_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2edefinitionAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edefinitionAt_entry, 2, 0};

V g_heff_2ebuild_2equery_2edefinitionAt(V v_program_240, V v_off_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_240)));
  V v_t_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_x_243});
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_program_240);
    heff_drop(v_off_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_c_246 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    V v_t_247 = (g_heff_2ebuild_2equery_2einfoAt(v_c_246, v_off_241));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop(v_program_240);
      heff_drop_cell(v_ru_24t_245_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_i_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V v_t_249 = heff_dup(heff_rfield(v_i_248, 2));
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        heff_drop(v_program_240);
        heff_drop_cell(v_ru_24t_245_24Just, 1);
        heff_drop_rec(v_i_248, 5);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_k_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
        V v_t_2414 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2edefinitionAt_lam0, 1, 1, (V[]){heff_dup(v_k_2410)}), v_t_2411));
        V v_x1_2415 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2414));
        switch (heff_tag_of(v_x1_2415)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24t_245_24Just, 1);
          heff_drop_rec(v_i_248, 5);
          heff_drop(v_k_2410);
          return NTAG(TAG_Nothing);
        }
        case TAG_Cons: {
          V v_x_2416 = heff_field(v_x1_2415, 0);
          heff_take_n(v_x1_2415, 1ULL, 2);
          V v_t_2418 = (g_heff_2ebuild_2equery_2edefinitionIn(v_i_248, v_k_2410, v_x_2416));
          return heff_tag_at_n(v_ru_24t_245_24Just, TAG_Just, 1, (V[]){v_t_2418});
        }
        default: return heff_nomatch(v_x1_2415);
        }
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edefinitionAt(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2edefinitionAt_lam0(V self, V *args) {
  V v_c2_2412 = args[0];
  V v_k_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_c2_2412, 5)), 6, 9);
  return ({ V a_0 = v_k_2410; V a_1 = heff_dup(v_c2_2412); V b_2 = heff_get_n(v_c2_2412, 7, 13); V a_3 = v_t_2413; V r_ = (g_heff_2ebuild_2equery_2edefinesGo(a_0, a_1, b_2, a_3)); heff_drop(b_2); heff_drop(v_t_2413); r_; });
}
V g_heff_2ebuild_2equery_2efieldFound_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2efieldFound_lam1(V self, V *args);
V g_heff_2ebuild_2equery_2efieldFound_lam2(V self, V *args);
Clo g_heff_2ebuild_2equery_2efieldFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2efieldFound_entry, 4, 0};

V g_heff_2ebuild_2equery_2efieldFound(V v_program_240, V v_c_241, V v_ls_242, V v_off_243) {
top: ;
  V v_t_247 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2efieldFound_lam0, 1, 1, (V[]){v_off_243}); V b_1 = heff_get_n(v_ls_242, 1, 2); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop_rec(v_c_241, 13);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_f_248 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_241, 4))));
    V v_t_2413 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2efieldFound_lam1, 2, 1, (V[]){v_c_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
    V v_t_2418 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2efieldFound_lam2, 1, 1, (V[]){v_f_248}); V a_1 = v_t_2413; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_t_2413); r_; });
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_247_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_s_2419 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      V v_t_2420 = heff_get_n(v_s_2419, 0, 3);
      V v_t_2421 = heff_dup(heff_rfield(v_t_2420, 1));
      switch (heff_tag_of(v_t_2421)) {
      case TAG_Nothing: {
        V v_t_2422 = (g_heff_2ebuild_2equery_2eownNameOf(v_program_240, heff_dup(heff_rfield(v_t_2420, 0))));
        switch (heff_tag_of(v_t_2422)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24t_247_24Just, 1);
          heff_drop_rec(v_t_2420, 3);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x_2423 = heff_field(v_t_2422, 0);
          heff_take_n(v_t_2422, 1ULL, 1);
          return heff_tag_at_n(v_ru_24t_247_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2420, v_x_2423})});
        }
        default: return heff_nomatch(v_t_2422);
        }
      }
      case TAG_Just: {
        V v_m_2424 = heff_field(v_t_2421, 0);
        heff_take_n(v_t_2421, 1ULL, 1);
        return heff_tag_at_n(v_ru_24t_247_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2420, v_m_2424})});
      }
      default: return heff_nomatch(v_t_2421);
      }
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ebuild_2equery_2efieldFound_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2efieldFound(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2equery_2efieldFound_lam0(V self, V *args) {
  V v_f_244 = args[0];
  V v_off_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_sp_245 = heff_get_n(v_f_244, 2, 3);
  V v_ret_24bool = heff_bool((heff_intLe_c(heff_dup(heff_rfield(v_sp_245, 0)), heff_dup(v_off_243)) && heff_intLe_c(heff_dup(v_off_243), heff_dup(heff_rfield(v_sp_245, 1)))));
  heff_drop(v_off_243);
  heff_drop_rec(v_sp_245, 2);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2efieldFound_lam1(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = (g_heff_2ebuild_2equery_2edeclSites(v_c_241, v_x_2411));
  return (g_prelude_2e_2b_2b(v_t_2412, v_acc_2410));
}
V g_heff_2ebuild_2equery_2efieldFound_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  V v_f_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2415 = heff_get_n(v_s_2414, 2, 3);
  V v_b_2416 = heff_get_n(v_f_248, 1, 3);
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_a_2415, 0)), heff_dup(heff_rfield(v_b_2416, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_a_2415, 1)), heff_dup(heff_rfield(v_b_2416, 1)))));
  heff_drop_rec(v_a_2415, 2);
  heff_drop_rec(v_b_2416, 2);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2eatLocal_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2eatLocal_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2eatLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eatLocal_entry, 2, 0};

V g_heff_2ebuild_2equery_2eatLocal(V v_off_240, V v_l_241) {
top: ;
  V v_sp_242 = heff_take_field(v_l_241, 1);
  if (heff_intLe_c(heff_dup(heff_rfield(v_sp_242, 0)), heff_dup(v_off_240))) {
    if (heff_intLe_c(heff_dup(v_off_240), heff_get_n(v_sp_242, 1, 2))) {
      heff_drop(v_off_240);
      heff_drop_rec(v_l_241, 3);
      return NTAG(TAG_True);
    } else {
      return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eatLocal_lam0, 1, 1, (V[]){v_off_240}); V b_1 = heff_get_n(v_l_241, 2, 3); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    }
  } else {
    heff_drop_rec(v_sp_242, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eatLocal_lam1, 1, 1, (V[]){v_off_240}); V b_1 = heff_get_n(v_l_241, 2, 3); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
}
V g_heff_2ebuild_2equery_2eatLocal_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eatLocal(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2eatLocal_lam0(V self, V *args) {
  V v_sp_245 = args[0];
  V v_off_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ret_24bool = heff_bool((heff_intLe_c(heff_dup(heff_rfield(v_sp_245, 0)), heff_dup(v_off_240)) && heff_intLe_c(heff_dup(v_off_240), heff_dup(heff_rfield(v_sp_245, 1)))));
  heff_drop_rec(v_sp_245, 2);
  heff_drop(v_off_240);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2eatLocal_lam1(V self, V *args) {
  V v_sp_247 = args[0];
  V v_off_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ret_24bool = heff_bool((heff_intLe_c(heff_dup(heff_rfield(v_sp_247, 0)), heff_dup(v_off_240)) && heff_intLe_c(heff_dup(v_off_240), heff_dup(heff_rfield(v_sp_247, 1)))));
  heff_drop_rec(v_sp_247, 2);
  heff_drop(v_off_240);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str2, 1, " ");
Clo g_heff_2ebuild_2equery_2ewordsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordsOf_entry, 4, 0};

V g_heff_2ebuild_2equery_2ewordsOf(V v_base_240, V v_line_241, V v_i_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_line_241)), heff_dup(v_i_242))) {
    heff_drop(v_base_240);
    heff_drop(v_line_241);
    heff_drop(v_i_242);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  } else {
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_line_241), heff_dup(v_i_242)), MK_INT(32LL))) {
      V t_0 = v_base_240;
      V t_1 = v_line_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_acc_243;
      v_base_240 = t_0;
      v_line_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      V v_x2_246 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2equery_2ewordsOf_str0), heff_dup(v_line_241), heff_dup(v_i_242)));
      V v_t_248;
      switch (heff_tag_of(v_x2_246)) {
      case TAG_Nothing: {
        v_t_248 = heff_strLength(heff_dup(v_line_241));
        break;
      }
      case TAG_Just: {
        V v_x_247 = heff_field(v_x2_246, 0);
        heff_take_n(v_x2_246, 1ULL, 1);
        v_t_248 = v_x_247;
        break;
      }
      default: heff_nomatch(v_x2_246);
      }
      V v_x2_249 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2equery_2ewordsOf_str1), heff_dup(v_line_241), heff_dup(v_i_242)));
      V v_t_2411;
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        v_t_2411 = heff_strLength(heff_dup(v_line_241));
        break;
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take_n(v_x2_249, 1ULL, 1);
        v_t_2411 = v_x_2410;
        break;
      }
      default: heff_nomatch(v_x2_249);
      }
      V v_x2_2412 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2equery_2ewordsOf_str2), heff_dup(v_line_241), heff_dup(v_i_242)));
      V v_t_2414;
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nothing: {
        v_t_2414 = heff_strLength(heff_dup(v_line_241));
        break;
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        heff_take_n(v_x2_2412, 1ULL, 1);
        v_t_2414 = v_x_2413;
        break;
      }
      default: heff_nomatch(v_x2_2412);
      }
      V v_e_2415 = heff_intAdd(heff_dup(v_base_240), v_t_2414);
      V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(heff_dup(v_base_240), heff_dup(v_i_242)), v_e_2415});
      V v_t_2417 = heff_rec_n(2, shape_text__span, (V[]){heff_strSlice(heff_dup(v_line_241), v_i_242, v_t_2411), v_t_2416});
      V t_0 = v_base_240;
      V t_1 = v_line_241;
      V t_2 = v_t_248;
      V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_acc_243});
      v_base_240 = t_0;
      v_line_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ebuild_2equery_2ewordsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ewordsOf(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2equery_2ewordsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordsIn_entry, 6, 0};

V g_heff_2ebuild_2equery_2ewordsIn(V v_fits_240, V v_name_241, V v_src_242, V v_i_243, V v_to_244, V v_acc_245) {
top: ;
  V v_t_246 = (g_prelude_2eindexFrom(heff_dup(v_name_241), heff_dup(v_src_242), v_i_243));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_fits_240);
    heff_drop(v_name_241);
    heff_drop(v_src_242);
    heff_drop(v_to_244);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
  }
  case TAG_Just: {
    V v_p_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_t_248 = heff_intAdd(heff_dup(v_p_247), heff_strLength(heff_dup(v_name_241)));
    if (heff_intLe_c(v_t_248, heff_dup(v_to_244))) {
      V v_t_2410 = (g_heff_2ebuild_2equery_2ewordAt(heff_dup(v_src_242), heff_dup(v_p_247), heff_dup(v_name_241)));
      V v_t_2413;
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        V v_t_2411 = heff_tr(heff_call(heff_dup(v_fits_240), 1, (V[]){heff_dup(v_p_247)}));
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_t_2411);
          V v_t_2412 = heff_intAdd(heff_dup(v_p_247), heff_strLength(heff_dup(v_name_241)));
          v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_p_247), v_t_2412}), v_acc_245});
        } else {
          heff_drop(v_t_2411);
          v_t_2413 = v_acc_245;
        }
      } else {
        heff_drop(v_t_2410);
        v_t_2413 = v_acc_245;
      }
      V t_0 = v_fits_240;
      V t_1 = v_name_241;
      V t_2 = v_src_242;
      V t_3 = heff_intAdd(v_p_247, MK_INT(1LL));
      V t_4 = v_to_244;
      V t_5 = v_t_2413;
      v_fits_240 = t_0;
      v_name_241 = t_1;
      v_src_242 = t_2;
      v_i_243 = t_3;
      v_to_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    } else {
      heff_drop(v_fits_240);
      heff_drop(v_name_241);
      heff_drop(v_src_242);
      heff_drop(v_to_244);
      heff_drop(v_p_247);
      return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ebuild_2equery_2ewordsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ewordsIn(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ebuild_2equery_2espacesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2espacesFrom_entry, 2, 0};

V g_heff_2ebuild_2equery_2espacesFrom(V v_src_240, V v_i_241) {
top: ;
  if (heff_intEq_c(heff_strByteAt(heff_dup(v_src_240), heff_dup(v_i_241)), MK_INT(32LL))) {
    V t_0 = v_src_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_src_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    heff_drop(v_src_240);
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2espacesFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2espacesFrom(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2espacesBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2espacesBefore_entry, 2, 0};

V g_heff_2ebuild_2equery_2espacesBefore(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
    V v_t_243 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)));
    if (heff_intEq_c(v_t_243, MK_INT(32LL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_src_240);
      return v_i_241;
    }
  } else {
    heff_drop(v_src_240);
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2espacesBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2espacesBefore(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2efieldUsesOf_lam1(V self, V *args);
V g_heff_2ebuild_2equery_2efieldUsesOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2efieldUsesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2efieldUsesOf_entry, 2, 0};

V g_heff_2ebuild_2equery_2efieldUsesOf(V v_ss_240, V v_ls_241) {
top: ;
  HEFF_LAST return g_list_2emap_24f2063070488x1806431062(heff_clo_n(g_heff_2ebuild_2equery_2efieldUsesOf_lam0, 1, 1, (V[]){heff_dup(v_ss_240)}), heff_get_n(v_ls_241, 1, 2));
}
V g_heff_2ebuild_2equery_2efieldUsesOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2efieldUsesOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2equery_2efieldUsesOf_lam1(V self, V *args) {
  V v_s_243 = args[0];
  V v_f_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_244 = heff_get_n(v_s_243, 2, 3);
  V v_b_245 = heff_get_n(v_f_242, 1, 3);
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_a_244, 0)), heff_dup(heff_rfield(v_b_245, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_a_244, 1)), heff_dup(heff_rfield(v_b_245, 1)))));
  heff_drop_rec(v_a_244, 2);
  heff_drop_rec(v_b_245, 2);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2efieldUsesOf_lam0(V self, V *args) {
  V v_f_242 = args[0];
  V v_ss_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2efieldUsesOf_lam1, 1, 1, (V[]){v_f_242}); V a_1 = v_ss_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_ss_240); r_; });
}
HEFF_LIT(g_heff_2ebuild_2equery_2emoreIn_str0, 1, "\012");
V g_heff_2ebuild_2equery_2emoreIn_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2emoreIn_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2emoreIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2emoreIn_entry, 3, 0};

V g_heff_2ebuild_2equery_2emoreIn(V v_t_240, V v_name_241, V v_c_242) {
top: ;
  V v_x1_243 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt(heff_dup(v_name_241), MK_INT(0LL))));
  V v_t_246;
  if ((heff_dup(v_x1_243) == NTAG(TAG_True))) {
    heff_drop(v_x1_243);
    v_t_246 = NTAG(TAG_False);
  } else {
    heff_drop(v_x1_243);
    V v_t_244 = heff_dup(heff_rfield(v_t_240, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      v_t_246 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_246 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
  }
  V v_t_2421;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_src_247 = heff_dup(heff_rfield(v_c_242, 3));
    V v_t_248 = heff_intSub(heff_strLength(heff_dup(v_src_247)), MK_INT(1LL));
    V v_t_2412 = (g_list_2efoldl_24f1715293669x1931437372(NTAG(TAG_Nil), heff_clo_n(g_heff_2ebuild_2equery_2emoreIn_lam0, 1, 1, (V[]){v_src_247}), MK_INT(0LL), v_t_248));
    v_t_2421 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2emoreIn_lam1, 2, 2, (V[]){heff_dup(v_c_242), heff_dup(v_name_241)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2412; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
  } else {
    heff_drop(v_t_246);
    v_t_2421 = NTAG(TAG_Nil);
  }
  V v_x1_2422 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt(heff_dup(v_name_241), MK_INT(0LL))));
  V v_t_2423;
  if ((heff_dup(v_x1_2422) == NTAG(TAG_True))) {
    heff_drop(v_x1_2422);
    v_t_2423 = (g_heff_2ebuild_2equery_2eexpectedIn(v_t_240, v_name_241, v_c_242));
  } else {
    heff_drop_rec(v_t_240, 3);
    heff_drop(v_name_241);
    heff_drop_rec(v_c_242, 13);
    heff_drop(v_x1_2422);
    v_t_2423 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_2421, v_t_2423));
}
V g_heff_2ebuild_2equery_2emoreIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2emoreIn(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2emoreIn_lam0(V self, V *args) {
  V v_p_249 = args[0];
  V v_src_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(v_p_249), MK_INT(0LL)) || ({ V v_t_2411 = heff_strByteAt(heff_dup(v_src_247), heff_intSub(heff_dup(v_p_249), MK_INT(1LL))); int c_ = heff_intEq_c(heff_dup(v_t_2411), MK_INT(10LL)); heff_drop(v_t_2411); c_; })));
  heff_drop(v_p_249);
  heff_drop(v_src_247);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2emoreIn_lam1(V self, V *args) {
  V v_acc_2413 = args[0];
  V v_x_2414 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_name_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_src_2415 = heff_get_n(v_c_242, 3, 13);
  V v_x2_2416 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2equery_2emoreIn_str0), heff_dup(v_src_2415), heff_dup(v_x_2414)));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nothing: {
    v_t_2418 = heff_strLength(heff_dup(v_src_2415));
    break;
  }
  case TAG_Just: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    heff_take_n(v_x2_2416, 1ULL, 1);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  V v_t_2419 = (g_heff_2ebuild_2equery_2ewordsOf(heff_dup(v_x_2414), heff_strSlice(v_src_2415, v_x_2414, v_t_2418), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2420 = (g_heff_2ebuild_2equery_2efixityWords(v_name_241, v_t_2419));
  return (g_prelude_2e_2b_2b(v_t_2420, v_acc_2413));
}
V g_heff_2ebuild_2equery_2elocalOccurrences_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2elocalOccurrences_lam1(V self, V *args);
V g_heff_2ebuild_2equery_2elocalOccurrences_lam2(V self, V *args);
Clo g_heff_2ebuild_2equery_2elocalOccurrences_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalOccurrences_entry, 2, 0};

V g_heff_2ebuild_2equery_2elocalOccurrences(V v_c_240, V v_b_241) {
top: ;
  V v_found_242 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_c_240, 4)));
  V v_t_243 = (g_list_2efilter_24s2018073091x1385246979(heff_dup(heff_rfield(v_found_242, 0))));
  V v_t_245 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2elocalOccurrences_lam0, 1, 1, (V[]){heff_dup(v_found_242)}), v_t_243));
  V v_t_246 = (g_list_2emap_24f1133029339x682401273(heff_get_n(v_found_242, 1, 2)));
  V v_t_247 = heff_get_n(heff_rec_n(2, shape_locals__fields, (V[]){v_t_245, v_t_246}), 0, 2);
  V v_t_2411 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2elocalOccurrences_lam1, 1, 1, (V[]){heff_dup(v_b_241)}); V a_1 = v_t_247; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_t_247); r_; });
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    heff_drop_rec(v_c_240, 13);
    heff_drop_rec(v_b_241, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_l_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 1);
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_l_2412, 1), heff_get_n(v_l_2412, 2, 3)});
    V v_t_2414 = (g_list_2esortBy_24s1768199906x1695529242(v_t_2413));
    HEFF_LAST return g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2elocalOccurrences_lam2, 1, 2, (V[]){v_b_241, v_c_240}), v_t_2414);
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2ebuild_2equery_2elocalOccurrences_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2elocalOccurrences(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2elocalOccurrences_lam0(V self, V *args) {
  V v_b_244 = args[0];
  V v_found_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2elocals_2emkLocal(heff_get_n(v_found_242, 1, 2), v_b_244));
}
V g_heff_2ebuild_2equery_2elocalOccurrences_lam1(V self, V *args) {
  V v_l_248 = args[0];
  V v_b_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_249 = heff_get_n(v_l_248, 1, 3);
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_a_249, 0)), heff_dup(heff_rfield(v_b_241, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_a_249, 1)), heff_dup(heff_rfield(v_b_241, 1)))));
  heff_drop_rec(v_b_241, 2);
  heff_drop_rec(v_a_249, 2);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2elocalOccurrences_lam2(V self, V *args) {
  V v_sp_2415 = args[0];
  V v_b_241 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_defines_2417 = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_sp_2415, 0)), heff_dup(heff_rfield(v_b_241, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_sp_2415, 1)), heff_dup(heff_rfield(v_b_241, 1)))));
  heff_drop_rec(v_b_241, 2);
  return heff_rec_n(4, shape_path__source__span__defines, (V[]){heff_dup(heff_rfield(v_c_240, 1)), heff_get_n(v_c_240, 3, 13), v_sp_2415, v_defines_2417});
}
Clo g_heff_2ebuild_2equery_2enameClass_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enameClass_entry, 1, 0};

V g_heff_2ebuild_2equery_2enameClass(V v_x_240) {
top: ;
  if (heff_intEq_c(heff_strLength(heff_dup(v_x_240)), MK_INT(0LL))) {
    heff_drop(v_x_240);
    return MK_INT(0LL);
  } else {
    V v_t_243 = heff_bool((heff_intLe_c(MK_INT(65LL), heff_strByteAt(heff_dup(v_x_240), MK_INT(0LL))) && heff_intLe_c(heff_strByteAt(heff_dup(v_x_240), MK_INT(0LL)), MK_INT(90LL))));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_t_244 = (g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(v_x_240, MK_INT(0LL)));
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop(v_t_244);
        return MK_INT(1LL);
      } else {
        heff_drop(v_t_244);
        return MK_INT(0LL);
      }
    } else {
      heff_drop(v_t_243);
      if (heff_intEq_c(heff_strByteAt(heff_dup(v_x_240), MK_INT(0LL)), MK_INT(95LL))) {
        V v_t_246 = (g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(v_x_240, MK_INT(0LL)));
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          return MK_INT(2LL);
        } else {
          heff_drop(v_t_246);
          return MK_INT(0LL);
        }
      } else {
        if (heff_intLe_c(MK_INT(97LL), heff_strByteAt(heff_dup(v_x_240), MK_INT(0LL)))) {
          if (heff_intLe_c(heff_strByteAt(heff_dup(v_x_240), MK_INT(0LL)), MK_INT(122LL))) {
            V v_t_249 = (g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(v_x_240, MK_INT(0LL)));
            if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
              heff_drop(v_t_249);
              return MK_INT(2LL);
            } else {
              heff_drop(v_t_249);
              return MK_INT(0LL);
            }
          } else {
            V v_t_2410 = (g_heff_2ebuild_2equery_2eallChars_24s624343939x922214358(MK_INT(47LL), v_x_240, MK_INT(0LL)));
            if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
              heff_drop(v_t_2410);
              return MK_INT(3LL);
            } else {
              heff_drop(v_t_2410);
              return MK_INT(0LL);
            }
          }
        } else {
          V v_t_2411 = (g_heff_2ebuild_2equery_2eallChars_24s624343939x922214358(MK_INT(47LL), v_x_240, MK_INT(0LL)));
          if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
            heff_drop(v_t_2411);
            return MK_INT(3LL);
          } else {
            heff_drop(v_t_2411);
            return MK_INT(0LL);
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2equery_2enameClass_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2enameClass(a[0]);
}
Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry, 1, 0};

V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      return NTAG(TAG_Nil);
    }
    case TAG_EBytes: {
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      V v_h_2412 = heff_field(v_x21_241, 0);
      V v_args_2413 = heff_field(v_x21_241, 1);
      V v_t_2414 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_h_2412));
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2413)));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s2134067310x2049132013(a_0, a_1)); heff_drop(v_t_2415); r_; });
      return (g_prelude_2e_2b_2b(v_t_2414, v_t_2416));
    }
    case TAG_EProject: {
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      V v_e_2419 = heff_field(v_x21_241, 1);
      V t_0 = v_e_2419;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EPi: {
      V v_b_2420 = heff_field(v_x21_241, 0);
      V v_cod_2421 = heff_field(v_x21_241, 1);
      V v_t_2438;
      switch (heff_tag_of(v_b_2420)) {
      case TAG_PiNamed: {
        V v_t_2424 = heff_field(v_b_2420, 2);
        v_t_2438 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2424));
        break;
      }
      case TAG_PiImplicit: {
        V v_t_2428 = heff_field(v_b_2420, 3);
        V v_d_2429 = heff_field(v_b_2420, 4);
        V v_t_2430 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2428));
        V v_t_2432;
        switch (heff_tag_of(v_d_2429)) {
        case TAG_Nothing: {
          v_t_2432 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x_2431 = heff_field(v_d_2429, 0);
          v_t_2432 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_x_2431));
          break;
        }
        default: heff_nomatch(v_d_2429);
        }
        v_t_2438 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2432));
        break;
      }
      case TAG_PiInstance: {
        V v_t_2436 = heff_field(v_b_2420, 3);
        v_t_2438 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2436));
        break;
      }
      case TAG_PiAnon: {
        V v_t_2437 = heff_field(v_b_2420, 0);
        v_t_2438 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2437));
        break;
      }
      default: heff_nomatch(v_b_2420);
      }
      V v_t_2439 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_cod_2421));
      return (g_prelude_2e_2b_2b(v_t_2438, v_t_2439));
    }
    case TAG_ELam: {
      V v_b_2440 = heff_field(v_x21_241, 0);
      V v_body_2441 = heff_field(v_x21_241, 1);
      V v_t_2449;
      switch (heff_tag_of(v_b_2440)) {
      case TAG_LamName: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LamImplicit: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LamAnn: {
        V v_t_2448 = heff_field(v_b_2440, 2);
        v_t_2449 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2448));
        break;
      }
      default: heff_nomatch(v_b_2440);
      }
      V v_t_2450 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_body_2441));
      return (g_prelude_2e_2b_2b(v_t_2449, v_t_2450));
    }
    case TAG_EAnn: {
      V v_e_2451 = heff_field(v_x21_241, 0);
      V v_t_2452 = heff_field(v_x21_241, 1);
      V v_t_2453 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2451));
      V v_t_2454 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2452));
      return (g_prelude_2e_2b_2b(v_t_2453, v_t_2454));
    }
    case TAG_ESpec: {
      V v_acc_2455 = heff_field(v_x21_241, 0);
      V v_v_2458 = heff_field(v_x21_241, 3);
      V v_t_2459 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_acc_2455));
      V v_t_2460 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_v_2458));
      return (g_prelude_2e_2b_2b(v_t_2459, v_t_2460));
    }
    case TAG_ESig: {
      V v_fs_2461 = heff_field(v_x21_241, 0);
      V v_t_2462 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2461)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2462; V r_ = (g_list_2efoldl_24s1777318809x1106245647(a_0, a_1)); heff_drop(v_t_2462); r_; });
    }
    case TAG_ESum: {
      V v_vs_2463 = heff_field(v_x21_241, 0);
      V v_t_2464 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_2463)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2464; V r_ = (g_list_2efoldl_24s491084544x100802329(a_0, a_1)); heff_drop(v_t_2464); r_; });
    }
    case TAG_EStruct: {
      V v_fs_2465 = heff_field(v_x21_241, 0);
      V v_t_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2465)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2466; V r_ = (g_list_2efoldl_24s189033563x26633104(a_0, a_1)); heff_drop(v_t_2466); r_; });
    }
    case TAG_EUpdate: {
      V v_a_2467 = heff_field(v_x21_241, 0);
      V v_fs_2468 = heff_field(v_x21_241, 1);
      V v_t_2469 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2467));
      V v_t_2470 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2468)));
      V v_t_2471 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2470; V r_ = (g_list_2efoldl_24s1026998256x1634433314(a_0, a_1)); heff_drop(v_t_2470); r_; });
      return (g_prelude_2e_2b_2b(v_t_2469, v_t_2471));
    }
    case TAG_EMatch: {
      V v_s_2472 = heff_field(v_x21_241, 0);
      V v_alts_2473 = heff_field(v_x21_241, 1);
      V v_t_2474 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_s_2472));
      V v_t_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_alts_2473)));
      V v_t_2476 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2475; V r_ = (g_list_2efoldl_24s302194196x751324068(a_0, a_1)); heff_drop(v_t_2475); r_; });
      return (g_prelude_2e_2b_2b(v_t_2474, v_t_2476));
    }
    case TAG_ELetIn: {
      V v_rhs_2477 = heff_field(v_x21_241, 0);
      V v_x212_2478 = heff_field(v_x21_241, 1);
      switch (heff_tag_of(v_x212_2478)) {
      case TAG_At: {
        V v_x2121_2479 = heff_field(v_x212_2478, 0);
        switch (heff_tag_of(v_x2121_2479)) {
        case TAG_MkAlt: {
          V v_e_2482 = heff_field(v_x2121_2479, 1);
          V v_t_2483 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_rhs_2477));
          V v_t_2484 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2482));
          return (g_prelude_2e_2b_2b(v_t_2483, v_t_2484));
        }
        default: return heff_nomatch(v_x2121_2479);
        }
      }
      default: return heff_nomatch(v_x212_2478);
      }
    }
    case TAG_EDo: {
      V v_stmts_2485 = heff_field(v_x21_241, 0);
      V v_t_2486 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stmts_2485)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2486; V r_ = (g_list_2efoldl_24s1620243413x998711352(a_0, a_1)); heff_drop(v_t_2486); r_; });
    }
    case TAG_ELocal: {
      V v_b_2487 = heff_field(v_x21_241, 0);
      V v_defs_2488 = heff_field(v_x21_241, 1);
      V v_t_2489 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_defs_2488)));
      V v_t_2490 = (g_list_2efoldl_24s1106937552x2116104854(MK_INT(12LL), NTAG(TAG_Nil), v_t_2489));
      V v_t_2491 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_b_2487));
      V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_defs_2488)));
      V v_t_2493 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2492; V r_ = (g_list_2efoldl_24s54159557x1528472185(a_0, a_1)); heff_drop(v_t_2492); r_; });
      V v_t_2494 = (g_prelude_2e_2b_2b(v_t_2491, v_t_2493));
      return (g_prelude_2e_2b_2b(v_t_2490, v_t_2494));
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2esymbolsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry, 5, 0};

V g_heff_2ebuild_2equery_2esymbolsGo_24dps(V v_c_240, V v_ss_241, V v_x3_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_ss_241);
    heff_drop(v_x4_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x3_242, 0);
    V v_os_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop(v_ss_241);
      heff_drop(v_o_245);
      heff_drop(v_os_246);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x41_247 = heff_field(v_x4_243, 0);
      V v_sps_248 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_247)) {
      case TAG_MkPair: {
        V v_sp_2410 = heff_field(v_x41_247, 1);
        heff_take_n(v_x41_247, 2ULL, 2);
        V v_t_2415 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2equery_2esymbolsGo_24dps_lam0, 1, 1, (V[]){heff_dup(v_sp_2410)}), heff_dup(v_ss_241)));
        V v_t_2416 = (g_heff_2ebuild_2equery_2esymbolWith(heff_dup(v_c_240), v_o_245, v_sp_2410, v_t_2415));
        V v_cell_2417 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
        V v_u_2418 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2417));
        heff_drop(v_u_2418);
        V t_0 = v_c_240;
        V t_1 = v_ss_241;
        V t_2 = v_os_246;
        V t_3 = v_sps_248;
        V t_4 = v_cell_2417;
        v_c_240 = t_0;
        v_ss_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
      default: return heff_nomatch(v_x41_247);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbolsGo_24dps(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_lam0(V self, V *args) {
  V v_s_2411 = args[0];
  V v_sp_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_s_2411, 2)), 0, 2);
  V v_ret_24bool = heff_bool((heff_intLe_c(heff_dup(heff_rfield(v_sp_2410, 0)), heff_dup(v_t_2412)) && ({ V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_s_2411, 2)), 1, 2); int c_ = heff_intLe_c(heff_dup(v_t_2414), heff_dup(heff_rfield(v_sp_2410, 1))); heff_drop(v_t_2414); c_; })));
  heff_drop_rec(v_s_2411, 3);
  heff_drop_rec(v_sp_2410, 2);
  heff_drop(v_t_2412);
  return v_ret_24bool;
}