// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkTry 8097
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define LBL_aliases 1464806715
#define LBL_c 317
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_decls 296817955
#define LBL_detail 611917692
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_expecting 1746726246
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_key 315609
#define LBL_label 304085774
#define LBL_line 9817275
#define LBL_local 304503685
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_type_5f 312202367
static uint32_t shape_c__name__span[] = {LBL_c, LBL_name, LBL_span};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_label__detail[] = {LBL_label, LBL_detail};
static uint32_t shape_out__code__expecting[] = {LBL_out, LBL_code, LBL_expecting};
static uint32_t shape_path__source__span[] = {LBL_path, LBL_source, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name[] = {LBL_target, LBL_name};
static uint32_t shape_text__span[] = {LBL_text, LBL_span};
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eshowTySx(V, V);
V g_heff_2ebuild_2edriver_2eshowTySx_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eshowTySx_clo;
V g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292(V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_clo;
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(V, V);
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_clo;
V g_heff_2ebuild_2equery_2eatLine(V, V);
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eatLine_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(V, V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2ecompletionDetail(V, V);
V g_heff_2ebuild_2equery_2ecompletionDetail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionDetail_clo;
V g_heff_2ebuild_2equery_2ecompletionOf(V, V, V, V);
V g_heff_2ebuild_2equery_2ecompletionOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionOf_clo;
V g_heff_2ebuild_2equery_2ecompletionsAt(V, V);
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo;
V g_heff_2ebuild_2equery_2edeclSites(V, V);
V g_heff_2ebuild_2equery_2edeclSites_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edeclSites_clo;
V g_heff_2ebuild_2equery_2edefinesGo(V, V, V, V);
V g_heff_2ebuild_2equery_2edefinesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinesGo_clo;
HeffT2 g_heff_2ebuild_2equery_2edefinitionAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2edefinitionIn(V, V, V);
V g_heff_2ebuild_2equery_2edefinitionIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionIn_clo;
V g_heff_2ebuild_2equery_2edocAt(V, V);
V g_heff_2ebuild_2equery_2edocAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocAt_clo;
V g_heff_2ebuild_2equery_2edocMarkdownIn(V, V);
V g_heff_2ebuild_2equery_2edocMarkdownIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdownIn_clo;
V g_heff_2ebuild_2equery_2eeqTarget(V, V);
V g_heff_2ebuild_2equery_2eeqTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eeqTarget_clo;
V g_heff_2ebuild_2equery_2eexpectedIn(V, V, V);
V g_heff_2ebuild_2equery_2eexpectedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexpectedIn_clo;
V g_heff_2ebuild_2equery_2efixityLine(V, V, V);
V g_heff_2ebuild_2equery_2efixityLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2efixityLine_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
HeffT2 g_heff_2ebuild_2equery_2elastDot_24cpr(V, V);
V g_heff_2ebuild_2equery_2elastPart(V, V);
V g_heff_2ebuild_2equery_2elastPart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elastPart_clo;
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ebuild_2equery_2emoreIn(V, V, V);
V g_heff_2ebuild_2equery_2emoreIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2emoreIn_clo;
V g_heff_2ebuild_2equery_2enameClass(V);
V g_heff_2ebuild_2equery_2enameClass_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameClass_clo;
V g_heff_2ebuild_2equery_2enameInGo(V, V, V, V);
V g_heff_2ebuild_2equery_2enameInGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameInGo_clo;
V g_heff_2ebuild_2equery_2enubByStart(V);
V g_heff_2ebuild_2equery_2enubByStart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enubByStart_clo;
V g_heff_2ebuild_2equery_2enubByStart_24dps(V, V);
V g_heff_2ebuild_2equery_2enubByStart_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enubByStart_24dps_clo;
HeffT2 g_heff_2ebuild_2equery_2eownNameOf_24cpr(V, V);
HeffT2 g_heff_2ebuild_2equery_2esiteFound_24cpr(V, V, V);
V g_heff_2ebuild_2equery_2espacesBefore(V, V);
V g_heff_2ebuild_2equery_2espacesBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesBefore_clo;
V g_heff_2ebuild_2equery_2espacesFrom(V, V);
V g_heff_2ebuild_2equery_2espacesFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesFrom_clo;
V g_heff_2ebuild_2equery_2estartsStatement(V, V, V);
V g_heff_2ebuild_2equery_2estartsStatement_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2estartsStatement_clo;
V g_heff_2ebuild_2equery_2estmtChildren_24s810860270x338158667(V);
V g_heff_2ebuild_2equery_2estmtChildren_24s810860270x338158667_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2estmtChildren_24s810860270x338158667_clo;
V g_heff_2ebuild_2equery_2esumTags(V);
V g_heff_2ebuild_2equery_2esumTags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esumTags_clo;
V g_heff_2ebuild_2equery_2esymbolWith(V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolWith_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolWith_clo;
V g_heff_2ebuild_2equery_2esymbolsGo_24dps(V, V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolsGo_24dps_clo;
V g_heff_2ebuild_2equery_2etypedFrom(V, V);
V g_heff_2ebuild_2equery_2etypedFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etypedFrom_clo;
V g_heff_2ebuild_2equery_2ewordAt(V, V, V);
V g_heff_2ebuild_2equery_2ewordAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordAt_clo;
V g_heff_2ebuild_2equery_2ewordsIn(V, V, V, V, V, V);
V g_heff_2ebuild_2equery_2ewordsIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordsIn_clo;
V g_heff_2ebuild_2equery_2ewordsOf(V, V, V, V);
V g_heff_2ebuild_2equery_2ewordsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordsOf_clo;
HeffT2 g_heff_2eelab_2eglobals_2elookupKey_24cpr(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s845102114x2128838930_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f2080327479x1330764413(V, V, V, V, V, V, V);
V g_list_2efoldl_24f2080327479x1330764413_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2080327479x1330764413_clo;
V g_list_2efoldl_24s1026998256x1634433314(V, V);
V g_list_2efoldl_24s1026998256x1634433314_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1026998256x1634433314_clo;
V g_list_2efoldl_24s1113296953x161795409(V, V);
V g_list_2efoldl_24s1113296953x161795409_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1113296953x161795409_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1516272141x1201056882(V, V, V);
V g_list_2efoldl_24s1516272141x1201056882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1516272141x1201056882_clo;
V g_list_2efoldl_24s1777318809x1106245647(V, V);
V g_list_2efoldl_24s1777318809x1106245647_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1777318809x1106245647_clo;
V g_list_2efoldl_24s189033563x26633104(V, V);
V g_list_2efoldl_24s189033563x26633104_entry(V self, V *a);
extern Clo g_list_2efoldl_24s189033563x26633104_clo;
V g_list_2efoldl_24s2134067310x2049132013(V, V);
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2134067310x2049132013_clo;
V g_list_2efoldl_24s302194196x751324068(V, V);
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a);
extern Clo g_list_2efoldl_24s302194196x751324068_clo;
V g_list_2efoldl_24s491084544x100802329(V, V);
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s491084544x100802329_clo;
V g_list_2efoldl_24s54159557x1528472185(V, V);
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s54159557x1528472185_clo;
V g_list_2efoldl_24s673493459x989016999(V, V, V);
V g_list_2efoldl_24s673493459x989016999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s673493459x989016999_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s2015972532x1874881274(V, V);
V g_list_2ekeepIf_24s2015972532x1874881274_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2015972532x1874881274_clo;
V g_list_2ekeepIf_24s257286374x378693326(V, V);
V g_list_2ekeepIf_24s257286374x378693326_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s257286374x378693326_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1721231741x1085491812(V);
V g_list_2emap_24s1721231741x1085491812_entry(V self, V *a);
extern Clo g_list_2emap_24s1721231741x1085491812_clo;
V g_list_2emap_24s173442543x1801751270(V);
V g_list_2emap_24s173442543x1801751270_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2esortBy_24s1119089913x1963956854(V);
V g_list_2esortBy_24s1119089913x1963956854_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1119089913x1963956854_clo;
V g_list_2esortBy_24s1993185874x500694228(V);
V g_list_2esortBy_24s1993185874x500694228_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1993185874x500694228_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2enameInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enameInGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2enameInGo(V v_src_240, V v_x_241, V v_sp_242, V v_from_243) {
top: ;
  V v_j_244 = heff_strFind_lent(v_x_241, v_src_240, v_from_243, 4);
  if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
    heff_drop(v_j_244);
    return v_sp_242;
  } else {
    V v_t_245 = heff_intAdd(heff_dup(v_j_244), heff_strLength_lent(v_x_241, 0));
    if (heff_intLe_c(v_t_245, heff_dup(heff_rfield(v_sp_242, 1)))) {
      V v_t_246 = (g_heff_2ebuild_2equery_2ewordAt(v_src_240, heff_dup(v_j_244), v_x_241));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop_rec(v_sp_242, 2);
        heff_drop(v_t_246);
        V v_t_247 = heff_intAdd(heff_dup(v_j_244), heff_strLength_lent(v_x_241, 0));
        return heff_rec_n(2, shape_start__end, (V[]){v_j_244, v_t_247});
      } else {
        heff_drop(v_t_246);
        V t_0 = v_src_240;
        V t_1 = v_x_241;
        V t_2 = v_sp_242;
        V t_3 = heff_intAdd(v_j_244, MK_INT(1LL));
        v_src_240 = t_0;
        v_x_241 = t_1;
        v_sp_242 = t_2;
        v_from_243 = t_3;
        goto top;
      }
    } else {
      heff_drop(v_j_244);
      return v_sp_242;
    }
  }
}
V g_heff_2ebuild_2equery_2enameInGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2equery_2enameInGo(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2equery_2enubByStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enubByStart_entry, 1, 0};

V g_heff_2ebuild_2equery_2enubByStart(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = (g_list_2ekeepIf_24s2015972532x1874881274(v_x_241, v_xs_242));
    V v_u_245 = (g_heff_2ebuild_2equery_2enubByStart_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2enubByStart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2enubByStart(a[0]);
}
Clo g_heff_2ebuild_2equery_2enubByStart_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enubByStart_24dps_entry, 2, 0};

V g_heff_2ebuild_2equery_2enubByStart_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2ekeepIf_24s2015972532x1874881274(v_x_242, v_xs_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2enubByStart_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2enubByStart_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str2, 1, ":");
Clo g_heff_2ebuild_2equery_2eatLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eatLine_entry, 2, 0};

V g_heff_2ebuild_2equery_2eatLine(V v_src_240, V v_sp_241) {
top: ;
  V v_j_242 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2eatLine_str0), v_src_240, MK_INT(0LL), 5);
  V v_t_243;
  if (heff_intLt_c_lent(v_j_242, MK_INT(0LL), 2)) {
    heff_drop(v_j_242);
    v_t_243 = NTAG(TAG_Nothing);
  } else {
    v_t_243 = heff_tag_n(TAG_Just, 1, (V[]){v_j_242});
  }
  V v_t_244 = (g_heff_2elsp_2erender_2elineColAt(v_src_240, heff_dup(heff_rfield(v_sp_241, 0)), MK_INT(0LL), MK_INT(0LL), v_t_243));
  V v_t_245 = heff_intAdd(heff_get_n(v_t_244, 0, 3), MK_INT(1LL));
  V v_j_246 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2eatLine_str1), v_src_240, MK_INT(0LL), 5);
  V v_t_247;
  if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
    heff_drop(v_j_246);
    v_t_247 = NTAG(TAG_Nothing);
  } else {
    v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){v_j_246});
  }
  V v_t_248 = (g_heff_2elsp_2erender_2elineColAt(v_src_240, heff_get_n(v_sp_241, 0, 2), MK_INT(0LL), MK_INT(0LL), v_t_247));
  V v_t_249 = heff_intAdd(heff_get_n(v_t_248, 2, 3), MK_INT(1LL));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2eatLine_str2), heff_intShow(v_t_249));
  return heff_strAppend(heff_intShow(v_t_245), v_t_2410);
}
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2eatLine(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2elastPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elastPart_entry, 2, 0};

V g_heff_2ebuild_2equery_2elastPart(V v_x_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((v_i_241 <= ((int64_t)0ULL))) {
    return v_x_240;
  } else {
    V v_t_242 = heff_strByteAt_lent(v_x_240, heff_box_word((v_i_241 - ((int64_t)1ULL))), 2);
    if ((heff_unbox_word(v_t_242) == ((int64_t)46ULL))) {
      return heff_strSlice(heff_dup(v_x_240), heff_box_word(v_i_241), heff_strLength(v_x_240));
    } else {
      V t_0 = v_x_240;
      int64_t t_1 = (v_i_241 - ((int64_t)1ULL));
      v_x_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ebuild_2equery_2elastPart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2elastPart(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2einfoAt_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V v_c_240, V v_off_241) {
top: ;
  V v_source_242 = heff_take_field(v_c_240, 3);
  V v_top_243 = heff_get_n(v_c_240, 5, 14);
  V v_t_2413 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2equery_2einfoAt_24cpr_lam0, 1, 2, (V[]){v_off_241, v_source_242}), heff_get_n(v_top_243, 7, 9)));
  V v_x1_2414 = (g_list_2esortBy_24s1993185874x500694228(v_t_2413));
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x1_2414, 0);
    heff_take_n(v_x1_2414, 1ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2415}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2414)}});
  }
}
V g_heff_2ebuild_2equery_2einfoAt_24cpr_lam0(V self, V *args) {
  V v_i_244 = args[0];
  V v_off_241 = heff_env(self)[0];
  V v_source_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_span_245 = heff_take_field(v_i_244, 0);
  V v_name_246 = heff_take_field(v_i_244, 1);
  V v_key_247 = heff_get_n(v_i_244, 2, 5);
  V v_t_248 = heff_intSub(heff_dup(heff_rfield(v_span_245, 1)), heff_dup(heff_rfield(v_span_245, 0)));
  V v_t_249 = heff_intAdd(heff_strLength_lent(v_name_246, 0), MK_INT(1LL));
  if (heff_intLe_c(v_t_248, v_t_249)) {
    if (heff_intLe_c(heff_dup(heff_rfield(v_span_245, 0)), heff_dup(v_off_241))) {
      if (heff_intLe_c(v_off_241, heff_dup(heff_rfield(v_span_245, 1)))) {
        switch (heff_tag_of(v_key_247)) {
        case TAG_Nothing: {
          heff_drop(v_source_242);
          heff_drop_rec(v_span_245, 2);
          heff_drop(v_name_246);
          return NTAG(TAG_True);
        }
        case TAG_Just: {
          heff_take_n(v_key_247, 0ULL, 1);
          V v_needle_2411 = (g_heff_2ebuild_2equery_2elastPart(heff_dup(v_name_246), heff_strLength(v_name_246)));
          V v_t_2412 = heff_strSlice(v_source_242, heff_take_field(v_span_245, 0), heff_get_n(v_span_245, 1, 2));
          V v_ret_24bool = heff_bool(heff_intLe_c(MK_INT(0LL), heff_strFind_lent(v_needle_2411, v_t_2412, MK_INT(0LL), 4)));
          heff_drop(v_needle_2411);
          heff_drop(v_t_2412);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_key_247);
        }
      } else {
        heff_drop(v_source_242);
        heff_drop_rec(v_span_245, 2);
        heff_drop(v_name_246);
        heff_drop(v_key_247);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_off_241);
      heff_drop(v_source_242);
      heff_drop_rec(v_span_245, 2);
      heff_drop(v_name_246);
      heff_drop(v_key_247);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_off_241);
    heff_drop(v_source_242);
    heff_drop_rec(v_span_245, 2);
    heff_drop(v_name_246);
    heff_drop(v_key_247);
    return NTAG(TAG_False);
  }
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str2, 0, "");
Clo g_heff_2ebuild_2equery_2ecompletionDetail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionDetail_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecompletionDetail(V v_c_240, V v_x_241) {
top: ;
  V v_top_242 = heff_take_field(v_c_240, 5);
  V v_module_243 = heff_get_n(v_c_240, 0, 14);
  HeffT2 v_t_244 = (g_heff_2eelab_2eglobals_2elookupKey_24cpr(heff_dup(heff_rfield(v_top_242, 0)), heff_dup(v_x_241)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_x_241);
      heff_drop(v_module_243);
      V v_it1_247 = v_field_246;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_MkPair: {
        V v_e_249 = heff_field(v_it1_247, 1);
        heff_take_n(v_it1_247, 2ULL, 2);
        V v_t_2410 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_249, 3, 4)));
        HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(heff_get_n(v_top_242, 0, 9), v_t_2410);
      }
      default: return heff_nomatch(v_it1_247);
      }
    } else {
      heff_drop(v_field_246);
      V v_g_2411 = heff_dup(heff_rfield(v_top_242, 0));
      V v_entries_2412 = heff_take_field(v_g_2411, 1);
      V v_aliases_2413 = heff_get_n(v_g_2411, 2, 8);
      V v_k_2414 = heff_strAppend(v_module_243, heff_strAppend(((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str0), v_x_241));
      HeffT2 v_t_2415 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_entries_2412, v_k_2414));
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          heff_drop(v_entries_2412);
          heff_drop(v_aliases_2413);
          heff_drop(v_k_2414);
          V v_e_2418 = v_field_2417;
          V v_t_2419 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2418, 3, 4)));
          HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(heff_get_n(v_top_242, 0, 9), v_t_2419);
        } else {
          heff_drop(v_field_2417);
          HeffT2 v_t_2420 = ({ V a_0 = v_aliases_2413; V a_1 = v_k_2414; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_aliases_2413); heff_drop(v_k_2414); r_; });
          {
            V v_field_2422 = v_t_2420.f[1];
            int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
            if ((v_tag_2421 == ((int64_t)0ULL))) {
              V v_k2_2423 = v_field_2422;
              HeffT2 v_t_2424 = ({ V a_0 = v_entries_2412; V a_1 = v_k2_2423; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_entries_2412); heff_drop(v_k2_2423); r_; });
              {
                V v_field_2426 = v_t_2424.f[1];
                int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
                if ((v_tag_2425 == ((int64_t)0ULL))) {
                  V v_e_2427 = v_field_2426;
                  V v_t_2428 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2427, 3, 4)));
                  HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(heff_get_n(v_top_242, 0, 9), v_t_2428);
                } else {
                  heff_drop_rec(v_top_242, 9);
                  heff_drop(v_field_2426);
                  return ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str1);
                }
              }
            } else {
              heff_drop_rec(v_top_242, 9);
              heff_drop(v_entries_2412);
              heff_drop(v_field_2422);
              return ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str2);
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2equery_2ecompletionDetail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecompletionDetail(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionOf_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionOf_str1, 1, ".");
Clo g_heff_2ebuild_2equery_2ecompletionOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionOf_entry, 4, 0};

V g_heff_2ebuild_2equery_2ecompletionOf(V v_c_240, V v_typed_241, V v_qualifier_242, V v_x_243) {
top: ;
  V v_t_244 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength_lent(v_typed_241, 0));
  if ((heff_strEq_c_lent(v_t_244, v_typed_241, 0) && (heff_strEq_c_lent(v_qualifier_242, ((V)&g_heff_2ebuild_2equery_2ecompletionOf_str0), 2) ? !heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2ecompletionOf_str1), v_x_243, MK_INT(0LL), 5)) : 1))) {
    heff_drop(v_t_244);
    V v_t_245 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength_lent(v_qualifier_242, 0));
    V v_t_246;
    if (heff_strEq_c_lent(v_t_245, v_qualifier_242, 1)) {
      v_t_246 = heff_strSlice(heff_dup(v_x_243), heff_strLength_lent(v_qualifier_242, 0), heff_strLength_lent(v_x_243, 0));
    } else {
      v_t_246 = heff_dup(v_x_243);
    }
    V v_t_247 = (g_heff_2ebuild_2equery_2ecompletionDetail(v_c_240, v_x_243));
    return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_label__detail, (V[]){v_t_246, v_t_247})});
  } else {
    heff_drop(v_c_240);
    heff_drop(v_x_243);
    heff_drop(v_t_244);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2equery_2ecompletionOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2equery_2ecompletionOf(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2equery_2estartsStatement_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2estartsStatement_entry, 3, 0};

V g_heff_2ebuild_2equery_2estartsStatement(V v_src_240, V v_i_241, V v_n_242) {
top: ;
  if ((heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1) && (heff_unbox_word(heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)))) == ((int64_t)32ULL)))) {
    V t_0 = v_src_240;
    V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
    V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
    v_src_240 = t_0;
    v_i_241 = t_1;
    v_n_242 = t_2;
    goto top;
  } else {
    V v_ret_24bool = heff_bool((heff_intLt_c_lent(MK_INT(0LL), v_n_242, 1) && (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2) || (heff_unbox_word(heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)))) == ((int64_t)10ULL)))));
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return v_ret_24bool;
  }
}
V g_heff_2ebuild_2equery_2estartsStatement_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2estartsStatement(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str0, 7, "abandon");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str1, 7, "abandon");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str2, 50, "a hole: checks at any small type, abandons the run");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str3, 4, "with");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str4, 4, "with");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str5, 58, "a statement: `with e as x do`, the block the `with`'s body");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str6, 0, "");
V g_heff_2ebuild_2equery_2ecompletionsAt_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2ecompletionsAt_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionsAt_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecompletionsAt(V v_c_240, V v_offset_241) {
top: ;
  V v_t_242 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_typed_243 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_242, heff_dup(v_offset_241));
  V v_t_244 = heff_strSlice(((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str0), MK_INT(0LL), heff_strLength_lent(v_typed_243, 0));
  V v_t_245;
  if (heff_strEq_c(v_t_244, v_typed_243)) {
    v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_label__detail, (V[]){((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str1), ((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str2)}), NTAG(TAG_Nil)});
  } else {
    v_t_245 = NTAG(TAG_Nil);
  }
  V v_from_246 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_t_247 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_typed_248 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_247, heff_dup(v_offset_241));
  V v_t_249 = (g_heff_2ebuild_2equery_2estartsStatement(heff_rfield(v_c_240, 3), v_from_246, MK_INT(0LL)));
  V v_t_2410;
  if (((heff_dup(v_t_249) == NTAG(TAG_True)) && heff_strEq_c(heff_strSlice(((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str3), MK_INT(0LL), heff_strLength_lent(v_typed_248, 0)), heff_dup(v_typed_248)))) {
    heff_drop(v_typed_248);
    heff_drop(v_t_249);
    v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_label__detail, (V[]){((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str4), ((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str5)}), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_typed_248);
    heff_drop(v_t_249);
    v_t_2410 = NTAG(TAG_Nil);
  }
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_245, v_t_2410));
  V v_t_2412 = (g_list_2emap_24s467798769x1763085075(heff_dup(heff_rfield(v_c_240, 7))));
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_2414 = ({ V b_0 = heff_get_n(v_t_2413, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2415 = (g_list_2emap_24s1415906091x1371825187(v_t_2414));
  V v_g_2416 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_entries_2417 = heff_take_field(v_g_2416, 1);
  V v_order_2418 = heff_get_n(v_g_2416, 0, 8);
  V v_t_2425 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2ecompletionsAt_lam0, 2, 1, (V[]){v_entries_2417}); V a_1 = NTAG(TAG_Nil); V a_2 = v_order_2418; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_order_2418); r_; });
  V v_t_2426 = (g_list_2emap_24s1721231741x1085491812(v_t_2425));
  V v_t_2427 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2426));
  V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2427));
  V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2428));
  V v_t_2430 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2429));
  V v_t_2442 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2ecompletionsAt_lam1, 1, 2, (V[]){v_c_240, v_offset_241}), v_t_2430));
  V v_t_2443 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2442));
  V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2443));
  return (g_list_2esortBy_24s1119089913x1963956854(v_t_2444));
}
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecompletionsAt(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2ecompletionsAt_lam0(V self, V *args) {
  V v_acc_2419 = args[0];
  V v_k_2420 = args[1];
  V v_entries_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2421 = ({ V a_0 = v_entries_2417; V a_1 = v_k_2420; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_entries_2417); r_; });
  {
    V v_field_2423 = v_t_2421.f[1];
    int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
    if ((v_tag_2422 == ((int64_t)0ULL))) {
      V v_e_2424 = v_field_2423;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2420, v_e_2424}), v_acc_2419});
    } else {
      heff_drop(v_k_2420);
      heff_drop(v_field_2423);
      return v_acc_2419;
    }
  }
}
V g_heff_2ebuild_2equery_2ecompletionsAt_lam1(V self, V *args) {
  V v_x_2431 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_offset_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_t_2433 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_2432, heff_dup(v_offset_241));
  V v_t_2434 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_typed_2435 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_2434, v_offset_241);
  int64_t v_t_2436 = (heff_unbox_word(heff_strLength_lent(v_typed_2435, 0)) - ((int64_t)1ULL));
  HeffT2 v_t_2437 = (g_heff_2ebuild_2equery_2elastDot_24cpr(v_typed_2435, heff_box_word(v_t_2436)));
  V v_t_2441;
  {
    V v_field_2439 = v_t_2437.f[1];
    int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
    if ((v_tag_2438 == ((int64_t)0ULL))) {
      V v_i_2440 = v_field_2439;
      v_t_2441 = heff_strSlice(v_typed_2435, MK_INT(0LL), heff_intAdd(v_i_2440, MK_INT(1LL)));
    } else {
      heff_drop(v_typed_2435);
      heff_drop(v_field_2439);
      v_t_2441 = ((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str6);
    }
  }
  return ({ V a_0 = v_c_240; V a_1 = v_t_2433; V a_2 = v_t_2441; V a_3 = v_x_2431; V r_ = (g_heff_2ebuild_2equery_2ecompletionOf(a_0, a_1, a_2, a_3)); heff_drop(v_t_2433); heff_drop(v_t_2441); r_; });
}
Clo g_heff_2ebuild_2equery_2esumTags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esumTags_entry, 1, 0};

V g_heff_2ebuild_2equery_2esumTags(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      return NTAG(TAG_Nil);
    }
    case TAG_EBinary: {
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELam: {
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      V v_alts_2428 = heff_field(v_x11_241, 0);
      V v_t_2429 = (g_list_2emap_24s173442543x1801751270(heff_dup(v_alts_2428)));
      HEFF_LAST return g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2429);
    }
    case TAG_EStruct: {
      return NTAG(TAG_Nil);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nil);
    }
    case TAG_EAssign: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWhile: {
      return NTAG(TAG_Nil);
    }
    case TAG_EFor: {
      return NTAG(TAG_Nil);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_Nil);
    }
    case TAG_EBreak: {
      return NTAG(TAG_Nil);
    }
    case TAG_EContinue: {
      return NTAG(TAG_Nil);
    }
    case TAG_EReturn: {
      return NTAG(TAG_Nil);
    }
    case TAG_ENest: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELazy: {
      return NTAG(TAG_Nil);
    }
    case TAG_ETuple: {
      return NTAG(TAG_Nil);
    }
    case TAG_ETry: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWith: {
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2esumTags_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2esumTags(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2edefinesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edefinesGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2edefinesGo(V v_k_240, V v_c_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_os_245 = heff_field(v_x3_242, 1);
    V v_key_246 = heff_dup(heff_rfield(v_o_244, 1));
    V v_name_247 = heff_dup(heff_rfield(v_o_244, 0));
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_c_241);
      heff_drop(v_key_246);
      heff_drop(v_name_247);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x41_248 = heff_field(v_x4_243, 0);
      V v_sps_249 = heff_field(v_x4_243, 1);
      switch (heff_tag_of(v_x41_248)) {
      case TAG_MkPair: {
        V v_sp_2411 = heff_field(v_x41_248, 1);
        if (heff_strEq_c_lent(v_key_246, v_k_240, 1)) {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_c__name__span, (V[]){v_c_241, v_name_247, heff_dup(v_sp_2411)})});
        } else {
          heff_drop(v_name_247);
          V t_0 = v_k_240;
          V t_1 = v_c_241;
          V t_2 = v_os_245;
          V t_3 = v_sps_249;
          v_k_240 = t_0;
          v_c_241 = t_1;
          v_x3_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
      }
      default: return heff_nomatch(v_x41_248);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2edefinesGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ebuild_2equery_2edefinesGo(a0, a[1], a2, a3); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ebuild_2equery_2edefinitionIn_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2edefinitionIn_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2edefinitionIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edefinitionIn_entry, 3, 0};

V g_heff_2ebuild_2equery_2edefinitionIn(V v_i_240, V v_k_241, V v_d_242) {
top: ;
  V v_c_243 = heff_take_field(v_d_242, 0);
  V v_span_244 = heff_get_n(v_d_242, 2, 3);
  V v_member_245 = heff_take_field(v_i_240, 3);
  V v_name_246 = heff_get_n(v_i_240, 1, 5);
  V v_c_247 = heff_dup(v_c_243);
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_247, 4))));
  V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2edefinitionIn_lam0, 2, 1, (V[]){v_c_247}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  HeffT2 v_t_2415 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ebuild_2equery_2edefinitionIn_lam1, 1, 3, (V[]){v_member_245, v_k_241, heff_dup(v_name_246)}), v_t_2412));
  V v_t_2420;
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      heff_drop(v_span_244);
      heff_drop(v_name_246);
      V v_s_2418 = v_field_2417;
      v_t_2420 = heff_get_n(v_s_2418, 2, 3);
    } else {
      heff_drop(v_field_2417);
      V v_sp_2419 = v_span_244;
      v_t_2420 = ({ V a_0 = heff_rfield(v_c_243, 3); V a_1 = v_name_246; V a_2 = heff_dup(v_sp_2419); V a_3 = heff_get_n(v_sp_2419, 0, 2); V r_ = (g_heff_2ebuild_2equery_2enameInGo(a_0, a_1, a_2, a_3)); heff_drop(v_name_246); r_; });
    }
  }
  return heff_rec_n(3, shape_path__source__span, (V[]){heff_dup(heff_rfield(v_c_243, 1)), heff_get_n(v_c_243, 3, 14), v_t_2420});
}
V g_heff_2ebuild_2equery_2edefinitionIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edefinitionIn(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2edefinitionIn_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_c_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = (g_heff_2ebuild_2equery_2edeclSites(v_c_247, v_x_2410));
  return (g_prelude_2e_2b_2b(v_t_2411, v_acc_249));
}
V g_heff_2ebuild_2equery_2edefinitionIn_lam1(V self, V *args) {
  V v_s_2413 = args[0];
  V v_member_245 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_name_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414;
  if ((heff_dup(v_member_245) == NTAG(TAG_True))) {
    heff_drop(v_member_245);
    v_t_2414 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_241, heff_tag_n(TAG_Just, 1, (V[]){v_name_246}), NTAG(TAG_Nothing)});
  } else {
    heff_drop(v_member_245);
    heff_drop(v_name_246);
    v_t_2414 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_241, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  }
  return (g_heff_2ebuild_2equery_2eeqTarget(heff_get_n(v_s_2413, 0, 3), v_t_2414));
}
V g_heff_2ebuild_2equery_2esiteFound_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2equery_2esiteFound_24cpr(V v_program_240, V v_c_241, V v_off_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_241, 4))));
  V v_t_247 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2esiteFound_24cpr_lam0, 2, 1, (V[]){v_c_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  HeffT2 v_t_248 = (g_list_2efind_24s845102114x2128838930_24cpr(v_off_242, v_t_247));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_s_2411 = v_field_2410;
      V v_t_2412 = heff_get_n(v_s_2411, 0, 3);
      V v_t_2413 = heff_dup(heff_rfield(v_t_2412, 1));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        HeffT2 v_t_2414 = (g_heff_2ebuild_2equery_2eownNameOf_24cpr(v_program_240, heff_rfield(v_t_2412, 0)));
        {
          V v_field_2416 = v_t_2414.f[1];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          if ((v_tag_2415 == ((int64_t)0ULL))) {
            V v_x_2417 = v_field_2416;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_target__name, (V[]){v_t_2412, v_x_2417})}});
          } else {
            heff_drop_rec(v_t_2412, 3);
            heff_drop(v_field_2416);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      case TAG_Just: {
        V v_m_2418 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 1);
        heff_drop(v_program_240);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_target__name, (V[]){v_t_2412, v_m_2418})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2413)}});
      }
    } else {
      heff_drop(v_program_240);
      heff_drop(v_field_2410);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2equery_2esiteFound_24cpr_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2ebuild_2equery_2edeclSites(v_c_241, v_x_245));
  return (g_prelude_2e_2b_2b(v_t_246, v_acc_244));
}
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str2, 1, " ");
Clo g_heff_2ebuild_2equery_2ewordsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordsOf_entry, 4, 0};

V g_heff_2ebuild_2equery_2ewordsOf(V v_base_240, V v_line_241, V v_i_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_line_241, 0), heff_dup(v_i_242))) {
    heff_drop(v_base_240);
    heff_drop(v_i_242);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_line_241, v_i_242, 0)) == ((int64_t)32ULL))) {
      V t_0 = v_base_240;
      V t_1 = v_line_241;
      V t_2 = heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL)));
      V t_3 = v_acc_243;
      v_base_240 = t_0;
      v_line_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      V v_j_244 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2ewordsOf_str0), v_line_241, v_i_242, 1);
      V v_t_245;
      if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
        heff_drop(v_j_244);
        v_t_245 = heff_strLength_lent(v_line_241, 0);
      } else {
        v_t_245 = v_j_244;
      }
      V v_j_246 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2ewordsOf_str1), v_line_241, v_i_242, 1);
      V v_t_247;
      if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
        heff_drop(v_j_246);
        v_t_247 = heff_strLength_lent(v_line_241, 0);
      } else {
        v_t_247 = v_j_246;
      }
      V v_j_248 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2ewordsOf_str2), v_line_241, v_i_242, 1);
      V v_t_249;
      if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
        heff_drop(v_j_248);
        v_t_249 = heff_strLength_lent(v_line_241, 0);
      } else {
        v_t_249 = v_j_248;
      }
      V v_e_2410 = heff_intAdd(heff_dup(v_base_240), v_t_249);
      V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(heff_dup(v_base_240), heff_dup(v_i_242)), v_e_2410});
      V v_t_2412 = heff_rec_n(2, shape_text__span, (V[]){heff_strSlice_lent(v_line_241, v_i_242, v_t_247, 6), v_t_2411});
      V t_0 = v_base_240;
      V t_1 = v_line_241;
      V t_2 = v_t_245;
      V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_acc_243});
      v_base_240 = t_0;
      v_line_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ebuild_2equery_2ewordsOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2ewordsOf(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2equery_2ewordsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordsIn_entry, 6, 0};

V g_heff_2ebuild_2equery_2ewordsIn(V v_fits_240, V v_name_241, V v_src_242, V v_i_243, V v_to_244, V v_acc_245) {
top: ;
  V v_j_246 = heff_strFind_lent(v_name_241, v_src_242, v_i_243, 4);
  if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
    heff_drop(v_fits_240);
    heff_drop(v_to_244);
    heff_drop(v_j_246);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
  } else {
    V v_t_247 = heff_intAdd(heff_dup(v_j_246), heff_strLength_lent(v_name_241, 0));
    if (heff_intLe_c_lent(v_t_247, v_to_244, 1)) {
      V v_t_248 = (g_heff_2ebuild_2equery_2ewordAt(v_src_242, heff_dup(v_j_246), v_name_241));
      V v_t_2411;
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_t_249 = heff_tr(heff_call(heff_dup(v_fits_240), 1, (V[]){heff_dup(v_j_246)}));
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_t_249);
          V v_t_2410 = heff_intAdd(heff_dup(v_j_246), heff_strLength_lent(v_name_241, 0));
          v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_j_246), v_t_2410}), v_acc_245});
        } else {
          heff_drop(v_t_249);
          v_t_2411 = v_acc_245;
        }
      } else {
        heff_drop(v_t_248);
        v_t_2411 = v_acc_245;
      }
      V t_0 = v_fits_240;
      V t_1 = v_name_241;
      V t_2 = v_src_242;
      V t_3 = heff_intAdd(v_j_246, MK_INT(1LL));
      V t_4 = v_to_244;
      V t_5 = v_t_2411;
      v_fits_240 = t_0;
      v_name_241 = t_1;
      v_src_242 = t_2;
      v_i_243 = t_3;
      v_to_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    } else {
      heff_drop(v_fits_240);
      heff_drop(v_to_244);
      heff_drop(v_j_246);
      return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
    }
  }
}
V g_heff_2ebuild_2equery_2ewordsIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2equery_2ewordsIn(a[0], a1, a2, a[3], a[4], a[5]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2equery_2espacesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2espacesFrom_entry, 2, 0};

V g_heff_2ebuild_2equery_2espacesFrom(V v_src_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)32ULL))) {
    V t_0 = v_src_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_src_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2espacesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2espacesFrom(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2espacesBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2espacesBefore_entry, 2, 0};

V g_heff_2ebuild_2equery_2espacesBefore(V v_src_240, V v_i_241) {
top: ;
  if ((heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1) && (heff_unbox_word(heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)))) == ((int64_t)32ULL)))) {
    V t_0 = v_src_240;
    V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
    v_src_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2espacesBefore_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2espacesBefore(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2equery_2emoreIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2emoreIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2emoreIn_entry, 3, 0};

V g_heff_2ebuild_2equery_2emoreIn(V v_t_240, V v_name_241, V v_c_242) {
top: ;
  V v_c_243 = heff_strByteAt_lent(v_name_241, MK_INT(0LL), 2);
  V v_t_2412;
  if (((heff_peek_word(v_c_243) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_243) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_243) == ((int64_t)47ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_243)) ? !(heff_peek_word(v_c_243) <= ((int64_t)57ULL)) : 1))))))) {
    heff_drop(v_c_243);
    V v_t_244 = heff_dup(heff_rfield(v_t_240, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_src_245 = heff_dup(heff_rfield(v_c_242, 3));
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_src_245, 0)) - ((int64_t)1ULL));
      V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = MK_INT(0LL); V a_2 = v_src_245; V a_3 = MK_INT(1LL); V a_4 = MK_INT(10LL); V a_5 = MK_INT(0LL); V a_6 = heff_box_word(v_t_246); V r_ = (g_list_2efoldl_24f2080327479x1330764413(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_src_245); r_; });
      v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2emoreIn_lam0, 2, 2, (V[]){heff_dup(v_name_241), heff_dup(v_c_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2412 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
  } else {
    heff_drop(v_c_243);
    v_t_2412 = NTAG(TAG_Nil);
  }
  V v_c_2413 = heff_strByteAt_lent(v_name_241, MK_INT(0LL), 2);
  V v_t_2414;
  if (((heff_peek_word(v_c_2413) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_2413) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_2413) == ((int64_t)47ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_2413)) && (heff_peek_word(v_c_2413) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_2413)) && (heff_peek_word(v_c_2413) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_2413)) ? !(heff_peek_word(v_c_2413) <= ((int64_t)57ULL)) : 1))))))) {
    heff_drop_rec(v_t_240, 3);
    heff_drop_rec(v_c_242, 14);
    heff_drop(v_c_2413);
    v_t_2414 = NTAG(TAG_Nil);
  } else {
    heff_drop(v_c_2413);
    v_t_2414 = (g_heff_2ebuild_2equery_2eexpectedIn(v_t_240, v_name_241, v_c_242));
  }
  return (g_prelude_2e_2b_2b(v_t_2412, v_t_2414));
}
V g_heff_2ebuild_2equery_2emoreIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2emoreIn(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2equery_2emoreIn_lam0(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x_249 = args[1];
  V v_name_241 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = ({ V a_0 = v_name_241; V b_1 = heff_get_n(v_c_242, 3, 14); V a_2 = v_x_249; V r_ = (g_heff_2ebuild_2equery_2efixityLine(a_0, b_1, a_2)); heff_drop(v_name_241); heff_drop(b_1); r_; });
  return (g_prelude_2e_2b_2b(v_t_2410, v_acc_248));
}
Clo g_heff_2ebuild_2equery_2enameClass_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enameClass_entry, 1, 0};

V g_heff_2ebuild_2equery_2enameClass(V v_x_240) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) == ((int64_t)0ULL))) {
    return MK_INT(0LL);
  } else {
    if (((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)90ULL)))) {
      V v_t_241 = (g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(v_x_240, MK_INT(0LL)));
      if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
        heff_drop(v_t_241);
        return MK_INT(1LL);
      } else {
        heff_drop(v_t_241);
        return MK_INT(0LL);
      }
    } else {
      if (((heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) == ((int64_t)95ULL)) || ((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL))))) {
        V v_t_242 = (g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(v_x_240, MK_INT(0LL)));
        if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
          heff_drop(v_t_242);
          return MK_INT(2LL);
        } else {
          heff_drop(v_t_242);
          return MK_INT(0LL);
        }
      } else {
        V v_t_243 = (g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292(MK_INT(47LL), MK_INT(95LL), MK_INT(39LL), MK_INT(47LL), MK_INT(97LL), MK_INT(122LL), MK_INT(65LL), MK_INT(90LL), MK_INT(48LL), MK_INT(57LL), MK_INT(32LL), MK_INT(10LL), MK_INT(40LL), MK_INT(41LL), MK_INT(91LL), MK_INT(93LL), MK_INT(123LL), MK_INT(125LL), MK_INT(44LL), MK_INT(34LL), MK_INT(96LL), v_x_240, MK_INT(0LL)));
        if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
          heff_drop(v_t_243);
          return MK_INT(3LL);
        } else {
          heff_drop(v_t_243);
          return MK_INT(0LL);
        }
      }
    }
  }
}
V g_heff_2ebuild_2equery_2enameClass_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2enameClass(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2edocMarkdownIn_str0, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMarkdownIn_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMarkdownIn_str2, 1, "\012");
Clo g_heff_2ebuild_2equery_2edocMarkdownIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edocMarkdownIn_entry, 2, 0};

V g_heff_2ebuild_2equery_2edocMarkdownIn(V v_lang_240, V v_ls_241) {
top: ;
  V v_t_242 = heff_rec_n(3, shape_out__code__expecting, (V[]){NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False)});
  V v_m_243 = (g_list_2efoldl_24s673493459x989016999(v_lang_240, v_t_242, v_ls_241));
  V v_code_244 = heff_take_field(v_m_243, 1);
  V v_out_245 = heff_get_n(v_m_243, 0, 3);
  V v_t_246;
  if ((heff_dup(v_code_244) == NTAG(TAG_True))) {
    heff_drop(v_code_244);
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMarkdownIn_str0), v_out_245});
  } else {
    heff_drop(v_code_244);
    v_t_246 = v_out_245;
  }
  V v_x2_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_246));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2equery_2edocMarkdownIn_str1);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2equery_2edocMarkdownIn_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ebuild_2equery_2edocMarkdownIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2edocMarkdownIn(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2edocAt_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2equery_2edocAt_str1, 0, "");
Clo g_heff_2ebuild_2equery_2edocAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edocAt_entry, 2, 0};

V g_heff_2ebuild_2equery_2edocAt(V v_program_240, V v_off_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2equery_2edefinitionAt_24cpr(v_program_240, v_off_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_d_245 = v_field_244;
      V v_source_246 = heff_take_field(v_d_245, 1);
      V v_span_247 = heff_get_n(v_d_245, 2, 3);
      V v_start_248 = (g_heff_2ebuild_2equery_2elineStartOf(v_source_246, heff_get_n(v_span_247, 0, 2)));
      V v_t_249 = ({ V a_0 = v_source_246; V a_1 = v_start_248; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ecommentAbove(a_0, a_1, a_2)); heff_drop(v_source_246); r_; });
      V v_t_2410 = (g_list_2emap_24s1819241345x1511673126(v_t_249));
      V v_ls_2411 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2410));
      return ({ V a_0 = ((V)&g_heff_2ebuild_2equery_2edocAt_str0); V a_1 = v_ls_2411; V r_ = (g_heff_2ebuild_2equery_2edocMarkdownIn(a_0, a_1)); heff_drop(v_ls_2411); r_; });
    } else {
      heff_drop(v_field_244);
      return ((V)&g_heff_2ebuild_2equery_2edocAt_str1);
    }
  }
}
V g_heff_2ebuild_2equery_2edocAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edocAt(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2estmtChildren_24s810860270x338158667_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2estmtChildren_24s810860270x338158667_entry, 1, 0};

V g_heff_2ebuild_2equery_2estmtChildren_24s810860270x338158667(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_StmtBind: {
      V v_e_245 = heff_field(v_x21_241, 2);
      HEFF_LAST return g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_245);
    }
    case TAG_StmtLet: {
      V v_e_247 = heff_field(v_x21_241, 1);
      HEFF_LAST return g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_247);
    }
    case TAG_StmtExpr: {
      V v_e_248 = heff_field(v_x21_241, 0);
      HEFF_LAST return g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_248);
    }
    case TAG_StmtLetMut: {
      V v_e_2411 = heff_field(v_x21_241, 2);
      HEFF_LAST return g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2411);
    }
    case TAG_StmtLetElse: {
      V v_e_2413 = heff_field(v_x21_241, 1);
      V v_ss_2414 = heff_field(v_x21_241, 2);
      V v_t_2415 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2413));
      V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_2414)));
      V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s1113296953x161795409(a_0, a_1)); heff_drop(v_t_2416); r_; });
      return (g_prelude_2e_2b_2b(v_t_2415, v_t_2417));
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2equery_2estmtChildren_24s810860270x338158667_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2estmtChildren_24s810860270x338158667(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry, 1, 0};

V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      return NTAG(TAG_Nil);
    }
    case TAG_EBinary: {
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      V v_h_2412 = heff_field(v_x21_241, 0);
      V v_args_2413 = heff_field(v_x21_241, 1);
      V v_t_2414 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_h_2412));
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2413)));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s2134067310x2049132013(a_0, a_1)); heff_drop(v_t_2415); r_; });
      return (g_prelude_2e_2b_2b(v_t_2414, v_t_2416));
    }
    case TAG_EProject: {
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      V v_e_2419 = heff_field(v_x21_241, 1);
      V t_0 = v_e_2419;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EPi: {
      V v_b_2420 = heff_field(v_x21_241, 0);
      V v_cod_2421 = heff_field(v_x21_241, 1);
      V v_t_2438;
      switch (heff_tag_of(v_b_2420)) {
      case TAG_PiNamed: {
        V v_t_2424 = heff_field(v_b_2420, 2);
        v_t_2438 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2424));
        break;
      }
      case TAG_PiImplicit: {
        V v_t_2428 = heff_field(v_b_2420, 3);
        V v_d_2429 = heff_field(v_b_2420, 4);
        V v_t_2430 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2428));
        V v_t_2432;
        switch (heff_tag_of(v_d_2429)) {
        case TAG_Nothing: {
          v_t_2432 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x_2431 = heff_field(v_d_2429, 0);
          v_t_2432 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_x_2431));
          break;
        }
        default: heff_nomatch(v_d_2429);
        }
        v_t_2438 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2432));
        break;
      }
      case TAG_PiInstance: {
        V v_t_2436 = heff_field(v_b_2420, 3);
        v_t_2438 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2436));
        break;
      }
      case TAG_PiAnon: {
        V v_t_2437 = heff_field(v_b_2420, 0);
        v_t_2438 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2437));
        break;
      }
      default: heff_nomatch(v_b_2420);
      }
      V v_t_2439 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_cod_2421));
      return (g_prelude_2e_2b_2b(v_t_2438, v_t_2439));
    }
    case TAG_ELam: {
      V v_b_2440 = heff_field(v_x21_241, 0);
      V v_body_2441 = heff_field(v_x21_241, 1);
      V v_t_2449;
      switch (heff_tag_of(v_b_2440)) {
      case TAG_LamName: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LamImplicit: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LamAnn: {
        V v_t_2448 = heff_field(v_b_2440, 2);
        v_t_2449 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2448));
        break;
      }
      default: heff_nomatch(v_b_2440);
      }
      V v_t_2450 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_body_2441));
      return (g_prelude_2e_2b_2b(v_t_2449, v_t_2450));
    }
    case TAG_EAnn: {
      V v_e_2451 = heff_field(v_x21_241, 0);
      V v_t_2452 = heff_field(v_x21_241, 1);
      V v_t_2453 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2451));
      V v_t_2454 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2452));
      return (g_prelude_2e_2b_2b(v_t_2453, v_t_2454));
    }
    case TAG_ESpec: {
      V v_acc_2455 = heff_field(v_x21_241, 0);
      V v_v_2458 = heff_field(v_x21_241, 3);
      V v_t_2459 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_acc_2455));
      V v_t_2460 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_v_2458));
      return (g_prelude_2e_2b_2b(v_t_2459, v_t_2460));
    }
    case TAG_ESig: {
      V v_fs_2461 = heff_field(v_x21_241, 0);
      V v_t_2462 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2461)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2462; V r_ = (g_list_2efoldl_24s1777318809x1106245647(a_0, a_1)); heff_drop(v_t_2462); r_; });
    }
    case TAG_ESum: {
      V v_vs_2463 = heff_field(v_x21_241, 0);
      V v_t_2464 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_2463)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2464; V r_ = (g_list_2efoldl_24s491084544x100802329(a_0, a_1)); heff_drop(v_t_2464); r_; });
    }
    case TAG_EStruct: {
      V v_fs_2465 = heff_field(v_x21_241, 0);
      V v_t_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2465)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2466; V r_ = (g_list_2efoldl_24s189033563x26633104(a_0, a_1)); heff_drop(v_t_2466); r_; });
    }
    case TAG_EUpdate: {
      V v_a_2467 = heff_field(v_x21_241, 0);
      V v_fs_2468 = heff_field(v_x21_241, 1);
      V v_t_2469 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2467));
      V v_t_2470 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2468)));
      V v_t_2471 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2470; V r_ = (g_list_2efoldl_24s1026998256x1634433314(a_0, a_1)); heff_drop(v_t_2470); r_; });
      return (g_prelude_2e_2b_2b(v_t_2469, v_t_2471));
    }
    case TAG_EMatch: {
      V v_s_2472 = heff_field(v_x21_241, 0);
      V v_alts_2473 = heff_field(v_x21_241, 1);
      V v_t_2474 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_s_2472));
      V v_t_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_alts_2473)));
      V v_t_2476 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2475; V r_ = (g_list_2efoldl_24s302194196x751324068(a_0, a_1)); heff_drop(v_t_2475); r_; });
      return (g_prelude_2e_2b_2b(v_t_2474, v_t_2476));
    }
    case TAG_ELetIn: {
      V v_rhs_2477 = heff_field(v_x21_241, 0);
      V v_x212_2478 = heff_field(v_x21_241, 1);
      switch (heff_tag_of(v_x212_2478)) {
      case TAG_At: {
        V v_x2121_2479 = heff_field(v_x212_2478, 0);
        switch (heff_tag_of(v_x2121_2479)) {
        case TAG_MkAlt: {
          V v_e_2482 = heff_field(v_x2121_2479, 1);
          V v_t_2483 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_rhs_2477));
          V v_t_2484 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2482));
          return (g_prelude_2e_2b_2b(v_t_2483, v_t_2484));
        }
        default: return heff_nomatch(v_x2121_2479);
        }
      }
      default: return heff_nomatch(v_x212_2478);
      }
    }
    case TAG_EDo: {
      V v_stmts_2485 = heff_field(v_x21_241, 0);
      V v_t_2486 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stmts_2485)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2486; V r_ = (g_list_2efoldl_24s1113296953x161795409(a_0, a_1)); heff_drop(v_t_2486); r_; });
    }
    case TAG_ELocal: {
      V v_b_2487 = heff_field(v_x21_241, 0);
      V v_defs_2488 = heff_field(v_x21_241, 1);
      V v_t_2489 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_defs_2488)));
      V v_t_2490 = (g_list_2efoldl_24s1516272141x1201056882(MK_INT(12LL), NTAG(TAG_Nil), v_t_2489));
      V v_t_2491 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_b_2487));
      V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_defs_2488)));
      V v_t_2493 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2492; V r_ = (g_list_2efoldl_24s54159557x1528472185(a_0, a_1)); heff_drop(v_t_2492); r_; });
      V v_t_2494 = (g_prelude_2e_2b_2b(v_t_2491, v_t_2493));
      return (g_prelude_2e_2b_2b(v_t_2490, v_t_2494));
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nil);
    }
    case TAG_EAssign: {
      V v_e_2498 = heff_field(v_x21_241, 2);
      V t_0 = v_e_2498;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EWhile: {
      V v_c_2499 = heff_field(v_x21_241, 0);
      V v_body_24100 = heff_field(v_x21_241, 1);
      V v_t_24101 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_c_2499));
      V v_t_24102 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_body_24100)));
      V v_t_24103 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24102; V r_ = (g_list_2efoldl_24s1113296953x161795409(a_0, a_1)); heff_drop(v_t_24102); r_; });
      return (g_prelude_2e_2b_2b(v_t_24101, v_t_24103));
    }
    case TAG_EFor: {
      V v_c_24105 = heff_field(v_x21_241, 1);
      V v_body_24106 = heff_field(v_x21_241, 2);
      V v_t_24107 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_c_24105));
      V v_t_24108 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_body_24106)));
      V v_t_24109 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24108; V r_ = (g_list_2efoldl_24s1113296953x161795409(a_0, a_1)); heff_drop(v_t_24108); r_; });
      return (g_prelude_2e_2b_2b(v_t_24107, v_t_24109));
    }
    case TAG_EIfThen: {
      V v_c_24110 = heff_field(v_x21_241, 0);
      V v_a_24111 = heff_field(v_x21_241, 1);
      V v_t_24112 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_c_24110));
      V v_t_24113 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_24111));
      return (g_prelude_2e_2b_2b(v_t_24112, v_t_24113));
    }
    case TAG_EBreak: {
      return NTAG(TAG_Nil);
    }
    case TAG_EContinue: {
      return NTAG(TAG_Nil);
    }
    case TAG_EReturn: {
      V v_e_24114 = heff_field(v_x21_241, 0);
      V t_0 = v_e_24114;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_ENest: {
      V v_e_24115 = heff_field(v_x21_241, 0);
      V t_0 = v_e_24115;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_ELazy: {
      V v_e_24116 = heff_field(v_x21_241, 0);
      V t_0 = v_e_24116;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_ETuple: {
      V v_es_24117 = heff_field(v_x21_241, 0);
      V v_t_24118 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_24117)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24118; V r_ = (g_list_2efoldl_24s2134067310x2049132013(a_0, a_1)); heff_drop(v_t_24118); r_; });
    }
    case TAG_ETry: {
      V v_x211_24119 = heff_field(v_x21_241, 0);
      switch (heff_tag_of(v_x211_24119)) {
      case TAG_MkTry: {
        V v_body_24121 = heff_field(v_x211_24119, 1);
        V v_c_24122 = heff_field(v_x211_24119, 2);
        V v_t_24123 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_body_24121)));
        V v_t_24124 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24123; V r_ = (g_list_2efoldl_24s1113296953x161795409(a_0, a_1)); heff_drop(v_t_24123); r_; });
        V v_t_24137;
        switch (heff_tag_of(v_c_24122)) {
        case TAG_MkCatchArm: {
          V v_b_24125 = heff_field(v_c_24122, 0);
          V v_ss_24126 = heff_field(v_c_24122, 1);
          V v_t_24134;
          switch (heff_tag_of(v_b_24125)) {
          case TAG_LamName: {
            v_t_24134 = NTAG(TAG_Nil);
            break;
          }
          case TAG_LamImplicit: {
            v_t_24134 = NTAG(TAG_Nil);
            break;
          }
          case TAG_LamAnn: {
            V v_t_24133 = heff_field(v_b_24125, 2);
            v_t_24134 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_24133));
            break;
          }
          default: heff_nomatch(v_b_24125);
          }
          V v_t_24135 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_24126)));
          V v_t_24136 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24135; V r_ = (g_list_2efoldl_24s1113296953x161795409(a_0, a_1)); heff_drop(v_t_24135); r_; });
          v_t_24137 = (g_prelude_2e_2b_2b(v_t_24134, v_t_24136));
          break;
        }
        default: heff_nomatch(v_c_24122);
        }
        return (g_prelude_2e_2b_2b(v_t_24124, v_t_24137));
      }
      default: return heff_nomatch(v_x211_24119);
      }
    }
    case TAG_EWith: {
      V v_w_24138 = heff_field(v_x21_241, 0);
      V v_body_24141 = heff_field(v_x21_241, 3);
      V v_t_24142 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_w_24138));
      V v_t_24143 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_body_24141)));
      V v_t_24144 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24143; V r_ = (g_list_2efoldl_24s1113296953x161795409(a_0, a_1)); heff_drop(v_t_24143); r_; });
      return (g_prelude_2e_2b_2b(v_t_24142, v_t_24144));
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2esymbolsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry, 5, 0};

V g_heff_2ebuild_2equery_2esymbolsGo_24dps(V v_c_240, V v_ss_241, V v_x3_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_ss_241);
    heff_drop(v_x4_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x3_242, 0);
    V v_os_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop(v_ss_241);
      heff_drop(v_o_245);
      heff_drop(v_os_246);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x41_247 = heff_field(v_x4_243, 0);
      V v_sps_248 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_247)) {
      case TAG_MkPair: {
        V v_sp_2410 = heff_field(v_x41_247, 1);
        heff_take_n(v_x41_247, 2ULL, 2);
        V v_t_2411 = (g_list_2ekeepIf_24s257286374x378693326(heff_dup(v_sp_2410), heff_dup(v_ss_241)));
        V v_t_2412 = (g_heff_2ebuild_2equery_2esymbolWith(heff_dup(v_c_240), v_o_245, v_sp_2410, v_t_2411));
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
        V v_u_2414 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2413));
        heff_drop(v_u_2414);
        V t_0 = v_c_240;
        V t_1 = v_ss_241;
        V t_2 = v_os_246;
        V t_3 = v_sps_248;
        V t_4 = v_cell_2413;
        v_c_240 = t_0;
        v_ss_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
      default: return heff_nomatch(v_x41_247);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbolsGo_24dps(a[0], a[1], a[2], a[3], a[4]);
}