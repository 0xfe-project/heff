// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_ArrayKeepsAs 18630
#define TAG_ArrayLength 32493
#define TAG_ArrayReplicate 47039
#define TAG_ArraySet 62162
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_IntAdd 18227
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define LBL_body 9524841
#define LBL_e 319
#define LBL_i 323
#define LBL_k 325
#define LBL_key 315609
#define LBL_m 327
#define LBL_n 328
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_ps 10346
#define LBL_y 339
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__name__i__e__ps__k__m__y[] = {LBL_key, LBL_name, LBL_i, LBL_e, LBL_ps, LBL_k, LBL_m, LBL_y};
static uint32_t shape_n__out__k[] = {LBL_n, LBL_out, LBL_k};
V g_heff_2ecompile_2earrayloops_2easLoop(V, V, V, V, V, V);
V g_heff_2ecompile_2earrayloops_2easLoop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earrayloops_2easLoop_clo;
V g_heff_2ecompile_2earrayloops_2ecallsUnknown(V);
V g_heff_2ecompile_2earrayloops_2ecallsUnknown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earrayloops_2ecallsUnknown_clo;
V g_heff_2ecompile_2earrayloops_2efreshCall(V);
V g_heff_2ecompile_2earrayloops_2efreshCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earrayloops_2efreshCall_clo;
V g_heff_2ecompile_2earrayloops_2egenerated(V, V, V, V, V);
V g_heff_2ecompile_2earrayloops_2egenerated_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earrayloops_2egenerated_clo;
V g_heff_2ecompile_2earrayloops_2egenerated_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2earrayloops_2egenerated_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earrayloops_2egenerated_24tok2_clo;
V g_heff_2ecompile_2earrayloops_2ego(V, V, V);
V g_heff_2ecompile_2earrayloops_2ego_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earrayloops_2ego_clo;
V g_heff_2ecompile_2earrayloops_2einPlace(V, V, V);
V g_heff_2ecompile_2earrayloops_2einPlace_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earrayloops_2einPlace_clo;
V g_heff_2ecompile_2earrayloops_2eloopOf(V, V, V, V, V, V);
V g_heff_2ecompile_2earrayloops_2eloopOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earrayloops_2eloopOf_clo;
V g_heff_2ecompile_2earrayloops_2enodeOf(V, V, V, V);
V g_heff_2ecompile_2earrayloops_2enodeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earrayloops_2enodeOf_clo;
V g_heff_2ecompile_2earrayloops_2enodeOf_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2earrayloops_2enodeOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earrayloops_2enodeOf_24tok2_clo;
V g_heff_2ecompile_2earrayloops_2ereadOnlyAt(V, V, V);
V g_heff_2ecompile_2earrayloops_2ereadOnlyAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earrayloops_2ereadOnlyAt_clo;
V g_heff_2ecompile_2earrayloops_2ewithFirst(V, V, V);
V g_heff_2ecompile_2earrayloops_2ewithFirst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earrayloops_2ewithFirst_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eifOf(V, V, V);
V g_heff_2ecompile_2eir_2eifOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eifOf_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_clo;
V g_heff_2ecompile_2elift_2efreeGo(V, V, V);
V g_heff_2ecompile_2elift_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2efreeGo_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1681798656x925918587(V, V);
V g_prelude_2e_2b_2b_24f1681798656x925918587_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1681798656x925918587_clo;
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054(V, V, V);
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
Clo g_heff_2ecompile_2earrayloops_2ecallsUnknown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earrayloops_2ecallsUnknown_entry, 1, 0};

V g_heff_2ecompile_2earrayloops_2ecallsUnknown(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EApp: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_EApp: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    default: {
      heff_drop(v_e1_241);
      V v_t_246 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_240, NTAG(TAG_Nil)));
      return ({ V a_0 = ((V)&g_heff_2ecompile_2earrayloops_2ecallsUnknown_clo); V a_1 = v_t_246; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_246); r_; });
    }
    }
  }
  default: {
    V v_t_247 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_240, NTAG(TAG_Nil)));
    return ({ V a_0 = ((V)&g_heff_2ecompile_2earrayloops_2ecallsUnknown_clo); V a_1 = v_t_247; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_247); r_; });
  }
  }
}
V g_heff_2ecompile_2earrayloops_2ecallsUnknown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earrayloops_2ecallsUnknown(a[0]);
}
Clo g_heff_2ecompile_2earrayloops_2ereadOnlyAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earrayloops_2ereadOnlyAt_entry, 3, 0};

V g_heff_2ecompile_2earrayloops_2ereadOnlyAt(V v_xs_240, V v_i_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_i_241);
    V v_ret_24bool = heff_bool(!heff_strEq_c_lent(v_y_243, v_xs_240, 0));
    heff_drop(v_xs_240);
    heff_drop(v_y_243);
    return v_ret_24bool;
  }
  case TAG_EPrimCall: {
    V v_p_244 = heff_field(v_e_242, 0);
    V v_es_245 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_xs_246 = heff_dup(v_xs_240);
    V v_i_247 = heff_dup(v_i_241);
    V v_p_248 = v_p_244;
    V v_es_249 = heff_dup(v_es_245);
    V v_t_2494;
    switch (heff_tag_of(v_p_248)) {
    case TAG_ArrayIndex: {
      switch (heff_tag_of(v_es_249)) {
      case TAG_Nil: {
        heff_drop(v_xs_246);
        heff_drop(v_i_247);
        v_t_2494 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        V v_es1_2410 = heff_field(v_es_249, 0);
        V v_es2_2411 = heff_field(v_es_249, 1);
        heff_take_n(v_es_249, 3ULL, 2);
        switch (heff_tag_of(v_es1_2410)) {
        case TAG_EVar: {
          V v_a_2412 = heff_field(v_es1_2410, 0);
          heff_take_n(v_es1_2410, 1ULL, 1);
          switch (heff_tag_of(v_es2_2411)) {
          case TAG_Nil: {
            heff_drop(v_xs_246);
            heff_drop(v_i_247);
            heff_drop(v_a_2412);
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_Cons: {
            V v_es21_2413 = heff_field(v_es2_2411, 0);
            V v_es22_2414 = heff_field(v_es2_2411, 1);
            heff_take_n(v_es2_2411, 3ULL, 2);
            switch (heff_tag_of(v_es21_2413)) {
            case TAG_EVar: {
              V v_j_2415 = heff_field(v_es21_2413, 0);
              heff_take_n(v_es21_2413, 1ULL, 1);
              switch (heff_tag_of(v_es22_2414)) {
              case TAG_Nil: {
                v_t_2494 = heff_bool((heff_strEq_c_lent(v_a_2412, v_xs_246, 0) && heff_strEq_c_lent(v_j_2415, v_i_247, 0)));
                heff_drop(v_xs_246);
                heff_drop(v_i_247);
                heff_drop(v_a_2412);
                heff_drop(v_j_2415);
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_es22_2414, 0ULL, 2);
                heff_drop(v_xs_246);
                heff_drop(v_i_247);
                heff_drop(v_a_2412);
                heff_drop(v_j_2415);
                v_t_2494 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_es22_2414);
              }
              break;
            }
            case TAG_EGlobal: {
              heff_take_n(v_es21_2413, 0ULL, 1);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_ELam: {
              heff_take_n(v_es21_2413, 0ULL, 2);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EApp: {
              heff_take_n(v_es21_2413, 0ULL, 2);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_ELet: {
              heff_take_n(v_es21_2413, 0ULL, 3);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_ERecord: {
              heff_take_n(v_es21_2413, 0ULL, 2);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EProj: {
              heff_take_n(v_es21_2413, 0ULL, 4);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_ETag: {
              heff_take_n(v_es21_2413, 0ULL, 3);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EMatch: {
              heff_take_n(v_es21_2413, 0ULL, 2);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EPrim: {
              heff_take_n(v_es21_2413, 0ULL, 1);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EPrimCall: {
              heff_take_n(v_es21_2413, 0ULL, 2);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_ECall: {
              heff_take_n(v_es21_2413, 0ULL, 2);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EInt: {
              heff_take_n(v_es21_2413, 0ULL, 1);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EFloat: {
              heff_take_nf(v_es21_2413, 0ULL, 1);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EStr: {
              heff_take_n(v_es21_2413, 0ULL, 1);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EBytes: {
              heff_take_n(v_es21_2413, 0ULL, 1);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EFixed: {
              heff_take_n(v_es21_2413, 0ULL, 2);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EFloat32: {
              heff_take_na(v_es21_2413, 0ULL, 1);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EAbandon: {
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EBool: {
              heff_take_n(v_es21_2413, 0ULL, 1);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_ESet: {
              heff_take_n(v_es21_2413, 0ULL, 3);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EValues: {
              heff_take_n(v_es21_2413, 0ULL, 1);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            case TAG_EFix: {
              heff_take_n(v_es21_2413, 0ULL, 2);
              heff_drop(v_xs_246);
              heff_drop(v_i_247);
              heff_drop(v_a_2412);
              heff_drop(v_es22_2414);
              v_t_2494 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_es21_2413);
            }
            break;
          }
          default: heff_nomatch(v_es2_2411);
          }
          break;
        }
        case TAG_EGlobal: {
          heff_take_n(v_es1_2410, 0ULL, 1);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_ELam: {
          heff_take_n(v_es1_2410, 0ULL, 2);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EApp: {
          heff_take_n(v_es1_2410, 0ULL, 2);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_ELet: {
          heff_take_n(v_es1_2410, 0ULL, 3);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_ERecord: {
          heff_take_n(v_es1_2410, 0ULL, 2);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EProj: {
          heff_take_n(v_es1_2410, 0ULL, 4);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_ETag: {
          heff_take_n(v_es1_2410, 0ULL, 3);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EMatch: {
          heff_take_n(v_es1_2410, 0ULL, 2);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrim: {
          heff_take_n(v_es1_2410, 0ULL, 1);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrimCall: {
          heff_take_n(v_es1_2410, 0ULL, 2);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_ECall: {
          heff_take_n(v_es1_2410, 0ULL, 2);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EInt: {
          heff_take_n(v_es1_2410, 0ULL, 1);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EFloat: {
          heff_take_nf(v_es1_2410, 0ULL, 1);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EStr: {
          heff_take_n(v_es1_2410, 0ULL, 1);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EBytes: {
          heff_take_n(v_es1_2410, 0ULL, 1);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EFixed: {
          heff_take_n(v_es1_2410, 0ULL, 2);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EFloat32: {
          heff_take_na(v_es1_2410, 0ULL, 1);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EAbandon: {
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EBool: {
          heff_take_n(v_es1_2410, 0ULL, 1);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_ESet: {
          heff_take_n(v_es1_2410, 0ULL, 3);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EValues: {
          heff_take_n(v_es1_2410, 0ULL, 1);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        case TAG_EFix: {
          heff_take_n(v_es1_2410, 0ULL, 2);
          heff_drop(v_xs_246);
          heff_drop(v_i_247);
          heff_drop(v_es2_2411);
          v_t_2494 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_es1_2410);
        }
        break;
      }
      default: heff_nomatch(v_es_249);
      }
      break;
    }
    default: {
      heff_drop(v_xs_246);
      heff_drop(v_i_247);
      heff_drop(v_p_248);
      heff_drop(v_es_249);
      v_t_2494 = NTAG(TAG_False);
      break;
    }
    }
    if ((heff_dup(v_t_2494) == NTAG(TAG_True))) {
      heff_drop(v_xs_240);
      heff_drop(v_i_241);
      heff_drop(v_es_245);
      heff_drop(v_t_2494);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2494);
      V v_t_2495 = heff_tr(heff_call(((V)&g_heff_2ecompile_2earrayloops_2ereadOnlyAt_clo), 2, (V[]){v_xs_240, v_i_241}));
      return ({ V a_0 = v_t_2495; V a_1 = v_es_245; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_es_245); r_; });
    }
  }
  default: {
    V v_t_2496 = heff_tr(heff_call(((V)&g_heff_2ecompile_2earrayloops_2ereadOnlyAt_clo), 2, (V[]){v_xs_240, v_i_241}));
    V v_t_2497 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_242, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_2496; V a_1 = v_t_2497; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2497); r_; });
  }
  }
}
V g_heff_2ecompile_2earrayloops_2ereadOnlyAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earrayloops_2ereadOnlyAt(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2earrayloops_2eloopOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2earrayloops_2eloopOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earrayloops_2eloopOf_entry, 6, 0};

V g_heff_2ecompile_2earrayloops_2eloopOf(V v_key_240, V v_name_241, V v_ps_242, V v_i_243, V v_a_244, V v_e_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_244), NTAG(TAG_Nil)});
  V v_t_247 = (g_prelude_2e_2b_2b(heff_dup(v_ps_242), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_i_243), v_t_246})));
  V v_key_248 = heff_dup(v_key_240);
  V v_ps_249 = v_ps_242;
  V v_i_2410 = v_i_243;
  V v_a_2411 = v_a_244;
  V v_e_2412 = v_e_245;
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_a_2411)}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayLength), v_t_2413});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_i_2410)}), v_t_2415});
  V v_t_2417 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_IntLt), v_t_2416});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(1LL)}), NTAG(TAG_Nil)});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_i_2410)}), v_t_2418});
  V v_t_2420 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_IntAdd), v_t_2419});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2412, NTAG(TAG_Nil)});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_i_2410}), v_t_2421});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_a_2411)}), v_t_2422});
  V v_t_2424 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArraySet), v_t_2423});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  V v_t_2426 = (g_prelude_2e_2b_2b_24f1681798656x925918587(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2425}), v_ps_249));
  V v_t_2427 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_248}), v_t_2426});
  V v_t_2428 = (g_heff_2ecompile_2eir_2eifOf(v_t_2417, v_t_2427, heff_tag_n(TAG_EVar, 1, (V[]){v_a_2411})));
  V v_e_2429 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_247, v_t_2428});
  return heff_clo_n(g_heff_2ecompile_2earrayloops_2eloopOf_lam0, 1, 3, (V[]){v_e_2429, v_key_240, v_name_241});
}
V g_heff_2ecompile_2earrayloops_2eloopOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earrayloops_2eloopOf(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2earrayloops_2eloopOf_lam0(V self, V *args) {
  V v_s_2430 = args[0];
  V v_e_2429 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_n_2431 = heff_take_field(v_s_2430, 0);
  V v_out_2432 = heff_take_field(v_s_2430, 1);
  V v_k_2433 = heff_get_n(v_s_2430, 2, 3);
  HeffT2 v_t_2434 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), v_n_2431, v_e_2429));
  {
    V v_field_2435 = v_t_2434.f[0];
    V v_field_2436 = v_t_2434.f[1];
    V v_x_2437 = v_field_2435;
    V v_n_2438 = v_field_2436;
    V v_t_2439 = v_out_2432;
    V v_t_2440 = v_k_2433;
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){v_key_240, v_name_241, v_x_2437}), v_t_2439});
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), heff_rec_n(3, shape_n__out__k, (V[]){v_n_2438, v_t_2441, v_t_2440})});
  }
}
HEFF_LIT(g_heff_2ecompile_2earrayloops_2efreshCall_str0, 9, "$generate");
Clo g_heff_2ecompile_2earrayloops_2efreshCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earrayloops_2efreshCall_entry, 1, 0};

V g_heff_2ecompile_2earrayloops_2efreshCall(V v_g_240) {
top: ;
  V v_m_241 = heff_take_field(v_g_240, 6);
  V v_y_242 = heff_take_field(v_g_240, 7);
  V v_key_243 = heff_take_field(v_g_240, 0);
  V v_k_244 = heff_take_field(v_g_240, 5);
  V v_ps_245 = heff_get_n(v_g_240, 4, 8);
  V v_t_246 = v_m_241;
  V v_t_247 = v_y_242;
  V v_t_248 = heff_strAppend(heff_strAppend(v_key_243, ((V)&g_heff_2ecompile_2earrayloops_2efreshCall_str0)), heff_intShow(v_k_244));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_247}), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_246}), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayReplicate), v_t_2410});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(1LL)}), v_t_2412});
  V v_t_2414 = (g_prelude_2e_2b_2b_24f1681798656x925918587(v_t_2413, v_ps_245));
  return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_t_248}), v_t_2414});
}
V g_heff_2ecompile_2earrayloops_2efreshCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earrayloops_2efreshCall(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2earrayloops_2einPlace_str0, 2, "a$");
HEFF_LIT(g_heff_2ecompile_2earrayloops_2einPlace_str1, 4, "$map");
HEFF_LIT(g_heff_2ecompile_2earrayloops_2einPlace_str2, 4, ".map");
HEFF_LIT(g_heff_2ecompile_2earrayloops_2einPlace_str3, 4, "$map");
Clo g_heff_2ecompile_2earrayloops_2einPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earrayloops_2einPlace_entry, 3, 0};

V g_heff_2ecompile_2earrayloops_2einPlace(V v_g_240, V v_xs_241, V v_s_242) {
top: ;
  V v_n_243 = heff_take_field(v_s_242, 0);
  V v_x_244 = heff_strAppend(((V)&g_heff_2ecompile_2earrayloops_2einPlace_str0), heff_intShow(heff_dup(v_n_243)));
  V v_t_245 = heff_strAppend(heff_dup(heff_rfield(v_g_240, 0)), ((V)&g_heff_2ecompile_2earrayloops_2einPlace_str1));
  V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_g_240, 5)));
  V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_g_240, 1)), ((V)&g_heff_2ecompile_2earrayloops_2einPlace_str2));
  V v_t_248 = (g_list_2ekeepIf_24s930188071x496633547(v_xs_241, heff_dup(heff_rfield(v_g_240, 4))));
  V v_m_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_xs_241), heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_244)})));
  V v_e_2410 = heff_dup(heff_rfield(v_g_240, 3));
  V v_t_2411 = (g_std_2eordmap_2esize(v_m_249));
  V v_t_2412;
  if (heff_intEq_c(v_t_2411, MK_INT(0LL))) {
    heff_drop(v_m_249);
    v_t_2412 = v_e_2410;
  } else {
    v_t_2412 = ({ V a_0 = v_m_249; V a_1 = v_e_2410; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_249); r_; });
  }
  V v_m_2413 = (g_heff_2ecompile_2earrayloops_2eloopOf(heff_strAppend(v_t_245, v_t_246), v_t_247, v_t_248, heff_dup(heff_rfield(v_g_240, 2)), v_x_244, v_t_2412));
  V v_t_2414 = ({ V rv_0 = heff_intAdd(v_n_243, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_s_242, 6ULL, 3, shape_n__out__k, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_t_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 2ULL, 2);
    V v_t_2418 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(heff_rfield(v_g_240, 7))});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_xs_241)}), v_t_2419});
    V v_t_2421 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayKeepsAs), v_t_2420});
    V v_t_2422 = heff_strAppend(heff_dup(heff_rfield(v_g_240, 0)), ((V)&g_heff_2ecompile_2earrayloops_2einPlace_str3));
    V v_t_2423 = heff_intShow(heff_dup(heff_rfield(v_g_240, 5)));
    V v_t_2424 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_strAppend(v_t_2422, v_t_2423)});
    V v_t_2425 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(heff_rfield(v_g_240, 7))});
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(0LL)}), v_t_2426});
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_xs_241)}), v_t_2427});
    V v_t_2429 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArraySet), v_t_2428});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(1LL)}), v_t_2430});
    V v_t_2432 = ({ V a_0 = v_t_2431; V a_1 = v_xs_241; V a_2 = heff_dup(heff_rfield(v_g_240, 4)); V r_ = (g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
    V v_t_2433 = (g_heff_2ecompile_2earrayloops_2efreshCall(v_g_240));
    V v_x_2434 = (g_heff_2ecompile_2eir_2eifOf(v_t_2421, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2424, v_t_2432}), v_t_2433));
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){v_x_2434, v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2earrayloops_2einPlace_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earrayloops_2einPlace(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2earrayloops_2ewithFirst_str0, 2, "u$");
HEFF_LIT(g_heff_2ecompile_2earrayloops_2ewithFirst_str1, 9, "$generate");
HEFF_LIT(g_heff_2ecompile_2earrayloops_2ewithFirst_str2, 9, ".generate");
HEFF_LIT(g_heff_2ecompile_2earrayloops_2ewithFirst_str3, 2, "a$");
V g_heff_2ecompile_2earrayloops_2ewithFirst_lam0(V self, V *args);
V g_heff_2ecompile_2earrayloops_2ewithFirst_lam1(V self, V *args);
Clo g_heff_2ecompile_2earrayloops_2ewithFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earrayloops_2ewithFirst_entry, 3, 0};

V g_heff_2ecompile_2earrayloops_2ewithFirst(V v_g_240, V v_n_241, V v_s_242) {
top: ;
  V v_n_243 = heff_take_field(v_s_242, 0);
  V v_out_244 = heff_take_field(v_s_242, 1);
  V v_k_245 = heff_get_n(v_s_242, 2, 3);
  V v_n_246 = v_n_243;
  V v_x_247 = heff_strAppend(((V)&g_heff_2ecompile_2earrayloops_2ewithFirst_str0), heff_intShow(heff_dup(v_n_246)));
  V v_t_248 = heff_intAdd(v_n_246, MK_INT(1LL));
  V v_t_249 = v_out_244;
  V v_t_2410 = v_k_245;
  V v_m_2411 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(heff_rfield(v_g_240, 2)), heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(0LL)})));
  V v_e_2412 = heff_dup(heff_rfield(v_g_240, 3));
  V v_t_2413 = (g_std_2eordmap_2esize(v_m_2411));
  V v_e_2414;
  if (heff_intEq_c(v_t_2413, MK_INT(0LL))) {
    heff_drop(v_m_2411);
    v_e_2414 = v_e_2412;
  } else {
    v_e_2414 = ({ V a_0 = v_m_2411; V a_1 = v_e_2412; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2411); r_; });
  }
  HeffT2 v_t_2415 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), heff_intAdd(heff_dup(v_t_248), MK_INT(1LL)), v_e_2414));
  {
    V v_field_2416 = v_t_2415.f[0];
    V v_field_2417 = v_t_2415.f[1];
    V v_x_2418 = v_field_2416;
    V v_n_2419 = v_field_2417;
    V v_t_2420 = heff_strAppend(heff_dup(heff_rfield(v_g_240, 0)), ((V)&g_heff_2ecompile_2earrayloops_2ewithFirst_str1));
    V v_t_2421 = heff_intShow(heff_dup(heff_rfield(v_g_240, 5)));
    V v_t_2422 = heff_strAppend(heff_dup(heff_rfield(v_g_240, 1)), ((V)&g_heff_2ecompile_2earrayloops_2ewithFirst_str2));
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2earrayloops_2ewithFirst_str3), heff_intShow(v_t_248));
    V v_m_2424 = (g_heff_2ecompile_2earrayloops_2eloopOf(heff_strAppend(v_t_2420, v_t_2421), v_t_2422, heff_dup(heff_rfield(v_g_240, 4)), heff_dup(heff_rfield(v_g_240, 2)), v_t_2423, heff_dup(heff_rfield(v_g_240, 3))));
    V v_x2_2425 = heff_tr(heff_call(v_m_2424, 1, (V[]){heff_rec_n(3, shape_n__out__k, (V[]){v_n_2419, v_t_249, v_t_2410})}));
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_MkPair: {
      V v_s_2427 = heff_field(v_x2_2425, 1);
      V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 2ULL, 2);
      V v_g_2428 = heff_dup(v_g_240);
      V v_e_2429 = heff_dup(v_n_241);
      V v_x2_24112;
      switch (heff_tag_of(v_e_2429)) {
      case TAG_EVar: {
        heff_take_n(v_e_2429, 0ULL, 1);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_e_2429, 0ULL, 1);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_e_2429, 0ULL, 2);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_e_2429, 0ULL, 2);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_e_2429, 0ULL, 3);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_e_2429, 0ULL, 2);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_e_2429, 0ULL, 4);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_e_2429, 0ULL, 3);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_e_2429, 0ULL, 2);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_e_2429, 0ULL, 1);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EPrimCall: {
        V v_e1_2451 = heff_field(v_e_2429, 0);
        V v_e2_2452 = heff_field(v_e_2429, 1);
        heff_take_n(v_e_2429, 3ULL, 2);
        switch (heff_tag_of(v_e1_2451)) {
        case TAG_ArrayLength: {
          switch (heff_tag_of(v_e2_2452)) {
          case TAG_Nil: {
            v_x2_24112 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Cons: {
            V v_e21_2453 = heff_field(v_e2_2452, 0);
            V v_e22_2454 = heff_field(v_e2_2452, 1);
            heff_take_n(v_e2_2452, 3ULL, 2);
            switch (heff_tag_of(v_e21_2453)) {
            case TAG_EVar: {
              V v_xs_2455 = heff_field(v_e21_2453, 0);
              V v_ru_24e21_2453_24EVar = heff_take_reuse_n(v_e21_2453, 1ULL, 1);
              switch (heff_tag_of(v_e22_2454)) {
              case TAG_Nil: {
                v_x2_24112 = heff_tag_at_n(v_ru_24e21_2453_24EVar, TAG_Just, 1, (V[]){v_xs_2455});
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_e22_2454, 0ULL, 2);
                heff_drop(v_xs_2455);
                heff_drop_cell(v_ru_24e21_2453_24EVar, 1);
                v_x2_24112 = NTAG(TAG_Nothing);
                break;
              }
              default: heff_nomatch(v_e22_2454);
              }
              break;
            }
            case TAG_EGlobal: {
              heff_take_n(v_e21_2453, 0ULL, 1);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_ELam: {
              heff_take_n(v_e21_2453, 0ULL, 2);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EApp: {
              heff_take_n(v_e21_2453, 0ULL, 2);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_ELet: {
              heff_take_n(v_e21_2453, 0ULL, 3);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_ERecord: {
              heff_take_n(v_e21_2453, 0ULL, 2);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EProj: {
              heff_take_n(v_e21_2453, 0ULL, 4);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_ETag: {
              heff_take_n(v_e21_2453, 0ULL, 3);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EMatch: {
              heff_take_n(v_e21_2453, 0ULL, 2);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EPrim: {
              heff_take_n(v_e21_2453, 0ULL, 1);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EPrimCall: {
              heff_take_n(v_e21_2453, 0ULL, 2);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_ECall: {
              heff_take_n(v_e21_2453, 0ULL, 2);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EInt: {
              heff_take_n(v_e21_2453, 0ULL, 1);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EFloat: {
              heff_take_nf(v_e21_2453, 0ULL, 1);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EStr: {
              heff_take_n(v_e21_2453, 0ULL, 1);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EBytes: {
              heff_take_n(v_e21_2453, 0ULL, 1);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EFixed: {
              heff_take_n(v_e21_2453, 0ULL, 2);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EFloat32: {
              heff_take_na(v_e21_2453, 0ULL, 1);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EAbandon: {
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EBool: {
              heff_take_n(v_e21_2453, 0ULL, 1);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_ESet: {
              heff_take_n(v_e21_2453, 0ULL, 3);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EValues: {
              heff_take_n(v_e21_2453, 0ULL, 1);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_EFix: {
              heff_take_n(v_e21_2453, 0ULL, 2);
              heff_drop(v_e22_2454);
              v_x2_24112 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_e21_2453);
            }
            break;
          }
          default: heff_nomatch(v_e2_2452);
          }
          break;
        }
        default: {
          heff_drop(v_e1_2451);
          heff_drop(v_e2_2452);
          v_x2_24112 = NTAG(TAG_Nothing);
          break;
        }
        }
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_e_2429, 0ULL, 2);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_e_2429, 0ULL, 1);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_e_2429, 0ULL, 1);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_e_2429, 0ULL, 1);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_e_2429, 0ULL, 1);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_e_2429, 0ULL, 2);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_e_2429, 0ULL, 1);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EAbandon: {
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_e_2429, 0ULL, 1);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_e_2429, 0ULL, 3);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_e_2429, 0ULL, 1);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_e_2429, 0ULL, 2);
        v_x2_24112 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_2429);
      }
      V v_m_24119;
      switch (heff_tag_of(v_x2_24112)) {
      case TAG_Nothing: {
        V v_x_24113 = (g_heff_2ecompile_2earrayloops_2efreshCall(v_g_2428));
        v_m_24119 = heff_clo_n(g_heff_2ecompile_2earrayloops_2ewithFirst_lam0, 1, 1, (V[]){v_x_24113});
        break;
      }
      case TAG_Just: {
        V v_xs_24115 = heff_field(v_x2_24112, 0);
        heff_take_n(v_x2_24112, 1ULL, 1);
        V v_t_24116 = (g_heff_2ecompile_2earrayloops_2ereadOnlyAt(heff_dup(v_xs_24115), heff_dup(heff_rfield(v_g_2428, 2)), heff_dup(heff_rfield(v_g_2428, 3))));
        if ((heff_dup(v_t_24116) == NTAG(TAG_True))) {
          heff_drop(v_t_24116);
          v_m_24119 = heff_tr(heff_call(((V)&g_heff_2ecompile_2earrayloops_2einPlace_clo), 2, (V[]){v_g_2428, v_xs_24115}));
        } else {
          heff_drop(v_xs_24115);
          heff_drop(v_t_24116);
          V v_x_24117 = (g_heff_2ecompile_2earrayloops_2efreshCall(v_g_2428));
          v_m_24119 = heff_clo_n(g_heff_2ecompile_2earrayloops_2ewithFirst_lam1, 1, 1, (V[]){v_x_24117});
        }
        break;
      }
      default: heff_nomatch(v_x2_24112);
      }
      V v_x2_24120 = heff_tr(heff_call(v_m_24119, 1, (V[]){v_s_2427}));
      switch (heff_tag_of(v_x2_24120)) {
      case TAG_MkPair: {
        V v_x_24121 = heff_field(v_x2_24120, 0);
        V v_s_24122 = heff_field(v_x2_24120, 1);
        V v_ru_24x2_24120_24MkPair = heff_take_reuse_n(v_x2_24120, 3ULL, 2);
        V v_t_24123 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(heff_rfield(v_g_240, 6))});
        V v_t_24124 = heff_tag_at_n(v_ru_24x2_24120_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(0LL)}), NTAG(TAG_Nil)});
        V v_t_24125 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_IntLe), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24123, v_t_24124})});
        V v_t_24126 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(heff_rfield(v_g_240, 6))});
        V v_t_24127 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, NTAG(TAG_Nil)});
        V v_t_24128 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_24127, NTAG(TAG_EAbandon)});
        V v_t_24129 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24128, NTAG(TAG_Nil)});
        V v_t_24130 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayGenerate), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24126, v_t_24129})});
        V v_t_24131 = heff_tag_n(TAG_ELet, 3, (V[]){heff_take_field(v_g_240, 7), v_x_2418, v_x_24121});
        V v_t_24132 = (g_heff_2ecompile_2eir_2eifOf(v_t_24125, v_t_24130, v_t_24131));
        V v_x_24133 = heff_tag_n(TAG_ELet, 3, (V[]){heff_get_n(v_g_240, 6, 8), v_n_241, v_t_24132});
        return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){v_x_24133, v_s_24122});
      }
      default: return heff_nomatch(v_x2_24120);
      }
    }
    default: return heff_nomatch(v_x2_2425);
    }
  }
}
V g_heff_2ecompile_2earrayloops_2ewithFirst_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earrayloops_2ewithFirst(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2earrayloops_2ewithFirst_lam0(V self, V *args) {
  V v_s_24114 = args[0];
  V v_x_24113 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24113, v_s_24114});
}
V g_heff_2ecompile_2earrayloops_2ewithFirst_lam1(V self, V *args) {
  V v_s_24118 = args[0];
  V v_x_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24117, v_s_24118});
}
HEFF_LIT(g_heff_2ecompile_2earrayloops_2easLoop_str0, 2, "m$");
HEFF_LIT(g_heff_2ecompile_2earrayloops_2easLoop_str1, 2, "y$");
Clo g_heff_2ecompile_2earrayloops_2easLoop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earrayloops_2easLoop_entry, 6, 0};

V g_heff_2ecompile_2earrayloops_2easLoop(V v_key_240, V v_name_241, V v_n_242, V v_i_243, V v_e_244, V v_s_245) {
top: ;
  V v_k_246 = heff_take_field(v_s_245, 2);
  V v_n_247 = heff_take_field(v_s_245, 0);
  V v_out_248 = heff_get_n(v_s_245, 1, 3);
  V v_x_249 = heff_dup(v_k_246);
  V v_t_2410 = v_n_247;
  V v_t_2411 = v_out_248;
  V v_t_2412 = heff_intAdd(v_k_246, MK_INT(1LL));
  V v_t_2413 = heff_intAdd(heff_dup(v_t_2410), MK_INT(1LL));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_i_243), NTAG(TAG_Nil)});
  V v_xs_2415 = heff_tr(g_heff_2ecompile_2elift_2efreeGo(v_t_2414, heff_dup(v_e_244), NTAG(TAG_Nil)));
  V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2415));
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2earrayloops_2easLoop_str0), heff_intShow(v_t_2410));
  V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2earrayloops_2easLoop_str1), heff_intShow(heff_dup(v_t_2413)));
  V v_t_2419 = heff_rec_n(3, shape_n__out__k, (V[]){heff_intAdd(v_t_2413, MK_INT(1LL)), v_t_2411, v_t_2412});
  return (g_heff_2ecompile_2earrayloops_2ewithFirst(heff_rec_n(8, shape_key__name__i__e__ps__k__m__y, (V[]){v_key_240, v_name_241, v_i_243, v_e_244, v_t_2416, v_x_249, v_t_2417, v_t_2418}), v_n_242, v_t_2419));
}
V g_heff_2ecompile_2earrayloops_2easLoop_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earrayloops_2easLoop(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2earrayloops_2egenerated_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earrayloops_2egenerated_entry, 5, 0};

V g_heff_2ecompile_2earrayloops_2egenerated(V v_key_240, V v_name_241, V v_n_242, V v_f_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_f_243)) {
  case TAG_ELam: {
    V v_f1_245 = heff_dup(heff_field(v_f_243, 0));
    V v_e_246 = heff_dup(heff_field(v_f_243, 1));
    switch (heff_tag_of(v_f1_245)) {
    case TAG_Nil: {
      heff_drop(v_key_240);
      heff_drop(v_name_241);
      heff_drop(v_e_246);
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_243, NTAG(TAG_Nil)});
      V v_t_248 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayGenerate), heff_tag_n(TAG_Cons, 2, (V[]){v_n_242, v_t_247})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_z_244});
    }
    case TAG_Cons: {
      V v_i_249 = heff_field(v_f1_245, 0);
      V v_f12_2410 = heff_field(v_f1_245, 1);
      V v_ru_24f1_245_24Cons = heff_take_reuse_n(v_f1_245, 3ULL, 2);
      switch (heff_tag_of(v_f12_2410)) {
      case TAG_Nil: {
        heff_drop_tag(v_f_243, 2);
        switch (heff_tag_of(v_e_246)) {
        case TAG_EAbandon: {
          heff_drop(v_key_240);
          heff_drop(v_name_241);
          V v_t_2411 = heff_tag_at_n(v_ru_24f1_245_24Cons, TAG_Cons, 2, (V[]){v_i_249, NTAG(TAG_Nil)});
          V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2411, v_e_246}), NTAG(TAG_Nil)});
          V v_t_2413 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayGenerate), heff_tag_n(TAG_Cons, 2, (V[]){v_n_242, v_t_2412})});
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_z_244});
        }
        default: {
          V v_x1_2414 = (g_heff_2ecompile_2earrayloops_2ecallsUnknown(heff_dup(v_e_246)));
          if (!(heff_dup(v_x1_2414) == NTAG(TAG_True))) {
            heff_drop(v_x1_2414);
            V v_t_2415 = heff_tag_at_n(v_ru_24f1_245_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_e_246), NTAG(TAG_Nil)});
            V v_x_2416 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(100LL), MK_INT(0LL), v_t_2415));
            if (!heff_intLt_c_lent(MK_INT(100LL), v_x_2416, 1)) {
              heff_drop(v_x_2416);
              return (g_heff_2ecompile_2earrayloops_2easLoop(v_key_240, v_name_241, v_n_242, v_i_249, v_e_246, v_z_244));
            } else {
              heff_drop(v_key_240);
              heff_drop(v_name_241);
              heff_drop(v_x_2416);
              V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_i_249, NTAG(TAG_Nil)});
              V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2417, v_e_246}), NTAG(TAG_Nil)});
              V v_t_2419 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayGenerate), heff_tag_n(TAG_Cons, 2, (V[]){v_n_242, v_t_2418})});
              return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_z_244});
            }
          } else {
            heff_drop(v_key_240);
            heff_drop(v_name_241);
            heff_drop(v_x1_2414);
            V v_t_2420 = heff_tag_at_n(v_ru_24f1_245_24Cons, TAG_Cons, 2, (V[]){v_i_249, NTAG(TAG_Nil)});
            V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2420, v_e_246}), NTAG(TAG_Nil)});
            V v_t_2422 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayGenerate), heff_tag_n(TAG_Cons, 2, (V[]){v_n_242, v_t_2421})});
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_z_244});
          }
        }
        }
      }
      case TAG_Cons: {
        V v_ru_24f12_2410_24Cons = heff_take_reuse_n(v_f12_2410, 0ULL, 2);
        heff_drop(v_key_240);
        heff_drop(v_name_241);
        heff_drop(v_e_246);
        heff_drop(v_i_249);
        V v_t_2425 = heff_tag_at_n(v_ru_24f1_245_24Cons, TAG_Cons, 2, (V[]){v_f_243, NTAG(TAG_Nil)});
        V v_t_2426 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayGenerate), heff_tag_at_n(v_ru_24f12_2410_24Cons, TAG_Cons, 2, (V[]){v_n_242, v_t_2425})});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_z_244});
      }
      default: return heff_nomatch(v_f12_2410);
      }
    }
    default: return heff_nomatch(v_f1_245);
    }
  }
  default: {
    heff_drop(v_key_240);
    heff_drop(v_name_241);
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_243, NTAG(TAG_Nil)});
    V v_t_2428 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayGenerate), heff_tag_n(TAG_Cons, 2, (V[]){v_n_242, v_t_2427})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2428, v_z_244});
  }
  }
}
V g_heff_2ecompile_2earrayloops_2egenerated_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earrayloops_2egenerated(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2earrayloops_2enodeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earrayloops_2enodeOf_entry, 4, 0};

V g_heff_2ecompile_2earrayloops_2enodeOf(V v_key_240, V v_name_241, V v_e_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EPrimCall: {
    V v_p_244 = heff_field(v_e_242, 0);
    V v_es_245 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_key_246 = v_key_240;
    V v_name_247 = v_name_241;
    V v_p_248 = v_p_244;
    V v_es_249 = v_es_245;
    switch (heff_tag_of(v_p_248)) {
    case TAG_ArrayGenerate: {
      switch (heff_tag_of(v_es_249)) {
      case TAG_Nil: {
        heff_drop(v_key_246);
        heff_drop(v_name_247);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_248, v_es_249}), v_z_243});
      }
      case TAG_Cons: {
        V v_n_2410 = heff_dup(heff_field(v_es_249, 0));
        V v_es2_2411 = heff_dup(heff_field(v_es_249, 1));
        switch (heff_tag_of(v_es2_2411)) {
        case TAG_Nil: {
          heff_drop(v_key_246);
          heff_drop(v_name_247);
          heff_drop(v_n_2410);
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_248, v_es_249}), v_z_243});
        }
        case TAG_Cons: {
          V v_f_2412 = heff_field(v_es2_2411, 0);
          V v_es22_2413 = heff_field(v_es2_2411, 1);
          V v_ru_24es2_2411_24Cons = heff_take_reuse_n(v_es2_2411, 3ULL, 2);
          switch (heff_tag_of(v_es22_2413)) {
          case TAG_Nil: {
            heff_drop_tag(v_es_249, 2);
            heff_drop_cell(v_ru_24es2_2411_24Cons, 2);
            return (g_heff_2ecompile_2earrayloops_2egenerated_24tok2(v_ru_24e_242_24EPrimCall, v_key_246, v_name_247, v_n_2410, v_f_2412, v_z_243));
          }
          case TAG_Cons: {
            heff_take_n(v_es22_2413, 0ULL, 2);
            heff_drop(v_key_246);
            heff_drop(v_name_247);
            heff_drop(v_n_2410);
            heff_drop(v_f_2412);
            return heff_tag_at_n(v_ru_24es2_2411_24Cons, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_248, v_es_249}), v_z_243});
          }
          default: return heff_nomatch(v_es22_2413);
          }
        }
        default: return heff_nomatch(v_es2_2411);
        }
      }
      default: return heff_nomatch(v_es_249);
      }
    }
    default: {
      heff_drop(v_key_246);
      heff_drop(v_name_247);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_248, v_es_249}), v_z_243});
    }
    }
  }
  default: {
    heff_drop(v_key_240);
    heff_drop(v_name_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_z_243});
  }
  }
}
V g_heff_2ecompile_2earrayloops_2enodeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earrayloops_2enodeOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2earrayloops_2ego_lam0(V self, V *args);
V g_heff_2ecompile_2earrayloops_2ego_lam1(V self, V *args);
Clo g_heff_2ecompile_2earrayloops_2ego_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earrayloops_2ego_entry, 3, 0};

V g_heff_2ecompile_2earrayloops_2ego(V v_key_240, V v_name_241, V v_e_242) {
top: ;
  V v_m_245 = (g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863(heff_clo_n(g_heff_2ecompile_2earrayloops_2ego_lam0, 2, 2, (V[]){heff_dup(v_key_240), heff_dup(v_name_241)}), v_e_242));
  return heff_clo_n(g_heff_2ecompile_2earrayloops_2ego_lam1, 1, 3, (V[]){v_m_245, v_key_240, v_name_241});
}
V g_heff_2ecompile_2earrayloops_2ego_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earrayloops_2ego(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2earrayloops_2ego_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_p_244 = args[1];
  V v_key_240 = heff_env(self)[0];
  V v_name_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_243);
  return (g_heff_2ecompile_2earrayloops_2ego(v_key_240, v_name_241, v_p_244));
}
V g_heff_2ecompile_2earrayloops_2ego_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    return (g_heff_2ecompile_2earrayloops_2enodeOf_24tok2(v_ru_24x2_247_24MkPair, v_key_240, v_name_241, v_x_248, v_s_249));
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2ecompile_2earrayloops_2egenerated_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earrayloops_2egenerated_24tok2_entry, 6, 0};

V g_heff_2ecompile_2earrayloops_2egenerated_24tok2(V v_tok_240, V v_key_241, V v_name_242, V v_n_243, V v_f_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_f_244)) {
  case TAG_ELam: {
    V v_f1_246 = heff_dup(heff_field(v_f_244, 0));
    V v_e_247 = heff_dup(heff_field(v_f_244, 1));
    switch (heff_tag_of(v_f1_246)) {
    case TAG_Nil: {
      heff_drop(v_key_241);
      heff_drop(v_name_242);
      heff_drop(v_e_247);
      V v_t_248 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_f_244, NTAG(TAG_Nil)});
      V v_t_249 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayGenerate), heff_tag_n(TAG_Cons, 2, (V[]){v_n_243, v_t_248})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_z_245});
    }
    case TAG_Cons: {
      V v_i_2410 = heff_field(v_f1_246, 0);
      V v_f12_2411 = heff_field(v_f1_246, 1);
      V v_ru_24f1_246_24Cons = heff_take_reuse_n(v_f1_246, 3ULL, 2);
      switch (heff_tag_of(v_f12_2411)) {
      case TAG_Nil: {
        heff_drop_tag(v_f_244, 2);
        switch (heff_tag_of(v_e_247)) {
        case TAG_EAbandon: {
          heff_drop(v_key_241);
          heff_drop(v_name_242);
          V v_t_2412 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_i_2410, NTAG(TAG_Nil)});
          V v_t_2413 = heff_tag_at_n(v_ru_24f1_246_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2412, v_e_247}), NTAG(TAG_Nil)});
          V v_t_2414 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayGenerate), heff_tag_n(TAG_Cons, 2, (V[]){v_n_243, v_t_2413})});
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_z_245});
        }
        default: {
          V v_x1_2415 = (g_heff_2ecompile_2earrayloops_2ecallsUnknown(heff_dup(v_e_247)));
          if (!(heff_dup(v_x1_2415) == NTAG(TAG_True))) {
            heff_drop(v_x1_2415);
            V v_t_2416 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_dup(v_e_247), NTAG(TAG_Nil)});
            V v_x_2417 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(100LL), MK_INT(0LL), v_t_2416));
            if (!heff_intLt_c_lent(MK_INT(100LL), v_x_2417, 1)) {
              heff_drop_cell(v_ru_24f1_246_24Cons, 2);
              heff_drop(v_x_2417);
              HEFF_LAST return g_heff_2ecompile_2earrayloops_2easLoop(v_key_241, v_name_242, v_n_243, v_i_2410, v_e_247, v_z_245);
            } else {
              heff_drop(v_key_241);
              heff_drop(v_name_242);
              heff_drop(v_x_2417);
              V v_t_2418 = heff_tag_at_n(v_ru_24f1_246_24Cons, TAG_Cons, 2, (V[]){v_i_2410, NTAG(TAG_Nil)});
              V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2418, v_e_247}), NTAG(TAG_Nil)});
              V v_t_2420 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayGenerate), heff_tag_n(TAG_Cons, 2, (V[]){v_n_243, v_t_2419})});
              return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2420, v_z_245});
            }
          } else {
            heff_drop(v_key_241);
            heff_drop(v_name_242);
            heff_drop(v_x1_2415);
            V v_t_2421 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_i_2410, NTAG(TAG_Nil)});
            V v_t_2422 = heff_tag_at_n(v_ru_24f1_246_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2421, v_e_247}), NTAG(TAG_Nil)});
            V v_t_2423 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayGenerate), heff_tag_n(TAG_Cons, 2, (V[]){v_n_243, v_t_2422})});
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_z_245});
          }
        }
        }
      }
      case TAG_Cons: {
        V v_ru_24f12_2411_24Cons = heff_take_reuse_n(v_f12_2411, 0ULL, 2);
        heff_drop(v_key_241);
        heff_drop(v_name_242);
        heff_drop(v_e_247);
        heff_drop(v_i_2410);
        V v_t_2426 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_f_244, NTAG(TAG_Nil)});
        V v_t_2427 = heff_tag_at_n(v_ru_24f12_2411_24Cons, TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayGenerate), heff_tag_at_n(v_ru_24f1_246_24Cons, TAG_Cons, 2, (V[]){v_n_243, v_t_2426})});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2427, v_z_245});
      }
      default: return heff_nomatch(v_f12_2411);
      }
    }
    default: return heff_nomatch(v_f1_246);
    }
  }
  default: {
    heff_drop(v_key_241);
    heff_drop(v_name_242);
    V v_t_2428 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_f_244, NTAG(TAG_Nil)});
    V v_t_2429 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayGenerate), heff_tag_n(TAG_Cons, 2, (V[]){v_n_243, v_t_2428})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_z_245});
  }
  }
}
V g_heff_2ecompile_2earrayloops_2egenerated_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earrayloops_2egenerated_24tok2(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2earrayloops_2enodeOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earrayloops_2enodeOf_24tok2_entry, 5, 0};

V g_heff_2ecompile_2earrayloops_2enodeOf_24tok2(V v_tok_240, V v_key_241, V v_name_242, V v_e_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EPrimCall: {
    V v_p_245 = heff_field(v_e_243, 0);
    V v_es_246 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EPrimCall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_key_247 = v_key_241;
    V v_name_248 = v_name_242;
    V v_p_249 = v_p_245;
    V v_es_2410 = v_es_246;
    switch (heff_tag_of(v_p_249)) {
    case TAG_ArrayGenerate: {
      switch (heff_tag_of(v_es_2410)) {
      case TAG_Nil: {
        heff_drop(v_key_247);
        heff_drop(v_name_248);
        return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_249, v_es_2410}), v_z_244});
      }
      case TAG_Cons: {
        V v_n_2411 = heff_dup(heff_field(v_es_2410, 0));
        V v_es2_2412 = heff_dup(heff_field(v_es_2410, 1));
        switch (heff_tag_of(v_es2_2412)) {
        case TAG_Nil: {
          heff_drop(v_key_247);
          heff_drop(v_name_248);
          heff_drop(v_n_2411);
          return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_249, v_es_2410}), v_z_244});
        }
        case TAG_Cons: {
          V v_f_2413 = heff_field(v_es2_2412, 0);
          V v_es22_2414 = heff_field(v_es2_2412, 1);
          heff_take_n(v_es2_2412, 3ULL, 2);
          switch (heff_tag_of(v_es22_2414)) {
          case TAG_Nil: {
            heff_drop_cell(v_tok_240, 2);
            heff_drop_tag(v_es_2410, 2);
            return (g_heff_2ecompile_2earrayloops_2egenerated_24tok2(v_ru_24e_243_24EPrimCall, v_key_247, v_name_248, v_n_2411, v_f_2413, v_z_244));
          }
          case TAG_Cons: {
            heff_take_n(v_es22_2414, 0ULL, 2);
            heff_drop(v_key_247);
            heff_drop(v_name_248);
            heff_drop(v_n_2411);
            heff_drop(v_f_2413);
            return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_249, v_es_2410}), v_z_244});
          }
          default: return heff_nomatch(v_es22_2414);
          }
        }
        default: return heff_nomatch(v_es2_2412);
        }
      }
      default: return heff_nomatch(v_es_2410);
      }
    }
    default: {
      heff_drop(v_key_247);
      heff_drop(v_name_248);
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_249, v_es_2410}), v_z_244});
    }
    }
  }
  default: {
    heff_drop(v_key_241);
    heff_drop(v_name_242);
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_e_243, v_z_244});
  }
  }
}
V g_heff_2ecompile_2earrayloops_2enodeOf_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earrayloops_2enodeOf_24tok2(a[0], a[1], a[2], a[3], a[4]);
}