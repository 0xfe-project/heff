// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_ELam 43266
#define TAG_EMatch 41631
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define LBL_end 310101
#define LBL_start 311115900
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eboolOf(V);
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo;
V g_heff_2esyntax_2epresyntax_2erightTupleP(V, V);
V g_heff_2esyntax_2epresyntax_2erightTupleP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2erightTupleP_clo;
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_clo;
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enames_241_get(void);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1023238561x651750209(V, V, V);
V g_list_2efoldl_24f1023238561x651750209_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1023238561x651750209_clo;
V g_list_2emap_24s1237964173x885934184(V);
V g_list_2emap_24s1237964173x885934184_entry(V self, V *a);
extern Clo g_list_2emap_24s1237964173x885934184_clo;
V g_list_2emap_24s695242541x1354106801(V);
V g_list_2emap_24s695242541x1354106801_entry(V self, V *a);
extern Clo g_list_2emap_24s695242541x1354106801_clo;
V g_list_2emap_24s986706030x137375431(V);
V g_list_2emap_24s986706030x137375431_entry(V self, V *a);
extern Clo g_list_2emap_24s986706030x137375431_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;

static V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enames_241_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enames_241_st;
static V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enames_241_init(void) {
  return ((V)&g_list_2emap_24s986706030x137375431_clo);
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enames_241_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enames_241_st)) return g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enames_241_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enames_241_val, &g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enames_241_st, g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enames_241_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str0, 4, "True");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str1, 5, "False");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str2, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str3, 4, "Cons");
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_lam1(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242(V v_sp_240, V v_bs_241, V v_has_242) {
top: ;
  V v_t_243 = (g_list_2emap_24s986706030x137375431(v_bs_241));
  V v_t_248 = (g_list_2efoldl_24f1023238561x651750209(NTAG(TAG_Nil), heff_clo_n(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_lam0, 1, 2, (V[]){v_has_242, heff_dup(v_sp_240)}), v_t_243));
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str2)}), heff_dup(v_sp_240)});
  return ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_lam1, 2, 1, (V[]){v_sp_240}); V a_1 = v_t_249; V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_has_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tr(heff_call(v_has_242, 1, (V[]){v_x_244}));
  V v_t_246;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    v_t_246 = ((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str0);
  } else {
    heff_drop(v_t_245);
    v_t_246 = ((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str1);
  }
  V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){v_t_246}), v_sp_240});
  return (g_heff_2esyntax_2epresyntax_2eboolOf(v_t_247));
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_lam1(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str3)}), v_sp_240});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_acc_2410, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_t_2413})));
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_str0, 6, "bound#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_str1, 6, "bound#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_str2, 6, "bound#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_str3, 6, "bound#");
Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244(V v_sp_240, V v_bs_241, V v_inner_242) {
top: ;
  V v_t_243 = (g_list_2emap_24s986706030x137375431(heff_dup(v_bs_241)));
  V v_t_244 = (g_list_2emap_24s695242541x1354106801(v_bs_241));
  V v_it_245 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_243, v_t_244));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nil: {
    V v_t_246 = (g_list_2emap_24s1237964173x885934184(v_it_245));
    V v_p_247 = (g_heff_2esyntax_2epresyntax_2erightTupleP(heff_dup(v_sp_240), v_t_246));
    V v_t_2410;
    switch (heff_tag_of(v_p_247)) {
    case TAG_At: {
      V v_s_249 = heff_dup(heff_field(v_p_247, 1));
      v_t_2410 = v_s_249;
      break;
    }
    default: heff_nomatch(v_p_247);
    }
    V v_t_2413;
    switch (heff_tag_of(v_inner_242)) {
    case TAG_At: {
      V v_s_2412 = heff_dup(heff_field(v_inner_242, 1));
      v_t_2413 = v_s_2412;
      break;
    }
    default: heff_nomatch(v_inner_242);
    }
    V v_t_2414 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2410, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_247, v_inner_242}), v_t_2414});
    V v_alts_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
    V v_t_2417 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
    V v_t_2418 = heff_tag_n(TAG_LamName, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_str0), v_t_2417), heff_dup(v_sp_240)});
    V v_t_2419 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
    V v_t_2420 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_str1), v_t_2419)});
    V v_t_2421 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2420, heff_dup(v_sp_240)}), v_alts_2416});
    V v_t_2422 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2418, heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_240});
  }
  case TAG_Cons: {
    V v_it1_2423 = heff_dup(heff_field(v_it_245, 0));
    V v_it2_2424 = heff_dup(heff_field(v_it_245, 1));
    switch (heff_tag_of(v_it1_2423)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_it1_2423, 0);
      V v_xsp_2426 = heff_field(v_it1_2423, 1);
      V v_ru_24it1_2423_24MkPair = heff_take_reuse_n(v_it1_2423, 3ULL, 2);
      switch (heff_tag_of(v_it2_2424)) {
      case TAG_Nil: {
        heff_drop_tag(v_it_245, 2);
        V v_t_2427 = heff_tag_at_n(v_ru_24it1_2423_24MkPair, TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_2425, v_xsp_2426}), v_inner_242});
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2427, v_sp_240});
      }
      case TAG_Cons: {
        V v_ru_24it2_2424_24Cons = heff_take_reuse_n(v_it2_2424, 0ULL, 2);
        heff_drop(v_x_2425);
        heff_drop(v_xsp_2426);
        V v_t_2430 = (g_list_2emap_24s1237964173x885934184(v_it_245));
        V v_p_2431 = (g_heff_2esyntax_2epresyntax_2erightTupleP(heff_dup(v_sp_240), v_t_2430));
        V v_t_2434;
        switch (heff_tag_of(v_p_2431)) {
        case TAG_At: {
          V v_s_2433 = heff_dup(heff_field(v_p_2431, 1));
          v_t_2434 = v_s_2433;
          break;
        }
        default: heff_nomatch(v_p_2431);
        }
        V v_t_2437;
        switch (heff_tag_of(v_inner_242)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_inner_242, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_inner_242);
        }
        V v_t_2438 = ({ V rv_1 = heff_get_n(v_t_2437, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2434, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2439 = heff_tag_at_n(v_ru_24it1_2423_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2431, v_inner_242}), v_t_2438});
        V v_alts_2440 = heff_tag_at_n(v_ru_24it2_2424_24Cons, TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
        V v_t_2441 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
        V v_t_2442 = heff_tag_n(TAG_LamName, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_str2), v_t_2441), heff_dup(v_sp_240)});
        V v_t_2443 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
        V v_t_2444 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_str3), v_t_2443)});
        V v_t_2445 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2444, heff_dup(v_sp_240)}), v_alts_2440});
        V v_t_2446 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2442, heff_tag_n(TAG_At, 2, (V[]){v_t_2445, heff_dup(v_sp_240)})});
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2446, v_sp_240});
      }
      default: return heff_nomatch(v_it2_2424);
      }
    }
    default: return heff_nomatch(v_it1_2423);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewithBoundOf_2enamesLam_244(a[0], a[1], a[2]);
}