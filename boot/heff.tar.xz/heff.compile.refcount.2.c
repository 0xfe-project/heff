// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ArrayReplicate 47039
#define TAG_ArraySet 62162
#define TAG_CIf 14188
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RField 17425
#define TAG_RFieldV 15755
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrimFn 2224
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Reuse 22912
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SOnce 21704
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38305
#define LBL_after 294093302
#define LBL_args 9498020
#define LBL_borrowed 695465691
#define LBL_funs 9650075
#define LBL_owned 307523263
#define LBL_reprs 309759928
#define LBL_sts 323756
#define LBL_takes 311482598
#define LBL_tl 10463
static uint32_t shape_sts__tl[] = {LBL_sts, LBL_tl};
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(V, V);
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_clo;
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok2_clo;
V g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915(V, V);
V g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_clo;
V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447(V, V);
V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2efreeOf(V, V);
V g_heff_2ecompile_2erefcount_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeOf_clo;
V g_heff_2ecompile_2erefcount_2efvArm(V);
V g_heff_2ecompile_2erefcount_2efvArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvArm_clo;
V g_heff_2ecompile_2erefcount_2eindexIn(V, V, V);
V g_heff_2ecompile_2erefcount_2eindexIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eindexIn_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ekeptFrom_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_clo;
V g_heff_2ecompile_2erefcount_2eothersW(V, V, V);
V g_heff_2ecompile_2erefcount_2eothersW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eothersW_clo;
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_clo;
V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_clo;
V g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531(V, V);
V g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_clo;
HeffT2 g_heff_2ecompile_2erefcount_2erebuiltV_24s1525876903x832315694_24cpr(V, V);
HeffT2 g_heff_2ecompile_2erefcount_2erebuiltVs_24s1306915676x1772197351_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_clo;
V g_heff_2ecompile_2erefcount_2ereuseArgs(V, V);
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ereusePrim_get(void);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24dps_24cpr(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseV_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseV_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2esameS(V, V);
V g_heff_2ecompile_2erefcount_2esameS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esameS_clo;
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(V, V);
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_clo;
V g_heff_2ecompile_2erefcount_2eslotBits(V);
V g_heff_2ecompile_2erefcount_2eslotBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eslotBits_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo;
V g_heff_2ecompile_2erefcount_2etokenK(V, V, V);
V g_heff_2ecompile_2erefcount_2etokenK_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etokenK_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etokenK_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2etokenRound(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etokenRound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etokenRound_clo;
V g_heff_2ecompile_2erefcount_2eunboxOf(V, V);
V g_heff_2ecompile_2erefcount_2eunboxOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxOf_clo;
V g_heff_2ecompile_2erefcount_2eupdatedIn(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eupdatedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eupdatedIn_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(V, V, V);
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1419545795x962553976(V, V, V);
V g_list_2eany_24s1419545795x962553976_entry(V self, V *a);
extern Clo g_list_2eany_24s1419545795x962553976_clo;
V g_list_2eany_24s1877524499x1789047582(V, V);
V g_list_2eany_24s1877524499x1789047582_entry(V self, V *a);
extern Clo g_list_2eany_24s1877524499x1789047582_clo;
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f1663632568x709545076(V, V, V, V);
V g_list_2efoldl_24f1663632568x709545076_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1663632568x709545076_clo;
V g_list_2efoldl_24s1050197499x1941129217(V, V);
V g_list_2efoldl_24s1050197499x1941129217_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1050197499x1941129217_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s421921225x565177679(V, V);
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a);
extern Clo g_list_2efoldl_24s421921225x565177679_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s788715611x32297348(V, V);
V g_list_2efoldl_24s788715611x32297348_entry(V self, V *a);
extern Clo g_list_2efoldl_24s788715611x32297348_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s689992630x418898235(V, V);
V g_list_2ekeepIf_24s689992630x418898235_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s689992630x418898235_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24tok1(V, V);
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24tok1_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s870182194x1066240094(V, V);
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
Clo g_heff_2ecompile_2erefcount_2elentThen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentThen_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2elentThen(V v_ce_240, V v_bi_241, V v_i_242, V v_e_243, V v_before_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2erefcount_2eelemI(v_i_242, v_bi_241));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    switch (heff_tag_of(v_e_243)) {
    case TAG_SVar: {
      V v_x_246 = heff_field(v_e_243, 0);
      HeffT2 v_t_247 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2410 = v_field_249;
          heff_drop(v_x_2410);
          return v_before_244;
        } else {
          heff_drop(v_field_249);
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_246), v_before_244});
        }
      }
    }
    case TAG_SGlobal: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SInt: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SFloat: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SStr: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SBytes: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SFixed: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SFloat32: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SPrimFn: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SLam: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_STag: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SRec: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SProj: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SPrim: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    default: return heff_nomatch(v_e_243);
    }
  } else {
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_t_245);
    return v_before_244;
  }
}
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2elentThen(a[0], a1, a[2], a3, a[4]); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2ereuseV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereuseV_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ereuseV(V v_ru_240, V v_n_241, V v_x3_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2erefcount_2ereuseV_24cpr(v_ru_240, v_n_241, v_x3_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ereuseV(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(V v_ru_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_TSeq: {
    V v_ss_243 = heff_field(v_x4_242, 0);
    V v_t_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TSeq = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), heff_dup(v_ss_243)));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_it1_248 = v_field_246;
      V v_ss2_249 = v_field_247;
      if ((heff_dup(v_it1_248) == NTAG(TAG_True))) {
        heff_drop(v_ru_240);
        heff_drop(v_n_241);
        heff_drop(v_ss_243);
        heff_drop(v_it1_248);
        return ((HeffT2){{NTAG(TAG_True), heff_tag_re_n(v_ru_24x4_242_24TSeq, TAG_TSeq, 2, 2ULL, (V[]){v_ss2_249, v_t_244})}});
      } else {
        heff_drop(v_it1_248);
        heff_drop(v_ss2_249);
        V v_cell_2410 = heff_tag_re_n(v_ru_24x4_242_24TSeq, TAG_TSeq, 2, 1ULL, (V[]){v_ss_243, heff_hole()});
        HeffT2 v_t_2411 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24dps_24cpr(v_ru_240, v_n_241, v_t_244, v_cell_2410));
        {
          V v_field_2412 = v_t_2411.f[0];
          V v_field_2413 = v_t_2411.f[1];
          V v_b_2414 = v_field_2412;
          V v__5f_2415 = v_field_2413;
          heff_drop(v__5f_2415);
          return ((HeffT2){{v_b_2414, v_cell_2410}});
        }
      }
    }
  }
  case TAG_TReturn: {
    V v_o_2416 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24TReturn = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_2417 = (g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(v_ru_240, v_n_241, v_o_2416));
    {
      V v_field_2418 = v_t_2417.f[0];
      V v_field_2419 = v_t_2417.f[1];
      V v_b_2420 = v_field_2418;
      V v_o2_2421 = v_field_2419;
      return ((HeffT2){{v_b_2420, heff_tag_at_n(v_ru_24x4_242_24TReturn, TAG_TReturn, 1, (V[]){v_o2_2421})}});
    }
  }
  case TAG_TLoop: {
    V v_vs_2422 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24TLoop = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_t_2424 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_vs_2422; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_vs_2422); r_; });
    switch (heff_tag_of(v_t_2424)) {
    case TAG_MkPair: {
      V v_b_2425 = heff_field(v_t_2424, 0);
      V v_vs2_2426 = heff_field(v_t_2424, 1);
      heff_take_n(v_t_2424, 3ULL, 2);
      return ((HeffT2){{v_b_2425, heff_tag_at_n(v_ru_24x4_242_24TLoop, TAG_TLoop, 1, (V[]){v_vs2_2426})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2424)}});
    }
  }
  case TAG_TIf: {
    V v_c_2427 = heff_field(v_x4_242, 0);
    V v_t_2428 = heff_field(v_x4_242, 1);
    V v_e_2429 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24TIf = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    HeffT2 v_t_2430 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_t_2428));
    {
      V v_field_2431 = v_t_2430.f[0];
      V v_field_2432 = v_t_2430.f[1];
      V v_bt_2433 = v_field_2431;
      V v_t2_2434 = v_field_2432;
      HeffT2 v_t_2435 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(v_ru_240, v_n_241, v_e_2429));
      {
        V v_field_2436 = v_t_2435.f[0];
        V v_field_2437 = v_t_2435.f[1];
        V v_be_2438 = v_field_2436;
        V v_e2_2439 = v_field_2437;
        V v_t_2440 = heff_bool(((heff_dup(v_bt_2433) == NTAG(TAG_True)) || (heff_dup(v_be_2438) == NTAG(TAG_True))));
        heff_drop(v_bt_2433);
        heff_drop(v_be_2438);
        return ((HeffT2){{v_t_2440, heff_tag_re_n(v_ru_24x4_242_24TIf, TAG_TIf, 3, 1ULL, (V[]){v_c_2427, v_t2_2434, v_e2_2439})}});
      }
    }
  }
  case TAG_TCase: {
    V v_v_2441 = heff_field(v_x4_242, 0);
    V v_arms_2442 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TCase = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_ps_2452 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam1, 1, 2, (V[]){v_ru_240, v_n_241}), v_arms_2442));
    V v_b_2453 = (g_list_2eany_24s910662703x1730636603(v_ps_2452));
    V v_as2_2454 = (g_list_2emap_24s1173914895x100384474(v_ps_2452));
    return ((HeffT2){{v_b_2453, heff_tag_re_n(v_ru_24x4_242_24TCase, TAG_TCase, 2, 1ULL, (V[]){v_v_2441, v_as2_2454})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam0(V self, V *args) {
  V v_v_2423 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_2423));
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam1(V self, V *args) {
  V v_x4_2443 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  switch (heff_tag_of(v_x4_2443)) {
  case TAG_MkArm: {
    V v_t_2444 = heff_field(v_x4_2443, 0);
    V v_vs_2445 = heff_field(v_x4_2443, 1);
    V v_b_2446 = heff_field(v_x4_2443, 2);
    V v_ru_24x4_2443_24MkArm = heff_take_reuse_n(v_x4_2443, 7ULL, 3);
    heff_clo_take(self, 2);
    HeffT2 v_t_2447 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(v_ru_240, v_n_241, v_b_2446));
    {
      V v_field_2448 = v_t_2447.f[0];
      V v_field_2449 = v_t_2447.f[1];
      V v_b_2450 = v_field_2448;
      V v_x_2451 = v_field_2449;
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2450, heff_tag_re_n(v_ru_24x4_2443_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2444, v_vs_2445, v_x_2451})});
    }
  }
  default: return heff_nomatch(v_x4_2443);
  }
}
Clo g_heff_2ecompile_2erefcount_2etokenK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etokenK_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2etokenK(V v_tk_240, V v_ru_241, V v_n_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2erefcount_2etokenK_24cpr(v_tk_240, v_ru_241, v_n_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_rec_n(2, shape_sts__tl, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2erefcount_2etokenK_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etokenK(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2etokenRound_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2etokenRound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etokenRound_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2etokenRound(V v_tk_240, V v_ru_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_TSeq: {
    V v_ss_244 = heff_field(v_x4_243, 0);
    V v_t_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24TSeq = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_acc_246 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_245, NTAG(TAG_Nil)));
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_244)));
    V v_t_248 = (g_list_2efoldl_24s2003609603x1707519208(v_acc_246, v_t_247));
    V v_x1_249 = ({ V a_0 = v_ru_241; V a_1 = v_t_248; V r_ = (g_list_2eany_24s1877524499x1789047582(a_0, a_1)); heff_drop(v_t_248); r_; });
    if (!(heff_dup(v_x1_249) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x4_243_24TSeq, 2);
      heff_drop(v_x1_249);
      HeffT2 v_t_2410 = (g_heff_2ecompile_2erefcount_2etokenK_24cpr(v_tk_240, v_ru_241, v_n_242));
      {
        V v_field_2412 = v_t_2410.f[1];
        heff_drop(v_t_2410.f[0]);
        return heff_tail(v_field_2412, 1, (V[]){heff_tag_n(TAG_TSeq, 2, (V[]){v_ss_244, v_t_245})});
      }
    } else {
      heff_drop(v_x1_249);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_244)));
      V v_t_2414 = (g_list_2efoldl_24s2003609603x1707519208(NTAG(TAG_Nil), v_t_2413));
      V v_t_2415 = ({ V a_0 = v_ru_241; V a_1 = v_t_2414; V r_ = (g_list_2eany_24s1877524499x1789047582(a_0, a_1)); heff_drop(v_t_2414); r_; });
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_tk_240);
        heff_drop(v_ru_241);
        heff_drop(v_n_242);
        heff_drop(v_t_2415);
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), heff_tag_re_n(v_ru_24x4_243_24TSeq, TAG_TSeq, 2, 3ULL, (V[]){v_ss_244, v_t_245})});
      } else {
        heff_drop(v_t_2415);
        V v_rt_2416 = heff_tr(g_heff_2ecompile_2erefcount_2etokenRound(v_tk_240, v_ru_241, v_n_242, v_t_245));
        V v_t_2419;
        switch (heff_tag_of(v_rt_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_dup(heff_field(v_rt_2416, 0));
          v_t_2419 = v_x_2417;
          break;
        }
        default: heff_nomatch(v_rt_2416);
        }
        V v_t_2422;
        switch (heff_tag_of(v_rt_2416)) {
        case TAG_MkPair: {
          V v_y_2421 = heff_field(v_rt_2416, 1);
          heff_take_n(v_rt_2416, 2ULL, 2);
          v_t_2422 = v_y_2421;
          break;
        }
        default: heff_nomatch(v_rt_2416);
        }
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, heff_tag_re_n(v_ru_24x4_243_24TSeq, TAG_TSeq, 2, 1ULL, (V[]){v_ss_244, v_t_2422})});
      }
    }
  }
  case TAG_TReturn: {
    V v_t_2424 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_x4_243, NTAG(TAG_Nil)));
    V v_t_2425 = ({ V a_0 = v_ru_241; V a_1 = v_t_2424; V r_ = (g_list_2eany_24s1877524499x1789047582(a_0, a_1)); heff_drop(v_t_2424); r_; });
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_tk_240);
      heff_drop(v_ru_241);
      heff_drop(v_n_242);
      heff_drop(v_t_2425);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_x4_243});
    } else {
      heff_drop(v_t_2425);
      HeffT2 v_t_2426 = (g_heff_2ecompile_2erefcount_2etokenK_24cpr(v_tk_240, v_ru_241, v_n_242));
      {
        V v_field_2428 = v_t_2426.f[1];
        heff_drop(v_t_2426.f[0]);
        return heff_tail(v_field_2428, 1, (V[]){v_x4_243});
      }
    }
  }
  case TAG_TLoop: {
    V v_t_2430 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_x4_243, NTAG(TAG_Nil)));
    V v_t_2431 = ({ V a_0 = v_ru_241; V a_1 = v_t_2430; V r_ = (g_list_2eany_24s1877524499x1789047582(a_0, a_1)); heff_drop(v_t_2430); r_; });
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop(v_tk_240);
      heff_drop(v_ru_241);
      heff_drop(v_n_242);
      heff_drop(v_t_2431);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_x4_243});
    } else {
      heff_drop(v_t_2431);
      HeffT2 v_t_2432 = (g_heff_2ecompile_2erefcount_2etokenK_24cpr(v_tk_240, v_ru_241, v_n_242));
      {
        V v_field_2434 = v_t_2432.f[1];
        heff_drop(v_t_2432.f[0]);
        return heff_tail(v_field_2434, 1, (V[]){v_x4_243});
      }
    }
  }
  case TAG_TIf: {
    V v_c_2435 = heff_field(v_x4_243, 0);
    V v_a_2436 = heff_field(v_x4_243, 1);
    V v_b_2437 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24TIf = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    V v_acc_2438 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_b_2437, NTAG(TAG_Nil)));
    V v_acc_2439 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_a_2436, v_acc_2438));
    V v_t_2440 = heff_tr(g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(v_c_2435, v_acc_2439));
    V v_x1_2441 = ({ V a_0 = v_ru_241; V a_1 = v_t_2440; V r_ = (g_list_2eany_24s1877524499x1789047582(a_0, a_1)); heff_drop(v_t_2440); r_; });
    if (!(heff_dup(v_x1_2441) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x4_243_24TIf, 3);
      heff_drop(v_x1_2441);
      HeffT2 v_t_2442 = (g_heff_2ecompile_2erefcount_2etokenK_24cpr(v_tk_240, v_ru_241, v_n_242));
      {
        V v_field_2444 = v_t_2442.f[1];
        heff_drop(v_t_2442.f[0]);
        return heff_tail(v_field_2444, 1, (V[]){heff_tag_n(TAG_TIf, 3, (V[]){v_c_2435, v_a_2436, v_b_2437})});
      }
    } else {
      heff_drop(v_x1_2441);
      V v_ra_2445 = heff_tr(g_heff_2ecompile_2erefcount_2etokenRound(heff_dup(v_tk_240), heff_dup(v_ru_241), heff_dup(v_n_242), v_a_2436));
      V v_rb_2446 = heff_tr(g_heff_2ecompile_2erefcount_2etokenRound(v_tk_240, v_ru_241, v_n_242, v_b_2437));
      V v_t_2449;
      switch (heff_tag_of(v_ra_2445)) {
      case TAG_MkPair: {
        V v_x_2447 = heff_dup(heff_field(v_ra_2445, 0));
        v_t_2449 = v_x_2447;
        break;
      }
      default: heff_nomatch(v_ra_2445);
      }
      V v_t_2452;
      if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
        heff_drop(v_t_2449);
        v_t_2452 = NTAG(TAG_True);
      } else {
        heff_drop(v_t_2449);
        switch (heff_tag_of(v_rb_2446)) {
        case TAG_MkPair: {
          V v_x_2450 = heff_dup(heff_field(v_rb_2446, 0));
          v_t_2452 = v_x_2450;
          break;
        }
        default: heff_nomatch(v_rb_2446);
        }
      }
      V v_t_2455;
      switch (heff_tag_of(v_ra_2445)) {
      case TAG_MkPair: {
        V v_y_2454 = heff_field(v_ra_2445, 1);
        heff_take_n(v_ra_2445, 2ULL, 2);
        v_t_2455 = v_y_2454;
        break;
      }
      default: heff_nomatch(v_ra_2445);
      }
      V v_t_2458;
      switch (heff_tag_of(v_rb_2446)) {
      case TAG_MkPair: {
        V v_y_2457 = heff_field(v_rb_2446, 1);
        heff_take_n(v_rb_2446, 2ULL, 2);
        v_t_2458 = v_y_2457;
        break;
      }
      default: heff_nomatch(v_rb_2446);
      }
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2452, heff_tag_re_n(v_ru_24x4_243_24TIf, TAG_TIf, 3, 1ULL, (V[]){v_c_2435, v_t_2455, v_t_2458})});
    }
  }
  case TAG_TCase: {
    V v_v_2459 = heff_field(v_x4_243, 0);
    V v_arms_2460 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24TCase = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2461 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2460)));
    V v_acc_2462 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2461; V r_ = (g_list_2efoldl_24s788715611x32297348(a_0, a_1)); heff_drop(v_t_2461); r_; });
    V v_t_2463 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_v_2459), v_acc_2462));
    V v_x1_2464 = ({ V a_0 = v_ru_241; V a_1 = v_t_2463; V r_ = (g_list_2eany_24s1877524499x1789047582(a_0, a_1)); heff_drop(v_t_2463); r_; });
    if (!(heff_dup(v_x1_2464) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x4_243_24TCase, 2);
      heff_drop(v_x1_2464);
      HeffT2 v_t_2465 = (g_heff_2ecompile_2erefcount_2etokenK_24cpr(v_tk_240, v_ru_241, v_n_242));
      {
        V v_field_2467 = v_t_2465.f[1];
        heff_drop(v_t_2465.f[0]);
        return heff_tail(v_field_2467, 1, (V[]){heff_tag_n(TAG_TCase, 2, (V[]){v_v_2459, v_arms_2460})});
      }
    } else {
      heff_drop(v_x1_2464);
      V v_rs_2475 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2etokenRound_lam0, 1, 3, (V[]){v_tk_240, v_ru_241, v_n_242}), v_arms_2460));
      V v_t_2476 = (g_list_2eany_24s910662703x1730636603(v_rs_2475));
      V v_t_2477 = (g_list_2emap_24s1173914895x100384474(v_rs_2475));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2476, heff_tag_re_n(v_ru_24x4_243_24TCase, TAG_TCase, 2, 1ULL, (V[]){v_v_2459, v_t_2477})});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erefcount_2etokenRound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etokenRound(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2etokenRound_lam0(V self, V *args) {
  V v_arm_2468 = args[0];
  V v_tk_240 = heff_env(self)[0];
  V v_ru_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  switch (heff_tag_of(v_arm_2468)) {
  case TAG_MkArm: {
    V v_t_2469 = heff_field(v_arm_2468, 0);
    V v_vs_2470 = heff_field(v_arm_2468, 1);
    V v_b_2471 = heff_field(v_arm_2468, 2);
    V v_ru_24arm_2468_24MkArm = heff_take_reuse_n(v_arm_2468, 7ULL, 3);
    heff_clo_take(self, 3);
    V v_x3_2472 = heff_tr(g_heff_2ecompile_2erefcount_2etokenRound(v_tk_240, v_ru_241, v_n_242, v_b_2471));
    switch (heff_tag_of(v_x3_2472)) {
    case TAG_MkPair: {
      V v_b_2473 = heff_field(v_x3_2472, 0);
      V v_x_2474 = heff_field(v_x3_2472, 1);
      V v_ru_24x3_2472_24MkPair = heff_take_reuse_n(v_x3_2472, 3ULL, 2);
      return heff_tag_re_n(v_ru_24x3_2472_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_b_2473, heff_tag_re_n(v_ru_24arm_2468_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2469, v_vs_2470, v_x_2474})});
    }
    default: return heff_nomatch(v_x3_2472);
    }
  }
  default: return heff_nomatch(v_arm_2468);
  }
}
Clo g_heff_2ecompile_2erefcount_2eothersW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eothersW_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eothersW(V v_x_240, V v_l_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_IVal: {
      V v_x311_245 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24IVal = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_245)) {
      case TAG_SVar: {
        V v_y_246 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        if (!heff_strEq_c_lent(v_x_240, v_y_246, 0)) {
          heff_drop(v_y_246);
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_rest_244;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        } else {
          heff_drop(v_rest_244);
          heff_drop(v_y_246);
          return NTAG(TAG_False);
        }
      }
      case TAG_SGlobal: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SInt: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat: {
        heff_take_na(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SStr: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SBytes: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFixed: {
        heff_take_n(v_x311_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SLam: {
        V v_x3112_2417 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        switch (heff_tag_of(v_x3112_2417)) {
        case TAG_MkBlock: {
          V v_t_2418 = heff_field(v_x3112_2417, 0);
          heff_take_n(v_x3112_2417, 1ULL, 1);
          V v_ps_2419 = ({ V a_0 = v_t_2418; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2418); r_; });
          V v_t_2420 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_240; V a_3 = v_ps_2419; V r_ = (g_list_2efoldl_24f1663632568x709545076(a_0, a_1, a_2, a_3)); heff_drop(v_ps_2419); r_; });
          if (heff_intEq_c(v_t_2420, MK_INT(0LL))) {
            V t_0 = v_x_240;
            V t_1 = v_l_241;
            V t_2 = v_rest_244;
            v_x_240 = t_0;
            v_l_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          } else {
            heff_drop(v_rest_244);
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_x3112_2417);
        }
      }
      case TAG_STag: {
        V v_argv_2422 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2422));
        V v_t_2425 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2424));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2425;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SRec: {
        V v_fs_2426 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V v_t_2428 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2426));
        V v_t_2429 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2428));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2429;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SProj: {
        V v_e_2430 = heff_field(v_x311_245, 0);
        V v_l2_2431 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 3ULL, 4);
        V v_t_2457;
        switch (heff_tag_of(v_e_2430)) {
        case TAG_SVar: {
          V v_y_2434 = heff_dup(heff_field(v_e_2430, 0));
          v_t_2457 = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2434, 0));
          heff_drop(v_y_2434);
          break;
        }
        case TAG_SGlobal: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SInt: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SFloat: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SStr: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SBytes: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SFixed: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SFloat32: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SPrimFn: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SLam: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_STag: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SRec: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SProj: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SPrim: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_e_2430);
        }
        if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop_cell(v_ru_24x31_243_24IVal, 1);
          heff_drop(v_e_2430);
          heff_drop(v_t_2457);
          if (!heff_strEq_c_lent(v_l_241, v_l2_2431, 0)) {
            heff_drop(v_l2_2431);
            V t_0 = v_x_240;
            V t_1 = v_l_241;
            V t_2 = v_rest_244;
            v_x_240 = t_0;
            v_l_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          } else {
            heff_drop(v_rest_244);
            heff_drop(v_l2_2431);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop(v_l2_2431);
          heff_drop(v_t_2457);
          V v_t_2458 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24IVal, TAG_IVal, 1, (V[]){v_e_2430}), v_rest_244});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_2458;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
      case TAG_SPrim: {
        V v_x3111_2459 = heff_field(v_x311_245, 0);
        V v_x3112_2460 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        switch (heff_tag_of(v_x3111_2459)) {
        case TAG_Reuse: {
          switch (heff_tag_of(v_x3112_2460)) {
          case TAG_Nil: {
            V v_t_2461 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x3112_2460));
            V v_t_2462 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2461));
            V t_0 = v_x_240;
            V t_1 = v_l_241;
            V t_2 = v_t_2462;
            v_x_240 = t_0;
            v_l_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          }
          case TAG_Cons: {
            V v_x31121_2463 = heff_dup(heff_field(v_x3112_2460, 0));
            V v_x31122_2464 = heff_dup(heff_field(v_x3112_2460, 1));
            switch (heff_tag_of(v_x31121_2463)) {
            case TAG_SVar: {
              heff_take_n(v_x31121_2463, 0ULL, 1);
              switch (heff_tag_of(v_x31122_2464)) {
              case TAG_Nil: {
                V v_t_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x3112_2460));
                V v_t_2467 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2466));
                V t_0 = v_x_240;
                V t_1 = v_l_241;
                V t_2 = v_t_2467;
                v_x_240 = t_0;
                v_l_241 = t_1;
                v_x3_242 = t_2;
                goto top;
              }
              case TAG_Cons: {
                V v_x311221_2468 = heff_field(v_x31122_2464, 0);
                V v_x311222_2469 = heff_field(v_x31122_2464, 1);
                heff_take_n(v_x31122_2464, 3ULL, 2);
                switch (heff_tag_of(v_x311221_2468)) {
                case TAG_SRec: {
                  V v_fs_2470 = heff_field(v_x311221_2468, 0);
                  heff_take_n(v_x311221_2468, 1ULL, 2);
                  switch (heff_tag_of(v_x311222_2469)) {
                  case TAG_Nil: {
                    heff_drop_tag(v_x3112_2460, 2);
                    V v_t_2472 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2470));
                    V v_t_2473 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2472));
                    V t_0 = v_x_240;
                    V t_1 = v_l_241;
                    V t_2 = v_t_2473;
                    v_x_240 = t_0;
                    v_l_241 = t_1;
                    v_x3_242 = t_2;
                    goto top;
                  }
                  case TAG_Cons: {
                    heff_take_n(v_x311222_2469, 0ULL, 2);
                    heff_drop(v_fs_2470);
                    V v_t_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x3112_2460));
                    V v_t_2477 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2476));
                    V t_0 = v_x_240;
                    V t_1 = v_l_241;
                    V t_2 = v_t_2477;
                    v_x_240 = t_0;
                    v_l_241 = t_1;
                    v_x3_242 = t_2;
                    goto top;
                  }
                  default: return heff_nomatch(v_x311222_2469);
                  }
                }
                default: {
                  heff_drop(v_x311221_2468);
                  heff_drop(v_x311222_2469);
                  V v_t_2478 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x3112_2460));
                  V v_t_2479 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2478));
                  V t_0 = v_x_240;
                  V t_1 = v_l_241;
                  V t_2 = v_t_2479;
                  v_x_240 = t_0;
                  v_l_241 = t_1;
                  v_x3_242 = t_2;
                  goto top;
                }
                }
              }
              default: return heff_nomatch(v_x31122_2464);
              }
            }
            default: {
              heff_drop(v_x31121_2463);
              heff_drop(v_x31122_2464);
              V v_t_2480 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x3112_2460));
              V v_t_2481 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2480));
              V t_0 = v_x_240;
              V t_1 = v_l_241;
              V t_2 = v_t_2481;
              v_x_240 = t_0;
              v_l_241 = t_1;
              v_x3_242 = t_2;
              goto top;
            }
            }
          }
          default: return heff_nomatch(v_x3112_2460);
          }
        }
        default: {
          heff_drop(v_x3111_2459);
          V v_t_2482 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x3112_2460));
          V v_t_2483 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2482));
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_2483;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        }
      }
      default: return heff_nomatch(v_x311_245);
      }
    }
    case TAG_IOp: {
      V v_x311_2484 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24IOp = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2484)) {
      case TAG_OSimple: {
        V v_v_2485 = heff_field(v_x311_2484, 0);
        heff_take_n(v_x311_2484, 1ULL, 1);
        V v_t_2486 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24IOp, TAG_IVal, 1, (V[]){v_v_2485}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2486;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OCall: {
        V v_argv_2488 = heff_field(v_x311_2484, 1);
        heff_take_n(v_x311_2484, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IOp, 1);
        V v_t_2489 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2488));
        V v_t_2490 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2489));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2490;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OApply: {
        V v_f_2491 = heff_field(v_x311_2484, 0);
        V v_argv_2492 = heff_field(v_x311_2484, 1);
        heff_take_n(v_x311_2484, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24IOp, 1);
        V v_t_2493 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2491, v_argv_2492})));
        V v_t_2494 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2493));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2494;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OPrim: {
        V v_argv_2496 = heff_field(v_x311_2484, 1);
        heff_take_n(v_x311_2484, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IOp, 1);
        V v_t_2497 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2496));
        V v_t_2498 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2497));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2498;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IOp, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OBool: {
        V v_c_2499 = heff_field(v_x311_2484, 0);
        heff_take_n(v_x311_2484, 1ULL, 1);
        V v_t_24100 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24IOp, TAG_ICond, 1, (V[]){v_c_2499}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24100;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_2484);
      }
    }
    case TAG_ICond: {
      V v_x311_24101 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ICond = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24101)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PRel: {
        V v_a_24103 = heff_field(v_x311_24101, 1);
        V v_b_24104 = heff_field(v_x311_24101, 2);
        heff_take_n(v_x311_24101, 6ULL, 3);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_24105 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_b_24104}), v_rest_244});
        V v_t_24106 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_a_24103}), v_t_24105});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24106;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PBool: {
        V v_v_24107 = heff_field(v_x311_24101, 0);
        V v_ru_24x311_24101_24PBool = heff_take_reuse_n(v_x311_24101, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_24108 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x311_24101_24PBool, TAG_IVal, 1, (V[]){v_v_24107}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24108;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PNot: {
        V v_c_24109 = heff_field(v_x311_24101, 0);
        heff_take_n(v_x311_24101, 1ULL, 1);
        V v_t_24110 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_c_24109}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24110;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PIf: {
        V v_a_24111 = heff_field(v_x311_24101, 0);
        V v_b_24112 = heff_field(v_x311_24101, 1);
        V v_c_24113 = heff_field(v_x311_24101, 2);
        heff_take_n(v_x311_24101, 7ULL, 3);
        V v_t_24114 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_c_24113}), v_rest_244});
        V v_t_24115 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_b_24112}), v_t_24114});
        V v_t_24116 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_24111}), v_t_24115});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24116;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PLet: {
        V v_o_24118 = heff_field(v_x311_24101, 1);
        V v_c_24119 = heff_field(v_x311_24101, 2);
        heff_take_n(v_x311_24101, 6ULL, 3);
        V v_t_24120 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_c_24119}), v_rest_244});
        V v_t_24121 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24118}), v_t_24120});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24121;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_24101);
      }
    }
    case TAG_ISts: {
      V v_x311_24122 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ISts = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24122)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ISts, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_Cons: {
        V v_x3111_24123 = heff_field(v_x311_24122, 0);
        V v_ss_24124 = heff_field(v_x311_24122, 1);
        V v_ru_24x311_24122_24Cons = heff_take_reuse_n(v_x311_24122, 3ULL, 2);
        switch (heff_tag_of(v_x3111_24123)) {
        case TAG_SLet: {
          V v_o_24126 = heff_field(v_x3111_24123, 1);
          heff_take_n(v_x3111_24123, 2ULL, 2);
          V v_t_24127 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_24124}), v_rest_244});
          V v_t_24128 = heff_tag_at_n(v_ru_24x311_24122_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24126}), v_t_24127});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24128;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SOnce: {
          V v_o_24130 = heff_field(v_x3111_24123, 1);
          heff_take_n(v_x3111_24123, 2ULL, 2);
          V v_t_24131 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_24124}), v_rest_244});
          V v_t_24132 = heff_tag_at_n(v_ru_24x311_24122_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24130}), v_t_24131});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24132;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SDecl: {
          heff_take_n(v_x3111_24123, 0ULL, 1);
          heff_drop_cell(v_ru_24x311_24122_24Cons, 2);
          V v_t_24134 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_24124}), v_rest_244});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24134;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SSet: {
          V v_o_24136 = heff_field(v_x3111_24123, 1);
          heff_take_n(v_x3111_24123, 2ULL, 2);
          V v_t_24137 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_24124}), v_rest_244});
          V v_t_24138 = heff_tag_at_n(v_ru_24x311_24122_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24136}), v_t_24137});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24138;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SIf: {
          V v_c_24139 = heff_field(v_x3111_24123, 0);
          V v_ts_24140 = heff_field(v_x3111_24123, 1);
          V v_fs_24141 = heff_field(v_x3111_24123, 2);
          heff_take_n(v_x3111_24123, 7ULL, 3);
          V v_t_24142 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_24124}), v_rest_244});
          V v_t_24143 = heff_tag_at_n(v_ru_24x311_24122_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_fs_24141}), v_t_24142});
          V v_t_24144 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_24140}), v_t_24143});
          V v_t_24145 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24139}), v_t_24144});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24145;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SCase: {
          V v_v_24146 = heff_field(v_x3111_24123, 0);
          V v_arms_24147 = heff_field(v_x3111_24123, 1);
          heff_take_n(v_x3111_24123, 3ULL, 2);
          V v_t_24148 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24147));
          V v_t_24149 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_24124}), v_rest_244});
          V v_t_24150 = (g_list_2efoldl_24s1104809983x118204267(v_t_24149, v_t_24148));
          V v_t_24151 = heff_tag_at_n(v_ru_24x311_24122_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24146}), v_t_24150});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24151;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x3111_24123);
        }
      }
      default: return heff_nomatch(v_x311_24122);
      }
    }
    case TAG_ITl: {
      V v_x311_24152 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ITl = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24152)) {
      case TAG_TSeq: {
        V v_ss_24153 = heff_field(v_x311_24152, 0);
        V v_t_24154 = heff_field(v_x311_24152, 1);
        V v_ru_24x311_24152_24TSeq = heff_take_reuse_n(v_x311_24152, 3ULL, 2);
        V v_t_24155 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ITl, 1, (V[]){v_t_24154}), v_rest_244});
        V v_t_24156 = heff_tag_at_n(v_ru_24x311_24152_24TSeq, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24153}), v_t_24155});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24156;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TReturn: {
        V v_o_24157 = heff_field(v_x311_24152, 0);
        V v_ru_24x311_24152_24TReturn = heff_take_reuse_n(v_x311_24152, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24158 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x311_24152_24TReturn, TAG_IOp, 1, (V[]){v_o_24157}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24158;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TLoop: {
        V v_vs_24159 = heff_field(v_x311_24152, 0);
        heff_take_n(v_x311_24152, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24160 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_24159));
        V v_t_24161 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_24160));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24161;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TIf: {
        V v_c_24162 = heff_field(v_x311_24152, 0);
        V v_t_24163 = heff_field(v_x311_24152, 1);
        V v_e_24164 = heff_field(v_x311_24152, 2);
        heff_take_n(v_x311_24152, 7ULL, 3);
        V v_t_24165 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ITl, 1, (V[]){v_e_24164}), v_rest_244});
        V v_t_24166 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_24163}), v_t_24165});
        V v_t_24167 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24162}), v_t_24166});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24167;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TCase: {
        V v_v_24168 = heff_field(v_x311_24152, 0);
        V v_arms_24169 = heff_field(v_x311_24152, 1);
        heff_take_n(v_x311_24152, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24170 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24169));
        V v_t_24171 = (g_list_2efoldl_24s421921225x565177679(v_rest_244, v_t_24170));
        V v_t_24172 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24168}), v_t_24171});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24172;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_24152);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2eothersW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eothersW(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(V v_ce_240, V v_live_241, V v_e_242, V v_l_243, V v_t_244, V v_n_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    heff_drop(v_n_245);
    V v_t_247 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, NTAG(TAG_RepV), v_e_242));
    return heff_tag_n(TAG_RGetLabel, 2, (V[]){v_t_247, v_l_243});
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_x8_246, 0);
    V v_ru_24x8_246_24Just = heff_take_reuse_n(v_x8_246, 1ULL, 1);
    V v_may_249 = (g_heff_2ecompile_2erepr_2emayBeFlat(v_t_244));
    V v_ts_2410 = heff_dup(heff_rfield(v_ce_240, 9));
    V v_live_2411 = heff_dup(v_live_241);
    V v_e_2412 = heff_dup(v_e_242);
    V v_l_2413 = v_l_243;
    V v_i_2414 = heff_dup(v_i_248);
    V v_x8_2440;
    switch (heff_tag_of(v_e_2412)) {
    case TAG_SVar: {
      V v_x_2415 = heff_field(v_e_2412, 0);
      heff_take_n(v_e_2412, 1ULL, 1);
      V v_t_2416 = ({ V a_0 = v_x_2415; V a_1 = v_live_2411; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_live_2411); r_; });
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        V v_t_2417 = ({ V a_0 = v_x_2415; V a_1 = v_l_2413; V a_2 = v_ts_2410; V r_ = (g_list_2eany_24s1419545795x962553976(a_0, a_1, a_2)); heff_drop(v_l_2413); heff_drop(v_ts_2410); r_; });
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop(v_t_2417);
          v_x8_2440 = heff_tag_at_n(v_ru_24x8_246_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_RTakeField, 2, (V[]){v_x_2415, v_i_2414})});
        } else {
          heff_drop_cell(v_ru_24x8_246_24Just, 1);
          heff_drop(v_i_2414);
          heff_drop(v_x_2415);
          heff_drop(v_t_2417);
          v_x8_2440 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        heff_drop(v_ts_2410);
        heff_drop(v_l_2413);
        heff_drop(v_i_2414);
        heff_drop(v_x_2415);
        heff_drop(v_t_2416);
        v_x8_2440 = NTAG(TAG_Nothing);
      }
      break;
    }
    case TAG_SGlobal: {
      heff_take_n(v_e_2412, 0ULL, 1);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_ts_2410);
      heff_drop(v_live_2411);
      heff_drop(v_l_2413);
      heff_drop(v_i_2414);
      v_x8_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SInt: {
      heff_take_n(v_e_2412, 0ULL, 1);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_ts_2410);
      heff_drop(v_live_2411);
      heff_drop(v_l_2413);
      heff_drop(v_i_2414);
      v_x8_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat: {
      heff_take_na(v_e_2412, 0ULL, 1);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_ts_2410);
      heff_drop(v_live_2411);
      heff_drop(v_l_2413);
      heff_drop(v_i_2414);
      v_x8_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SStr: {
      heff_take_n(v_e_2412, 0ULL, 1);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_ts_2410);
      heff_drop(v_live_2411);
      heff_drop(v_l_2413);
      heff_drop(v_i_2414);
      v_x8_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SBytes: {
      heff_take_n(v_e_2412, 0ULL, 1);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_ts_2410);
      heff_drop(v_live_2411);
      heff_drop(v_l_2413);
      heff_drop(v_i_2414);
      v_x8_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFixed: {
      heff_take_n(v_e_2412, 0ULL, 2);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_ts_2410);
      heff_drop(v_live_2411);
      heff_drop(v_l_2413);
      heff_drop(v_i_2414);
      v_x8_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat32: {
      heff_take_na(v_e_2412, 0ULL, 1);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_ts_2410);
      heff_drop(v_live_2411);
      heff_drop(v_l_2413);
      heff_drop(v_i_2414);
      v_x8_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrimFn: {
      heff_take_n(v_e_2412, 0ULL, 1);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_ts_2410);
      heff_drop(v_live_2411);
      heff_drop(v_l_2413);
      heff_drop(v_i_2414);
      v_x8_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      heff_take_n(v_e_2412, 0ULL, 2);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_ts_2410);
      heff_drop(v_live_2411);
      heff_drop(v_l_2413);
      heff_drop(v_i_2414);
      v_x8_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      heff_take_n(v_e_2412, 0ULL, 3);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_ts_2410);
      heff_drop(v_live_2411);
      heff_drop(v_l_2413);
      heff_drop(v_i_2414);
      v_x8_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      heff_take_n(v_e_2412, 0ULL, 2);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_ts_2410);
      heff_drop(v_live_2411);
      heff_drop(v_l_2413);
      heff_drop(v_i_2414);
      v_x8_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      heff_take_n(v_e_2412, 0ULL, 4);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_ts_2410);
      heff_drop(v_live_2411);
      heff_drop(v_l_2413);
      heff_drop(v_i_2414);
      v_x8_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrim: {
      heff_take_n(v_e_2412, 0ULL, 2);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_ts_2410);
      heff_drop(v_live_2411);
      heff_drop(v_l_2413);
      heff_drop(v_i_2414);
      v_x8_2440 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_2412);
    }
    switch (heff_tag_of(v_x8_2440)) {
    case TAG_Nothing: {
      V v_ce_2441 = v_ce_240;
      V v_live_2442 = v_live_241;
      V v_e_2443 = v_e_242;
      V v_i_2444 = v_i_248;
      V v_n_2445 = v_n_245;
      V v_may_2446 = v_may_249;
      V v_ce_2447 = v_ce_2441;
      V v_live_2448 = v_live_2442;
      V v_e_2449 = heff_dup(v_e_2443);
      V v_i_2450 = v_i_2444;
      V v_n_2451 = v_n_2445;
      V v_may_2452 = v_may_2446;
      V v_x8_2476;
      switch (heff_tag_of(v_e_2443)) {
      case TAG_SVar: {
        V v_x_2453 = heff_dup(heff_field(v_e_2443, 0));
        v_x8_2476 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2453});
        break;
      }
      case TAG_SGlobal: {
        v_x8_2476 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        v_x8_2476 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_x8_2476 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_x8_2476 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_x8_2476 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_x8_2476 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_x8_2476 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_x8_2476 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_x8_2476 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_x8_2476 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_x8_2476 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_x8_2476 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_x8_2476 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_2443);
      }
      V v_x9_24100;
      switch (heff_tag_of(v_e_2443)) {
      case TAG_SVar: {
        heff_take_n(v_e_2443, 0ULL, 1);
        v_x9_24100 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SGlobal: {
        V v_g_2478 = heff_field(v_e_2443, 0);
        V v_ru_24e_2443_24SGlobal = heff_take_reuse_n(v_e_2443, 1ULL, 1);
        v_x9_24100 = heff_tag_at_n(v_ru_24e_2443_24SGlobal, TAG_Just, 1, (V[]){v_g_2478});
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_e_2443, 0ULL, 1);
        v_x9_24100 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_e_2443, 0ULL, 1);
        v_x9_24100 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_e_2443, 0ULL, 1);
        v_x9_24100 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_e_2443, 0ULL, 1);
        v_x9_24100 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_e_2443, 0ULL, 2);
        v_x9_24100 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_e_2443, 0ULL, 1);
        v_x9_24100 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_e_2443, 0ULL, 1);
        v_x9_24100 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_e_2443, 0ULL, 2);
        v_x9_24100 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_e_2443, 0ULL, 3);
        v_x9_24100 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_e_2443, 0ULL, 2);
        v_x9_24100 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_e_2443, 0ULL, 4);
        v_x9_24100 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_e_2443, 0ULL, 2);
        v_x9_24100 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_2443);
      }
      switch (heff_tag_of(v_x8_2476)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_x9_24100)) {
        case TAG_Nothing: {
          heff_drop(v_may_2452);
          V v_t_24101 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_2447, v_live_2448, NTAG(TAG_RepV), v_e_2449));
          return heff_tag_n(TAG_RGetN, 3, (V[]){v_t_24101, v_i_2450, v_n_2451});
        }
        case TAG_Just: {
          V v_g_24102 = heff_field(v_x9_24100, 0);
          V v_ru_24x9_24100_24Just = heff_take_reuse_n(v_x9_24100, 1ULL, 1);
          heff_drop_rec(v_ce_2447, 17);
          heff_drop(v_live_2448);
          heff_drop(v_e_2449);
          heff_drop(v_n_2451);
          if ((heff_dup(v_may_2452) == NTAG(TAG_True))) {
            heff_drop(v_may_2452);
            return heff_tag_n(TAG_RFieldV, 2, (V[]){heff_tag_at_n(v_ru_24x9_24100_24Just, TAG_RGetRaw, 1, (V[]){v_g_24102}), v_i_2450});
          } else {
            heff_drop(v_may_2452);
            V v_t_24103 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24x9_24100_24Just, TAG_RGetRaw, 1, (V[]){v_g_24102}), v_i_2450});
            return heff_tag_n(TAG_RDupE, 1, (V[]){v_t_24103});
          }
        }
        default: return heff_nomatch(v_x9_24100);
        }
      }
      case TAG_Just: {
        V v_x_24104 = heff_field(v_x8_2476, 0);
        V v_ru_24x8_2476_24Just = heff_take_reuse_n(v_x8_2476, 1ULL, 1);
        heff_drop(v_e_2449);
        heff_drop(v_x9_24100);
        V v_t_24105 = ({ V a_0 = v_x_24104; V a_1 = v_live_2448; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_live_2448); r_; });
        if ((heff_dup(v_t_24105) == NTAG(TAG_True))) {
          heff_drop_rec(v_ce_2447, 17);
          heff_drop(v_n_2451);
          heff_drop(v_t_24105);
          if ((heff_dup(v_may_2452) == NTAG(TAG_True))) {
            heff_drop(v_may_2452);
            return heff_tag_n(TAG_RFieldV, 2, (V[]){heff_tag_at_n(v_ru_24x8_2476_24Just, TAG_RLocal, 1, (V[]){v_x_24104}), v_i_2450});
          } else {
            heff_drop(v_may_2452);
            V v_t_24106 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24x8_2476_24Just, TAG_RLocal, 1, (V[]){v_x_24104}), v_i_2450});
            return heff_tag_n(TAG_RDupE, 1, (V[]){v_t_24106});
          }
        } else {
          heff_drop(v_t_24105);
          V v_t_24107 = ({ V a_0 = v_x_24104; V b_1 = heff_get_n(v_ce_2447, 6, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          if ((heff_dup(v_t_24107) == NTAG(TAG_True))) {
            heff_drop(v_n_2451);
            heff_drop(v_t_24107);
            if ((heff_dup(v_may_2452) == NTAG(TAG_True))) {
              heff_drop(v_may_2452);
              return heff_tag_n(TAG_RFieldV, 2, (V[]){heff_tag_at_n(v_ru_24x8_2476_24Just, TAG_RLocal, 1, (V[]){v_x_24104}), v_i_2450});
            } else {
              heff_drop(v_may_2452);
              V v_t_24108 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24x8_2476_24Just, TAG_RLocal, 1, (V[]){v_x_24104}), v_i_2450});
              return heff_tag_n(TAG_RDupE, 1, (V[]){v_t_24108});
            }
          } else {
            heff_drop(v_may_2452);
            heff_drop(v_t_24107);
            return heff_tag_n(TAG_RGetN, 3, (V[]){heff_tag_at_n(v_ru_24x8_2476_24Just, TAG_RLocal, 1, (V[]){v_x_24104}), v_i_2450, v_n_2451});
          }
        }
      }
      default: return heff_nomatch(v_x8_2476);
      }
    }
    case TAG_Just: {
      V v_t_24109 = heff_field(v_x8_2440, 0);
      heff_take_n(v_x8_2440, 1ULL, 1);
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_live_241);
      heff_drop(v_e_242);
      heff_drop(v_n_245);
      heff_drop(v_i_248);
      heff_drop(v_may_249);
      return v_t_24109;
    }
    default: return heff_nomatch(v_x8_2440);
    }
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(a[0], a[1], a[2], a[3], a4, a[5], a[6]); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x4_242, 0);
    V v_es_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_244)));
    V v_t_246 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_245));
    V v_live_247 = (g_prelude_2e_2b_2b(v_t_246, heff_dup(v_live_241)));
    V v_t_248 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_247, NTAG(TAG_RepV), v_e_243));
    V v_cell_249 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(v_ce_240, v_live_241, v_es_244, v_cell_249));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(V v_ce_240, V v_live_241, V v_x4_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_242, 0);
    V v_es_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_245)));
    V v_t_247 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_246));
    V v_live_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_live_241)));
    V v_t_249 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_248, NTAG(TAG_RepV), v_e_244));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2410);
    V t_0 = v_ce_240;
    V t_1 = v_live_241;
    V t_2 = v_es_245;
    V t_3 = v_u_2411;
    v_ce_240 = t_0;
    v_live_241 = t_1;
    v_x4_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SVar: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SVar = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_ce_240, 10), v_x_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop_rec(v_ce_240, 17);
        heff_drop(v_live_241);
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RLocal, 1, (V[]){v_x_243});
      } else {
        heff_drop(v_field_246);
        V v_t_248 = ({ V a_0 = v_x_243; V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_t_248);
          return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RDup, 1, (V[]){v_x_243});
        } else {
          heff_drop(v_t_248);
          V v_t_249 = ({ V a_0 = v_x_243; V b_1 = heff_get_n(v_ce_240, 6, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RDup, 1, (V[]){v_x_243});
          } else {
            heff_drop(v_t_249);
            return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RLocal, 1, (V[]){v_x_243});
          }
        }
      }
    }
  }
  case TAG_SGlobal: {
    V v_g_2410 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SGlobal = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_live_241);
    HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_ce_240, 0, 17); V a_1 = v_g_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_x_2414 = v_field_2413;
        heff_drop(v_x_2414);
        return heff_tag_at_n(v_ru_24x4_242_24SGlobal, TAG_RClo, 1, (V[]){v_g_2410});
      } else {
        heff_drop(v_field_2413);
        return heff_tag_at_n(v_ru_24x4_242_24SGlobal, TAG_RGet, 1, (V[]){v_g_2410});
      }
    }
  }
  case TAG_SInt: {
    V v_n_2415 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SInt = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SInt, TAG_RInt, 1, (V[]){v_n_2415});
  }
  case TAG_SFloat: {
    double v_x_2416 = heff_tflat_f64(v_x4_242, 0);
    V v_ru_24x4_242_24SFloat = heff_take_reuse_na(v_x4_242, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_nf(v_ru_24x4_242_24SFloat, TAG_RFloat, 1, 1u, (V[]){heff_word_f64(v_x_2416)});
  }
  case TAG_SStr: {
    V v_s_2417 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SStr = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SStr, TAG_RStr, 1, (V[]){v_s_2417});
  }
  case TAG_SBytes: {
    V v_s_2418 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SBytes = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SBytes, TAG_RBytes, 1, (V[]){v_s_2418});
  }
  case TAG_SFixed: {
    V v_w_2419 = heff_field(v_x4_242, 0);
    V v_n_2420 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SFixed = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SFixed, TAG_RFixed, 2, (V[]){v_w_2419, v_n_2420});
  }
  case TAG_SFloat32: {
    double v_x_2421 = heff_tflat_f64(v_x4_242, 0);
    V v_ru_24x4_242_24SFloat32 = heff_take_reuse_na(v_x4_242, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_nf(v_ru_24x4_242_24SFloat32, TAG_RF32, 1, 1u, (V[]){heff_word_f64(v_x_2421)});
  }
  case TAG_SPrimFn: {
    V v_p_2422 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SPrimFn = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SPrimFn, TAG_RPrimFn, 1, (V[]){v_p_2422});
  }
  case TAG_SLam: {
    V v_xs_2423 = heff_field(v_x4_242, 0);
    V v_x42_2424 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x42_2424)) {
    case TAG_MkBlock: {
      V v_t_2425 = heff_field(v_x42_2424, 0);
      heff_take_n(v_x42_2424, 1ULL, 1);
      V v_t_2426 = (g_heff_2ecompile_2erefcount_2efreeOf(heff_dup(v_xs_2423), heff_dup(v_t_2425)));
      return (g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(v_ce_240, v_live_241, v_xs_2423, v_t_2425, v_t_2426));
    }
    default: return heff_nomatch(v_x42_2424);
    }
  }
  case TAG_STag: {
    V v_t_2427 = heff_field(v_x4_242, 0);
    V v_argv_2428 = heff_field(v_x4_242, 1);
    V v_ts_2429 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24STag = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    switch (heff_tag_of(v_argv_2428)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_live_241);
      heff_drop(v_ts_2429);
      heff_drop_cell(v_ru_24x4_242_24STag, 3);
      return heff_tag_n(TAG_RNTag, 1, (V[]){v_t_2427});
    }
    case TAG_Cons: {
      V v_ce_2432 = v_ce_240;
      V v_live_2433 = v_live_241;
      V v_t_2434 = v_t_2427;
      V v_argv_2435 = v_argv_2428;
      V v_ts_2436 = v_ts_2429;
      V v_n_2437 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2435));
      V v_t_2438 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2437, MK_INT(1LL))));
      V v_t_2441 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_lam0, 1, 1, (V[]){heff_dup(v_ts_2436)}), v_t_2438));
      V v_t_2442 = (g_heff_2ecompile_2erefcount_2eslotBits(v_t_2441));
      V v_n_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2435));
      V v_t_2444 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2443, MK_INT(1LL))));
      V v_rps_2447 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_lam1, 1, 1, (V[]){v_ts_2436}), v_t_2444));
      V v_t_2448 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_2432, v_live_2433, heff_dup(v_rps_2447), v_argv_2435));
      V v_t_2449 = (g_list_2ezipWith_24s870182194x1066240094(v_rps_2447, v_t_2448));
      return heff_tag_at_n(v_ru_24x4_242_24STag, TAG_RTag, 3, (V[]){v_t_2434, v_t_2442, v_t_2449});
    }
    default: return heff_nomatch(v_argv_2428);
    }
  }
  case TAG_SRec: {
    V v_fs_2450 = heff_field(v_x4_242, 0);
    V v_ts_2451 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SRec = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2452 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x4_242_24SRec, heff_dup(v_fs_2450)));
    V v_t_2453 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_live_241; V a_2 = v_t_2452; V a_3 = heff_dup(v_fs_2450); V r_ = (g_heff_2ecompile_2erefcount_2eupdatedIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2452); r_; });
    return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_fs_2450; V a_3 = v_ts_2451; V a_4 = v_t_2453; V r_ = (g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ts_2451); heff_drop(v_t_2453); r_; });
  }
  case TAG_SProj: {
    V v_e_2454 = heff_field(v_x4_242, 0);
    V v_l_2455 = heff_field(v_x4_242, 1);
    V v_sh_2456 = heff_field(v_x4_242, 2);
    V v_t_2457 = heff_field(v_x4_242, 3);
    heff_take_n(v_x4_242, 15ULL, 4);
    V v_t_2458 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2456));
    V v_t_2459 = ({ V a_0 = v_l_2455; V a_1 = MK_INT(0LL); V a_2 = v_sh_2456; V r_ = (g_heff_2ecompile_2erefcount_2eindexIn(a_0, a_1, a_2)); heff_drop(v_sh_2456); r_; });
    return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_e_2454; V a_3 = v_l_2455; V a_4 = v_t_2457; V a_5 = v_t_2458; V a_6 = v_t_2459; V r_ = (g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2457); r_; });
  }
  case TAG_SPrim: {
    V v_p_2460 = heff_field(v_x4_242, 0);
    V v_argv_2461 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_t_2462;
    switch (heff_tag_of(v_p_2460)) {
    case TAG_ArraySet: {
      v_t_2462 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(2LL)});
      break;
    }
    case TAG_ArrayReplicate: {
      v_t_2462 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(1LL)});
      break;
    }
    default: {
      v_t_2462 = NTAG(TAG_Nothing);
      break;
    }
    }
    return (g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495(v_ce_240, v_live_241, v_p_2460, v_argv_2461, v_t_2462));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_lam0(V self, V *args) {
  V v_i_2439 = args[0];
  V v_ts_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440 = ({ V a_0 = heff_dup(v_i_2439); V a_1 = v_ts_2436; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2436); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2439, v_t_2440));
}
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_lam1(V self, V *args) {
  V v_i_2445 = args[0];
  V v_ts_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = ({ V a_0 = heff_dup(v_i_2445); V a_1 = v_ts_2436; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2436); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2445, v_t_2446));
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915(V v_lit_240, V v_ce_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2erefcount_2efvArm(heff_tag_n(TAG_ASts, 1, (V[]){heff_dup(v_lit_240)})));
  V v_wanted_243 = (g_prelude_2e_2b_2b(v_t_242, heff_dup(heff_rfield(v_ce_241, 5))));
  V v_xs_246 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_lam0, 1, 1, (V[]){v_wanted_243}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_t_247 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_241), v_xs_246));
  V v_t_248 = (g_list_2emap_24s1796125103x644876049(v_t_247));
  V v_owned_249 = heff_dup(heff_rfield(v_ce_241, 4));
  V v_t_2410 = (g_heff_2ecompile_2erefcount_2efvArm(heff_tag_n(TAG_ASts, 1, (V[]){heff_dup(v_lit_240)})));
  V v_wanted_2411 = (g_prelude_2e_2b_2b(v_t_2410, heff_dup(heff_rfield(v_ce_241, 5))));
  V v_t_2413 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_lam1, 1, 1, (V[]){v_wanted_2411}), v_owned_249));
  V v_ce_2414 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2413, heff_dup(heff_rfield(v_ce_241, 5)), v_ce_241));
  V v_t_2415 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2414, v_lit_240, NTAG(TAG_Nothing)));
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_248, v_t_2415);
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_lam0(V self, V *args) {
  V v_v_244 = args[0];
  V v_wanted_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = ({ V a_0 = v_v_244; V a_1 = v_wanted_243; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_244); heff_drop(v_wanted_243); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_245) == NTAG(TAG_True)));
  heff_drop(v_x1_245);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_lam1(V self, V *args) {
  V v_v_2412 = args[0];
  V v_wanted_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2412; V a_1 = v_wanted_2411; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2412); heff_drop(v_wanted_2411); r_; });
}
Clo g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(V v_ce_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    V v_x_242 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SVar = heff_take_reuse_n(v_v_241, 1ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_at_n(v_ru_24v_241_24SVar, TAG_RLocal, 1, (V[]){v_x_242});
  }
  case TAG_SGlobal: {
    V v_g_243 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SGlobal = heff_take_reuse_n(v_v_241, 1ULL, 1);
    HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_ce_240, 0, 17); V a_1 = v_g_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_RClo, 1, (V[]){v_g_243});
      } else {
        heff_drop(v_field_246);
        return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_RGetRaw, 1, (V[]){v_g_243});
      }
    }
  }
  case TAG_SInt: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFloat: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SStr: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SBytes: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFixed: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFloat32: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SPrimFn: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SLam: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_STag: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SRec: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SProj: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SPrim: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_ce_244, V v_p_245, V v_fa_246, V v_wb_247) {
top: ;
  V v_wanted_248 = (g_prelude_2e_2b_2b(heff_dup(v_fa_246), heff_dup(v_wb_247)));
  V v_xs_2411 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_lam0, 1, 1, (V[]){v_wanted_248}), heff_dup(heff_rfield(v_ce_244, 4))));
  V v_t_2412 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_244), v_xs_2411));
  V v_t_2413 = (g_list_2emap_24s1796125103x644876049(v_t_2412));
  V v_wanted_2414 = (g_prelude_2e_2b_2b(v_fa_246, heff_dup(v_wb_247)));
  V v_t_2416 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_lam1, 1, 1, (V[]){v_wanted_2414}), heff_dup(heff_rfield(v_ce_244, 4))));
  V v_ce_2417 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2416, heff_dup(v_wb_247), heff_dup(v_ce_244)));
  HeffT2 v_t_2418 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_245));
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    V v_t_2426;
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_sh_2421 = v_field_2420;
      V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_243, NTAG(TAG_Nil)});
      V v_t_2423 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_2417, heff_dup(v_wb_247), heff_get_n(v_sh_2421, 0, 2), heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_t_2422})));
      v_t_2426 = heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_245, v_t_2423});
    } else {
      heff_drop(v_field_2420);
      V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_243, NTAG(TAG_Nil)});
      V v_t_2425 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_2417, heff_dup(v_wb_247), heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_t_2424})));
      v_t_2426 = heff_tag_n(TAG_CondRel, 2, (V[]){v_p_245, v_t_2425});
    }
    V v_t_2428 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_lam2, 1, 1, (V[]){heff_dup(v_wb_247)}), heff_dup(heff_rfield(v_ce_244, 4))));
    V v_t_2429 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2428, heff_dup(heff_rfield(v_ce_244, 5)), heff_dup(v_ce_244)));
    V v_t_2430 = (g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447(v_lit_241, v_t_2429));
    V v_t_2432 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_lam3, 1, 1, (V[]){v_wb_247}), heff_dup(heff_rfield(v_ce_244, 4))));
    V v_t_2433 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2432, heff_dup(heff_rfield(v_ce_244, 5)), v_ce_244));
    V v_t_2434 = (g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447(v_lit_240, v_t_2433));
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_t_2426, v_t_2430, v_t_2434}), NTAG(TAG_Nil)});
    return (g_prelude_2e_2b_2b(v_t_2413, v_t_2435));
  }
}
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_lam0(V self, V *args) {
  V v_v_249 = args[0];
  V v_wanted_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2410 = ({ V a_0 = v_v_249; V a_1 = v_wanted_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_249); heff_drop(v_wanted_248); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2410) == NTAG(TAG_True)));
  heff_drop(v_x1_2410);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_lam1(V self, V *args) {
  V v_v_2415 = args[0];
  V v_wanted_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2415; V a_1 = v_wanted_2414; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2415); heff_drop(v_wanted_2414); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_lam2(V self, V *args) {
  V v_v_2427 = args[0];
  V v_wb_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2427; V a_1 = v_wb_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2427); heff_drop(v_wb_247); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_lam3(V self, V *args) {
  V v_v_2431 = args[0];
  V v_wb_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2431; V a_1 = v_wb_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2431); heff_drop(v_wb_247); r_; });
}
V g_heff_2ecompile_2erefcount_2erebuiltV_24s1525876903x832315694_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2erebuiltV_24s1525876903x832315694_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2erebuiltV_24s1525876903x832315694_24cpr(V v_seen_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_SVar: {
    return ((HeffT2){{v_seen_240, v_x3_241}});
  }
  case TAG_SGlobal: {
    return ((HeffT2){{v_seen_240, v_x3_241}});
  }
  case TAG_SInt: {
    return ((HeffT2){{v_seen_240, v_x3_241}});
  }
  case TAG_SFloat: {
    return ((HeffT2){{v_seen_240, v_x3_241}});
  }
  case TAG_SStr: {
    return ((HeffT2){{v_seen_240, v_x3_241}});
  }
  case TAG_SBytes: {
    return ((HeffT2){{v_seen_240, v_x3_241}});
  }
  case TAG_SFixed: {
    return ((HeffT2){{v_seen_240, v_x3_241}});
  }
  case TAG_SFloat32: {
    return ((HeffT2){{v_seen_240, v_x3_241}});
  }
  case TAG_SPrimFn: {
    return ((HeffT2){{v_seen_240, v_x3_241}});
  }
  case TAG_SLam: {
    V v_xs_2412 = heff_field(v_x3_241, 0);
    V v_x32_2413 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24SLam = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x32_2413)) {
    case TAG_MkBlock: {
      V v_t_2414 = heff_field(v_x32_2413, 0);
      V v_ru_24x32_2413_24MkBlock = heff_take_reuse_n(v_x32_2413, 1ULL, 1);
      V v_t_2415 = (g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531(NTAG(TAG_Nil), v_t_2414));
      V v_t_2416 = heff_tag_re_n(v_ru_24x3_241_24SLam, TAG_SLam, 2, 1ULL, (V[]){v_xs_2412, heff_tag_at_n(v_ru_24x32_2413_24MkBlock, TAG_MkBlock, 1, (V[]){v_t_2415})});
      return ((HeffT2){{v_seen_240, v_t_2416}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x32_2413)}});
    }
  }
  case TAG_STag: {
    V v_t_2417 = heff_field(v_x3_241, 0);
    V v_args_2418 = heff_field(v_x3_241, 1);
    V v_ts_2419 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24STag = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    HeffT2 v_t_2420 = (g_heff_2ecompile_2erefcount_2erebuiltVs_24s1306915676x1772197351_24cpr(v_seen_240, v_args_2418));
    {
      V v_field_2421 = v_t_2420.f[0];
      V v_field_2422 = v_t_2420.f[1];
      V v_s2_2423 = v_field_2421;
      V v_as2_2424 = v_field_2422;
      return ((HeffT2){{v_s2_2423, heff_tag_re_n(v_ru_24x3_241_24STag, TAG_STag, 3, 5ULL, (V[]){v_t_2417, v_as2_2424, v_ts_2419})}});
    }
  }
  case TAG_SRec: {
    V v_fs_2425 = heff_field(v_x3_241, 0);
    V v_ts_2426 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24SRec = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2427 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2425)));
    HeffT2 v_t_2428 = (g_heff_2ecompile_2erefcount_2erebuiltVs_24s1306915676x1772197351_24cpr(v_seen_240, v_t_2427));
    {
      V v_field_2429 = v_t_2428.f[0];
      V v_field_2430 = v_t_2428.f[1];
      V v_s2_2431 = v_field_2429;
      V v_vs2_2432 = v_field_2430;
      V v_seen_2433 = v_s2_2431;
      V v_fs_2434 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2425, v_vs2_2432));
      V v_ts_2435 = v_ts_2426;
      V v_x_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2434));
      if (heff_intLt_c(MK_INT(62LL), v_x_2436)) {
        return ((HeffT2){{v_seen_2433, heff_tag_at_n(v_ru_24x3_241_24SRec, TAG_SRec, 2, (V[]){v_fs_2434, v_ts_2435})}});
      } else {
        V v_t_2443 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2erefcount_2erebuiltV_24s1525876903x832315694_24cpr_lam0, 1, 1, (V[]){heff_dup(v_fs_2434)}), v_fs_2434));
        if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
          heff_drop(v_t_2443);
          return ((HeffT2){{v_seen_2433, heff_tag_at_n(v_ru_24x3_241_24SRec, TAG_SRec, 2, (V[]){v_fs_2434, v_ts_2435})}});
        } else {
          heff_drop(v_t_2443);
          HeffT2 v_t_2449 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ecompile_2erefcount_2erebuiltV_24s1525876903x832315694_24cpr_lam1, 1, 1, (V[]){heff_dup(v_fs_2434)}), v_seen_2433));
          {
            V v_field_2451 = v_t_2449.f[1];
            int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
            if ((v_tag_2450 == ((int64_t)0ULL))) {
              V v_p_2452 = v_field_2451;
              V v_t_2453 = (g_list_2ekeepIf_24s689992630x418898235(v_p_2452, v_seen_2433));
              V v_t_2456;
              switch (heff_tag_of(v_p_2452)) {
              case TAG_MkPair: {
                V v_x_2454 = heff_field(v_p_2452, 0);
                heff_take_n(v_p_2452, 1ULL, 2);
                v_t_2456 = v_x_2454;
                break;
              }
              default: heff_nomatch(v_p_2452);
              }
              V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_241_24SRec, TAG_SRec, 2, (V[]){v_fs_2434, v_ts_2435}), NTAG(TAG_Nil)});
              V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_t_2456}), v_t_2457});
              return ((HeffT2){{v_t_2453, heff_tag_n(TAG_SPrim, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2ereusePrim_get()), v_t_2458})}});
            } else {
              heff_drop(v_field_2451);
              return ((HeffT2){{v_seen_2433, heff_tag_at_n(v_ru_24x3_241_24SRec, TAG_SRec, 2, (V[]){v_fs_2434, v_ts_2435})}});
            }
          }
        }
      }
    }
  }
  case TAG_SProj: {
    return ((HeffT2){{v_seen_240, v_x3_241}});
  }
  case TAG_SPrim: {
    V v_p_2463 = heff_field(v_x3_241, 0);
    V v_args_2464 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24SPrim = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    HeffT2 v_t_2465 = (g_heff_2ecompile_2erefcount_2erebuiltVs_24s1306915676x1772197351_24cpr(v_seen_240, v_args_2464));
    {
      V v_field_2466 = v_t_2465.f[0];
      V v_field_2467 = v_t_2465.f[1];
      V v_s2_2468 = v_field_2466;
      V v_as2_2469 = v_field_2467;
      return ((HeffT2){{v_s2_2468, heff_tag_re_n(v_ru_24x3_241_24SPrim, TAG_SPrim, 2, 1ULL, (V[]){v_p_2463, v_as2_2469})}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
V g_heff_2ecompile_2erefcount_2erebuiltV_24s1525876903x832315694_24cpr_lam0(V self, V *args) {
  V v_f_2437 = args[0];
  V v_fs_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438 = (g_list_2emap_24s1937570095x2110149801(v_fs_2434));
  HeffT2 v_t_2439 = ({ V a_0 = v_t_2438; V a_1 = v_f_2437; HeffT2 r_ = (g_heff_2ecompile_2erefcount_2ekeptFrom_24cpr(a_0, a_1)); heff_drop(v_t_2438); heff_drop(v_f_2437); r_; });
  {
    V v_field_2441 = v_t_2439.f[1];
    int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2440 == ((int64_t)0ULL)) && ({ V v_x11_2442 = heff_dup(v_field_2441); int c_ = 1; heff_drop(v_x11_2442); c_; })));
    heff_drop(v_field_2441);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2erefcount_2erebuiltV_24s1525876903x832315694_24cpr_lam1(V self, V *args) {
  V v_p_2444 = args[0];
  V v_fs_2434 = heff_env(self)[0];
  V v_t_2447;
  switch (heff_tag_of(v_p_2444)) {
  case TAG_MkPair: {
    V v_y_2446 = heff_field(v_p_2444, 1);
    heff_take_n(v_p_2444, 2ULL, 2);
    v_t_2447 = v_y_2446;
    break;
  }
  default: heff_nomatch(v_p_2444);
  }
  heff_clo_take(self, 1);
  V v_t_2448 = (g_list_2emap_24s1937570095x2110149801(v_fs_2434));
  return ({ V a_0 = v_t_2447; V a_1 = v_t_2448; V r_ = (g_heff_2ecompile_2erefcount_2esameS(a_0, a_1)); heff_drop(v_t_2447); heff_drop(v_t_2448); r_; });
}
Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ecoerce_24tok2(V v_tok_240, V v_from_241, V v_to_242, V v_v_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2erepr_2ereprEq(v_from_241, v_to_242));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_from_241);
    heff_drop(v_to_242);
    heff_drop(v_t_244);
    return v_v_243;
  } else {
    heff_drop(v_t_244);
    V v_t_246;
    switch (heff_tag_of(v_to_242)) {
    case TAG_RepV: {
      v_t_246 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_RepF64: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_RepInt: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_to_242);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_to_242);
      heff_drop(v_t_246);
      return heff_tag_at_n(v_tok_240, TAG_RBox, 2, (V[]){v_from_241, v_v_243});
    } else {
      heff_drop(v_t_246);
      switch (heff_tag_of(v_from_241)) {
      case TAG_RepV: {
        switch (heff_tag_of(v_v_243)) {
        case TAG_RDup: {
          V v_x_247 = heff_field(v_v_243, 0);
          V v_ru_24v_243_24RDup = heff_take_reuse_n(v_v_243, 1ULL, 1);
          return heff_tag_at_n(v_tok_240, TAG_RPeek, 2, (V[]){v_to_242, heff_tag_at_n(v_ru_24v_243_24RDup, TAG_RLocal, 1, (V[]){v_x_247})});
        }
        case TAG_RGet: {
          V v_g_248 = heff_field(v_v_243, 0);
          V v_ru_24v_243_24RGet = heff_take_reuse_n(v_v_243, 1ULL, 1);
          return heff_tag_at_n(v_tok_240, TAG_RPeek, 2, (V[]){v_to_242, heff_tag_at_n(v_ru_24v_243_24RGet, TAG_RGetRaw, 1, (V[]){v_g_248})});
        }
        case TAG_RDupE: {
          V v_e_249 = heff_field(v_v_243, 0);
          heff_take_n(v_v_243, 1ULL, 1);
          return heff_tag_at_n(v_tok_240, TAG_RPeek, 2, (V[]){v_to_242, v_e_249});
        }
        default: {
          return heff_tag_at_n(v_tok_240, TAG_RUnbox, 2, (V[]){v_to_242, v_v_243});
        }
        }
      }
      case TAG_RepFix: {
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_242, heff_tag_at_n(v_tok_240, TAG_RBox, 2, (V[]){v_from_241, v_v_243})));
      }
      case TAG_RepF64: {
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_242, heff_tag_at_n(v_tok_240, TAG_RBox, 2, (V[]){v_from_241, v_v_243})));
      }
      case TAG_RepInt: {
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_242, heff_tag_at_n(v_tok_240, TAG_RBox, 2, (V[]){v_from_241, v_v_243})));
      }
      default: return heff_nomatch(v_from_241);
      }
    }
  }
}
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecoerce_24tok2(a[0], a[1], a[2], a[3]);
}