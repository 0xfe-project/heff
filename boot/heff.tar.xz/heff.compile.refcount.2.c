// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_CIf 14188
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_F32 16337
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_after 294093302
#define LBL_args 9498020
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_funs 9650075
#define LBL_n 328
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_sigs 10025609
#define LBL_sts 323756
#define LBL_tag 324116
#define LBL_takes 311482598
#define LBL_tl 10463
static uint32_t shape_n__tag[] = {LBL_n, LBL_tag};
static uint32_t shape_sts__tl[] = {LBL_sts, LBL_tl};
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eimperative_2estmtsParts(V);
V g_heff_2ecompile_2eimperative_2estmtsParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2estmtsParts_clo;
V g_heff_2ecompile_2eimperative_2etailParts(V);
V g_heff_2ecompile_2eimperative_2etailParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etailParts_clo;
V g_heff_2ecompile_2erefcount_2earmFound(V, V, V);
V g_heff_2ecompile_2erefcount_2earmFound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmFound_clo;
V g_heff_2ecompile_2erefcount_2earmFound_24tok3(V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmFound_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmFound_24tok3_clo;
V g_heff_2ecompile_2erefcount_2ecellIn_get(void);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok2_clo;
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(V, V);
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_clo;
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(V, V);
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_clo;
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2eelementRepr(V, V);
V g_heff_2ecompile_2erefcount_2eelementRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelementRepr_clo;
V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_clo;
V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_24tok1(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_24tok1_clo;
V g_heff_2ecompile_2erefcount_2efreeOf(V, V);
V g_heff_2ecompile_2erefcount_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeOf_clo;
V g_heff_2ecompile_2erefcount_2efunPlain(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efunPlain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efunPlain_clo;
V g_heff_2ecompile_2erefcount_2efunWith(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efunWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efunWith_clo;
V g_heff_2ecompile_2erefcount_2egoneOne(V, V, V);
V g_heff_2ecompile_2erefcount_2egoneOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2egoneOne_clo;
V g_heff_2ecompile_2erefcount_2egoneTo(V, V);
V g_heff_2ecompile_2erefcount_2egoneTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2egoneTo_clo;
V g_heff_2ecompile_2erefcount_2eindexIn(V, V, V);
V g_heff_2ecompile_2erefcount_2eindexIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eindexIn_clo;
V g_heff_2ecompile_2erefcount_2eintPrims_get(void);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_clo;
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_clo;
V g_heff_2ecompile_2erefcount_2eothersW(V, V, V);
V g_heff_2ecompile_2erefcount_2eothersW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eothersW_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs(V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok1(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_clo;
V g_heff_2ecompile_2erefcount_2epeekOf(V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekOf_clo;
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_clo;
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_24tok2_clo;
V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_clo;
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_clo;
V g_heff_2ecompile_2erefcount_2ereuseArgs(V, V);
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseV_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseV_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereusedAny_24cpr(V, V, V, V);
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(V, V);
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etagGiven_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_clo;
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etakeIn_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeVar(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeVar_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etokenArm_24cpr(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etokenK(V, V, V);
V g_heff_2ecompile_2erefcount_2etokenK_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etokenK_clo;
V g_heff_2ecompile_2erefcount_2etokenRound(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etokenRound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etokenRound_clo;
V g_heff_2ecompile_2erefcount_2etokenSts(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etokenSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etokenSts_clo;
V g_heff_2ecompile_2erefcount_2etokenTl(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etokenTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etokenTl_clo;
V g_heff_2ecompile_2erefcount_2eunboxOf(V, V);
V g_heff_2ecompile_2erefcount_2eunboxOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxOf_clo;
V g_heff_2ecompile_2erefcount_2eupdatedIn(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eupdatedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eupdatedIn_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(V, V, V);
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_list_2eany_24s1877524499x1789047582(V, V);
V g_list_2eany_24s1877524499x1789047582_entry(V self, V *a);
extern Clo g_list_2eany_24s1877524499x1789047582_clo;
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f1663632568x709545076(V, V, V, V);
V g_list_2efoldl_24f1663632568x709545076_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1663632568x709545076_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s421921225x565177679(V, V);
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a);
extern Clo g_list_2efoldl_24s421921225x565177679_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s826961155x1314392429(V, V);
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s826961155x1314392429_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24tok1(V, V);
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24tok1_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2efst(V);
V g_prelude_2efst_entry(V self, V *a);
extern Clo g_prelude_2efst_clo;
V g_prelude_2enot(V);
V g_prelude_2enot_entry(V self, V *a);
extern Clo g_prelude_2enot_clo;
V g_prelude_2esnd(V);
V g_prelude_2esnd_entry(V self, V *a);
extern Clo g_prelude_2esnd_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
Clo g_heff_2ecompile_2erefcount_2elentThen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentThen_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2elentThen(V v_ce_240, V v_bi_241, V v_i_242, V v_e_243, V v_before_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2erefcount_2eelemI(v_i_242, v_bi_241));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    switch (heff_tag_of(v_e_243)) {
    case TAG_SVar: {
      V v_x_246 = heff_field(v_e_243, 0);
      HeffT2 v_t_247 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2410 = v_field_249;
          heff_drop(v_x_2410);
          return v_before_244;
        } else {
          heff_drop(v_field_249);
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_246), v_before_244});
        }
      }
    }
    case TAG_SGlobal: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SInt: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SFloat: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SStr: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SBytes: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SFixed: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SFloat32: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SPrimFn: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SLam: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_STag: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SRec: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SProj: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    case TAG_SPrim: {
      heff_drop_rec(v_ce_240, 17);
      return v_before_244;
    }
    default: return heff_nomatch(v_e_243);
    }
  } else {
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_t_245);
    return v_before_244;
  }
}
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2elentThen(a[0], a1, a[2], a3, a[4]); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2eelementRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eelementRepr_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eelementRepr(V v_ce_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    V v_x_242 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_242); r_; });
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_245;
        return v_x_246;
      } else {
        heff_drop(v_field_245);
        return NTAG(TAG_RepV);
      }
    }
  }
  case TAG_SGlobal: {
    heff_take_n(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SInt: {
    heff_take_n(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SFloat: {
    heff_take_na(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepF64);
  }
  case TAG_SStr: {
    heff_take_n(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SBytes: {
    heff_take_n(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SFixed: {
    V v_w_2412 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 2);
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_n(TAG_RepFix, 1, (V[]){v_w_2412});
  }
  case TAG_SFloat32: {
    V v_ru_24v_241_24SFloat32 = heff_take_reuse_na(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_at_n(v_ru_24v_241_24SFloat32, TAG_RepFix, 1, (V[]){NTAG(TAG_F32)});
  }
  case TAG_SPrimFn: {
    heff_take_n(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SLam: {
    heff_take_n(v_v_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_STag: {
    heff_take_n(v_v_241, 0ULL, 3);
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SRec: {
    heff_take_n(v_v_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SProj: {
    heff_take_n(v_v_241, 0ULL, 4);
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SPrim: {
    V v_p_2427 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 2);
    heff_drop_rec(v_ce_240, 17);
    HeffT2 v_t_2429 = ({ V a_0 = v_p_2427; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(a_0)); heff_drop(v_p_2427); r_; });
    {
      V v_field_2431 = v_t_2429.f[1];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        V v_s_2432 = v_field_2431;
        return heff_get_n(v_s_2432, 1, 2);
      } else {
        heff_drop(v_field_2431);
        return NTAG(TAG_RepV);
      }
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erefcount_2eelementRepr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eelementRepr(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2ereuseV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereuseV_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ereuseV(V v_ru_240, V v_n_241, V v_x3_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2erefcount_2ereuseV_24cpr(v_ru_240, v_n_241, v_x3_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ereuseV(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(V v_ru_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_TSeq: {
    V v_ss_243 = heff_field(v_x4_242, 0);
    V v_t_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TSeq = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), heff_dup(v_ss_243)));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_it1_248 = v_field_246;
      V v_ss2_249 = v_field_247;
      if ((heff_dup(v_it1_248) == NTAG(TAG_True))) {
        heff_drop(v_ru_240);
        heff_drop(v_n_241);
        heff_drop(v_ss_243);
        heff_drop(v_it1_248);
        return ((HeffT2){{NTAG(TAG_True), heff_tag_at_n(v_ru_24x4_242_24TSeq, TAG_TSeq, 2, (V[]){v_ss2_249, v_t_244})}});
      } else {
        heff_drop(v_it1_248);
        heff_drop(v_ss2_249);
        HeffT2 v_t_2410 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(v_ru_240, v_n_241, v_t_244));
        {
          V v_field_2411 = v_t_2410.f[0];
          V v_field_2412 = v_t_2410.f[1];
          V v_b_2413 = v_field_2411;
          V v_t2_2414 = v_field_2412;
          return ((HeffT2){{v_b_2413, heff_tag_at_n(v_ru_24x4_242_24TSeq, TAG_TSeq, 2, (V[]){v_ss_243, v_t2_2414})}});
        }
      }
    }
  }
  case TAG_TReturn: {
    V v_o_2415 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24TReturn = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_2416 = (g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(v_ru_240, v_n_241, v_o_2415));
    {
      V v_field_2417 = v_t_2416.f[0];
      V v_field_2418 = v_t_2416.f[1];
      V v_b_2419 = v_field_2417;
      V v_o2_2420 = v_field_2418;
      return ((HeffT2){{v_b_2419, heff_tag_at_n(v_ru_24x4_242_24TReturn, TAG_TReturn, 1, (V[]){v_o2_2420})}});
    }
  }
  case TAG_TLoop: {
    V v_vs_2421 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24TLoop = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_t_2423 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_vs_2421; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_vs_2421); r_; });
    switch (heff_tag_of(v_t_2423)) {
    case TAG_MkPair: {
      V v_b_2424 = heff_field(v_t_2423, 0);
      V v_vs2_2425 = heff_field(v_t_2423, 1);
      heff_take_n(v_t_2423, 3ULL, 2);
      return ((HeffT2){{v_b_2424, heff_tag_at_n(v_ru_24x4_242_24TLoop, TAG_TLoop, 1, (V[]){v_vs2_2425})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2423)}});
    }
  }
  case TAG_TIf: {
    V v_c_2426 = heff_field(v_x4_242, 0);
    V v_t_2427 = heff_field(v_x4_242, 1);
    V v_e_2428 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24TIf = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    HeffT2 v_t_2429 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_t_2427));
    {
      V v_field_2430 = v_t_2429.f[0];
      V v_field_2431 = v_t_2429.f[1];
      V v_bt_2432 = v_field_2430;
      V v_t2_2433 = v_field_2431;
      HeffT2 v_t_2434 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(v_ru_240, v_n_241, v_e_2428));
      {
        V v_field_2435 = v_t_2434.f[0];
        V v_field_2436 = v_t_2434.f[1];
        V v_be_2437 = v_field_2435;
        V v_e2_2438 = v_field_2436;
        V v_t_2439 = heff_bool(((heff_dup(v_bt_2432) == NTAG(TAG_True)) || (heff_dup(v_be_2437) == NTAG(TAG_True))));
        heff_drop(v_bt_2432);
        heff_drop(v_be_2437);
        return ((HeffT2){{v_t_2439, heff_tag_at_n(v_ru_24x4_242_24TIf, TAG_TIf, 3, (V[]){v_c_2426, v_t2_2433, v_e2_2438})}});
      }
    }
  }
  case TAG_TCase: {
    V v_v_2440 = heff_field(v_x4_242, 0);
    V v_arms_2441 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TCase = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_ps_2451 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam1, 1, 2, (V[]){v_ru_240, v_n_241}), v_arms_2441));
    V v_b_2452 = (g_list_2eany_24s910662703x1730636603(v_ps_2451));
    V v_as2_2453 = (g_list_2emap_24s1173914895x100384474(v_ps_2451));
    return ((HeffT2){{v_b_2452, heff_tag_at_n(v_ru_24x4_242_24TCase, TAG_TCase, 2, (V[]){v_v_2440, v_as2_2453})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam0(V self, V *args) {
  V v_v_2422 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_2422));
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam1(V self, V *args) {
  V v_x4_2442 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x4_2442)) {
  case TAG_MkArm: {
    V v_t_2443 = heff_field(v_x4_2442, 0);
    V v_vs_2444 = heff_field(v_x4_2442, 1);
    V v_b_2445 = heff_field(v_x4_2442, 2);
    V v_ru_24x4_2442_24MkArm = heff_take_reuse_n(v_x4_2442, 7ULL, 3);
    HeffT2 v_t_2446 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(v_ru_240, v_n_241, v_b_2445));
    {
      V v_field_2447 = v_t_2446.f[0];
      V v_field_2448 = v_t_2446.f[1];
      V v_b_2449 = v_field_2447;
      V v_x_2450 = v_field_2448;
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2449, heff_tag_at_n(v_ru_24x4_2442_24MkArm, TAG_MkArm, 3, (V[]){v_t_2443, v_vs_2444, v_x_2450})});
    }
  }
  default: return heff_nomatch(v_x4_2442);
  }
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusedAny_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusedAny_24cpr_str1, 0, "");

HeffT2 g_heff_2ecompile_2erefcount_2ereusedAny_24cpr(V v_ru_240, V v_n_241, V v_b_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_b1_245 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    if ((heff_dup(v_x41_244) == NTAG(TAG_True))) {
      heff_drop(v_n_241);
      heff_drop(v_b_242);
      heff_drop(v_x41_244);
      return ((HeffT2){{heff_tag_n(TAG_Just, 1, (V[]){v_ru_240}), v_b1_245}});
    } else {
      heff_drop(v_x41_244);
      heff_drop(v_b1_245);
      switch (heff_tag_of(v_b_242)) {
      case TAG_ATail: {
        V v_t_246 = heff_dup(heff_field(v_b_242, 0));
        HeffT2 v_t_247 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(heff_dup(v_ru_240), heff_rec_n(2, shape_n__tag, (V[]){v_n_241, ((V)&g_heff_2ecompile_2erefcount_2ereusedAny_24cpr_str0)}), v_t_246));
        {
          V v_field_248 = v_t_247.f[0];
          V v_field_249 = v_t_247.f[1];
          V v_b_2410 = v_field_248;
          V v_t2_2411 = v_field_249;
          if ((heff_dup(v_b_2410) == NTAG(TAG_True))) {
            heff_drop_tag(v_b_242, 1);
            heff_drop(v_b_2410);
            return ((HeffT2){{heff_tag_n(TAG_Just, 1, (V[]){v_ru_240}), heff_tag_n(TAG_ATail, 1, (V[]){v_t2_2411})}});
          } else {
            heff_drop(v_ru_240);
            heff_drop(v_b_2410);
            heff_drop(v_t2_2411);
            return ((HeffT2){{NTAG(TAG_Nothing), v_b_242}});
          }
        }
      }
      case TAG_ASts: {
        V v_ss_2412 = heff_dup(heff_field(v_b_242, 0));
        HeffT2 v_t_2413 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(heff_dup(v_ru_240), heff_rec_n(2, shape_n__tag, (V[]){v_n_241, ((V)&g_heff_2ecompile_2erefcount_2ereusedAny_24cpr_str1)}), v_ss_2412));
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v_b_2416 = v_field_2414;
          V v_ss2_2417 = v_field_2415;
          if ((heff_dup(v_b_2416) == NTAG(TAG_True))) {
            heff_drop_tag(v_b_242, 1);
            heff_drop(v_b_2416);
            return ((HeffT2){{heff_tag_n(TAG_Just, 1, (V[]){v_ru_240}), heff_tag_n(TAG_ASts, 1, (V[]){v_ss2_2417})}});
          } else {
            heff_drop(v_ru_240);
            heff_drop(v_b_2416);
            heff_drop(v_ss2_2417);
            return ((HeffT2){{NTAG(TAG_Nothing), v_b_242}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_b_242)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2ecompile_2erefcount_2etokenK_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2etokenK_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2etokenK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etokenK_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2etokenK(V v_tk_240, V v_ru_241, V v_n_242) {
top: ;
  return heff_rec_n(2, shape_sts__tl, (V[]){heff_clo_n(g_heff_2ecompile_2erefcount_2etokenK_lam0, 1, 3, (V[]){heff_dup(v_tk_240), heff_dup(v_ru_241), heff_dup(v_n_242)}), heff_clo_n(g_heff_2ecompile_2erefcount_2etokenK_lam1, 1, 3, (V[]){v_tk_240, v_ru_241, v_n_242})});
}
V g_heff_2ecompile_2erefcount_2etokenK_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etokenK(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2etokenK_lam0(V self, V *args) {
  V v_ss_243 = args[0];
  V v_tk_240 = heff_env(self)[0];
  V v_ru_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = (g_heff_2ecompile_2erefcount_2etokenK(heff_dup(v_tk_240), heff_dup(v_ru_241), heff_dup(v_n_242)));
  return (g_heff_2ecompile_2erefcount_2etokenSts(v_t_244, v_tk_240, v_ru_241, v_n_242, v_ss_243));
}
V g_heff_2ecompile_2erefcount_2etokenK_lam1(V self, V *args) {
  V v_t_245 = args[0];
  V v_tk_240 = heff_env(self)[0];
  V v_ru_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = (g_heff_2ecompile_2erefcount_2etokenK(heff_dup(v_tk_240), heff_dup(v_ru_241), heff_dup(v_n_242)));
  return (g_heff_2ecompile_2erefcount_2etokenTl(v_t_246, v_tk_240, v_ru_241, v_n_242, v_t_245));
}
V g_heff_2ecompile_2erefcount_2etokenRound_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2etokenRound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etokenRound_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2etokenRound(V v_tk_240, V v_ru_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_TSeq: {
    V v_ss_244 = heff_field(v_x4_243, 0);
    V v_t_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24TSeq = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_acc_246 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_245, NTAG(TAG_Nil)));
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_244)));
    V v_t_248 = ({ V a_0 = v_acc_246; V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_t_249 = ({ V a_0 = v_ru_241; V a_1 = v_t_248; V r_ = (g_list_2eany_24s1877524499x1789047582(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_prelude_2enot(a_0)); heff_drop(v_t_249); r_; });
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x4_243_24TSeq, 2);
      heff_drop(v_t_2410);
      V v_t_2411 = (g_heff_2ecompile_2erefcount_2etokenK(v_tk_240, v_ru_241, v_n_242));
      return heff_tail(heff_get_n(v_t_2411, 1, 2), 1, (V[]){heff_tag_n(TAG_TSeq, 2, (V[]){v_ss_244, v_t_245})});
    } else {
      heff_drop(v_t_2410);
      V v_t_2412 = (g_heff_2ecompile_2eimperative_2estmtsParts(heff_dup(v_ss_244)));
      V v_t_2413 = heff_tr(heff_call(heff_dup(g_heff_2ecompile_2erefcount_2ecellIn_get()), 2, (V[]){heff_dup(v_ru_241), v_t_2412}));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_tk_240);
        heff_drop(v_ru_241);
        heff_drop(v_n_242);
        heff_drop(v_t_2413);
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), heff_tag_at_n(v_ru_24x4_243_24TSeq, TAG_TSeq, 2, (V[]){v_ss_244, v_t_245})});
      } else {
        heff_drop(v_t_2413);
        V v_rt_2414 = heff_tr(g_heff_2ecompile_2erefcount_2etokenRound(v_tk_240, v_ru_241, v_n_242, v_t_245));
        V v_t_2415 = (g_prelude_2efst(v_rt_2414));
        V v_t_2416 = ({ V a_0 = v_rt_2414; V r_ = (g_prelude_2esnd(a_0)); heff_drop(v_rt_2414); r_; });
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, heff_tag_at_n(v_ru_24x4_243_24TSeq, TAG_TSeq, 2, (V[]){v_ss_244, v_t_2416})});
      }
    }
  }
  case TAG_TReturn: {
    V v_t_2418 = heff_tr(g_heff_2ecompile_2eimperative_2etailParts(v_x4_243));
    V v_t_2419 = heff_tr(heff_call(heff_dup(g_heff_2ecompile_2erefcount_2ecellIn_get()), 2, (V[]){heff_dup(v_ru_241), v_t_2418}));
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop(v_tk_240);
      heff_drop(v_ru_241);
      heff_drop(v_n_242);
      heff_drop(v_t_2419);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_x4_243});
    } else {
      heff_drop(v_t_2419);
      V v_t_2420 = (g_heff_2ecompile_2erefcount_2etokenK(v_tk_240, v_ru_241, v_n_242));
      return heff_tail(heff_get_n(v_t_2420, 1, 2), 1, (V[]){v_x4_243});
    }
  }
  case TAG_TLoop: {
    V v_t_2422 = heff_tr(g_heff_2ecompile_2eimperative_2etailParts(v_x4_243));
    V v_t_2423 = heff_tr(heff_call(heff_dup(g_heff_2ecompile_2erefcount_2ecellIn_get()), 2, (V[]){heff_dup(v_ru_241), v_t_2422}));
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_tk_240);
      heff_drop(v_ru_241);
      heff_drop(v_n_242);
      heff_drop(v_t_2423);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_x4_243});
    } else {
      heff_drop(v_t_2423);
      V v_t_2424 = (g_heff_2ecompile_2erefcount_2etokenK(v_tk_240, v_ru_241, v_n_242));
      return heff_tail(heff_get_n(v_t_2424, 1, 2), 1, (V[]){v_x4_243});
    }
  }
  case TAG_TIf: {
    V v_c_2425 = heff_field(v_x4_243, 0);
    V v_a_2426 = heff_field(v_x4_243, 1);
    V v_b_2427 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24TIf = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    V v_t_2428 = ({ V b_0 = heff_tag_at_n(v_ru_24x4_243_24TIf, TAG_TIf, 3, (V[]){heff_dup(v_c_2425), heff_dup(v_a_2426), heff_dup(v_b_2427)}); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2etailParts(b_0)); heff_drop(b_0); r_; });
    V v_t_2429 = heff_tr(heff_call(heff_dup(g_heff_2ecompile_2erefcount_2ecellIn_get()), 2, (V[]){heff_dup(v_ru_241), v_t_2428}));
    V v_t_2430 = ({ V a_0 = v_t_2429; V r_ = (g_prelude_2enot(a_0)); heff_drop(v_t_2429); r_; });
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop(v_t_2430);
      V v_t_2431 = (g_heff_2ecompile_2erefcount_2etokenK(v_tk_240, v_ru_241, v_n_242));
      return heff_tail(heff_get_n(v_t_2431, 1, 2), 1, (V[]){heff_tag_n(TAG_TIf, 3, (V[]){v_c_2425, v_a_2426, v_b_2427})});
    } else {
      heff_drop(v_t_2430);
      V v_ra_2432 = heff_tr(g_heff_2ecompile_2erefcount_2etokenRound(heff_dup(v_tk_240), heff_dup(v_ru_241), heff_dup(v_n_242), v_a_2426));
      V v_rb_2433 = heff_tr(g_heff_2ecompile_2erefcount_2etokenRound(v_tk_240, v_ru_241, v_n_242, v_b_2427));
      V v_t_2434 = (g_prelude_2efst(v_ra_2432));
      V v_t_2435;
      if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
        heff_drop(v_t_2434);
        v_t_2435 = NTAG(TAG_True);
      } else {
        heff_drop(v_t_2434);
        v_t_2435 = (g_prelude_2efst(v_rb_2433));
      }
      V v_t_2436 = ({ V a_0 = v_ra_2432; V r_ = (g_prelude_2esnd(a_0)); heff_drop(v_ra_2432); r_; });
      V v_t_2437 = ({ V a_0 = v_rb_2433; V r_ = (g_prelude_2esnd(a_0)); heff_drop(v_rb_2433); r_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2435, heff_tag_n(TAG_TIf, 3, (V[]){v_c_2425, v_t_2436, v_t_2437})});
    }
  }
  case TAG_TCase: {
    V v_v_2438 = heff_field(v_x4_243, 0);
    V v_arms_2439 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24TCase = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2440 = ({ V b_0 = heff_tag_at_n(v_ru_24x4_243_24TCase, TAG_TCase, 2, (V[]){heff_dup(v_v_2438), heff_dup(v_arms_2439)}); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2etailParts(b_0)); heff_drop(b_0); r_; });
    V v_t_2441 = heff_tr(heff_call(heff_dup(g_heff_2ecompile_2erefcount_2ecellIn_get()), 2, (V[]){heff_dup(v_ru_241), v_t_2440}));
    V v_t_2442 = ({ V a_0 = v_t_2441; V r_ = (g_prelude_2enot(a_0)); heff_drop(v_t_2441); r_; });
    if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
      heff_drop(v_t_2442);
      V v_t_2443 = (g_heff_2ecompile_2erefcount_2etokenK(v_tk_240, v_ru_241, v_n_242));
      return heff_tail(heff_get_n(v_t_2443, 1, 2), 1, (V[]){heff_tag_n(TAG_TCase, 2, (V[]){v_v_2438, v_arms_2439})});
    } else {
      heff_drop(v_t_2442);
      V v_rs_2449 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2etokenRound_lam0, 1, 3, (V[]){v_tk_240, v_ru_241, v_n_242}), v_arms_2439));
      V v_t_2450 = (g_list_2eany_24s910662703x1730636603(v_rs_2449));
      V v_t_2451 = (g_list_2emap_24s1173914895x100384474(v_rs_2449));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2450, heff_tag_n(TAG_TCase, 2, (V[]){v_v_2438, v_t_2451})});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erefcount_2etokenRound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etokenRound(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2etokenRound_lam0(V self, V *args) {
  V v_arm_2444 = args[0];
  V v_tk_240 = heff_env(self)[0];
  V v_ru_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_arm_2444)) {
  case TAG_MkArm: {
    V v_t_2445 = heff_field(v_arm_2444, 0);
    V v_vs_2446 = heff_field(v_arm_2444, 1);
    V v_b_2447 = heff_field(v_arm_2444, 2);
    V v_ru_24arm_2444_24MkArm = heff_take_reuse_n(v_arm_2444, 7ULL, 3);
    V v_t_2448 = heff_tr(g_heff_2ecompile_2erefcount_2etokenRound(v_tk_240, v_ru_241, v_n_242, v_b_2447));
    return (g_heff_2ecompile_2erefcount_2earmFound_24tok3(v_ru_24arm_2444_24MkArm, v_t_2445, v_vs_2446, v_t_2448));
  }
  default: return heff_nomatch(v_arm_2444);
  }
}

HeffT2 g_heff_2ecompile_2erefcount_2etokenArm_24cpr(V v_tk_240, V v_ru_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_ATail: {
    V v_t_244 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24ATail = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_245 = heff_tr(g_heff_2ecompile_2erefcount_2etokenRound(v_tk_240, v_ru_241, v_n_242, v_t_244));
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_b_246 = heff_field(v_t_245, 0);
      V v_t2_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      return ((HeffT2){{v_b_246, heff_tag_at_n(v_ru_24x4_243_24ATail, TAG_ATail, 1, (V[]){v_t2_247})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_245)}});
    }
  }
  case TAG_ASts: {
    V v_ss_248 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24ASts = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_248)));
    V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_t_2411 = ({ V a_0 = v_ru_241; V a_1 = v_t_2410; V r_ = (g_list_2eany_24s1877524499x1789047582(a_0, a_1)); heff_drop(v_t_2410); r_; });
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_tk_240);
      heff_drop(v_ru_241);
      heff_drop(v_n_242);
      heff_drop(v_t_2411);
      return ((HeffT2){{NTAG(TAG_False), heff_tag_at_n(v_ru_24x4_243_24ASts, TAG_ASts, 1, (V[]){v_ss_248})}});
    } else {
      heff_drop(v_t_2411);
      V v_t_2412 = (g_heff_2ecompile_2erefcount_2etokenK(v_tk_240, v_ru_241, v_n_242));
      V v_t_2413 = heff_tr(heff_call(heff_get_n(v_t_2412, 0, 2), 1, (V[]){v_ss_248}));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_MkPair: {
        V v_b_2414 = heff_field(v_t_2413, 0);
        V v_ss2_2415 = heff_field(v_t_2413, 1);
        heff_take_n(v_t_2413, 3ULL, 2);
        return ((HeffT2){{v_b_2414, heff_tag_at_n(v_ru_24x4_243_24ASts, TAG_ASts, 1, (V[]){v_ss2_2415})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2413)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2eothersW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eothersW_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eothersW(V v_x_240, V v_l_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_IVal: {
      V v_x311_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_245)) {
      case TAG_SVar: {
        V v_y_246 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        if (!heff_strEq_c_lent(v_x_240, v_y_246, 0)) {
          heff_drop(v_y_246);
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_rest_244;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        } else {
          heff_drop(v_rest_244);
          heff_drop(v_y_246);
          return NTAG(TAG_False);
        }
      }
      case TAG_SGlobal: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SInt: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat: {
        heff_take_na(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SStr: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SBytes: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFixed: {
        heff_take_n(v_x311_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SLam: {
        V v_x3112_2417 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        switch (heff_tag_of(v_x3112_2417)) {
        case TAG_MkBlock: {
          V v_t_2418 = heff_field(v_x3112_2417, 0);
          heff_take_n(v_x3112_2417, 1ULL, 1);
          V v_ps_2419 = ({ V a_0 = v_t_2418; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2418); r_; });
          V v_t_2420 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_240; V a_3 = v_ps_2419; V r_ = (g_list_2efoldl_24f1663632568x709545076(a_0, a_1, a_2, a_3)); heff_drop(v_ps_2419); r_; });
          if (heff_intEq_c(v_t_2420, MK_INT(0LL))) {
            V t_0 = v_x_240;
            V t_1 = v_l_241;
            V t_2 = v_rest_244;
            v_x_240 = t_0;
            v_l_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          } else {
            heff_drop(v_rest_244);
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_x3112_2417);
        }
      }
      case TAG_STag: {
        V v_argv_2422 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2422));
        V v_t_2425 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2424));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2425;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SRec: {
        V v_fs_2426 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2428 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2426));
        V v_t_2429 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2428));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2429;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SProj: {
        V v_e_2430 = heff_field(v_x311_245, 0);
        V v_l2_2431 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 3ULL, 4);
        V v_t_2457;
        switch (heff_tag_of(v_e_2430)) {
        case TAG_SVar: {
          V v_y_2434 = heff_dup(heff_field(v_e_2430, 0));
          v_t_2457 = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2434, 0));
          heff_drop(v_y_2434);
          break;
        }
        case TAG_SGlobal: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SInt: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SFloat: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SStr: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SBytes: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SFixed: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SFloat32: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SPrimFn: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SLam: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_STag: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SRec: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SProj: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SPrim: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_e_2430);
        }
        if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop(v_e_2430);
          heff_drop(v_t_2457);
          if (!heff_strEq_c_lent(v_l_241, v_l2_2431, 0)) {
            heff_drop(v_l2_2431);
            V t_0 = v_x_240;
            V t_1 = v_l_241;
            V t_2 = v_rest_244;
            v_x_240 = t_0;
            v_l_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          } else {
            heff_drop(v_rest_244);
            heff_drop(v_l2_2431);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop(v_l2_2431);
          heff_drop(v_t_2457);
          V v_t_2458 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_e_2430}), v_rest_244});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_2458;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
      case TAG_SPrim: {
        V v_argv_2460 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2461 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2460));
        V v_t_2462 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2461));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2462;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_245);
      }
    }
    case TAG_IOp: {
      V v_x311_2463 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2463)) {
      case TAG_OSimple: {
        V v_v_2464 = heff_field(v_x311_2463, 0);
        heff_take_n(v_x311_2463, 1ULL, 1);
        V v_t_2465 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2464}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2465;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OCall: {
        V v_argv_2467 = heff_field(v_x311_2463, 1);
        heff_take_n(v_x311_2463, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2468 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2467));
        V v_t_2469 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2468));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2469;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OApply: {
        V v_f_2470 = heff_field(v_x311_2463, 0);
        V v_argv_2471 = heff_field(v_x311_2463, 1);
        heff_take_n(v_x311_2463, 3ULL, 2);
        V v_t_2472 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2470, v_argv_2471})));
        V v_t_2473 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2472));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2473;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OPrim: {
        V v_argv_2475 = heff_field(v_x311_2463, 1);
        heff_take_n(v_x311_2463, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2475));
        V v_t_2477 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2476));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2477;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OBool: {
        V v_c_2478 = heff_field(v_x311_2463, 0);
        heff_take_n(v_x311_2463, 1ULL, 1);
        V v_t_2479 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2478}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2479;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_2463);
      }
    }
    case TAG_ICond: {
      V v_x311_2480 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ICond = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2480)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PRel: {
        V v_a_2482 = heff_field(v_x311_2480, 1);
        V v_b_2483 = heff_field(v_x311_2480, 2);
        heff_take_n(v_x311_2480, 6ULL, 3);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2484 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_b_2483}), v_rest_244});
        V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_a_2482}), v_t_2484});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2485;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PBool: {
        V v_v_2486 = heff_field(v_x311_2480, 0);
        heff_take_n(v_x311_2480, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2487 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2486}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2487;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PNot: {
        V v_c_2488 = heff_field(v_x311_2480, 0);
        heff_take_n(v_x311_2480, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2489 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2488}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2489;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PIf: {
        V v_a_2490 = heff_field(v_x311_2480, 0);
        V v_b_2491 = heff_field(v_x311_2480, 1);
        V v_c_2492 = heff_field(v_x311_2480, 2);
        heff_take_n(v_x311_2480, 7ULL, 3);
        V v_t_2493 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2492}), v_rest_244});
        V v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_b_2491}), v_t_2493});
        V v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_2490}), v_t_2494});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2495;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PLet: {
        V v_o_2497 = heff_field(v_x311_2480, 1);
        V v_c_2498 = heff_field(v_x311_2480, 2);
        heff_take_n(v_x311_2480, 6ULL, 3);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2499 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2498}), v_rest_244});
        V v_t_24100 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2497}), v_t_2499});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24100;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_2480);
      }
    }
    case TAG_ISts: {
      V v_x311_24101 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ISts = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24101)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ISts, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_Cons: {
        V v_x3111_24102 = heff_field(v_x311_24101, 0);
        V v_ss_24103 = heff_field(v_x311_24101, 1);
        V v_ru_24x311_24101_24Cons = heff_take_reuse_n(v_x311_24101, 3ULL, 2);
        switch (heff_tag_of(v_x3111_24102)) {
        case TAG_SLet: {
          V v_o_24105 = heff_field(v_x3111_24102, 1);
          heff_take_n(v_x3111_24102, 2ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_24106 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24103}), v_rest_244});
          V v_t_24107 = heff_tag_at_n(v_ru_24x311_24101_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24105}), v_t_24106});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24107;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SDecl: {
          heff_take_n(v_x3111_24102, 0ULL, 1);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          heff_drop_cell(v_ru_24x311_24101_24Cons, 2);
          V v_t_24109 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24103}), v_rest_244});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24109;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SSet: {
          V v_o_24111 = heff_field(v_x3111_24102, 1);
          heff_take_n(v_x3111_24102, 2ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_24112 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24103}), v_rest_244});
          V v_t_24113 = heff_tag_at_n(v_ru_24x311_24101_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24111}), v_t_24112});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24113;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SIf: {
          V v_c_24114 = heff_field(v_x3111_24102, 0);
          V v_ts_24115 = heff_field(v_x3111_24102, 1);
          V v_fs_24116 = heff_field(v_x3111_24102, 2);
          heff_take_n(v_x3111_24102, 7ULL, 3);
          V v_t_24117 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24103}), v_rest_244});
          V v_t_24118 = heff_tag_at_n(v_ru_24x311_24101_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_fs_24116}), v_t_24117});
          V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_24115}), v_t_24118});
          V v_t_24120 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24114}), v_t_24119});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24120;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SCase: {
          V v_v_24121 = heff_field(v_x3111_24102, 0);
          V v_arms_24122 = heff_field(v_x3111_24102, 1);
          heff_take_n(v_x3111_24102, 3ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_24123 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24103}), v_rest_244});
          V v_t_24124 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24122));
          V v_t_24125 = (g_list_2efoldl_24s1104809983x118204267(v_t_24123, v_t_24124));
          V v_t_24126 = heff_tag_at_n(v_ru_24x311_24101_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24121}), v_t_24125});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24126;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x3111_24102);
        }
      }
      default: return heff_nomatch(v_x311_24101);
      }
    }
    case TAG_ITl: {
      V v_x311_24127 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ITl = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24127)) {
      case TAG_TSeq: {
        V v_ss_24128 = heff_field(v_x311_24127, 0);
        V v_t_24129 = heff_field(v_x311_24127, 1);
        V v_ru_24x311_24127_24TSeq = heff_take_reuse_n(v_x311_24127, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24130 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_24129}), v_rest_244});
        V v_t_24131 = heff_tag_at_n(v_ru_24x311_24127_24TSeq, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24128}), v_t_24130});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24131;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TReturn: {
        V v_o_24132 = heff_field(v_x311_24127, 0);
        heff_take_n(v_x311_24127, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24133 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24132}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24133;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TLoop: {
        V v_vs_24134 = heff_field(v_x311_24127, 0);
        heff_take_n(v_x311_24127, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24135 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_24134));
        V v_t_24136 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_24135));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24136;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TIf: {
        V v_c_24137 = heff_field(v_x311_24127, 0);
        V v_t_24138 = heff_field(v_x311_24127, 1);
        V v_e_24139 = heff_field(v_x311_24127, 2);
        heff_take_n(v_x311_24127, 7ULL, 3);
        V v_t_24140 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_e_24139}), v_rest_244});
        V v_t_24141 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ITl, 1, (V[]){v_t_24138}), v_t_24140});
        V v_t_24142 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24137}), v_t_24141});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24142;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TCase: {
        V v_v_24143 = heff_field(v_x311_24127, 0);
        V v_arms_24144 = heff_field(v_x311_24127, 1);
        heff_take_n(v_x311_24127, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24145 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24144));
        V v_t_24146 = (g_list_2efoldl_24s421921225x565177679(v_rest_244, v_t_24145));
        V v_t_24147 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24143}), v_t_24146});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24147;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_24127);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2eothersW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eothersW(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2etakeVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etakeVar_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2etakeVar(V v_ce_240, V v_rest_241, V v_x3_242, V v_l_243, V v_sh_244) {
top: ;
  V v_owned_245 = heff_take_field(v_ce_240, 4);
  V v_borrowed_246 = heff_take_field(v_ce_240, 6);
  V v_after_247 = heff_get_n(v_ce_240, 5, 17);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_rest_241);
    heff_drop(v_l_243);
    heff_drop(v_sh_244);
    heff_drop(v_owned_245);
    heff_drop(v_borrowed_246);
    heff_drop(v_after_247);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_sh_244)) {
    case TAG_Nil: {
      heff_drop(v_rest_241);
      heff_drop(v_l_243);
      heff_drop(v_owned_245);
      heff_drop(v_borrowed_246);
      heff_drop(v_after_247);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_ru_24sh_244_24Cons = heff_take_reuse_n(v_sh_244, 0ULL, 2);
      V v_t_2411 = ({ V a_0 = v_x_248; V a_1 = v_owned_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_owned_245); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_x1_2412 = ({ V a_0 = v_x_248; V a_1 = v_borrowed_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_borrowed_246); r_; });
        if (!(heff_dup(v_x1_2412) == NTAG(TAG_True))) {
          heff_drop(v_x1_2412);
          V v_x1_2413 = ({ V a_0 = v_x_248; V a_1 = v_after_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_after_247); r_; });
          if (!(heff_dup(v_x1_2413) == NTAG(TAG_True))) {
            heff_drop(v_x1_2413);
            V v_t_2414 = (g_heff_2ecompile_2erefcount_2eothersW(v_x_248, v_l_243, v_rest_241));
            if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
              heff_drop(v_t_2414);
              return heff_tag_at_n(v_ru_24sh_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_248), v_l_243}), NTAG(TAG_Nil)});
            } else {
              heff_drop(v_l_243);
              heff_drop_cell(v_ru_24sh_244_24Cons, 2);
              heff_drop(v_t_2414);
              return NTAG(TAG_Nil);
            }
          } else {
            heff_drop(v_rest_241);
            heff_drop(v_l_243);
            heff_drop_cell(v_ru_24sh_244_24Cons, 2);
            heff_drop(v_x1_2413);
            return NTAG(TAG_Nil);
          }
        } else {
          heff_drop(v_rest_241);
          heff_drop(v_l_243);
          heff_drop(v_after_247);
          heff_drop_cell(v_ru_24sh_244_24Cons, 2);
          heff_drop(v_x1_2412);
          return NTAG(TAG_Nil);
        }
      } else {
        heff_drop(v_rest_241);
        heff_drop(v_l_243);
        heff_drop(v_borrowed_246);
        heff_drop(v_after_247);
        heff_drop_cell(v_ru_24sh_244_24Cons, 2);
        heff_drop(v_t_2411);
        return NTAG(TAG_Nil);
      }
    }
    default: return heff_nomatch(v_sh_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2etakeVar_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2etakeVar(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str0, 7, "intHash");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str1, 6, "intShr");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str2, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str3, 6, "intXor");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str4, 6, "intShl");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str5, 6, "intAnd");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str6, 5, "intOr");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str7, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str8, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str9, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str10, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str11, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str12, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str13, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str14, 6, "intSub");

static V g_heff_2ecompile_2erefcount_2eintPrims_val;
static HEFF_ONCE g_heff_2ecompile_2erefcount_2eintPrims_st;
static V g_heff_2ecompile_2erefcount_2eintPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str8), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str10), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str12), v_t_245})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str14), v_t_246})});
}
V g_heff_2ecompile_2erefcount_2eintPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erefcount_2eintPrims_st)) return g_heff_2ecompile_2erefcount_2eintPrims_val;
  return heff_global(&g_heff_2ecompile_2erefcount_2eintPrims_val, &g_heff_2ecompile_2erefcount_2eintPrims_st, g_heff_2ecompile_2erefcount_2eintPrims_init);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2epeekOf_str0, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2erefcount_2epeekOf_str1, 10, "arrayIndex");
Clo g_heff_2ecompile_2erefcount_2epeekOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2epeekOf_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2epeekOf(V v_ce_240, V v_x_241, V v_o_242, V v_rest_243) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_o1_244 = heff_field(v_o_242, 0);
    switch (heff_tag_of(v_o1_244)) {
    case TAG_SVar: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SInt: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SStr: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SBytes: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFixed: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat32: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFn: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      V v_p_2426 = heff_field(v_o1_244, 0);
      V v_argv_2427 = heff_field(v_o1_244, 1);
      if (heff_strEq_c_lent(v_p_2426, ((V)&g_heff_2ecompile_2erefcount_2epeekOf_str0), 2)) {
        HEFF_LAST return g_heff_2ecompile_2erefcount_2epeekArgs(v_ce_240, v_x_241, heff_dup(v_argv_2427), v_rest_243);
      } else {
        heff_drop(v_ce_240);
        heff_drop(v_rest_243);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_o1_244);
    }
  }
  case TAG_OCall: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_OApply: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_OPrim: {
    V v_p_2432 = heff_field(v_o_242, 0);
    V v_argv_2433 = heff_field(v_o_242, 1);
    if (heff_strEq_c_lent(v_p_2432, ((V)&g_heff_2ecompile_2erefcount_2epeekOf_str1), 2)) {
      HEFF_LAST return g_heff_2ecompile_2erefcount_2epeekArgs(v_ce_240, v_x_241, heff_dup(v_argv_2433), v_rest_243);
    } else {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_OAbandon: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_OBool: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_243);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_o_242);
  }
}
V g_heff_2ecompile_2erefcount_2epeekOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2epeekOf(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}

HeffT2 g_heff_2ecompile_2erefcount_2etagGiven_24cpr(V v_ts_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_Nothing: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_v1_242 = heff_field(v_v_241, 0);
    switch (heff_tag_of(v_v1_242)) {
    case TAG_RLocal: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RDup: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RClo: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGet: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGetRaw: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RStr: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RBytes: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFixed: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RF32: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RNTag: {
      V v_t_2415 = heff_field(v_v1_242, 0);
      V v_t_2416 = (g_heff_2ecompile_2erefcount_2eelemS(v_t_2415, v_ts_240));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_t_2415)}});
      } else {
        heff_drop(v_t_2416);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_RTag: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RTagIn: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RRec: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RRecIn: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RField: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RDupE: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFieldV: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGetN: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFieldU: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGetNU: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RWord: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RTakeField: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGetLabel: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPrimFn: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPrim: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RLam: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RCall: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RApply: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RBool: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RAbandon: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RBox: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RUnbox: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPeek: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPrimU: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPrimAt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFixU: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RF32U: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RF64U: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_v1_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_v_241)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2egoneTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2egoneTo_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2egoneTo(V v_acc_240, V v_ss_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erefcount_2egoneOne_clo), 1, (V[]){((V)&g_heff_2ecompile_2erefcount_2egoneTo_clo)}));
  return (g_list_2efoldl(v_t_242, v_acc_240, v_ss_241));
}
V g_heff_2ecompile_2erefcount_2egoneTo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2egoneTo(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(V v_ce_240, V v_live_241, V v_e_242, V v_l_243, V v_t_244, V v_n_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    heff_drop(v_n_245);
    V v_t_247 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, NTAG(TAG_RepV), v_e_242));
    return heff_tag_n(TAG_RGetLabel, 2, (V[]){v_t_247, v_l_243});
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_x8_246, 0);
    V v_may_249 = (g_heff_2ecompile_2erepr_2emayBeFlat(v_t_244));
    HeffT2 v_t_2410 = ({ V a_0 = heff_rfield(v_ce_240, 9); V a_1 = v_live_241; V a_2 = heff_dup(v_e_242); V a_3 = v_l_243; V a_4 = heff_dup(v_i_248); HeffT2 r_ = (g_heff_2ecompile_2erefcount_2etakeIn_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_l_243); r_; });
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        heff_drop_rec(v_ce_240, 17);
        heff_drop(v_live_241);
        heff_drop(v_e_242);
        heff_drop(v_n_245);
        heff_drop(v_may_249);
        V v_t_2413 = v_field_2412;
        return v_t_2413;
      } else {
        heff_drop(v_field_2412);
        return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_e_242; V a_3 = heff_dup(v_i_248); V a_4 = v_n_245; V a_5 = v_may_249; V r_ = (g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_may_249); r_; });
      }
    }
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V r = g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(a[0], a[1], a[2], a[3], a4, a[5], a6); heff_drop(a4); heff_drop(a6); return r;
}
Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x4_242, 0);
    V v_es_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_244)));
    V v_t_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_245); r_; });
    V v_live_247 = (g_prelude_2e_2b_2b(v_t_246, heff_dup(v_live_241)));
    V v_t_248 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_247, NTAG(TAG_RepV), v_e_243));
    V v_cell_249 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(v_ce_240, v_live_241, v_es_244, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(V v_ce_240, V v_live_241, V v_x4_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_242, 0);
    V v_es_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_245)));
    V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_live_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_live_241)));
    V v_t_249 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_248, NTAG(TAG_RepV), v_e_244));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_ce_240;
    V t_1 = v_live_241;
    V t_2 = v_es_245;
    V t_3 = v_cell_2410;
    v_ce_240 = t_0;
    v_live_241 = t_1;
    v_x4_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_str0, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_str1, 14, "arrayReplicate");
Clo g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SVar: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SVar = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(heff_rfield(v_ce_240, 10), v_x_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop_rec(v_ce_240, 17);
        heff_drop(v_live_241);
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RLocal, 1, (V[]){v_x_243});
      } else {
        heff_drop(v_field_246);
        V v_t_248 = ({ V a_0 = v_x_243; V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_t_248);
          return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RDup, 1, (V[]){v_x_243});
        } else {
          heff_drop(v_t_248);
          V v_t_249 = ({ V a_0 = v_x_243; V b_1 = heff_get_n(v_ce_240, 6, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RDup, 1, (V[]){v_x_243});
          } else {
            heff_drop(v_t_249);
            return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RLocal, 1, (V[]){v_x_243});
          }
        }
      }
    }
  }
  case TAG_SGlobal: {
    V v_g_2410 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SGlobal = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_live_241);
    HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_ce_240, 0, 17); V a_1 = v_g_2410; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_x_2414 = v_field_2413;
        heff_drop(v_x_2414);
        return heff_tag_at_n(v_ru_24x4_242_24SGlobal, TAG_RClo, 1, (V[]){v_g_2410});
      } else {
        heff_drop(v_field_2413);
        return heff_tag_at_n(v_ru_24x4_242_24SGlobal, TAG_RGet, 1, (V[]){v_g_2410});
      }
    }
  }
  case TAG_SInt: {
    V v_n_2415 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SInt = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SInt, TAG_RInt, 1, (V[]){v_n_2415});
  }
  case TAG_SFloat: {
    double v_x_2416 = heff_tflat_f64(v_x4_242, 0);
    V v_ru_24x4_242_24SFloat = heff_take_reuse_na(v_x4_242, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_nf(v_ru_24x4_242_24SFloat, TAG_RFloat, 1, 1u, (V[]){heff_word_f64(v_x_2416)});
  }
  case TAG_SStr: {
    V v_s_2417 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SStr = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SStr, TAG_RStr, 1, (V[]){v_s_2417});
  }
  case TAG_SBytes: {
    V v_s_2418 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SBytes = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SBytes, TAG_RBytes, 1, (V[]){v_s_2418});
  }
  case TAG_SFixed: {
    V v_w_2419 = heff_field(v_x4_242, 0);
    V v_n_2420 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SFixed = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SFixed, TAG_RFixed, 2, (V[]){v_w_2419, v_n_2420});
  }
  case TAG_SFloat32: {
    double v_x_2421 = heff_tflat_f64(v_x4_242, 0);
    V v_ru_24x4_242_24SFloat32 = heff_take_reuse_na(v_x4_242, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_nf(v_ru_24x4_242_24SFloat32, TAG_RF32, 1, 1u, (V[]){heff_word_f64(v_x_2421)});
  }
  case TAG_SPrimFn: {
    V v_p_2422 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SPrimFn = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SPrimFn, TAG_RPrimFn, 1, (V[]){v_p_2422});
  }
  case TAG_SLam: {
    V v_xs_2423 = heff_field(v_x4_242, 0);
    V v_x42_2424 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x42_2424)) {
    case TAG_MkBlock: {
      V v_t_2425 = heff_field(v_x42_2424, 0);
      V v_ru_24x42_2424_24MkBlock = heff_take_reuse_n(v_x42_2424, 1ULL, 1);
      V v_t_2426 = (g_heff_2ecompile_2erefcount_2efreeOf(heff_dup(v_xs_2423), heff_dup(v_t_2425)));
      return (g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1(v_ru_24x42_2424_24MkBlock, v_ce_240, v_live_241, v_xs_2423, v_t_2425, v_t_2426));
    }
    default: return heff_nomatch(v_x42_2424);
    }
  }
  case TAG_STag: {
    V v_t_2427 = heff_field(v_x4_242, 0);
    V v_argv_2428 = heff_field(v_x4_242, 1);
    V v_ts_2429 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24STag = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    switch (heff_tag_of(v_argv_2428)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_live_241);
      heff_drop(v_ts_2429);
      heff_drop_cell(v_ru_24x4_242_24STag, 3);
      return heff_tag_n(TAG_RNTag, 1, (V[]){v_t_2427});
    }
    case TAG_Cons: {
      return ({ V a_0 = v_ru_24x4_242_24STag; V a_1 = v_ce_240; V a_2 = v_live_241; V a_3 = v_t_2427; V a_4 = v_argv_2428; V a_5 = v_ts_2429; V r_ = (g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_ts_2429); r_; });
    }
    default: return heff_nomatch(v_argv_2428);
    }
  }
  case TAG_SRec: {
    V v_fs_2432 = heff_field(v_x4_242, 0);
    V v_ts_2433 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SRec = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2434 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x4_242_24SRec, heff_dup(v_fs_2432)));
    V v_t_2435 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_live_241; V a_2 = v_t_2434; V a_3 = heff_dup(v_fs_2432); V r_ = (g_heff_2ecompile_2erefcount_2eupdatedIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2434); r_; });
    return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_fs_2432; V a_3 = v_ts_2433; V a_4 = v_t_2435; V r_ = (g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ts_2433); heff_drop(v_t_2435); r_; });
  }
  case TAG_SProj: {
    V v_e_2436 = heff_field(v_x4_242, 0);
    V v_l_2437 = heff_field(v_x4_242, 1);
    V v_sh_2438 = heff_field(v_x4_242, 2);
    V v_t_2439 = heff_field(v_x4_242, 3);
    heff_take_n(v_x4_242, 15ULL, 4);
    V v_t_2440 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2438));
    V v_t_2441 = (g_heff_2ecompile_2erefcount_2eindexIn(v_l_2437, MK_INT(0LL), v_sh_2438));
    return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_e_2436; V a_3 = v_l_2437; V a_4 = v_t_2439; V a_5 = v_t_2440; V a_6 = v_t_2441; V r_ = (g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2439); heff_drop(v_t_2441); r_; });
  }
  case TAG_SPrim: {
    V v_p_2442 = heff_field(v_x4_242, 0);
    V v_argv_2443 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SPrim = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2444;
    if (heff_strEq_c_lent(v_p_2442, ((V)&g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_str0), 2)) {
      v_t_2444 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(2LL)});
    } else {
      if (heff_strEq_c_lent(v_p_2442, ((V)&g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_str1), 2)) {
        v_t_2444 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(1LL)});
      } else {
        v_t_2444 = NTAG(TAG_Nothing);
      }
    }
    return (g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_24tok2(v_ru_24x4_242_24SPrim, v_ce_240, v_live_241, v_p_2442, v_argv_2443, v_t_2444));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769(V v_ce_240, V v_c_241, V v_yes_242, V v_no_243, V v_wanted_244) {
top: ;
  V v_xs_247 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam0, 1, 1, (V[]){heff_dup(v_wanted_244)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_248 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_247));
  V v_t_249 = (g_list_2emap_24s1796125103x644876049(v_t_248));
  V v_t_2411 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam1, 1, 1, (V[]){heff_dup(v_wanted_244)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_ce_2412 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2411, heff_dup(v_wanted_244), heff_dup(v_ce_240)));
  V v_t_2413 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_2412, 4)), heff_dup(heff_rfield(v_ce_2412, 6))));
  V v_t_2414 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2413, v_ce_2412));
  V v_t_2415 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2414));
  V v_t_2416 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_2415, v_c_241));
  V v_t_2418 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam2, 1, 1, (V[]){heff_dup(v_wanted_244)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2419 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2418, heff_dup(heff_rfield(v_ce_240, 5)), heff_dup(v_ce_240)));
  V v_t_2420 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2419, v_yes_242));
  V v_t_2422 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam3, 1, 1, (V[]){v_wanted_244}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2423 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2422, heff_dup(heff_rfield(v_ce_240, 5)), v_ce_240));
  V v_t_2424 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2423, v_no_243));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_t_2416, v_t_2420, v_t_2424}), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_t_249, v_t_2425));
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769(a[0], a[1], a2, a3, a[4]); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam0(V self, V *args) {
  V v_v_245 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_246 = ({ V a_0 = v_v_245; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_245); heff_drop(v_wanted_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_246) == NTAG(TAG_True)));
  heff_drop(v_x1_246);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam1(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2410; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2410); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam2(V self, V *args) {
  V v_v_2417 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2417; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2417); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam3(V self, V *args) {
  V v_v_2421 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2421; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2421); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(V v_ce_240, V v_p_241, V v_args_242, V v_yes_243, V v_no_244, V v_fa_245, V v_wb_246) {
top: ;
  V v_wanted_247 = (g_prelude_2e_2b_2b(heff_dup(v_fa_245), heff_dup(v_wb_246)));
  V v_xs_2410 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam0, 1, 1, (V[]){v_wanted_247}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2411 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2410));
  V v_t_2412 = (g_list_2emap_24s1796125103x644876049(v_t_2411));
  V v_wanted_2413 = (g_prelude_2e_2b_2b(v_fa_245, heff_dup(v_wb_246)));
  V v_t_2415 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam1, 1, 1, (V[]){v_wanted_2413}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_ce_2416 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2415, heff_dup(v_wb_246), heff_dup(v_ce_240)));
  HeffT2 v_t_2417 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_241));
  V v_t_2423;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_sh_2420 = v_field_2419;
      V v_t_2421 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_2416, heff_dup(v_wb_246), heff_get_n(v_sh_2420, 0, 2), v_args_242));
      v_t_2423 = heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_241, v_t_2421});
    } else {
      heff_drop(v_field_2419);
      V v_t_2422 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_2416, heff_dup(v_wb_246), v_args_242));
      v_t_2423 = heff_tag_n(TAG_CondRel, 2, (V[]){v_p_241, v_t_2422});
    }
  }
  V v_t_2425 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam2, 1, 1, (V[]){heff_dup(v_wb_246)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2426 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2425, heff_dup(heff_rfield(v_ce_240, 5)), heff_dup(v_ce_240)));
  V v_t_2427 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2426, v_yes_243));
  V v_t_2429 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam3, 1, 1, (V[]){v_wb_246}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2430 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2429, heff_dup(heff_rfield(v_ce_240, 5)), v_ce_240));
  V v_t_2431 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2430, v_no_244));
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_t_2423, v_t_2427, v_t_2431}), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_t_2412, v_t_2432));
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(a[0], a[1], a[2], a3, a4, a[5], a[6]); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam0(V self, V *args) {
  V v_v_248 = args[0];
  V v_wanted_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = ({ V a_0 = v_v_248; V a_1 = v_wanted_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_248); heff_drop(v_wanted_247); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
  heff_drop(v_x1_249);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam1(V self, V *args) {
  V v_v_2414 = args[0];
  V v_wanted_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2414; V a_1 = v_wanted_2413; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2414); heff_drop(v_wanted_2413); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam2(V self, V *args) {
  V v_v_2424 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2424; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2424); heff_drop(v_wb_246); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam3(V self, V *args) {
  V v_v_2428 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2428; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2428); heff_drop(v_wb_246); r_; });
}
Clo g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(V v_ce_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    V v_x_242 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SVar = heff_take_reuse_n(v_v_241, 1ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_at_n(v_ru_24v_241_24SVar, TAG_RLocal, 1, (V[]){v_x_242});
  }
  case TAG_SGlobal: {
    V v_g_243 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SGlobal = heff_take_reuse_n(v_v_241, 1ULL, 1);
    HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_ce_240, 0, 17); V a_1 = v_g_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_RClo, 1, (V[]){v_g_243});
      } else {
        heff_drop(v_field_246);
        return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_RGetRaw, 1, (V[]){v_g_243});
      }
    }
  }
  case TAG_SInt: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFloat: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SStr: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SBytes: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFixed: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFloat32: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SPrimFn: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SLam: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_STag: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SRec: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SProj: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SPrim: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2efunPlain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efunPlain_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2efunPlain(V v_ce_240, V v_key_241, V v_xs_242, V v_b_243) {
top: ;
  HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 7), v_key_241));
  V v_t_248;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      v_t_248 = v_x_247;
    } else {
      heff_drop(v_field_246);
      v_t_248 = NTAG(TAG_Nil);
    }
  }
  HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 11), v_key_241));
  V v_t_2413;
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_s_2412 = v_field_2411;
      v_t_2413 = heff_get_n(v_s_2412, 0, 2);
    } else {
      heff_drop(v_field_2411);
      v_t_2413 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_xs_242)));
    }
  }
  V v_t_2414 = (g_std_2emap_2elookup_24s1930949324x2078207031(heff_rfield(v_ce_240, 11), v_key_241));
  return (g_heff_2ecompile_2erefcount_2efunWith(v_ce_240, v_key_241, v_xs_242, v_b_243, v_t_248, v_t_2413, v_t_2414));
}
V g_heff_2ecompile_2erefcount_2efunPlain_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efunPlain(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ecoerce_24tok2(V v_tok_240, V v_from_241, V v_to_242, V v_v_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2erepr_2ereprEq(v_from_241, v_to_242));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_from_241);
    heff_drop(v_to_242);
    heff_drop(v_t_244);
    return v_v_243;
  } else {
    heff_drop(v_t_244);
    V v_t_246;
    switch (heff_tag_of(v_to_242)) {
    case TAG_RepV: {
      v_t_246 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_RepF64: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_RepInt: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_to_242);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_to_242);
      heff_drop(v_t_246);
      return heff_tag_at_n(v_tok_240, TAG_RBox, 2, (V[]){v_from_241, v_v_243});
    } else {
      heff_drop(v_t_246);
      switch (heff_tag_of(v_from_241)) {
      case TAG_RepV: {
        heff_drop_cell(v_tok_240, 2);
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_242, v_v_243));
      }
      case TAG_RepFix: {
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_242, heff_tag_at_n(v_tok_240, TAG_RBox, 2, (V[]){v_from_241, v_v_243})));
      }
      case TAG_RepF64: {
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_242, heff_tag_at_n(v_tok_240, TAG_RBox, 2, (V[]){v_from_241, v_v_243})));
      }
      case TAG_RepInt: {
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_242, heff_tag_at_n(v_tok_240, TAG_RBox, 2, (V[]){v_from_241, v_v_243})));
      }
      default: return heff_nomatch(v_from_241);
      }
    }
  }
}
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecoerce_24tok2(a[0], a[1], a[2], a[3]);
}