// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CIf 14188
#define TAG_Given 9359
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_KnownCell 38933
#define TAG_KnownClo 18392
#define TAG_KnownRec 32578
#define TAG_KnownTag 34380
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkDrop 35958
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RBytes 24984
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RF32 30142
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPrim 49376
#define TAG_RPrimFn 2224
#define TAG_RStr 44714
#define TAG_RTagIn 62720
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define TAG_TakeKeep 54413
#define TAG_TakeN 37047
#define TAG_TakeNone 22612
#define LBL_after 294093302
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_counted 1189688364
#define LBL_flat 9641024
#define LBL_flats 298871860
#define LBL_funs 9650075
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_n 328
#define LBL_names 305943394
#define LBL_owned 307523263
#define LBL_plain 308106724
#define LBL_reprs 309759928
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tag 324116
#define LBL_takes 311482598
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_sureRecs, LBL_ret};
static uint32_t shape_plain__flats__names__counted__flat__sure[] = {LBL_plain, LBL_flats, LBL_names, LBL_counted, LBL_flat, LBL_sure};
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(V, V);
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_clo;
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(V, V);
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_clo;
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_clo;
V g_heff_2ecompile_2erefcount_2edropOf(V, V);
V g_heff_2ecompile_2erefcount_2edropOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropOf_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_clo;
V g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539_clo;
V g_heff_2ecompile_2erefcount_2efieldMask(V, V, V);
V g_heff_2ecompile_2erefcount_2efieldMask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldMask_clo;
V g_heff_2ecompile_2erefcount_2eflatOnes(V, V, V);
V g_heff_2ecompile_2erefcount_2eflatOnes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eflatOnes_clo;
V g_heff_2ecompile_2erefcount_2eflatnessOf(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eflatnessOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eflatnessOf_clo;
V g_heff_2ecompile_2erefcount_2efreeOf(V, V);
V g_heff_2ecompile_2erefcount_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeOf_clo;
V g_heff_2ecompile_2erefcount_2eindexIn(V, V, V);
V g_heff_2ecompile_2erefcount_2eindexIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eindexIn_clo;
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_clo;
V g_heff_2ecompile_2erefcount_2eothersW(V, V, V);
V g_heff_2ecompile_2erefcount_2eothersW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eothersW_clo;
V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_clo;
V g_heff_2ecompile_2erefcount_2ereadsWith(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ereadsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereadsWith_clo;
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_clo;
V g_heff_2ecompile_2erefcount_2erelTest_24s1551809647x1570729674(V, V, V, V);
V g_heff_2ecompile_2erefcount_2erelTest_24s1551809647x1570729674_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2erelTest_24s1551809647x1570729674_clo;
V g_heff_2ecompile_2erefcount_2ereuseArgs(V, V);
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo;
V g_heff_2ecompile_2erefcount_2ereusePrim_get(void);
V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_clo;
V g_heff_2ecompile_2erefcount_2ereuseV(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseV_clo;
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_clo;
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(V, V);
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_clo;
V g_heff_2ecompile_2erefcount_2eslotBits(V);
V g_heff_2ecompile_2erefcount_2eslotBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eslotBits_clo;
V g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481(V, V, V);
V g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481_clo;
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_clo;
V g_heff_2ecompile_2erefcount_2etakeIn(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeIn_clo;
V g_heff_2ecompile_2erefcount_2etakeOf(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeOf_clo;
V g_heff_2ecompile_2erefcount_2etakeVar(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeVar_clo;
V g_heff_2ecompile_2erefcount_2eunboxParam(V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxParam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxParam_clo;
V g_heff_2ecompile_2erefcount_2eunboxParams(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxParams_clo;
V g_heff_2ecompile_2erefcount_2eupdatedIn(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eupdatedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eupdatedIn_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(V, V, V);
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1435885690x1984517496(V, V);
V g_list_2eany_24s1435885690x1984517496_entry(V self, V *a);
extern Clo g_list_2eany_24s1435885690x1984517496_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s179107915x1917665184(V);
V g_list_2efilter_24s179107915x1917665184_entry(V self, V *a);
extern Clo g_list_2efilter_24s179107915x1917665184_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f1686830387x1555365313(V, V, V, V);
V g_list_2efoldl_24f1686830387x1555365313_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1686830387x1555365313_clo;
V g_list_2efoldl_24f613246640x472569916(V, V, V, V);
V g_list_2efoldl_24f613246640x472569916_entry(V self, V *a);
extern Clo g_list_2efoldl_24f613246640x472569916_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s421921225x565177679(V, V);
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a);
extern Clo g_list_2efoldl_24s421921225x565177679_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s826961155x1314392429(V, V);
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s826961155x1314392429_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s870182194x1066240094(V, V);
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithBorrowed_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ewithBorrowed(V v_bs_240, V v_ce_241) {
top: ;
  return ({ V rv_6 = v_bs_240; V rr_ = heff_rec_reuse_nf(v_ce_241, 65471ULL, 16, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__ret, 4294955007u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithBorrowed(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2edropOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2edropOf_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2edropOf(V v_x_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_k_241)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_x11_242 = heff_dup(heff_field(v_k_241, 0));
    switch (heff_tag_of(v_x11_242)) {
    case TAG_KnownTag: {
      V v_n_243 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_intLt_c(MK_INT(0LL), v_n_243)) {
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_x_240);
        heff_drop_tag(v_k_241, 1);
        return NTAG(TAG_Nil);
      }
    }
    case TAG_KnownCell: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
    }
    case TAG_KnownRec: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
    }
    case TAG_KnownClo: {
      V v_n_247 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_intLt_c(MK_INT(0LL), v_n_247)) {
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_x_240);
        heff_drop_tag(v_k_241, 1);
        return NTAG(TAG_Nil);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_k_241);
  }
}
V g_heff_2ecompile_2erefcount_2edropOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2edropOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2elentThen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentThen_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2elentThen(V v_ce_240, V v_bi_241, V v_i_242, V v_e_243, V v_before_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2erefcount_2eelemI(v_i_242, v_bi_241));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    switch (heff_tag_of(v_e_243)) {
    case TAG_SVar: {
      V v_x_246 = heff_field(v_e_243, 0);
      V v_x3_247 = ({ V a_0 = heff_dup(v_x_246); V b_1 = heff_get_n(v_ce_240, 10, 16); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_246), v_before_244});
      }
      case TAG_Just: {
        heff_take_n(v_x3_247, 0ULL, 1);
        return v_before_244;
      }
      default: return heff_nomatch(v_x3_247);
      }
    }
    case TAG_SGlobal: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SInt: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SFloat: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SStr: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SBytes: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SFixed: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SFloat32: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SPrimFn: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SLam: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_STag: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SRec: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SProj: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SPrim: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    default: return heff_nomatch(v_e_243);
    }
  } else {
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_t_245);
    return v_before_244;
  }
}
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2elentThen(a[0], a1, a[2], a3, a[4]); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erefcount_2ereadsWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ereadsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereadsWith_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ereadsWith(V v_ce_240, V v_su_241, V v_ws_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_ce_240);
    heff_drop(v_su_241);
    return heff_rec_n(6, shape_plain__flats__names__counted__flat__sure, (V[]){v_ws_242, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_ps_244 = heff_field(v_x4_243, 0);
    V v_fs_245 = (g_heff_2ecompile_2erefcount_2eflatOnes(v_ce_240, v_ps_244, heff_dup(v_ws_242)));
    V v_t_248 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2ereadsWith_lam0, 1, 1, (V[]){heff_dup(v_fs_245)}), v_ws_242));
    V v_t_249 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_245)));
    V v_t_2410 = (g_list_2efilter_24s179107915x1917665184(heff_dup(v_fs_245)));
    V v_t_2411 = (g_list_2emap_24s1937570095x2110149801(v_t_2410));
    return heff_rec_n(6, shape_plain__flats__names__counted__flat__sure, (V[]){v_t_248, v_fs_245, v_t_249, v_t_2411, NTAG(TAG_True), v_su_241});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erefcount_2ereadsWith_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2ereadsWith(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erefcount_2ereadsWith_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_fs_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_247 = ({ V a_0 = v_p_246; V a_1 = v_fs_245; V r_ = (g_list_2eany_24s1435885690x1984517496(a_0, a_1)); heff_drop(v_p_246); heff_drop(v_fs_245); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
  heff_drop(v_x1_247);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2erefcount_2etakeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etakeOf_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2etakeOf(V v_fl_240, V v_su_241, V v_x3_242, V v_taken_243, V v_vs_244, V v_used_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_taken_243)) {
    case TAG_Nothing: {
      return NTAG(TAG_TakeNone);
    }
    case TAG_Just: {
      V v_t_247 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_245, MK_INT(0LL), v_vs_244));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
      V v_t_249 = (g_heff_2ecompile_2erefcount_2eflatnessOf(v_fl_240, v_su_241, v_t_247, v_t_248));
      V v_t_2410 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_245, MK_INT(0LL), v_vs_244));
      V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
      return heff_tag_n(TAG_TakeN, 3, (V[]){v_t_249, v_t_2410, v_t_2411});
    }
    default: return heff_nomatch(v_taken_243);
    }
  }
  case TAG_Just: {
    V v_ru_2412 = heff_field(v_x3_242, 0);
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_245, MK_INT(0LL), v_vs_244));
    V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
    V v_t_2415 = (g_heff_2ecompile_2erefcount_2eflatnessOf(v_fl_240, v_su_241, v_t_2413, v_t_2414));
    V v_t_2416 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_245, MK_INT(0LL), v_vs_244));
    V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
    return heff_tag_n(TAG_TakeKeep, 4, (V[]){v_t_2415, heff_dup(v_ru_2412), v_t_2416, v_t_2417});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2etakeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2ecompile_2erefcount_2etakeOf(a0, a1, a2, a3, a4, a5); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2ecompile_2erefcount_2ereuseArgs_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereuseArgs_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ereuseArgs(V v_go_240, V v_vs_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), NTAG(TAG_Nil)});
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseArgs_lam0, 2, 1, (V[]){v_go_240}), v_t_242, v_vs_241));
}
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2ereuseArgs(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2ereuseArgs_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_v_244 = args[1];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_acc_243)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_acc_243, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_acc_243);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_go_240);
    heff_drop(v_t_247);
    V v_t_2410;
    switch (heff_tag_of(v_acc_243)) {
    case TAG_MkPair: {
      V v_y_249 = heff_field(v_acc_243, 1);
      heff_take_n(v_acc_243, 2ULL, 2);
      v_t_2410 = v_y_249;
      break;
    }
    default: heff_nomatch(v_acc_243);
    }
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_244, NTAG(TAG_Nil)});
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2411));
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_t_2412});
  } else {
    heff_drop(v_t_247);
    V v_x2_2413 = heff_tr(heff_call(v_go_240, 1, (V[]){v_v_244}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_b_2414 = heff_field(v_x2_2413, 0);
      V v_e_2415 = heff_field(v_x2_2413, 1);
      V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_acc_243)) {
      case TAG_MkPair: {
        V v_y_2417 = heff_field(v_acc_243, 1);
        heff_take_n(v_acc_243, 2ULL, 2);
        v_t_2418 = v_y_2417;
        break;
      }
      default: heff_nomatch(v_acc_243);
      }
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2415, NTAG(TAG_Nil)});
      V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2419));
      return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_b_2414, v_t_2420});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereuseV_str0, 0, "");
V g_heff_2ecompile_2erefcount_2ereuseV_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ereuseV_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ereuseV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereuseV_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ereuseV(V v_ru_240, V v_n_241, V v_v_242) {
top: ;
  switch (heff_tag_of(v_v_242)) {
  case TAG_SVar: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SGlobal: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SInt: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SFloat: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SStr: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SBytes: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SFixed: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SFloat32: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SPrimFn: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SLam: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_STag: {
    V v_t_2415 = heff_field(v_v_242, 0);
    V v_as_2416 = heff_field(v_v_242, 1);
    V v_ts_2417 = heff_field(v_v_242, 2);
    V v_ru_24v_242_24STag = heff_take_reuse_n(v_v_242, 7ULL, 3);
    V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2416));
    if (heff_intEq_c(v_t_2418, heff_dup(heff_rfield(v_n_241, 0)))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_n_241, 1)), ((V)&g_heff_2ecompile_2erefcount_2ereuseV_str0))) {
        heff_drop_rec(v_n_241, 2);
        V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v_242_24STag, TAG_STag, 3, (V[]){v_t_2415, v_as_2416, v_ts_2417}), NTAG(TAG_Nil)});
        V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_ru_240}), v_t_2421});
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_n(TAG_SPrim, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2ereusePrim_get()), v_t_2422})});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_n_241, 1)), heff_dup(v_t_2415))) {
          heff_drop_rec(v_n_241, 2);
          V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v_242_24STag, TAG_STag, 3, (V[]){v_t_2415, v_as_2416, v_ts_2417}), NTAG(TAG_Nil)});
          V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_ru_240}), v_t_2424});
          return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_n(TAG_SPrim, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2ereusePrim_get()), v_t_2425})});
        } else {
          V v_x3_2427 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseV_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_as_2416; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_as_2416); r_; });
          switch (heff_tag_of(v_x3_2427)) {
          case TAG_MkPair: {
            V v_b_2428 = heff_field(v_x3_2427, 0);
            V v_as_2429 = heff_field(v_x3_2427, 1);
            V v_ru_24x3_2427_24MkPair = heff_take_reuse_n(v_x3_2427, 3ULL, 2);
            return heff_tag_at_n(v_ru_24x3_2427_24MkPair, TAG_MkPair, 2, (V[]){v_b_2428, heff_tag_at_n(v_ru_24v_242_24STag, TAG_STag, 3, (V[]){v_t_2415, v_as_2429, v_ts_2417})});
          }
          default: return heff_nomatch(v_x3_2427);
          }
        }
      }
    } else {
      V v_x3_2431 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseV_lam1, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_as_2416; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_as_2416); r_; });
      switch (heff_tag_of(v_x3_2431)) {
      case TAG_MkPair: {
        V v_b_2432 = heff_field(v_x3_2431, 0);
        V v_as_2433 = heff_field(v_x3_2431, 1);
        V v_ru_24x3_2431_24MkPair = heff_take_reuse_n(v_x3_2431, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x3_2431_24MkPair, TAG_MkPair, 2, (V[]){v_b_2432, heff_tag_at_n(v_ru_24v_242_24STag, TAG_STag, 3, (V[]){v_t_2415, v_as_2433, v_ts_2417})});
      }
      default: return heff_nomatch(v_x3_2431);
      }
    }
  }
  case TAG_SRec: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SProj: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SPrim: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  default: return heff_nomatch(v_v_242);
  }
}
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ereuseV(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2ereuseV_lam0(V self, V *args) {
  V v_v_2426 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_2426));
}
V g_heff_2ecompile_2erefcount_2ereuseV_lam1(V self, V *args) {
  V v_v_2430 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_2430));
}
V g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481(V v_ru_240, V v_n_241, V v_arms_242) {
top: ;
  V v_t_2410 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481_lam0, 1, 2, (V[]){heff_dup(v_ru_240), heff_dup(v_n_241)}), v_arms_242));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481_lam1, 1, 2, (V[]){v_ru_240, v_n_241}), v_arms_242));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_t_2419});
}
V g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481_lam0(V self, V *args) {
  V v_arm_243 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_243)) {
  case TAG_MkArm: {
    V v_ss_246 = heff_field(v_arm_243, 2);
    heff_take_n(v_arm_243, 4ULL, 3);
    V v_x1_247 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(v_ru_240, v_n_241, v_ss_246));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      return v_x_248;
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  default: return heff_nomatch(v_arm_243);
  }
}
V g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481_lam1(V self, V *args) {
  V v_arm_2411 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_2411)) {
  case TAG_MkArm: {
    V v_t_2412 = heff_field(v_arm_2411, 0);
    V v_vs_2413 = heff_field(v_arm_2411, 1);
    V v_ss_2414 = heff_field(v_arm_2411, 2);
    V v_ru_24arm_2411_24MkArm = heff_take_reuse_n(v_arm_2411, 7ULL, 3);
    V v_x1_2415 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(v_ru_240, v_n_241, v_ss_2414));
    V v_t_2418;
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_MkPair: {
      V v_y_2417 = heff_field(v_x1_2415, 1);
      heff_take_n(v_x1_2415, 2ULL, 2);
      v_t_2418 = v_y_2417;
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    return heff_tag_at_n(v_ru_24arm_2411_24MkArm, TAG_MkArm, 3, (V[]){v_t_2412, v_vs_2413, v_t_2418});
  }
  default: return heff_nomatch(v_arm_2411);
  }
}
Clo g_heff_2ecompile_2erefcount_2eothersW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eothersW_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eothersW(V v_x_240, V v_l_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    heff_drop(v_l_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_IVal: {
      V v_x311_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_245)) {
      case TAG_SVar: {
        V v_y_246 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        if (heff_strEq_c_lent(v_x_240, v_y_246, 2)) {
          heff_drop(v_x_240);
          heff_drop(v_l_241);
          heff_drop(v_rest_244);
          return NTAG(TAG_False);
        } else {
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_rest_244;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
      case TAG_SGlobal: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SInt: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat: {
        heff_take_na(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SStr: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SBytes: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFixed: {
        heff_take_n(v_x311_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SLam: {
        V v_x3112_2418 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        switch (heff_tag_of(v_x3112_2418)) {
        case TAG_MkBlock: {
          V v_t_2419 = heff_field(v_x3112_2418, 0);
          heff_take_n(v_x3112_2418, 1ULL, 1);
          V v_ps_2420 = ({ V a_0 = v_t_2419; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2419); r_; });
          V v_t_2421 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_dup(v_x_240); V a_3 = v_ps_2420; V r_ = (g_list_2efoldl_24f613246640x472569916(a_0, a_1, a_2, a_3)); heff_drop(v_ps_2420); r_; });
          if (heff_intEq_c(v_t_2421, MK_INT(0LL))) {
            V t_0 = v_x_240;
            V t_1 = v_l_241;
            V t_2 = v_rest_244;
            v_x_240 = t_0;
            v_l_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          } else {
            heff_drop(v_x_240);
            heff_drop(v_l_241);
            heff_drop(v_rest_244);
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_x3112_2418);
        }
      }
      case TAG_STag: {
        V v_as_2424 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2424));
        V v_t_2427 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2426));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2427;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SRec: {
        V v_fs_2428 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2430 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2428));
        V v_t_2431 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2430));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2431;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SProj: {
        V v_e_2432 = heff_field(v_x311_245, 0);
        V v_l2_2433 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 3ULL, 4);
        V v_t_2459;
        switch (heff_tag_of(v_e_2432)) {
        case TAG_SVar: {
          V v_y_2436 = heff_dup(heff_field(v_e_2432, 0));
          v_t_2459 = heff_strEq_lent(v_x_240, v_y_2436, 2);
          break;
        }
        case TAG_SGlobal: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SInt: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SFloat: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SStr: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SBytes: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SFixed: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SFloat32: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SPrimFn: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SLam: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_STag: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SRec: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SProj: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SPrim: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_e_2432);
        }
        if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop(v_e_2432);
          heff_drop(v_t_2459);
          if (heff_strEq_c_lent(v_l_241, v_l2_2433, 2)) {
            heff_drop(v_x_240);
            heff_drop(v_l_241);
            heff_drop(v_rest_244);
            return NTAG(TAG_False);
          } else {
            V t_0 = v_x_240;
            V t_1 = v_l_241;
            V t_2 = v_rest_244;
            v_x_240 = t_0;
            v_l_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          }
        } else {
          heff_drop(v_l2_2433);
          heff_drop(v_t_2459);
          V v_t_2461 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_e_2432}), v_rest_244});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_2461;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
      case TAG_SPrim: {
        V v_as_2463 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2464 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2463));
        V v_t_2465 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2464));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2465;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_245);
      }
    }
    case TAG_IOp: {
      V v_x311_2466 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2466)) {
      case TAG_OSimple: {
        V v_v_2467 = heff_field(v_x311_2466, 0);
        heff_take_n(v_x311_2466, 1ULL, 1);
        V v_t_2468 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2467}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2468;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OCall: {
        V v_as_2470 = heff_field(v_x311_2466, 1);
        heff_take_n(v_x311_2466, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2471 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2470));
        V v_t_2472 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2471));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2472;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OApply: {
        V v_f_2473 = heff_field(v_x311_2466, 0);
        V v_as_2474 = heff_field(v_x311_2466, 1);
        heff_take_n(v_x311_2466, 3ULL, 2);
        V v_t_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2473, v_as_2474})));
        V v_t_2476 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2475));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2476;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OPrim: {
        V v_as_2478 = heff_field(v_x311_2466, 1);
        heff_take_n(v_x311_2466, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2478));
        V v_t_2480 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2479));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2480;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OBool: {
        V v_c_2481 = heff_field(v_x311_2466, 0);
        heff_take_n(v_x311_2466, 1ULL, 1);
        V v_t_2482 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2481}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2482;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_2466);
      }
    }
    case TAG_ICond: {
      V v_x311_2483 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ICond = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2483)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PRel: {
        V v_a_2485 = heff_field(v_x311_2483, 1);
        V v_b_2486 = heff_field(v_x311_2483, 2);
        heff_take_n(v_x311_2483, 6ULL, 3);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2487 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_b_2486}), v_rest_244});
        V v_t_2488 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_a_2485}), v_t_2487});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2488;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PBool: {
        V v_v_2489 = heff_field(v_x311_2483, 0);
        heff_take_n(v_x311_2483, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2490 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2489}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2490;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PNot: {
        V v_c_2491 = heff_field(v_x311_2483, 0);
        heff_take_n(v_x311_2483, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2492 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2491}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2492;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PIf: {
        V v_a_2493 = heff_field(v_x311_2483, 0);
        V v_b_2494 = heff_field(v_x311_2483, 1);
        V v_c_2495 = heff_field(v_x311_2483, 2);
        heff_take_n(v_x311_2483, 7ULL, 3);
        V v_t_2496 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2495}), v_rest_244});
        V v_t_2497 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_b_2494}), v_t_2496});
        V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_2493}), v_t_2497});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2498;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PLet: {
        V v_o_24100 = heff_field(v_x311_2483, 1);
        V v_c_24101 = heff_field(v_x311_2483, 2);
        heff_take_n(v_x311_2483, 6ULL, 3);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_24102 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24101}), v_rest_244});
        V v_t_24103 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24100}), v_t_24102});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24103;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_2483);
      }
    }
    case TAG_ISts: {
      V v_x311_24104 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ISts = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24104)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ISts, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_Cons: {
        V v_x3111_24105 = heff_field(v_x311_24104, 0);
        V v_ss_24106 = heff_field(v_x311_24104, 1);
        V v_ru_24x311_24104_24Cons = heff_take_reuse_n(v_x311_24104, 3ULL, 2);
        switch (heff_tag_of(v_x3111_24105)) {
        case TAG_SLet: {
          V v_o_24108 = heff_field(v_x3111_24105, 1);
          heff_take_n(v_x3111_24105, 2ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_24109 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24106}), v_rest_244});
          V v_t_24110 = heff_tag_at_n(v_ru_24x311_24104_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24108}), v_t_24109});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24110;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SDecl: {
          heff_take_n(v_x3111_24105, 0ULL, 1);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          heff_drop_cell(v_ru_24x311_24104_24Cons, 2);
          V v_t_24112 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24106}), v_rest_244});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24112;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SSet: {
          V v_o_24114 = heff_field(v_x3111_24105, 1);
          heff_take_n(v_x3111_24105, 2ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_24115 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24106}), v_rest_244});
          V v_t_24116 = heff_tag_at_n(v_ru_24x311_24104_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24114}), v_t_24115});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24116;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SIf: {
          V v_c_24117 = heff_field(v_x3111_24105, 0);
          V v_ts_24118 = heff_field(v_x3111_24105, 1);
          V v_fs_24119 = heff_field(v_x3111_24105, 2);
          heff_take_n(v_x3111_24105, 7ULL, 3);
          V v_t_24120 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24106}), v_rest_244});
          V v_t_24121 = heff_tag_at_n(v_ru_24x311_24104_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_fs_24119}), v_t_24120});
          V v_t_24122 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_24118}), v_t_24121});
          V v_t_24123 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24117}), v_t_24122});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24123;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SCase: {
          V v_v_24124 = heff_field(v_x3111_24105, 0);
          V v_arms_24125 = heff_field(v_x3111_24105, 1);
          heff_take_n(v_x3111_24105, 3ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_24126 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24106}), v_rest_244});
          V v_t_24127 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24125));
          V v_t_24128 = (g_list_2efoldl_24s1104809983x118204267(v_t_24126, v_t_24127));
          V v_t_24129 = heff_tag_at_n(v_ru_24x311_24104_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24124}), v_t_24128});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24129;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x3111_24105);
        }
      }
      default: return heff_nomatch(v_x311_24104);
      }
    }
    case TAG_ITl: {
      V v_x311_24130 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ITl = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24130)) {
      case TAG_TSeq: {
        V v_ss_24131 = heff_field(v_x311_24130, 0);
        V v_t_24132 = heff_field(v_x311_24130, 1);
        V v_ru_24x311_24130_24TSeq = heff_take_reuse_n(v_x311_24130, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24133 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_24132}), v_rest_244});
        V v_t_24134 = heff_tag_at_n(v_ru_24x311_24130_24TSeq, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24131}), v_t_24133});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24134;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TReturn: {
        V v_o_24135 = heff_field(v_x311_24130, 0);
        heff_take_n(v_x311_24130, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24136 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24135}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24136;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TLoop: {
        V v_vs_24137 = heff_field(v_x311_24130, 0);
        heff_take_n(v_x311_24130, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24138 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_24137));
        V v_t_24139 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_24138));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24139;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TIf: {
        V v_c_24140 = heff_field(v_x311_24130, 0);
        V v_t_24141 = heff_field(v_x311_24130, 1);
        V v_e_24142 = heff_field(v_x311_24130, 2);
        heff_take_n(v_x311_24130, 7ULL, 3);
        V v_t_24143 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_e_24142}), v_rest_244});
        V v_t_24144 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ITl, 1, (V[]){v_t_24141}), v_t_24143});
        V v_t_24145 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24140}), v_t_24144});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24145;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TCase: {
        V v_v_24146 = heff_field(v_x311_24130, 0);
        V v_arms_24147 = heff_field(v_x311_24130, 1);
        heff_take_n(v_x311_24130, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24148 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24147));
        V v_t_24149 = (g_list_2efoldl_24s421921225x565177679(v_rest_244, v_t_24148));
        V v_t_24150 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24146}), v_t_24149});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24150;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_24130);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2eothersW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eothersW(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2etakeVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etakeVar_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2etakeVar(V v_ce_240, V v_rest_241, V v_x3_242, V v_l_243, V v_sh_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_rest_241);
    heff_drop(v_l_243);
    heff_drop(v_sh_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_sh_244)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_241);
      heff_drop(v_l_243);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_ru_24sh_244_24Cons = heff_take_reuse_n(v_sh_244, 0ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2erefcount_2eelemS(heff_dup(v_x_245), heff_rfield(v_ce_240, 4)));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_x1_249 = (g_heff_2ecompile_2erefcount_2eelemS(heff_dup(v_x_245), heff_rfield(v_ce_240, 6)));
        if ((heff_dup(v_x1_249) == NTAG(TAG_True))) {
          heff_drop_rec(v_ce_240, 16);
          heff_drop(v_rest_241);
          heff_drop(v_l_243);
          heff_drop_cell(v_ru_24sh_244_24Cons, 2);
          heff_drop(v_x1_249);
          return NTAG(TAG_Nil);
        } else {
          heff_drop(v_x1_249);
          V v_x1_2410 = ({ V a_0 = heff_dup(v_x_245); V b_1 = heff_get_n(v_ce_240, 5, 16); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
            heff_drop(v_rest_241);
            heff_drop(v_l_243);
            heff_drop_cell(v_ru_24sh_244_24Cons, 2);
            heff_drop(v_x1_2410);
            return NTAG(TAG_Nil);
          } else {
            heff_drop(v_x1_2410);
            V v_t_2411 = (g_heff_2ecompile_2erefcount_2eothersW(heff_dup(v_x_245), heff_dup(v_l_243), v_rest_241));
            if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
              heff_drop(v_t_2411);
              return heff_tag_at_n(v_ru_24sh_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_245), v_l_243}), NTAG(TAG_Nil)});
            } else {
              heff_drop(v_l_243);
              heff_drop_cell(v_ru_24sh_244_24Cons, 2);
              heff_drop(v_t_2411);
              return NTAG(TAG_Nil);
            }
          }
        }
      } else {
        heff_drop_rec(v_ce_240, 16);
        heff_drop(v_rest_241);
        heff_drop(v_l_243);
        heff_drop_cell(v_ru_24sh_244_24Cons, 2);
        heff_drop(v_t_248);
        return NTAG(TAG_Nil);
      }
    }
    default: return heff_nomatch(v_sh_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2etakeVar_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2etakeVar(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2eunboxParams_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eunboxParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eunboxParams_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2eunboxParams(V v_ce_240, V v_bi_241, V v_rps_242, V v_xs_243) {
top: ;
  V v_t_244 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_243), v_rps_242));
  V v_t_245 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
  V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
  V v_t_2417 = (g_list_2efoldl_24f1686830387x1555365313(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2erefcount_2eunboxParams_lam0, 2, 2, (V[]){heff_dup(v_bi_241), v_ce_240}), v_t_244, v_t_246));
  return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2417); r_; });
}
V g_heff_2ecompile_2erefcount_2eunboxParams_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eunboxParams(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2eunboxParams_lam0(V self, V *args) {
  V v_p_247 = args[0];
  V v_i_248 = args[1];
  V v_bi_241 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_lent_249 = ({ V a_0 = v_i_248; V a_1 = v_bi_241; V r_ = (g_heff_2ecompile_2erefcount_2eelemI(a_0, a_1)); heff_drop(v_bi_241); r_; });
  V v_t_2412;
  switch (heff_tag_of(v_p_247)) {
  case TAG_MkPair: {
    V v_y_2411 = heff_dup(heff_field(v_p_247, 1));
    v_t_2412 = v_y_2411;
    break;
  }
  default: heff_nomatch(v_p_247);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_RepV: {
    V v_t_2415;
    switch (heff_tag_of(v_p_247)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_p_247, 0);
      heff_take_n(v_p_247, 1ULL, 2);
      v_t_2415 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_p_247);
    }
    return ({ V a_0 = v_ce_240; V a_1 = v_lent_249; V a_2 = v_t_2415; V r_ = (g_heff_2ecompile_2erefcount_2eunboxParam(a_0, a_1, a_2)); heff_drop(v_lent_249); r_; });
  }
  case TAG_RepFix: {
    heff_take_n(v_t_2412, 0ULL, 1);
    heff_drop(v_p_247);
    heff_drop(v_ce_240);
    heff_drop(v_lent_249);
    return NTAG(TAG_Nil);
  }
  case TAG_RepF64: {
    heff_drop(v_p_247);
    heff_drop(v_ce_240);
    heff_drop(v_lent_249);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_2412);
  }
}
Clo g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928(V v_ce_240, V v_live_241, V v_e_242, V v_i_243, V v_n_244, V v_may_245) {
top: ;
  V v_t_2429;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SVar: {
    V v_x_246 = heff_dup(heff_field(v_e_242, 0));
    v_t_2429 = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
    break;
  }
  case TAG_SGlobal: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SInt: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SStr: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SBytes: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFixed: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat32: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrimFn: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SLam: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_STag: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SRec: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SProj: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrim: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_242);
  }
  V v_t_2453;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SVar: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SGlobal: {
    V v_g_2431 = heff_dup(heff_field(v_e_242, 0));
    v_t_2453 = heff_tag_n(TAG_Just, 1, (V[]){v_g_2431});
    break;
  }
  case TAG_SInt: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SStr: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SBytes: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFixed: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat32: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrimFn: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SLam: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_STag: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SRec: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SProj: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrim: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_242);
  }
  return (g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539(v_ce_240, v_live_241, v_e_242, v_i_243, v_n_244, v_may_245, v_t_2429, v_t_2453));
}
V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
Clo g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(V v_ce_240, V v_live_241, V v_e_242, V v_l_243, V v_t_244, V v_n_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    heff_drop(v_n_245);
    V v_t_247 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, NTAG(TAG_RepV), v_e_242));
    return heff_tag_n(TAG_RGetLabel, 2, (V[]){v_t_247, v_l_243});
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_x8_246, 0);
    V v_may_249 = (g_heff_2ecompile_2erepr_2emayBeFlat(v_t_244));
    V v_x8_2410 = (g_heff_2ecompile_2erefcount_2etakeIn(heff_rfield(v_ce_240, 9), v_live_241, heff_dup(v_e_242), v_l_243, heff_dup(v_i_248)));
    switch (heff_tag_of(v_x8_2410)) {
    case TAG_Nothing: {
      return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_e_242; V a_3 = heff_dup(v_i_248); V a_4 = v_n_245; V a_5 = v_may_249; V r_ = (g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_may_249); r_; });
    }
    case TAG_Just: {
      V v_t_2411 = heff_field(v_x8_2410, 0);
      heff_take_n(v_x8_2410, 1ULL, 1);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_live_241);
      heff_drop(v_e_242);
      heff_drop(v_n_245);
      heff_drop(v_may_249);
      return v_t_2411;
    }
    default: return heff_nomatch(v_x8_2410);
    }
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V r = g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(a[0], a[1], a[2], a[3], a4, a[5], a6); heff_drop(a4); heff_drop(a6); return r;
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_Cons: {
    V v_ru_243 = heff_field(v_x4_242, 0);
    V v_x42_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_244)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
    }
    case TAG_Cons: {
      V v_x421_245 = heff_field(v_x42_244, 0);
      V v_x422_246 = heff_field(v_x42_244, 1);
      switch (heff_tag_of(v_x421_245)) {
      case TAG_SVar: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SGlobal: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SInt: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SFloat: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SStr: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SBytes: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SFixed: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SFloat32: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SPrimFn: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SLam: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_STag: {
        V v_t_2419 = heff_field(v_x421_245, 0);
        V v_as_2420 = heff_field(v_x421_245, 1);
        V v_ts_2421 = heff_field(v_x421_245, 2);
        switch (heff_tag_of(v_x422_246)) {
        case TAG_Nil: {
          V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_as_2420)));
          V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_2422); r_; });
          V v_live_2424 = (g_prelude_2e_2b_2b(v_t_2423, heff_dup(v_live_241)));
          V v_t_2425 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2424, NTAG(TAG_RepV), heff_dup(v_ru_243)));
          V v_n_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2420));
          V v_t_2427 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2426, MK_INT(1LL))));
          V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam0, 1, 1, (V[]){heff_dup(v_ts_2421)}), v_t_2427));
          V v_t_2431 = (g_heff_2ecompile_2erefcount_2eslotBits(v_t_2430));
          V v_n_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2420));
          V v_t_2433 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2432, MK_INT(1LL))));
          V v_rps_2436 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam1, 1, 1, (V[]){heff_dup(v_ts_2421)}), v_t_2433));
          V v_t_2437 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_240, v_live_241, heff_dup(v_rps_2436), heff_dup(v_as_2420)));
          V v_t_2438 = (g_list_2ezipWith_24s870182194x1066240094(v_rps_2436, v_t_2437));
          return heff_tag_n(TAG_RTagIn, 4, (V[]){v_t_2425, heff_dup(v_t_2419), v_t_2431, v_t_2438});
        }
        case TAG_Cons: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        default: return heff_nomatch(v_x422_246);
        }
      }
      case TAG_SRec: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SProj: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SPrim: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      default: return heff_nomatch(v_x421_245);
      }
    }
    default: return heff_nomatch(v_x42_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam0(V self, V *args) {
  V v_i_2428 = args[0];
  V v_ts_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = ({ V a_0 = heff_dup(v_i_2428); V a_1 = v_ts_2421; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2421); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2428, v_t_2429));
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam1(V self, V *args) {
  V v_i_2434 = args[0];
  V v_ts_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = ({ V a_0 = heff_dup(v_i_2434); V a_1 = v_ts_2421; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2421); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2434, v_t_2435));
}
Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x4_242, 0);
    V v_es_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_244)));
    V v_t_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_245); r_; });
    V v_live_247 = (g_prelude_2e_2b_2b(v_t_246, heff_dup(v_live_241)));
    V v_t_248 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_247, NTAG(TAG_RepV), v_e_243));
    V v_cell_249 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(v_ce_240, v_live_241, v_es_244, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(V v_ce_240, V v_live_241, V v_x4_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_242, 0);
    V v_es_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_245)));
    V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_live_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_live_241)));
    V v_t_249 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_248, NTAG(TAG_RepV), v_e_244));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_ce_240;
    V t_1 = v_live_241;
    V t_2 = v_es_245;
    V t_3 = v_cell_2410;
    v_ce_240 = t_0;
    v_live_241 = t_1;
    v_x4_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SVar: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SVar = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_243), heff_rfield(v_ce_240, 10)));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      V v_t_245 = ({ V a_0 = heff_dup(v_x_243); V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop_rec(v_ce_240, 16);
        heff_drop(v_t_245);
        return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RDup, 1, (V[]){v_x_243});
      } else {
        heff_drop(v_t_245);
        V v_t_246 = ({ V a_0 = heff_dup(v_x_243); V b_1 = heff_get_n(v_ce_240, 6, 16); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RDup, 1, (V[]){v_x_243});
        } else {
          heff_drop(v_t_246);
          return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RLocal, 1, (V[]){v_x_243});
        }
      }
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_live_241);
      return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RLocal, 1, (V[]){v_x_243});
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_SGlobal: {
    V v_g_248 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SGlobal = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_live_241);
    V v_x3_249 = ({ V a_0 = heff_dup(v_g_248); V b_1 = heff_get_n(v_ce_240, 0, 16); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      return heff_tag_at_n(v_ru_24x4_242_24SGlobal, TAG_RGet, 1, (V[]){v_g_248});
    }
    case TAG_Just: {
      heff_take_n(v_x3_249, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x4_242_24SGlobal, TAG_RClo, 1, (V[]){v_g_248});
    }
    default: return heff_nomatch(v_x3_249);
    }
  }
  case TAG_SInt: {
    V v_n_2411 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SInt = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SInt, TAG_RInt, 1, (V[]){v_n_2411});
  }
  case TAG_SFloat: {
    double v_x_2412 = heff_tflat_f64(v_x4_242, 0);
    V v_ru_24x4_242_24SFloat = heff_take_reuse_na(v_x4_242, 0ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_nf(v_ru_24x4_242_24SFloat, TAG_RFloat, 1, 1u, (V[]){heff_word_f64(v_x_2412)});
  }
  case TAG_SStr: {
    V v_s_2413 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SStr = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SStr, TAG_RStr, 1, (V[]){v_s_2413});
  }
  case TAG_SBytes: {
    V v_s_2414 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SBytes = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SBytes, TAG_RBytes, 1, (V[]){v_s_2414});
  }
  case TAG_SFixed: {
    V v_w_2415 = heff_field(v_x4_242, 0);
    V v_n_2416 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SFixed = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SFixed, TAG_RFixed, 2, (V[]){v_w_2415, v_n_2416});
  }
  case TAG_SFloat32: {
    double v_x_2417 = heff_tflat_f64(v_x4_242, 0);
    V v_ru_24x4_242_24SFloat32 = heff_take_reuse_na(v_x4_242, 0ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_nf(v_ru_24x4_242_24SFloat32, TAG_RF32, 1, 1u, (V[]){heff_word_f64(v_x_2417)});
  }
  case TAG_SPrimFn: {
    V v_p_2418 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SPrimFn = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SPrimFn, TAG_RPrimFn, 1, (V[]){v_p_2418});
  }
  case TAG_SLam: {
    V v_xs_2419 = heff_field(v_x4_242, 0);
    V v_x42_2420 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x42_2420)) {
    case TAG_MkBlock: {
      V v_t_2421 = heff_field(v_x42_2420, 0);
      heff_take_n(v_x42_2420, 1ULL, 1);
      V v_t_2422 = (g_heff_2ecompile_2erefcount_2efreeOf(heff_dup(v_xs_2419), heff_dup(v_t_2421)));
      return (g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(v_ce_240, v_live_241, v_xs_2419, v_t_2421, v_t_2422));
    }
    default: return heff_nomatch(v_x42_2420);
    }
  }
  case TAG_STag: {
    V v_t_2423 = heff_field(v_x4_242, 0);
    V v_as_2424 = heff_field(v_x4_242, 1);
    V v_ts_2425 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    switch (heff_tag_of(v_as_2424)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_live_241);
      heff_drop(v_ts_2425);
      return heff_tag_n(TAG_RNTag, 1, (V[]){v_t_2423});
    }
    case TAG_Cons: {
      return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_t_2423; V a_3 = v_as_2424; V a_4 = v_ts_2425; V r_ = (g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ts_2425); r_; });
    }
    default: return heff_nomatch(v_as_2424);
    }
  }
  case TAG_SRec: {
    V v_fs_2428 = heff_field(v_x4_242, 0);
    V v_ts_2429 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_t_2430 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2428)));
    V v_t_2431 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_live_241; V a_2 = v_t_2430; V a_3 = heff_dup(v_fs_2428); V r_ = (g_heff_2ecompile_2erefcount_2eupdatedIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2430); r_; });
    return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_fs_2428; V a_3 = v_ts_2429; V a_4 = v_t_2431; V r_ = (g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ts_2429); heff_drop(v_t_2431); r_; });
  }
  case TAG_SProj: {
    V v_e_2432 = heff_field(v_x4_242, 0);
    V v_l_2433 = heff_field(v_x4_242, 1);
    V v_sh_2434 = heff_field(v_x4_242, 2);
    V v_t_2435 = heff_field(v_x4_242, 3);
    heff_take_n(v_x4_242, 15ULL, 4);
    V v_t_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2434));
    V v_t_2437 = ({ V a_0 = heff_dup(v_l_2433); V a_1 = MK_INT(0LL); V a_2 = v_sh_2434; V r_ = (g_heff_2ecompile_2erefcount_2eindexIn(a_0, a_1, a_2)); heff_drop(v_sh_2434); r_; });
    return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_e_2432; V a_3 = v_l_2433; V a_4 = v_t_2435; V a_5 = v_t_2436; V a_6 = v_t_2437; V r_ = (g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2435); heff_drop(v_t_2437); r_; });
  }
  case TAG_SPrim: {
    V v_p_2438 = heff_field(v_x4_242, 0);
    V v_as_2439 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SPrim = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_p_2438), heff_dup(g_heff_2ecompile_2erefcount_2ereusePrim_get()))) {
      heff_drop(v_p_2438);
      heff_drop_cell(v_ru_24x4_242_24SPrim, 2);
      return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_as_2439; V r_ = (g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(a_0, a_1, a_2)); heff_drop(v_as_2439); r_; });
    } else {
      V v_t_2441 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_as_2439));
      return heff_tag_at_n(v_ru_24x4_242_24SPrim, TAG_RPrim, 2, (V[]){v_p_2438, v_t_2441});
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330(V v_ce_240, V v_lent_241, V v_live_242, V v_bi_243, V v_i_244, V v_e_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    V v_t_247 = (g_heff_2ecompile_2erefcount_2eelemI(v_i_244, v_bi_243));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_242, NTAG(TAG_RepV), v_e_245));
      return heff_tag_n(TAG_LentValue, 1, (V[]){v_t_248});
    } else {
      heff_drop(v_t_247);
      V v_t_249 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_242, NTAG(TAG_RepV), v_e_245));
      return heff_tag_n(TAG_Given, 1, (V[]){v_t_249});
    }
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_x8_246, 0);
    V v_ru_24x8_246_24Just = heff_take_reuse_n(v_x8_246, 1ULL, 1);
    V v_t_2411 = (g_heff_2ecompile_2erefcount_2eelemI(v_i_244, v_bi_243));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_live_242);
      heff_drop(v_e_245);
      heff_drop(v_t_2411);
      V v_t_2412 = (g_heff_2ecompile_2erefcount_2eelemS(heff_dup(v_x_2410), v_lent_241));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop_rec(v_ce_240, 16);
        heff_drop(v_t_2412);
        return heff_tag_at_n(v_ru_24x8_246_24Just, TAG_Given, 1, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_x_2410})});
      } else {
        heff_drop(v_t_2412);
        V v_t_2413 = (g_heff_2ecompile_2erefcount_2eelemS(heff_dup(v_x_2410), heff_rfield(v_ce_240, 6)));
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop_rec(v_ce_240, 16);
          heff_drop(v_t_2413);
          return heff_tag_at_n(v_ru_24x8_246_24Just, TAG_Given, 1, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_x_2410})});
        } else {
          heff_drop_cell(v_ru_24x8_246_24Just, 1);
          heff_drop(v_t_2413);
          V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2410), NTAG(TAG_Nil)});
          V v_t_2415 = (g_heff_2ecompile_2erefcount_2edropsOf(v_ce_240, v_t_2414));
          return heff_tag_n(TAG_LentVar, 2, (V[]){v_x_2410, v_t_2415});
        }
      }
    } else {
      heff_drop(v_x_2410);
      heff_drop(v_t_2411);
      V v_t_2416 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_242, NTAG(TAG_RepV), v_e_245));
      return heff_tag_at_n(v_ru_24x8_246_24Just, TAG_Given, 1, (V[]){v_t_2416});
    }
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330(a[0], a1, a[2], a3, a[4], a[5], a[6]); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769(V v_ce_240, V v_c_241, V v_yes_242, V v_no_243, V v_wanted_244) {
top: ;
  V v_xs_247 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam0, 1, 1, (V[]){heff_dup(v_wanted_244)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_248 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_247));
  V v_t_249 = (g_list_2emap_24s1796125103x644876049(v_t_248));
  V v_t_2411 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam1, 1, 1, (V[]){heff_dup(v_wanted_244)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_ce_2412 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2411, heff_dup(v_wanted_244), heff_dup(v_ce_240)));
  V v_t_2413 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_2412, 4)), heff_dup(heff_rfield(v_ce_2412, 6))));
  V v_t_2414 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2413, v_ce_2412));
  V v_t_2415 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2414));
  V v_t_2416 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_2415, v_c_241));
  V v_t_2418 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam2, 1, 1, (V[]){heff_dup(v_wanted_244)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2419 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2418, heff_dup(heff_rfield(v_ce_240, 5)), heff_dup(v_ce_240)));
  V v_t_2420 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2419, v_yes_242));
  V v_t_2422 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam3, 1, 1, (V[]){v_wanted_244}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2423 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2422, heff_dup(heff_rfield(v_ce_240, 5)), v_ce_240));
  V v_t_2424 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2423, v_no_243));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_t_2416, v_t_2420, v_t_2424}), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_t_249, v_t_2425));
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769(a[0], a[1], a2, a3, a[4]); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam0(V self, V *args) {
  V v_v_245 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_246 = ({ V a_0 = v_v_245; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wanted_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_246) == NTAG(TAG_True)));
  heff_drop(v_x1_246);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam1(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2410; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam2(V self, V *args) {
  V v_v_2417 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2417; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam3(V self, V *args) {
  V v_v_2421 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2421; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(V v_ce_240, V v_p_241, V v_args_242, V v_yes_243, V v_no_244, V v_fa_245, V v_wb_246) {
top: ;
  V v_wanted_247 = (g_prelude_2e_2b_2b(heff_dup(v_fa_245), heff_dup(v_wb_246)));
  V v_xs_2410 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam0, 1, 1, (V[]){v_wanted_247}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2411 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2410));
  V v_t_2412 = (g_list_2emap_24s1796125103x644876049(v_t_2411));
  V v_wanted_2413 = (g_prelude_2e_2b_2b(v_fa_245, heff_dup(v_wb_246)));
  V v_t_2415 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam1, 1, 1, (V[]){v_wanted_2413}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2416 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2415, heff_dup(v_wb_246), heff_dup(v_ce_240)));
  V v_t_2417 = (g_heff_2ecompile_2erefcount_2erelTest_24s1551809647x1570729674(v_t_2416, heff_dup(v_wb_246), v_p_241, v_args_242));
  V v_t_2419 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam2, 1, 1, (V[]){heff_dup(v_wb_246)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2420 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2419, heff_dup(heff_rfield(v_ce_240, 5)), heff_dup(v_ce_240)));
  V v_t_2421 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2420, v_yes_243));
  V v_t_2423 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam3, 1, 1, (V[]){v_wb_246}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2424 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2423, heff_dup(heff_rfield(v_ce_240, 5)), v_ce_240));
  V v_t_2425 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2424, v_no_244));
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_t_2417, v_t_2421, v_t_2425}), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_t_2412, v_t_2426));
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(a[0], a[1], a[2], a3, a4, a[5], a[6]); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam0(V self, V *args) {
  V v_v_248 = args[0];
  V v_wanted_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = ({ V a_0 = v_v_248; V a_1 = v_wanted_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wanted_247); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
  heff_drop(v_x1_249);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam1(V self, V *args) {
  V v_v_2414 = args[0];
  V v_wanted_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2414; V a_1 = v_wanted_2413; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wanted_2413); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam2(V self, V *args) {
  V v_v_2418 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2418; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wb_246); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam3(V self, V *args) {
  V v_v_2422 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2422; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wb_246); r_; });
}
Clo g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(V v_ce_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    V v_x_242 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SVar = heff_take_reuse_n(v_v_241, 1ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    return heff_tag_at_n(v_ru_24v_241_24SVar, TAG_RLocal, 1, (V[]){v_x_242});
  }
  case TAG_SGlobal: {
    V v_g_243 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SGlobal = heff_take_reuse_n(v_v_241, 1ULL, 1);
    V v_x3_244 = ({ V a_0 = heff_dup(v_g_243); V b_1 = heff_get_n(v_ce_240, 0, 16); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_RGetRaw, 1, (V[]){v_g_243});
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_RClo, 1, (V[]){v_g_243});
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_SInt: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFloat: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SStr: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SBytes: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFixed: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFloat32: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SPrimFn: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SLam: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_STag: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SRec: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SProj: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SPrim: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(a[0], a[1]);
}