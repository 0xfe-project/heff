// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_F32 16337
#define TAG_Given 9359
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_KnownCell 38933
#define TAG_KnownClo 18392
#define TAG_KnownRec 32578
#define TAG_KnownTag 34380
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkCArm 24694
#define TAG_MkDrop 35958
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define TAG_TakeKeep 54413
#define TAG_TakeN 37047
#define TAG_TakeNone 22612
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_after 294093302
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_counted 1189688364
#define LBL_flat 9641024
#define LBL_flats 298871860
#define LBL_funs 9650075
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_names 305943394
#define LBL_owned 307523263
#define LBL_plain 308106724
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tags 10047712
#define LBL_takes 311482598
static uint32_t shape_at__tags[] = {LBL_at, LBL_tags};
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_sureRecs, LBL_ret};
static uint32_t shape_plain__flats__names__counted__flat__sure[] = {LBL_plain, LBL_flats, LBL_names, LBL_counted, LBL_flat, LBL_sure};
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(V, V);
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_clo;
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(V, V);
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_clo;
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_clo;
V g_heff_2ecompile_2erefcount_2edropOf(V, V);
V g_heff_2ecompile_2erefcount_2edropOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropOf_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2eelementRepr(V, V);
V g_heff_2ecompile_2erefcount_2eelementRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelementRepr_clo;
V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_clo;
V g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539_clo;
V g_heff_2ecompile_2erefcount_2efieldMask(V, V, V);
V g_heff_2ecompile_2erefcount_2efieldMask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldMask_clo;
V g_heff_2ecompile_2erefcount_2eflatOnes(V, V, V);
V g_heff_2ecompile_2erefcount_2eflatOnes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eflatOnes_clo;
V g_heff_2ecompile_2erefcount_2eflatnessOf(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eflatnessOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eflatnessOf_clo;
V g_heff_2ecompile_2erefcount_2efreeOf(V, V);
V g_heff_2ecompile_2erefcount_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeOf_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2egoneOne(V, V, V);
V g_heff_2ecompile_2erefcount_2egoneOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2egoneOne_clo;
V g_heff_2ecompile_2erefcount_2egoneTo(V, V);
V g_heff_2ecompile_2erefcount_2egoneTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2egoneTo_clo;
V g_heff_2ecompile_2erefcount_2eindexIn(V, V, V);
V g_heff_2ecompile_2erefcount_2eindexIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eindexIn_clo;
HeffT2 g_heff_2ecompile_2erefcount_2eindexIn_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2eintPrims_get(void);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_clo;
V g_heff_2ecompile_2erefcount_2eothersW(V, V, V);
V g_heff_2ecompile_2erefcount_2eothersW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eothersW_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs(V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_clo;
V g_heff_2ecompile_2erefcount_2epeekOf(V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekOf_clo;
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_clo;
V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_clo;
V g_heff_2ecompile_2erefcount_2ereadsWith(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ereadsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereadsWith_clo;
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_clo;
V g_heff_2ecompile_2erefcount_2ereuseArgs(V, V);
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseV_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseV_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_clo;
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(V, V);
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_clo;
V g_heff_2ecompile_2erefcount_2eslotBits(V);
V g_heff_2ecompile_2erefcount_2eslotBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eslotBits_clo;
V g_heff_2ecompile_2erefcount_2estrAs(V, V);
V g_heff_2ecompile_2erefcount_2estrAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estrAs_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etagGiven_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etakeIn_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeOf(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeOf_clo;
V g_heff_2ecompile_2erefcount_2etakeVar(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeVar_clo;
V g_heff_2ecompile_2erefcount_2ethreadSts(V, V);
V g_heff_2ecompile_2erefcount_2ethreadSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ethreadSts_clo;
V g_heff_2ecompile_2erefcount_2ethreaded(V, V);
V g_heff_2ecompile_2erefcount_2ethreaded_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ethreaded_clo;
V g_heff_2ecompile_2erefcount_2ethreadedArms(V, V);
V g_heff_2ecompile_2erefcount_2ethreadedArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ethreadedArms_clo;
V g_heff_2ecompile_2erefcount_2eunboxParam(V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxParam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxParam_clo;
V g_heff_2ecompile_2erefcount_2eunboxParams(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxParams_clo;
V g_heff_2ecompile_2erefcount_2eupdatedIn(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eupdatedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eupdatedIn_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(V, V, V);
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_list_2eany_24s1435885690x1984517496(V, V);
V g_list_2eany_24s1435885690x1984517496_entry(V self, V *a);
extern Clo g_list_2eany_24s1435885690x1984517496_clo;
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1791954930x928584331(V);
V g_list_2efilter_24s1791954930x928584331_entry(V self, V *a);
extern Clo g_list_2efilter_24s1791954930x928584331_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f1686830387x1555365313(V, V, V, V);
V g_list_2efoldl_24f1686830387x1555365313_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1686830387x1555365313_clo;
V g_list_2efoldl_24f613246640x472569916(V, V, V, V);
V g_list_2efoldl_24f613246640x472569916_entry(V self, V *a);
extern Clo g_list_2efoldl_24f613246640x472569916_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1879887278x1868824044(V, V);
V g_list_2efoldl_24s1879887278x1868824044_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1879887278x1868824044_clo;
V g_list_2efoldl_24s2092021924x904081891(V, V);
V g_list_2efoldl_24s2092021924x904081891_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2092021924x904081891_clo;
V g_list_2efoldl_24s421921225x565177679(V, V);
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a);
extern Clo g_list_2efoldl_24s421921225x565177679_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s826961155x1314392429(V, V);
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s826961155x1314392429_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1512396752x1753792987(V, V, V);
V g_list_2emap_24s1512396752x1753792987_entry(V self, V *a);
extern Clo g_list_2emap_24s1512396752x1753792987_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s870182194x1066240094(V, V);
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithBorrowed_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ewithBorrowed(V v_bs_240, V v_ce_241) {
top: ;
  return ({ V rv_6 = v_bs_240; V rr_ = heff_rec_reuse_nf(v_ce_241, 65471ULL, 16, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__ret, 4294955007u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithBorrowed(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V v_bs_240, V v_ms_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return ((HeffT2){{v_bs_240, v_ms_241}});
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_IVal: {
      V v_x311_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_245)) {
      case TAG_SVar: {
        V v_x_246 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 1);
        V t_0 = v_bs_240;
        V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_ms_241});
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SInt: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat: {
        heff_take_na(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SStr: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SBytes: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFixed: {
        heff_take_n(v_x311_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SLam: {
        V v_xs_2416 = heff_field(v_x311_245, 0);
        V v_x3112_2417 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 3ULL, 2);
        switch (heff_tag_of(v_x3112_2417)) {
        case TAG_MkBlock: {
          V v_t_2418 = heff_field(v_x3112_2417, 0);
          heff_take_n(v_x3112_2417, 1ULL, 1);
          V v_t_2419 = (g_prelude_2e_2b_2b(v_xs_2416, v_bs_240));
          V v_t_2420 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_2418}), v_rest_244});
          V t_0 = v_t_2419;
          V t_1 = v_ms_241;
          V t_2 = v_t_2420;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_x3112_2417)}});
        }
      }
      case TAG_STag: {
        V v_as_2422 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2422));
        V v_t_2425 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2424));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2425;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SRec: {
        V v_fs_2426 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2428 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2426));
        V v_t_2429 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2428));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2429;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SProj: {
        V v_v_2430 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 4);
        V v_t_2434 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2430}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2434;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrim: {
        V v_as_2436 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2436));
        V v_t_2438 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2437));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2438;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x311_245)}});
      }
    }
    case TAG_IOp: {
      V v_x311_2439 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2439)) {
      case TAG_OSimple: {
        V v_v_2440 = heff_field(v_x311_2439, 0);
        heff_take_n(v_x311_2439, 1ULL, 1);
        V v_t_2441 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2440}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2441;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OCall: {
        V v_as_2443 = heff_field(v_x311_2439, 1);
        heff_take_n(v_x311_2439, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2443));
        V v_t_2445 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2444));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2445;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OApply: {
        V v_f_2446 = heff_field(v_x311_2439, 0);
        V v_as_2447 = heff_field(v_x311_2439, 1);
        heff_take_n(v_x311_2439, 3ULL, 2);
        V v_t_2448 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2446, v_as_2447})));
        V v_t_2449 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2448));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2449;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OPrim: {
        V v_as_2451 = heff_field(v_x311_2439, 1);
        heff_take_n(v_x311_2439, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2452 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2451));
        V v_t_2453 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2452));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2453;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OBool: {
        V v_c_2454 = heff_field(v_x311_2439, 0);
        heff_take_n(v_x311_2439, 1ULL, 1);
        V v_t_2455 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2454}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2455;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x311_2439)}});
      }
    }
    case TAG_ICond: {
      V v_x311_2456 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ICond = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2456)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PRel: {
        V v_a_2458 = heff_field(v_x311_2456, 1);
        V v_b_2459 = heff_field(v_x311_2456, 2);
        heff_take_n(v_x311_2456, 6ULL, 3);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2460 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_b_2459}), v_rest_244});
        V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_a_2458}), v_t_2460});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2461;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PBool: {
        V v_v_2462 = heff_field(v_x311_2456, 0);
        heff_take_n(v_x311_2456, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2463 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2462}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2463;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PNot: {
        V v_c_2464 = heff_field(v_x311_2456, 0);
        heff_take_n(v_x311_2456, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2465 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2464}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2465;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PIf: {
        V v_a_2466 = heff_field(v_x311_2456, 0);
        V v_b_2467 = heff_field(v_x311_2456, 1);
        V v_c_2468 = heff_field(v_x311_2456, 2);
        heff_take_n(v_x311_2456, 7ULL, 3);
        V v_t_2469 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2468}), v_rest_244});
        V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_b_2467}), v_t_2469});
        V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_2466}), v_t_2470});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2471;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PLet: {
        V v_x_2472 = heff_field(v_x311_2456, 0);
        V v_o_2473 = heff_field(v_x311_2456, 1);
        V v_c_2474 = heff_field(v_x311_2456, 2);
        heff_take_n(v_x311_2456, 7ULL, 3);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2475 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2474}), v_rest_244});
        V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2473}), v_t_2475});
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2472, v_bs_240});
        V t_1 = v_ms_241;
        V t_2 = v_t_2476;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x311_2456)}});
      }
    }
    case TAG_ISts: {
      V v_x311_2477 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ISts = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2477)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ISts, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_Cons: {
        V v_x3111_2478 = heff_field(v_x311_2477, 0);
        V v_ss_2479 = heff_field(v_x311_2477, 1);
        V v_ru_24x311_2477_24Cons = heff_take_reuse_n(v_x311_2477, 3ULL, 2);
        switch (heff_tag_of(v_x3111_2478)) {
        case TAG_SLet: {
          V v_x_2480 = heff_field(v_x3111_2478, 0);
          V v_o_2481 = heff_field(v_x3111_2478, 1);
          V v_ru_24x3111_2478_24SLet = heff_take_reuse_n(v_x3111_2478, 3ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_2482 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2479}), v_rest_244});
          V v_t_2483 = heff_tag_at_n(v_ru_24x311_2477_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2481}), v_t_2482});
          V t_0 = heff_tag_at_n(v_ru_24x3111_2478_24SLet, TAG_Cons, 2, (V[]){v_x_2480, v_bs_240});
          V t_1 = v_ms_241;
          V t_2 = v_t_2483;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SDecl: {
          V v_x_2484 = heff_field(v_x3111_2478, 0);
          heff_take_n(v_x3111_2478, 1ULL, 1);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_2485 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2479}), v_rest_244});
          V t_0 = heff_tag_at_n(v_ru_24x311_2477_24Cons, TAG_Cons, 2, (V[]){v_x_2484, v_bs_240});
          V t_1 = v_ms_241;
          V t_2 = v_t_2485;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SSet: {
          V v_o_2487 = heff_field(v_x3111_2478, 1);
          heff_take_n(v_x3111_2478, 2ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_2488 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2479}), v_rest_244});
          V v_t_2489 = heff_tag_at_n(v_ru_24x311_2477_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2487}), v_t_2488});
          V t_0 = v_bs_240;
          V t_1 = v_ms_241;
          V t_2 = v_t_2489;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SIf: {
          V v_c_2490 = heff_field(v_x3111_2478, 0);
          V v_ts_2491 = heff_field(v_x3111_2478, 1);
          V v_fs_2492 = heff_field(v_x3111_2478, 2);
          heff_take_n(v_x3111_2478, 7ULL, 3);
          V v_t_2493 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2479}), v_rest_244});
          V v_t_2494 = heff_tag_at_n(v_ru_24x311_2477_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_fs_2492}), v_t_2493});
          V v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_2491}), v_t_2494});
          V v_t_2496 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2490}), v_t_2495});
          V t_0 = v_bs_240;
          V t_1 = v_ms_241;
          V t_2 = v_t_2496;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SCase: {
          V v_v_2497 = heff_field(v_x3111_2478, 0);
          V v_arms_2498 = heff_field(v_x3111_2478, 1);
          heff_take_n(v_x3111_2478, 3ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_2499 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2498)));
          V v_t_24100 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2499; V r_ = (g_list_2efoldl_24s1530401830x609500251(a_0, a_1)); heff_drop(v_t_2499); r_; });
          V v_t_24101 = (g_prelude_2e_2b_2b(v_t_24100, v_bs_240));
          V v_t_24102 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2479}), v_rest_244});
          V v_t_24103 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2498));
          V v_t_24104 = (g_list_2efoldl_24s1104809983x118204267(v_t_24102, v_t_24103));
          V v_t_24105 = heff_tag_at_n(v_ru_24x311_2477_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2497}), v_t_24104});
          V t_0 = v_t_24101;
          V t_1 = v_ms_241;
          V t_2 = v_t_24105;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_x3111_2478)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x311_2477)}});
      }
    }
    case TAG_ITl: {
      V v_x311_24106 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ITl = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24106)) {
      case TAG_TSeq: {
        V v_ss_24107 = heff_field(v_x311_24106, 0);
        V v_t_24108 = heff_field(v_x311_24106, 1);
        V v_ru_24x311_24106_24TSeq = heff_take_reuse_n(v_x311_24106, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24109 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_24108}), v_rest_244});
        V v_t_24110 = heff_tag_at_n(v_ru_24x311_24106_24TSeq, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24107}), v_t_24109});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_24110;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TReturn: {
        V v_o_24111 = heff_field(v_x311_24106, 0);
        heff_take_n(v_x311_24106, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24112 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24111}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_24112;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TLoop: {
        V v_vs_24113 = heff_field(v_x311_24106, 0);
        heff_take_n(v_x311_24106, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24114 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_24113));
        V v_t_24115 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_24114));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_24115;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TIf: {
        V v_c_24116 = heff_field(v_x311_24106, 0);
        V v_t_24117 = heff_field(v_x311_24106, 1);
        V v_e_24118 = heff_field(v_x311_24106, 2);
        heff_take_n(v_x311_24106, 7ULL, 3);
        V v_t_24119 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_e_24118}), v_rest_244});
        V v_t_24120 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ITl, 1, (V[]){v_t_24117}), v_t_24119});
        V v_t_24121 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24116}), v_t_24120});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_24121;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TCase: {
        V v_v_24122 = heff_field(v_x311_24106, 0);
        V v_arms_24123 = heff_field(v_x311_24106, 1);
        heff_take_n(v_x311_24106, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24124 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_24123)));
        V v_t_24125 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24124; V r_ = (g_list_2efoldl_24s1530401830x609500251(a_0, a_1)); heff_drop(v_t_24124); r_; });
        V v_t_24126 = (g_prelude_2e_2b_2b(v_t_24125, v_bs_240));
        V v_t_24127 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24123));
        V v_t_24128 = (g_list_2efoldl_24s421921225x565177679(v_rest_244, v_t_24127));
        V v_t_24129 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24122}), v_t_24128});
        V t_0 = v_t_24126;
        V t_1 = v_ms_241;
        V t_2 = v_t_24129;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x311_24106)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2edropOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2edropOf_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2edropOf(V v_x_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_k_241)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_x11_242 = heff_dup(heff_field(v_k_241, 0));
    switch (heff_tag_of(v_x11_242)) {
    case TAG_KnownTag: {
      V v_n_243 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_intLt_c(MK_INT(0LL), v_n_243)) {
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_x_240);
        heff_drop_tag(v_k_241, 1);
        return NTAG(TAG_Nil);
      }
    }
    case TAG_KnownCell: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
    }
    case TAG_KnownRec: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
    }
    case TAG_KnownClo: {
      V v_n_247 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_intLt_c(MK_INT(0LL), v_n_247)) {
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_x_240);
        heff_drop_tag(v_k_241, 1);
        return NTAG(TAG_Nil);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_k_241);
  }
}
V g_heff_2ecompile_2erefcount_2edropOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2edropOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2elentThen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentThen_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2elentThen(V v_ce_240, V v_bi_241, V v_i_242, V v_e_243, V v_before_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2erefcount_2eelemI(v_i_242, v_bi_241));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    switch (heff_tag_of(v_e_243)) {
    case TAG_SVar: {
      V v_x_246 = heff_field(v_e_243, 0);
      HeffT2 v_t_247 = ({ V b_0 = heff_get_n(v_ce_240, 10, 16); V a_1 = v_x_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_249;
          heff_drop(v_x_2411);
          return v_before_244;
        } else {
          heff_drop(v_field_249);
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_246), v_before_244});
        }
      }
    }
    case TAG_SGlobal: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SInt: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SFloat: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SStr: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SBytes: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SFixed: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SFloat32: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SPrimFn: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SLam: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_STag: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SRec: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SProj: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    case TAG_SPrim: {
      heff_drop_rec(v_ce_240, 16);
      return v_before_244;
    }
    default: return heff_nomatch(v_e_243);
    }
  } else {
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_t_245);
    return v_before_244;
  }
}
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2elentThen(a[0], a1, a[2], a3, a[4]); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2eelementRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eelementRepr_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eelementRepr(V v_ce_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    V v_x_242 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_ce_240, 10, 16); V a_1 = v_x_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_242); r_; });
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        return v_x_247;
      } else {
        heff_drop(v_field_245);
        return NTAG(TAG_RepV);
      }
    }
  }
  case TAG_SGlobal: {
    heff_take_n(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_RepV);
  }
  case TAG_SInt: {
    heff_take_n(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_RepV);
  }
  case TAG_SFloat: {
    heff_take_na(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_RepF64);
  }
  case TAG_SStr: {
    heff_take_n(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_RepV);
  }
  case TAG_SBytes: {
    heff_take_n(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_RepV);
  }
  case TAG_SFixed: {
    V v_w_2413 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 2);
    heff_drop_rec(v_ce_240, 16);
    return heff_tag_n(TAG_RepFix, 1, (V[]){v_w_2413});
  }
  case TAG_SFloat32: {
    V v_ru_24v_241_24SFloat32 = heff_take_reuse_na(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    return heff_tag_at_n(v_ru_24v_241_24SFloat32, TAG_RepFix, 1, (V[]){NTAG(TAG_F32)});
  }
  case TAG_SPrimFn: {
    heff_take_n(v_v_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_RepV);
  }
  case TAG_SLam: {
    heff_take_n(v_v_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_RepV);
  }
  case TAG_STag: {
    heff_take_n(v_v_241, 0ULL, 3);
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_RepV);
  }
  case TAG_SRec: {
    heff_take_n(v_v_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_RepV);
  }
  case TAG_SProj: {
    heff_take_n(v_v_241, 0ULL, 4);
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_RepV);
  }
  case TAG_SPrim: {
    V v_p_2428 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 2);
    heff_drop_rec(v_ce_240, 16);
    HeffT2 v_t_2430 = ({ V a_0 = v_p_2428; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(a_0)); heff_drop(v_p_2428); r_; });
    {
      V v_field_2432 = v_t_2430.f[1];
      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
      if ((v_tag_2431 == ((int64_t)0ULL))) {
        V v_s_2434 = v_field_2432;
        return heff_get_n(v_s_2434, 1, 2);
      } else {
        heff_drop(v_field_2432);
        return NTAG(TAG_RepV);
      }
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erefcount_2eelementRepr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eelementRepr(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2estrAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2estrAs_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2estrAs(V v_x1_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RepV: {
    return heff_tag_n(TAG_RStr, 1, (V[]){v_s_241});
  }
  case TAG_RepFix: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RepFix = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    heff_drop(v_s_241);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_I8: {
      heff_drop_cell(v_ru_24x1_240_24RepFix, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_242, MK_INT(0LL)});
    }
    case TAG_I16: {
      heff_drop_cell(v_ru_24x1_240_24RepFix, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_242, MK_INT(0LL)});
    }
    case TAG_I32: {
      heff_drop_cell(v_ru_24x1_240_24RepFix, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_242, MK_INT(0LL)});
    }
    case TAG_I64: {
      heff_drop_cell(v_ru_24x1_240_24RepFix, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_242, MK_INT(0LL)});
    }
    case TAG_U8: {
      heff_drop_cell(v_ru_24x1_240_24RepFix, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_242, MK_INT(0LL)});
    }
    case TAG_U16: {
      heff_drop_cell(v_ru_24x1_240_24RepFix, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_242, MK_INT(0LL)});
    }
    case TAG_U32: {
      heff_drop_cell(v_ru_24x1_240_24RepFix, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_242, MK_INT(0LL)});
    }
    case TAG_U64: {
      heff_drop_cell(v_ru_24x1_240_24RepFix, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_242, MK_INT(0LL)});
    }
    case TAG_F32: {
      return heff_tag_at_nf(v_ru_24x1_240_24RepFix, TAG_RF32U, 1, 1u, (V[]){heff_word_f64((0.0))});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_RepF64: {
    heff_drop(v_s_241);
    return heff_tag_nf(TAG_RF64U, 1, 1u, (V[]){heff_word_f64((0.0))});
  }
  case TAG_RepInt: {
    heff_drop(v_s_241);
    return heff_tag_n(TAG_RFixU, 2, (V[]){NTAG(TAG_I64), MK_INT(0LL)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2estrAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2estrAs(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2ereadsWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ereadsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereadsWith_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ereadsWith(V v_ce_240, V v_su_241, V v_ws_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_ce_240);
    heff_drop(v_su_241);
    return heff_rec_n(6, shape_plain__flats__names__counted__flat__sure, (V[]){v_ws_242, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_ps_244 = heff_field(v_x4_243, 0);
    V v_fs_245 = (g_heff_2ecompile_2erefcount_2eflatOnes(v_ce_240, v_ps_244, heff_dup(v_ws_242)));
    V v_t_248 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2ereadsWith_lam0, 1, 1, (V[]){heff_dup(v_fs_245)}), v_ws_242));
    V v_t_249 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_245)));
    V v_t_2410 = (g_list_2efilter_24s1791954930x928584331(heff_dup(v_fs_245)));
    V v_t_2411 = (g_list_2emap_24s1937570095x2110149801(v_t_2410));
    return heff_rec_n(6, shape_plain__flats__names__counted__flat__sure, (V[]){v_t_248, v_fs_245, v_t_249, v_t_2411, NTAG(TAG_True), v_su_241});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erefcount_2ereadsWith_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2ereadsWith(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erefcount_2ereadsWith_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_fs_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_247 = ({ V a_0 = v_p_246; V a_1 = v_fs_245; V r_ = (g_list_2eany_24s1435885690x1984517496(a_0, a_1)); heff_drop(v_p_246); heff_drop(v_fs_245); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
  heff_drop(v_x1_247);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2erefcount_2etakeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etakeOf_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2etakeOf(V v_fl_240, V v_su_241, V v_x3_242, V v_taken_243, V v_vs_244, V v_used_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_taken_243)) {
    case TAG_Nothing: {
      return NTAG(TAG_TakeNone);
    }
    case TAG_Just: {
      V v_t_247 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_245, MK_INT(0LL), v_vs_244));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
      V v_t_249 = (g_heff_2ecompile_2erefcount_2eflatnessOf(v_fl_240, v_su_241, v_t_247, v_t_248));
      V v_t_2410 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_245, MK_INT(0LL), v_vs_244));
      V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
      return heff_tag_n(TAG_TakeN, 3, (V[]){v_t_249, v_t_2410, v_t_2411});
    }
    default: return heff_nomatch(v_taken_243);
    }
  }
  case TAG_Just: {
    V v_ru_2412 = heff_field(v_x3_242, 0);
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_245, MK_INT(0LL), v_vs_244));
    V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
    V v_t_2415 = (g_heff_2ecompile_2erefcount_2eflatnessOf(v_fl_240, v_su_241, v_t_2413, v_t_2414));
    V v_t_2416 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_245, MK_INT(0LL), v_vs_244));
    V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
    return heff_tag_n(TAG_TakeKeep, 4, (V[]){v_t_2415, heff_dup(v_ru_2412), v_t_2416, v_t_2417});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2etakeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2ecompile_2erefcount_2etakeOf(a0, a1, a2, a3, a4, a5); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2ecompile_2erefcount_2ereuseArgs_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereuseArgs_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ereuseArgs(V v_go_240, V v_vs_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), NTAG(TAG_Nil)});
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseArgs_lam0, 2, 1, (V[]){v_go_240}), v_t_242, v_vs_241));
}
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2ereuseArgs(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2ereuseArgs_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_v_244 = args[1];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_acc_243)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_acc_243, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_acc_243);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_go_240);
    heff_drop(v_t_247);
    V v_t_2410;
    switch (heff_tag_of(v_acc_243)) {
    case TAG_MkPair: {
      V v_y_249 = heff_field(v_acc_243, 1);
      heff_take_n(v_acc_243, 2ULL, 2);
      v_t_2410 = v_y_249;
      break;
    }
    default: heff_nomatch(v_acc_243);
    }
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_244, NTAG(TAG_Nil)});
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2411));
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_t_2412});
  } else {
    heff_drop(v_t_247);
    V v_x2_2413 = heff_tr(heff_call(v_go_240, 1, (V[]){v_v_244}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_b_2414 = heff_field(v_x2_2413, 0);
      V v_e_2415 = heff_field(v_x2_2413, 1);
      V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_acc_243)) {
      case TAG_MkPair: {
        V v_y_2417 = heff_field(v_acc_243, 1);
        heff_take_n(v_acc_243, 2ULL, 2);
        v_t_2418 = v_y_2417;
        break;
      }
      default: heff_nomatch(v_acc_243);
      }
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2415, NTAG(TAG_Nil)});
      V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2419));
      return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_b_2414, v_t_2420});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
}
Clo g_heff_2ecompile_2erefcount_2ereuseV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereuseV_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ereuseV(V v_ru_240, V v_n_241, V v_x3_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2erefcount_2ereuseV_24cpr(v_ru_240, v_n_241, v_x3_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ereuseV(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(V v_ru_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_TSeq: {
    V v_ss_243 = heff_field(v_x4_242, 0);
    V v_t_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TSeq = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), heff_dup(v_ss_243)));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_it1_248 = v_field_246;
      V v_ss2_249 = v_field_247;
      if ((heff_dup(v_it1_248) == NTAG(TAG_True))) {
        heff_drop(v_ru_240);
        heff_drop(v_n_241);
        heff_drop(v_ss_243);
        heff_drop(v_it1_248);
        return ((HeffT2){{NTAG(TAG_True), heff_tag_at_n(v_ru_24x4_242_24TSeq, TAG_TSeq, 2, (V[]){v_ss2_249, v_t_244})}});
      } else {
        heff_drop(v_it1_248);
        heff_drop(v_ss2_249);
        HeffT2 v_t_2410 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(v_ru_240, v_n_241, v_t_244));
        {
          V v_field_2411 = v_t_2410.f[0];
          V v_field_2412 = v_t_2410.f[1];
          V v_b_2413 = v_field_2411;
          V v_t2_2414 = v_field_2412;
          return ((HeffT2){{v_b_2413, heff_tag_at_n(v_ru_24x4_242_24TSeq, TAG_TSeq, 2, (V[]){v_ss_243, v_t2_2414})}});
        }
      }
    }
  }
  case TAG_TReturn: {
    V v_o_2415 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24TReturn = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_2416 = (g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(v_ru_240, v_n_241, v_o_2415));
    {
      V v_field_2417 = v_t_2416.f[0];
      V v_field_2418 = v_t_2416.f[1];
      V v_b_2419 = v_field_2417;
      V v_o2_2420 = v_field_2418;
      return ((HeffT2){{v_b_2419, heff_tag_at_n(v_ru_24x4_242_24TReturn, TAG_TReturn, 1, (V[]){v_o2_2420})}});
    }
  }
  case TAG_TLoop: {
    V v_vs_2421 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24TLoop = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_t_2423 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_vs_2421; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_vs_2421); r_; });
    switch (heff_tag_of(v_t_2423)) {
    case TAG_MkPair: {
      V v_b_2424 = heff_field(v_t_2423, 0);
      V v_vs2_2425 = heff_field(v_t_2423, 1);
      heff_take_n(v_t_2423, 3ULL, 2);
      return ((HeffT2){{v_b_2424, heff_tag_at_n(v_ru_24x4_242_24TLoop, TAG_TLoop, 1, (V[]){v_vs2_2425})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2423)}});
    }
  }
  case TAG_TIf: {
    V v_c_2426 = heff_field(v_x4_242, 0);
    V v_t_2427 = heff_field(v_x4_242, 1);
    V v_e_2428 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24TIf = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    HeffT2 v_t_2429 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_t_2427));
    {
      V v_field_2430 = v_t_2429.f[0];
      V v_field_2431 = v_t_2429.f[1];
      V v_bt_2432 = v_field_2430;
      V v_t2_2433 = v_field_2431;
      HeffT2 v_t_2434 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(v_ru_240, v_n_241, v_e_2428));
      {
        V v_field_2435 = v_t_2434.f[0];
        V v_field_2436 = v_t_2434.f[1];
        V v_be_2437 = v_field_2435;
        V v_e2_2438 = v_field_2436;
        V v_f_2439;
        if ((heff_dup(v_bt_2432) == NTAG(TAG_True))) {
          heff_drop(v_bt_2432);
          heff_drop(v_be_2437);
          v_f_2439 = NTAG(TAG_True);
        } else {
          heff_drop(v_bt_2432);
          v_f_2439 = v_be_2437;
        }
        return ((HeffT2){{v_f_2439, heff_tag_at_n(v_ru_24x4_242_24TIf, TAG_TIf, 3, (V[]){v_c_2426, v_t2_2433, v_e2_2438})}});
      }
    }
  }
  case TAG_TCase: {
    V v_v_2440 = heff_field(v_x4_242, 0);
    V v_arms_2441 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TCase = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_ps_2451 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam1, 1, 2, (V[]){v_ru_240, v_n_241}), v_arms_2441));
    V v_b_2452 = (g_list_2eany_24s910662703x1730636603(v_ps_2451));
    V v_as2_2453 = (g_list_2emap_24s1173914895x100384474(v_ps_2451));
    return ((HeffT2){{v_b_2452, heff_tag_at_n(v_ru_24x4_242_24TCase, TAG_TCase, 2, (V[]){v_v_2440, v_as2_2453})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam0(V self, V *args) {
  V v_v_2422 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_2422));
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr_lam1(V self, V *args) {
  V v_x4_2442 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x4_2442)) {
  case TAG_MkArm: {
    V v_t_2443 = heff_field(v_x4_2442, 0);
    V v_vs_2444 = heff_field(v_x4_2442, 1);
    V v_b_2445 = heff_field(v_x4_2442, 2);
    V v_ru_24x4_2442_24MkArm = heff_take_reuse_n(v_x4_2442, 7ULL, 3);
    HeffT2 v_t_2446 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(v_ru_240, v_n_241, v_b_2445));
    {
      V v_field_2447 = v_t_2446.f[0];
      V v_field_2448 = v_t_2446.f[1];
      V v_b_2449 = v_field_2447;
      V v_x_2450 = v_field_2448;
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2449, heff_tag_at_n(v_ru_24x4_2442_24MkArm, TAG_MkArm, 3, (V[]){v_t_2443, v_vs_2444, v_x_2450})});
    }
  }
  default: return heff_nomatch(v_x4_2442);
  }
}
Clo g_heff_2ecompile_2erefcount_2eothersW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eothersW_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eothersW(V v_x_240, V v_l_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_IVal: {
      V v_x311_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_245)) {
      case TAG_SVar: {
        V v_y_246 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        if (heff_strEq_c_lent(v_x_240, v_y_246, 2)) {
          heff_drop(v_rest_244);
          return NTAG(TAG_False);
        } else {
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_rest_244;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
      case TAG_SGlobal: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SInt: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat: {
        heff_take_na(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SStr: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SBytes: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFixed: {
        heff_take_n(v_x311_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SLam: {
        V v_x3112_2418 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        switch (heff_tag_of(v_x3112_2418)) {
        case TAG_MkBlock: {
          V v_t_2419 = heff_field(v_x3112_2418, 0);
          heff_take_n(v_x3112_2418, 1ULL, 1);
          V v_ps_2420 = ({ V a_0 = v_t_2419; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2419); r_; });
          V v_t_2421 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_240; V a_3 = v_ps_2420; V r_ = (g_list_2efoldl_24f613246640x472569916(a_0, a_1, a_2, a_3)); heff_drop(v_ps_2420); r_; });
          if (heff_intEq_c(v_t_2421, MK_INT(0LL))) {
            V t_0 = v_x_240;
            V t_1 = v_l_241;
            V t_2 = v_rest_244;
            v_x_240 = t_0;
            v_l_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          } else {
            heff_drop(v_rest_244);
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_x3112_2418);
        }
      }
      case TAG_STag: {
        V v_as_2424 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2424));
        V v_t_2427 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2426));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2427;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SRec: {
        V v_fs_2428 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2430 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2428));
        V v_t_2431 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2430));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2431;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SProj: {
        V v_e_2432 = heff_field(v_x311_245, 0);
        V v_l2_2433 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 3ULL, 4);
        V v_t_2459;
        switch (heff_tag_of(v_e_2432)) {
        case TAG_SVar: {
          V v_y_2436 = heff_dup(heff_field(v_e_2432, 0));
          v_t_2459 = heff_strEq_lent(v_x_240, v_y_2436, 2);
          break;
        }
        case TAG_SGlobal: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SInt: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SFloat: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SStr: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SBytes: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SFixed: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SFloat32: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SPrimFn: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SLam: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_STag: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SRec: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SProj: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        case TAG_SPrim: {
          v_t_2459 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_e_2432);
        }
        if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop(v_e_2432);
          heff_drop(v_t_2459);
          if (heff_strEq_c_lent(v_l_241, v_l2_2433, 2)) {
            heff_drop(v_rest_244);
            return NTAG(TAG_False);
          } else {
            V t_0 = v_x_240;
            V t_1 = v_l_241;
            V t_2 = v_rest_244;
            v_x_240 = t_0;
            v_l_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          }
        } else {
          heff_drop(v_l2_2433);
          heff_drop(v_t_2459);
          V v_t_2461 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_e_2432}), v_rest_244});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_2461;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
      case TAG_SPrim: {
        V v_as_2463 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2464 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2463));
        V v_t_2465 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2464));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2465;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_245);
      }
    }
    case TAG_IOp: {
      V v_x311_2466 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2466)) {
      case TAG_OSimple: {
        V v_v_2467 = heff_field(v_x311_2466, 0);
        heff_take_n(v_x311_2466, 1ULL, 1);
        V v_t_2468 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2467}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2468;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OCall: {
        V v_as_2470 = heff_field(v_x311_2466, 1);
        heff_take_n(v_x311_2466, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2471 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2470));
        V v_t_2472 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2471));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2472;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OApply: {
        V v_f_2473 = heff_field(v_x311_2466, 0);
        V v_as_2474 = heff_field(v_x311_2466, 1);
        heff_take_n(v_x311_2466, 3ULL, 2);
        V v_t_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2473, v_as_2474})));
        V v_t_2476 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2475));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2476;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OPrim: {
        V v_as_2478 = heff_field(v_x311_2466, 1);
        heff_take_n(v_x311_2466, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2478));
        V v_t_2480 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2479));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2480;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OBool: {
        V v_c_2481 = heff_field(v_x311_2466, 0);
        heff_take_n(v_x311_2466, 1ULL, 1);
        V v_t_2482 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2481}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2482;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_2466);
      }
    }
    case TAG_ICond: {
      V v_x311_2483 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ICond = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2483)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PRel: {
        V v_a_2485 = heff_field(v_x311_2483, 1);
        V v_b_2486 = heff_field(v_x311_2483, 2);
        heff_take_n(v_x311_2483, 6ULL, 3);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2487 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_b_2486}), v_rest_244});
        V v_t_2488 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_a_2485}), v_t_2487});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2488;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PBool: {
        V v_v_2489 = heff_field(v_x311_2483, 0);
        heff_take_n(v_x311_2483, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2490 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2489}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2490;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PNot: {
        V v_c_2491 = heff_field(v_x311_2483, 0);
        heff_take_n(v_x311_2483, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2492 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2491}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2492;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PIf: {
        V v_a_2493 = heff_field(v_x311_2483, 0);
        V v_b_2494 = heff_field(v_x311_2483, 1);
        V v_c_2495 = heff_field(v_x311_2483, 2);
        heff_take_n(v_x311_2483, 7ULL, 3);
        V v_t_2496 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2495}), v_rest_244});
        V v_t_2497 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_b_2494}), v_t_2496});
        V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_2493}), v_t_2497});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2498;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PLet: {
        V v_o_24100 = heff_field(v_x311_2483, 1);
        V v_c_24101 = heff_field(v_x311_2483, 2);
        heff_take_n(v_x311_2483, 6ULL, 3);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_24102 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24101}), v_rest_244});
        V v_t_24103 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24100}), v_t_24102});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24103;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_2483);
      }
    }
    case TAG_ISts: {
      V v_x311_24104 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ISts = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24104)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ISts, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_Cons: {
        V v_x3111_24105 = heff_field(v_x311_24104, 0);
        V v_ss_24106 = heff_field(v_x311_24104, 1);
        V v_ru_24x311_24104_24Cons = heff_take_reuse_n(v_x311_24104, 3ULL, 2);
        switch (heff_tag_of(v_x3111_24105)) {
        case TAG_SLet: {
          V v_o_24108 = heff_field(v_x3111_24105, 1);
          heff_take_n(v_x3111_24105, 2ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_24109 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24106}), v_rest_244});
          V v_t_24110 = heff_tag_at_n(v_ru_24x311_24104_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24108}), v_t_24109});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24110;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SDecl: {
          heff_take_n(v_x3111_24105, 0ULL, 1);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          heff_drop_cell(v_ru_24x311_24104_24Cons, 2);
          V v_t_24112 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24106}), v_rest_244});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24112;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SSet: {
          V v_o_24114 = heff_field(v_x3111_24105, 1);
          heff_take_n(v_x3111_24105, 2ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_24115 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24106}), v_rest_244});
          V v_t_24116 = heff_tag_at_n(v_ru_24x311_24104_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24114}), v_t_24115});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24116;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SIf: {
          V v_c_24117 = heff_field(v_x3111_24105, 0);
          V v_ts_24118 = heff_field(v_x3111_24105, 1);
          V v_fs_24119 = heff_field(v_x3111_24105, 2);
          heff_take_n(v_x3111_24105, 7ULL, 3);
          V v_t_24120 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24106}), v_rest_244});
          V v_t_24121 = heff_tag_at_n(v_ru_24x311_24104_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_fs_24119}), v_t_24120});
          V v_t_24122 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_24118}), v_t_24121});
          V v_t_24123 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24117}), v_t_24122});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24123;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SCase: {
          V v_v_24124 = heff_field(v_x3111_24105, 0);
          V v_arms_24125 = heff_field(v_x3111_24105, 1);
          heff_take_n(v_x3111_24105, 3ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_24126 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24106}), v_rest_244});
          V v_t_24127 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24125));
          V v_t_24128 = (g_list_2efoldl_24s1104809983x118204267(v_t_24126, v_t_24127));
          V v_t_24129 = heff_tag_at_n(v_ru_24x311_24104_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24124}), v_t_24128});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24129;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x3111_24105);
        }
      }
      default: return heff_nomatch(v_x311_24104);
      }
    }
    case TAG_ITl: {
      V v_x311_24130 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ITl = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24130)) {
      case TAG_TSeq: {
        V v_ss_24131 = heff_field(v_x311_24130, 0);
        V v_t_24132 = heff_field(v_x311_24130, 1);
        V v_ru_24x311_24130_24TSeq = heff_take_reuse_n(v_x311_24130, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24133 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_24132}), v_rest_244});
        V v_t_24134 = heff_tag_at_n(v_ru_24x311_24130_24TSeq, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24131}), v_t_24133});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24134;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TReturn: {
        V v_o_24135 = heff_field(v_x311_24130, 0);
        heff_take_n(v_x311_24130, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24136 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24135}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24136;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TLoop: {
        V v_vs_24137 = heff_field(v_x311_24130, 0);
        heff_take_n(v_x311_24130, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24138 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_24137));
        V v_t_24139 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_24138));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24139;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TIf: {
        V v_c_24140 = heff_field(v_x311_24130, 0);
        V v_t_24141 = heff_field(v_x311_24130, 1);
        V v_e_24142 = heff_field(v_x311_24130, 2);
        heff_take_n(v_x311_24130, 7ULL, 3);
        V v_t_24143 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_e_24142}), v_rest_244});
        V v_t_24144 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ITl, 1, (V[]){v_t_24141}), v_t_24143});
        V v_t_24145 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24140}), v_t_24144});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24145;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TCase: {
        V v_v_24146 = heff_field(v_x311_24130, 0);
        V v_arms_24147 = heff_field(v_x311_24130, 1);
        heff_take_n(v_x311_24130, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24148 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24147));
        V v_t_24149 = (g_list_2efoldl_24s421921225x565177679(v_rest_244, v_t_24148));
        V v_t_24150 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24146}), v_t_24149});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24150;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_24130);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2eothersW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eothersW(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2etakeVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etakeVar_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2etakeVar(V v_ce_240, V v_rest_241, V v_x3_242, V v_l_243, V v_sh_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_rest_241);
    heff_drop(v_l_243);
    heff_drop(v_sh_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_sh_244)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_241);
      heff_drop(v_l_243);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_ru_24sh_244_24Cons = heff_take_reuse_n(v_sh_244, 0ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_245, heff_rfield(v_ce_240, 4)));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_x1_249 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_245, heff_rfield(v_ce_240, 6)));
        if ((heff_dup(v_x1_249) == NTAG(TAG_True))) {
          heff_drop_rec(v_ce_240, 16);
          heff_drop(v_rest_241);
          heff_drop(v_l_243);
          heff_drop_cell(v_ru_24sh_244_24Cons, 2);
          heff_drop(v_x1_249);
          return NTAG(TAG_Nil);
        } else {
          heff_drop(v_x1_249);
          V v_x1_2410 = ({ V a_0 = v_x_245; V b_1 = heff_get_n(v_ce_240, 5, 16); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
            heff_drop(v_rest_241);
            heff_drop(v_l_243);
            heff_drop_cell(v_ru_24sh_244_24Cons, 2);
            heff_drop(v_x1_2410);
            return NTAG(TAG_Nil);
          } else {
            heff_drop(v_x1_2410);
            V v_t_2411 = (g_heff_2ecompile_2erefcount_2eothersW(v_x_245, v_l_243, v_rest_241));
            if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
              heff_drop(v_t_2411);
              return heff_tag_at_n(v_ru_24sh_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_245), v_l_243}), NTAG(TAG_Nil)});
            } else {
              heff_drop(v_l_243);
              heff_drop_cell(v_ru_24sh_244_24Cons, 2);
              heff_drop(v_t_2411);
              return NTAG(TAG_Nil);
            }
          }
        }
      } else {
        heff_drop_rec(v_ce_240, 16);
        heff_drop(v_rest_241);
        heff_drop(v_l_243);
        heff_drop_cell(v_ru_24sh_244_24Cons, 2);
        heff_drop(v_t_248);
        return NTAG(TAG_Nil);
      }
    }
    default: return heff_nomatch(v_sh_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2etakeVar_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2etakeVar(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str0, 7, "intHash");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str1, 6, "intShr");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str2, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str3, 6, "intXor");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str4, 6, "intShl");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str5, 6, "intAnd");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str6, 5, "intOr");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str7, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str8, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str9, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str10, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str11, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str12, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str13, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eintPrims_str14, 6, "intSub");

static V g_heff_2ecompile_2erefcount_2eintPrims_val;
static HEFF_ONCE g_heff_2ecompile_2erefcount_2eintPrims_st;
static V g_heff_2ecompile_2erefcount_2eintPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str8), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str10), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str12), v_t_245})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erefcount_2eintPrims_str14), v_t_246})});
}
V g_heff_2ecompile_2erefcount_2eintPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erefcount_2eintPrims_st)) return g_heff_2ecompile_2erefcount_2eintPrims_val;
  return heff_global(&g_heff_2ecompile_2erefcount_2eintPrims_val, &g_heff_2ecompile_2erefcount_2eintPrims_st, g_heff_2ecompile_2erefcount_2eintPrims_init);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2epeekOf_str0, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2erefcount_2epeekOf_str1, 10, "arrayIndex");
Clo g_heff_2ecompile_2erefcount_2epeekOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2epeekOf_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2epeekOf(V v_ce_240, V v_x_241, V v_o_242, V v_rest_243) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_o1_244 = heff_field(v_o_242, 0);
    switch (heff_tag_of(v_o1_244)) {
    case TAG_SVar: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SInt: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SStr: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SBytes: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFixed: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat32: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFn: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      V v_p_2426 = heff_field(v_o1_244, 0);
      V v_as_2427 = heff_field(v_o1_244, 1);
      if (heff_strEq_c_lent(v_p_2426, ((V)&g_heff_2ecompile_2erefcount_2epeekOf_str0), 2)) {
        HEFF_LAST return g_heff_2ecompile_2erefcount_2epeekArgs(v_ce_240, v_x_241, heff_dup(v_as_2427), v_rest_243);
      } else {
        heff_drop(v_ce_240);
        heff_drop(v_rest_243);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_o1_244);
    }
  }
  case TAG_OCall: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_OApply: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_OPrim: {
    V v_p_2433 = heff_field(v_o_242, 0);
    V v_as_2434 = heff_field(v_o_242, 1);
    if (heff_strEq_c_lent(v_p_2433, ((V)&g_heff_2ecompile_2erefcount_2epeekOf_str1), 2)) {
      HEFF_LAST return g_heff_2ecompile_2erefcount_2epeekArgs(v_ce_240, v_x_241, heff_dup(v_as_2434), v_rest_243);
    } else {
      heff_drop(v_ce_240);
      heff_drop(v_rest_243);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_OAbandon: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_OBool: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_243);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_o_242);
  }
}
V g_heff_2ecompile_2erefcount_2epeekOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2epeekOf(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2eunboxParams_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eunboxParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eunboxParams_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2eunboxParams(V v_ce_240, V v_bi_241, V v_rps_242, V v_xs_243) {
top: ;
  V v_t_244 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_243), v_rps_242));
  V v_t_245 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
  V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
  V v_t_2417 = (g_list_2efoldl_24f1686830387x1555365313(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2erefcount_2eunboxParams_lam0, 2, 2, (V[]){heff_dup(v_bi_241), v_ce_240}), v_t_244, v_t_246));
  return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2417); r_; });
}
V g_heff_2ecompile_2erefcount_2eunboxParams_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eunboxParams(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2eunboxParams_lam0(V self, V *args) {
  V v_p_247 = args[0];
  V v_i_248 = args[1];
  V v_bi_241 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_lent_249 = ({ V a_0 = v_i_248; V a_1 = v_bi_241; V r_ = (g_heff_2ecompile_2erefcount_2eelemI(a_0, a_1)); heff_drop(v_bi_241); r_; });
  V v_t_2412;
  switch (heff_tag_of(v_p_247)) {
  case TAG_MkPair: {
    V v_y_2411 = heff_dup(heff_field(v_p_247, 1));
    v_t_2412 = v_y_2411;
    break;
  }
  default: heff_nomatch(v_p_247);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_RepV: {
    V v_t_2415;
    switch (heff_tag_of(v_p_247)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_p_247, 0);
      heff_take_n(v_p_247, 1ULL, 2);
      v_t_2415 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_p_247);
    }
    return ({ V a_0 = v_ce_240; V a_1 = v_lent_249; V a_2 = v_t_2415; V r_ = (g_heff_2ecompile_2erefcount_2eunboxParam(a_0, a_1, a_2)); heff_drop(v_lent_249); r_; });
  }
  case TAG_RepFix: {
    heff_take_n(v_t_2412, 0ULL, 1);
    heff_drop(v_p_247);
    heff_drop(v_ce_240);
    heff_drop(v_lent_249);
    return NTAG(TAG_Nil);
  }
  case TAG_RepF64: {
    heff_drop(v_p_247);
    heff_drop(v_ce_240);
    heff_drop(v_lent_249);
    return NTAG(TAG_Nil);
  }
  case TAG_RepInt: {
    heff_drop(v_p_247);
    heff_drop(v_ce_240);
    heff_drop(v_lent_249);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_2412);
  }
}

HeffT2 g_heff_2ecompile_2erefcount_2etagGiven_24cpr(V v_ts_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_Nothing: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_v1_242 = heff_field(v_v_241, 0);
    switch (heff_tag_of(v_v1_242)) {
    case TAG_RLocal: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RDup: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RClo: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGet: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGetRaw: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RStr: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RBytes: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFixed: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RF32: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RNTag: {
      V v_t_2415 = heff_field(v_v1_242, 0);
      V v_t_2416 = (g_heff_2ecompile_2erefcount_2eelemS(v_t_2415, v_ts_240));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_t_2415)}});
      } else {
        heff_drop(v_t_2416);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_RTag: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RTagIn: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RRec: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RRecIn: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RField: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RDupE: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFieldV: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGetN: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFieldU: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGetNU: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RWord: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RTakeField: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGetLabel: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPrimFn: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPrim: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RLam: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RCall: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RApply: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RBool: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RAbandon: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RBox: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RUnbox: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPeek: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPrimU: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPrimAt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFixU: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RF32U: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RF64U: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_v1_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_v_241)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2ethreadSts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ethreadSts_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ethreadSts(V v_th_240, V v_ss_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erefcount_2ethreadSts_clo), 1, (V[]){heff_dup(v_th_240)}));
  return (g_list_2emap_24s1512396752x1753792987(v_th_240, v_t_242, v_ss_241));
}
V g_heff_2ecompile_2erefcount_2ethreadSts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ethreadSts(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2egoneTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2egoneTo_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2egoneTo(V v_acc_240, V v_ss_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erefcount_2egoneOne_clo), 1, (V[]){((V)&g_heff_2ecompile_2erefcount_2egoneTo_clo)}));
  return (g_list_2efoldl(v_t_242, v_acc_240, v_ss_241));
}
V g_heff_2ecompile_2erefcount_2egoneTo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2egoneTo(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2ethreadedArms_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ethreadedArms_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ethreadedArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ethreadedArms_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ethreadedArms(V v_th_240, V v_arms_241) {
top: ;
  V v_gone_2412 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ethreadedArms_lam0, 1, 1, (V[]){v_th_240}), v_arms_241));
  V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_gone_2412)));
  V v_t_2414 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s1879887278x1868824044(a_0, a_1)); heff_drop(v_t_2413); r_; });
  V v_ts_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_heff_2ecompile_2erefcount_2egoneTo(a_0, a_1)); heff_drop(v_t_2414); r_; });
  HEFF_LAST return g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ethreadedArms_lam1, 1, 1, (V[]){v_ts_2415}), v_gone_2412);
}
V g_heff_2ecompile_2erefcount_2ethreadedArms_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ethreadedArms(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2ethreadedArms_lam0(V self, V *args) {
  V v_x2_242 = args[0];
  V v_th_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_242)) {
  case TAG_MkCArm: {
    V v_t_243 = heff_field(v_x2_242, 0);
    V v_fs_244 = heff_field(v_x2_242, 1);
    V v_fl_245 = heff_field(v_x2_242, 2);
    V v_su_246 = heff_field(v_x2_242, 3);
    V v_pl_247 = heff_field(v_x2_242, 4);
    V v_tk_248 = heff_field(v_x2_242, 5);
    V v_body_249 = heff_field(v_x2_242, 6);
    V v_lv_2410 = heff_field(v_x2_242, 7);
    V v_ru_24x2_242_24MkCArm = heff_take_reuse_n(v_x2_242, 255ULL, 8);
    V v_t_2411 = (g_heff_2ecompile_2erefcount_2ethreadSts(v_th_240, v_body_249));
    return heff_tag_at_n(v_ru_24x2_242_24MkCArm, TAG_MkCArm, 8, (V[]){v_t_243, v_fs_244, v_fl_245, v_su_246, v_pl_247, v_tk_248, v_t_2411, v_lv_2410});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2erefcount_2ethreadedArms_lam1(V self, V *args) {
  V v_x2_2416 = args[0];
  V v_ts_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkCArm: {
    V v_t_2417 = heff_field(v_x2_2416, 0);
    V v_fs_2418 = heff_field(v_x2_2416, 1);
    V v_fl_2419 = heff_field(v_x2_2416, 2);
    V v_su_2420 = heff_field(v_x2_2416, 3);
    V v_pl_2421 = heff_field(v_x2_2416, 4);
    V v_tk_2422 = heff_field(v_x2_2416, 5);
    V v_body_2423 = heff_field(v_x2_2416, 6);
    V v_lv_2424 = heff_field(v_x2_2416, 7);
    V v_ru_24x2_2416_24MkCArm = heff_take_reuse_n(v_x2_2416, 255ULL, 8);
    V v_t_2425 = ({ V a_0 = v_t_2417; V a_1 = v_ts_2415; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_ts_2415); r_; });
    V v_t_2426;
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_t_2425);
      v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLabel, 1, (V[]){heff_dup(v_t_2417)}), v_body_2423});
    } else {
      heff_drop(v_t_2425);
      v_t_2426 = v_body_2423;
    }
    return heff_tag_at_n(v_ru_24x2_2416_24MkCArm, TAG_MkCArm, 8, (V[]){v_t_2417, v_fs_2418, v_fl_2419, v_su_2420, v_pl_2421, v_tk_2422, v_t_2426, v_lv_2424});
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
Clo g_heff_2ecompile_2erefcount_2ethreaded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ethreaded_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ethreaded(V v_xs_240, V v_ss_241) {
top: ;
  switch (heff_tag_of(v_ss_241)) {
  case TAG_Nil: {
    heff_drop(v_xs_240);
    return v_ss_241;
  }
  case TAG_Cons: {
    V v_ss1_242 = heff_dup(heff_field(v_ss_241, 0));
    V v_ss2_243 = heff_dup(heff_field(v_ss_241, 1));
    switch (heff_tag_of(v_ss1_242)) {
    case TAG_CDrop: {
      heff_take_n(v_ss1_242, 0ULL, 1);
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CLet: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CDecl: {
      heff_take_n(v_ss1_242, 0ULL, 1);
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CSet: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CAbandon: {
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CIf: {
      heff_take_n(v_ss1_242, 0ULL, 3);
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CSwitch: {
      V v_ss11_2413 = heff_field(v_ss1_242, 0);
      V v_arms_2414 = heff_field(v_ss1_242, 1);
      V v_r_2415 = heff_field(v_ss1_242, 2);
      V v_ru_24ss1_242_24CSwitch = heff_take_reuse_n(v_ss1_242, 7ULL, 3);
      switch (heff_tag_of(v_ss11_2413)) {
      case TAG_RLocal: {
        V v_p_2416 = heff_field(v_ss11_2413, 0);
        heff_take_n(v_ss11_2413, 1ULL, 1);
        switch (heff_tag_of(v_ss2_243)) {
        case TAG_Nil: {
          heff_drop_tag(v_ss_241, 2);
          HeffT2 v_t_2417 = (g_heff_2ecompile_2erefcount_2eindexIn_24cpr(v_p_2416, MK_INT(0LL), v_xs_240));
          {
            V v_field_2419 = v_t_2417.f[1];
            int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
            if ((v_tag_2418 == ((int64_t)0ULL))) {
              V v_i_2421 = v_field_2419;
              V v_t_2422 = (g_list_2efoldl_24s2092021924x904081891(NTAG(TAG_Nil), heff_dup(v_arms_2414)));
              V v_t_2423 = (g_heff_2ecompile_2erefcount_2ethreadedArms(heff_rec_n(2, shape_at__tags, (V[]){v_i_2421, v_t_2422}), v_arms_2414));
              V v_t_2424 = heff_tag_at_n(v_ru_24ss1_242_24CSwitch, TAG_CSwitch, 3, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_p_2416}), v_t_2423, v_r_2415});
              return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
            } else {
              heff_drop(v_field_2419);
              V v_t_2425 = heff_tag_at_n(v_ru_24ss1_242_24CSwitch, TAG_CSwitch, 3, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_p_2416}), v_arms_2414, v_r_2415});
              return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
            }
          }
        }
        case TAG_Cons: {
          heff_take_n(v_ss2_243, 0ULL, 2);
          heff_drop(v_xs_240);
          heff_drop(v_arms_2414);
          heff_drop(v_r_2415);
          heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
          heff_drop(v_p_2416);
          return v_ss_241;
        }
        default: return heff_nomatch(v_ss2_243);
        }
      }
      case TAG_RDup: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RClo: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RGet: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RGetRaw: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RInt: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RFloat: {
        heff_take_na(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RStr: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RBytes: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RFixed: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RF32: {
        heff_take_na(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RNTag: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RTag: {
        heff_take_n(v_ss11_2413, 0ULL, 3);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RTagIn: {
        heff_take_n(v_ss11_2413, 0ULL, 4);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RRec: {
        heff_take_n(v_ss11_2413, 0ULL, 3);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RRecIn: {
        heff_take_n(v_ss11_2413, 0ULL, 8);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RField: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RDupE: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RFieldV: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RGetN: {
        heff_take_n(v_ss11_2413, 0ULL, 3);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RFieldU: {
        heff_take_n(v_ss11_2413, 0ULL, 4);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RGetNU: {
        heff_take_n(v_ss11_2413, 0ULL, 5);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RWord: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RTakeField: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RGetLabel: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RPrimFn: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RPrim: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RLam: {
        heff_take_n(v_ss11_2413, 0ULL, 4);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RCall: {
        heff_take_n(v_ss11_2413, 0ULL, 4);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RApply: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RBool: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RAbandon: {
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RBox: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RUnbox: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RPeek: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RPrimU: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RPrimAt: {
        heff_take_n(v_ss11_2413, 0ULL, 3);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RFixU: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RF32U: {
        heff_take_na(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RF64U: {
        heff_take_na(v_ss11_2413, 0ULL, 1);
        heff_drop(v_xs_240);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      default: return heff_nomatch(v_ss11_2413);
      }
    }
    case TAG_CReturn: {
      heff_take_n(v_ss1_242, 0ULL, 1);
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CInPlace: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CRoomed: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CTail: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CLoop: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CLoopTo: {
      heff_take_n(v_ss1_242, 0ULL, 3);
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CLabel: {
      heff_take_n(v_ss1_242, 0ULL, 1);
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CJump: {
      heff_take_n(v_ss1_242, 0ULL, 3);
      heff_drop(v_xs_240);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    default: return heff_nomatch(v_ss1_242);
    }
  }
  default: return heff_nomatch(v_ss_241);
  }
}
V g_heff_2ecompile_2erefcount_2ethreaded_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ethreaded(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928(V v_ce_240, V v_live_241, V v_e_242, V v_i_243, V v_n_244, V v_may_245) {
top: ;
  V v_t_2429;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SVar: {
    V v_x_246 = heff_dup(heff_field(v_e_242, 0));
    v_t_2429 = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
    break;
  }
  case TAG_SGlobal: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SInt: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SStr: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SBytes: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFixed: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat32: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrimFn: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SLam: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_STag: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SRec: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SProj: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrim: {
    v_t_2429 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_242);
  }
  V v_t_2453;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SVar: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SGlobal: {
    V v_g_2431 = heff_dup(heff_field(v_e_242, 0));
    v_t_2453 = heff_tag_n(TAG_Just, 1, (V[]){v_g_2431});
    break;
  }
  case TAG_SInt: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SStr: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SBytes: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFixed: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat32: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrimFn: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SLam: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_STag: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SRec: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SProj: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrim: {
    v_t_2453 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_242);
  }
  return (g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539(v_ce_240, v_live_241, v_e_242, v_i_243, v_n_244, v_may_245, v_t_2429, v_t_2453));
}
V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
Clo g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(V v_ce_240, V v_live_241, V v_e_242, V v_l_243, V v_t_244, V v_n_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    heff_drop(v_n_245);
    V v_t_247 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, NTAG(TAG_RepV), v_e_242));
    return heff_tag_n(TAG_RGetLabel, 2, (V[]){v_t_247, v_l_243});
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_x8_246, 0);
    V v_may_249 = (g_heff_2ecompile_2erepr_2emayBeFlat(v_t_244));
    HeffT2 v_t_2410 = ({ V a_0 = heff_rfield(v_ce_240, 9); V a_1 = v_live_241; V a_2 = heff_dup(v_e_242); V a_3 = v_l_243; V a_4 = heff_dup(v_i_248); HeffT2 r_ = (g_heff_2ecompile_2erefcount_2etakeIn_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_l_243); r_; });
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        heff_drop_rec(v_ce_240, 16);
        heff_drop(v_live_241);
        heff_drop(v_e_242);
        heff_drop(v_n_245);
        heff_drop(v_may_249);
        V v_t_2414 = v_field_2412;
        return v_t_2414;
      } else {
        heff_drop(v_field_2412);
        return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_e_242; V a_3 = heff_dup(v_i_248); V a_4 = v_n_245; V a_5 = v_may_249; V r_ = (g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_may_249); r_; });
      }
    }
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V r = g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(a[0], a[1], a[2], a[3], a4, a[5], a6); heff_drop(a4); heff_drop(a6); return r;
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_Cons: {
    V v_ru_243 = heff_field(v_x4_242, 0);
    V v_x42_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_244)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
    }
    case TAG_Cons: {
      V v_x421_245 = heff_field(v_x42_244, 0);
      V v_x422_246 = heff_field(v_x42_244, 1);
      switch (heff_tag_of(v_x421_245)) {
      case TAG_SVar: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SGlobal: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SInt: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SFloat: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SStr: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SBytes: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SFixed: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SFloat32: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SPrimFn: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SLam: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_STag: {
        V v_t_2419 = heff_field(v_x421_245, 0);
        V v_as_2420 = heff_field(v_x421_245, 1);
        V v_ts_2421 = heff_field(v_x421_245, 2);
        switch (heff_tag_of(v_x422_246)) {
        case TAG_Nil: {
          V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_as_2420)));
          V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_2422); r_; });
          V v_live_2424 = (g_prelude_2e_2b_2b(v_t_2423, heff_dup(v_live_241)));
          V v_t_2425 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2424, NTAG(TAG_RepV), heff_dup(v_ru_243)));
          V v_n_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2420));
          V v_t_2427 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2426, MK_INT(1LL))));
          V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam0, 1, 1, (V[]){heff_dup(v_ts_2421)}), v_t_2427));
          V v_t_2431 = (g_heff_2ecompile_2erefcount_2eslotBits(v_t_2430));
          V v_n_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2420));
          V v_t_2433 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2432, MK_INT(1LL))));
          V v_rps_2436 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam1, 1, 1, (V[]){heff_dup(v_ts_2421)}), v_t_2433));
          V v_t_2437 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_240, v_live_241, heff_dup(v_rps_2436), heff_dup(v_as_2420)));
          V v_t_2438 = (g_list_2ezipWith_24s870182194x1066240094(v_rps_2436, v_t_2437));
          return heff_tag_n(TAG_RTagIn, 4, (V[]){v_t_2425, heff_dup(v_t_2419), v_t_2431, v_t_2438});
        }
        case TAG_Cons: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        default: return heff_nomatch(v_x422_246);
        }
      }
      case TAG_SRec: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SProj: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SPrim: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      default: return heff_nomatch(v_x421_245);
      }
    }
    default: return heff_nomatch(v_x42_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam0(V self, V *args) {
  V v_i_2428 = args[0];
  V v_ts_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = ({ V a_0 = heff_dup(v_i_2428); V a_1 = v_ts_2421; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2421); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2428, v_t_2429));
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam1(V self, V *args) {
  V v_i_2434 = args[0];
  V v_ts_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = ({ V a_0 = heff_dup(v_i_2434); V a_1 = v_ts_2421; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2421); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2434, v_t_2435));
}
Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x4_242, 0);
    V v_es_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_244)));
    V v_t_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_245); r_; });
    V v_live_247 = (g_prelude_2e_2b_2b(v_t_246, heff_dup(v_live_241)));
    V v_t_248 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_247, NTAG(TAG_RepV), v_e_243));
    V v_cell_249 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(v_ce_240, v_live_241, v_es_244, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(V v_ce_240, V v_live_241, V v_x4_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_242, 0);
    V v_es_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_245)));
    V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_live_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_live_241)));
    V v_t_249 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_248, NTAG(TAG_RepV), v_e_244));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_ce_240;
    V t_1 = v_live_241;
    V t_2 = v_es_245;
    V t_3 = v_cell_2410;
    v_ce_240 = t_0;
    v_live_241 = t_1;
    v_x4_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_str0, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_str1, 14, "arrayReplicate");
Clo g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SVar: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SVar = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(heff_rfield(v_ce_240, 10), v_x_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop_rec(v_ce_240, 16);
        heff_drop(v_live_241);
        V v_x_248 = v_field_246;
        heff_drop(v_x_248);
        return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RLocal, 1, (V[]){v_x_243});
      } else {
        heff_drop(v_field_246);
        V v_t_249 = ({ V a_0 = v_x_243; V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop_rec(v_ce_240, 16);
          heff_drop(v_t_249);
          return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RDup, 1, (V[]){v_x_243});
        } else {
          heff_drop(v_t_249);
          V v_t_2410 = ({ V a_0 = v_x_243; V b_1 = heff_get_n(v_ce_240, 6, 16); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
            heff_drop(v_t_2410);
            return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RDup, 1, (V[]){v_x_243});
          } else {
            heff_drop(v_t_2410);
            return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RLocal, 1, (V[]){v_x_243});
          }
        }
      }
    }
  }
  case TAG_SGlobal: {
    V v_g_2411 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SGlobal = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_live_241);
    HeffT2 v_t_2412 = ({ V b_0 = heff_get_n(v_ce_240, 0, 16); V a_1 = v_g_2411; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        V v_x_2416 = v_field_2414;
        heff_drop(v_x_2416);
        return heff_tag_at_n(v_ru_24x4_242_24SGlobal, TAG_RClo, 1, (V[]){v_g_2411});
      } else {
        heff_drop(v_field_2414);
        return heff_tag_at_n(v_ru_24x4_242_24SGlobal, TAG_RGet, 1, (V[]){v_g_2411});
      }
    }
  }
  case TAG_SInt: {
    V v_n_2417 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SInt = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SInt, TAG_RInt, 1, (V[]){v_n_2417});
  }
  case TAG_SFloat: {
    double v_x_2418 = heff_tflat_f64(v_x4_242, 0);
    V v_ru_24x4_242_24SFloat = heff_take_reuse_na(v_x4_242, 0ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_nf(v_ru_24x4_242_24SFloat, TAG_RFloat, 1, 1u, (V[]){heff_word_f64(v_x_2418)});
  }
  case TAG_SStr: {
    V v_s_2419 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SStr = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SStr, TAG_RStr, 1, (V[]){v_s_2419});
  }
  case TAG_SBytes: {
    V v_s_2420 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SBytes = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SBytes, TAG_RBytes, 1, (V[]){v_s_2420});
  }
  case TAG_SFixed: {
    V v_w_2421 = heff_field(v_x4_242, 0);
    V v_n_2422 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SFixed = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SFixed, TAG_RFixed, 2, (V[]){v_w_2421, v_n_2422});
  }
  case TAG_SFloat32: {
    double v_x_2423 = heff_tflat_f64(v_x4_242, 0);
    V v_ru_24x4_242_24SFloat32 = heff_take_reuse_na(v_x4_242, 0ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_nf(v_ru_24x4_242_24SFloat32, TAG_RF32, 1, 1u, (V[]){heff_word_f64(v_x_2423)});
  }
  case TAG_SPrimFn: {
    V v_p_2424 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SPrimFn = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SPrimFn, TAG_RPrimFn, 1, (V[]){v_p_2424});
  }
  case TAG_SLam: {
    V v_xs_2425 = heff_field(v_x4_242, 0);
    V v_x42_2426 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x42_2426)) {
    case TAG_MkBlock: {
      V v_t_2427 = heff_field(v_x42_2426, 0);
      heff_take_n(v_x42_2426, 1ULL, 1);
      V v_t_2428 = (g_heff_2ecompile_2erefcount_2efreeOf(heff_dup(v_xs_2425), heff_dup(v_t_2427)));
      return (g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(v_ce_240, v_live_241, v_xs_2425, v_t_2427, v_t_2428));
    }
    default: return heff_nomatch(v_x42_2426);
    }
  }
  case TAG_STag: {
    V v_t_2429 = heff_field(v_x4_242, 0);
    V v_as_2430 = heff_field(v_x4_242, 1);
    V v_ts_2431 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    switch (heff_tag_of(v_as_2430)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_live_241);
      heff_drop(v_ts_2431);
      return heff_tag_n(TAG_RNTag, 1, (V[]){v_t_2429});
    }
    case TAG_Cons: {
      return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_t_2429; V a_3 = v_as_2430; V a_4 = v_ts_2431; V r_ = (g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ts_2431); r_; });
    }
    default: return heff_nomatch(v_as_2430);
    }
  }
  case TAG_SRec: {
    V v_fs_2434 = heff_field(v_x4_242, 0);
    V v_ts_2435 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_t_2436 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2434)));
    V v_t_2437 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_live_241; V a_2 = v_t_2436; V a_3 = heff_dup(v_fs_2434); V r_ = (g_heff_2ecompile_2erefcount_2eupdatedIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2436); r_; });
    return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_fs_2434; V a_3 = v_ts_2435; V a_4 = v_t_2437; V r_ = (g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ts_2435); heff_drop(v_t_2437); r_; });
  }
  case TAG_SProj: {
    V v_e_2438 = heff_field(v_x4_242, 0);
    V v_l_2439 = heff_field(v_x4_242, 1);
    V v_sh_2440 = heff_field(v_x4_242, 2);
    V v_t_2441 = heff_field(v_x4_242, 3);
    heff_take_n(v_x4_242, 15ULL, 4);
    V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2440));
    V v_t_2443 = (g_heff_2ecompile_2erefcount_2eindexIn(v_l_2439, MK_INT(0LL), v_sh_2440));
    return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_e_2438; V a_3 = v_l_2439; V a_4 = v_t_2441; V a_5 = v_t_2442; V a_6 = v_t_2443; V r_ = (g_heff_2ecompile_2erefcount_2eprojAt_24s876374567x2056622650(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2441); heff_drop(v_t_2443); r_; });
  }
  case TAG_SPrim: {
    V v_p_2444 = heff_field(v_x4_242, 0);
    V v_as_2445 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_t_2448;
    if (heff_strEq_c_lent(v_p_2444, ((V)&g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_str0), 2)) {
      v_t_2448 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(2LL)});
    } else {
      if (heff_strEq_c_lent(v_p_2444, ((V)&g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_str1), 2)) {
        v_t_2448 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(1LL)});
      } else {
        v_t_2448 = NTAG(TAG_Nothing);
      }
    }
    return (g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495(v_ce_240, v_live_241, v_p_2444, v_as_2445, v_t_2448));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330(V v_ce_240, V v_lent_241, V v_live_242, V v_bi_243, V v_i_244, V v_e_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    V v_t_247 = (g_heff_2ecompile_2erefcount_2eelemI(v_i_244, v_bi_243));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_242, NTAG(TAG_RepV), v_e_245));
      return heff_tag_n(TAG_LentValue, 1, (V[]){v_t_248});
    } else {
      heff_drop(v_t_247);
      V v_t_249 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_242, NTAG(TAG_RepV), v_e_245));
      return heff_tag_n(TAG_Given, 1, (V[]){v_t_249});
    }
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_x8_246, 0);
    V v_ru_24x8_246_24Just = heff_take_reuse_n(v_x8_246, 1ULL, 1);
    V v_t_2411 = (g_heff_2ecompile_2erefcount_2eelemI(v_i_244, v_bi_243));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_live_242);
      heff_drop(v_e_245);
      heff_drop(v_t_2411);
      V v_t_2412 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_2410, v_lent_241));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop_rec(v_ce_240, 16);
        heff_drop(v_t_2412);
        return heff_tag_at_n(v_ru_24x8_246_24Just, TAG_Given, 1, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_x_2410})});
      } else {
        heff_drop(v_t_2412);
        V v_t_2413 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_2410, heff_rfield(v_ce_240, 6)));
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop_rec(v_ce_240, 16);
          heff_drop(v_t_2413);
          return heff_tag_at_n(v_ru_24x8_246_24Just, TAG_Given, 1, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_x_2410})});
        } else {
          heff_drop_cell(v_ru_24x8_246_24Just, 1);
          heff_drop(v_t_2413);
          V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2410), NTAG(TAG_Nil)});
          V v_t_2415 = (g_heff_2ecompile_2erefcount_2edropsOf(v_ce_240, v_t_2414));
          return heff_tag_n(TAG_LentVar, 2, (V[]){v_x_2410, v_t_2415});
        }
      }
    } else {
      heff_drop(v_x_2410);
      heff_drop(v_t_2411);
      V v_t_2416 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_242, NTAG(TAG_RepV), v_e_245));
      return heff_tag_at_n(v_ru_24x8_246_24Just, TAG_Given, 1, (V[]){v_t_2416});
    }
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330(a[0], a1, a[2], a3, a[4], a[5], a[6]); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769(V v_ce_240, V v_c_241, V v_yes_242, V v_no_243, V v_wanted_244) {
top: ;
  V v_xs_247 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam0, 1, 1, (V[]){heff_dup(v_wanted_244)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_248 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_247));
  V v_t_249 = (g_list_2emap_24s1796125103x644876049(v_t_248));
  V v_t_2411 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam1, 1, 1, (V[]){heff_dup(v_wanted_244)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_ce_2412 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2411, heff_dup(v_wanted_244), heff_dup(v_ce_240)));
  V v_t_2413 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_2412, 4)), heff_dup(heff_rfield(v_ce_2412, 6))));
  V v_t_2414 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2413, v_ce_2412));
  V v_t_2415 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2414));
  V v_t_2416 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_2415, v_c_241));
  V v_t_2418 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam2, 1, 1, (V[]){heff_dup(v_wanted_244)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2419 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2418, heff_dup(heff_rfield(v_ce_240, 5)), heff_dup(v_ce_240)));
  V v_t_2420 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2419, v_yes_242));
  V v_t_2422 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam3, 1, 1, (V[]){v_wanted_244}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2423 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2422, heff_dup(heff_rfield(v_ce_240, 5)), v_ce_240));
  V v_t_2424 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2423, v_no_243));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_t_2416, v_t_2420, v_t_2424}), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_t_249, v_t_2425));
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769(a[0], a[1], a2, a3, a[4]); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam0(V self, V *args) {
  V v_v_245 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_246 = ({ V a_0 = v_v_245; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_245); heff_drop(v_wanted_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_246) == NTAG(TAG_True)));
  heff_drop(v_x1_246);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam1(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2410; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2410); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam2(V self, V *args) {
  V v_v_2417 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2417; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2417); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_lam3(V self, V *args) {
  V v_v_2421 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2421; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2421); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(V v_ce_240, V v_p_241, V v_args_242, V v_yes_243, V v_no_244, V v_fa_245, V v_wb_246) {
top: ;
  V v_wanted_247 = (g_prelude_2e_2b_2b(heff_dup(v_fa_245), heff_dup(v_wb_246)));
  V v_xs_2410 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam0, 1, 1, (V[]){v_wanted_247}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2411 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2410));
  V v_t_2412 = (g_list_2emap_24s1796125103x644876049(v_t_2411));
  V v_wanted_2413 = (g_prelude_2e_2b_2b(v_fa_245, heff_dup(v_wb_246)));
  V v_t_2415 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam1, 1, 1, (V[]){v_wanted_2413}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_ce_2416 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2415, heff_dup(v_wb_246), heff_dup(v_ce_240)));
  HeffT2 v_t_2417 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_241));
  V v_t_2424;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_sh_2421 = v_field_2419;
      V v_t_2422 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_2416, heff_dup(v_wb_246), heff_get_n(v_sh_2421, 0, 2), v_args_242));
      v_t_2424 = heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_241, v_t_2422});
    } else {
      heff_drop(v_field_2419);
      V v_t_2423 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_2416, heff_dup(v_wb_246), v_args_242));
      v_t_2424 = heff_tag_n(TAG_CondRel, 2, (V[]){v_p_241, v_t_2423});
    }
  }
  V v_t_2426 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam2, 1, 1, (V[]){heff_dup(v_wb_246)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2427 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2426, heff_dup(heff_rfield(v_ce_240, 5)), heff_dup(v_ce_240)));
  V v_t_2428 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2427, v_yes_243));
  V v_t_2430 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam3, 1, 1, (V[]){v_wb_246}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2431 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2430, heff_dup(heff_rfield(v_ce_240, 5)), v_ce_240));
  V v_t_2432 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2431, v_no_244));
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_t_2424, v_t_2428, v_t_2432}), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_t_2412, v_t_2433));
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(a[0], a[1], a[2], a3, a4, a[5], a[6]); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam0(V self, V *args) {
  V v_v_248 = args[0];
  V v_wanted_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = ({ V a_0 = v_v_248; V a_1 = v_wanted_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_248); heff_drop(v_wanted_247); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
  heff_drop(v_x1_249);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam1(V self, V *args) {
  V v_v_2414 = args[0];
  V v_wanted_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2414; V a_1 = v_wanted_2413; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2414); heff_drop(v_wanted_2413); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam2(V self, V *args) {
  V v_v_2425 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2425; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2425); heff_drop(v_wb_246); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_lam3(V self, V *args) {
  V v_v_2429 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2429; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2429); heff_drop(v_wb_246); r_; });
}
Clo g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(V v_ce_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    V v_x_242 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SVar = heff_take_reuse_n(v_v_241, 1ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    return heff_tag_at_n(v_ru_24v_241_24SVar, TAG_RLocal, 1, (V[]){v_x_242});
  }
  case TAG_SGlobal: {
    V v_g_243 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SGlobal = heff_take_reuse_n(v_v_241, 1ULL, 1);
    HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_ce_240, 0, 16); V a_1 = v_g_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_246;
        heff_drop(v_x_248);
        return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_RClo, 1, (V[]){v_g_243});
      } else {
        heff_drop(v_field_246);
        return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_RGetRaw, 1, (V[]){v_g_243});
      }
    }
  }
  case TAG_SInt: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFloat: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SStr: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SBytes: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFixed: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFloat32: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SPrimFn: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SLam: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_STag: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SRec: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SProj: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SPrim: {
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(a[0], a[1]);
}