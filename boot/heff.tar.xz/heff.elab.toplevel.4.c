// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_ArgEvidence 24309
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_ArmCovered 35323
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Become 65038
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_Get 18914
#define TAG_HGlobal 55847
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_INotationVar 46285
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_MkAbs 54862
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkEquation 38417
#define TAG_MkSt 48854
#define TAG_Nom 25944
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_Put 28059
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpId 35501
#define TAG_Throw 56084
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_globals 352931696
#define LBL_implicit 319715269
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_scrutinee 73860976
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_trace 311979359
#define LBL_tree 10063973
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_unreached 121683306
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace, LBL_unreached};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_co_2ebind_24s1464300710x102529052(V, V, V);
V g_co_2ebind_24s1464300710x102529052_entry(V self, V *a);
extern Clo g_co_2ebind_24s1464300710x102529052_clo;
V g_co_2ebind_24s196996678x1811735276(V, V, V);
V g_co_2ebind_24s196996678x1811735276_entry(V self, V *a);
extern Clo g_co_2ebind_24s196996678x1811735276_clo;
HeffT2 g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr(V, V, V, V);
V g_heff_2eelab_2eclauses_2efresh(V, V);
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efresh_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_clo;
V g_heff_2eelab_2eclauses_2eunreachedAlts(V);
V g_heff_2eelab_2eclauses_2eunreachedAlts_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eunreachedAlts_clo;
V g_heff_2eelab_2eenvironment_2eseeArms(V, V, V);
V g_heff_2eelab_2eenvironment_2eseeArms_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2eseeArms_clo;
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eprimitive_2ebasicPrims_get(void);
V g_heff_2eelab_2erules_2ecaseLet(V, V, V);
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseLet_clo;
V g_heff_2eelab_2erules_2esumElim(V, V, V, V);
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumElim_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_clo;
V g_heff_2eelab_2etoplevel_2eannotatesData(V);
V g_heff_2eelab_2etoplevel_2eannotatesData_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eannotatesData_clo;
V g_heff_2eelab_2etoplevel_2eappendM(V, V);
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24tok2(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24tok2_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24dps(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24dps_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_clo;
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void);
V g_heff_2eelab_2etoplevel_2ebodyPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo;
V g_heff_2eelab_2etoplevel_2echecksOnly(V);
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2econcatMapM(V, V);
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo;
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(V);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_clo;
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_clo;
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo;
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152(V);
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames(V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(V, V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
HeffT2 g_heff_2eelab_2etoplevel_2elamsOf_24cpr(V, V);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_clo;
V g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288_clo;
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_clo;
V g_heff_2eelab_2etoplevel_2enamedTwice(V, V);
V g_heff_2eelab_2etoplevel_2enamedTwice_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enamedTwice_clo;
V g_heff_2eelab_2etoplevel_2enamedTwice_24dps(V, V, V);
V g_heff_2eelab_2etoplevel_2enamedTwice_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enamedTwice_24dps_clo;
V g_heff_2eelab_2etoplevel_2eopPat(V, V);
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eopPat_clo;
V g_heff_2eelab_2etoplevel_2eparamsInOrder(V, V, V);
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo;
V g_heff_2eelab_2etoplevel_2eprimKnown(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTermF_clo;
V g_heff_2eelab_2etoplevel_2eselfTypeF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTypeF_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
HeffT2 g_heff_2eelab_2etoplevel_2eselfWalk_24cpr(V);
V g_heff_2eelab_2etoplevel_2etagSpans(V);
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpans_clo;
V g_heff_2eelab_2etoplevel_2ethawDone(V);
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawDone_clo;
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_clo;
HeffT2 g_heff_2eelab_2eunify_2ezonker_24cpr(V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2einfSpineOf_24cpr(V);
HeffT2 g_heff_2esyntax_2epresyntax_2epatSpineOf_24cpr(V);
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s347605591x806617237(V);
V g_list_2emap_24s347605591x806617237_entry(V self, V *a);
extern Clo g_list_2emap_24s347605591x806617237_clo;
V g_list_2emap_24s839307021x1449425912(V);
V g_list_2emap_24s839307021x1449425912_entry(V self, V *a);
extern Clo g_list_2emap_24s839307021x1449425912_clo;
V g_prelude_2etraverse_24s1099455515x1225465224(V, V, V);
V g_prelude_2etraverse_24s1099455515x1225465224_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1099455515x1225465224_clo;
V g_prelude_2etraverse_24s1157078602x1175067503(V, V, V);
V g_prelude_2etraverse_24s1157078602x1175067503_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1157078602x1175067503_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
HeffT2 g_prelude_2etraverse_24s24931311x762276985_24cpr(V);
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eselfTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfTypeF_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eselfTypeF(V v_r_240, V v_k_241, V v_d_242, V v_t_243) {
top: ;
  V v_el_244 = heff_take_field(v_r_240, 0);
  V v_ty_245 = heff_get_n(v_r_240, 1, 2);
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop(v_d_242);
    heff_drop(v_el_244);
    heff_drop(v_ty_245);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_247 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_ty_245);
    V v_t_248 = heff_tr(heff_call(v_el_244, 2, (V[]){v_d_242, v_e_247}));
    return heff_tag_at_n(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_248});
  }
  case TAG_SFunction: {
    V v_level_249 = heff_field(v_t_243, 0);
    V v_dom_2410 = heff_field(v_t_243, 1);
    V v_t3_2411 = heff_field(v_t_243, 2);
    V v_implicit_2412 = heff_field(v_t_243, 3);
    V v_dflt_2413 = heff_field(v_t_243, 4);
    V v_ru_24t_243_24SFunction = heff_take_reuse_n(v_t_243, 31ULL, 5);
    heff_drop(v_el_244);
    switch (heff_tag_of(v_t3_2411)) {
    case TAG_MkAbs: {
      V v_x_2414 = heff_field(v_t3_2411, 0);
      V v_b_2415 = heff_field(v_t3_2411, 1);
      V v_ru_24t3_2411_24MkAbs = heff_take_reuse_n(v_t3_2411, 3ULL, 2);
      V v_t_2416 = heff_tr(heff_call(heff_dup(v_ty_245), 2, (V[]){heff_dup(v_d_242), v_dom_2410}));
      V v_t_2417 = heff_tr(heff_call(v_ty_245, 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2415}));
      return heff_tag_re_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, 25ULL, (V[]){v_level_249, v_t_2416, heff_tag_re_n(v_ru_24t3_2411_24MkAbs, TAG_MkAbs, 2, 1ULL, (V[]){v_x_2414, v_t_2417}), v_implicit_2412, v_dflt_2413});
    }
    case TAG_AbsConst: {
      V v_b_2418 = heff_field(v_t3_2411, 0);
      V v_ru_24t3_2411_24AbsConst = heff_take_reuse_n(v_t3_2411, 1ULL, 1);
      V v_t_2419 = heff_tr(heff_call(heff_dup(v_ty_245), 2, (V[]){heff_dup(v_d_242), v_dom_2410}));
      V v_t_2420 = heff_tr(heff_call(v_ty_245, 2, (V[]){v_d_242, v_b_2418}));
      return heff_tag_re_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, 25ULL, (V[]){v_level_249, v_t_2419, heff_tag_at_n(v_ru_24t3_2411_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2420}), v_implicit_2412, v_dflt_2413});
    }
    default: return heff_nomatch(v_t3_2411);
    }
  }
  case TAG_SRecord: {
    V v_level_2421 = heff_field(v_t_243, 0);
    V v_ft_2422 = heff_field(v_t_243, 1);
    V v_ds_2423 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SRecord = heff_take_reuse_n(v_t_243, 7ULL, 3);
    heff_drop(v_el_244);
    V v_f_2424 = heff_tr(heff_call(v_ty_245, 1, (V[]){v_d_242}));
    V v_xs_2425 = heff_take_field(v_ft_2422, 2);
    V v_t_2428 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2425, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam0, 1, 2, (V[]){v_xs_2425, v_f_2424}));
    V v_t_2429 = ({ V rv_2 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_ft_2422, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_re_n(v_ru_24t_243_24SRecord, TAG_SRecord, 3, 5ULL, (V[]){v_level_2421, v_t_2429, v_ds_2423});
  }
  case TAG_SSum: {
    V v_vs_2430 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_el_244);
    V v_f_2431 = heff_tr(heff_call(v_ty_245, 1, (V[]){v_d_242}));
    V v_xs_2432 = heff_take_field(v_vs_2430, 2);
    V v_t_2437 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2432, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam1, 1, 2, (V[]){v_xs_2432, v_f_2431}));
    V v_t_2438 = ({ V rv_2 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_vs_2430, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2438});
  }
  case TAG_SIsTy: {
    V v_a_2439 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_el_244);
    V v_t_2440 = heff_tr(heff_call(v_ty_245, 2, (V[]){v_d_242, v_a_2439}));
    return heff_tag_at_n(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2440});
  }
  case TAG_SPrimInt: {
    heff_drop(v_d_242);
    heff_drop(v_el_244);
    heff_drop(v_ty_245);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop(v_d_242);
    heff_drop(v_el_244);
    heff_drop(v_ty_245);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop(v_d_242);
    heff_drop(v_el_244);
    heff_drop(v_ty_245);
    return v_t_243;
  }
  case TAG_SPrimRune: {
    heff_drop(v_d_242);
    heff_drop(v_el_244);
    heff_drop(v_ty_245);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    V v_a_2441 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SPrimArray = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_el_244);
    V v_t_2442 = heff_tr(heff_call(v_ty_245, 2, (V[]){v_d_242, v_a_2441}));
    return heff_tag_at_n(v_ru_24t_243_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2442});
  }
  case TAG_SFixed: {
    heff_drop(v_d_242);
    heff_drop(v_el_244);
    heff_drop(v_ty_245);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eselfTypeF(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam0(V self, V *args) {
  V v_i_2426 = args[0];
  V v_xs_2425 = heff_env(self)[0];
  V v_f_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_arrayIndex(v_xs_2425, v_i_2426);
  V f_ = v_f_2424;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam2(V self, V *args) {
  V v_i_2435 = args[0];
  V v_xs_2434 = heff_env(self)[0];
  V v_f_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_arrayIndex(v_xs_2434, v_i_2435);
  V f_ = v_f_2431;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam1(V self, V *args) {
  V v_i_2433 = args[0];
  V v_xs_2432 = heff_env(self)[0];
  V v_f_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2434 = heff_arrayIndex(v_xs_2432, v_i_2433);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2434, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam2, 1, 2, (V[]){v_xs_2434, v_f_2431}));
}
V g_heff_2eelab_2etoplevel_2eselfWalk_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfWalk_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2eelab_2etoplevel_2eselfWalk_24cpr(V v_k_240) {
top: ;
  return ((HeffT2){{heff_clo_n(g_heff_2eelab_2etoplevel_2eselfWalk_24cpr_lam0, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfWalk_24cpr_lam1, 2, 1, (V[]){heff_dup(v_k_240)})}});
}
V g_heff_2eelab_2etoplevel_2eselfWalk_24cpr_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_k_240 = heff_env(self)[0];
  V v_t_243 = (g_heff_2eelab_2etoplevel_2eselfWalk(v_k_240));
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_243; V a_1 = v_k_240; V a_2 = v_d_241; V a_3 = v_t_242; V r_ = (g_heff_2eelab_2etoplevel_2eselfTermF(a_0, a_1, a_2, a_3)); heff_drop(v_k_240); r_; });
}
V g_heff_2eelab_2etoplevel_2eselfWalk_24cpr_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_k_240 = heff_env(self)[0];
  V v_t_246 = (g_heff_2eelab_2etoplevel_2eselfWalk(v_k_240));
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_246; V a_1 = v_k_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2eselfTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_k_240); r_; });
}
Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echecksOnly_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echecksOnly(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_At: {
    V v_c1_241 = heff_field(v_c_240, 0);
    switch (heff_tag_of(v_c1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_c1_241, 0);
      HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2einfSpineOf_24cpr(heff_dup(v_i_243)));
      {
        V v_field_245 = v_t_244.f[0];
        heff_drop(v_t_244.f[1]);
        V v_t_247 = v_field_245;
        V v_t_2410;
        switch (heff_tag_of(v_t_247)) {
        case TAG_At: {
          V v_x_248 = heff_field(v_t_247, 0);
          heff_take_n(v_t_247, 1ULL, 2);
          v_t_2410 = v_x_248;
          break;
        }
        default: heff_nomatch(v_t_247);
        }
        switch (heff_tag_of(v_t_2410)) {
        case TAG_IVar: {
          heff_take_n(v_t_2410, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_INotationVar: {
          heff_take_n(v_t_2410, 0ULL, 3);
          return NTAG(TAG_False);
        }
        case TAG_IInt: {
          heff_take_n(v_t_2410, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_IFloat: {
          heff_take_n(v_t_2410, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_IString: {
          heff_take_n(v_t_2410, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_IBytes: {
          heff_take_n(v_t_2410, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_IPrim: {
          heff_take_n(v_t_2410, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_IRune: {
          heff_take_n(v_t_2410, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_IApp: {
          heff_take_n(v_t_2410, 0ULL, 2);
          return NTAG(TAG_False);
        }
        case TAG_IAnn: {
          heff_take_n(v_t_2410, 0ULL, 2);
          return NTAG(TAG_False);
        }
        case TAG_ISpec: {
          heff_take_n(v_t_2410, 0ULL, 4);
          return NTAG(TAG_False);
        }
        case TAG_IUpdate: {
          heff_take_n(v_t_2410, 0ULL, 2);
          return NTAG(TAG_False);
        }
        case TAG_IAnnLam: {
          heff_take_n(v_t_2410, 0ULL, 4);
          return NTAG(TAG_True);
        }
        case TAG_IInvalid: {
          heff_take_n(v_t_2410, 0ULL, 3);
          return NTAG(TAG_False);
        }
        case TAG_INominal: {
          heff_take_n(v_t_2410, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_ILitEq: {
          heff_take_n(v_t_2410, 0ULL, 4);
          return NTAG(TAG_False);
        }
        case TAG_ILazy: {
          heff_take_n(v_t_2410, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_ITuple: {
          heff_take_n(v_t_2410, 0ULL, 1);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_2410);
        }
      }
    }
    case TAG_CType: {
      return NTAG(TAG_False);
    }
    case TAG_CLam: {
      return NTAG(TAG_True);
    }
    case TAG_CImplicitLam: {
      return NTAG(TAG_True);
    }
    case TAG_CAnnLam: {
      return NTAG(TAG_True);
    }
    case TAG_CTag: {
      return NTAG(TAG_True);
    }
    case TAG_CStruct: {
      return NTAG(TAG_True);
    }
    case TAG_CMatch: {
      return NTAG(TAG_True);
    }
    case TAG_CLetIn: {
      return NTAG(TAG_True);
    }
    case TAG_CLocal: {
      return NTAG(TAG_True);
    }
    case TAG_CAbandon: {
      return NTAG(TAG_True);
    }
    case TAG_CNominal: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_c1_241);
    }
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2echecksOnly(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2enamedTwice_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2enamedTwice_str1, 30, "an arm above it is `_` already");
HEFF_LIT(g_heff_2eelab_2etoplevel_2enamedTwice_str2, 25, "an arm above it matches `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2enamedTwice_str3, 9, "` already");
Clo g_heff_2eelab_2etoplevel_2enamedTwice_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enamedTwice_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2enamedTwice(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_sp_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkPair = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_246 = (g_list_2eany_24s1006624359x760861690(v_x_244, v_seen_240));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_t_247;
        if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2etoplevel_2enamedTwice_str0), 2)) {
          heff_drop(v_x_244);
          v_t_247 = ((V)&g_heff_2eelab_2etoplevel_2enamedTwice_str1);
        } else {
          v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2enamedTwice_str2), v_x_244), ((V)&g_heff_2eelab_2etoplevel_2enamedTwice_str3));
        }
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24MkPair, TAG_ArmCovered, 2, (V[]){v_sp_245, v_t_247}), heff_hole()});
        V v_u_249 = (g_heff_2eelab_2etoplevel_2enamedTwice_24dps(v_seen_240, v_rest_243, v_cell_248));
        heff_drop(v_u_249);
        return v_cell_248;
      } else {
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x21_242_24MkPair, 2);
        heff_drop(v_t_246);
        V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_seen_240});
        V t_1 = v_rest_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2enamedTwice_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2enamedTwice(a[0], a[1]);
}

HeffT2 g_heff_2eelab_2etoplevel_2elamsOf_24cpr(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLocal: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SGlobal: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SCode: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SApp: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLam: {
    V v_x22_248 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    switch (heff_tag_of(v_x22_248)) {
    case TAG_MkAbs: {
      V v_b_2410 = heff_field(v_x22_248, 1);
      heff_take_n(v_x22_248, 2ULL, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_b_2410;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_AbsConst: {
      V v_b_2411 = heff_field(v_x22_248, 0);
      heff_take_n(v_x22_248, 1ULL, 1);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_b_2411;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x22_248)}});
    }
  }
  case TAG_SCons: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SProj: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_STag: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SMatch: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SSpecialize: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SIs: {
    V v_b_2422 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V t_0 = v_n_240;
    V t_1 = v_b_2422;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SAbandon: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SRec: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SFix: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SImplicit: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SPrim: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SMetaApp: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitInt: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitFloat: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitString: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitBytes: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitRune: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitFixed: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitFloat32: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eparamsInOrder_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eparamsInOrder(V v_k_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_i_241, v_k_240, 0));
    heff_drop(v_k_240);
    heff_drop(v_i_241);
    return v_ret_24bool;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_SLocal: {
      V v_j_245 = heff_field(v_x31_243, 0);
      V v_t_246 = heff_intSub_lent(heff_intSub_lent(v_k_240, MK_INT(1LL), 2), v_i_241, 1);
      if (heff_intEq_c_lent(v_j_245, v_t_246, 2)) {
        V t_0 = v_k_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_i_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_k_240);
        heff_drop(v_i_241);
        return NTAG(TAG_False);
      }
    }
    case TAG_SGlobal: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SCode: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SApp: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLam: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SCons: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SProj: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_STag: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SMatch: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SSpecialize: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SIs: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SOpaque: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SAbandon: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SFix: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SImplicit: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SPrim: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SMetaApp: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitInt: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitString: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitBytes: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitRune: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFixed: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat32: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eparamsInOrder(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_str0, 38, "an explicit argument was expected here");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_str1, 38, "an explicit argument was expected here");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_str2, 38, "an explicit argument was expected here");
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam4(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_ArgExplicit: {
      V v_c_243 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_m_244 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_243)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam0, 2, 3, (V[]){v_m_244, v_c_243, v_sp_242});
    }
    case TAG_ArgProject: {
      heff_take_n(v_x21_241, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam2, 2, 1, (V[]){v_sp_242});
    }
    case TAG_ArgNamed: {
      heff_take_n(v_x21_241, 0ULL, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam3, 2, 1, (V[]){v_sp_242});
    }
    case TAG_ArgEvidence: {
      heff_take_n(v_x21_241, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam4, 2, 1, (V[]){v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152(a[0]);
}
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_c_243, v_sp_242}), v_x_248});
  V f_ = v_k_246;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_m_244 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_244}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_247, v_hd_245, heff_clo_n(g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam1, 1, 3, (V[]){v_c_243, v_sp_242, v_k_246})));
}
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_malg_2413 = heff_take_field(v_hd_2411, 2);
  V v_bind_2414 = heff_get_n(v_hd_2411, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_str0), v_sp_242, NTAG(TAG_Nothing)});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(v_malg_2413, 1, (V[]){v_t_2417}));
  V f_ = v_bind_2414;
  args[0] = v_t_2418;
  args[1] = v_k2_2412;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_malg_2423 = heff_take_field(v_hd_2421, 2);
  V v_bind_2424 = heff_get_n(v_hd_2421, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_str1), v_sp_242, NTAG(TAG_Nothing)});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(v_malg_2423, 1, (V[]){v_t_2427}));
  V f_ = v_bind_2424;
  args[0] = v_t_2428;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_lam4(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k2_2431 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_malg_2432 = heff_take_field(v_hd_2430, 2);
  V v_bind_2433 = heff_get_n(v_hd_2430, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_str2), v_sp_242, NTAG(TAG_Nothing)});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(v_malg_2432, 1, (V[]){v_t_2436}));
  V f_ = v_bind_2433;
  args[0] = v_t_2437;
  args[1] = v_k2_2431;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_str2, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_str3, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam5(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkAlt: {
      V v_p_243 = heff_field(v_x21_241, 0);
      V v_body_244 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_p_245 = v_p_243;
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2epatSpineOf_24cpr(heff_dup(v_p_245)));
      {
        V v_field_247 = v_t_246.f[0];
        heff_drop(v_t_246.f[1]);
        V v_t_249 = v_field_247;
        V v_c_2447;
        switch (heff_tag_of(v_t_249)) {
        case TAG_At: {
          V v_it1_2410 = heff_field(v_t_249, 0);
          heff_take_n(v_t_249, 1ULL, 2);
          switch (heff_tag_of(v_it1_2410)) {
          case TAG_PatVar: {
            V v_it11_2412 = heff_field(v_it1_2410, 0);
            heff_take_n(v_it1_2410, 1ULL, 1);
            if (heff_strEq_c(v_it11_2412, ((V)&g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_str0))) {
              heff_drop(v_p_245);
              v_c_2447 = ((V)&g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0_clo);
            } else {
              v_c_2447 = heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1, 2, 1, (V[]){v_p_245});
            }
            break;
          }
          case TAG_PatTag: {
            V v_x_2427 = heff_field(v_it1_2410, 0);
            heff_take_n(v_it1_2410, 1ULL, 3);
            v_c_2447 = heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2, 2, 2, (V[]){v_p_245, v_x_2427});
            break;
          }
          default: {
            heff_drop(v_it1_2410);
            v_c_2447 = heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam4, 2, 1, (V[]){v_p_245});
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_t_249);
        }
        return heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam5, 2, 2, (V[]){v_c_2447, v_body_244});
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(a[0]);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_str1), NTAG(TAG_Nil)});
  V f_ = v_k_2414;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k2_2417 = args[1];
  V v_p_245 = heff_env(self)[0];
  V v_malg_2418 = heff_take_field(v_hd_2416, 2);
  V v_bind_2419 = heff_get_n(v_hd_2416, 1, 3);
  V v_t_2422;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_At: {
    V v_s_2421 = heff_field(v_p_245, 1);
    heff_take_n(v_p_245, 2ULL, 2);
    v_t_2422 = v_s_2421;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_str2), v_t_2422, NTAG(TAG_Nothing)});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(v_malg_2418, 1, (V[]){v_t_2425}));
  V f_ = v_bind_2419;
  args[0] = v_t_2426;
  args[1] = v_k2_2417;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2431 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2431;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2427, v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_p_245 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2432 = (g_heff_2esyntax_2epresyntax_2epatSpineOf_24cpr(v_p_245));
  {
    V v_field_2434 = v_t_2432.f[1];
    heff_drop(v_t_2432.f[0]);
    return (g_prelude_2etraverse_24s1157078602x1175067503(v_field_2434, v_hd_2430, heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam3, 1, 2, (V[]){v_k_2431, v_x_2427})));
  }
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam4(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k2_2437 = args[1];
  V v_p_245 = heff_env(self)[0];
  V v_malg_2438 = heff_take_field(v_hd_2436, 2);
  V v_bind_2439 = heff_get_n(v_hd_2436, 1, 3);
  V v_t_2442;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_At: {
    V v_s_2441 = heff_field(v_p_245, 1);
    heff_take_n(v_p_245, 2ULL, 2);
    v_t_2442 = v_s_2441;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_2443 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_str3), v_t_2442, NTAG(TAG_Nothing)});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tr(heff_call(v_malg_2438, 1, (V[]){v_t_2445}));
  V f_ = v_bind_2439;
  args[0] = v_t_2446;
  args[1] = v_k2_2437;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam7(V self, V *args) {
  V v_x_2455 = args[0];
  V v_xs_2452 = heff_env(self)[0];
  V v_k_2449 = heff_env(self)[1];
  V v_x_2451 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2456 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_xs_2452), v_x_2455});
  V f_ = v_k_2449;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2451, v_t_2456});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam6(V self, V *args) {
  V v_x_2450 = args[0];
  V v_body_244 = heff_env(self)[0];
  V v_hd_2448 = heff_env(self)[1];
  V v_k_2449 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x_2450, 0);
    V v_xs_2452 = heff_field(v_x_2450, 1);
    heff_take_n(v_x_2450, 3ULL, 2);
    heff_clo_take(self, 3);
    V v_m_2453 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_244));
    V v_t_2454 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_2453}));
    return (g_co_2ebind_24s196996678x1811735276(v_t_2454, v_hd_2448, heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam7, 1, 3, (V[]){v_xs_2452, v_k_2449, v_x_2451})));
  }
  default: return heff_nomatch(v_x_2450);
  }
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam5(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_c_2447 = heff_env(self)[0];
  V v_body_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2447;
  args[0] = heff_dup(v_hd_2448);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam6, 1, 3, (V[]){v_body_244, v_hd_2448, v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_str0, 2, "it");
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam4(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(V v_sp_240, V v_see_241, V v_scrutN_242, V v_casesN_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(v_casesN_243));
  if (((heff_dup(v_t_244) == NTAG(TAG_True)) && ({ V v_c_2451 = (g_heff_2eelab_2etoplevel_2eannotatesData(v_scrutN_242)); int c_ = !(heff_dup(v_c_2451) == NTAG(TAG_True)); heff_drop(v_c_2451); c_; }))) {
    heff_drop(v_t_244);
    V v_t_245 = (g_heff_2eelab_2etoplevel_2etagSpans(v_casesN_243));
    V v_t_246 = (g_heff_2eelab_2etoplevel_2enamedTwice(NTAG(TAG_Nil), v_t_245));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam0, 2, 5, (V[]){v_t_246, v_scrutN_242, v_casesN_243, v_see_241, v_sp_240});
  } else {
    heff_drop(v_t_244);
    HeffT2 v_t_2421 = (g_prelude_2etraverse_24s24931311x762276985_24cpr(heff_dup(v_casesN_243)));
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        heff_drop(v_sp_240);
        heff_drop(v_casesN_243);
        V v_e_2424 = v_field_2423;
        V v_span_2425 = heff_take_field(v_e_2424, 0);
        V v_msg_2426 = heff_get_n(v_e_2424, 1, 2);
        HEFF_LAST return g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(v_see_241, v_scrutN_242, v_span_2425, v_msg_2426);
      } else {
        V v_x_2427 = v_field_2423;
        V v_used_2428 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(v_x_2427, NTAG(TAG_Nil)));
        V v_t_2429 = (g_heff_2eelab_2eclauses_2efresh(v_used_2428, ((V)&g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_str0)));
        HeffT2 v_t_2430 = (g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr(v_sp_240, v_x_2427, v_used_2428, v_t_2429));
        {
          V v_field_2432 = v_t_2430.f[1];
          int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
          if ((v_tag_2431 == ((int64_t)0ULL))) {
            heff_drop(v_casesN_243);
            V v_err_2433 = v_field_2432;
            V v_span_2434 = heff_take_field(v_err_2433, 0);
            V v_msg_2435 = heff_get_n(v_err_2433, 1, 2);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(v_see_241, v_scrutN_242, v_span_2434, v_msg_2435);
          } else {
            V v_r_2436 = v_field_2432;
            V v_tree_2437 = heff_take_field(v_r_2436, 1);
            V v_scrutinee_2438 = heff_get_n(v_r_2436, 0, 2);
            V v_t_2439 = (g_heff_2eelab_2eclauses_2eunreachedAlts(v_casesN_243));
            V v_t_2440 = (g_list_2emap_24s839307021x1449425912(v_t_2439));
            return heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam4, 2, 5, (V[]){v_t_2440, v_scrutN_242, v_tree_2437, v_see_241, v_scrutinee_2438});
          }
        }
      }
    }
  }
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_see_241 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_casesN_243 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_t_2414;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_see_241)) {
  case TAG_Nothing: {
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_see_2413 = heff_field(v_see_241, 0);
    heff_take_n(v_see_241, 1ULL, 1);
    v_t_2414 = heff_tr(heff_call(v_see_2413, 1, (V[]){v_x_2411}));
    break;
  }
  default: heff_nomatch(v_see_241);
  }
  V v_t_2415 = ({ V a_0 = v_casesN_243; V r_ = (g_heff_2eelab_2etoplevel_2etagSpans(a_0)); heff_drop(v_casesN_243); r_; });
  V v_t_2416 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2412)));
  V v_t_2417 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2412));
  V v_t_2418 = (g_list_2emap_24s1173914895x100384474(v_x_2412));
  V v_t_2419 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2416), v_t_2417, heff_arrayFromList(v_t_2418)});
  V v_x_2420 = ({ V a_0 = v_sp_240; V a_1 = v_t_2414; V a_2 = v_t_2415; V a_3 = v_t_2419; V r_ = (g_heff_2eelab_2erules_2esumElim(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); heff_drop(v_t_2415); r_; });
  V f_ = v_k_248;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_casesN_243 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_see_241 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_prelude_2etraverse_24s1099455515x1225465224(heff_dup(v_casesN_243), v_hd_247, heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam3, 1, 5, (V[]){v_see_241, v_x_2411, v_casesN_243, v_sp_240, v_k_248})));
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_scrutN_242 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_casesN_243 = heff_env(self)[2];
  V v_see_241 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_drop(v_x_249);
  heff_clo_take(self, 6);
  V v_t_2410 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_242));
  V f_ = v_t_2410;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam2, 1, 5, (V[]){v_casesN_243, v_hd_247, v_see_241, v_sp_240, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_t_246 = heff_env(self)[0];
  V v_scrutN_242 = heff_env(self)[1];
  V v_casesN_243 = heff_env(self)[2];
  V v_see_241 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2eenvironment_2eseeArms(v_t_246, heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam1, 1, 6, (V[]){v_scrutN_242, v_hd_247, v_casesN_243, v_see_241, v_sp_240, v_k_248})));
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam7(V self, V *args) {
  V v_x_2447 = args[0];
  V v_see_241 = heff_env(self)[0];
  V v_x_2445 = heff_env(self)[1];
  V v_scrutinee_2438 = heff_env(self)[2];
  V v_k_2442 = heff_env(self)[3];
  V v_t_2449;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_see_241)) {
  case TAG_Nothing: {
    v_t_2449 = v_x_2445;
    break;
  }
  case TAG_Just: {
    V v_see_2448 = heff_field(v_see_241, 0);
    heff_take_n(v_see_241, 1ULL, 1);
    v_t_2449 = heff_tr(heff_call(v_see_2448, 1, (V[]){v_x_2445}));
    break;
  }
  default: heff_nomatch(v_see_241);
  }
  V v_x_2450 = ({ V a_0 = v_scrutinee_2438; V a_1 = v_t_2449; V a_2 = v_x_2447; V r_ = (g_heff_2eelab_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_t_2449); heff_drop(v_x_2447); r_; });
  V f_ = v_k_2442;
  args[0] = v_x_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_tree_2437 = heff_env(self)[0];
  V v_hd_2441 = heff_env(self)[1];
  V v_see_241 = heff_env(self)[2];
  V v_scrutinee_2438 = heff_env(self)[3];
  V v_k_2442 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2446 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_tree_2437));
  V f_ = v_t_2446;
  heff_room[0] = v_hd_2441;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam7, 1, 4, (V[]){v_see_241, v_x_2445, v_scrutinee_2438, v_k_2442});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_scrutN_242 = heff_env(self)[0];
  V v_hd_2441 = heff_env(self)[1];
  V v_tree_2437 = heff_env(self)[2];
  V v_see_241 = heff_env(self)[3];
  V v_scrutinee_2438 = heff_env(self)[4];
  V v_k_2442 = heff_env(self)[5];
  heff_drop(v_x_2443);
  heff_clo_take(self, 6);
  V v_t_2444 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_242));
  V f_ = v_t_2444;
  heff_room[0] = heff_dup(v_hd_2441);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam6, 1, 5, (V[]){v_tree_2437, v_hd_2441, v_see_241, v_scrutinee_2438, v_k_2442});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam4(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_t_2440 = heff_env(self)[0];
  V v_scrutN_242 = heff_env(self)[1];
  V v_tree_2437 = heff_env(self)[2];
  V v_see_241 = heff_env(self)[3];
  V v_scrutinee_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2eenvironment_2eseeArms(v_t_2440, heff_dup(v_hd_2441), heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam5, 1, 6, (V[]){v_scrutN_242, v_hd_2441, v_tree_2437, v_see_241, v_scrutinee_2438, v_k_2442})));
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(V v_f_240, V v_eqs_241, V v_sp_242, V v_z_243, V v_z_244) {
top: ;
  V v_x1_245 = (g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123(v_eqs_241));
  if (!(heff_dup(v_x1_245) == NTAG(TAG_True))) {
    heff_drop(v_z_243);
    heff_drop(v_x1_245);
    return heff_tail(v_z_244, 1, (V[]){heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0, 2, 3, (V[]){v_eqs_241, v_f_240, v_sp_242})})});
  } else {
    heff_drop(v_x1_245);
    HEFF_LAST return g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288(v_f_240, v_eqs_241, v_sp_242, v_z_243, v_z_244);
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2(V self, V *args) {
  V v_m_2415 = args[0];
  V v_e_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_246, 1, 8), v_m_2415));
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_f_2411 = heff_env(self)[0];
  V v_fsp_2412 = heff_env(self)[1];
  V v_rhs_2414 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_k_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_2411, v_fsp_2412, v_x_2419, v_rhs_2414}), v_sp_2410});
  V f_ = v_k_2418;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_f_2411 = heff_env(self)[1];
  V v_fsp_2412 = heff_env(self)[2];
  V v_rhs_2414 = heff_env(self)[3];
  V v_sp_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4, 1, 5, (V[]){v_f_2411, v_fsp_2412, v_rhs_2414, v_sp_2410, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1(V self, V *args) {
  V v_m_248 = args[0];
  V v_e_246 = heff_env(self)[0];
  switch (heff_tag_of(v_m_248)) {
  case TAG_At: {
    V v_x21_249 = heff_field(v_m_248, 0);
    V v_sp_2410 = heff_field(v_m_248, 1);
    heff_take_n(v_m_248, 3ULL, 2);
    switch (heff_tag_of(v_x21_249)) {
    case TAG_MkEquation: {
      V v_f_2411 = heff_field(v_x21_249, 0);
      V v_fsp_2412 = heff_field(v_x21_249, 1);
      V v_ps_2413 = heff_field(v_x21_249, 2);
      V v_rhs_2414 = heff_field(v_x21_249, 3);
      heff_take_n(v_x21_249, 15ULL, 4);
      heff_clo_take(self, 1);
      V v_c_2416 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2, 1, 1, (V[]){v_e_246}), v_ps_2413));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3, 2, 5, (V[]){v_c_2416, v_f_2411, v_fsp_2412, v_rhs_2414, v_sp_2410});
    }
    default: return heff_nomatch(v_x21_249);
    }
  }
  default: return heff_nomatch(v_m_248);
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_e_246 = heff_env(self)[0];
  V v_a_247 = heff_env(self)[1];
  V v_hd_2422 = heff_env(self)[2];
  V v_k_2423 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2425)) {
  case TAG_MkChk: {
    V v_f_2426 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 1);
    heff_clo_take(self, 4);
    V f_ = v_f_2426;
    heff_room[0] = v_e_246;
    heff_room[1] = v_a_247;
    heff_room[2] = v_hd_2422;
    heff_room[3] = v_k_2423;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_hd_2422 = heff_env(self)[2];
  V v_e_246 = heff_env(self)[3];
  V v_a_247 = heff_env(self)[4];
  V v_k_2423 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288(v_f_240, v_x_2424, v_sp_242, heff_dup(v_hd_2422), heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7, 1, 4, (V[]){v_e_246, v_a_247, v_hd_2422, v_k_2423})));
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_e_246 = heff_env(self)[3];
  V v_a_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6, 1, 6, (V[]){v_f_240, v_sp_242, v_hd_2422, v_e_246, v_a_247, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0(V self, V *args) {
  V v_e_246 = args[0];
  V v_a_247 = args[1];
  V v_eqs_241 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2421 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1, 1, 1, (V[]){heff_dup(v_e_246)}), v_eqs_241));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5, 2, 5, (V[]){v_c_2421, v_f_240, v_sp_242, v_e_246, v_a_247});
}
Clo g_heff_2eelab_2etoplevel_2eexplicitNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eexplicitNames_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eexplicitNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ab_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_implicit_243 = heff_take_field(v_ab_241, 3);
    V v_name_244 = heff_get_n(v_ab_241, 1, 4);
    V v_t_245 = v_implicit_243;
    switch (heff_tag_of(v_t_245)) {
    case TAG_Expl: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_name_244, heff_hole()});
      V v_u_247 = (g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(v_rest_242, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    case TAG_Impl: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_244);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Inst: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_244);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eexplicitNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eexplicitNames(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2econcatMapM_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2econcatMapM(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2etoplevel_2econcatMapM(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2etoplevel_2eappendM(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2econcatMapM(a[0], a1); heff_drop(a1); return r;
}

static V g_heff_2eelab_2etoplevel_2ebasicPrimNames_val;
static HEFF_ONCE g_heff_2eelab_2etoplevel_2ebasicPrimNames_st;
static V g_heff_2eelab_2etoplevel_2ebasicPrimNames_init(void) {
  return (g_list_2emap_24s347605591x806617237(heff_dup(g_heff_2eelab_2eprimitive_2ebasicPrims_get())));
}
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2etoplevel_2ebasicPrimNames_st)) return g_heff_2eelab_2etoplevel_2ebasicPrimNames_val;
  return heff_global(&g_heff_2eelab_2etoplevel_2ebasicPrimNames_val, &g_heff_2eelab_2etoplevel_2ebasicPrimNames_st, g_heff_2eelab_2etoplevel_2ebasicPrimNames_init);
}
Clo g_heff_2eelab_2etoplevel_2eappendT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eappendT(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2etoplevel_2eappendT_24dps(v_xs_243, v_ys_241, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendT(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eappendT_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_24dps_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappendT_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_u_246;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eappendT_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(V v_g_240, V v_n_241, V v_d_242, V v_a_243, V v_p_244) {
top: ;
  V v_val_245 = heff_take_field(v_a_243, 1);
  V v_stx_246 = heff_get_n(v_a_243, 0, 2);
  V v_c_2410;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkSt: {
    V v_c_247 = heff_dup(heff_field(v_p_244, 0));
    v_c_2410 = v_c_247;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2411 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2412;
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_t_2411);
    v_t_2412 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_2411);
    v_t_2412 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_t_2413 = ({ V rv_7 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2412}); V rr_ = heff_rec_reuse_nf(v_c_2410, 383ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  V v_t_2416;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2415 = heff_field(v_n_241, 1);
    v_t_2416 = heff_dup(v_s_2415);
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_t_2417 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2418;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_t_2417);
    v_t_2418 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_2417);
    v_t_2418 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_t_2419 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2420;
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_t_2419);
    v_t_2420 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_2419);
    v_t_2420 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_t_2426 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_t_2420}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam0, 1, 1, (V[]){heff_dup(v_val_245)}), NTAG(TAG_Nothing)));
  V v_x1_2427 = heff_tr(heff_call(heff_dup(v_val_245), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2431;
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_Nom: {
    V v_x_2428 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 1);
    v_t_2431 = v_x_2428;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2427, 0ULL, 1);
    v_t_2431 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2430 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 1);
    v_t_2431 = v_x_2430;
    break;
  }
  default: heff_nomatch(v_x1_2427);
  }
  V v_t_2432 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SOpaque), heff_dup(v_stx_246), v_t_2426, v_t_2431});
  V v_t_2433 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_2418, v_t_2432, heff_dup(v_g_240)));
  V v_t_2434 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2435;
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_drop(v_t_2434);
    v_t_2435 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_2434);
    v_t_2435 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_x1_2436 = heff_tr(heff_call(v_val_245, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2440;
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_Nom: {
    V v_x_2437 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    v_t_2440 = v_x_2437;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2436, 0ULL, 1);
    v_t_2440 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2439 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    v_t_2440 = v_x_2439;
    break;
  }
  default: heff_nomatch(v_x1_2436);
  }
  V v_t_2441 = (g_heff_2eelab_2etoplevel_2ebodyPhase(v_t_2416, heff_dup(v_d_242), v_t_2433, v_t_2435, v_t_2440));
  V v_t_2442 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_t_2441}));
  V v_t_2446;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkSt: {
    V v_d_2444 = heff_field(v_p_244, 1);
    V v_w_2445 = heff_field(v_p_244, 2);
    V v_ru_24p_244_24MkSt = heff_take_reuse_n(v_p_244, 6ULL, 3);
    v_t_2446 = heff_tag_re_n(v_ru_24p_244_24MkSt, TAG_MkSt, 3, 6ULL, (V[]){v_t_2413, v_d_2444, v_w_2445});
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  return (g_co_2ebind_24s1464300710x102529052(v_t_2442, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam1, 3, 4, (V[]){heff_dup(v_n_241), v_d_242, v_stx_246, v_g_240}), v_t_2446));
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam0(V self, V *args) {
  V v_u_2421 = args[0];
  V v_val_245 = heff_env(self)[0];
  heff_drop(v_u_2421);
  heff_clo_take(self, 1);
  V v_x1_2422 = heff_tr(heff_call(v_val_245, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    return v_x_2423;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    return v_x_2425;
  }
  default: return heff_nomatch(v_x1_2422);
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2(V self, V *args) {
  V v_c_2450 = args[0];
  return ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_c_2450, 383ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6(V self, V *args) {
  V v_c_2463 = args[0];
  return heff_get_n(v_c_2463, 3, 9);
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam7(V self, V *args) {
  V v_x_2467 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_stx_246 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_body_2447 = heff_env(self)[4];
  V v_hd_2448 = heff_env(self)[5];
  V v_k_2449 = heff_env(self)[6];
  V v_t_2490;
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_2468 = heff_field(v_n_241, 0);
    heff_take_n(v_n_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_2468)) {
    case TAG_DeclEquations: {
      V v_x113_2472 = heff_field(v_x11_2468, 2);
      heff_take_n(v_x11_2468, 4ULL, 5);
      switch (heff_tag_of(v_x113_2472)) {
      case TAG_AsDefinition: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_AsInstance: {
        v_t_2490 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x113_2472);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2468, 0ULL, 5);
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2468, 0ULL, 4);
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2468, 0ULL, 3);
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2468, 0ULL, 2);
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2468, 0ULL, 1);
      v_t_2490 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2468);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  HeffT2 v_t_2491 = (g_heff_2eelab_2eunify_2ezonker_24cpr(v_x_2467));
  {
    V v_field_2493 = v_t_2491.f[1];
    heff_drop(v_t_2491.f[0]);
    V v_t_2494 = heff_tr(heff_call(v_field_2493, 1, (V[]){v_stx_246}));
    return ({ V a_0 = v_g_240; V a_1 = v_d_242; V a_2 = v_t_2490; V a_3 = v_t_2494; V a_4 = v_x_2467; V a_5 = v_body_2447; V a_6 = v_hd_2448; V a_7 = v_k_2449; V r_ = (g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2467); heff_drop_rec(v_hd_2448, 3); r_; });
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam5(V self, V *args) {
  V v_x_2462 = args[0];
  V v_hd_2448 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_stx_246 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_body_2447 = heff_env(self)[5];
  V v_k_2449 = heff_env(self)[6];
  heff_drop(v_x_2462);
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6_clo)})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2448, 2)), 1, (V[]){v_t_2465}));
  heff_clo_take(self, 7);
  V f_ = heff_dup(heff_rfield(v_hd_2448, 1));
  heff_room[0] = v_t_2466;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam7, 1, 7, (V[]){v_n_241, v_stx_246, v_g_240, v_d_242, v_body_2447, v_hd_2448, v_k_2449});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam4(V self, V *args) {
  V v_x_2458 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_hd_2448 = heff_env(self)[2];
  V v_stx_246 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_body_2447 = heff_env(self)[5];
  V v_k_2449 = heff_env(self)[6];
  heff_drop(v_x_2458);
  V v_t_2461;
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2460 = heff_dup(heff_field(v_n_241, 1));
    v_t_2461 = v_s_2460;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  return (g_heff_2eelab_2etoplevel_2eprimKnown(v_t_2461, heff_dup(v_d_242), heff_dup(v_hd_2448), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam5, 1, 7, (V[]){v_hd_2448, v_n_241, v_stx_246, v_g_240, v_d_242, v_body_2447, v_k_2449})));
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam3(V self, V *args) {
  V v_x_2454 = args[0];
  V v_hd_2448 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_stx_246 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_body_2447 = heff_env(self)[5];
  V v_k_2449 = heff_env(self)[6];
  V v_t_2455 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2454, NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2448, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})}));
  heff_clo_take(self, 7);
  V f_ = heff_dup(heff_rfield(v_hd_2448, 1));
  heff_room[0] = v_t_2457;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam4, 1, 7, (V[]){v_n_241, v_d_242, v_hd_2448, v_stx_246, v_g_240, v_body_2447, v_k_2449});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam1(V self, V *args) {
  V v_body_2447 = args[0];
  V v_hd_2448 = args[1];
  V v_k_2449 = args[2];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_stx_246 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2_clo)})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2448, 2)), 1, (V[]){v_t_2452}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_2448, 1));
  args[0] = v_t_2453;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam3, 1, 7, (V[]){v_hd_2448, v_n_241, v_d_242, v_stx_246, v_g_240, v_body_2447, v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2ethawDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawDone_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ethawDone(V v_acc_240) {
top: ;
  V v_keys_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 2)));
  V v_broken_242 = heff_take_field(v_acc_240, 3);
  V v_watches_243 = heff_take_field(v_acc_240, 4);
  V v_tests_244 = heff_take_field(v_acc_240, 5);
  V v_spans_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 6)));
  V v_infos_246 = heff_take_field(v_acc_240, 7);
  V v_trace_247 = heff_take_field(v_acc_240, 8);
  V v_unreached_248 = heff_take_field(v_acc_240, 9);
  return ({ V rv_2 = v_keys_241; V rv_3 = v_broken_242; V rv_4 = v_watches_243; V rv_5 = v_tests_244; V rv_6 = v_spans_245; V rv_7 = v_infos_246; V rv_8 = v_trace_247; V rv_9 = v_unreached_248; V rr_ = heff_rec_reuse_nf(v_acc_240, 3ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawDone(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(V v_ys_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(v_ys_240, v_f_241, v_xs_244, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(a[0], a[1], a[2]);
}