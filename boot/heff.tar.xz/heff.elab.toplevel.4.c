// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Become 65038
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HGlobal 55847
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_MkAbs 54862
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkEquation 38417
#define TAG_MkSt 48854
#define TAG_MkTyp 8305
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Throw 56084
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_globals 352931696
#define LBL_head 9693863
#define LBL_hidden 729654485
#define LBL_implicit 319715269
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_level 304224158
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_scrutinee 73860976
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_tree 10063973
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_key__module[] = {LBL_key, LBL_module};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_name__level[] = {LBL_name, LBL_level};
static uint32_t shape_name__ty__tm__prim[] = {LBL_name, LBL_ty, LBL_tm, LBL_prim};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_co_2ebind_24s2023162438x1917167210(V, V, V);
V g_co_2ebind_24s2023162438x1917167210_entry(V self, V *a);
extern Clo g_co_2ebind_24s2023162438x1917167210_clo;
V g_co_2ebind_24s591410632x427349444(V, V, V);
V g_co_2ebind_24s591410632x427349444_entry(V self, V *a);
extern Clo g_co_2ebind_24s591410632x427349444_clo;
V g_heff_2ecompile_2eprims_2ebasicPrims_get(void);
HeffT2 g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr(V, V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2edesugar_24cpr(V, V, V, V);
V g_heff_2eelab_2eclauses_2efresh(V, V);
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efresh_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_clo;
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2emeta_2esettleGo(V, V, V, V);
V g_heff_2eelab_2emeta_2esettleGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2esettleGo_clo;
V g_heff_2eelab_2erules_2ecaseLet(V, V, V);
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseLet_clo;
V g_heff_2eelab_2erules_2esumElim(V, V, V, V);
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumElim_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604_clo;
V g_heff_2eelab_2etoplevel_2eannotatesData(V);
V g_heff_2eelab_2etoplevel_2eannotatesData_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eannotatesData_clo;
V g_heff_2eelab_2etoplevel_2eappendM(V, V);
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24dps(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24dps_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_clo;
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void);
V g_heff_2eelab_2etoplevel_2ebodyPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo;
V g_heff_2eelab_2etoplevel_2echeckStuck(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo;
V g_heff_2eelab_2etoplevel_2echeckUnsolved(V, V, V);
V g_heff_2eelab_2etoplevel_2echeckUnsolved_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckUnsolved_clo;
V g_heff_2eelab_2etoplevel_2echecksOnly(V);
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2echkHeadOf(V, V);
V g_heff_2eelab_2etoplevel_2echkHeadOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkHeadOf_clo;
HeffT1 g_heff_2eelab_2etoplevel_2echkHeadOf_24cpr(V, V);
V g_heff_2eelab_2etoplevel_2econcatMapM(V, V);
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo;
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(V);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_clo;
V g_heff_2eelab_2etoplevel_2edoPat(V);
V g_heff_2eelab_2etoplevel_2edoPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoPat_clo;
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_clo;
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo;
V g_heff_2eelab_2etoplevel_2eequationsBody(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsBody_clo;
V g_heff_2eelab_2etoplevel_2eequationsD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsD_clo;
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames(V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(V, V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
HeffT2 g_heff_2eelab_2etoplevel_2elamsOf_24cpr(V, V);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(V, V, V);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_clo;
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_clo;
V g_heff_2eelab_2etoplevel_2enominalTyp(V);
V g_heff_2eelab_2etoplevel_2enominalTyp_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalTyp_clo;
V g_heff_2eelab_2etoplevel_2eopPat(V, V);
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eopPat_clo;
V g_heff_2eelab_2etoplevel_2eparamsInOrder(V, V, V);
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo;
V g_heff_2eelab_2etoplevel_2epoisonedLeft(V, V);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo;
V g_heff_2eelab_2etoplevel_2eprimKnown(V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2esearchedInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2esearchedInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2esearchedInstance_clo;
V g_heff_2eelab_2etoplevel_2eselfTypeF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTypeF_clo;
V g_heff_2eelab_2etoplevel_2etagSpans(V);
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpans_clo;
V g_heff_2eelab_2etoplevel_2ethawDone(V);
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawDone_clo;
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2ewatchEntry(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo;
V g_heff_2eelab_2etoplevel_2ewatchPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchPhase_clo;
V g_heff_2eelab_2etoplevel_2ewithArgs(V, V);
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo;
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720(V, V);
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_clo;
V g_heff_2esyntax_2epresyntax_2einfSpineOf(V);
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s522699319x1190492156(V, V);
V g_list_2ekeepIf_24s522699319x1190492156_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s522699319x1190492156_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2etraverse_24s1099455515x1225465224(V);
V g_prelude_2etraverse_24s1099455515x1225465224_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1099455515x1225465224_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
HeffT2 g_prelude_2etraverse_24s24931311x762276985_24cpr(V);
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eselfTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfTypeF_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eselfTypeF(V v_r_240, V v_k_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_245}));
    return heff_tag_at_n(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_246});
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_t_243, 0);
    V v_dom_248 = heff_field(v_t_243, 1);
    V v_t3_249 = heff_field(v_t_243, 2);
    V v_implicit_2410 = heff_field(v_t_243, 3);
    V v_dflt_2411 = heff_field(v_t_243, 4);
    V v_ru_24t_243_24SFunction = heff_take_reuse_n(v_t_243, 31ULL, 5);
    switch (heff_tag_of(v_t3_249)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_t3_249, 0);
      V v_b_2413 = heff_field(v_t3_249, 1);
      heff_take_n(v_t3_249, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2413}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2414, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2412, v_t_2415}), v_implicit_2410, v_dflt_2411});
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_t3_249, 0);
      heff_take_n(v_t3_249, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_b_2416}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2417, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2418}), v_implicit_2410, v_dflt_2411});
    }
    default: return heff_nomatch(v_t3_249);
    }
  }
  case TAG_SRecord: {
    V v_level_2419 = heff_field(v_t_243, 0);
    V v_ft_2420 = heff_field(v_t_243, 1);
    V v_ds_2421 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SRecord = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_f_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_d_242}));
    V v_xs_2423 = heff_take_field(v_ft_2420, 2);
    V v_t_2426 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2423, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam0, 1, 2, (V[]){v_xs_2423, v_f_2422}));
    V v_t_2427 = ({ V rv_2 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_ft_2420, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SRecord, TAG_SRecord, 3, (V[]){v_level_2419, v_t_2427, v_ds_2421});
  }
  case TAG_SSum: {
    V v_vs_2428 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2429 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_d_242}));
    V v_xs_2430 = heff_take_field(v_vs_2428, 2);
    V v_t_2435 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2430, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam1, 1, 2, (V[]){v_xs_2430, v_f_2429}));
    V v_t_2436 = ({ V rv_2 = v_t_2435; V rr_ = heff_rec_reuse_nf(v_vs_2428, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2436});
  }
  case TAG_SIsTy: {
    V v_a_2437 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_2437}));
    return heff_tag_at_n(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2438});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    V v_a_2439 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SPrimArray = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_2439}));
    return heff_tag_at_n(v_ru_24t_243_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2440});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eselfTypeF(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam0(V self, V *args) {
  V v_i_2424 = args[0];
  V v_xs_2423 = heff_env(self)[0];
  V v_f_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_arrayIndex(v_xs_2423, v_i_2424);
  V f_ = v_f_2422;
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam2(V self, V *args) {
  V v_i_2433 = args[0];
  V v_xs_2432 = heff_env(self)[0];
  V v_f_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_arrayIndex(v_xs_2432, v_i_2433);
  V f_ = v_f_2429;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam1(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  V v_f_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2432, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam2, 1, 2, (V[]){v_xs_2432, v_f_2429}));
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalTyp_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalTyp_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalTyp_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalTyp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalTyp_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalTyp(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam0, 1, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalTyp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2enominalTyp(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam3(V self, V *args) {
  V v_u_249 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  V v_x1_2410 = heff_tr(heff_call(heff_get_n(v_x_247, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2414;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2410, 0ULL, 1);
    v_t_2414 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2414});
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_SIsTy, 1, (V[]){heff_dup(heff_rfield(v_x_247, 0))});
  V f_ = v_k_246;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam3, 1, 1, (V[]){v_x_247})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam2, 1, 1, (V[]){v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_244;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkTyp: {
    V v_f_242 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_243 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_241, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_244 = heff_tr(heff_call(v_f_242, 1, (V[]){v_t_243}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam1, 2, 1, (V[]){v_c_244});
}
Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echecksOnly_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echecksOnly(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_At: {
    V v_c1_241 = heff_field(v_c_240, 0);
    switch (heff_tag_of(v_c1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_c1_241, 0);
      V v_t_244 = (g_heff_2esyntax_2epresyntax_2einfSpineOf(heff_dup(v_i_243)));
      V v_t_245 = heff_get_n(v_t_244, 0, 2);
      V v_t_248;
      switch (heff_tag_of(v_t_245)) {
      case TAG_At: {
        V v_x_246 = heff_field(v_t_245, 0);
        heff_take_n(v_t_245, 1ULL, 2);
        v_t_248 = v_x_246;
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      switch (heff_tag_of(v_t_248)) {
      case TAG_IVar: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IInt: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IFloat: {
        heff_take_na(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IString: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IBytes: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IPrim: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IRune: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IApp: {
        heff_take_n(v_t_248, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_IAnn: {
        heff_take_n(v_t_248, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_ISpec: {
        heff_take_n(v_t_248, 0ULL, 4);
        return NTAG(TAG_False);
      }
      case TAG_IUpdate: {
        heff_take_n(v_t_248, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_IAnnLam: {
        heff_take_n(v_t_248, 0ULL, 4);
        return NTAG(TAG_True);
      }
      case TAG_IInvalid: {
        heff_take_n(v_t_248, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_INominal: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_ILitEq: {
        heff_take_n(v_t_248, 0ULL, 4);
        return NTAG(TAG_False);
      }
      case TAG_ILazy: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_ITuple: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    case TAG_CType: {
      return NTAG(TAG_False);
    }
    case TAG_CLam: {
      return NTAG(TAG_True);
    }
    case TAG_CImplicitLam: {
      return NTAG(TAG_True);
    }
    case TAG_CAnnLam: {
      return NTAG(TAG_True);
    }
    case TAG_CTag: {
      return NTAG(TAG_True);
    }
    case TAG_CStruct: {
      return NTAG(TAG_True);
    }
    case TAG_CMatch: {
      return NTAG(TAG_True);
    }
    case TAG_CLetIn: {
      return NTAG(TAG_True);
    }
    case TAG_CLocal: {
      return NTAG(TAG_True);
    }
    case TAG_CAbandon: {
      return NTAG(TAG_True);
    }
    case TAG_CNominal: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_c1_241);
    }
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2echecksOnly(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2eelab_2etoplevel_2elamsOf_24cpr(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLocal: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SGlobal: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SCode: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SApp: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLam: {
    V v_x22_248 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    switch (heff_tag_of(v_x22_248)) {
    case TAG_MkAbs: {
      V v_b_2410 = heff_field(v_x22_248, 1);
      heff_take_n(v_x22_248, 2ULL, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_b_2410;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_AbsConst: {
      V v_b_2411 = heff_field(v_x22_248, 0);
      heff_take_n(v_x22_248, 1ULL, 1);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_b_2411;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x22_248)}});
    }
  }
  case TAG_SCons: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SProj: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_STag: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SMatch: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SSpecialize: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SIs: {
    V v_b_2422 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V t_0 = v_n_240;
    V t_1 = v_b_2422;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SAbandon: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SRec: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SFix: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SImplicit: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SPrim: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SMetaApp: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitInt: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitFloat: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitString: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitBytes: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitRune: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitFixed: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitFloat32: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eparamsInOrder_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eparamsInOrder(V v_k_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_intEq(v_i_241, v_k_240);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_SLocal: {
      V v_j_245 = heff_field(v_x31_243, 0);
      V v_t_246 = heff_intSub(heff_intSub(heff_dup(v_k_240), MK_INT(1LL)), heff_dup(v_i_241));
      if (heff_intEq_c_lent(v_j_245, v_t_246, 2)) {
        V t_0 = v_k_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_i_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_k_240);
        heff_drop(v_i_241);
        return NTAG(TAG_False);
      }
    }
    case TAG_SGlobal: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SCode: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SApp: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLam: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SCons: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SProj: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_STag: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SMatch: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SSpecialize: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SIs: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SOpaque: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SAbandon: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SFix: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SImplicit: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SPrim: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SMetaApp: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitInt: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitString: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitBytes: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitRune: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFixed: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat32: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eparamsInOrder(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2echkHeadOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkHeadOf_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2echkHeadOf(V v_n_240, V v_j_241) {
top: ;
  HeffT1 v_t_242 = (g_heff_2eelab_2etoplevel_2echkHeadOf_24cpr(v_n_240, v_j_241));
  {
    V v_field_243 = v_t_242.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_243});
  }
}
V g_heff_2eelab_2etoplevel_2echkHeadOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2echkHeadOf(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkAlt: {
      V v_p_243 = heff_field(v_x21_241, 0);
      V v_body_244 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_c_245 = (g_heff_2eelab_2etoplevel_2edoPat(v_p_243));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0, 2, 2, (V[]){v_c_245, v_body_244});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(a[0]);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_xs_2410 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_xs_2410), v_x_2412});
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_t_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_body_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x_248, 0);
    V v_xs_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2411 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_244));
    return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2411, v_hd_246, heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2, 1, 3, (V[]){v_xs_2410, v_k_247, v_x_249})));
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_body_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1, 1, 3, (V[]){v_body_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_str0, 2, "it");
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam3(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(V v_sp_240, V v_see_241, V v_scrutN_242, V v_casesN_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(v_casesN_243));
  V v_t_246 = heff_bool(((heff_dup(v_t_244) == NTAG(TAG_True)) && ({ V v_t_245 = (g_heff_2eelab_2etoplevel_2eannotatesData(v_scrutN_242)); int c_ = !(heff_dup(v_t_245) == NTAG(TAG_True)); heff_drop(v_t_245); c_; })));
  heff_drop(v_t_244);
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_c_247 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_242));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam0, 2, 4, (V[]){v_c_247, v_casesN_243, v_see_241, v_sp_240});
  } else {
    heff_drop(v_t_246);
    HeffT2 v_t_2421 = (g_prelude_2etraverse_24s24931311x762276985_24cpr(v_casesN_243));
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        heff_drop(v_sp_240);
        V v_e_2425 = v_field_2423;
        HEFF_LAST return g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(v_see_241, v_scrutN_242, heff_dup(heff_rfield(v_e_2425, 0)), heff_get_n(v_e_2425, 1, 2));
      } else {
        V v_x_2426 = v_field_2423;
        V v_used_2427 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(v_x_2426, NTAG(TAG_Nil)));
        V v_t_2428 = (g_heff_2eelab_2eclauses_2efresh(v_used_2427, ((V)&g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_str0)));
        HeffT2 v_t_2429 = (g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr(v_sp_240, v_x_2426, v_used_2427, v_t_2428));
        {
          V v_field_2431 = v_t_2429.f[1];
          int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
          if ((v_tag_2430 == ((int64_t)0ULL))) {
            V v_err_2433 = v_field_2431;
            HEFF_LAST return g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(v_see_241, v_scrutN_242, heff_dup(heff_rfield(v_err_2433, 0)), heff_get_n(v_err_2433, 1, 2));
          } else {
            V v_r_2434 = v_field_2431;
            V v_c_2435 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_242));
            return heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam3, 2, 3, (V[]){v_c_2435, v_r_2434, v_see_241});
          }
        }
      }
    }
  }
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_see_241 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_casesN_243 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414;
  switch (heff_tag_of(v_see_241)) {
  case TAG_Nothing: {
    v_t_2414 = v_x_2410;
    break;
  }
  case TAG_Just: {
    V v_see_2413 = heff_field(v_see_241, 0);
    heff_take_n(v_see_241, 1ULL, 1);
    v_t_2414 = heff_tr(heff_call(v_see_2413, 1, (V[]){v_x_2410}));
    break;
  }
  default: heff_nomatch(v_see_241);
  }
  V v_t_2415 = (g_heff_2eelab_2etoplevel_2etagSpans(v_casesN_243));
  V v_t_2416 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2412)));
  V v_t_2417 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2412));
  V v_t_2418 = (g_list_2emap_24s1173914895x100384474(v_x_2412));
  V v_t_2419 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2416), v_t_2417, heff_arrayFromList(v_t_2418)});
  V v_x_2420 = ({ V a_0 = v_sp_240; V a_1 = v_t_2414; V a_2 = v_t_2415; V a_3 = v_t_2419; V r_ = (g_heff_2eelab_2erules_2esumElim(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); heff_drop(v_t_2415); r_; });
  V f_ = v_k_249;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_casesN_243 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_see_241 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = (g_prelude_2etraverse_24s1099455515x1225465224(heff_dup(v_casesN_243)));
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam2, 1, 5, (V[]){v_see_241, v_x_2410, v_casesN_243, v_sp_240, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_casesN_243 = heff_env(self)[1];
  V v_see_241 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam1, 1, 5, (V[]){v_casesN_243, v_hd_248, v_see_241, v_sp_240, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam5(V self, V *args) {
  V v_x_2440 = args[0];
  V v_see_241 = heff_env(self)[0];
  V v_x_2438 = heff_env(self)[1];
  V v_r_2434 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2442;
  switch (heff_tag_of(v_see_241)) {
  case TAG_Nothing: {
    v_t_2442 = v_x_2438;
    break;
  }
  case TAG_Just: {
    V v_see_2441 = heff_field(v_see_241, 0);
    heff_take_n(v_see_241, 1ULL, 1);
    v_t_2442 = heff_tr(heff_call(v_see_2441, 1, (V[]){v_x_2438}));
    break;
  }
  default: heff_nomatch(v_see_241);
  }
  V v_x_2443 = ({ V a_0 = heff_get_n(v_r_2434, 0, 2); V a_1 = v_t_2442; V a_2 = v_x_2440; V r_ = (g_heff_2eelab_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_t_2442); heff_drop(v_x_2440); r_; });
  V f_ = v_k_2437;
  args[0] = v_x_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_r_2434 = heff_env(self)[0];
  V v_hd_2436 = heff_env(self)[1];
  V v_see_241 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2439 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(heff_rfield(v_r_2434, 1))));
  V f_ = v_c_2439;
  heff_room[0] = v_hd_2436;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam5, 1, 4, (V[]){v_see_241, v_x_2438, v_r_2434, v_k_2437});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam3(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_r_2434 = heff_env(self)[1];
  V v_see_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2435;
  args[0] = heff_dup(v_hd_2436);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_lam4, 1, 4, (V[]){v_r_2434, v_hd_2436, v_see_241, v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(V v_f_240, V v_eqs_241, V v_sp_242) {
top: ;
  V v_x1_243 = (g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604(v_eqs_241));
  if ((heff_dup(v_x1_243) == NTAG(TAG_True))) {
    heff_drop(v_x1_243);
    HeffT2 v_t_244 = (g_heff_2eelab_2eclauses_2edesugar_24cpr(v_f_240, NTAG(TAG_Nil), v_eqs_241, v_sp_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_err_248 = v_field_246;
        return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0, 2, 1, (V[]){v_err_248});
      } else {
        V v_b_2415 = v_field_246;
        return (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_b_2415));
      }
    }
  } else {
    heff_drop(v_x1_243);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1, 2, 3, (V[]){v_eqs_241, v_f_240, v_sp_242});
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_err_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), heff_take_field(v_err_248, 1), heff_get_n(v_err_248, 0, 2), NTAG(TAG_Nothing)});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2413}));
  V f_ = heff_get_n(v_hd_249, 1, 3);
  args[0] = v_t_2414;
  args[1] = v_k2_2410;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4(V self, V *args) {
  V v_m_2427 = args[0];
  V v_e_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_2418, 1, 6), v_m_2427));
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_f_2423 = heff_env(self)[0];
  V v_fsp_2424 = heff_env(self)[1];
  V v_rhs_2426 = heff_env(self)[2];
  V v_sp_2422 = heff_env(self)[3];
  V v_k_2430 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_2423, v_fsp_2424, v_x_2431, v_rhs_2426}), v_sp_2422});
  V f_ = v_k_2430;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  V v_f_2423 = heff_env(self)[1];
  V v_fsp_2424 = heff_env(self)[2];
  V v_rhs_2426 = heff_env(self)[3];
  V v_sp_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2428;
  args[0] = v_hd_2429;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6, 1, 5, (V[]){v_f_2423, v_fsp_2424, v_rhs_2426, v_sp_2422, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3(V self, V *args) {
  V v_m_2420 = args[0];
  V v_e_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2420)) {
  case TAG_At: {
    V v_x21_2421 = heff_field(v_m_2420, 0);
    V v_sp_2422 = heff_field(v_m_2420, 1);
    heff_take_n(v_m_2420, 3ULL, 2);
    switch (heff_tag_of(v_x21_2421)) {
    case TAG_MkEquation: {
      V v_f_2423 = heff_field(v_x21_2421, 0);
      V v_fsp_2424 = heff_field(v_x21_2421, 1);
      V v_ps_2425 = heff_field(v_x21_2421, 2);
      V v_rhs_2426 = heff_field(v_x21_2421, 3);
      heff_take_n(v_x21_2421, 15ULL, 4);
      V v_c_2428 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4, 1, 1, (V[]){v_e_2418}), v_ps_2425));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5, 2, 5, (V[]){v_c_2428, v_f_2423, v_fsp_2424, v_rhs_2426, v_sp_2422});
    }
    default: return heff_nomatch(v_x21_2421);
    }
  }
  default: return heff_nomatch(v_m_2420);
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam9(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k2_2443 = args[1];
  V v_err_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), heff_take_field(v_err_2441, 1), heff_get_n(v_err_2441, 0, 2), NTAG(TAG_Nothing)});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tr(heff_call(heff_take_field(v_hd_2442, 2), 1, (V[]){v_t_2446}));
  V f_ = heff_get_n(v_hd_2442, 1, 3);
  args[0] = v_t_2447;
  args[1] = v_k2_2443;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam10(V self, V *args) {
  V v_x_2450 = args[0];
  V v_e_2418 = heff_env(self)[0];
  V v_a_2419 = heff_env(self)[1];
  V v_hd_2434 = heff_env(self)[2];
  V v_k_2435 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2450)) {
  case TAG_MkChk: {
    V v_f_2451 = heff_field(v_x_2450, 0);
    heff_take_n(v_x_2450, 1ULL, 1);
    V f_ = v_f_2451;
    heff_room[0] = v_e_2418;
    heff_room[1] = v_a_2419;
    heff_room[2] = v_hd_2434;
    heff_room[3] = v_k_2435;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2450);
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam8(V self, V *args) {
  V v_x_2436 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_hd_2434 = heff_env(self)[2];
  V v_e_2418 = heff_env(self)[3];
  V v_a_2419 = heff_env(self)[4];
  V v_k_2435 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_2437 = (g_heff_2eelab_2eclauses_2edesugar_24cpr(v_f_240, NTAG(TAG_Nil), v_x_2436, v_sp_242));
  V v_c_2449;
  {
    V v_field_2439 = v_t_2437.f[1];
    int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
    if ((v_tag_2438 == ((int64_t)0ULL))) {
      V v_err_2441 = v_field_2439;
      v_c_2449 = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam9, 2, 1, (V[]){v_err_2441});
    } else {
      V v_b_2448 = v_field_2439;
      v_c_2449 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_b_2448));
    }
  }
  V f_ = v_c_2449;
  heff_room[0] = heff_dup(v_hd_2434);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam10, 1, 4, (V[]){v_e_2418, v_a_2419, v_hd_2434, v_k_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_e_2418 = heff_env(self)[3];
  V v_a_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2433;
  args[0] = heff_dup(v_hd_2434);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam8, 1, 6, (V[]){v_f_240, v_sp_242, v_hd_2434, v_e_2418, v_a_2419, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2(V self, V *args) {
  V v_e_2418 = args[0];
  V v_a_2419 = args[1];
  V v_eqs_241 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2433 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3, 1, 1, (V[]){heff_dup(v_e_2418)}), v_eqs_241));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7, 2, 5, (V[]){v_c_2433, v_f_240, v_sp_242, v_e_2418, v_a_2419});
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_eqs_241 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2, 2, 3, (V[]){v_eqs_241, v_f_240, v_sp_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2eelab_2etoplevel_2eexplicitNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eexplicitNames_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eexplicitNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ab_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_ab_241, 3);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Expl: {
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_ab_241, 1, 4), heff_hole()});
      V v_u_245 = (g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    case TAG_Impl: {
      heff_drop_rec(v_ab_241, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Inst: {
      heff_drop_rec(v_ab_241, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eexplicitNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eexplicitNames(a[0]);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam9(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eequationsD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eequationsD_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eequationsD(V v_name_240, V v_tyN_241, V v_eqs_242, V v_sp_243) {
top: ;
  V v_x1_244 = (g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604(v_eqs_242));
  V v_c_2429;
  if ((heff_dup(v_x1_244) == NTAG(TAG_True))) {
    heff_drop(v_x1_244);
    v_c_2429 = (g_heff_2eelab_2etoplevel_2eequationsBody(heff_dup(v_name_240), NTAG(TAG_Nil), v_eqs_242, v_sp_243));
  } else {
    heff_drop(v_x1_244);
    v_c_2429 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam0, 2, 3, (V[]){v_eqs_242, heff_dup(v_name_240), v_sp_243});
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam9, 2, 3, (V[]){v_c_2429, heff_dup(v_tyN_241), v_name_240});
}
V g_heff_2eelab_2etoplevel_2eequationsD_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eequationsD(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam3(V self, V *args) {
  V v_m_2416 = args[0];
  V v_e_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_247, 1, 6), v_m_2416));
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_f_2412 = heff_env(self)[0];
  V v_fsp_2413 = heff_env(self)[1];
  V v_rhs_2415 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_2412, v_fsp_2413, v_x_2420, v_rhs_2415}), v_sp_2411});
  V f_ = v_k_2419;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_f_2412 = heff_env(self)[1];
  V v_fsp_2413 = heff_env(self)[2];
  V v_rhs_2415 = heff_env(self)[3];
  V v_sp_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam5, 1, 5, (V[]){v_f_2412, v_fsp_2413, v_rhs_2415, v_sp_2411, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam2(V self, V *args) {
  V v_m_249 = args[0];
  V v_e_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_249)) {
  case TAG_At: {
    V v_x21_2410 = heff_field(v_m_249, 0);
    V v_sp_2411 = heff_field(v_m_249, 1);
    heff_take_n(v_m_249, 3ULL, 2);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkEquation: {
      V v_f_2412 = heff_field(v_x21_2410, 0);
      V v_fsp_2413 = heff_field(v_x21_2410, 1);
      V v_ps_2414 = heff_field(v_x21_2410, 2);
      V v_rhs_2415 = heff_field(v_x21_2410, 3);
      heff_take_n(v_x21_2410, 15ULL, 4);
      V v_c_2417 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam3, 1, 1, (V[]){v_e_247}), v_ps_2414));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam4, 2, 5, (V[]){v_c_2417, v_f_2412, v_fsp_2413, v_rhs_2415, v_sp_2411});
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_m_249);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_e_247 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  V v_hd_2423 = heff_env(self)[2];
  V v_k_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_MkChk: {
    V v_f_2428 = heff_field(v_x_2427, 0);
    heff_take_n(v_x_2427, 1ULL, 1);
    V f_ = v_f_2428;
    heff_room[0] = v_e_247;
    heff_room[1] = v_a_248;
    heff_room[2] = v_hd_2423;
    heff_room[3] = v_k_2424;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_name_240 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_hd_2423 = heff_env(self)[2];
  V v_e_247 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  V v_k_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2426 = (g_heff_2eelab_2etoplevel_2eequationsBody(v_name_240, NTAG(TAG_Nil), v_x_2425, v_sp_243));
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_2423);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam8, 1, 4, (V[]){v_e_247, v_a_248, v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam6(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_e_247 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam7, 1, 6, (V[]){v_name_240, v_sp_243, v_hd_2423, v_e_247, v_a_248, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam1(V self, V *args) {
  V v_e_247 = args[0];
  V v_a_248 = args[1];
  V v_eqs_242 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2422 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam2, 1, 1, (V[]){heff_dup(v_e_247)}), v_eqs_242));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam6, 2, 5, (V[]){v_c_2422, v_name_240, v_sp_243, v_e_247, v_a_248});
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_eqs_242 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam1, 2, 3, (V[]){v_eqs_242, v_name_240, v_sp_243})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam11(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2432 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2438 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2437, v_x_2432}); V r_ = (g_heff_2eelab_2etoplevel_2ewithArgs(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_ty_2439 = heff_field(v_x2_2438, 0);
    V v_tm_2440 = heff_field(v_x2_2438, 1);
    heff_take_n(v_x2_2438, 3ULL, 2);
    V v_t_2441 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_240, v_ty_2439, v_tm_2440, NTAG(TAG_False)});
    V f_ = v_k_2431;
    args[0] = v_t_2441;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam10(V self, V *args) {
  V v_x_2432 = args[0];
  V v_tyN_241 = heff_env(self)[0];
  V v_hd_2430 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_2431 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_n_2435;
  switch (heff_tag_of(v_tyN_241)) {
  case TAG_At: {
    V v_n_2433 = heff_field(v_tyN_241, 0);
    V v_sp_2434 = heff_field(v_tyN_241, 1);
    heff_take_n(v_tyN_241, 3ULL, 2);
    v_n_2435 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2434, v_n_2433));
    break;
  }
  default: heff_nomatch(v_tyN_241);
  }
  V v_c_2436 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2435));
  V f_ = v_c_2436;
  heff_room[0] = v_hd_2430;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam11, 1, 3, (V[]){v_x_2432, v_name_240, v_k_2431});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam9(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_c_2429 = heff_env(self)[0];
  V v_tyN_241 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2429;
  args[0] = heff_dup(v_hd_2430);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam10, 1, 4, (V[]){v_tyN_241, v_hd_2430, v_name_240, v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2econcatMapM_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2econcatMapM(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2etoplevel_2econcatMapM(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2etoplevel_2eappendM(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2econcatMapM(a[0], a1); heff_drop(a1); return r;
}

static V g_heff_2eelab_2etoplevel_2ebasicPrimNames_val;
static HEFF_ONCE g_heff_2eelab_2etoplevel_2ebasicPrimNames_st;
static V g_heff_2eelab_2etoplevel_2ebasicPrimNames_init(void) {
  return (g_list_2emap_24s1415906091x1371825187(heff_dup(g_heff_2ecompile_2eprims_2ebasicPrims_get())));
}
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2etoplevel_2ebasicPrimNames_st)) return g_heff_2eelab_2etoplevel_2ebasicPrimNames_val;
  return heff_global(&g_heff_2eelab_2etoplevel_2ebasicPrimNames_val, &g_heff_2eelab_2etoplevel_2ebasicPrimNames_st, g_heff_2eelab_2etoplevel_2ebasicPrimNames_init);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2esearchedInstance_str0, 116, "an instance takes only implicit and instance arguments, `{x : A}` and `{{x : A}}`: a search gives it no explicit one");
HEFF_LIT(g_heff_2eelab_2etoplevel_2esearchedInstance_str1, 192, "make it implicit, solved where the instance is found (`{a : Type} -> {{e : Equality a}} -> Equality (List a)`), or declare a definition, no instance, and give it its arguments where it is used");
HEFF_LIT(g_heff_2eelab_2etoplevel_2esearchedInstance_str2, 135, "the instance's implicit argument `_` is not in what it is an instance of: a search, unifying that with the type wanted, cannot solve it");
HEFF_LIT(g_heff_2eelab_2etoplevel_2esearchedInstance_str3, 120, "use it in what the instance is an instance of (`{a : Type} -> {{e : Equality a}} -> Equality (List a)`), or leave it out");
V g_heff_2eelab_2etoplevel_2esearchedInstance_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2esearchedInstance_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2esearchedInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2esearchedInstance_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2esearchedInstance(V v_sp_240, V v_implicits_241, V v_depth_242, V v_conclusion_243) {
top: ;
  switch (heff_tag_of(v_conclusion_243)) {
  case TAG_SU: {
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
  }
  case TAG_SDecode: {
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_247; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  case TAG_SFunction: {
    V v_conclusion3_2410 = heff_field(v_conclusion_243, 2);
    V v_conclusion4_2411 = heff_field(v_conclusion_243, 3);
    heff_take_n(v_conclusion_243, 12ULL, 5);
    switch (heff_tag_of(v_conclusion4_2411)) {
    case TAG_Expl: {
      heff_drop(v_implicits_241);
      heff_drop(v_depth_242);
      heff_drop(v_conclusion3_2410);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2esearchedInstance_lam0, 2, 1, (V[]){v_sp_240});
    }
    case TAG_Impl: {
      switch (heff_tag_of(v_conclusion3_2410)) {
      case TAG_MkAbs: {
        V v_x_2419 = heff_field(v_conclusion3_2410, 0);
        V v_cod_2420 = heff_field(v_conclusion3_2410, 1);
        V v_ru_24conclusion3_2410_24MkAbs = heff_take_reuse_n(v_conclusion3_2410, 3ULL, 2);
        V v_t_2421 = heff_tag_at_n(v_ru_24conclusion3_2410_24MkAbs, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__level, (V[]){v_x_2419, heff_dup(v_depth_242)}), v_implicits_241});
        V v_t_2422 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(v_cod_2420));
        V t_0 = v_sp_240;
        V t_1 = v_t_2421;
        V t_2 = heff_intAdd(v_depth_242, MK_INT(1LL));
        V t_3 = v_t_2422;
        v_sp_240 = t_0;
        v_implicits_241 = t_1;
        v_depth_242 = t_2;
        v_conclusion_243 = t_3;
        goto top;
      }
      case TAG_AbsConst: {
        heff_take_n(v_conclusion3_2410, 0ULL, 1);
        heff_drop(v_implicits_241);
        heff_drop(v_depth_242);
        return heff_clo_n(g_heff_2eelab_2etoplevel_2esearchedInstance_lam1, 2, 1, (V[]){v_sp_240});
      }
      default: return heff_nomatch(v_conclusion3_2410);
      }
    }
    case TAG_Inst: {
      switch (heff_tag_of(v_conclusion3_2410)) {
      case TAG_MkAbs: {
        V v_cod_2431 = heff_field(v_conclusion3_2410, 1);
        heff_take_n(v_conclusion3_2410, 2ULL, 2);
        V v_t_2432 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(v_cod_2431));
        V t_0 = v_sp_240;
        V t_1 = v_implicits_241;
        V t_2 = heff_intAdd(v_depth_242, MK_INT(1LL));
        V t_3 = v_t_2432;
        v_sp_240 = t_0;
        v_implicits_241 = t_1;
        v_depth_242 = t_2;
        v_conclusion_243 = t_3;
        goto top;
      }
      case TAG_AbsConst: {
        V v_cod_2433 = heff_field(v_conclusion3_2410, 0);
        heff_take_n(v_conclusion3_2410, 1ULL, 1);
        V v_t_2434 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(v_cod_2433));
        V t_0 = v_sp_240;
        V t_1 = v_implicits_241;
        V t_2 = v_depth_242;
        V t_3 = v_t_2434;
        v_sp_240 = t_0;
        v_implicits_241 = t_1;
        v_depth_242 = t_2;
        v_conclusion_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_conclusion3_2410);
      }
    }
    default: return heff_nomatch(v_conclusion4_2411);
    }
  }
  case TAG_SRecord: {
    V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2438; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2438); r_; });
  }
  case TAG_SSum: {
    V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2440; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2440); r_; });
  }
  case TAG_SIsTy: {
    V v_t_2442 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2442; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2442); r_; });
  }
  case TAG_SPrimInt: {
    V v_t_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2443; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2443); r_; });
  }
  case TAG_SPrimFloat: {
    V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2444; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2444); r_; });
  }
  case TAG_SPrimString: {
    V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2445; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2445); r_; });
  }
  case TAG_SPrimRune: {
    V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2446; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2446); r_; });
  }
  case TAG_SPrimArray: {
    V v_t_2448 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2448; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2448); r_; });
  }
  case TAG_SFixed: {
    V v_t_2450 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2450; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2450); r_; });
  }
  default: return heff_nomatch(v_conclusion_243);
  }
}
V g_heff_2eelab_2etoplevel_2esearchedInstance_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2esearchedInstance(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2esearchedInstance_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(348LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2esearchedInstance_str0), v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2esearchedInstance_str1)})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2417}));
  V f_ = heff_get_n(v_hd_2413, 1, 3);
  args[0] = v_t_2418;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2esearchedInstance_lam1(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(350LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2esearchedInstance_str2), v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2esearchedInstance_str3)})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_2424, 2), 1, (V[]){v_t_2428}));
  V f_ = heff_get_n(v_hd_2424, 1, 3);
  args[0] = v_t_2429;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ewatchPhase_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchPhase_lam6, 1, 0};
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewatchPhase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchPhase_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2ewatchPhase(V v_g_240, V v_sp_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_t_245 = heff_field(v_x3_242, 0);
    V v_ty_246 = heff_field(v_x3_242, 1);
    return (g_heff_2eelab_2emeta_2esettleGo(heff_dup(v_g_240), MK_INT(0LL), heff_dup(v_p_243), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam0, 1, 6, (V[]){v_p_243, v_g_240, v_sp_241, heff_dup(v_t_245), heff_dup(v_ty_246), v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2ewatchPhase(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam6(V self, V *args) {
  V v_c_2415 = args[0];
  return heff_get_n(v_c_2415, 3, 8);
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  V v_k_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2420 = ({ V a_0 = v_g_240; V a_1 = v_x_2419; V a_2 = v_t_245; V a_3 = v_ty_246; V r_ = (g_heff_2eelab_2etoplevel_2ewatchEntry(a_0, a_1, a_2, a_3)); heff_drop(v_x_2419); r_; });
  V f_ = v_k_2413;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_t_245 = heff_env(self)[2];
  V v_ty_246 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2ewatchPhase_lam6_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2417}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam7, 1, 4, (V[]){v_g_240, v_t_245, v_ty_246, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam4(V self, V *args) {
  V v_unsolved_2411 = args[0];
  V v_hd_2412 = args[1];
  V v_k_2413 = args[2];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_unsolved_2411; V a_1 = heff_dup(v_hd_2412); V a_2 = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam5, 1, 5, (V[]){v_hd_2412, v_g_240, v_t_245, v_ty_246, v_k_2413}); V r_ = (g_heff_2eelab_2etoplevel_2echeckUnsolved(a_0, a_1, a_2)); heff_drop(v_unsolved_2411); r_; });
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  return (g_co_2ebind_24s591410632x427349444(heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam4, 3, 3, (V[]){v_g_240, v_t_245, v_ty_246}), v_p_243, v_p_244));
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_t_245 = heff_env(self)[4];
  V v_ty_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_249);
  return ({ V a_0 = heff_dup(v_g_240); V a_1 = v_sp_241; V a_2 = v_x_247; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam3, 1, 5, (V[]){v_g_240, v_t_245, v_ty_246, v_p_243, v_p_244}); V r_ = (g_heff_2eelab_2etoplevel_2echeckStuck(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_247); r_; });
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_t_245 = heff_env(self)[4];
  V v_ty_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_248);
  return (g_heff_2eelab_2etoplevel_2epoisonedLeft(heff_dup(v_p_243), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam2, 1, 7, (V[]){v_g_240, v_sp_241, v_x_247, v_p_243, v_t_245, v_ty_246, v_p_244})));
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_t_245 = heff_env(self)[3];
  V v_ty_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2etoplevel_2erecoveredCheck(heff_dup(v_p_243), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam1, 1, 7, (V[]){v_p_243, v_g_240, v_sp_241, v_x_247, v_t_245, v_ty_246, v_p_244})));
}
Clo g_heff_2eelab_2etoplevel_2eappendT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eappendT(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2etoplevel_2eappendT_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendT(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eappendT_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_24dps_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappendT_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendT_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_str0, 0, "");
Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720(V v_n_240, V v_g_241) {
top: ;
  V v_t_2424;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_242 = heff_dup(heff_field(v_n_240, 0));
    switch (heff_tag_of(v_x11_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 5);
      v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){v_f_244});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_249 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 5);
      v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){v_x_249});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2414 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 4);
      v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2414});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2418 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 3);
      v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2418});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2421 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 2);
      v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2421});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2424 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_242);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  switch (heff_tag_of(v_t_2424)) {
  case TAG_Nothing: {
    heff_drop(v_n_240);
    return v_g_241;
  }
  case TAG_Just: {
    V v_x_2425 = heff_field(v_t_2424, 0);
    heff_take_n(v_t_2424, 1ULL, 1);
    switch (heff_tag_of(v_n_240)) {
    case TAG_At: {
      V v_x11_2426 = heff_field(v_n_240, 0);
      V v_ru_24n_240_24At = heff_take_reuse_n(v_n_240, 1ULL, 2);
      switch (heff_tag_of(v_x11_2426)) {
      case TAG_DeclEquations: {
        V v_x113_2430 = heff_field(v_x11_2426, 2);
        heff_take_n(v_x11_2426, 4ULL, 5);
        switch (heff_tag_of(v_x113_2430)) {
        case TAG_AsDefinition: {
          heff_drop(v_x_2425);
          heff_drop_cell(v_ru_24n_240_24At, 2);
          return v_g_241;
        }
        case TAG_AsInstance: {
          V v_t_2435;
          if (heff_strEq_c_lent(v_x_2425, v_x_2425, 0)) {
            v_t_2435 = ((V)&g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_str0);
          } else {
            int64_t v_t_2434 = (heff_unbox_word(heff_strLength_lent(v_x_2425, 0)) - heff_unbox_word(heff_strLength_lent(v_x_2425, 0)));
            v_t_2435 = heff_strSlice_lent(v_x_2425, MK_INT(0LL), heff_box_word((v_t_2434 - ((int64_t)1ULL))), 6);
          }
          V v_t_2436 = (g_list_2ekeepIf_24s522699319x1190492156(v_x_2425, heff_take_field(v_g_241, 7)));
          V v_t_2437 = heff_tag_at_n(v_ru_24n_240_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_key__module, (V[]){v_x_2425, v_t_2435}), v_t_2436});
          return ({ V rv_7 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_g_241, 127ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
        }
        default: return heff_nomatch(v_x113_2430);
        }
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_2426, 0ULL, 5);
        heff_drop(v_x_2425);
        heff_drop_cell(v_ru_24n_240_24At, 2);
        return v_g_241;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_2426, 0ULL, 4);
        heff_drop(v_x_2425);
        heff_drop_cell(v_ru_24n_240_24At, 2);
        return v_g_241;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_x11_2426, 0ULL, 3);
        heff_drop(v_x_2425);
        heff_drop_cell(v_ru_24n_240_24At, 2);
        return v_g_241;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_2426, 0ULL, 2);
        heff_drop(v_x_2425);
        heff_drop_cell(v_ru_24n_240_24At, 2);
        return v_g_241;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_2426, 0ULL, 1);
        heff_drop(v_x_2425);
        heff_drop_cell(v_ru_24n_240_24At, 2);
        return v_g_241;
      }
      default: return heff_nomatch(v_x11_2426);
      }
    }
    default: return heff_nomatch(v_n_240);
    }
  }
  default: return heff_nomatch(v_t_2424);
  }
}
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(V v_g_240, V v_n_241, V v_d_242, V v_a_243, V v_st_244) {
top: ;
  V v_c_248;
  switch (heff_tag_of(v_st_244)) {
  case TAG_MkSt: {
    V v_c_245 = heff_dup(heff_field(v_st_244, 0));
    v_c_248 = v_c_245;
    break;
  }
  default: heff_nomatch(v_st_244);
  }
  V v_t_2411;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2410 = heff_field(v_n_241, 1);
    v_t_2411 = heff_dup(v_s_2410);
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_t_2412 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2413;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    v_t_2413 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_2412);
    v_t_2413 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_t_2414 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2415;
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_t_2414);
    v_t_2415 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_2414);
    v_t_2415 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_t_2421 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(heff_tag_n(TAG_HGlobal, 1, (V[]){v_t_2415}), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam0, 1, 1, (V[]){heff_dup(v_a_243)}), NTAG(TAG_Nothing)));
  V v_x1_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_243, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2426;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2423;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    v_t_2426 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  V v_t_2427 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SOpaque), heff_dup(heff_rfield(v_a_243, 0)), v_t_2421, v_t_2426});
  V v_t_2428 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_2413, v_t_2427, heff_dup(v_g_240)));
  V v_t_2429 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2430;
  if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
    heff_drop(v_t_2429);
    v_t_2430 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_2429);
    v_t_2430 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_x1_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_243, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2435;
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_Nom: {
    V v_x_2432 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    v_t_2435 = v_x_2432;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2431, 0ULL, 1);
    v_t_2435 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2434 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    v_t_2435 = v_x_2434;
    break;
  }
  default: heff_nomatch(v_x1_2431);
  }
  V v_t_2436 = (g_heff_2eelab_2etoplevel_2ebodyPhase(v_t_2411, heff_dup(v_d_242), v_t_2428, v_t_2430, v_t_2435));
  V v_t_2437 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_t_2436}));
  V v_t_2444;
  switch (heff_tag_of(v_st_244)) {
  case TAG_MkSt: {
    V v_d_2439 = heff_field(v_st_244, 1);
    V v_w_2440 = heff_field(v_st_244, 2);
    V v_ru_24st_244_24MkSt = heff_take_reuse_n(v_st_244, 6ULL, 3);
    V v_t_2441 = heff_dup(heff_rfield(v_d_242, 3));
    V v_t_2442;
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop(v_t_2441);
      v_t_2442 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2441);
      v_t_2442 = heff_dup(heff_rfield(v_d_242, 0));
    }
    V v_t_2443 = ({ V rv_7 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2442}); V rr_ = heff_rec_reuse_nf(v_c_248, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
    v_t_2444 = heff_tag_at_n(v_ru_24st_244_24MkSt, TAG_MkSt, 3, (V[]){v_t_2443, v_d_2439, v_w_2440});
    break;
  }
  default: heff_nomatch(v_st_244);
  }
  return (g_co_2ebind_24s2023162438x1917167210(v_t_2437, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam1, 3, 4, (V[]){heff_dup(v_n_241), v_d_242, v_a_243, v_g_240}), v_t_2444));
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  V v_x1_2417 = heff_tr(heff_call(heff_get_n(v_a_243, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nom: {
    V v_x_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    return v_x_2418;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2420 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    return v_x_2420;
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2(V self, V *args) {
  V v_c_2448 = args[0];
  return ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_c_2448, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6(V self, V *args) {
  V v_c_2462 = args[0];
  return heff_get_n(v_c_2462, 3, 8);
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam7(V self, V *args) {
  V v_x_2466 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_body_2445 = heff_env(self)[4];
  V v_hd_2446 = heff_env(self)[5];
  V v_k_2447 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2489;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_2467 = heff_field(v_n_241, 0);
    heff_take_n(v_n_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_2467)) {
    case TAG_DeclEquations: {
      V v_x113_2471 = heff_field(v_x11_2467, 2);
      heff_take_n(v_x11_2467, 4ULL, 5);
      switch (heff_tag_of(v_x113_2471)) {
      case TAG_AsDefinition: {
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_AsInstance: {
        v_t_2489 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x113_2471);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2467, 0ULL, 5);
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2467, 0ULL, 4);
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2467, 0ULL, 3);
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2467, 0ULL, 2);
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2467, 0ULL, 1);
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2467);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_t_2490 = (g_heff_2eelab_2eunify_2ezonker(v_x_2466));
  V v_t_2491 = heff_tr(heff_call(heff_get_n(v_t_2490, 1, 2), 1, (V[]){heff_get_n(v_a_243, 0, 2)}));
  return ({ V a_0 = v_g_240; V a_1 = v_d_242; V a_2 = v_t_2489; V a_3 = v_t_2491; V a_4 = v_x_2466; V a_5 = v_body_2445; V a_6 = v_hd_2446; V a_7 = v_k_2447; V r_ = (g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2466); heff_drop_rec(v_hd_2446, 3); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam5(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_2446 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_a_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_body_2445 = heff_env(self)[5];
  V v_k_2447 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2461);
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6_clo)})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2446, 2)), 1, (V[]){v_t_2464}));
  V f_ = heff_dup(heff_rfield(v_hd_2446, 1));
  heff_room[0] = v_t_2465;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam7, 1, 7, (V[]){v_n_241, v_a_243, v_g_240, v_d_242, v_body_2445, v_hd_2446, v_k_2447});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam4(V self, V *args) {
  V v_x_2456 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_hd_2446 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_body_2445 = heff_env(self)[5];
  V v_k_2447 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2456);
  V v_t_2459;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2458 = heff_dup(heff_field(v_n_241, 1));
    v_t_2459 = v_s_2458;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_2460 = (g_heff_2eelab_2etoplevel_2eprimKnown(v_t_2459, heff_dup(v_d_242)));
  V f_ = v_c_2460;
  heff_room[0] = heff_dup(v_hd_2446);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam5, 1, 7, (V[]){v_hd_2446, v_n_241, v_a_243, v_g_240, v_d_242, v_body_2445, v_k_2447});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam3(V self, V *args) {
  V v_x_2452 = args[0];
  V v_hd_2446 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_body_2445 = heff_env(self)[5];
  V v_k_2447 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2453 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2452, NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2446, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})}));
  V f_ = heff_dup(heff_rfield(v_hd_2446, 1));
  heff_room[0] = v_t_2455;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam4, 1, 7, (V[]){v_n_241, v_d_242, v_hd_2446, v_a_243, v_g_240, v_body_2445, v_k_2447});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam1(V self, V *args) {
  V v_body_2445 = args[0];
  V v_hd_2446 = args[1];
  V v_k_2447 = args[2];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_a_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2_clo)})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2446, 2)), 1, (V[]){v_t_2450}));
  V f_ = heff_dup(heff_rfield(v_hd_2446, 1));
  args[0] = v_t_2451;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam3, 1, 7, (V[]){v_hd_2446, v_n_241, v_d_242, v_a_243, v_g_240, v_body_2445, v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2ethawDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawDone_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ethawDone(V v_acc_240) {
top: ;
  V v_keys_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 2)));
  V v_spans_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 6)));
  return ({ V rv_2 = v_keys_241; V rv_6 = v_spans_242; V rr_ = heff_rec_reuse_nf(v_acc_240, 443ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 249807u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawDone(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(V v_ys_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(v_ys_240, v_f_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(a[0], a[1], a[2]);
}