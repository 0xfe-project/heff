// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_prelude_2esplit_2esplitFrom_240_2ebackwards_241(V, V);
V g_prelude_2esplit_2esplitFrom_240_2ebackwards_241_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_2ebackwards_241_clo;
Clo g_prelude_2esplit_2esplitFrom_240_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esplit_2esplitFrom_240_entry, 5, 0};

V g_prelude_2esplit_2esplitFrom_240(V v_s_240, V v_sep_241, V v_i_242, V v_j_243, V v_acc_244) {
top: ;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    V v_t_245 = heff_strSlice_lent(v_s_240, v_i_242, heff_strLength_lent(v_s_240, 0), 6);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    return (g_prelude_2esplit_2esplitFrom_240_2ebackwards_241(v_acc_244, v_t_246));
  } else {
    V v_t_247 = heff_intAdd_lent(v_j_243, heff_strLength_lent(v_sep_241, 0), 2);
    V v_t_248 = heff_intAdd_lent(v_j_243, heff_strLength_lent(v_sep_241, 0), 2);
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_i_242, v_j_243, 6), v_acc_244});
    V t_0 = v_s_240;
    V t_1 = v_sep_241;
    V t_2 = v_t_247;
    V t_3 = heff_strFind_lent(v_sep_241, v_s_240, v_t_248, 4);
    V t_4 = v_t_249;
    v_s_240 = t_0;
    v_sep_241 = t_1;
    v_i_242 = t_2;
    v_j_243 = t_3;
    v_acc_244 = t_4;
    goto top;
  }
}
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_prelude_2esplit_2esplitFrom_240(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}