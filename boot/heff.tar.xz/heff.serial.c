// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeListGo_24s773_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
Clo g_heff_2eserial_2eencodeListGo_24s773_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2eencodeListGo_24s773_entry, 2, 0};

V g_heff_2eserial_2eencodeListGo_24s773(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest2_244 = (g_heff_2eserial_2eencodeListGo_24s773(v_xs_243, v_rest_241));
    V v_t_245 = heff_intShow(heff_strLength(heff_dup(v_x_242)));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2eserial_2eencodeListGo_24s773_str0), v_x_242));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, v_rest2_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eserial_2eencodeListGo_24s773_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2eencodeListGo_24s773(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeListGo_24s776_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
Clo g_heff_2eserial_2eencodeListGo_24s776_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2eencodeListGo_24s776_entry, 2, 0};

V g_heff_2eserial_2eencodeListGo_24s776(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest2_244 = (g_heff_2eserial_2eencodeListGo_24s776(v_xs_243, v_rest_241));
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x_242, 0);
      V v_v_246 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_247 = heff_intShow(heff_strLength(heff_dup(v_x_245)));
      V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eserial_2eencodeListGo_24s776_str0), v_x_245));
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_heff_2eserial_2eencodeTermF_24s774(v_v_246, v_rest2_244))});
    }
    default: return heff_nomatch(v_x_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eserial_2eencodeListGo_24s776_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2eencodeListGo_24s776(a[0], a[1]);
}
Clo g_heff_2eserial_2eencodeDict_24s775_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2eencodeDict_24s775_entry, 2, 0};

V g_heff_2eserial_2eencodeDict_24s775(V v_d_240, V v_rest_241) {
top: ;
  V v_t_242 = heff_arrayToList(heff_get(heff_dup(v_d_240), LBL_keys));
  V v_t_243 = heff_arrayToList(heff_get(v_d_240, LBL_values));
  V v_xs_244 = (g_heff_2edict_2ezipKV(v_t_242, v_t_243));
  V v_i_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_244));
  return heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_i_245), (g_heff_2eserial_2eencodeListGo_24s776(v_xs_244, v_rest_241))});
}
V g_heff_2eserial_2eencodeDict_24s775_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2eencodeDict_24s775(a[0], a[1]);
}
Clo g_heff_2eserial_2eencodeListGo_24s777_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2eencodeListGo_24s777_entry, 2, 0};

V g_heff_2eserial_2eencodeListGo_24s777(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eserial_2eencodeListGo_24s777(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2eserial_2eencodeTermF_24s774(heff_dup(v_x_242), v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eserial_2eencodeListGo_24s777_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eserial_2eencodeListGo_24s777(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeListGo_24s779_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
Clo g_heff_2eserial_2eencodeListGo_24s779_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2eencodeListGo_24s779_entry, 2, 0};

V g_heff_2eserial_2eencodeListGo_24s779(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest2_244 = (g_heff_2eserial_2eencodeListGo_24s779(v_xs_243, v_rest_241));
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x_242, 0);
      V v_v_246 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24MkPair = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_247 = heff_intShow(heff_strLength(heff_dup(v_x_245)));
      V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eserial_2eencodeListGo_24s779_str0), v_x_245));
      V v_t_2414;
      switch (heff_tag_of(v_v_246)) {
      case TAG_MkPair: {
        V v_xs_249 = heff_field(v_v_246, 0);
        V v_b_2410 = heff_field(v_v_246, 1);
        heff_take_n(v_v_246, 3ULL, 2);
        V v_xs_2411 = heff_arrayToList(v_xs_249);
        V v_rest_2412 = (g_heff_2eserial_2eencodeTermF_24s774(v_b_2410, v_rest2_244));
        V v_i_2413 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_2411));
        v_t_2414 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_i_2413), (g_heff_2eserial_2eencodeListGo_24s773(v_xs_2411, v_rest_2412))});
        break;
      }
      default: heff_nomatch(v_v_246);
      }
      return heff_tag_at(v_ru_24x_242_24MkPair, TAG_Cons, 2, (V[]){v_t_248, v_t_2414});
    }
    default: return heff_nomatch(v_x_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eserial_2eencodeListGo_24s779_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2eencodeListGo_24s779(a[0], a[1]);
}
Clo g_heff_2eserial_2eencodeDict_24s778_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2eencodeDict_24s778_entry, 2, 0};

V g_heff_2eserial_2eencodeDict_24s778(V v_d_240, V v_rest_241) {
top: ;
  V v_t_242 = heff_arrayToList(heff_get(heff_dup(v_d_240), LBL_keys));
  V v_t_243 = heff_arrayToList(heff_get(v_d_240, LBL_values));
  V v_xs_244 = (g_heff_2edict_2ezipKV(v_t_242, v_t_243));
  V v_i_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_244));
  return heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_i_245), (g_heff_2eserial_2eencodeListGo_24s779(v_xs_244, v_rest_241))});
}
V g_heff_2eserial_2eencodeDict_24s778_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2eencodeDict_24s778(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeListGo_24s782_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
Clo g_heff_2eserial_2eencodeListGo_24s782_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2eencodeListGo_24s782_entry, 2, 0};

V g_heff_2eserial_2eencodeListGo_24s782(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest2_244 = (g_heff_2eserial_2eencodeListGo_24s782(v_xs_243, v_rest_241));
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x_242, 0);
      V v_v_246 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_247 = heff_intShow(heff_strLength(heff_dup(v_x_245)));
      V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eserial_2eencodeListGo_24s782_str0), v_x_245));
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, ({ V a_0 = v_v_246; V a_1 = v_rest2_244; V r_ = (g_heff_2eserial_2eencodeTypeF_24s780(a_0, a_1)); heff_drop(v_v_246); r_; })});
    }
    default: return heff_nomatch(v_x_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eserial_2eencodeListGo_24s782_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2eencodeListGo_24s782(a[0], a[1]);
}
Clo g_heff_2eserial_2eencodeDict_24s781_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2eencodeDict_24s781_entry, 2, 0};

V g_heff_2eserial_2eencodeDict_24s781(V v_d_240, V v_rest_241) {
top: ;
  V v_t_242 = heff_arrayToList(heff_get(heff_dup(v_d_240), LBL_keys));
  V v_t_243 = heff_arrayToList(heff_get(v_d_240, LBL_values));
  V v_xs_244 = (g_heff_2edict_2ezipKV(v_t_242, v_t_243));
  V v_i_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_244));
  return heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_i_245), (g_heff_2eserial_2eencodeListGo_24s782(v_xs_244, v_rest_241))});
}
V g_heff_2eserial_2eencodeDict_24s781_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2eencodeDict_24s781(a[0], a[1]);
}
Clo g_heff_2eserial_2eencodeListGo_24s783_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2eencodeListGo_24s783_entry, 2, 0};

V g_heff_2eserial_2eencodeListGo_24s783(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eserial_2eencodeListGo_24s783(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2eserial_2eencodeTypeF_24s780(v_x_242, v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eserial_2eencodeListGo_24s783_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eserial_2eencodeListGo_24s783(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeListGo_24s785_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
Clo g_heff_2eserial_2eencodeListGo_24s785_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2eencodeListGo_24s785_entry, 2, 0};

V g_heff_2eserial_2eencodeListGo_24s785(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest2_244 = (g_heff_2eserial_2eencodeListGo_24s785(v_xs_243, v_rest_241));
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x_242, 0);
      V v_v_246 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24MkPair = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_247 = heff_intShow(heff_strLength(heff_dup(v_x_245)));
      V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eserial_2eencodeListGo_24s785_str0), v_x_245));
      V v_xs_249 = heff_arrayToList(v_v_246);
      V v_i_2410 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_249));
      V v_t_2411 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_i_2410), ({ V a_0 = v_xs_249; V a_1 = v_rest2_244; V r_ = (g_heff_2eserial_2eencodeListGo_24s783(a_0, a_1)); heff_drop(v_xs_249); r_; })});
      return heff_tag_at(v_ru_24x_242_24MkPair, TAG_Cons, 2, (V[]){v_t_248, v_t_2411});
    }
    default: return heff_nomatch(v_x_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eserial_2eencodeListGo_24s785_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2eencodeListGo_24s785(a[0], a[1]);
}
Clo g_heff_2eserial_2eencodeDict_24s784_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2eencodeDict_24s784_entry, 2, 0};

V g_heff_2eserial_2eencodeDict_24s784(V v_d_240, V v_rest_241) {
top: ;
  V v_t_242 = heff_arrayToList(heff_get(heff_dup(v_d_240), LBL_keys));
  V v_t_243 = heff_arrayToList(heff_get(v_d_240, LBL_values));
  V v_xs_244 = (g_heff_2edict_2ezipKV(v_t_242, v_t_243));
  V v_i_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_244));
  return heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_i_245), (g_heff_2eserial_2eencodeListGo_24s785(v_xs_244, v_rest_241))});
}
V g_heff_2eserial_2eencodeDict_24s784_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2eencodeDict_24s784(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {117}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {117}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2eencodeTypeF_24s780_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2eencodeTypeF_24s780_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {102, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTypeF_24s780_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2eencodeTypeF_24s780_str18 = {{0x80000000u, K_STR, 0}, 2, 2, {114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2eencodeTypeF_24s780_str19 = {{0x80000000u, K_STR, 0}, 2, 2, {115, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTypeF_24s780_str20 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2eencodeTypeF_24s780_str21 = {{0x80000000u, K_STR, 0}, 2, 2, {112, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2eencodeTypeF_24s780_str22 = {{0x80000000u, K_STR, 0}, 2, 2, {112, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2eencodeTypeF_24s780_str23 = {{0x80000000u, K_STR, 0}, 2, 2, {112, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2eencodeTypeF_24s780_str24 = {{0x80000000u, K_STR, 0}, 2, 2, {112, 97}};
Clo g_heff_2eserial_2eencodeTypeF_24s780_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2eencodeTypeF_24s780_entry, 2, 0};

V g_heff_2eserial_2eencodeTypeF_24s780(V v_t_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_SU: {
    V v_it1_242 = heff_field(v_t_240, 0);
    switch (heff_tag_of(v_it1_242)) {
    case TAG_SmallU: {
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str0), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str1), v_rest_241})});
    }
    case TAG_LargeU: {
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str2), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str3), v_rest_241})});
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  case TAG_SDecode: {
    V v_e_243 = heff_field(v_t_240, 0);
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str4), (g_heff_2eserial_2eencodeTermF_24s774(heff_dup(v_e_243), v_rest_241))});
  }
  case TAG_SFunction: {
    V v_level_244 = heff_field(v_t_240, 0);
    V v_dom_245 = heff_field(v_t_240, 1);
    V v_cod_246 = heff_field(v_t_240, 2);
    V v_implicit_247 = heff_field(v_t_240, 3);
    V v_t_248;
    switch (heff_tag_of(v_level_244)) {
    case TAG_Small: {
      v_t_248 = ((V)&g_heff_2eserial_2eencodeTypeF_24s780_str5);
      break;
    }
    case TAG_Large: {
      v_t_248 = ((V)&g_heff_2eserial_2eencodeTypeF_24s780_str6);
      break;
    }
    case TAG_TopL: {
      v_t_248 = ((V)&g_heff_2eserial_2eencodeTypeF_24s780_str7);
      break;
    }
    default: heff_nomatch(v_level_244);
    }
    V v_t_249;
    switch (heff_tag_of(v_implicit_247)) {
    case TAG_Expl: {
      v_t_249 = ((V)&g_heff_2eserial_2eencodeTypeF_24s780_str8);
      break;
    }
    case TAG_Impl: {
      v_t_249 = ((V)&g_heff_2eserial_2eencodeTypeF_24s780_str9);
      break;
    }
    case TAG_Inst: {
      v_t_249 = ((V)&g_heff_2eserial_2eencodeTypeF_24s780_str10);
      break;
    }
    default: heff_nomatch(v_implicit_247);
    }
    V v_rest_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, v_rest_241});
    V v_rest_2417;
    switch (heff_tag_of(v_cod_246)) {
    case TAG_MkAbs: {
      V v_x_2411 = heff_field(v_cod_246, 0);
      V v_e_2412 = heff_field(v_cod_246, 1);
      V v_t_2413 = heff_intShow(heff_strLength(heff_dup(v_x_2411)));
      V v_t_2414 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2eserial_2eencodeTypeF_24s780_str11), heff_dup(v_x_2411)));
      V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){v_t_2414, (g_heff_2eserial_2eencodeTypeF_24s780(v_e_2412, v_rest_2410))});
      v_rest_2417 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str12), v_t_2415});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2416 = heff_field(v_cod_246, 0);
      v_rest_2417 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str13), (g_heff_2eserial_2eencodeTypeF_24s780(v_e_2416, v_rest_2410))});
      break;
    }
    default: heff_nomatch(v_cod_246);
    }
    V v_t_2418 = (g_heff_2eserial_2eencodeTypeF_24s780(v_dom_245, v_rest_2417));
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str14), heff_tag(TAG_Cons, 2, (V[]){v_t_248, v_t_2418})});
  }
  case TAG_SRecord: {
    V v_level_2419 = heff_field(v_t_240, 0);
    V v_fs_2420 = heff_field(v_t_240, 1);
    V v_ds_2421 = heff_field(v_t_240, 2);
    V v_t_2422;
    switch (heff_tag_of(v_level_2419)) {
    case TAG_Small: {
      v_t_2422 = ((V)&g_heff_2eserial_2eencodeTypeF_24s780_str15);
      break;
    }
    case TAG_Large: {
      v_t_2422 = ((V)&g_heff_2eserial_2eencodeTypeF_24s780_str16);
      break;
    }
    case TAG_TopL: {
      v_t_2422 = ((V)&g_heff_2eserial_2eencodeTypeF_24s780_str17);
      break;
    }
    default: heff_nomatch(v_level_2419);
    }
    V v_t_2423 = (g_heff_2eserial_2eencodeDict_24s775(heff_dup(v_ds_2421), v_rest_241));
    V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){v_t_2422, (g_heff_2eserial_2eencodeDict_24s781(heff_dup(v_fs_2420), v_t_2423))});
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str18), v_t_2424});
  }
  case TAG_SSum: {
    V v_vs_2425 = heff_field(v_t_240, 0);
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str19), (g_heff_2eserial_2eencodeDict_24s784(heff_dup(v_vs_2425), v_rest_241))});
  }
  case TAG_SIsTy: {
    V v_t2_2426 = heff_field(v_t_240, 0);
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str20), (g_heff_2eserial_2eencodeTypeF_24s780(v_t2_2426, v_rest_241))});
  }
  case TAG_SPrimInt: {
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str21), v_rest_241});
  }
  case TAG_SPrimFloat: {
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str22), v_rest_241});
  }
  case TAG_SPrimString: {
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str23), v_rest_241});
  }
  case TAG_SPrimArray: {
    V v_t2_2427 = heff_field(v_t_240, 0);
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTypeF_24s780_str24), (g_heff_2eserial_2eencodeTypeF_24s780(v_t2_2427, v_rest_241))});
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2eserial_2eencodeTypeF_24s780_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eserial_2eencodeTypeF_24s780(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 111, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 108, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 97, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {112, 114, 106}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str13 = {{0x80000000u, K_STR, 0}, 3, 3, {116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {109, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str16 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2eencodeTermF_24s774_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str18 = {{0x80000000u, K_STR, 0}, 3, 3, {111, 112, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str19 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 98, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str20 = {{0x80000000u, K_STR, 0}, 3, 3, {114, 101, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str24 = {{0x80000000u, K_STR, 0}, 3, 3, {102, 105, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str26 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 109, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str28 = {{0x80000000u, K_STR, 0}, 3, 3, {112, 114, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eserial_2eencodeTermF_24s774_str29 = {{0x80000000u, K_STR, 0}, 4, 4, {109, 101, 116, 97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str31 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str33 = {{0x80000000u, K_STR, 0}, 3, 3, {102, 108, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2eencodeTermF_24s774_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2eencodeTermF_24s774_str35 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 116, 114}};
Clo g_heff_2eserial_2eencodeTermF_24s774_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2eencodeTermF_24s774_entry, 2, 0};

V g_heff_2eserial_2eencodeTermF_24s774(V v_e_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_i_242), v_rest_241});
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str0), v_t_243});
  }
  case TAG_SGlobal: {
    V v_x_244 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V v_t_245 = heff_intShow(heff_strLength(heff_dup(v_x_244)));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2eserial_2eencodeTermF_24s774_str1), v_x_244));
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str2), heff_tag(TAG_Cons, 2, (V[]){v_t_246, v_rest_241})});
  }
  case TAG_SCode: {
    V v_t_247 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str3), ({ V a_0 = v_t_247; V a_1 = v_rest_241; V r_ = (g_heff_2eserial_2eencodeTypeF_24s780(a_0, a_1)); heff_drop(v_t_247); r_; })});
  }
  case TAG_SApp: {
    V v_f_248 = heff_field(v_e_240, 0);
    V v_a_249 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24SApp = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_rest_2410 = (g_heff_2eserial_2eencodeTermF_24s774(v_a_249, v_rest_241));
    V v_t_2411 = (g_heff_2eserial_2eencodeTermF_24s774(v_f_248, v_rest_2410));
    return heff_tag_at(v_ru_24e_240_24SApp, TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str4), v_t_2411});
  }
  case TAG_SLam: {
    V v_t_2412 = heff_field(v_e_240, 0);
    V v_b_2413 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24SLam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_rest_2420;
    switch (heff_tag_of(v_b_2413)) {
    case TAG_MkAbs: {
      V v_x_2414 = heff_field(v_b_2413, 0);
      V v_e_2415 = heff_field(v_b_2413, 1);
      V v_ru_24b_2413_24MkAbs = heff_take_reuse_n(v_b_2413, 3ULL, 2);
      V v_t_2416 = heff_intShow(heff_strLength(heff_dup(v_x_2414)));
      V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2eserial_2eencodeTermF_24s774_str5), v_x_2414));
      V v_t_2418 = heff_tag_at(v_ru_24e_240_24SLam, TAG_Cons, 2, (V[]){v_t_2417, (g_heff_2eserial_2eencodeTermF_24s774(v_e_2415, v_rest_241))});
      v_rest_2420 = heff_tag_at(v_ru_24b_2413_24MkAbs, TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str6), v_t_2418});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2419 = heff_field(v_b_2413, 0);
      heff_take_n(v_b_2413, 1ULL, 1);
      v_rest_2420 = heff_tag_at(v_ru_24e_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str7), (g_heff_2eserial_2eencodeTermF_24s774(v_e_2419, v_rest_241))});
      break;
    }
    default: heff_nomatch(v_b_2413);
    }
    V v_t_2421 = ({ V a_0 = v_t_2412; V a_1 = v_rest_2420; V r_ = (g_heff_2eserial_2eencodeTypeF_24s780(a_0, a_1)); heff_drop(v_t_2412); r_; });
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str8), v_t_2421});
  }
  case TAG_SCons: {
    V v_d_2422 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str9), (g_heff_2eserial_2eencodeDict_24s775(v_d_2422, v_rest_241))});
  }
  case TAG_SProj: {
    V v_e2_2423 = heff_field(v_e_240, 0);
    V v_l_2424 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24SProj = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2425 = heff_intShow(heff_strLength(heff_dup(v_l_2424)));
    V v_t_2426 = heff_strAppend(v_t_2425, heff_strAppend(((V)&g_heff_2eserial_2eencodeTermF_24s774_str10), v_l_2424));
    return heff_tag_at(v_ru_24e_240_24SProj, TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str11), (g_heff_2eserial_2eencodeTermF_24s774(v_e2_2423, heff_tag(TAG_Cons, 2, (V[]){v_t_2426, v_rest_241})))});
  }
  case TAG_STag: {
    V v_t_2427 = heff_field(v_e_240, 0);
    V v_as_2428 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24STag = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2429 = heff_intShow(heff_strLength(heff_dup(v_t_2427)));
    V v_t_2430 = heff_strAppend(v_t_2429, heff_strAppend(((V)&g_heff_2eserial_2eencodeTermF_24s774_str12), v_t_2427));
    V v_xs_2431 = heff_arrayToList(v_as_2428);
    V v_i_2432 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_2431));
    V v_t_2433 = heff_tag_at(v_ru_24e_240_24STag, TAG_Cons, 2, (V[]){heff_intShow(v_i_2432), ({ V a_0 = v_xs_2431; V a_1 = v_rest_241; V r_ = (g_heff_2eserial_2eencodeListGo_24s777(a_0, a_1)); heff_drop(v_xs_2431); r_; })});
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str13), heff_tag(TAG_Cons, 2, (V[]){v_t_2430, v_t_2433})});
  }
  case TAG_SMatch: {
    V v_e2_2434 = heff_field(v_e_240, 0);
    V v_cs_2435 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24SMatch = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_rest_2436 = (g_heff_2eserial_2eencodeDict_24s778(v_cs_2435, v_rest_241));
    V v_t_2437 = (g_heff_2eserial_2eencodeTermF_24s774(v_e2_2434, v_rest_2436));
    return heff_tag_at(v_ru_24e_240_24SMatch, TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str14), v_t_2437});
  }
  case TAG_SSpecialize: {
    V v_e2_2438 = heff_field(v_e_240, 0);
    V v_l_2439 = heff_field(v_e_240, 1);
    V v_v_2440 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_t_2441 = heff_intShow(heff_strLength(heff_dup(v_l_2439)));
    V v_t_2442 = heff_strAppend(v_t_2441, heff_strAppend(((V)&g_heff_2eserial_2eencodeTermF_24s774_str15), v_l_2439));
    V v_rest_2443 = heff_tag(TAG_Cons, 2, (V[]){v_t_2442, (g_heff_2eserial_2eencodeTermF_24s774(v_v_2440, v_rest_241))});
    V v_t_2444 = (g_heff_2eserial_2eencodeTermF_24s774(v_e2_2438, v_rest_2443));
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str16), v_t_2444});
  }
  case TAG_SIs: {
    V v_e2_2445 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str17), (g_heff_2eserial_2eencodeTermF_24s774(v_e2_2445, v_rest_241))});
  }
  case TAG_SOpaque: {
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str18), v_rest_241});
  }
  case TAG_SAbandon: {
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str19), v_rest_241});
  }
  case TAG_SRec: {
    V v_e2_2446 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str20), (g_heff_2eserial_2eencodeTermF_24s774(v_e2_2446, v_rest_241))});
  }
  case TAG_SFix: {
    V v_t_2447 = heff_field(v_e_240, 0);
    V v_b_2448 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24SFix = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_rest_2455;
    switch (heff_tag_of(v_b_2448)) {
    case TAG_MkAbs: {
      V v_x_2449 = heff_field(v_b_2448, 0);
      V v_e_2450 = heff_field(v_b_2448, 1);
      V v_ru_24b_2448_24MkAbs = heff_take_reuse_n(v_b_2448, 3ULL, 2);
      V v_t_2451 = heff_intShow(heff_strLength(heff_dup(v_x_2449)));
      V v_t_2452 = heff_strAppend(v_t_2451, heff_strAppend(((V)&g_heff_2eserial_2eencodeTermF_24s774_str21), v_x_2449));
      V v_t_2453 = heff_tag_at(v_ru_24e_240_24SFix, TAG_Cons, 2, (V[]){v_t_2452, (g_heff_2eserial_2eencodeTermF_24s774(v_e_2450, v_rest_241))});
      v_rest_2455 = heff_tag_at(v_ru_24b_2448_24MkAbs, TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str22), v_t_2453});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2454 = heff_field(v_b_2448, 0);
      heff_take_n(v_b_2448, 1ULL, 1);
      v_rest_2455 = heff_tag_at(v_ru_24e_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str23), (g_heff_2eserial_2eencodeTermF_24s774(v_e_2454, v_rest_241))});
      break;
    }
    default: heff_nomatch(v_b_2448);
    }
    V v_t_2456 = ({ V a_0 = v_t_2447; V a_1 = v_rest_2455; V r_ = (g_heff_2eserial_2eencodeTypeF_24s780(a_0, a_1)); heff_drop(v_t_2447); r_; });
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str24), v_t_2456});
  }
  case TAG_SImplicit: {
    V v_x_2457 = heff_field(v_e_240, 0);
    V v_e2_2458 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24SImplicit = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2459 = heff_intShow(heff_strLength(heff_dup(v_x_2457)));
    V v_t_2460 = heff_strAppend(v_t_2459, heff_strAppend(((V)&g_heff_2eserial_2eencodeTermF_24s774_str25), v_x_2457));
    V v_t_2461 = heff_tag_at(v_ru_24e_240_24SImplicit, TAG_Cons, 2, (V[]){v_t_2460, (g_heff_2eserial_2eencodeTermF_24s774(v_e2_2458, v_rest_241))});
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str26), v_t_2461});
  }
  case TAG_SPrim: {
    V v_x_2462 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V v_t_2463 = heff_intShow(heff_strLength(heff_dup(v_x_2462)));
    V v_t_2464 = heff_strAppend(v_t_2463, heff_strAppend(((V)&g_heff_2eserial_2eencodeTermF_24s774_str27), v_x_2462));
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str28), heff_tag(TAG_Cons, 2, (V[]){v_t_2464, v_rest_241})});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_e_240, 0ULL, 3);
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str29), v_rest_241});
  }
  case TAG_SLitInt: {
    V v_i_2468 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V v_s_2469 = heff_intShow(v_i_2468);
    V v_t_2470 = heff_intShow(heff_strLength(heff_dup(v_s_2469)));
    V v_t_2471 = heff_strAppend(v_t_2470, heff_strAppend(((V)&g_heff_2eserial_2eencodeTermF_24s774_str30), v_s_2469));
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str31), heff_tag(TAG_Cons, 2, (V[]){v_t_2471, v_rest_241})});
  }
  case TAG_SLitFloat: {
    V v_x_2472 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V v_s_2473 = heff_floatShow(v_x_2472);
    V v_t_2474 = heff_intShow(heff_strLength(heff_dup(v_s_2473)));
    V v_t_2475 = heff_strAppend(v_t_2474, heff_strAppend(((V)&g_heff_2eserial_2eencodeTermF_24s774_str32), v_s_2473));
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str33), heff_tag(TAG_Cons, 2, (V[]){v_t_2475, v_rest_241})});
  }
  case TAG_SLitString: {
    V v_s_2476 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V v_t_2477 = heff_intShow(heff_strLength(heff_dup(v_s_2476)));
    V v_t_2478 = heff_strAppend(v_t_2477, heff_strAppend(((V)&g_heff_2eserial_2eencodeTermF_24s774_str34), v_s_2476));
    return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eserial_2eencodeTermF_24s774_str35), heff_tag(TAG_Cons, 2, (V[]){v_t_2478, v_rest_241})});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2eserial_2eencodeTermF_24s774_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2eencodeTermF_24s774(a[0], a[1]);
}
Clo g_heff_2eserial_2ewordEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2ewordEnd_entry, 2, 0};

V g_heff_2eserial_2ewordEnd(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    return v_i_241;
  }
  case TAG_False: {
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(32LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_s_240);
      return v_i_241;
    }
    case TAG_False: {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eserial_2ewordEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2ewordEnd(a[0], a[1]);
}
Clo g_heff_2eserial_2etakeWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2etakeWord_entry, 2, 0};

V g_heff_2eserial_2etakeWord(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_False: {
    V v_t_243 = (g_heff_2eserial_2ewordEnd(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_x_244 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), v_t_243);
    V v_i_245 = (g_heff_2eserial_2ewordEnd(heff_dup(v_s_240), v_i_241));
    V v_t_246 = heff_intLt(heff_dup(v_i_245), heff_strLength(heff_dup(v_s_240)));
    V v_i_248;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = heff_intEq(heff_strCharCode(v_s_240, heff_dup(v_i_245)), MK_INT(32LL));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        v_i_248 = heff_intAdd(v_i_245, MK_INT(1LL));
        break;
      }
      case TAG_False: {
        v_i_248 = v_i_245;
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_s_240);
      v_i_248 = v_i_245;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_244, v_i_248})});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eserial_2etakeWord_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2etakeWord(a[0], a[1]);
}
Clo g_heff_2eserial_2ecolonAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2ecolonAt_entry, 2, 0};

V g_heff_2eserial_2ecolonAt(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    return v_i_241;
  }
  case TAG_False: {
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(58LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_s_240);
      return v_i_241;
    }
    case TAG_False: {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eserial_2ecolonAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2ecolonAt(a[0], a[1]);
}
Clo g_heff_2eserial_2etakeStrAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2etakeStrAt_entry, 3, 0};

V g_heff_2eserial_2etakeStrAt(V v_s_240, V v_j_241, V v_n_242) {
top: ;
  V v_t_243 = heff_intLt(heff_strLength(heff_dup(v_s_240)), heff_intAdd(heff_dup(v_j_241), heff_dup(v_n_242)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_j_241);
    heff_drop(v_n_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_False: {
    V v_i_244 = heff_intAdd(heff_dup(v_j_241), heff_dup(v_n_242));
    V v_t_245 = heff_intLt(heff_dup(v_i_244), heff_strLength(heff_dup(v_s_240)));
    V v_i_247;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_244)), MK_INT(32LL));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        v_i_247 = heff_intAdd(v_i_244, MK_INT(1LL));
        break;
      }
      case TAG_False: {
        v_i_247 = v_i_244;
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      break;
    }
    case TAG_False: {
      v_i_247 = v_i_244;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_248 = heff_strSlice(v_s_240, heff_dup(v_j_241), heff_intAdd(v_j_241, v_n_242));
    return heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_248, v_i_247})});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eserial_2etakeStrAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2etakeStrAt(a[0], a[1], a[2]);
}
Clo g_heff_2eserial_2etakeStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2etakeStr_entry, 2, 0};

V g_heff_2eserial_2etakeStr(V v_s_240, V v_i_241) {
top: ;
  V v_a_242 = (g_heff_2eserial_2ecolonAt(heff_dup(v_s_240), heff_dup(v_i_241)));
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_s_240)), v_a_242);
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_False: {
    V v_t_244 = (g_heff_2eserial_2ecolonAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_245 = heff_intEq(v_t_244, heff_dup(v_i_241));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_246 = (g_heff_2eserial_2ecolonAt(heff_dup(v_s_240), heff_dup(v_i_241)));
      V v_t_247 = (g_heff_2eserial_2ecolonAt(heff_dup(v_s_240), heff_dup(v_i_241)));
      V v_t_248 = (g_heff_2esurface_2eintOfText(heff_strSlice(heff_dup(v_s_240), v_i_241, v_t_247)));
      return (g_heff_2eserial_2etakeStrAt(v_s_240, heff_intAdd(v_t_246, MK_INT(1LL)), v_t_248));
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eserial_2etakeStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2etakeStr(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2etakePlicity_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2etakePlicity_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2etakePlicity_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {50}};
Clo g_heff_2eserial_2etakePlicity_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2etakePlicity_entry, 2, 0};

V g_heff_2eserial_2etakePlicity(V v_s_240, V v_i_241) {
top: ;
  V v_x1_242 = (g_heff_2eserial_2etakeWord(v_s_240, v_i_241));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Just = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_243, 0);
      V v_i_245 = heff_field(v_x11_243, 1);
      V v_ru_24x11_243_24MkPair = heff_take_reuse_n(v_x11_243, 3ULL, 2);
      V v_t_246 = heff_strEq(heff_dup(v_x_244), ((V)&g_heff_2eserial_2etakePlicity_str0));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_x_244);
        V v_t_247 = heff_tag_at(v_ru_24x11_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Expl), v_i_245});
        return heff_tag_at(v_ru_24x1_242_24Just, TAG_Just, 1, (V[]){v_t_247});
      }
      case TAG_False: {
        V v_t_248 = heff_strEq(heff_dup(v_x_244), ((V)&g_heff_2eserial_2etakePlicity_str1));
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          heff_drop(v_x_244);
          V v_t_249 = heff_tag_at(v_ru_24x11_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Impl), v_i_245});
          return heff_tag_at(v_ru_24x1_242_24Just, TAG_Just, 1, (V[]){v_t_249});
        }
        case TAG_False: {
          V v_t_2410 = heff_strEq(v_x_244, ((V)&g_heff_2eserial_2etakePlicity_str2));
          switch (heff_tag_of(v_t_2410)) {
          case TAG_True: {
            V v_t_2411 = heff_tag_at(v_ru_24x11_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Inst), v_i_245});
            return heff_tag_at(v_ru_24x1_242_24Just, TAG_Just, 1, (V[]){v_t_2411});
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24x1_242_24Just, 1);
            heff_drop(v_i_245);
            heff_drop_cell(v_ru_24x11_243_24MkPair, 2);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2410);
          }
        }
        default: return heff_nomatch(v_t_248);
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2eserial_2etakePlicity_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2etakePlicity(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2etakeLevel_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2etakeLevel_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2etakeLevel_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {50}};
Clo g_heff_2eserial_2etakeLevel_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2etakeLevel_entry, 2, 0};

V g_heff_2eserial_2etakeLevel(V v_s_240, V v_i_241) {
top: ;
  V v_x1_242 = (g_heff_2eserial_2etakeWord(v_s_240, v_i_241));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Just = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_243, 0);
      V v_i_245 = heff_field(v_x11_243, 1);
      V v_ru_24x11_243_24MkPair = heff_take_reuse_n(v_x11_243, 3ULL, 2);
      V v_t_246 = heff_strEq(heff_dup(v_x_244), ((V)&g_heff_2eserial_2etakeLevel_str0));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_x_244);
        V v_t_247 = heff_tag_at(v_ru_24x11_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Small), v_i_245});
        return heff_tag_at(v_ru_24x1_242_24Just, TAG_Just, 1, (V[]){v_t_247});
      }
      case TAG_False: {
        V v_t_248 = heff_strEq(heff_dup(v_x_244), ((V)&g_heff_2eserial_2etakeLevel_str1));
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          heff_drop(v_x_244);
          V v_t_249 = heff_tag_at(v_ru_24x11_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Large), v_i_245});
          return heff_tag_at(v_ru_24x1_242_24Just, TAG_Just, 1, (V[]){v_t_249});
        }
        case TAG_False: {
          V v_t_2410 = heff_strEq(v_x_244, ((V)&g_heff_2eserial_2etakeLevel_str2));
          switch (heff_tag_of(v_t_2410)) {
          case TAG_True: {
            V v_t_2411 = heff_tag_at(v_ru_24x11_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_TopL), v_i_245});
            return heff_tag_at(v_ru_24x1_242_24Just, TAG_Just, 1, (V[]){v_t_2411});
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24x1_242_24Just, 1);
            heff_drop(v_i_245);
            heff_drop_cell(v_ru_24x11_243_24MkPair, 2);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2410);
          }
        }
        default: return heff_nomatch(v_t_248);
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2eserial_2etakeLevel_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2etakeLevel(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2etakeAbs_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2etakeAbs_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2eserial_2etakeAbs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2etakeAbs_entry, 3, 0};

V g_heff_2eserial_2etakeAbs(V v_s_240, V v_f_241, V v_i_242) {
top: ;
  V v_x1_243 = (g_heff_2eserial_2etakeWord(heff_dup(v_s_240), v_i_242));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    heff_drop(v_f_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24Just = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x11_244, 0);
      V v_i_246 = heff_field(v_x11_244, 1);
      V v_ru_24x11_244_24MkPair = heff_take_reuse_n(v_x11_244, 3ULL, 2);
      V v_t_247 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2etakeAbs_str0));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_x_245);
        V v_x1_248 = (g_heff_2eserial_2etakeStr(v_s_240, v_i_246));
        switch (heff_tag_of(v_x1_248)) {
        case TAG_Nothing: {
          heff_drop(v_f_241);
          heff_drop_cell(v_ru_24x1_243_24Just, 1);
          heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x11_249 = heff_field(v_x1_248, 0);
          heff_take_n(v_x1_248, 1ULL, 1);
          switch (heff_tag_of(v_x11_249)) {
          case TAG_MkPair: {
            V v_x_2410 = heff_field(v_x11_249, 0);
            V v_i_2411 = heff_field(v_x11_249, 1);
            heff_take_n(v_x11_249, 3ULL, 2);
            V v_x1_2412 = heff_tr(heff_apply(v_f_241, 1, (V[]){v_i_2411}));
            switch (heff_tag_of(v_x1_2412)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x1_243_24Just, 1);
              heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
              heff_drop(v_x_2410);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x11_2413 = heff_field(v_x1_2412, 0);
              heff_take_n(v_x1_2412, 1ULL, 1);
              switch (heff_tag_of(v_x11_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x11_2413, 0);
                V v_i_2415 = heff_field(v_x11_2413, 1);
                heff_take_n(v_x11_2413, 3ULL, 2);
                V v_t_2416 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkAbs, 2, (V[]){v_x_2410, v_x_2414}), v_i_2415});
                return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_2416});
              }
              default: return heff_nomatch(v_x11_2413);
              }
            }
            default: return heff_nomatch(v_x1_2412);
            }
          }
          default: return heff_nomatch(v_x11_249);
          }
        }
        default: return heff_nomatch(v_x1_248);
        }
      }
      case TAG_False: {
        heff_drop(v_s_240);
        V v_t_2417 = heff_strEq(v_x_245, ((V)&g_heff_2eserial_2etakeAbs_str1));
        switch (heff_tag_of(v_t_2417)) {
        case TAG_True: {
          V v_x1_2418 = heff_tr(heff_apply(v_f_241, 1, (V[]){v_i_246}));
          switch (heff_tag_of(v_x1_2418)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x1_243_24Just, 1);
            heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x11_2419 = heff_field(v_x1_2418, 0);
            V v_ru_24x1_2418_24Just = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
            switch (heff_tag_of(v_x11_2419)) {
            case TAG_MkPair: {
              V v_x_2420 = heff_field(v_x11_2419, 0);
              V v_i_2421 = heff_field(v_x11_2419, 1);
              heff_take_n(v_x11_2419, 3ULL, 2);
              V v_t_2422 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_243_24Just, TAG_AbsConst, 1, (V[]){v_x_2420}), v_i_2421});
              return heff_tag_at(v_ru_24x1_2418_24Just, TAG_Just, 1, (V[]){v_t_2422});
            }
            default: return heff_nomatch(v_x11_2419);
            }
          }
          default: return heff_nomatch(v_x1_2418);
          }
        }
        case TAG_False: {
          heff_drop(v_f_241);
          heff_drop_cell(v_ru_24x1_243_24Just, 1);
          heff_drop(v_i_246);
          heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_t_2417);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2eserial_2etakeAbs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2etakeAbs(a[0], a[1], a[2]);
}
Clo g_heff_2eserial_2etakeManyG_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2etakeManyG_entry, 3, 0};

V g_heff_2eserial_2etakeManyG(V v_f_240, V v_n_241, V v_i_242) {
top: ;
  V v_t_243 = heff_intLe(heff_dup(v_n_241), MK_INT(0LL));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_f_240);
    heff_drop(v_n_241);
    V v_t_244 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_242});
    return heff_tag(TAG_Just, 1, (V[]){v_t_244});
  }
  case TAG_False: {
    V v_x1_245 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_i_242}));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nothing: {
      heff_drop(v_f_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x11_246 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24Just = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      switch (heff_tag_of(v_x11_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x11_246, 0);
        V v_i_248 = heff_field(v_x11_246, 1);
        V v_ru_24x11_246_24MkPair = heff_take_reuse_n(v_x11_246, 3ULL, 2);
        V v_x1_249 = (g_heff_2eserial_2etakeManyG(v_f_240, heff_intSub(v_n_241, MK_INT(1LL)), v_i_248));
        switch (heff_tag_of(v_x1_249)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x1_245_24Just, 1);
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x11_246_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x11_2410 = heff_field(v_x1_249, 0);
          heff_take_n(v_x1_249, 1ULL, 1);
          switch (heff_tag_of(v_x11_2410)) {
          case TAG_MkPair: {
            V v_x_2411 = heff_field(v_x11_2410, 0);
            V v_i_2412 = heff_field(v_x11_2410, 1);
            heff_take_n(v_x11_2410, 3ULL, 2);
            V v_t_2413 = heff_tag_at(v_ru_24x11_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_i_2412});
            return heff_tag_at(v_ru_24x1_245_24Just, TAG_Just, 1, (V[]){v_t_2413});
          }
          default: return heff_nomatch(v_x11_2410);
          }
        }
        default: return heff_nomatch(v_x1_249);
        }
      }
      default: return heff_nomatch(v_x11_246);
      }
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eserial_2etakeManyG_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2etakeManyG(a[0], a[1], a[2]);
}
V g_heff_2eserial_2etakeDict_lam0(V self, V *args);
Clo g_heff_2eserial_2etakeDict_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2etakeDict_entry, 3, 0};

V g_heff_2eserial_2etakeDict(V v_s_240, V v_f_241, V v_i_242) {
top: ;
  V v_x1_243 = (g_heff_2eserial_2etakeWord(heff_dup(v_s_240), v_i_242));
  V v_x1_248;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nothing: {
    v_x1_248 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24Just = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x11_244, 0);
      V v_i_246 = heff_field(v_x11_244, 1);
      heff_take_n(v_x11_244, 3ULL, 2);
      V v_x_247 = (g_heff_2esurface_2eintOfText(v_x_245));
      v_x1_248 = heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_247, v_i_246})});
      break;
    }
    default: heff_nomatch(v_x11_244);
    }
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_x1_2422;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    heff_drop(v_f_241);
    v_x1_2422 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x11_249, 0);
      V v_i_2411 = heff_field(v_x11_249, 1);
      heff_take_n(v_x11_249, 3ULL, 2);
      v_x1_2422 = (g_heff_2eserial_2etakeManyG(heff_clo(g_heff_2eserial_2etakeDict_lam0, 1, 2, (V[]){v_s_240, v_f_241}), v_x_2410, v_i_2411));
      break;
    }
    default: heff_nomatch(v_x11_249);
    }
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_2423 = heff_field(v_x1_2422, 0);
    V v_ru_24x1_2422_24Just = heff_take_reuse_n(v_x1_2422, 1ULL, 1);
    switch (heff_tag_of(v_x11_2423)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_field(v_x11_2423, 0);
      V v_i_2425 = heff_field(v_x11_2423, 1);
      heff_take_n(v_x11_2423, 3ULL, 2);
      V v_t_2426 = (g_prelude_2emap_24s5(heff_dup(v_x_2424)));
      V v_t_2427 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_x_2424));
      V v_t_2428 = (g_prelude_2emap_24s6(v_x_2424));
      V v_x_2429 = heff_rec(3, shape_153_35_368, (V[]){heff_arrayFromList(v_t_2426), v_t_2427, heff_arrayFromList(v_t_2428)});
      return heff_tag_at(v_ru_24x1_2422_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2429, v_i_2425})});
    }
    default: return heff_nomatch(v_x11_2423);
    }
  }
  default: return heff_nomatch(v_x1_2422);
  }
}
V g_heff_2eserial_2etakeDict_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2etakeDict(a[0], a[1], a[2]);
}
V g_heff_2eserial_2etakeDict_lam0(V self, V *args) {
  V v_j_2412 = args[0];
  V v_s_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2413 = (g_heff_2eserial_2etakeStr(v_s_240, v_j_2412));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Nothing: {
    heff_drop(v_f_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_ru_24x1_2413_24Just = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x11_2414, 0);
      V v_i_2416 = heff_field(v_x11_2414, 1);
      V v_ru_24x11_2414_24MkPair = heff_take_reuse_n(v_x11_2414, 3ULL, 2);
      V v_x1_2417 = heff_tr(heff_apply(v_f_241, 1, (V[]){v_i_2416}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_2413_24Just, 1);
        heff_drop(v_x_2415);
        heff_drop_cell(v_ru_24x11_2414_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        heff_take_n(v_x1_2417, 1ULL, 1);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x11_2418, 0);
          V v_i_2420 = heff_field(v_x11_2418, 1);
          heff_take_n(v_x11_2418, 3ULL, 2);
          V v_t_2421 = heff_tag_at(v_ru_24x11_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2415, v_x_2419}), v_i_2420});
          return heff_tag_at(v_ru_24x1_2413_24Just, TAG_Just, 1, (V[]){v_t_2421});
        }
        default: return heff_nomatch(v_x11_2418);
        }
      }
      default: return heff_nomatch(v_x1_2417);
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_heff_2eserial_2etakeAlt_lam0(V self, V *args);
Clo g_heff_2eserial_2etakeAlt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2etakeAlt_entry, 3, 0};

V g_heff_2eserial_2etakeAlt(V v_s_240, V v_k_241, V v_i_242) {
top: ;
  V v_x1_243 = (g_heff_2eserial_2etakeWord(heff_dup(v_s_240), v_i_242));
  V v_x1_248;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nothing: {
    v_x1_248 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24Just = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x11_244, 0);
      V v_i_246 = heff_field(v_x11_244, 1);
      heff_take_n(v_x11_244, 3ULL, 2);
      V v_x_247 = (g_heff_2esurface_2eintOfText(v_x_245));
      v_x1_248 = heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_247, v_i_246})});
      break;
    }
    default: heff_nomatch(v_x11_244);
    }
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_x1_2413;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    v_x1_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x11_249, 0);
      V v_i_2411 = heff_field(v_x11_249, 1);
      heff_take_n(v_x11_249, 3ULL, 2);
      v_x1_2413 = (g_heff_2eserial_2etakeManyG(heff_clo(g_heff_2eserial_2etakeAlt_lam0, 1, 1, (V[]){v_s_240}), v_x_2410, v_i_2411));
      break;
    }
    default: heff_nomatch(v_x11_249);
    }
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Nothing: {
    heff_drop(v_k_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_ru_24x1_2413_24Just = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x11_2414, 0);
      V v_i_2416 = heff_field(v_x11_2414, 1);
      V v_ru_24x11_2414_24MkPair = heff_take_reuse_n(v_x11_2414, 3ULL, 2);
      V v_x1_2417 = heff_tr(heff_apply(heff_get(v_k_241, LBL_el), 1, (V[]){v_i_2416}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_2413_24Just, 1);
        heff_drop(v_x_2415);
        heff_drop_cell(v_ru_24x11_2414_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        heff_take_n(v_x1_2417, 1ULL, 1);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x11_2418, 0);
          V v_i_2420 = heff_field(v_x11_2418, 1);
          heff_take_n(v_x11_2418, 3ULL, 2);
          V v_t_2421 = heff_tag_at(v_ru_24x11_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2415), v_x_2419});
          return heff_tag_at(v_ru_24x1_2413_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2421, v_i_2420})});
        }
        default: return heff_nomatch(v_x11_2418);
        }
      }
      default: return heff_nomatch(v_x1_2417);
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_heff_2eserial_2etakeAlt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2etakeAlt(a[0], a[1], a[2]);
}
V g_heff_2eserial_2etakeAlt_lam0(V self, V *args) {
  V v_j_2412 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eserial_2etakeStr(v_s_240, v_j_2412));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 111, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 108, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 97, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {112, 114, 106}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {109, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2edecodeTermF_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {111, 112, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 98, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str13 = {{0x80000000u, K_STR, 0}, 3, 3, {114, 101, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {102, 105, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str15 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 109, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str16 = {{0x80000000u, K_STR, 0}, 3, 3, {112, 114, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str17 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str18 = {{0x80000000u, K_STR, 0}, 3, 3, {102, 108, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTermF_str19 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 116, 114}};
V g_heff_2eserial_2edecodeTermF_lam0(V self, V *args);
V g_heff_2eserial_2edecodeTermF_lam1(V self, V *args);
V g_heff_2eserial_2edecodeTermF_lam2(V self, V *args);
V g_heff_2eserial_2edecodeTermF_lam3(V self, V *args);
V g_heff_2eserial_2edecodeTermF_lam4(V self, V *args);
Clo g_heff_2eserial_2edecodeTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2edecodeTermF_entry, 3, 0};

V g_heff_2eserial_2edecodeTermF(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  V v_x1_243 = (g_heff_2eserial_2etakeWord(heff_dup(v_s_241), v_i_242));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nothing: {
    heff_drop(v_k_240);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24Just = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x11_244, 0);
      V v_i_246 = heff_field(v_x11_244, 1);
      V v_ru_24x11_244_24MkPair = heff_take_reuse_n(v_x11_244, 3ULL, 2);
      V v_t_247 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str0));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_k_240);
        heff_drop(v_x_245);
        V v_x1_248 = (g_heff_2eserial_2etakeWord(v_s_241, v_i_246));
        V v_x1_2413;
        switch (heff_tag_of(v_x1_248)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x1_243_24Just, 1);
          v_x1_2413 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x11_249 = heff_field(v_x1_248, 0);
          heff_take_n(v_x1_248, 1ULL, 1);
          switch (heff_tag_of(v_x11_249)) {
          case TAG_MkPair: {
            V v_x_2410 = heff_field(v_x11_249, 0);
            V v_i_2411 = heff_field(v_x11_249, 1);
            heff_take_n(v_x11_249, 3ULL, 2);
            V v_x_2412 = (g_heff_2esurface_2eintOfText(v_x_2410));
            v_x1_2413 = heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2412, v_i_2411})});
            break;
          }
          default: heff_nomatch(v_x11_249);
          }
          break;
        }
        default: heff_nomatch(v_x1_248);
        }
        switch (heff_tag_of(v_x1_2413)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x11_2414 = heff_field(v_x1_2413, 0);
          V v_ru_24x1_2413_24Just = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
          switch (heff_tag_of(v_x11_2414)) {
          case TAG_MkPair: {
            V v_x_2415 = heff_field(v_x11_2414, 0);
            V v_i_2416 = heff_field(v_x11_2414, 1);
            heff_take_n(v_x11_2414, 3ULL, 2);
            V v_t_2417 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_SLocal, 1, (V[]){v_x_2415}), v_i_2416});
            return heff_tag_at(v_ru_24x1_2413_24Just, TAG_Just, 1, (V[]){v_t_2417});
          }
          default: return heff_nomatch(v_x11_2414);
          }
        }
        default: return heff_nomatch(v_x1_2413);
        }
      }
      case TAG_False: {
        V v_t_2418 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str1));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_True: {
          heff_drop(v_k_240);
          heff_drop(v_x_245);
          V v_x1_2419 = (g_heff_2eserial_2etakeStr(v_s_241, v_i_246));
          switch (heff_tag_of(v_x1_2419)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x1_243_24Just, 1);
            heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x11_2420 = heff_field(v_x1_2419, 0);
            V v_ru_24x1_2419_24Just = heff_take_reuse_n(v_x1_2419, 1ULL, 1);
            switch (heff_tag_of(v_x11_2420)) {
            case TAG_MkPair: {
              V v_x_2421 = heff_field(v_x11_2420, 0);
              V v_i_2422 = heff_field(v_x11_2420, 1);
              heff_take_n(v_x11_2420, 3ULL, 2);
              V v_t_2423 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_243_24Just, TAG_SGlobal, 1, (V[]){v_x_2421}), v_i_2422});
              return heff_tag_at(v_ru_24x1_2419_24Just, TAG_Just, 1, (V[]){v_t_2423});
            }
            default: return heff_nomatch(v_x11_2420);
            }
          }
          default: return heff_nomatch(v_x1_2419);
          }
        }
        case TAG_False: {
          V v_t_2424 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str2));
          switch (heff_tag_of(v_t_2424)) {
          case TAG_True: {
            heff_drop(v_s_241);
            heff_drop(v_x_245);
            V v_x1_2425 = heff_tr(heff_apply(heff_get(v_k_240, LBL_ty), 1, (V[]){v_i_246}));
            switch (heff_tag_of(v_x1_2425)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x1_243_24Just, 1);
              heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x11_2426 = heff_field(v_x1_2425, 0);
              V v_ru_24x1_2425_24Just = heff_take_reuse_n(v_x1_2425, 1ULL, 1);
              switch (heff_tag_of(v_x11_2426)) {
              case TAG_MkPair: {
                V v_x_2427 = heff_field(v_x11_2426, 0);
                V v_i_2428 = heff_field(v_x11_2426, 1);
                heff_take_n(v_x11_2426, 3ULL, 2);
                V v_t_2429 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_243_24Just, TAG_SCode, 1, (V[]){v_x_2427}), v_i_2428});
                return heff_tag_at(v_ru_24x1_2425_24Just, TAG_Just, 1, (V[]){v_t_2429});
              }
              default: return heff_nomatch(v_x11_2426);
              }
            }
            default: return heff_nomatch(v_x1_2425);
            }
          }
          case TAG_False: {
            V v_t_2430 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str3));
            switch (heff_tag_of(v_t_2430)) {
            case TAG_True: {
              heff_drop(v_s_241);
              heff_drop(v_x_245);
              V v_x1_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_el), 1, (V[]){v_i_246}));
              switch (heff_tag_of(v_x1_2431)) {
              case TAG_Nothing: {
                heff_drop(v_k_240);
                heff_drop_cell(v_ru_24x1_243_24Just, 1);
                heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x11_2432 = heff_field(v_x1_2431, 0);
                heff_take_n(v_x1_2431, 1ULL, 1);
                switch (heff_tag_of(v_x11_2432)) {
                case TAG_MkPair: {
                  V v_x_2433 = heff_field(v_x11_2432, 0);
                  V v_i_2434 = heff_field(v_x11_2432, 1);
                  heff_take_n(v_x11_2432, 3ULL, 2);
                  V v_x1_2435 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_i_2434}));
                  switch (heff_tag_of(v_x1_2435)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x1_243_24Just, 1);
                    heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                    heff_drop(v_x_2433);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x11_2436 = heff_field(v_x1_2435, 0);
                    heff_take_n(v_x1_2435, 1ULL, 1);
                    switch (heff_tag_of(v_x11_2436)) {
                    case TAG_MkPair: {
                      V v_x_2437 = heff_field(v_x11_2436, 0);
                      V v_i_2438 = heff_field(v_x11_2436, 1);
                      heff_take_n(v_x11_2436, 3ULL, 2);
                      V v_t_2439 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_SApp, 2, (V[]){v_x_2433, v_x_2437}), v_i_2438});
                      return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_2439});
                    }
                    default: return heff_nomatch(v_x11_2436);
                    }
                  }
                  default: return heff_nomatch(v_x1_2435);
                  }
                }
                default: return heff_nomatch(v_x11_2432);
                }
              }
              default: return heff_nomatch(v_x1_2431);
              }
            }
            case TAG_False: {
              V v_t_2440 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str4));
              switch (heff_tag_of(v_t_2440)) {
              case TAG_True: {
                heff_drop(v_x_245);
                V v_x1_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_ty), 1, (V[]){v_i_246}));
                switch (heff_tag_of(v_x1_2441)) {
                case TAG_Nothing: {
                  heff_drop(v_k_240);
                  heff_drop(v_s_241);
                  heff_drop_cell(v_ru_24x1_243_24Just, 1);
                  heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_x11_2442 = heff_field(v_x1_2441, 0);
                  heff_take_n(v_x1_2441, 1ULL, 1);
                  switch (heff_tag_of(v_x11_2442)) {
                  case TAG_MkPair: {
                    V v_x_2443 = heff_field(v_x11_2442, 0);
                    V v_i_2444 = heff_field(v_x11_2442, 1);
                    heff_take_n(v_x11_2442, 3ULL, 2);
                    V v_x1_2446 = (g_heff_2eserial_2etakeAbs(v_s_241, heff_clo(g_heff_2eserial_2edecodeTermF_lam0, 1, 1, (V[]){v_k_240}), v_i_2444));
                    switch (heff_tag_of(v_x1_2446)) {
                    case TAG_Nothing: {
                      heff_drop_cell(v_ru_24x1_243_24Just, 1);
                      heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                      heff_drop(v_x_2443);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x11_2447 = heff_field(v_x1_2446, 0);
                      heff_take_n(v_x1_2446, 1ULL, 1);
                      switch (heff_tag_of(v_x11_2447)) {
                      case TAG_MkPair: {
                        V v_x_2448 = heff_field(v_x11_2447, 0);
                        V v_i_2449 = heff_field(v_x11_2447, 1);
                        heff_take_n(v_x11_2447, 3ULL, 2);
                        V v_t_2450 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_SLam, 2, (V[]){v_x_2443, v_x_2448}), v_i_2449});
                        return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_2450});
                      }
                      default: return heff_nomatch(v_x11_2447);
                      }
                    }
                    default: return heff_nomatch(v_x1_2446);
                    }
                  }
                  default: return heff_nomatch(v_x11_2442);
                  }
                }
                default: return heff_nomatch(v_x1_2441);
                }
              }
              case TAG_False: {
                V v_t_2451 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str5));
                switch (heff_tag_of(v_t_2451)) {
                case TAG_True: {
                  heff_drop(v_x_245);
                  V v_x1_2453 = (g_heff_2eserial_2etakeDict(v_s_241, heff_clo(g_heff_2eserial_2edecodeTermF_lam1, 1, 1, (V[]){v_k_240}), v_i_246));
                  switch (heff_tag_of(v_x1_2453)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x1_243_24Just, 1);
                    heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x11_2454 = heff_field(v_x1_2453, 0);
                    V v_ru_24x1_2453_24Just = heff_take_reuse_n(v_x1_2453, 1ULL, 1);
                    switch (heff_tag_of(v_x11_2454)) {
                    case TAG_MkPair: {
                      V v_x_2455 = heff_field(v_x11_2454, 0);
                      V v_i_2456 = heff_field(v_x11_2454, 1);
                      heff_take_n(v_x11_2454, 3ULL, 2);
                      V v_t_2457 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_243_24Just, TAG_SCons, 1, (V[]){v_x_2455}), v_i_2456});
                      return heff_tag_at(v_ru_24x1_2453_24Just, TAG_Just, 1, (V[]){v_t_2457});
                    }
                    default: return heff_nomatch(v_x11_2454);
                    }
                  }
                  default: return heff_nomatch(v_x1_2453);
                  }
                }
                case TAG_False: {
                  V v_t_2458 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str6));
                  switch (heff_tag_of(v_t_2458)) {
                  case TAG_True: {
                    heff_drop(v_x_245);
                    V v_x1_2459 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_i_246}));
                    switch (heff_tag_of(v_x1_2459)) {
                    case TAG_Nothing: {
                      heff_drop(v_s_241);
                      heff_drop_cell(v_ru_24x1_243_24Just, 1);
                      heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x11_2460 = heff_field(v_x1_2459, 0);
                      heff_take_n(v_x1_2459, 1ULL, 1);
                      switch (heff_tag_of(v_x11_2460)) {
                      case TAG_MkPair: {
                        V v_x_2461 = heff_field(v_x11_2460, 0);
                        V v_i_2462 = heff_field(v_x11_2460, 1);
                        heff_take_n(v_x11_2460, 3ULL, 2);
                        V v_x1_2463 = (g_heff_2eserial_2etakeStr(v_s_241, v_i_2462));
                        switch (heff_tag_of(v_x1_2463)) {
                        case TAG_Nothing: {
                          heff_drop_cell(v_ru_24x1_243_24Just, 1);
                          heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                          heff_drop(v_x_2461);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x11_2464 = heff_field(v_x1_2463, 0);
                          heff_take_n(v_x1_2463, 1ULL, 1);
                          switch (heff_tag_of(v_x11_2464)) {
                          case TAG_MkPair: {
                            V v_x_2465 = heff_field(v_x11_2464, 0);
                            V v_i_2466 = heff_field(v_x11_2464, 1);
                            heff_take_n(v_x11_2464, 3ULL, 2);
                            V v_t_2467 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_SProj, 2, (V[]){v_x_2461, v_x_2465}), v_i_2466});
                            return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_2467});
                          }
                          default: return heff_nomatch(v_x11_2464);
                          }
                        }
                        default: return heff_nomatch(v_x1_2463);
                        }
                      }
                      default: return heff_nomatch(v_x11_2460);
                      }
                    }
                    default: return heff_nomatch(v_x1_2459);
                    }
                  }
                  case TAG_False: {
                    V v_t_2468 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str7));
                    switch (heff_tag_of(v_t_2468)) {
                    case TAG_True: {
                      heff_drop(v_x_245);
                      V v_x1_2469 = (g_heff_2eserial_2etakeStr(heff_dup(v_s_241), v_i_246));
                      switch (heff_tag_of(v_x1_2469)) {
                      case TAG_Nothing: {
                        heff_drop(v_k_240);
                        heff_drop(v_s_241);
                        heff_drop_cell(v_ru_24x1_243_24Just, 1);
                        heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x11_2470 = heff_field(v_x1_2469, 0);
                        V v_ru_24x1_2469_24Just = heff_take_reuse_n(v_x1_2469, 1ULL, 1);
                        switch (heff_tag_of(v_x11_2470)) {
                        case TAG_MkPair: {
                          V v_x_2471 = heff_field(v_x11_2470, 0);
                          V v_i_2472 = heff_field(v_x11_2470, 1);
                          heff_take_n(v_x11_2470, 3ULL, 2);
                          V v_x1_2473 = (g_heff_2eserial_2etakeWord(v_s_241, v_i_2472));
                          V v_x1_2478;
                          switch (heff_tag_of(v_x1_2473)) {
                          case TAG_Nothing: {
                            heff_drop_cell(v_ru_24x1_243_24Just, 1);
                            v_x1_2478 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Just: {
                            V v_x11_2474 = heff_field(v_x1_2473, 0);
                            heff_take_n(v_x1_2473, 1ULL, 1);
                            switch (heff_tag_of(v_x11_2474)) {
                            case TAG_MkPair: {
                              V v_x_2475 = heff_field(v_x11_2474, 0);
                              V v_i_2476 = heff_field(v_x11_2474, 1);
                              heff_take_n(v_x11_2474, 3ULL, 2);
                              V v_x_2477 = (g_heff_2esurface_2eintOfText(v_x_2475));
                              v_x1_2478 = heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2477, v_i_2476})});
                              break;
                            }
                            default: heff_nomatch(v_x11_2474);
                            }
                            break;
                          }
                          default: heff_nomatch(v_x1_2473);
                          }
                          V v_x1_2483;
                          switch (heff_tag_of(v_x1_2478)) {
                          case TAG_Nothing: {
                            heff_drop(v_k_240);
                            v_x1_2483 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Just: {
                            V v_x11_2479 = heff_field(v_x1_2478, 0);
                            heff_take_n(v_x1_2478, 1ULL, 1);
                            switch (heff_tag_of(v_x11_2479)) {
                            case TAG_MkPair: {
                              V v_x_2480 = heff_field(v_x11_2479, 0);
                              V v_i_2481 = heff_field(v_x11_2479, 1);
                              heff_take_n(v_x11_2479, 3ULL, 2);
                              v_x1_2483 = (g_heff_2eserial_2etakeManyG(heff_clo(g_heff_2eserial_2edecodeTermF_lam2, 1, 1, (V[]){v_k_240}), v_x_2480, v_i_2481));
                              break;
                            }
                            default: heff_nomatch(v_x11_2479);
                            }
                            break;
                          }
                          default: heff_nomatch(v_x1_2478);
                          }
                          switch (heff_tag_of(v_x1_2483)) {
                          case TAG_Nothing: {
                            heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                            heff_drop_cell(v_ru_24x1_2469_24Just, 1);
                            heff_drop(v_x_2471);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x11_2484 = heff_field(v_x1_2483, 0);
                            heff_take_n(v_x1_2483, 1ULL, 1);
                            switch (heff_tag_of(v_x11_2484)) {
                            case TAG_MkPair: {
                              V v_x_2485 = heff_field(v_x11_2484, 0);
                              V v_i_2486 = heff_field(v_x11_2484, 1);
                              heff_take_n(v_x11_2484, 3ULL, 2);
                              V v_t_2487 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_STag, 2, (V[]){v_x_2471, heff_arrayFromList(v_x_2485)});
                              return heff_tag_at(v_ru_24x1_2469_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2487, v_i_2486})});
                            }
                            default: return heff_nomatch(v_x11_2484);
                            }
                          }
                          default: return heff_nomatch(v_x1_2483);
                          }
                        }
                        default: return heff_nomatch(v_x11_2470);
                        }
                      }
                      default: return heff_nomatch(v_x1_2469);
                      }
                    }
                    case TAG_False: {
                      V v_t_2488 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str8));
                      switch (heff_tag_of(v_t_2488)) {
                      case TAG_True: {
                        heff_drop(v_x_245);
                        V v_x1_2489 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_el), 1, (V[]){v_i_246}));
                        switch (heff_tag_of(v_x1_2489)) {
                        case TAG_Nothing: {
                          heff_drop(v_k_240);
                          heff_drop(v_s_241);
                          heff_drop_cell(v_ru_24x1_243_24Just, 1);
                          heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x11_2490 = heff_field(v_x1_2489, 0);
                          heff_take_n(v_x1_2489, 1ULL, 1);
                          switch (heff_tag_of(v_x11_2490)) {
                          case TAG_MkPair: {
                            V v_x_2491 = heff_field(v_x11_2490, 0);
                            V v_i_2492 = heff_field(v_x11_2490, 1);
                            heff_take_n(v_x11_2490, 3ULL, 2);
                            V v_x1_2494 = (g_heff_2eserial_2etakeDict(heff_dup(v_s_241), heff_clo(g_heff_2eserial_2edecodeTermF_lam3, 1, 2, (V[]){v_s_241, v_k_240}), v_i_2492));
                            switch (heff_tag_of(v_x1_2494)) {
                            case TAG_Nothing: {
                              heff_drop_cell(v_ru_24x1_243_24Just, 1);
                              heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                              heff_drop(v_x_2491);
                              return NTAG(TAG_Nothing);
                            }
                            case TAG_Just: {
                              V v_x11_2495 = heff_field(v_x1_2494, 0);
                              heff_take_n(v_x1_2494, 1ULL, 1);
                              switch (heff_tag_of(v_x11_2495)) {
                              case TAG_MkPair: {
                                V v_x_2496 = heff_field(v_x11_2495, 0);
                                V v_i_2497 = heff_field(v_x11_2495, 1);
                                heff_take_n(v_x11_2495, 3ULL, 2);
                                V v_t_2498 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_SMatch, 2, (V[]){v_x_2491, v_x_2496}), v_i_2497});
                                return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_2498});
                              }
                              default: return heff_nomatch(v_x11_2495);
                              }
                            }
                            default: return heff_nomatch(v_x1_2494);
                            }
                          }
                          default: return heff_nomatch(v_x11_2490);
                          }
                        }
                        default: return heff_nomatch(v_x1_2489);
                        }
                      }
                      case TAG_False: {
                        V v_t_2499 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str9));
                        switch (heff_tag_of(v_t_2499)) {
                        case TAG_True: {
                          heff_drop(v_x_245);
                          V v_x1_24100 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_el), 1, (V[]){v_i_246}));
                          switch (heff_tag_of(v_x1_24100)) {
                          case TAG_Nothing: {
                            heff_drop(v_k_240);
                            heff_drop(v_s_241);
                            heff_drop_cell(v_ru_24x1_243_24Just, 1);
                            heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x11_24101 = heff_field(v_x1_24100, 0);
                            heff_take_n(v_x1_24100, 1ULL, 1);
                            switch (heff_tag_of(v_x11_24101)) {
                            case TAG_MkPair: {
                              V v_x_24102 = heff_field(v_x11_24101, 0);
                              V v_i_24103 = heff_field(v_x11_24101, 1);
                              heff_take_n(v_x11_24101, 3ULL, 2);
                              V v_x1_24104 = (g_heff_2eserial_2etakeStr(v_s_241, v_i_24103));
                              switch (heff_tag_of(v_x1_24104)) {
                              case TAG_Nothing: {
                                heff_drop(v_k_240);
                                heff_drop_cell(v_ru_24x1_243_24Just, 1);
                                heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                                heff_drop(v_x_24102);
                                return NTAG(TAG_Nothing);
                              }
                              case TAG_Just: {
                                V v_x11_24105 = heff_field(v_x1_24104, 0);
                                heff_take_n(v_x1_24104, 1ULL, 1);
                                switch (heff_tag_of(v_x11_24105)) {
                                case TAG_MkPair: {
                                  V v_x_24106 = heff_field(v_x11_24105, 0);
                                  V v_i_24107 = heff_field(v_x11_24105, 1);
                                  heff_take_n(v_x11_24105, 3ULL, 2);
                                  V v_x1_24108 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_i_24107}));
                                  switch (heff_tag_of(v_x1_24108)) {
                                  case TAG_Nothing: {
                                    heff_drop_cell(v_ru_24x1_243_24Just, 1);
                                    heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                                    heff_drop(v_x_24102);
                                    heff_drop(v_x_24106);
                                    return NTAG(TAG_Nothing);
                                  }
                                  case TAG_Just: {
                                    V v_x11_24109 = heff_field(v_x1_24108, 0);
                                    heff_take_n(v_x1_24108, 1ULL, 1);
                                    switch (heff_tag_of(v_x11_24109)) {
                                    case TAG_MkPair: {
                                      V v_x_24110 = heff_field(v_x11_24109, 0);
                                      V v_i_24111 = heff_field(v_x11_24109, 1);
                                      heff_take_n(v_x11_24109, 3ULL, 2);
                                      V v_t_24112 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_SSpecialize, 3, (V[]){v_x_24102, v_x_24106, v_x_24110}), v_i_24111});
                                      return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_24112});
                                    }
                                    default: return heff_nomatch(v_x11_24109);
                                    }
                                  }
                                  default: return heff_nomatch(v_x1_24108);
                                  }
                                }
                                default: return heff_nomatch(v_x11_24105);
                                }
                              }
                              default: return heff_nomatch(v_x1_24104);
                              }
                            }
                            default: return heff_nomatch(v_x11_24101);
                            }
                          }
                          default: return heff_nomatch(v_x1_24100);
                          }
                        }
                        case TAG_False: {
                          V v_t_24113 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str10));
                          switch (heff_tag_of(v_t_24113)) {
                          case TAG_True: {
                            heff_drop(v_s_241);
                            heff_drop(v_x_245);
                            V v_x1_24114 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_i_246}));
                            switch (heff_tag_of(v_x1_24114)) {
                            case TAG_Nothing: {
                              heff_drop_cell(v_ru_24x1_243_24Just, 1);
                              heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                              return NTAG(TAG_Nothing);
                            }
                            case TAG_Just: {
                              V v_x11_24115 = heff_field(v_x1_24114, 0);
                              V v_ru_24x1_24114_24Just = heff_take_reuse_n(v_x1_24114, 1ULL, 1);
                              switch (heff_tag_of(v_x11_24115)) {
                              case TAG_MkPair: {
                                V v_x_24116 = heff_field(v_x11_24115, 0);
                                V v_i_24117 = heff_field(v_x11_24115, 1);
                                heff_take_n(v_x11_24115, 3ULL, 2);
                                V v_t_24118 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_243_24Just, TAG_SIs, 1, (V[]){v_x_24116}), v_i_24117});
                                return heff_tag_at(v_ru_24x1_24114_24Just, TAG_Just, 1, (V[]){v_t_24118});
                              }
                              default: return heff_nomatch(v_x11_24115);
                              }
                            }
                            default: return heff_nomatch(v_x1_24114);
                            }
                          }
                          case TAG_False: {
                            V v_t_24119 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str11));
                            switch (heff_tag_of(v_t_24119)) {
                            case TAG_True: {
                              heff_drop(v_k_240);
                              heff_drop(v_s_241);
                              heff_drop(v_x_245);
                              V v_t_24120 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_SOpaque), v_i_246});
                              return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_24120});
                            }
                            case TAG_False: {
                              V v_t_24121 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str12));
                              switch (heff_tag_of(v_t_24121)) {
                              case TAG_True: {
                                heff_drop(v_k_240);
                                heff_drop(v_s_241);
                                heff_drop(v_x_245);
                                V v_t_24122 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_SAbandon), v_i_246});
                                return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_24122});
                              }
                              case TAG_False: {
                                V v_t_24123 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str13));
                                switch (heff_tag_of(v_t_24123)) {
                                case TAG_True: {
                                  heff_drop(v_s_241);
                                  heff_drop(v_x_245);
                                  V v_x1_24124 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_i_246}));
                                  switch (heff_tag_of(v_x1_24124)) {
                                  case TAG_Nothing: {
                                    heff_drop_cell(v_ru_24x1_243_24Just, 1);
                                    heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                                    return NTAG(TAG_Nothing);
                                  }
                                  case TAG_Just: {
                                    V v_x11_24125 = heff_field(v_x1_24124, 0);
                                    V v_ru_24x1_24124_24Just = heff_take_reuse_n(v_x1_24124, 1ULL, 1);
                                    switch (heff_tag_of(v_x11_24125)) {
                                    case TAG_MkPair: {
                                      V v_x_24126 = heff_field(v_x11_24125, 0);
                                      V v_i_24127 = heff_field(v_x11_24125, 1);
                                      heff_take_n(v_x11_24125, 3ULL, 2);
                                      V v_t_24128 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_243_24Just, TAG_SRec, 1, (V[]){v_x_24126}), v_i_24127});
                                      return heff_tag_at(v_ru_24x1_24124_24Just, TAG_Just, 1, (V[]){v_t_24128});
                                    }
                                    default: return heff_nomatch(v_x11_24125);
                                    }
                                  }
                                  default: return heff_nomatch(v_x1_24124);
                                  }
                                }
                                case TAG_False: {
                                  V v_t_24129 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str14));
                                  switch (heff_tag_of(v_t_24129)) {
                                  case TAG_True: {
                                    heff_drop(v_x_245);
                                    V v_x1_24130 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_ty), 1, (V[]){v_i_246}));
                                    switch (heff_tag_of(v_x1_24130)) {
                                    case TAG_Nothing: {
                                      heff_drop(v_k_240);
                                      heff_drop(v_s_241);
                                      heff_drop_cell(v_ru_24x1_243_24Just, 1);
                                      heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                                      return NTAG(TAG_Nothing);
                                    }
                                    case TAG_Just: {
                                      V v_x11_24131 = heff_field(v_x1_24130, 0);
                                      heff_take_n(v_x1_24130, 1ULL, 1);
                                      switch (heff_tag_of(v_x11_24131)) {
                                      case TAG_MkPair: {
                                        V v_x_24132 = heff_field(v_x11_24131, 0);
                                        V v_i_24133 = heff_field(v_x11_24131, 1);
                                        heff_take_n(v_x11_24131, 3ULL, 2);
                                        V v_x1_24135 = (g_heff_2eserial_2etakeAbs(v_s_241, heff_clo(g_heff_2eserial_2edecodeTermF_lam4, 1, 1, (V[]){v_k_240}), v_i_24133));
                                        switch (heff_tag_of(v_x1_24135)) {
                                        case TAG_Nothing: {
                                          heff_drop_cell(v_ru_24x1_243_24Just, 1);
                                          heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                                          heff_drop(v_x_24132);
                                          return NTAG(TAG_Nothing);
                                        }
                                        case TAG_Just: {
                                          V v_x11_24136 = heff_field(v_x1_24135, 0);
                                          heff_take_n(v_x1_24135, 1ULL, 1);
                                          switch (heff_tag_of(v_x11_24136)) {
                                          case TAG_MkPair: {
                                            V v_x_24137 = heff_field(v_x11_24136, 0);
                                            V v_i_24138 = heff_field(v_x11_24136, 1);
                                            heff_take_n(v_x11_24136, 3ULL, 2);
                                            V v_t_24139 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_SFix, 2, (V[]){v_x_24132, v_x_24137}), v_i_24138});
                                            return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_24139});
                                          }
                                          default: return heff_nomatch(v_x11_24136);
                                          }
                                        }
                                        default: return heff_nomatch(v_x1_24135);
                                        }
                                      }
                                      default: return heff_nomatch(v_x11_24131);
                                      }
                                    }
                                    default: return heff_nomatch(v_x1_24130);
                                    }
                                  }
                                  case TAG_False: {
                                    V v_t_24140 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str15));
                                    switch (heff_tag_of(v_t_24140)) {
                                    case TAG_True: {
                                      heff_drop(v_x_245);
                                      V v_x1_24141 = (g_heff_2eserial_2etakeStr(v_s_241, v_i_246));
                                      switch (heff_tag_of(v_x1_24141)) {
                                      case TAG_Nothing: {
                                        heff_drop(v_k_240);
                                        heff_drop_cell(v_ru_24x1_243_24Just, 1);
                                        heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                                        return NTAG(TAG_Nothing);
                                      }
                                      case TAG_Just: {
                                        V v_x11_24142 = heff_field(v_x1_24141, 0);
                                        heff_take_n(v_x1_24141, 1ULL, 1);
                                        switch (heff_tag_of(v_x11_24142)) {
                                        case TAG_MkPair: {
                                          V v_x_24143 = heff_field(v_x11_24142, 0);
                                          V v_i_24144 = heff_field(v_x11_24142, 1);
                                          heff_take_n(v_x11_24142, 3ULL, 2);
                                          V v_x1_24145 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_i_24144}));
                                          switch (heff_tag_of(v_x1_24145)) {
                                          case TAG_Nothing: {
                                            heff_drop_cell(v_ru_24x1_243_24Just, 1);
                                            heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                                            heff_drop(v_x_24143);
                                            return NTAG(TAG_Nothing);
                                          }
                                          case TAG_Just: {
                                            V v_x11_24146 = heff_field(v_x1_24145, 0);
                                            heff_take_n(v_x1_24145, 1ULL, 1);
                                            switch (heff_tag_of(v_x11_24146)) {
                                            case TAG_MkPair: {
                                              V v_x_24147 = heff_field(v_x11_24146, 0);
                                              V v_i_24148 = heff_field(v_x11_24146, 1);
                                              heff_take_n(v_x11_24146, 3ULL, 2);
                                              V v_t_24149 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_SImplicit, 2, (V[]){v_x_24143, v_x_24147}), v_i_24148});
                                              return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_24149});
                                            }
                                            default: return heff_nomatch(v_x11_24146);
                                            }
                                          }
                                          default: return heff_nomatch(v_x1_24145);
                                          }
                                        }
                                        default: return heff_nomatch(v_x11_24142);
                                        }
                                      }
                                      default: return heff_nomatch(v_x1_24141);
                                      }
                                    }
                                    case TAG_False: {
                                      heff_drop(v_k_240);
                                      V v_t_24150 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str16));
                                      switch (heff_tag_of(v_t_24150)) {
                                      case TAG_True: {
                                        heff_drop(v_x_245);
                                        V v_x1_24151 = (g_heff_2eserial_2etakeStr(v_s_241, v_i_246));
                                        switch (heff_tag_of(v_x1_24151)) {
                                        case TAG_Nothing: {
                                          heff_drop_cell(v_ru_24x1_243_24Just, 1);
                                          heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                                          return NTAG(TAG_Nothing);
                                        }
                                        case TAG_Just: {
                                          V v_x11_24152 = heff_field(v_x1_24151, 0);
                                          V v_ru_24x1_24151_24Just = heff_take_reuse_n(v_x1_24151, 1ULL, 1);
                                          switch (heff_tag_of(v_x11_24152)) {
                                          case TAG_MkPair: {
                                            V v_x_24153 = heff_field(v_x11_24152, 0);
                                            V v_i_24154 = heff_field(v_x11_24152, 1);
                                            heff_take_n(v_x11_24152, 3ULL, 2);
                                            V v_t_24155 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_243_24Just, TAG_SPrim, 1, (V[]){v_x_24153}), v_i_24154});
                                            return heff_tag_at(v_ru_24x1_24151_24Just, TAG_Just, 1, (V[]){v_t_24155});
                                          }
                                          default: return heff_nomatch(v_x11_24152);
                                          }
                                        }
                                        default: return heff_nomatch(v_x1_24151);
                                        }
                                      }
                                      case TAG_False: {
                                        V v_t_24156 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str17));
                                        switch (heff_tag_of(v_t_24156)) {
                                        case TAG_True: {
                                          heff_drop(v_x_245);
                                          V v_x1_24157 = (g_heff_2eserial_2etakeStr(v_s_241, v_i_246));
                                          switch (heff_tag_of(v_x1_24157)) {
                                          case TAG_Nothing: {
                                            heff_drop_cell(v_ru_24x1_243_24Just, 1);
                                            heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                                            return NTAG(TAG_Nothing);
                                          }
                                          case TAG_Just: {
                                            V v_x11_24158 = heff_field(v_x1_24157, 0);
                                            V v_ru_24x1_24157_24Just = heff_take_reuse_n(v_x1_24157, 1ULL, 1);
                                            switch (heff_tag_of(v_x11_24158)) {
                                            case TAG_MkPair: {
                                              V v_x_24159 = heff_field(v_x11_24158, 0);
                                              V v_i_24160 = heff_field(v_x11_24158, 1);
                                              heff_take_n(v_x11_24158, 3ULL, 2);
                                              V v_x_24161 = heff_tag_at(v_ru_24x1_243_24Just, TAG_SLitInt, 1, (V[]){(g_heff_2esurface_2eintOfText(v_x_24159))});
                                              return heff_tag_at(v_ru_24x1_24157_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){v_x_24161, v_i_24160})});
                                            }
                                            default: return heff_nomatch(v_x11_24158);
                                            }
                                          }
                                          default: return heff_nomatch(v_x1_24157);
                                          }
                                        }
                                        case TAG_False: {
                                          V v_t_24162 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTermF_str18));
                                          switch (heff_tag_of(v_t_24162)) {
                                          case TAG_True: {
                                            heff_drop(v_x_245);
                                            V v_x1_24163 = (g_heff_2eserial_2etakeStr(v_s_241, v_i_246));
                                            switch (heff_tag_of(v_x1_24163)) {
                                            case TAG_Nothing: {
                                              heff_drop_cell(v_ru_24x1_243_24Just, 1);
                                              heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                                              return NTAG(TAG_Nothing);
                                            }
                                            case TAG_Just: {
                                              V v_x11_24164 = heff_field(v_x1_24163, 0);
                                              V v_ru_24x1_24163_24Just = heff_take_reuse_n(v_x1_24163, 1ULL, 1);
                                              switch (heff_tag_of(v_x11_24164)) {
                                              case TAG_MkPair: {
                                                V v_x_24165 = heff_field(v_x11_24164, 0);
                                                V v_i_24166 = heff_field(v_x11_24164, 1);
                                                heff_take_n(v_x11_24164, 3ULL, 2);
                                                V v_x_24167 = heff_tag_at(v_ru_24x1_243_24Just, TAG_SLitFloat, 1, (V[]){(g_heff_2esurface_2efloatOfText(v_x_24165))});
                                                return heff_tag_at(v_ru_24x1_24163_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){v_x_24167, v_i_24166})});
                                              }
                                              default: return heff_nomatch(v_x11_24164);
                                              }
                                            }
                                            default: return heff_nomatch(v_x1_24163);
                                            }
                                          }
                                          case TAG_False: {
                                            V v_t_24168 = heff_strEq(v_x_245, ((V)&g_heff_2eserial_2edecodeTermF_str19));
                                            switch (heff_tag_of(v_t_24168)) {
                                            case TAG_True: {
                                              V v_x1_24169 = (g_heff_2eserial_2etakeStr(v_s_241, v_i_246));
                                              switch (heff_tag_of(v_x1_24169)) {
                                              case TAG_Nothing: {
                                                heff_drop_cell(v_ru_24x1_243_24Just, 1);
                                                heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                                                return NTAG(TAG_Nothing);
                                              }
                                              case TAG_Just: {
                                                V v_x11_24170 = heff_field(v_x1_24169, 0);
                                                V v_ru_24x1_24169_24Just = heff_take_reuse_n(v_x1_24169, 1ULL, 1);
                                                switch (heff_tag_of(v_x11_24170)) {
                                                case TAG_MkPair: {
                                                  V v_x_24171 = heff_field(v_x11_24170, 0);
                                                  V v_i_24172 = heff_field(v_x11_24170, 1);
                                                  heff_take_n(v_x11_24170, 3ULL, 2);
                                                  V v_t_24173 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_243_24Just, TAG_SLitString, 1, (V[]){v_x_24171}), v_i_24172});
                                                  return heff_tag_at(v_ru_24x1_24169_24Just, TAG_Just, 1, (V[]){v_t_24173});
                                                }
                                                default: return heff_nomatch(v_x11_24170);
                                                }
                                              }
                                              default: return heff_nomatch(v_x1_24169);
                                              }
                                            }
                                            case TAG_False: {
                                              heff_drop(v_s_241);
                                              heff_drop_cell(v_ru_24x1_243_24Just, 1);
                                              heff_drop(v_i_246);
                                              heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                                              return NTAG(TAG_Nothing);
                                            }
                                            default: return heff_nomatch(v_t_24168);
                                            }
                                          }
                                          default: return heff_nomatch(v_t_24162);
                                          }
                                        }
                                        default: return heff_nomatch(v_t_24156);
                                        }
                                      }
                                      default: return heff_nomatch(v_t_24150);
                                      }
                                    }
                                    default: return heff_nomatch(v_t_24140);
                                    }
                                  }
                                  default: return heff_nomatch(v_t_24129);
                                  }
                                }
                                default: return heff_nomatch(v_t_24123);
                                }
                              }
                              default: return heff_nomatch(v_t_24121);
                              }
                            }
                            default: return heff_nomatch(v_t_24119);
                            }
                          }
                          default: return heff_nomatch(v_t_24113);
                          }
                        }
                        default: return heff_nomatch(v_t_2499);
                        }
                      }
                      default: return heff_nomatch(v_t_2488);
                      }
                    }
                    default: return heff_nomatch(v_t_2468);
                    }
                  }
                  default: return heff_nomatch(v_t_2458);
                  }
                }
                default: return heff_nomatch(v_t_2451);
                }
              }
              default: return heff_nomatch(v_t_2440);
              }
            }
            default: return heff_nomatch(v_t_2430);
            }
          }
          default: return heff_nomatch(v_t_2424);
          }
        }
        default: return heff_nomatch(v_t_2418);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2eserial_2edecodeTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2edecodeTermF(a[0], a[1], a[2]);
}
V g_heff_2eserial_2edecodeTermF_lam0(V self, V *args) {
  V v_j3_2445 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_k_240, LBL_el);
  args[0] = v_j3_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eserial_2edecodeTermF_lam1(V self, V *args) {
  V v_j2_2452 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_k_240, LBL_el);
  args[0] = v_j2_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eserial_2edecodeTermF_lam2(V self, V *args) {
  V v_j3_2482 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_k_240, LBL_el);
  args[0] = v_j3_2482;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eserial_2edecodeTermF_lam3(V self, V *args) {
  V v_j3_2493 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eserial_2etakeAlt(v_s_241, v_k_240, v_j3_2493));
}
V g_heff_2eserial_2edecodeTermF_lam4(V self, V *args) {
  V v_j3_24134 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_k_240, LBL_el);
  args[0] = v_j3_24134;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2edecodeTypeF_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {117}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2edecodeTypeF_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eserial_2edecodeTypeF_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2edecodeTypeF_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2edecodeTypeF_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {102, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2edecodeTypeF_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2edecodeTypeF_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {115, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eserial_2edecodeTypeF_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2edecodeTypeF_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {112, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2edecodeTypeF_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {112, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2edecodeTypeF_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {112, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eserial_2edecodeTypeF_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {112, 97}};
V g_heff_2eserial_2edecodeTypeF_lam0(V self, V *args);
V g_heff_2eserial_2edecodeTypeF_lam1(V self, V *args);
V g_heff_2eserial_2edecodeTypeF_lam2(V self, V *args);
V g_heff_2eserial_2edecodeTypeF_lam4(V self, V *args);
V g_heff_2eserial_2edecodeTypeF_lam3(V self, V *args);
Clo g_heff_2eserial_2edecodeTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2edecodeTypeF_entry, 3, 0};

V g_heff_2eserial_2edecodeTypeF(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  V v_x1_243 = (g_heff_2eserial_2etakeWord(heff_dup(v_s_241), v_i_242));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nothing: {
    heff_drop(v_k_240);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24Just = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x11_244, 0);
      V v_i_246 = heff_field(v_x11_244, 1);
      V v_ru_24x11_244_24MkPair = heff_take_reuse_n(v_x11_244, 3ULL, 2);
      V v_t_247 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTypeF_str0));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_k_240);
        heff_drop(v_x_245);
        V v_x1_248 = (g_heff_2eserial_2etakeWord(v_s_241, v_i_246));
        switch (heff_tag_of(v_x1_248)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x1_243_24Just, 1);
          heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x11_249 = heff_field(v_x1_248, 0);
          V v_ru_24x1_248_24Just = heff_take_reuse_n(v_x1_248, 1ULL, 1);
          switch (heff_tag_of(v_x11_249)) {
          case TAG_MkPair: {
            V v_x_2410 = heff_field(v_x11_249, 0);
            V v_i_2411 = heff_field(v_x11_249, 1);
            heff_take_n(v_x11_249, 3ULL, 2);
            V v_t_2412 = heff_strEq(heff_dup(v_x_2410), ((V)&g_heff_2eserial_2edecodeTypeF_str1));
            switch (heff_tag_of(v_t_2412)) {
            case TAG_True: {
              heff_drop(v_x_2410);
              V v_t_2413 = heff_tag_at(v_ru_24x1_243_24Just, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
              return heff_tag_at(v_ru_24x1_248_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_i_2411})});
            }
            case TAG_False: {
              V v_t_2414 = heff_strEq(v_x_2410, ((V)&g_heff_2eserial_2edecodeTypeF_str2));
              switch (heff_tag_of(v_t_2414)) {
              case TAG_True: {
                V v_t_2415 = heff_tag_at(v_ru_24x1_243_24Just, TAG_SU, 1, (V[]){NTAG(TAG_LargeU)});
                return heff_tag_at(v_ru_24x1_248_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){v_t_2415, v_i_2411})});
              }
              case TAG_False: {
                heff_drop_cell(v_ru_24x1_243_24Just, 1);
                heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                heff_drop_cell(v_ru_24x1_248_24Just, 1);
                heff_drop(v_i_2411);
                return NTAG(TAG_Nothing);
              }
              default: return heff_nomatch(v_t_2414);
              }
            }
            default: return heff_nomatch(v_t_2412);
            }
          }
          default: return heff_nomatch(v_x11_249);
          }
        }
        default: return heff_nomatch(v_x1_248);
        }
      }
      case TAG_False: {
        V v_t_2416 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTypeF_str3));
        switch (heff_tag_of(v_t_2416)) {
        case TAG_True: {
          heff_drop(v_s_241);
          heff_drop(v_x_245);
          V v_x1_2417 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_i_246}));
          switch (heff_tag_of(v_x1_2417)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x1_243_24Just, 1);
            heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x11_2418 = heff_field(v_x1_2417, 0);
            V v_ru_24x1_2417_24Just = heff_take_reuse_n(v_x1_2417, 1ULL, 1);
            switch (heff_tag_of(v_x11_2418)) {
            case TAG_MkPair: {
              V v_x_2419 = heff_field(v_x11_2418, 0);
              V v_i_2420 = heff_field(v_x11_2418, 1);
              heff_take_n(v_x11_2418, 3ULL, 2);
              V v_t_2421 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_243_24Just, TAG_SDecode, 1, (V[]){v_x_2419}), v_i_2420});
              return heff_tag_at(v_ru_24x1_2417_24Just, TAG_Just, 1, (V[]){v_t_2421});
            }
            default: return heff_nomatch(v_x11_2418);
            }
          }
          default: return heff_nomatch(v_x1_2417);
          }
        }
        case TAG_False: {
          V v_t_2422 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTypeF_str4));
          switch (heff_tag_of(v_t_2422)) {
          case TAG_True: {
            heff_drop(v_x_245);
            V v_x1_2423 = (g_heff_2eserial_2etakeLevel(heff_dup(v_s_241), v_i_246));
            switch (heff_tag_of(v_x1_2423)) {
            case TAG_Nothing: {
              heff_drop(v_k_240);
              heff_drop(v_s_241);
              heff_drop_cell(v_ru_24x1_243_24Just, 1);
              heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x11_2424 = heff_field(v_x1_2423, 0);
              heff_take_n(v_x1_2423, 1ULL, 1);
              switch (heff_tag_of(v_x11_2424)) {
              case TAG_MkPair: {
                V v_x_2425 = heff_field(v_x11_2424, 0);
                V v_i_2426 = heff_field(v_x11_2424, 1);
                heff_take_n(v_x11_2424, 3ULL, 2);
                V v_x1_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_ty), 1, (V[]){v_i_2426}));
                switch (heff_tag_of(v_x1_2427)) {
                case TAG_Nothing: {
                  heff_drop(v_k_240);
                  heff_drop(v_s_241);
                  heff_drop_cell(v_ru_24x1_243_24Just, 1);
                  heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                  heff_drop(v_x_2425);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_x11_2428 = heff_field(v_x1_2427, 0);
                  heff_take_n(v_x1_2427, 1ULL, 1);
                  switch (heff_tag_of(v_x11_2428)) {
                  case TAG_MkPair: {
                    V v_x_2429 = heff_field(v_x11_2428, 0);
                    V v_i_2430 = heff_field(v_x11_2428, 1);
                    heff_take_n(v_x11_2428, 3ULL, 2);
                    V v_x1_2432 = (g_heff_2eserial_2etakeAbs(heff_dup(v_s_241), heff_clo(g_heff_2eserial_2edecodeTypeF_lam0, 1, 1, (V[]){v_k_240}), v_i_2430));
                    switch (heff_tag_of(v_x1_2432)) {
                    case TAG_Nothing: {
                      heff_drop(v_s_241);
                      heff_drop_cell(v_ru_24x1_243_24Just, 1);
                      heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                      heff_drop(v_x_2425);
                      heff_drop(v_x_2429);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x11_2433 = heff_field(v_x1_2432, 0);
                      heff_take_n(v_x1_2432, 1ULL, 1);
                      switch (heff_tag_of(v_x11_2433)) {
                      case TAG_MkPair: {
                        V v_x_2434 = heff_field(v_x11_2433, 0);
                        V v_i_2435 = heff_field(v_x11_2433, 1);
                        heff_take_n(v_x11_2433, 3ULL, 2);
                        V v_x1_2436 = (g_heff_2eserial_2etakePlicity(v_s_241, v_i_2435));
                        switch (heff_tag_of(v_x1_2436)) {
                        case TAG_Nothing: {
                          heff_drop_cell(v_ru_24x1_243_24Just, 1);
                          heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                          heff_drop(v_x_2425);
                          heff_drop(v_x_2429);
                          heff_drop(v_x_2434);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x11_2437 = heff_field(v_x1_2436, 0);
                          heff_take_n(v_x1_2436, 1ULL, 1);
                          switch (heff_tag_of(v_x11_2437)) {
                          case TAG_MkPair: {
                            V v_x_2438 = heff_field(v_x11_2437, 0);
                            V v_i_2439 = heff_field(v_x11_2437, 1);
                            heff_take_n(v_x11_2437, 3ULL, 2);
                            V v_t_2440 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_SFunction, 4, (V[]){v_x_2425, v_x_2429, v_x_2434, v_x_2438}), v_i_2439});
                            return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_2440});
                          }
                          default: return heff_nomatch(v_x11_2437);
                          }
                        }
                        default: return heff_nomatch(v_x1_2436);
                        }
                      }
                      default: return heff_nomatch(v_x11_2433);
                      }
                    }
                    default: return heff_nomatch(v_x1_2432);
                    }
                  }
                  default: return heff_nomatch(v_x11_2428);
                  }
                }
                default: return heff_nomatch(v_x1_2427);
                }
              }
              default: return heff_nomatch(v_x11_2424);
              }
            }
            default: return heff_nomatch(v_x1_2423);
            }
          }
          case TAG_False: {
            V v_t_2441 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTypeF_str5));
            switch (heff_tag_of(v_t_2441)) {
            case TAG_True: {
              heff_drop(v_x_245);
              V v_x1_2442 = (g_heff_2eserial_2etakeLevel(heff_dup(v_s_241), v_i_246));
              switch (heff_tag_of(v_x1_2442)) {
              case TAG_Nothing: {
                heff_drop(v_k_240);
                heff_drop(v_s_241);
                heff_drop_cell(v_ru_24x1_243_24Just, 1);
                heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x11_2443 = heff_field(v_x1_2442, 0);
                heff_take_n(v_x1_2442, 1ULL, 1);
                switch (heff_tag_of(v_x11_2443)) {
                case TAG_MkPair: {
                  V v_x_2444 = heff_field(v_x11_2443, 0);
                  V v_i_2445 = heff_field(v_x11_2443, 1);
                  heff_take_n(v_x11_2443, 3ULL, 2);
                  V v_x1_2447 = (g_heff_2eserial_2etakeDict(heff_dup(v_s_241), heff_clo(g_heff_2eserial_2edecodeTypeF_lam1, 1, 1, (V[]){heff_dup(v_k_240)}), v_i_2445));
                  switch (heff_tag_of(v_x1_2447)) {
                  case TAG_Nothing: {
                    heff_drop(v_k_240);
                    heff_drop(v_s_241);
                    heff_drop_cell(v_ru_24x1_243_24Just, 1);
                    heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                    heff_drop(v_x_2444);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x11_2448 = heff_field(v_x1_2447, 0);
                    heff_take_n(v_x1_2447, 1ULL, 1);
                    switch (heff_tag_of(v_x11_2448)) {
                    case TAG_MkPair: {
                      V v_x_2449 = heff_field(v_x11_2448, 0);
                      V v_i_2450 = heff_field(v_x11_2448, 1);
                      heff_take_n(v_x11_2448, 3ULL, 2);
                      V v_x1_2452 = (g_heff_2eserial_2etakeDict(v_s_241, heff_clo(g_heff_2eserial_2edecodeTypeF_lam2, 1, 1, (V[]){v_k_240}), v_i_2450));
                      switch (heff_tag_of(v_x1_2452)) {
                      case TAG_Nothing: {
                        heff_drop_cell(v_ru_24x1_243_24Just, 1);
                        heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                        heff_drop(v_x_2444);
                        heff_drop(v_x_2449);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x11_2453 = heff_field(v_x1_2452, 0);
                        heff_take_n(v_x1_2452, 1ULL, 1);
                        switch (heff_tag_of(v_x11_2453)) {
                        case TAG_MkPair: {
                          V v_x_2454 = heff_field(v_x11_2453, 0);
                          V v_i_2455 = heff_field(v_x11_2453, 1);
                          heff_take_n(v_x11_2453, 3ULL, 2);
                          V v_t_2456 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_SRecord, 3, (V[]){v_x_2444, v_x_2449, v_x_2454}), v_i_2455});
                          return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_2456});
                        }
                        default: return heff_nomatch(v_x11_2453);
                        }
                      }
                      default: return heff_nomatch(v_x1_2452);
                      }
                    }
                    default: return heff_nomatch(v_x11_2448);
                    }
                  }
                  default: return heff_nomatch(v_x1_2447);
                  }
                }
                default: return heff_nomatch(v_x11_2443);
                }
              }
              default: return heff_nomatch(v_x1_2442);
              }
            }
            case TAG_False: {
              V v_t_2457 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTypeF_str6));
              switch (heff_tag_of(v_t_2457)) {
              case TAG_True: {
                heff_drop(v_x_245);
                V v_x1_2474 = (g_heff_2eserial_2etakeDict(heff_dup(v_s_241), heff_clo(g_heff_2eserial_2edecodeTypeF_lam3, 1, 2, (V[]){v_s_241, v_k_240}), v_i_246));
                switch (heff_tag_of(v_x1_2474)) {
                case TAG_Nothing: {
                  heff_drop_cell(v_ru_24x1_243_24Just, 1);
                  heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_x11_2475 = heff_field(v_x1_2474, 0);
                  V v_ru_24x1_2474_24Just = heff_take_reuse_n(v_x1_2474, 1ULL, 1);
                  switch (heff_tag_of(v_x11_2475)) {
                  case TAG_MkPair: {
                    V v_x_2476 = heff_field(v_x11_2475, 0);
                    V v_i_2477 = heff_field(v_x11_2475, 1);
                    heff_take_n(v_x11_2475, 3ULL, 2);
                    V v_t_2478 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_243_24Just, TAG_SSum, 1, (V[]){v_x_2476}), v_i_2477});
                    return heff_tag_at(v_ru_24x1_2474_24Just, TAG_Just, 1, (V[]){v_t_2478});
                  }
                  default: return heff_nomatch(v_x11_2475);
                  }
                }
                default: return heff_nomatch(v_x1_2474);
                }
              }
              case TAG_False: {
                heff_drop(v_s_241);
                V v_t_2479 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTypeF_str7));
                switch (heff_tag_of(v_t_2479)) {
                case TAG_True: {
                  heff_drop(v_x_245);
                  V v_x1_2480 = heff_tr(heff_apply(heff_get(v_k_240, LBL_ty), 1, (V[]){v_i_246}));
                  switch (heff_tag_of(v_x1_2480)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x1_243_24Just, 1);
                    heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x11_2481 = heff_field(v_x1_2480, 0);
                    V v_ru_24x1_2480_24Just = heff_take_reuse_n(v_x1_2480, 1ULL, 1);
                    switch (heff_tag_of(v_x11_2481)) {
                    case TAG_MkPair: {
                      V v_x_2482 = heff_field(v_x11_2481, 0);
                      V v_i_2483 = heff_field(v_x11_2481, 1);
                      heff_take_n(v_x11_2481, 3ULL, 2);
                      V v_t_2484 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_243_24Just, TAG_SIsTy, 1, (V[]){v_x_2482}), v_i_2483});
                      return heff_tag_at(v_ru_24x1_2480_24Just, TAG_Just, 1, (V[]){v_t_2484});
                    }
                    default: return heff_nomatch(v_x11_2481);
                    }
                  }
                  default: return heff_nomatch(v_x1_2480);
                  }
                }
                case TAG_False: {
                  V v_t_2485 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTypeF_str8));
                  switch (heff_tag_of(v_t_2485)) {
                  case TAG_True: {
                    heff_drop(v_k_240);
                    heff_drop(v_x_245);
                    V v_t_2486 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimInt), v_i_246});
                    return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_2486});
                  }
                  case TAG_False: {
                    V v_t_2487 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTypeF_str9));
                    switch (heff_tag_of(v_t_2487)) {
                    case TAG_True: {
                      heff_drop(v_k_240);
                      heff_drop(v_x_245);
                      V v_t_2488 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimFloat), v_i_246});
                      return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_2488});
                    }
                    case TAG_False: {
                      V v_t_2489 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eserial_2edecodeTypeF_str10));
                      switch (heff_tag_of(v_t_2489)) {
                      case TAG_True: {
                        heff_drop(v_k_240);
                        heff_drop(v_x_245);
                        V v_t_2490 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimString), v_i_246});
                        return heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){v_t_2490});
                      }
                      case TAG_False: {
                        V v_t_2491 = heff_strEq(v_x_245, ((V)&g_heff_2eserial_2edecodeTypeF_str11));
                        switch (heff_tag_of(v_t_2491)) {
                        case TAG_True: {
                          V v_x1_2492 = heff_tr(heff_apply(heff_get(v_k_240, LBL_ty), 1, (V[]){v_i_246}));
                          switch (heff_tag_of(v_x1_2492)) {
                          case TAG_Nothing: {
                            heff_drop_cell(v_ru_24x1_243_24Just, 1);
                            heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x11_2493 = heff_field(v_x1_2492, 0);
                            V v_ru_24x1_2492_24Just = heff_take_reuse_n(v_x1_2492, 1ULL, 1);
                            switch (heff_tag_of(v_x11_2493)) {
                            case TAG_MkPair: {
                              V v_x_2494 = heff_field(v_x11_2493, 0);
                              V v_i_2495 = heff_field(v_x11_2493, 1);
                              heff_take_n(v_x11_2493, 3ULL, 2);
                              V v_t_2496 = heff_tag_at(v_ru_24x11_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_243_24Just, TAG_SPrimArray, 1, (V[]){v_x_2494}), v_i_2495});
                              return heff_tag_at(v_ru_24x1_2492_24Just, TAG_Just, 1, (V[]){v_t_2496});
                            }
                            default: return heff_nomatch(v_x11_2493);
                            }
                          }
                          default: return heff_nomatch(v_x1_2492);
                          }
                        }
                        case TAG_False: {
                          heff_drop(v_k_240);
                          heff_drop_cell(v_ru_24x1_243_24Just, 1);
                          heff_drop(v_i_246);
                          heff_drop_cell(v_ru_24x11_244_24MkPair, 2);
                          return NTAG(TAG_Nothing);
                        }
                        default: return heff_nomatch(v_t_2491);
                        }
                      }
                      default: return heff_nomatch(v_t_2489);
                      }
                    }
                    default: return heff_nomatch(v_t_2487);
                    }
                  }
                  default: return heff_nomatch(v_t_2485);
                  }
                }
                default: return heff_nomatch(v_t_2479);
                }
              }
              default: return heff_nomatch(v_t_2457);
              }
            }
            default: return heff_nomatch(v_t_2441);
            }
          }
          default: return heff_nomatch(v_t_2422);
          }
        }
        default: return heff_nomatch(v_t_2416);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2eserial_2edecodeTypeF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2edecodeTypeF(a[0], a[1], a[2]);
}
V g_heff_2eserial_2edecodeTypeF_lam0(V self, V *args) {
  V v_j4_2431 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_k_240, LBL_ty);
  args[0] = v_j4_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eserial_2edecodeTypeF_lam1(V self, V *args) {
  V v_j3_2446 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_k_240, LBL_ty);
  args[0] = v_j3_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eserial_2edecodeTypeF_lam2(V self, V *args) {
  V v_j4_2451 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_k_240, LBL_el);
  args[0] = v_j4_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eserial_2edecodeTypeF_lam4(V self, V *args) {
  V v_j3_2468 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_k_240, LBL_ty);
  args[0] = v_j3_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eserial_2edecodeTypeF_lam3(V self, V *args) {
  V v_j2_2458 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2459 = (g_heff_2eserial_2etakeWord(v_s_241, v_j2_2458));
  V v_x1_2464;
  switch (heff_tag_of(v_x1_2459)) {
  case TAG_Nothing: {
    v_x1_2464 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_2460 = heff_field(v_x1_2459, 0);
    V v_ru_24x1_2459_24Just = heff_take_reuse_n(v_x1_2459, 1ULL, 1);
    switch (heff_tag_of(v_x11_2460)) {
    case TAG_MkPair: {
      V v_x_2461 = heff_field(v_x11_2460, 0);
      V v_i_2462 = heff_field(v_x11_2460, 1);
      heff_take_n(v_x11_2460, 3ULL, 2);
      V v_x_2463 = (g_heff_2esurface_2eintOfText(v_x_2461));
      v_x1_2464 = heff_tag_at(v_ru_24x1_2459_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2463, v_i_2462})});
      break;
    }
    default: heff_nomatch(v_x11_2460);
    }
    break;
  }
  default: heff_nomatch(v_x1_2459);
  }
  V v_x1_2469;
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_Nothing: {
    heff_drop(v_k_240);
    v_x1_2469 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_2465 = heff_field(v_x1_2464, 0);
    heff_take_n(v_x1_2464, 1ULL, 1);
    switch (heff_tag_of(v_x11_2465)) {
    case TAG_MkPair: {
      V v_x_2466 = heff_field(v_x11_2465, 0);
      V v_i_2467 = heff_field(v_x11_2465, 1);
      heff_take_n(v_x11_2465, 3ULL, 2);
      v_x1_2469 = (g_heff_2eserial_2etakeManyG(heff_clo(g_heff_2eserial_2edecodeTypeF_lam4, 1, 1, (V[]){v_k_240}), v_x_2466, v_i_2467));
      break;
    }
    default: heff_nomatch(v_x11_2465);
    }
    break;
  }
  default: heff_nomatch(v_x1_2464);
  }
  switch (heff_tag_of(v_x1_2469)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_2470 = heff_field(v_x1_2469, 0);
    V v_ru_24x1_2469_24Just = heff_take_reuse_n(v_x1_2469, 1ULL, 1);
    switch (heff_tag_of(v_x11_2470)) {
    case TAG_MkPair: {
      V v_x_2471 = heff_field(v_x11_2470, 0);
      V v_i_2472 = heff_field(v_x11_2470, 1);
      V v_ru_24x11_2470_24MkPair = heff_take_reuse_n(v_x11_2470, 3ULL, 2);
      V v_t_2473 = heff_tag_at(v_ru_24x11_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2471), v_i_2472});
      return heff_tag_at(v_ru_24x1_2469_24Just, TAG_Just, 1, (V[]){v_t_2473});
    }
    default: return heff_nomatch(v_x11_2470);
    }
  }
  default: return heff_nomatch(v_x1_2469);
  }
}
V g_heff_2eserial_2edkOf_lam0(V self, V *args);
V g_heff_2eserial_2edkOf_lam1(V self, V *args);
Clo g_heff_2eserial_2edkOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eserial_2edkOf_entry, 1, 0};

V g_heff_2eserial_2edkOf(V v_s_240) {
top: ;
  return heff_rec(2, shape_80_351, (V[]){heff_clo(g_heff_2eserial_2edkOf_lam0, 1, 1, (V[]){heff_dup(v_s_240)}), heff_clo(g_heff_2eserial_2edkOf_lam1, 1, 1, (V[]){v_s_240})});
}
V g_heff_2eserial_2edkOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eserial_2edkOf(a[0]);
}
V g_heff_2eserial_2edkOf_lam0(V self, V *args) {
  V v_i_241 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2eserial_2edkOf(heff_dup(v_s_240)));
  return (g_heff_2eserial_2edecodeTermF(v_t_242, v_s_240, v_i_241));
}
V g_heff_2eserial_2edkOf_lam1(V self, V *args) {
  V v_i_243 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eserial_2edkOf(heff_dup(v_s_240)));
  return (g_heff_2eserial_2edecodeTypeF(v_t_244, v_s_240, v_i_243));
}