// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define LBL_end 310101
#define LBL_start 311115900
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
V g_heff_2eelab_2etoplevel_2eappChk_2eapplied_242(V, V, V);
V g_heff_2eelab_2etoplevel_2eappChk_2eapplied_242_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappChk_2eapplied_242_clo;
V g_heff_2eelab_2etoplevel_2echecksOnly(V);
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo;
Clo g_heff_2eelab_2etoplevel_2eappChk_2eapplied_242_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappChk_2eapplied_242_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappChk_2eapplied_242(V v_start_240, V v_s_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_start_240);
    return v_s_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x311_245 = heff_field(v_x31_243, 0);
      V v_a_246 = heff_field(v_x31_243, 1);
      switch (heff_tag_of(v_x311_245)) {
      case TAG_MkPair: {
        V v_c_247 = heff_field(v_x311_245, 0);
        V v_sp_248 = heff_field(v_x311_245, 1);
        V v_t_249 = (g_heff_2eelab_2etoplevel_2echecksOnly(v_c_247));
        V v_t_2435;
        switch (heff_tag_of(v_c_247)) {
        case TAG_At: {
          V v_x11_2410 = heff_field(v_c_247, 0);
          switch (heff_tag_of(v_x11_2410)) {
          case TAG_CInf: {
            v_t_2435 = NTAG(TAG_False);
            break;
          }
          case TAG_CType: {
            v_t_2435 = NTAG(TAG_False);
            break;
          }
          case TAG_CLam: {
            v_t_2435 = NTAG(TAG_True);
            break;
          }
          case TAG_CImplicitLam: {
            v_t_2435 = NTAG(TAG_False);
            break;
          }
          case TAG_CAnnLam: {
            v_t_2435 = NTAG(TAG_False);
            break;
          }
          case TAG_CTag: {
            v_t_2435 = NTAG(TAG_False);
            break;
          }
          case TAG_CStruct: {
            v_t_2435 = NTAG(TAG_False);
            break;
          }
          case TAG_CMatch: {
            v_t_2435 = NTAG(TAG_False);
            break;
          }
          case TAG_CLetIn: {
            v_t_2435 = NTAG(TAG_False);
            break;
          }
          case TAG_CLocal: {
            v_t_2435 = NTAG(TAG_False);
            break;
          }
          case TAG_CAbandon: {
            v_t_2435 = NTAG(TAG_False);
            break;
          }
          case TAG_CNominal: {
            v_t_2435 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x11_2410);
          }
          break;
        }
        default: heff_nomatch(v_c_247);
        }
        V v_t_2436 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_240), heff_dup(heff_rfield(v_sp_248, 1))});
        V v_t_2437 = ({ V a_0 = v_t_249; V a_1 = v_t_2435; V a_2 = v_t_2436; V a_3 = v_s_241; V a_4 = heff_dup(v_a_246); V r_ = (g_heff_2eelab_2erules_2efunctionElimC(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_249); heff_drop(v_t_2435); heff_drop(v_s_241); r_; });
        V t_0 = v_start_240;
        V t_1 = v_t_2437;
        V t_2 = v_rest_244;
        v_start_240 = t_0;
        v_s_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_245);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2eappChk_2eapplied_242_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eappChk_2eapplied_242(a[0], a[1], a2); heff_drop(a2); return r;
}