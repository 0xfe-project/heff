// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_CJump 43389
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CReturn 19985
#define TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565 57410
#define TAG_Given 9359
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_KnownCell 38933
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkCArm 24694
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RCall 39004
#define TAG_RField 17425
#define TAG_RLocal 34280
#define TAG_RPrim 49376
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SOnce 21704
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38305
#define TAG_TakeKeep 54413
#define TAG_TakeN 37047
#define TAG_TakeNone 22612
#define LBL_after 294093302
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_counted 1189688364
#define LBL_flat 9641024
#define LBL_flats 298871860
#define LBL_funs 9650075
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_names 305943394
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_plain 308106724
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sts 323756
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_takes 311482598
#define LBL_tokens 1078955205
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tokens, LBL_ret};
V g_heff_2ecompile_2erefcount_2eanyW(V, V);
V g_heff_2ecompile_2erefcount_2eanyW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eanyW_clo;
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_clo;
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_clo;
V g_heff_2ecompile_2erefcount_2ecallAs(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecallAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecallAs_clo;
V g_heff_2ecompile_2erefcount_2ecoerce(V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_clo;
V g_heff_2ecompile_2erefcount_2ecoerce_24tok1(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok1_clo;
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok2_clo;
V g_heff_2ecompile_2erefcount_2ecompV_24s1933826292x763462755(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecompV_24s1933826292x763462755_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompV_24s1933826292x763462755_clo;
V g_heff_2ecompile_2erefcount_2edropOf(V, V);
V g_heff_2ecompile_2erefcount_2edropOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropOf_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2efieldMask(V, V, V);
V g_heff_2ecompile_2erefcount_2efieldMask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldMask_clo;
V g_heff_2ecompile_2erefcount_2eflatnessOf(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eflatnessOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eflatnessOf_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2eindexIn_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ekeptFrom_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo;
V g_heff_2ecompile_2erefcount_2elentIn(V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentIn_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2enotFlatAt(V, V, V);
V g_heff_2ecompile_2erefcount_2enotFlatAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2enotFlatAt_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2epartsThen(V, V);
V g_heff_2ecompile_2erefcount_2epartsThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epartsThen_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_clo;
V g_heff_2ecompile_2erefcount_2epeekPrim_get(void);
V g_heff_2ecompile_2erefcount_2epow2(V);
V g_heff_2ecompile_2erefcount_2epow2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epow2_clo;
HeffT2 g_heff_2ecompile_2erefcount_2erebuiltOp_24s510905267x500217447_24cpr(V, V);
HeffT2 g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr(V, V);
HeffT2 g_heff_2ecompile_2erefcount_2erebuiltSts_24s860872616x1839682545_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2esameS(V, V);
V g_heff_2ecompile_2erefcount_2esameS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esameS_clo;
V g_heff_2ecompile_2erefcount_2eshapesOfV(V, V);
V g_heff_2ecompile_2erefcount_2eshapesOfV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eshapesOfV_clo;
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_clo;
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo;
V g_heff_2ecompile_2erefcount_2etokenK(V, V, V);
V g_heff_2ecompile_2erefcount_2etokenK_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etokenK_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etokenK_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2etokenSt_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etokenTl(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etokenTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etokenTl_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2ereprsEq(V, V);
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsEq_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s1793250635x935291087(V);
V g_list_2eall_24s1793250635x935291087_entry(V self, V *a);
extern Clo g_list_2eall_24s1793250635x935291087_clo;
V g_list_2eany_24s332132496x946063656(V, V);
V g_list_2eany_24s332132496x946063656_entry(V self, V *a);
extern Clo g_list_2eany_24s332132496x946063656_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24s1050197499x1941129217(V, V);
V g_list_2efoldl_24s1050197499x1941129217_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1050197499x1941129217_clo;
V g_list_2efoldl_24s1060781110x816201608(V, V);
V g_list_2efoldl_24s1060781110x816201608_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1060781110x816201608_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s421921225x565177679(V, V);
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a);
extern Clo g_list_2efoldl_24s421921225x565177679_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24tok1(V, V);
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24tok1_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s976303750x321235480(V);
V g_list_2emap_24s976303750x321235480_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithTakes_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ewithTakes(V v_ts_240, V v_ce_241) {
top: ;
  return ({ V rv_9 = v_ts_240; V rr_ = heff_rec_reuse_nf(v_ce_241, 130559ULL, 17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, 4294180863u, 0u); heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithTakes(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2esameS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esameS_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2esameS(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_x_244, v_y_246, 0)) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2esameS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2esameS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2erefcount_2ekeptFrom_24cpr(V v_ls_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_l_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_SVar: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SStr: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SBytes: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFixed: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFloat32: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimFn: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      V v_e_2421 = heff_field(v_x22_243, 0);
      V v_l2_2422 = heff_field(v_x22_243, 1);
      V v_sh_2423 = heff_field(v_x22_243, 2);
      if (heff_strEq_c_lent(v_l_242, v_l2_2422, 0)) {
        V v_t_2425 = (g_heff_2ecompile_2erefcount_2esameS(v_ls_240, v_sh_2423));
        if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
          heff_drop(v_t_2425);
          switch (heff_tag_of(v_e_2421)) {
          case TAG_SVar: {
            V v_x_2426 = heff_field(v_e_2421, 0);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_2426)}});
          }
          case TAG_SGlobal: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SInt: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SFloat: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SStr: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SBytes: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SFixed: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SFloat32: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SPrimFn: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLam: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_STag: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SRec: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SProj: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SPrim: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_e_2421)}});
          }
        } else {
          heff_drop(v_t_2425);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_SPrim: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x22_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2efieldMask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efieldMask_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2efieldMask(V v_used_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x3_242, 0);
    V v_vs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ecompile_2erefcount_2eelemS(v_v_243, v_used_240));
    V v_t_246;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      v_t_246 = (g_heff_2ecompile_2erefcount_2epow2(heff_dup(v_i_241)));
    } else {
      heff_drop(v_t_245);
      v_t_246 = MK_INT(0LL);
    }
    V v_t_247 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_vs_244));
    return heff_intAdd(v_t_246, v_t_247);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2efieldMask_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2efieldMask(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2etokenK_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2etokenK_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2etokenK_24cpr(V v_tk_240, V v_ru_241, V v_n_242) {
top: ;
  return ((HeffT2){{heff_clo_n(g_heff_2ecompile_2erefcount_2etokenK_24cpr_lam0, 1, 3, (V[]){heff_dup(v_tk_240), heff_dup(v_ru_241), heff_dup(v_n_242)}), heff_clo_n(g_heff_2ecompile_2erefcount_2etokenK_24cpr_lam1, 1, 3, (V[]){v_tk_240, v_ru_241, v_n_242})}});
}
V g_heff_2ecompile_2erefcount_2etokenK_24cpr_lam0(V self, V *args) {
  V v_ss_243 = args[0];
  V v_tk_240 = heff_env(self)[0];
  V v_ru_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_k_244 = (g_heff_2ecompile_2erefcount_2etokenK(heff_dup(v_tk_240), heff_dup(v_ru_241), heff_dup(v_n_242)));
  heff_clo_take(self, 3);
  V v_tk_245 = v_tk_240;
  V v_ru_246 = v_ru_241;
  V v_n_247 = v_n_242;
  V v_x5_248 = v_ss_243;
  switch (heff_tag_of(v_x5_248)) {
  case TAG_Nil: {
    heff_drop_rec(v_k_244, 2);
    heff_drop(v_tk_245);
    heff_drop(v_ru_246);
    heff_drop(v_n_247);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_st_249 = heff_field(v_x5_248, 0);
    V v_rest_2410 = heff_field(v_x5_248, 1);
    V v_ru_24x5_248_24Cons = heff_take_reuse_n(v_x5_248, 3ULL, 2);
    HeffT2 v_t_2411 = (g_heff_2ecompile_2erefcount_2etokenSt_24cpr(heff_dup(v_k_244), v_tk_245, v_ru_246, v_n_247, v_st_249));
    {
      V v_field_2412 = v_t_2411.f[0];
      V v_field_2413 = v_t_2411.f[1];
      V v_x31_2414 = v_field_2412;
      V v_st_2415 = v_field_2413;
      if ((heff_dup(v_x31_2414) == NTAG(TAG_True))) {
        heff_drop_rec(v_k_244, 2);
        heff_drop(v_x31_2414);
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_re_n(v_ru_24x5_248_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_st_2415, v_rest_2410})});
      } else {
        heff_drop(v_x31_2414);
        V v_x2_2416 = heff_tr(heff_call(heff_get_n(v_k_244, 0, 2), 1, (V[]){v_rest_2410}));
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_MkPair: {
          V v_b_2417 = heff_field(v_x2_2416, 0);
          V v_ss_2418 = heff_field(v_x2_2416, 1);
          V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
          return heff_tag_re_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_b_2417, heff_tag_at_n(v_ru_24x5_248_24Cons, TAG_Cons, 2, (V[]){v_st_2415, v_ss_2418})});
        }
        default: return heff_nomatch(v_x2_2416);
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_248);
  }
}
V g_heff_2ecompile_2erefcount_2etokenK_24cpr_lam1(V self, V *args) {
  V v_t_2419 = args[0];
  V v_tk_240 = heff_env(self)[0];
  V v_ru_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_t_2420 = (g_heff_2ecompile_2erefcount_2etokenK(heff_dup(v_tk_240), heff_dup(v_ru_241), heff_dup(v_n_242)));
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2erefcount_2etokenTl(v_t_2420, v_tk_240, v_ru_241, v_n_242, v_t_2419));
}
Clo g_heff_2ecompile_2erefcount_2epartsThen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2epartsThen_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2epartsThen(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IVal: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24IVal = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_SVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24IVal, 1);
      return v_rest_241;
    }
    case TAG_SGlobal: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24IVal, 1);
      return v_rest_241;
    }
    case TAG_SInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24IVal, 1);
      return v_rest_241;
    }
    case TAG_SFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24IVal, 1);
      return v_rest_241;
    }
    case TAG_SStr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24IVal, 1);
      return v_rest_241;
    }
    case TAG_SBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24IVal, 1);
      return v_rest_241;
    }
    case TAG_SFixed: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24IVal, 1);
      return v_rest_241;
    }
    case TAG_SFloat32: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24IVal, 1);
      return v_rest_241;
    }
    case TAG_SPrimFn: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24IVal, 1);
      return v_rest_241;
    }
    case TAG_SLam: {
      V v_x112_2414 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24SLam = heff_take_reuse_n(v_x11_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24IVal, 1);
      switch (heff_tag_of(v_x112_2414)) {
      case TAG_MkBlock: {
        V v_t_2415 = heff_field(v_x112_2414, 0);
        V v_ru_24x112_2414_24MkBlock = heff_take_reuse_n(v_x112_2414, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x11_242_24SLam, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x112_2414_24MkBlock, TAG_ITl, 1, (V[]){v_t_2415}), v_rest_241});
      }
      default: return heff_nomatch(v_x112_2414);
      }
    }
    case TAG_STag: {
      V v_argv_2417 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 2ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24IVal, 1);
      V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2417));
      HEFF_LAST return g_list_2efoldl_24s1203202837x1639358108(v_rest_241, v_t_2419);
    }
    case TAG_SRec: {
      V v_fs_2420 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24IVal, 1);
      V v_t_2422 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2420));
      HEFF_LAST return g_list_2efoldl_24s1203202837x1639358108(v_rest_241, v_t_2422);
    }
    case TAG_SProj: {
      V v_e_2423 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 4);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24IVal, TAG_IVal, 1, (V[]){v_e_2423}), v_rest_241});
    }
    case TAG_SPrim: {
      V v_argv_2428 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24IVal, 1);
      V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2428));
      HEFF_LAST return g_list_2efoldl_24s1203202837x1639358108(v_rest_241, v_t_2429);
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_IOp: {
    V v_x11_2430 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24IOp = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_OSimple: {
      V v_v_2431 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24IOp, TAG_IVal, 1, (V[]){v_v_2431}), v_rest_241});
    }
    case TAG_OCall: {
      V v_argv_2433 = heff_field(v_x11_2430, 1);
      heff_take_n(v_x11_2430, 2ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24IOp, 1);
      V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2433));
      HEFF_LAST return g_list_2efoldl_24s1203202837x1639358108(v_rest_241, v_t_2434);
    }
    case TAG_OApply: {
      V v_f_2435 = heff_field(v_x11_2430, 0);
      V v_argv_2436 = heff_field(v_x11_2430, 1);
      V v_ru_24x11_2430_24OApply = heff_take_reuse_n(v_x11_2430, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24IOp, 1);
      V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x11_2430_24OApply, TAG_Cons, 2, (V[]){v_f_2435, v_argv_2436})));
      HEFF_LAST return g_list_2efoldl_24s1203202837x1639358108(v_rest_241, v_t_2437);
    }
    case TAG_OPrim: {
      V v_argv_2439 = heff_field(v_x11_2430, 1);
      heff_take_n(v_x11_2430, 2ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24IOp, 1);
      V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2439));
      HEFF_LAST return g_list_2efoldl_24s1203202837x1639358108(v_rest_241, v_t_2440);
    }
    case TAG_OAbandon: {
      heff_drop_cell(v_ru_24x1_240_24IOp, 1);
      return v_rest_241;
    }
    case TAG_OBool: {
      V v_c_2441 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24IOp, TAG_ICond, 1, (V[]){v_c_2441}), v_rest_241});
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  case TAG_ICond: {
    V v_x11_2442 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ICond = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2442)) {
    case TAG_PTrue: {
      heff_drop_cell(v_ru_24x1_240_24ICond, 1);
      return v_rest_241;
    }
    case TAG_PFalse: {
      heff_drop_cell(v_ru_24x1_240_24ICond, 1);
      return v_rest_241;
    }
    case TAG_PRel: {
      V v_a_2444 = heff_field(v_x11_2442, 1);
      V v_b_2445 = heff_field(v_x11_2442, 2);
      heff_take_n(v_x11_2442, 6ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24ICond, 1);
      V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_b_2445}), v_rest_241});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_a_2444}), v_t_2446});
    }
    case TAG_PBool: {
      V v_v_2447 = heff_field(v_x11_2442, 0);
      V v_ru_24x11_2442_24PBool = heff_take_reuse_n(v_x11_2442, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24ICond, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x11_2442_24PBool, TAG_IVal, 1, (V[]){v_v_2447}), v_rest_241});
    }
    case TAG_PNot: {
      V v_c_2448 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ICond, TAG_ICond, 1, (V[]){v_c_2448}), v_rest_241});
    }
    case TAG_PIf: {
      V v_a_2449 = heff_field(v_x11_2442, 0);
      V v_b_2450 = heff_field(v_x11_2442, 1);
      V v_c_2451 = heff_field(v_x11_2442, 2);
      heff_take_n(v_x11_2442, 7ULL, 3);
      V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ICond, TAG_ICond, 1, (V[]){v_c_2451}), v_rest_241});
      V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_b_2450}), v_t_2452});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_2449}), v_t_2453});
    }
    case TAG_PLet: {
      V v_o_2455 = heff_field(v_x11_2442, 1);
      V v_c_2456 = heff_field(v_x11_2442, 2);
      heff_take_n(v_x11_2442, 6ULL, 3);
      V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ICond, TAG_ICond, 1, (V[]){v_c_2456}), v_rest_241});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2455}), v_t_2457});
    }
    default: return heff_nomatch(v_x11_2442);
    }
  }
  case TAG_ISts: {
    V v_x11_2458 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ISts = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2458)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24ISts, 1);
      return v_rest_241;
    }
    case TAG_Cons: {
      V v_x111_2459 = heff_field(v_x11_2458, 0);
      V v_ss_2460 = heff_field(v_x11_2458, 1);
      V v_ru_24x11_2458_24Cons = heff_take_reuse_n(v_x11_2458, 3ULL, 2);
      switch (heff_tag_of(v_x111_2459)) {
      case TAG_SLet: {
        V v_o_2462 = heff_field(v_x111_2459, 1);
        V v_ru_24x111_2459_24SLet = heff_take_reuse_n(v_x111_2459, 2ULL, 2);
        V v_t_2463 = heff_tag_at_n(v_ru_24x11_2458_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ISts, TAG_ISts, 1, (V[]){v_ss_2460}), v_rest_241});
        return heff_tag_at_n(v_ru_24x111_2459_24SLet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2462}), v_t_2463});
      }
      case TAG_SOnce: {
        V v_o_2465 = heff_field(v_x111_2459, 1);
        V v_ru_24x111_2459_24SOnce = heff_take_reuse_n(v_x111_2459, 2ULL, 2);
        V v_t_2466 = heff_tag_at_n(v_ru_24x11_2458_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ISts, TAG_ISts, 1, (V[]){v_ss_2460}), v_rest_241});
        return heff_tag_at_n(v_ru_24x111_2459_24SOnce, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2465}), v_t_2466});
      }
      case TAG_SDecl: {
        heff_take_n(v_x111_2459, 0ULL, 1);
        return heff_tag_at_n(v_ru_24x11_2458_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ISts, TAG_ISts, 1, (V[]){v_ss_2460}), v_rest_241});
      }
      case TAG_SSet: {
        V v_o_2469 = heff_field(v_x111_2459, 1);
        V v_ru_24x111_2459_24SSet = heff_take_reuse_n(v_x111_2459, 2ULL, 2);
        V v_t_2470 = heff_tag_at_n(v_ru_24x11_2458_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ISts, TAG_ISts, 1, (V[]){v_ss_2460}), v_rest_241});
        return heff_tag_at_n(v_ru_24x111_2459_24SSet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2469}), v_t_2470});
      }
      case TAG_SIf: {
        V v_c_2471 = heff_field(v_x111_2459, 0);
        V v_ts_2472 = heff_field(v_x111_2459, 1);
        V v_fs_2473 = heff_field(v_x111_2459, 2);
        heff_take_n(v_x111_2459, 7ULL, 3);
        V v_t_2474 = heff_tag_at_n(v_ru_24x11_2458_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ISts, TAG_ISts, 1, (V[]){v_ss_2460}), v_rest_241});
        V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_fs_2473}), v_t_2474});
        V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_2472}), v_t_2475});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2471}), v_t_2476});
      }
      case TAG_SCase: {
        V v_v_2477 = heff_field(v_x111_2459, 0);
        V v_arms_2478 = heff_field(v_x111_2459, 1);
        V v_ru_24x111_2459_24SCase = heff_take_reuse_n(v_x111_2459, 3ULL, 2);
        V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2478));
        V v_t_2480 = heff_tag_at_n(v_ru_24x11_2458_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ISts, TAG_ISts, 1, (V[]){v_ss_2460}), v_rest_241});
        V v_t_2481 = (g_list_2efoldl_24s1104809983x118204267(v_t_2480, v_t_2479));
        return heff_tag_at_n(v_ru_24x111_2459_24SCase, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2477}), v_t_2481});
      }
      default: return heff_nomatch(v_x111_2459);
      }
    }
    default: return heff_nomatch(v_x11_2458);
    }
  }
  case TAG_ITl: {
    V v_x11_2482 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ITl = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2482)) {
    case TAG_TSeq: {
      V v_ss_2483 = heff_field(v_x11_2482, 0);
      V v_t_2484 = heff_field(v_x11_2482, 1);
      V v_ru_24x11_2482_24TSeq = heff_take_reuse_n(v_x11_2482, 3ULL, 2);
      V v_t_2485 = heff_tag_at_n(v_ru_24x11_2482_24TSeq, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ITl, TAG_ITl, 1, (V[]){v_t_2484}), v_rest_241});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2483}), v_t_2485});
    }
    case TAG_TReturn: {
      V v_o_2486 = heff_field(v_x11_2482, 0);
      V v_ru_24x11_2482_24TReturn = heff_take_reuse_n(v_x11_2482, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24ITl, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x11_2482_24TReturn, TAG_IOp, 1, (V[]){v_o_2486}), v_rest_241});
    }
    case TAG_TLoop: {
      V v_vs_2487 = heff_field(v_x11_2482, 0);
      heff_take_n(v_x11_2482, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24ITl, 1);
      V v_t_2488 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_2487));
      HEFF_LAST return g_list_2efoldl_24s1203202837x1639358108(v_rest_241, v_t_2488);
    }
    case TAG_TIf: {
      V v_c_2489 = heff_field(v_x11_2482, 0);
      V v_t_2490 = heff_field(v_x11_2482, 1);
      V v_e_2491 = heff_field(v_x11_2482, 2);
      heff_take_n(v_x11_2482, 7ULL, 3);
      V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ITl, TAG_ITl, 1, (V[]){v_e_2491}), v_rest_241});
      V v_t_2493 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_2490}), v_t_2492});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2489}), v_t_2493});
    }
    case TAG_TCase: {
      V v_v_2494 = heff_field(v_x11_2482, 0);
      V v_arms_2495 = heff_field(v_x11_2482, 1);
      V v_ru_24x11_2482_24TCase = heff_take_reuse_n(v_x11_2482, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24ITl, 1);
      V v_t_2496 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2495));
      V v_t_2497 = (g_list_2efoldl_24s421921225x565177679(v_rest_241, v_t_2496));
      return heff_tag_at_n(v_ru_24x11_2482_24TCase, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2494}), v_t_2497});
    }
    default: return heff_nomatch(v_x11_2482);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2epartsThen_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2epartsThen(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2ecallAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecallAs_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2ecallAs(V v_ce_240, V v_g_241, V v_argv_242, V v_loop_243, V v_ls_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_ce_240, 2));
  V v_t_249;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_s_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_key_247 = heff_take_field(v_s_246, 0);
    V v_params_248 = heff_get_n(v_s_246, 1, 3);
    if ((heff_strEq_c_lent(v_key_247, v_g_241, 0) && ({ V v_t_2475 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_params_248)); int c_ = ({ V v_t_2476 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242)); int c_ = heff_intEq_c_lent(v_t_2475, v_t_2476, 0); heff_drop(v_t_2476); c_; }); heff_drop(v_t_2475); c_; }))) {
      heff_drop(v_key_247);
      heff_drop(v_params_248);
      v_t_249 = (g_list_2eall_24s1793250635x935291087(v_loop_243));
    } else {
      heff_drop(v_key_247);
      heff_drop(v_params_248);
      v_t_249 = NTAG(TAG_False);
    }
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_g_241);
    heff_drop(v_argv_242);
    heff_drop(v_ls_244);
    heff_drop(v_t_249);
    V v_vs_2410 = (g_list_2emap_24s976303750x321235480(v_loop_243));
    V v_t_2411 = heff_get_n(v_ce_240, 2, 17);
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      heff_drop(v_vs_2410);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      V v_s_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      V v_t_2413 = heff_tag_n(TAG_CLoop, 2, (V[]){heff_get_n(v_s_2412, 1, 3), v_vs_2410});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_2411);
    }
  } else {
    heff_drop(v_loop_243);
    heff_drop(v_t_249);
    V v_ce_2414 = heff_dup(v_ce_240);
    V v_g_2415 = heff_dup(v_g_241);
    V v_argv_2416 = v_argv_242;
    HeffT2 v_t_2417 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_2414, 0), v_g_2415));
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      V v_n_2420 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_argv_2416; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_argv_2416); r_; });
      V v_t_2421 = heff_dup(heff_rfield(v_ce_2414, 2));
      V v_t_2443;
      switch (heff_tag_of(v_t_2421)) {
      case TAG_Nothing: {
        heff_drop_rec(v_ce_2414, 17);
        heff_drop(v_g_2415);
        heff_drop(v_field_2419);
        heff_drop(v_n_2420);
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_s_2422 = heff_field(v_t_2421, 0);
        heff_take_n(v_t_2421, 1ULL, 1);
        V v_t_2423 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_s_2422, 1, 3); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        if (heff_intEq_c_lent(v_t_2423, v_n_2420, 1)) {
          if ((v_tag_2418 == ((int64_t)0ULL))) {
            V v_m_2424 = v_field_2419;
            if (heff_intEq_c(v_n_2420, v_m_2424)) {
              V v_ce_2425 = heff_dup(v_ce_2414);
              V v_x2_2426 = heff_get_n(v_ce_2414, 2, 17);
              V v_g_2427 = v_g_2415;
              switch (heff_tag_of(v_x2_2426)) {
              case TAG_Nothing: {
                heff_drop_rec(v_ce_2425, 17);
                heff_drop(v_g_2427);
                v_t_2443 = NTAG(TAG_False);
                break;
              }
              case TAG_Just: {
                V v_s_2428 = heff_field(v_x2_2426, 0);
                heff_take_n(v_x2_2426, 1ULL, 1);
                HeffT2 v_t_2429 = ({ V a_0 = heff_rfield(v_ce_2425, 11); V b_1 = heff_get_n(v_s_2428, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
                {
                  V v_field_2431 = v_t_2429.f[1];
                  int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                  HeffT2 v_t_2432 = ({ V b_0 = heff_get_n(v_ce_2425, 11, 17); V a_1 = v_g_2427; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_g_2427); r_; });
                  {
                    V v_field_2434 = v_t_2432.f[1];
                    int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                    if ((v_tag_2430 == ((int64_t)0ULL))) {
                      V v_a_2435 = v_field_2431;
                      V v_params_2436 = heff_take_field(v_a_2435, 0);
                      V v_result_2437 = heff_get_n(v_a_2435, 1, 2);
                      if ((v_tag_2433 == ((int64_t)0ULL))) {
                        V v_b_2438 = v_field_2434;
                        V v_params_2439 = heff_take_field(v_b_2438, 0);
                        V v_result_2440 = heff_get_n(v_b_2438, 1, 2);
                        V v_t_2441 = ({ V a_0 = v_params_2436; V a_1 = v_params_2439; V r_ = (g_heff_2ecompile_2erepr_2ereprsEq(a_0, a_1)); heff_drop(v_params_2436); heff_drop(v_params_2439); r_; });
                        if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
                          heff_drop(v_t_2441);
                          v_t_2443 = ({ V a_0 = v_result_2437; V a_1 = v_result_2440; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_result_2437); heff_drop(v_result_2440); r_; });
                        } else {
                          heff_drop(v_result_2437);
                          heff_drop(v_result_2440);
                          heff_drop(v_t_2441);
                          v_t_2443 = NTAG(TAG_False);
                        }
                      } else {
                        heff_drop(v_field_2434);
                        heff_drop(v_params_2436);
                        heff_drop(v_result_2437);
                        v_t_2443 = NTAG(TAG_False);
                      }
                    } else {
                      heff_drop(v_field_2431);
                      v_t_2443 = heff_bool(((v_tag_2433 == ((int64_t)0ULL)) ? ({ V v_x_2442 = heff_dup(v_field_2434); int c_ = 0; heff_drop(v_x_2442); c_; }) : 1));
                      heff_drop(v_field_2434);
                    }
                  }
                }
                break;
              }
              default: heff_nomatch(v_x2_2426);
              }
            } else {
              heff_drop_rec(v_ce_2414, 17);
              heff_drop(v_g_2415);
              v_t_2443 = NTAG(TAG_False);
            }
          } else {
            heff_drop_rec(v_ce_2414, 17);
            heff_drop(v_g_2415);
            heff_drop(v_field_2419);
            heff_drop(v_n_2420);
            v_t_2443 = NTAG(TAG_False);
          }
        } else {
          heff_drop_rec(v_ce_2414, 17);
          heff_drop(v_g_2415);
          heff_drop(v_field_2419);
          heff_drop(v_n_2420);
          v_t_2443 = NTAG(TAG_False);
        }
        break;
      }
      default: heff_nomatch(v_t_2421);
      }
      if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
        heff_drop(v_t_2443);
        V v_t_2444 = (g_list_2eall_24s1793250635x935291087(v_ls_244));
        if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
          heff_drop(v_t_2444);
          HeffT2 v_t_2445 = ({ V b_0 = heff_get_n(v_ce_240, 11, 17); V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_2447 = v_t_2445.f[1];
            int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
            V v_t_2449 = heff_bool(((v_tag_2446 == ((int64_t)0ULL)) && ({ V v_x_2448 = heff_dup(v_field_2447); int c_ = 1; heff_drop(v_x_2448); c_; })));
            heff_drop(v_field_2447);
            V v_t_2450 = (g_list_2emap_24s976303750x321235480(v_ls_244));
            return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CJump, 3, (V[]){v_g_241, v_t_2449, v_t_2450}), NTAG(TAG_Nil)});
          }
        } else {
          heff_drop(v_t_2444);
          HeffT2 v_t_2451 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
          {
            V v_field_2453 = v_t_2451.f[1];
            int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
            V v_t_2455;
            if ((v_tag_2452 == ((int64_t)0ULL))) {
              V v_s_2454 = v_field_2453;
              v_t_2455 = heff_get_n(v_s_2454, 1, 2);
            } else {
              heff_drop(v_field_2453);
              v_t_2455 = NTAG(TAG_RepV);
            }
            HeffT2 v_t_2456 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
            {
              V v_field_2458 = v_t_2456.f[1];
              int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
              V v_t_2460;
              if ((v_tag_2457 == ((int64_t)0ULL))) {
                V v_x_2459 = v_field_2458;
                v_t_2460 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2459, 1, 2)});
              } else {
                heff_drop(v_field_2458);
                v_t_2460 = NTAG(TAG_Nothing);
              }
              V v_t_2461 = heff_tag_n(TAG_RCall, 4, (V[]){v_g_241, NTAG(TAG_False), v_t_2460, v_ls_244});
              V v_t_2462 = (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2455, heff_get_n(v_ce_240, 16, 17), v_t_2461));
              return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_2462}), NTAG(TAG_Nil)});
            }
          }
        }
      } else {
        heff_drop(v_t_2443);
        HeffT2 v_t_2463 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
        {
          V v_field_2465 = v_t_2463.f[1];
          int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
          V v_t_2467;
          if ((v_tag_2464 == ((int64_t)0ULL))) {
            V v_s_2466 = v_field_2465;
            v_t_2467 = heff_get_n(v_s_2466, 1, 2);
          } else {
            heff_drop(v_field_2465);
            v_t_2467 = NTAG(TAG_RepV);
          }
          HeffT2 v_t_2468 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
          {
            V v_field_2470 = v_t_2468.f[1];
            int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
            V v_t_2472;
            if ((v_tag_2469 == ((int64_t)0ULL))) {
              V v_x_2471 = v_field_2470;
              v_t_2472 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2471, 1, 2)});
            } else {
              heff_drop(v_field_2470);
              v_t_2472 = NTAG(TAG_Nothing);
            }
            V v_t_2473 = heff_tag_n(TAG_RCall, 4, (V[]){v_g_241, NTAG(TAG_False), v_t_2472, v_ls_244});
            V v_t_2474 = (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2467, heff_get_n(v_ce_240, 16, 17), v_t_2473));
            return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_2474}), NTAG(TAG_Nil)});
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2erefcount_2ecallAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecallAs(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_e_245, V v_es_246) {
top: ;
  V v_t_247 = (g_heff_2ecompile_2erefcount_2elentIn(heff_dup(v_ce_240), v_bi_243, heff_intAdd_lent(v_i_244, MK_INT(1LL), 2), heff_dup(v_es_246)));
  V v_lent_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_live_241)));
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_246));
  V v_t_2410 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_249));
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, heff_dup(v_live_241)));
  V v_live_2412 = (g_prelude_2e_2b_2b(v_before_242, v_t_2411));
  V v_ce_2413 = heff_dup(v_ce_240);
  V v_lent_2414 = v_lent_248;
  V v_live_2415 = v_live_2412;
  V v_bi_2416 = heff_dup(v_bi_243);
  V v_i_2417 = heff_dup(v_i_244);
  V v_e_2418 = heff_dup(v_e_245);
  V v_t_2419 = ({ V a_0 = v_i_244; V a_1 = v_bi_243; V r_ = (g_heff_2ecompile_2erefcount_2eelemI(a_0, a_1)); heff_drop(v_bi_243); r_; });
  V v_x8_2478;
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_t_2419);
    V v_ce_2420 = v_ce_240;
    V v_after_2421 = v_live_241;
    V v_x3_2422 = v_e_245;
    switch (heff_tag_of(v_x3_2422)) {
    case TAG_SVar: {
      heff_take_n(v_x3_2422, 0ULL, 1);
      heff_drop_rec(v_ce_2420, 17);
      heff_drop(v_after_2421);
      v_x8_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SGlobal: {
      heff_take_n(v_x3_2422, 0ULL, 1);
      heff_drop_rec(v_ce_2420, 17);
      heff_drop(v_after_2421);
      v_x8_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SInt: {
      heff_take_n(v_x3_2422, 0ULL, 1);
      heff_drop_rec(v_ce_2420, 17);
      heff_drop(v_after_2421);
      v_x8_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat: {
      heff_take_na(v_x3_2422, 0ULL, 1);
      heff_drop_rec(v_ce_2420, 17);
      heff_drop(v_after_2421);
      v_x8_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SStr: {
      heff_take_n(v_x3_2422, 0ULL, 1);
      heff_drop_rec(v_ce_2420, 17);
      heff_drop(v_after_2421);
      v_x8_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SBytes: {
      heff_take_n(v_x3_2422, 0ULL, 1);
      heff_drop_rec(v_ce_2420, 17);
      heff_drop(v_after_2421);
      v_x8_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFixed: {
      heff_take_n(v_x3_2422, 0ULL, 2);
      heff_drop_rec(v_ce_2420, 17);
      heff_drop(v_after_2421);
      v_x8_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat32: {
      heff_take_na(v_x3_2422, 0ULL, 1);
      heff_drop_rec(v_ce_2420, 17);
      heff_drop(v_after_2421);
      v_x8_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrimFn: {
      heff_take_n(v_x3_2422, 0ULL, 1);
      heff_drop_rec(v_ce_2420, 17);
      heff_drop(v_after_2421);
      v_x8_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      heff_take_n(v_x3_2422, 0ULL, 2);
      heff_drop_rec(v_ce_2420, 17);
      heff_drop(v_after_2421);
      v_x8_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      heff_take_n(v_x3_2422, 0ULL, 3);
      heff_drop_rec(v_ce_2420, 17);
      heff_drop(v_after_2421);
      v_x8_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      heff_take_n(v_x3_2422, 0ULL, 2);
      heff_drop_rec(v_ce_2420, 17);
      heff_drop(v_after_2421);
      v_x8_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      V v_e_2440 = heff_field(v_x3_2422, 0);
      V v_l_2441 = heff_field(v_x3_2422, 1);
      V v_sh_2442 = heff_field(v_x3_2422, 2);
      V v_t_2443 = heff_field(v_x3_2422, 3);
      heff_take_n(v_x3_2422, 15ULL, 4);
      V v_t_2444 = ({ V a_0 = v_t_2443; V r_ = (g_heff_2ecompile_2erepr_2emayBeFlat(a_0)); heff_drop(v_t_2443); r_; });
      if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
        heff_drop_rec(v_ce_2420, 17);
        heff_drop(v_after_2421);
        heff_drop(v_e_2440);
        heff_drop(v_l_2441);
        heff_drop(v_sh_2442);
        heff_drop(v_t_2444);
        v_x8_2478 = NTAG(TAG_Nothing);
      } else {
        heff_drop(v_t_2444);
        HeffT2 v_t_2445 = ({ V a_0 = v_l_2441; V a_1 = MK_INT(0LL); V a_2 = v_sh_2442; HeffT2 r_ = (g_heff_2ecompile_2erefcount_2eindexIn_24cpr(a_0, a_1, a_2)); heff_drop(v_l_2441); heff_drop(v_sh_2442); r_; });
        {
          V v_field_2447 = v_t_2445.f[1];
          int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
          switch (heff_tag_of(v_e_2440)) {
          case TAG_SVar: {
            V v_x_2448 = heff_field(v_e_2440, 0);
            V v_ru_24e_2440_24SVar = heff_take_reuse_n(v_e_2440, 1ULL, 1);
            if ((v_tag_2446 == ((int64_t)0ULL))) {
              V v_i_2449 = v_field_2447;
              V v_t_2450 = ({ V a_0 = v_x_2448; V a_1 = v_after_2421; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_after_2421); r_; });
              if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
                heff_drop_rec(v_ce_2420, 17);
                heff_drop(v_t_2450);
                V v_t_2451 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24e_2440_24SVar, TAG_RLocal, 1, (V[]){v_x_2448}), v_i_2449});
                v_x8_2478 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2451});
              } else {
                heff_drop(v_t_2450);
                V v_t_2452 = ({ V a_0 = v_x_2448; V b_1 = heff_get_n(v_ce_2420, 6, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
                if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
                  heff_drop(v_t_2452);
                  V v_t_2453 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24e_2440_24SVar, TAG_RLocal, 1, (V[]){v_x_2448}), v_i_2449});
                  v_x8_2478 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2453});
                } else {
                  heff_drop(v_x_2448);
                  heff_drop_cell(v_ru_24e_2440_24SVar, 1);
                  heff_drop(v_i_2449);
                  heff_drop(v_t_2452);
                  v_x8_2478 = NTAG(TAG_Nothing);
                }
              }
            } else {
              heff_drop_rec(v_ce_2420, 17);
              heff_drop(v_after_2421);
              heff_drop(v_field_2447);
              heff_drop(v_x_2448);
              heff_drop_cell(v_ru_24e_2440_24SVar, 1);
              v_x8_2478 = NTAG(TAG_Nothing);
            }
            break;
          }
          case TAG_SGlobal: {
            heff_take_n(v_e_2440, 0ULL, 1);
            heff_drop_rec(v_ce_2420, 17);
            heff_drop(v_after_2421);
            heff_drop(v_field_2447);
            v_x8_2478 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SInt: {
            heff_take_n(v_e_2440, 0ULL, 1);
            heff_drop_rec(v_ce_2420, 17);
            heff_drop(v_after_2421);
            heff_drop(v_field_2447);
            v_x8_2478 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SFloat: {
            heff_take_na(v_e_2440, 0ULL, 1);
            heff_drop_rec(v_ce_2420, 17);
            heff_drop(v_after_2421);
            heff_drop(v_field_2447);
            v_x8_2478 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SStr: {
            heff_take_n(v_e_2440, 0ULL, 1);
            heff_drop_rec(v_ce_2420, 17);
            heff_drop(v_after_2421);
            heff_drop(v_field_2447);
            v_x8_2478 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SBytes: {
            heff_take_n(v_e_2440, 0ULL, 1);
            heff_drop_rec(v_ce_2420, 17);
            heff_drop(v_after_2421);
            heff_drop(v_field_2447);
            v_x8_2478 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SFixed: {
            heff_take_n(v_e_2440, 0ULL, 2);
            heff_drop_rec(v_ce_2420, 17);
            heff_drop(v_after_2421);
            heff_drop(v_field_2447);
            v_x8_2478 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SFloat32: {
            heff_take_na(v_e_2440, 0ULL, 1);
            heff_drop_rec(v_ce_2420, 17);
            heff_drop(v_after_2421);
            heff_drop(v_field_2447);
            v_x8_2478 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SPrimFn: {
            heff_take_n(v_e_2440, 0ULL, 1);
            heff_drop_rec(v_ce_2420, 17);
            heff_drop(v_after_2421);
            heff_drop(v_field_2447);
            v_x8_2478 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SLam: {
            heff_take_n(v_e_2440, 0ULL, 2);
            heff_drop_rec(v_ce_2420, 17);
            heff_drop(v_after_2421);
            heff_drop(v_field_2447);
            v_x8_2478 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_STag: {
            heff_take_n(v_e_2440, 0ULL, 3);
            heff_drop_rec(v_ce_2420, 17);
            heff_drop(v_after_2421);
            heff_drop(v_field_2447);
            v_x8_2478 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SRec: {
            heff_take_n(v_e_2440, 0ULL, 2);
            heff_drop_rec(v_ce_2420, 17);
            heff_drop(v_after_2421);
            heff_drop(v_field_2447);
            v_x8_2478 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SProj: {
            heff_take_n(v_e_2440, 0ULL, 4);
            heff_drop_rec(v_ce_2420, 17);
            heff_drop(v_after_2421);
            heff_drop(v_field_2447);
            v_x8_2478 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_SPrim: {
            heff_take_n(v_e_2440, 0ULL, 2);
            heff_drop_rec(v_ce_2420, 17);
            heff_drop(v_after_2421);
            heff_drop(v_field_2447);
            v_x8_2478 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_e_2440);
          }
        }
      }
      break;
    }
    case TAG_SPrim: {
      heff_take_n(v_x3_2422, 0ULL, 2);
      heff_drop_rec(v_ce_2420, 17);
      heff_drop(v_after_2421);
      v_x8_2478 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x3_2422);
    }
  } else {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_e_245);
    heff_drop(v_t_2419);
    v_x8_2478 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_x8_2478)) {
  case TAG_Nothing: {
    V v_ce_2479 = heff_dup(v_ce_2413);
    V v_lent_2480 = v_lent_2414;
    V v_live_2481 = v_live_2415;
    V v_bi_2482 = v_bi_2416;
    V v_i_2483 = v_i_2417;
    V v_e_2484 = heff_dup(v_e_2418);
    V v_x8_24112;
    switch (heff_tag_of(v_e_2418)) {
    case TAG_SVar: {
      V v_x_2485 = heff_field(v_e_2418, 0);
      V v_ru_24e_2418_24SVar = heff_take_reuse_n(v_e_2418, 1ULL, 1);
      HeffT2 v_t_2486 = ({ V b_0 = heff_get_n(v_ce_2413, 10, 17); V a_1 = v_x_2485; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2488 = v_t_2486.f[1];
        int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
        if ((v_tag_2487 == ((int64_t)0ULL))) {
          heff_drop(v_x_2485);
          heff_drop_cell(v_ru_24e_2418_24SVar, 1);
          V v_x_2489 = v_field_2488;
          heff_drop(v_x_2489);
          v_x8_24112 = NTAG(TAG_Nothing);
        } else {
          heff_drop(v_field_2488);
          v_x8_24112 = heff_tag_at_n(v_ru_24e_2418_24SVar, TAG_Just, 1, (V[]){v_x_2485});
        }
      }
      break;
    }
    case TAG_SGlobal: {
      heff_take_n(v_e_2418, 0ULL, 1);
      heff_drop_rec(v_ce_2413, 17);
      v_x8_24112 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SInt: {
      heff_take_n(v_e_2418, 0ULL, 1);
      heff_drop_rec(v_ce_2413, 17);
      v_x8_24112 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat: {
      heff_take_na(v_e_2418, 0ULL, 1);
      heff_drop_rec(v_ce_2413, 17);
      v_x8_24112 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SStr: {
      heff_take_n(v_e_2418, 0ULL, 1);
      heff_drop_rec(v_ce_2413, 17);
      v_x8_24112 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SBytes: {
      heff_take_n(v_e_2418, 0ULL, 1);
      heff_drop_rec(v_ce_2413, 17);
      v_x8_24112 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFixed: {
      heff_take_n(v_e_2418, 0ULL, 2);
      heff_drop_rec(v_ce_2413, 17);
      v_x8_24112 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat32: {
      heff_take_na(v_e_2418, 0ULL, 1);
      heff_drop_rec(v_ce_2413, 17);
      v_x8_24112 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrimFn: {
      heff_take_n(v_e_2418, 0ULL, 1);
      heff_drop_rec(v_ce_2413, 17);
      v_x8_24112 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      heff_take_n(v_e_2418, 0ULL, 2);
      heff_drop_rec(v_ce_2413, 17);
      v_x8_24112 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      heff_take_n(v_e_2418, 0ULL, 3);
      heff_drop_rec(v_ce_2413, 17);
      v_x8_24112 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      heff_take_n(v_e_2418, 0ULL, 2);
      heff_drop_rec(v_ce_2413, 17);
      v_x8_24112 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      heff_take_n(v_e_2418, 0ULL, 4);
      heff_drop_rec(v_ce_2413, 17);
      v_x8_24112 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrim: {
      heff_take_n(v_e_2418, 0ULL, 2);
      heff_drop_rec(v_ce_2413, 17);
      v_x8_24112 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_2418);
    }
    switch (heff_tag_of(v_x8_24112)) {
    case TAG_Nothing: {
      heff_drop(v_lent_2480);
      V v_t_24113 = ({ V a_0 = v_i_2483; V a_1 = v_bi_2482; V r_ = (g_heff_2ecompile_2erefcount_2eelemI(a_0, a_1)); heff_drop(v_bi_2482); r_; });
      if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
        heff_drop(v_t_24113);
        V v_t_24114 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_2479, v_live_2481, NTAG(TAG_RepV), v_e_2484));
        return heff_tag_n(TAG_LentValue, 1, (V[]){v_t_24114});
      } else {
        heff_drop(v_t_24113);
        V v_t_24115 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_2479, v_live_2481, NTAG(TAG_RepV), v_e_2484));
        return heff_tag_n(TAG_Given, 1, (V[]){v_t_24115});
      }
    }
    case TAG_Just: {
      V v_x_24116 = heff_field(v_x8_24112, 0);
      V v_ru_24x8_24112_24Just = heff_take_reuse_n(v_x8_24112, 1ULL, 1);
      V v_t_24117 = ({ V a_0 = v_i_2483; V a_1 = v_bi_2482; V r_ = (g_heff_2ecompile_2erefcount_2eelemI(a_0, a_1)); heff_drop(v_bi_2482); r_; });
      if ((heff_dup(v_t_24117) == NTAG(TAG_True))) {
        heff_drop(v_live_2481);
        heff_drop(v_e_2484);
        heff_drop(v_t_24117);
        V v_ce_24118 = v_ce_2479;
        V v_borrowed_24119 = heff_take_field(v_ce_24118, 6);
        V v_reprs_24120 = heff_take_field(v_ce_24118, 10);
        V v_known_24121 = heff_get_n(v_ce_24118, 8, 17);
        V v_live_24122 = v_lent_2480;
        V v_x_24123 = v_x_24116;
        V v_t_24124 = ({ V a_0 = v_x_24123; V a_1 = v_live_24122; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_live_24122); r_; });
        if ((heff_dup(v_t_24124) == NTAG(TAG_True))) {
          heff_drop(v_borrowed_24119);
          heff_drop(v_reprs_24120);
          heff_drop(v_known_24121);
          heff_drop(v_t_24124);
          return heff_tag_at_n(v_ru_24x8_24112_24Just, TAG_Given, 1, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_x_24123})});
        } else {
          heff_drop(v_t_24124);
          V v_t_24125 = ({ V a_0 = v_x_24123; V a_1 = v_borrowed_24119; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_borrowed_24119); r_; });
          if ((heff_dup(v_t_24125) == NTAG(TAG_True))) {
            heff_drop(v_reprs_24120);
            heff_drop(v_known_24121);
            heff_drop(v_t_24125);
            return heff_tag_at_n(v_ru_24x8_24112_24Just, TAG_Given, 1, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_x_24123})});
          } else {
            heff_drop_cell(v_ru_24x8_24112_24Just, 1);
            heff_drop(v_t_24125);
            HeffT2 v_t_24126 = ({ V a_0 = v_reprs_24120; V a_1 = v_x_24123; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_reprs_24120); r_; });
            {
              V v_field_24128 = v_t_24126.f[1];
              int64_t v_tag_24127 = ((int64_t)v_t_24126.f[0]);
              V v_t_24130;
              if ((v_tag_24127 == ((int64_t)0ULL))) {
                V v_x_24129 = v_field_24128;
                heff_drop(v_x_24129);
                v_t_24130 = NTAG(TAG_Nil);
              } else {
                heff_drop(v_field_24128);
                v_t_24130 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_24123), NTAG(TAG_Nil)});
              }
              V v_t_24131 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_24130));
              V v_t_24136 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_lam0, 2, 1, (V[]){v_known_24121}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24131; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24131); r_; });
              return heff_tag_n(TAG_LentVar, 2, (V[]){v_x_24123, v_t_24136});
            }
          }
        }
      } else {
        heff_drop(v_lent_2480);
        heff_drop(v_x_24116);
        heff_drop(v_t_24117);
        V v_t_24137 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_2479, v_live_2481, NTAG(TAG_RepV), v_e_2484));
        return heff_tag_at_n(v_ru_24x8_24112_24Just, TAG_Given, 1, (V[]){v_t_24137});
      }
    }
    default: return heff_nomatch(v_x8_24112);
    }
  }
  case TAG_Just: {
    V v_a_24138 = heff_field(v_x8_2478, 0);
    V v_ru_24x8_2478_24Just = heff_take_reuse_n(v_x8_2478, 1ULL, 1);
    heff_drop_rec(v_ce_2413, 17);
    heff_drop(v_lent_2414);
    heff_drop(v_live_2415);
    heff_drop(v_bi_2416);
    heff_drop(v_i_2417);
    heff_drop(v_e_2418);
    return heff_tag_at_n(v_ru_24x8_2478_24Just, TAG_Given, 1, (V[]){v_a_24138});
  }
  default: return heff_nomatch(v_x8_2478);
  }
}
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_lam0(V self, V *args) {
  V v_acc_24132 = args[0];
  V v_x_24133 = args[1];
  V v_known_24121 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24134 = ({ V a_0 = v_known_24121; V a_1 = v_x_24133; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_known_24121); r_; });
  V v_t_24135 = (g_heff_2ecompile_2erefcount_2edropOf(v_x_24133, v_t_24134));
  return (g_prelude_2e_2b_2b(v_t_24135, v_acc_24132));
}
Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_bi_243);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_rp_247 = heff_field(v_x7_245, 0);
    V v_rps_248 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_bi_243);
      heff_drop(v_i_244);
      heff_drop(v_rp_247);
      heff_drop(v_rps_248);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_249 = heff_field(v_x8_246, 0);
      V v_es_2410 = heff_field(v_x8_246, 1);
      heff_take_n(v_x8_246, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), heff_dup(v_bi_243), heff_dup(v_i_244), v_rp_247, heff_dup(v_e_249), heff_dup(v_es_2410)));
      V v_t_2412 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = heff_dup(v_i_244); V a_3 = v_e_249; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_249); r_; });
      V v_cell_2413 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2414 = (g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(v_ce_240, v_live_241, v_t_2412, v_bi_243, heff_box_word((heff_unbox_word(v_i_244) + ((int64_t)1ULL))), v_rps_248, v_es_2410, v_cell_2413));
      heff_drop(v_u_2414);
      return v_cell_2413;
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2erefcount_2ecompV_24s1933826292x763462755_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecompV_24s1933826292x763462755_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ecompV_24s1933826292x763462755(V v_lit_240, V v_lit_241, V v_ce_242, V v_live_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_242, v_live_243, v_lit_241));
  return heff_tag_n(TAG_RPrim, 2, (V[]){v_lit_240, v_t_244});
}
V g_heff_2ecompile_2erefcount_2ecompV_24s1933826292x763462755_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecompV_24s1933826292x763462755(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam2(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(V v_ce_240, V v_x_241, V v_a_242, V v_i_243, V v_rest_244, V v_after_245, V v_wb_246) {
top: ;
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){heff_dup(v_i_243)}), NTAG(TAG_Nil)});
  HeffT2 v_t_248 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_247));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_bs_2411 = v_field_249;
    V v_ms_2412 = v_field_2410;
    V v_ms_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2412));
    V v_t_2414 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2411; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2411); r_; });
    V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2413; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
    V v_wanted_2416 = (g_prelude_2e_2b_2b(v_t_2415, heff_dup(v_wb_246)));
    V v_xs_2419 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam0, 1, 1, (V[]){v_wanted_2416}), heff_dup(heff_rfield(v_ce_240, 4))));
    V v_t_2420 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2419));
    V v_t_2421 = (g_list_2emap_24s1796125103x644876049(v_t_2420));
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){heff_dup(v_i_243)}), NTAG(TAG_Nil)});
    HeffT2 v_t_2423 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2422));
    {
      V v_field_2424 = v_t_2423.f[0];
      V v_field_2425 = v_t_2423.f[1];
      V v_bs_2426 = v_field_2424;
      V v_ms_2427 = v_field_2425;
      V v_ms_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2427));
      V v_t_2429 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2426; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2426); r_; });
      V v_t_2430 = ({ V a_0 = v_t_2429; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2428; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2429); r_; });
      V v_wanted_2431 = (g_prelude_2e_2b_2b(v_t_2430, heff_dup(v_wb_246)));
      V v_t_2433 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam1, 1, 1, (V[]){v_wanted_2431}), heff_dup(heff_rfield(v_ce_240, 4))));
      V v_ce_2434 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2433, heff_dup(v_wb_246), heff_dup(v_ce_240)));
      V v_t_2435 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_2434, heff_dup(v_wb_246), NTAG(TAG_RepV), v_i_243));
      V v_t_2437 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam2, 1, 1, (V[]){v_wb_246}), heff_dup(heff_rfield(v_ce_240, 4))));
      V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_dup(heff_rfield(v_ce_240, 6))});
      V v_t_2439 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2438, heff_dup(v_ce_240)));
      V v_ce_2440 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2437, heff_get_n(v_ce_240, 5, 17), v_t_2439));
      V v_t_2441 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2440, v_rest_244, v_after_245));
      V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
      V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_a_242}), v_t_2442});
      V v_t_2444 = heff_tag_n(TAG_CLet, 2, (V[]){v_x_241, heff_tag_n(TAG_RPrim, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2epeekPrim_get()), v_t_2443})});
      return (g_prelude_2e_2b_2b(v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, v_t_2441})));
    }
  }
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam0(V self, V *args) {
  V v_v_2417 = args[0];
  V v_wanted_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2418 = ({ V a_0 = v_v_2417; V a_1 = v_wanted_2416; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2417); heff_drop(v_wanted_2416); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2418) == NTAG(TAG_True)));
  heff_drop(v_x1_2418);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam1(V self, V *args) {
  V v_v_2432 = args[0];
  V v_wanted_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2432; V a_1 = v_wanted_2431; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2432); heff_drop(v_wanted_2431); r_; });
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam2(V self, V *args) {
  V v_v_2436 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2436; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2436); heff_drop(v_wb_246); r_; });
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_str0, 0, "");
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam4(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam5(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam6(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry, 9, 0};

V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(V v_ce_240, V v_taken_241, V v_lent_242, V v_t_243, V v_vs_244, V v_fb_245, V v_leaves_246, V v_rd_247, V v_x10_248) {
top: ;
  V v_flat_249 = heff_take_field(v_rd_247, 4);
  V v_sure_2410 = heff_take_field(v_rd_247, 5);
  V v_names_2411 = heff_take_field(v_rd_247, 2);
  V v_counted_2412 = heff_take_field(v_rd_247, 3);
  V v_plain_2413 = heff_take_field(v_rd_247, 0);
  V v_flats_2414 = heff_get_n(v_rd_247, 1, 6);
  switch (heff_tag_of(v_x10_248)) {
  case TAG_MkPair: {
    V v_ru_2415 = heff_field(v_x10_248, 0);
    V v_b2_2416 = heff_field(v_x10_248, 1);
    V v_ru_24x10_248_24MkPair = heff_take_reuse_n(v_x10_248, 3ULL, 2);
    V v_t_2418;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2418 = NTAG(TAG_True);
    } else {
      switch (heff_tag_of(v_taken_241)) {
      case TAG_Nothing: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        v_t_2418 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_taken_241);
      }
    }
    V v_fl_2419 = heff_dup(v_flat_249);
    V v_su_2420 = heff_dup(v_sure_2410);
    V v_x3_2421 = heff_dup(v_ru_2415);
    V v_taken_2422 = heff_dup(v_taken_241);
    V v_vs_2423 = heff_dup(v_vs_244);
    V v_ys_2424 = v_names_2411;
    V v_used_2429;
    switch (heff_tag_of(v_ys_2424)) {
    case TAG_Nil: {
      v_used_2429 = heff_dup(v_fb_245);
      break;
    }
    case TAG_Cons: {
      v_used_2429 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam0, 1, 1, (V[]){v_ys_2424}), heff_dup(v_fb_245)));
      break;
    }
    default: heff_nomatch(v_ys_2424);
    }
    V v_t_2442;
    switch (heff_tag_of(v_x3_2421)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_taken_2422)) {
      case TAG_Nothing: {
        heff_drop(v_fl_2419);
        heff_drop(v_su_2420);
        heff_drop(v_vs_2423);
        heff_drop(v_used_2429);
        v_t_2442 = NTAG(TAG_TakeNone);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_taken_2422, 0ULL, 1);
        V v_t_2431 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_2429, MK_INT(0LL), v_vs_2423));
        V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2423));
        V v_t_2433 = ({ V a_0 = v_fl_2419; V a_1 = v_su_2420; V a_2 = v_t_2431; V a_3 = v_t_2432; V r_ = (g_heff_2ecompile_2erefcount_2eflatnessOf(a_0, a_1, a_2, a_3)); heff_drop(v_fl_2419); heff_drop(v_su_2420); r_; });
        V v_t_2434 = ({ V a_0 = v_used_2429; V a_1 = MK_INT(0LL); V a_2 = v_vs_2423; V r_ = (g_heff_2ecompile_2erefcount_2efieldMask(a_0, a_1, a_2)); heff_drop(v_used_2429); r_; });
        V v_t_2435 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_2423; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_vs_2423); r_; });
        v_t_2442 = heff_tag_n(TAG_TakeN, 3, (V[]){v_t_2433, v_t_2434, v_t_2435});
        break;
      }
      default: heff_nomatch(v_taken_2422);
      }
      break;
    }
    case TAG_Just: {
      V v_ru_2436 = heff_field(v_x3_2421, 0);
      heff_take_n(v_x3_2421, 1ULL, 1);
      heff_drop(v_taken_2422);
      V v_t_2437 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_2429, MK_INT(0LL), v_vs_2423));
      V v_t_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2423));
      V v_t_2439 = ({ V a_0 = v_fl_2419; V a_1 = v_su_2420; V a_2 = v_t_2437; V a_3 = v_t_2438; V r_ = (g_heff_2ecompile_2erefcount_2eflatnessOf(a_0, a_1, a_2, a_3)); heff_drop(v_fl_2419); heff_drop(v_su_2420); r_; });
      V v_t_2440 = ({ V a_0 = v_used_2429; V a_1 = MK_INT(0LL); V a_2 = v_vs_2423; V r_ = (g_heff_2ecompile_2erefcount_2efieldMask(a_0, a_1, a_2)); heff_drop(v_used_2429); r_; });
      V v_t_2441 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_2423; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_vs_2423); r_; });
      v_t_2442 = heff_tag_n(TAG_TakeKeep, 4, (V[]){v_t_2439, v_ru_2436, v_t_2440, v_t_2441});
      break;
    }
    default: heff_nomatch(v_x3_2421);
    }
    V v_t_2444;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2444 = heff_dup(v_counted_2412);
    } else {
      v_t_2444 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam1, 1, 1, (V[]){heff_dup(v_fb_245)}), heff_dup(v_vs_244)));
    }
    V v_owned_2445 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), v_t_2444));
    V v_wanted_2446 = (g_prelude_2e_2b_2b(heff_dup(v_fb_245), heff_dup(heff_rfield(v_ce_240, 5))));
    V v_t_2449 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam2, 1, 1, (V[]){v_wanted_2446}), v_owned_2445));
    V v_xs_2454 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam3, 1, 1, (V[]){v_taken_241}), v_t_2449));
    V v_t_2455 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2454));
    V v_t_2456 = (g_list_2emap_24s1796125103x644876049(v_t_2455));
    V v_t_2458;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2458 = heff_dup(v_counted_2412);
    } else {
      v_t_2458 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam4, 1, 1, (V[]){heff_dup(v_fb_245)}), heff_dup(v_vs_244)));
    }
    V v_t_2460;
    switch (heff_tag_of(v_ru_2415)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x10_248_24MkPair, 2);
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2459 = heff_dup(heff_field(v_ru_2415, 0));
      v_t_2460 = heff_tag_at_n(v_ru_24x10_248_24MkPair, TAG_Cons, 2, (V[]){v_x_2459, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_2415);
    }
    V v_t_2461 = (g_prelude_2e_2b_2b(v_t_2458, v_t_2460));
    V v_owned_2462 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), v_t_2461));
    V v_t_2464;
    switch (heff_tag_of(v_ru_2415)) {
    case TAG_Nothing: {
      v_t_2464 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2463 = heff_dup(heff_field(v_ru_2415, 0));
      v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2463, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_2415);
    }
    V v_wanted_2465 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_240, 5)), v_fb_245, v_t_2464));
    V v_t_2467 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam5, 1, 1, (V[]){v_wanted_2465}), v_owned_2462));
    V v_t_2474;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      V v_ys_2468 = v_counted_2412;
      V v_t_2473;
      switch (heff_tag_of(v_ys_2468)) {
      case TAG_Nil: {
        v_t_2473 = heff_dup(v_vs_244);
        break;
      }
      case TAG_Cons: {
        v_t_2473 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam6, 1, 1, (V[]){v_ys_2468}), heff_dup(v_vs_244)));
        break;
      }
      default: heff_nomatch(v_ys_2468);
      }
      v_t_2474 = (g_prelude_2e_2b_2b(v_t_2473, heff_dup(heff_rfield(v_ce_240, 6))));
    } else {
      heff_drop(v_counted_2412);
      v_t_2474 = heff_dup(heff_rfield(v_ce_240, 6));
    }
    V v_t_2475 = heff_dup(v_flat_249);
    V v_vs_2476;
    if ((heff_dup(v_t_2475) == NTAG(TAG_True))) {
      heff_drop(v_t_2475);
      v_vs_2476 = NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_2475);
      v_vs_2476 = heff_dup(v_vs_244);
    }
    V v_n_2477 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_244; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_vs_244); r_; });
    V v_t_2481;
    switch (heff_tag_of(v_ru_2415)) {
    case TAG_Nothing: {
      heff_drop(v_flat_249);
      heff_drop(v_vs_2476);
      heff_drop(v_n_2477);
      v_t_2481 = heff_dup(v_ce_240);
      break;
    }
    case TAG_Just: {
      V v_ru_2478 = heff_field(v_ru_2415, 0);
      heff_take_n(v_ru_2415, 1ULL, 1);
      V v_t_2479 = v_flat_249;
      V v_t_2480;
      if ((heff_dup(v_t_2479) == NTAG(TAG_True))) {
        heff_drop(v_t_2479);
        v_t_2480 = ((V)&g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_str0);
      } else {
        heff_drop(v_t_2479);
        v_t_2480 = heff_dup(v_t_243);
      }
      v_t_2481 = (g_heff_2ecompile_2erefcount_2ewithKnown(v_ru_2478, heff_tag_n(TAG_KnownCell, 3, (V[]){v_n_2477, v_t_2480, v_vs_2476}), heff_dup(v_ce_240)));
      break;
    }
    default: heff_nomatch(v_ru_2415);
    }
    V v_t_2482 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2474, v_t_2481));
    V v_ce_2483 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2467, heff_get_n(v_ce_240, 5, 17), v_t_2482));
    V v_t_2486;
    switch (heff_tag_of(v_b2_2416)) {
    case TAG_ATail: {
      V v_t_2484 = heff_field(v_b2_2416, 0);
      heff_take_n(v_b2_2416, 1ULL, 1);
      v_t_2486 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2483, v_t_2484));
      break;
    }
    case TAG_ASts: {
      V v_ss_2485 = heff_field(v_b2_2416, 0);
      heff_take_n(v_b2_2416, 1ULL, 1);
      v_t_2486 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2483, v_ss_2485, NTAG(TAG_Nothing)));
      break;
    }
    default: heff_nomatch(v_b2_2416);
    }
    V v_t_2487 = (g_prelude_2e_2b_2b(v_t_2456, v_t_2486));
    return heff_tag_n(TAG_MkCArm, 8, (V[]){v_t_243, v_plain_2413, v_flats_2414, v_sure_2410, v_t_2418, v_t_2442, v_t_2487, v_leaves_246});
  }
  default: return heff_nomatch(v_x10_248);
  }
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam0(V self, V *args) {
  V v_x_2427 = args[0];
  V v_ys_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2428 = ({ V a_0 = v_x_2427; V a_1 = v_ys_2424; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2427); heff_drop_tag(v_ys_2424, 2); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2428) == NTAG(TAG_True)));
  heff_drop(v_x1_2428);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam1(V self, V *args) {
  V v_v_2443 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2443; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2443); heff_drop(v_fb_245); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam2(V self, V *args) {
  V v_v_2447 = args[0];
  V v_wanted_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2448 = ({ V a_0 = v_v_2447; V a_1 = v_wanted_2446; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2447); heff_drop(v_wanted_2446); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2448) == NTAG(TAG_True)));
  heff_drop(v_x1_2448);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam3(V self, V *args) {
  V v_v_2450 = args[0];
  V v_taken_241 = heff_env(self)[0];
  V v_t_2452;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_taken_241)) {
  case TAG_Nothing: {
    v_t_2452 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2451 = heff_field(v_taken_241, 0);
    heff_take_n(v_taken_241, 1ULL, 1);
    v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2451, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_taken_241);
  }
  V v_x1_2453 = ({ V a_0 = v_v_2450; V a_1 = v_t_2452; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2450); heff_drop(v_t_2452); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2453) == NTAG(TAG_True)));
  heff_drop(v_x1_2453);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam4(V self, V *args) {
  V v_v_2457 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2457; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2457); heff_drop(v_fb_245); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam5(V self, V *args) {
  V v_v_2466 = args[0];
  V v_wanted_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2466; V a_1 = v_wanted_2465; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2466); heff_drop(v_wanted_2465); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam6(V self, V *args) {
  V v_x_2471 = args[0];
  V v_ys_2468 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2472 = ({ V a_0 = v_x_2471; V a_1 = v_ys_2468; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2471); heff_drop_tag(v_ys_2468, 2); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2472) == NTAG(TAG_True)));
  heff_drop(v_x1_2472);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str2, 0, "");
Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V v_ce_240, V v_x3_241) {
top: ;
  return (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(NTAG(TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565), ((V)&g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str0), ((V)&g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str1), ((V)&g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str2), v_ce_240, v_x3_241));
}
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2eshapesOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eshapesOfV_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eshapesOfV(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SVar: {
    return v_acc_240;
  }
  case TAG_SGlobal: {
    return v_acc_240;
  }
  case TAG_SInt: {
    return v_acc_240;
  }
  case TAG_SFloat: {
    return v_acc_240;
  }
  case TAG_SStr: {
    return v_acc_240;
  }
  case TAG_SBytes: {
    return v_acc_240;
  }
  case TAG_SFixed: {
    return v_acc_240;
  }
  case TAG_SFloat32: {
    return v_acc_240;
  }
  case TAG_SPrimFn: {
    return v_acc_240;
  }
  case TAG_SLam: {
    return v_acc_240;
  }
  case TAG_STag: {
    V v_args_2415 = heff_field(v_x2_241, 1);
    return (g_list_2efoldl(((V)&g_heff_2ecompile_2erefcount_2eshapesOfV_clo), v_acc_240, v_args_2415));
  }
  case TAG_SRec: {
    V v_fs_2417 = heff_field(v_x2_241, 0);
    V v_t_2419 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2417)));
    return ({ V a_0 = ((V)&g_heff_2ecompile_2erefcount_2eshapesOfV_clo); V a_1 = v_acc_240; V a_2 = v_t_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
  }
  case TAG_SProj: {
    V v_x21_2420 = heff_field(v_x2_241, 0);
    V v_sh_2422 = heff_field(v_x2_241, 2);
    switch (heff_tag_of(v_x21_2420)) {
    case TAG_SVar: {
      V v_x_2424 = heff_field(v_x21_2420, 0);
      switch (heff_tag_of(v_sh_2422)) {
      case TAG_Nil: {
        return v_acc_240;
      }
      case TAG_Cons: {
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2424), heff_dup(v_sh_2422)}), v_acc_240});
      }
      default: return heff_nomatch(v_sh_2422);
      }
    }
    case TAG_SGlobal: {
      V t_0 = v_acc_240;
      V t_1 = v_x21_2420;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_SInt: {
      V t_0 = v_acc_240;
      V t_1 = v_x21_2420;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_SFloat: {
      V t_0 = v_acc_240;
      V t_1 = v_x21_2420;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_SStr: {
      V t_0 = v_acc_240;
      V t_1 = v_x21_2420;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_SBytes: {
      V t_0 = v_acc_240;
      V t_1 = v_x21_2420;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_SFixed: {
      V t_0 = v_acc_240;
      V t_1 = v_x21_2420;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_SFloat32: {
      V t_0 = v_acc_240;
      V t_1 = v_x21_2420;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_SPrimFn: {
      V t_0 = v_acc_240;
      V t_1 = v_x21_2420;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_SLam: {
      V t_0 = v_acc_240;
      V t_1 = v_x21_2420;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_STag: {
      V t_0 = v_acc_240;
      V t_1 = v_x21_2420;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_SRec: {
      V t_0 = v_acc_240;
      V t_1 = v_x21_2420;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_SProj: {
      V t_0 = v_acc_240;
      V t_1 = v_x21_2420;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_SPrim: {
      V t_0 = v_acc_240;
      V t_1 = v_x21_2420;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_2420);
    }
  }
  case TAG_SPrim: {
    V v_args_2450 = heff_field(v_x2_241, 1);
    return (g_list_2efoldl(((V)&g_heff_2ecompile_2erefcount_2eshapesOfV_clo), v_acc_240, v_args_2450));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2eshapesOfV_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eshapesOfV(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr(V v_seen_240, V v_st_241) {
top: ;
  switch (heff_tag_of(v_st_241)) {
  case TAG_SLet: {
    V v_x_242 = heff_field(v_st_241, 0);
    V v_o_243 = heff_field(v_st_241, 1);
    V v_ru_24st_241_24SLet = heff_take_reuse_n(v_st_241, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_o_243)) {
    case TAG_OSimple: {
      V v_v_244 = heff_dup(heff_field(v_o_243, 0));
      v_t_2412 = ({ V a_0 = v_seen_240; V a_1 = v_v_244; V r_ = (g_heff_2ecompile_2erefcount_2eshapesOfV(a_0, a_1)); heff_drop(v_v_244); r_; });
      break;
    }
    case TAG_OCall: {
      V v_args_246 = heff_dup(heff_field(v_o_243, 1));
      v_t_2412 = ({ V a_0 = v_seen_240; V a_1 = v_args_246; V r_ = (g_list_2efoldl_24s1060781110x816201608(a_0, a_1)); heff_drop(v_args_246); r_; });
      break;
    }
    case TAG_OApply: {
      V v_f_247 = heff_dup(heff_field(v_o_243, 0));
      V v_args_248 = heff_dup(heff_field(v_o_243, 1));
      v_t_2412 = ({ V a_0 = v_seen_240; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_247, v_args_248}); V r_ = (g_list_2efoldl_24s1060781110x816201608(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    case TAG_OPrim: {
      V v_args_2410 = heff_dup(heff_field(v_o_243, 1));
      v_t_2412 = ({ V a_0 = v_seen_240; V a_1 = v_args_2410; V r_ = (g_list_2efoldl_24s1060781110x816201608(a_0, a_1)); heff_drop(v_args_2410); r_; });
      break;
    }
    case TAG_OAbandon: {
      v_t_2412 = v_seen_240;
      break;
    }
    case TAG_OBool: {
      v_t_2412 = v_seen_240;
      break;
    }
    default: heff_nomatch(v_o_243);
    }
    HeffT2 v_t_2413 = (g_heff_2ecompile_2erefcount_2erebuiltOp_24s510905267x500217447_24cpr(v_t_2412, v_o_243));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_s2_2416 = v_field_2414;
      V v_o2_2417 = v_field_2415;
      return ((HeffT2){{v_s2_2416, heff_tag_re_n(v_ru_24st_241_24SLet, TAG_SLet, 2, 1ULL, (V[]){v_x_242, v_o2_2417})}});
    }
  }
  case TAG_SOnce: {
    V v_x_2418 = heff_field(v_st_241, 0);
    V v_o_2419 = heff_field(v_st_241, 1);
    V v_ru_24st_241_24SOnce = heff_take_reuse_n(v_st_241, 3ULL, 2);
    V v_t_2428;
    switch (heff_tag_of(v_o_2419)) {
    case TAG_OSimple: {
      V v_v_2420 = heff_dup(heff_field(v_o_2419, 0));
      v_t_2428 = ({ V a_0 = v_seen_240; V a_1 = v_v_2420; V r_ = (g_heff_2ecompile_2erefcount_2eshapesOfV(a_0, a_1)); heff_drop(v_v_2420); r_; });
      break;
    }
    case TAG_OCall: {
      V v_args_2422 = heff_dup(heff_field(v_o_2419, 1));
      v_t_2428 = ({ V a_0 = v_seen_240; V a_1 = v_args_2422; V r_ = (g_list_2efoldl_24s1060781110x816201608(a_0, a_1)); heff_drop(v_args_2422); r_; });
      break;
    }
    case TAG_OApply: {
      V v_f_2423 = heff_dup(heff_field(v_o_2419, 0));
      V v_args_2424 = heff_dup(heff_field(v_o_2419, 1));
      v_t_2428 = ({ V a_0 = v_seen_240; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_2423, v_args_2424}); V r_ = (g_list_2efoldl_24s1060781110x816201608(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    case TAG_OPrim: {
      V v_args_2426 = heff_dup(heff_field(v_o_2419, 1));
      v_t_2428 = ({ V a_0 = v_seen_240; V a_1 = v_args_2426; V r_ = (g_list_2efoldl_24s1060781110x816201608(a_0, a_1)); heff_drop(v_args_2426); r_; });
      break;
    }
    case TAG_OAbandon: {
      v_t_2428 = v_seen_240;
      break;
    }
    case TAG_OBool: {
      v_t_2428 = v_seen_240;
      break;
    }
    default: heff_nomatch(v_o_2419);
    }
    HeffT2 v_t_2429 = (g_heff_2ecompile_2erefcount_2erebuiltOp_24s510905267x500217447_24cpr(v_t_2428, v_o_2419));
    {
      V v_field_2430 = v_t_2429.f[0];
      V v_field_2431 = v_t_2429.f[1];
      V v_s2_2432 = v_field_2430;
      V v_o2_2433 = v_field_2431;
      return ((HeffT2){{v_s2_2432, heff_tag_re_n(v_ru_24st_241_24SOnce, TAG_SOnce, 2, 1ULL, (V[]){v_x_2418, v_o2_2433})}});
    }
  }
  case TAG_SDecl: {
    return ((HeffT2){{v_seen_240, v_st_241}});
  }
  case TAG_SSet: {
    V v_x_2435 = heff_field(v_st_241, 0);
    V v_o_2436 = heff_field(v_st_241, 1);
    V v_ru_24st_241_24SSet = heff_take_reuse_n(v_st_241, 3ULL, 2);
    V v_t_2445;
    switch (heff_tag_of(v_o_2436)) {
    case TAG_OSimple: {
      V v_v_2437 = heff_dup(heff_field(v_o_2436, 0));
      v_t_2445 = ({ V a_0 = v_seen_240; V a_1 = v_v_2437; V r_ = (g_heff_2ecompile_2erefcount_2eshapesOfV(a_0, a_1)); heff_drop(v_v_2437); r_; });
      break;
    }
    case TAG_OCall: {
      V v_args_2439 = heff_dup(heff_field(v_o_2436, 1));
      v_t_2445 = ({ V a_0 = v_seen_240; V a_1 = v_args_2439; V r_ = (g_list_2efoldl_24s1060781110x816201608(a_0, a_1)); heff_drop(v_args_2439); r_; });
      break;
    }
    case TAG_OApply: {
      V v_f_2440 = heff_dup(heff_field(v_o_2436, 0));
      V v_args_2441 = heff_dup(heff_field(v_o_2436, 1));
      v_t_2445 = ({ V a_0 = v_seen_240; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_2440, v_args_2441}); V r_ = (g_list_2efoldl_24s1060781110x816201608(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    case TAG_OPrim: {
      V v_args_2443 = heff_dup(heff_field(v_o_2436, 1));
      v_t_2445 = ({ V a_0 = v_seen_240; V a_1 = v_args_2443; V r_ = (g_list_2efoldl_24s1060781110x816201608(a_0, a_1)); heff_drop(v_args_2443); r_; });
      break;
    }
    case TAG_OAbandon: {
      v_t_2445 = v_seen_240;
      break;
    }
    case TAG_OBool: {
      v_t_2445 = v_seen_240;
      break;
    }
    default: heff_nomatch(v_o_2436);
    }
    HeffT2 v_t_2446 = (g_heff_2ecompile_2erefcount_2erebuiltOp_24s510905267x500217447_24cpr(v_t_2445, v_o_2436));
    {
      V v_field_2447 = v_t_2446.f[0];
      V v_field_2448 = v_t_2446.f[1];
      V v_s2_2449 = v_field_2447;
      V v_o2_2450 = v_field_2448;
      return ((HeffT2){{v_s2_2449, heff_tag_re_n(v_ru_24st_241_24SSet, TAG_SSet, 2, 1ULL, (V[]){v_x_2435, v_o2_2450})}});
    }
  }
  case TAG_SIf: {
    V v_c_2451 = heff_field(v_st_241, 0);
    V v_ts_2452 = heff_field(v_st_241, 1);
    V v_fs_2453 = heff_field(v_st_241, 2);
    V v_ru_24st_241_24SIf = heff_take_reuse_n(v_st_241, 7ULL, 3);
    HeffT2 v_t_2454 = (g_heff_2ecompile_2erefcount_2erebuiltSts_24s860872616x1839682545_24cpr(heff_dup(v_seen_240), v_ts_2452));
    {
      V v_field_2455 = v_t_2454.f[0];
      V v_field_2456 = v_t_2454.f[1];
      V v_s1_2457 = v_field_2455;
      V v_ts2_2458 = v_field_2456;
      HeffT2 v_t_2459 = (g_heff_2ecompile_2erefcount_2erebuiltSts_24s860872616x1839682545_24cpr(heff_dup(v_seen_240), v_fs_2453));
      {
        V v_field_2460 = v_t_2459.f[0];
        V v_field_2461 = v_t_2459.f[1];
        V v_s2_2462 = v_field_2460;
        V v_fs2_2463 = v_field_2461;
        V v_t_2466 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr_lam0, 1, 2, (V[]){v_s1_2457, v_s2_2462}), v_seen_240));
        return ((HeffT2){{v_t_2466, heff_tag_re_n(v_ru_24st_241_24SIf, TAG_SIf, 3, 1ULL, (V[]){v_c_2451, v_ts2_2458, v_fs2_2463})}});
      }
    }
  }
  case TAG_SCase: {
    V v_v_2467 = heff_field(v_st_241, 0);
    V v_arms_2468 = heff_field(v_st_241, 1);
    V v_ru_24st_241_24SCase = heff_take_reuse_n(v_st_241, 3ULL, 2);
    V v_outs_2478 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr_lam1, 1, 1, (V[]){heff_dup(v_seen_240)}), v_arms_2468));
    V v_outs_2479 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_outs_2478)));
    V v_t_2482 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr_lam2, 1, 1, (V[]){v_outs_2479}), v_seen_240));
    V v_t_2483 = (g_list_2emap_24s1173914895x100384474(v_outs_2478));
    return ((HeffT2){{v_t_2482, heff_tag_re_n(v_ru_24st_241_24SCase, TAG_SCase, 2, 1ULL, (V[]){v_v_2467, v_t_2483})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_st_241)}});
  }
}
V g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr_lam0(V self, V *args) {
  V v_p_2464 = args[0];
  V v_s1_2457 = heff_env(self)[0];
  V v_s2_2462 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2465 = ({ V a_0 = v_p_2464; V a_1 = v_s1_2457; V r_ = (g_list_2eany_24s332132496x946063656(a_0, a_1)); heff_drop(v_s1_2457); r_; });
  if ((heff_dup(v_t_2465) == NTAG(TAG_True))) {
    heff_drop(v_t_2465);
    return ({ V a_0 = v_p_2464; V a_1 = v_s2_2462; V r_ = (g_list_2eany_24s332132496x946063656(a_0, a_1)); heff_drop(v_p_2464); heff_drop(v_s2_2462); r_; });
  } else {
    heff_drop(v_p_2464);
    heff_drop(v_s2_2462);
    heff_drop(v_t_2465);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr_lam1(V self, V *args) {
  V v_a_2469 = args[0];
  V v_seen_240 = heff_env(self)[0];
  switch (heff_tag_of(v_a_2469)) {
  case TAG_MkArm: {
    V v_t_2470 = heff_field(v_a_2469, 0);
    V v_vs_2471 = heff_field(v_a_2469, 1);
    V v_ss_2472 = heff_field(v_a_2469, 2);
    V v_ru_24a_2469_24MkArm = heff_take_reuse_n(v_a_2469, 7ULL, 3);
    heff_clo_take(self, 1);
    HeffT2 v_t_2473 = (g_heff_2ecompile_2erefcount_2erebuiltSts_24s860872616x1839682545_24cpr(v_seen_240, v_ss_2472));
    {
      V v_field_2474 = v_t_2473.f[0];
      V v_field_2475 = v_t_2473.f[1];
      V v_s2_2476 = v_field_2474;
      V v_ss2_2477 = v_field_2475;
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_s2_2476, heff_tag_re_n(v_ru_24a_2469_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2470, v_vs_2471, v_ss2_2477})});
    }
  }
  default: return heff_nomatch(v_a_2469);
  }
}
V g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr_lam3(V self, V *args) {
  V v_o_2481 = args[0];
  V v_p_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_p_2480; V a_1 = v_o_2481; V r_ = (g_list_2eany_24s332132496x946063656(a_0, a_1)); heff_drop(v_p_2480); heff_drop(v_o_2481); r_; });
}
V g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr_lam2(V self, V *args) {
  V v_p_2480 = args[0];
  V v_outs_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2erebuiltSt_24s78107455x1505148853_24cpr_lam3, 1, 1, (V[]){v_p_2480}); V a_1 = v_outs_2479; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_outs_2479); r_; });
}
Clo g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2epeekArgs_24tok2(V v_tok_240, V v_ce_241, V v_x_242, V v_argv_243, V v_rest_244) {
top: ;
  V v_borrowed_245 = heff_take_field(v_ce_241, 6);
  V v_reprs_246 = heff_take_field(v_ce_241, 10);
  V v_self_247 = heff_get_n(v_ce_241, 2, 17);
  switch (heff_tag_of(v_argv_243)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_x_242);
    heff_drop(v_rest_244);
    heff_drop(v_borrowed_245);
    heff_drop(v_reprs_246);
    heff_drop(v_self_247);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_argv1_248 = heff_field(v_argv_243, 0);
    V v_argv2_249 = heff_field(v_argv_243, 1);
    heff_take_n(v_argv_243, 3ULL, 2);
    switch (heff_tag_of(v_argv1_248)) {
    case TAG_SVar: {
      V v_a_2410 = heff_field(v_argv1_248, 0);
      V v_ru_24argv1_248_24SVar = heff_take_reuse_n(v_argv1_248, 1ULL, 1);
      switch (heff_tag_of(v_argv2_249)) {
      case TAG_Nil: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_x_242);
        heff_drop(v_rest_244);
        heff_drop(v_borrowed_245);
        heff_drop(v_reprs_246);
        heff_drop(v_self_247);
        heff_drop(v_a_2410);
        heff_drop_cell(v_ru_24argv1_248_24SVar, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_i_2411 = heff_field(v_argv2_249, 0);
        V v_argv22_2412 = heff_field(v_argv2_249, 1);
        heff_take_n(v_argv2_249, 3ULL, 2);
        switch (heff_tag_of(v_argv22_2412)) {
        case TAG_Nil: {
          V v_t_2413 = ({ V a_0 = v_a_2410; V a_1 = v_borrowed_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_borrowed_245); r_; });
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_t_2413);
            HeffT2 v_t_2414 = ({ V a_0 = v_reprs_246; V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_reprs_246); r_; });
            {
              V v_field_2416 = v_t_2414.f[1];
              int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
              if ((v_tag_2415 == ((int64_t)0ULL))) {
                V v_x_2417 = v_field_2416;
                switch (heff_tag_of(v_x_2417)) {
                case TAG_RepV: {
                  V v_t_2418 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erefcount_2enotFlatAt_clo), 2, (V[]){v_self_247, v_x_242}));
                  V v_t_2419 = (g_heff_2ecompile_2erefcount_2eanyW(v_t_2418, v_rest_244));
                  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
                    heff_drop(v_t_2419);
                    return heff_tag_at_n(v_ru_24argv1_248_24SVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_a_2410, v_i_2411})});
                  } else {
                    heff_drop_cell(v_tok_240, 2);
                    heff_drop(v_a_2410);
                    heff_drop_cell(v_ru_24argv1_248_24SVar, 1);
                    heff_drop(v_i_2411);
                    heff_drop(v_t_2419);
                    return NTAG(TAG_Nothing);
                  }
                }
                case TAG_RepFix: {
                  heff_take_n(v_x_2417, 0ULL, 1);
                  heff_drop_cell(v_tok_240, 2);
                  heff_drop(v_x_242);
                  heff_drop(v_rest_244);
                  heff_drop(v_self_247);
                  heff_drop(v_a_2410);
                  heff_drop_cell(v_ru_24argv1_248_24SVar, 1);
                  heff_drop(v_i_2411);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepF64: {
                  heff_drop_cell(v_tok_240, 2);
                  heff_drop(v_x_242);
                  heff_drop(v_rest_244);
                  heff_drop(v_self_247);
                  heff_drop(v_a_2410);
                  heff_drop_cell(v_ru_24argv1_248_24SVar, 1);
                  heff_drop(v_i_2411);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepInt: {
                  heff_drop_cell(v_tok_240, 2);
                  heff_drop(v_x_242);
                  heff_drop(v_rest_244);
                  heff_drop(v_self_247);
                  heff_drop(v_a_2410);
                  heff_drop_cell(v_ru_24argv1_248_24SVar, 1);
                  heff_drop(v_i_2411);
                  return NTAG(TAG_Nothing);
                }
                default: return heff_nomatch(v_x_2417);
                }
              } else {
                heff_drop(v_field_2416);
                V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erefcount_2enotFlatAt_clo), 2, (V[]){v_self_247, v_x_242}));
                V v_t_2422 = (g_heff_2ecompile_2erefcount_2eanyW(v_t_2421, v_rest_244));
                if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
                  heff_drop(v_t_2422);
                  return heff_tag_at_n(v_ru_24argv1_248_24SVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_a_2410, v_i_2411})});
                } else {
                  heff_drop_cell(v_tok_240, 2);
                  heff_drop(v_a_2410);
                  heff_drop_cell(v_ru_24argv1_248_24SVar, 1);
                  heff_drop(v_i_2411);
                  heff_drop(v_t_2422);
                  return NTAG(TAG_Nothing);
                }
              }
            }
          } else {
            heff_drop_cell(v_tok_240, 2);
            heff_drop(v_x_242);
            heff_drop(v_rest_244);
            heff_drop(v_reprs_246);
            heff_drop(v_self_247);
            heff_drop(v_a_2410);
            heff_drop_cell(v_ru_24argv1_248_24SVar, 1);
            heff_drop(v_i_2411);
            heff_drop(v_t_2413);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_argv22_2412, 0ULL, 2);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_x_242);
          heff_drop(v_rest_244);
          heff_drop(v_borrowed_245);
          heff_drop(v_reprs_246);
          heff_drop(v_self_247);
          heff_drop(v_a_2410);
          heff_drop_cell(v_ru_24argv1_248_24SVar, 1);
          heff_drop(v_i_2411);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_argv22_2412);
        }
      }
      default: return heff_nomatch(v_argv2_249);
      }
    }
    case TAG_SGlobal: {
      heff_take_n(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      return NTAG(TAG_Nothing);
    }
    case TAG_SInt: {
      heff_take_n(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat: {
      heff_take_na(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      return NTAG(TAG_Nothing);
    }
    case TAG_SStr: {
      heff_take_n(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      return NTAG(TAG_Nothing);
    }
    case TAG_SBytes: {
      heff_take_n(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFixed: {
      heff_take_n(v_argv1_248, 0ULL, 2);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat32: {
      heff_take_na(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFn: {
      heff_take_n(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_argv1_248, 0ULL, 2);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_argv1_248, 0ULL, 3);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_argv1_248, 0ULL, 2);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_argv1_248, 0ULL, 4);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_argv1_248, 0ULL, 2);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_argv1_248);
    }
  }
  default: return heff_nomatch(v_argv_243);
  }
}
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2epeekArgs_24tok2(a[0], a[1], a[2], a[3], a[4]);
}