// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565 57410
#define TAG_Given 9359
#define TAG_KnownCell 38933
#define TAG_MkCArm 24694
#define TAG_RAbandon 7524
#define TAG_RCall 39004
#define TAG_RLocal 34280
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RTag 45075
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define LBL_after 294093302
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_counted 1189688364
#define LBL_flat 9641024
#define LBL_flats 298871860
#define LBL_funs 9650075
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_names 305943394
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_plain 308106724
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tags 10047712
#define LBL_takes 311482598
#define LBL_tokens 1078955205
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tokens, LBL_ret};
V g_heff_2ecompile_2erefcount_2eagrees(V, V, V);
V g_heff_2ecompile_2erefcount_2eagrees_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eagrees_clo;
V g_heff_2ecompile_2erefcount_2eapplyLast(V, V, V);
V g_heff_2ecompile_2erefcount_2eapplyLast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eapplyLast_clo;
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_clo;
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_clo;
V g_heff_2ecompile_2erefcount_2ecallAs(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecallAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecallAs_clo;
V g_heff_2ecompile_2erefcount_2ecoerce(V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_clo;
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok2_clo;
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(V, V);
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461_clo;
V g_heff_2ecompile_2erefcount_2efieldMask(V, V, V);
V g_heff_2ecompile_2erefcount_2efieldMask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldMask_clo;
V g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775_clo;
V g_heff_2ecompile_2erefcount_2efvSts(V);
V g_heff_2ecompile_2erefcount_2efvSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvSts_clo;
V g_heff_2ecompile_2erefcount_2efvSts_24tok1(V, V);
V g_heff_2ecompile_2erefcount_2efvSts_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvSts_24tok1_clo;
V g_heff_2ecompile_2erefcount_2efvTl(V);
V g_heff_2ecompile_2erefcount_2efvTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_clo;
V g_heff_2ecompile_2erefcount_2efvTl_24tok1(V, V);
V g_heff_2ecompile_2erefcount_2efvTl_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_24tok1_clo;
V g_heff_2ecompile_2erefcount_2efvVal(V);
V g_heff_2ecompile_2erefcount_2efvVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvVal_clo;
V g_heff_2ecompile_2erefcount_2eintW(V, V);
V g_heff_2ecompile_2erefcount_2eintW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eintW_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ekeptFrom_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo;
V g_heff_2ecompile_2erefcount_2elentField(V, V, V);
V g_heff_2ecompile_2erefcount_2elentField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentField_clo;
V g_heff_2ecompile_2erefcount_2elentIn(V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentIn_clo;
V g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_clo;
V g_heff_2ecompile_2erefcount_2enthValue(V, V);
V g_heff_2ecompile_2erefcount_2enthValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2enthValue_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_clo;
V g_heff_2ecompile_2erefcount_2epeekPrim_get(void);
V g_heff_2ecompile_2erefcount_2epow2(V);
V g_heff_2ecompile_2erefcount_2epow2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epow2_clo;
V g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082_clo;
V g_heff_2ecompile_2erefcount_2esameAs(V, V, V);
V g_heff_2ecompile_2erefcount_2esameAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esameAs_clo;
V g_heff_2ecompile_2erefcount_2esameS(V, V);
V g_heff_2ecompile_2erefcount_2esameS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esameS_clo;
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_clo;
V g_heff_2ecompile_2erefcount_2eslotBits(V);
V g_heff_2ecompile_2erefcount_2eslotBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eslotBits_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etagGiven_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3_clo;
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo;
V g_heff_2ecompile_2erefcount_2etakeOf(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeOf_clo;
V g_heff_2ecompile_2erefcount_2ethreadSt(V, V, V);
V g_heff_2ecompile_2erefcount_2ethreadSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ethreadSt_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(V, V, V);
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2ereprsEq(V, V);
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsEq_clo;
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_list_2eall_24s1793250635x935291087(V);
V g_list_2eall_24s1793250635x935291087_entry(V self, V *a);
extern Clo g_list_2eall_24s1793250635x935291087_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s826961155x1314392429(V, V);
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s826961155x1314392429_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f889159142x1775976195(V, V, V, V);
V g_list_2emap_24f889159142x1775976195_entry(V self, V *a);
extern Clo g_list_2emap_24f889159142x1775976195_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24tok1(V, V);
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24tok1_clo;
V g_list_2emap_24s976303750x321235480(V);
V g_list_2emap_24s976303750x321235480_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s870182194x1066240094(V, V);
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithTakes_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ewithTakes(V v_ts_240, V v_ce_241) {
top: ;
  V v_funs_242 = heff_take_field(v_ce_241, 0);
  V v_bounce_243 = heff_take_field(v_ce_241, 1);
  V v_self_244 = heff_take_field(v_ce_241, 2);
  V v_lam_245 = heff_take_field(v_ce_241, 3);
  V v_owned_246 = heff_take_field(v_ce_241, 4);
  V v_after_247 = heff_take_field(v_ce_241, 5);
  V v_borrowed_248 = heff_take_field(v_ce_241, 6);
  V v_bor_249 = heff_take_field(v_ce_241, 7);
  V v_known_2410 = heff_take_field(v_ce_241, 8);
  V v_reprs_2411 = heff_take_field(v_ce_241, 10);
  V v_sigs_2412 = heff_take_field(v_ce_241, 11);
  V v_flat_2413 = heff_take_field(v_ce_241, 12);
  V v_sure_2414 = heff_take_field(v_ce_241, 13);
  V v_sureRecs_2415 = heff_take_field(v_ce_241, 14);
  V v_tokens_2416 = heff_take_field(v_ce_241, 15);
  V v_ret_2417 = heff_get_n(v_ce_241, 16, 17);
  return heff_rec_n(17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, (V[]){v_funs_242, v_bounce_243, v_self_244, v_lam_245, v_owned_246, v_after_247, v_borrowed_248, v_bor_249, v_known_2410, v_ts_240, v_reprs_2411, v_sigs_2412, v_flat_2413, v_sure_2414, v_sureRecs_2415, v_tokens_2416, v_ret_2417});
}
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithTakes(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2esameS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esameS_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2esameS(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_x_244, v_y_246, 0)) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2esameS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2esameS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2erefcount_2ekeptFrom_24cpr(V v_ls_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_l_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_SVar: {
      heff_take_n(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SInt: {
      heff_take_n(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFloat: {
      heff_take_na(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SStr: {
      heff_take_n(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SBytes: {
      heff_take_n(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFixed: {
      heff_take_n(v_x22_243, 0ULL, 2);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFloat32: {
      heff_take_na(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimFn: {
      heff_take_n(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      heff_take_n(v_x22_243, 0ULL, 2);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_x22_243, 0ULL, 3);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_x22_243, 0ULL, 2);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      V v_e_2421 = heff_field(v_x22_243, 0);
      V v_l2_2422 = heff_field(v_x22_243, 1);
      V v_sh_2423 = heff_field(v_x22_243, 2);
      heff_take_n(v_x22_243, 7ULL, 4);
      if (heff_strEq_c(v_l_242, v_l2_2422)) {
        V v_t_2425 = ({ V a_0 = v_ls_240; V a_1 = v_sh_2423; V r_ = (g_heff_2ecompile_2erefcount_2esameS(a_0, a_1)); heff_drop(v_sh_2423); r_; });
        if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
          heff_drop(v_t_2425);
          switch (heff_tag_of(v_e_2421)) {
          case TAG_SVar: {
            V v_x_2426 = heff_field(v_e_2421, 0);
            heff_take_n(v_e_2421, 1ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2426}});
          }
          case TAG_SGlobal: {
            heff_take_n(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SInt: {
            heff_take_n(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SFloat: {
            heff_take_na(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SStr: {
            heff_take_n(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SBytes: {
            heff_take_n(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SFixed: {
            heff_take_n(v_e_2421, 0ULL, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SFloat32: {
            heff_take_na(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SPrimFn: {
            heff_take_n(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLam: {
            heff_take_n(v_e_2421, 0ULL, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_STag: {
            heff_take_n(v_e_2421, 0ULL, 3);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SRec: {
            heff_take_n(v_e_2421, 0ULL, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SProj: {
            heff_take_n(v_e_2421, 0ULL, 4);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SPrim: {
            heff_take_n(v_e_2421, 0ULL, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_e_2421)}});
          }
        } else {
          heff_drop(v_e_2421);
          heff_drop(v_t_2425);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_e_2421);
        heff_drop(v_sh_2423);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_SPrim: {
      heff_take_n(v_x22_243, 0ULL, 2);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x22_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2esameAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esameAs_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2esameAs(V v_ce_240, V v_x2_241, V v_g_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_s_243 = heff_field(v_x2_241, 0);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 11), heff_rfield(v_s_243, 0)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      HeffT2 v_t_247 = ({ V b_0 = heff_get_n(v_ce_240, 11, 17); V a_1 = v_g_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          V v_a_2410 = v_field_246;
          V v_params_2411 = heff_take_field(v_a_2410, 0);
          V v_result_2412 = heff_get_n(v_a_2410, 1, 2);
          if ((v_tag_248 == ((int64_t)0ULL))) {
            V v_b_2413 = v_field_249;
            V v_params_2414 = heff_take_field(v_b_2413, 0);
            V v_result_2415 = heff_get_n(v_b_2413, 1, 2);
            V v_t_2416 = ({ V a_0 = v_params_2411; V a_1 = v_params_2414; V r_ = (g_heff_2ecompile_2erepr_2ereprsEq(a_0, a_1)); heff_drop(v_params_2411); heff_drop(v_params_2414); r_; });
            if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
              heff_drop(v_t_2416);
              return ({ V a_0 = v_result_2412; V a_1 = v_result_2415; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_result_2412); heff_drop(v_result_2415); r_; });
            } else {
              heff_drop(v_result_2412);
              heff_drop(v_result_2415);
              heff_drop(v_t_2416);
              return NTAG(TAG_False);
            }
          } else {
            heff_drop(v_field_249);
            heff_drop(v_params_2411);
            heff_drop(v_result_2412);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop(v_field_246);
          V v_ret_24bool = heff_bool(((v_tag_248 == ((int64_t)0ULL)) ? ({ V v_x_2417 = heff_dup(v_field_249); int c_ = 0; heff_drop(v_x_2417); c_; }) : 1));
          heff_drop(v_field_249);
          return v_ret_24bool;
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2esameAs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2esameAs(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erefcount_2eapplyLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eapplyLast_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eapplyLast(V v_ce_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_n_241);
    V v_t_243 = heff_tag_n(TAG_CReturn, 1, (V[]){NTAG(TAG_RAbandon)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246;
    if ((heff_intLt_c_lent(MK_INT(0LL), v_n_241, 1) && heff_intLe_c(heff_dup(v_n_241), heff_dup(heff_rfield(v_ce_240, 3))))) {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_n_241);
      v_t_246 = heff_tag_n(TAG_CInPlace, 2, (V[]){v_f_244, v_vs_245});
    } else {
      if ((heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_ce_240, 3))) && heff_intLe_c_lent(v_n_241, MK_INT(4LL), 2))) {
        heff_drop_rec(v_ce_240, 17);
        heff_drop(v_n_241);
        v_t_246 = heff_tag_n(TAG_CRoomed, 2, (V[]){v_f_244, v_vs_245});
      } else {
        heff_drop_rec(v_ce_240, 17);
        heff_drop(v_n_241);
        v_t_246 = heff_tag_n(TAG_CTail, 2, (V[]){v_f_244, v_vs_245});
      }
    }
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2eapplyLast_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eapplyLast(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2efieldMask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efieldMask_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2efieldMask(V v_used_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x3_242, 0);
    V v_vs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ecompile_2erefcount_2eelemS(v_v_243, v_used_240));
    V v_t_246;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      v_t_246 = (g_heff_2ecompile_2erefcount_2epow2(heff_dup(v_i_241)));
    } else {
      heff_drop(v_t_245);
      v_t_246 = MK_INT(0LL);
    }
    V v_t_247 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_vs_244));
    return heff_intAdd(v_t_246, v_t_247);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2efieldMask_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2efieldMask(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erefcount_2ecallAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecallAs_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2ecallAs(V v_ce_240, V v_g_241, V v_argv_242, V v_loop_243, V v_ls_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_ce_240, 2));
  V v_t_249;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_s_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_key_247 = heff_take_field(v_s_246, 0);
    V v_params_248 = heff_get_n(v_s_246, 1, 2);
    if ((heff_strEq_c_lent(v_key_247, v_g_241, 0) && ({ V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_params_248)); int c_ = ({ V v_t_2447 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242)); int c_ = heff_intEq_c_lent(v_t_2446, v_t_2447, 0); heff_drop(v_t_2447); c_; }); heff_drop(v_t_2446); c_; }))) {
      heff_drop(v_key_247);
      heff_drop(v_params_248);
      v_t_249 = (g_list_2eall_24s1793250635x935291087(v_loop_243));
    } else {
      heff_drop(v_key_247);
      heff_drop(v_params_248);
      v_t_249 = NTAG(TAG_False);
    }
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_g_241);
    heff_drop(v_ls_244);
    heff_drop(v_t_249);
    V v_vs_2410 = (g_list_2emap_24s976303750x321235480(v_loop_243));
    V v_t_2411 = heff_get_n(v_ce_240, 2, 17);
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      heff_drop(v_vs_2410);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      V v_s_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      V v_t_2413 = heff_tag_n(TAG_CLoop, 2, (V[]){heff_get_n(v_s_2412, 1, 2), v_vs_2410});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_2411);
    }
  } else {
    heff_drop(v_loop_243);
    heff_drop(v_t_249);
    V v_t_2414 = (g_heff_2ecompile_2erefcount_2eagrees(heff_dup(v_ce_240), v_g_241, v_argv_242));
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V v_t_2415 = (g_list_2eall_24s1793250635x935291087(v_ls_244));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_ce_240, 11, 17); V a_1 = v_g_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2420;
        {
          V v_field_2418 = v_t_2416.f[1];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          v_t_2420 = heff_bool(((v_tag_2417 == ((int64_t)0ULL)) && ({ V v_x_2419 = heff_dup(v_field_2418); int c_ = 1; heff_drop(v_x_2419); c_; })));
          heff_drop(v_field_2418);
        }
        V v_t_2421 = (g_list_2emap_24s976303750x321235480(v_ls_244));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CJump, 3, (V[]){v_g_241, v_t_2420, v_t_2421}), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_t_2415);
        HeffT2 v_t_2422 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
        V v_t_2426;
        {
          V v_field_2424 = v_t_2422.f[1];
          int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
          if ((v_tag_2423 == ((int64_t)0ULL))) {
            V v_s_2425 = v_field_2424;
            v_t_2426 = heff_get_n(v_s_2425, 1, 2);
          } else {
            heff_drop(v_field_2424);
            v_t_2426 = NTAG(TAG_RepV);
          }
        }
        HeffT2 v_t_2427 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
        V v_t_2431;
        {
          V v_field_2429 = v_t_2427.f[1];
          int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
          if ((v_tag_2428 == ((int64_t)0ULL))) {
            V v_x_2430 = v_field_2429;
            v_t_2431 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2430, 1, 2)});
          } else {
            heff_drop(v_field_2429);
            v_t_2431 = NTAG(TAG_Nothing);
          }
        }
        V v_t_2432 = heff_tag_n(TAG_RCall, 4, (V[]){v_g_241, NTAG(TAG_False), v_t_2431, v_ls_244});
        V v_t_2433 = (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2426, heff_get_n(v_ce_240, 16, 17), v_t_2432));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_2433}), NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_t_2414);
      HeffT2 v_t_2434 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
      V v_t_2438;
      {
        V v_field_2436 = v_t_2434.f[1];
        int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
        if ((v_tag_2435 == ((int64_t)0ULL))) {
          V v_s_2437 = v_field_2436;
          v_t_2438 = heff_get_n(v_s_2437, 1, 2);
        } else {
          heff_drop(v_field_2436);
          v_t_2438 = NTAG(TAG_RepV);
        }
      }
      HeffT2 v_t_2439 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
      V v_t_2443;
      {
        V v_field_2441 = v_t_2439.f[1];
        int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
        if ((v_tag_2440 == ((int64_t)0ULL))) {
          V v_x_2442 = v_field_2441;
          v_t_2443 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2442, 1, 2)});
        } else {
          heff_drop(v_field_2441);
          v_t_2443 = NTAG(TAG_Nothing);
        }
      }
      V v_t_2444 = heff_tag_n(TAG_RCall, 4, (V[]){v_g_241, NTAG(TAG_False), v_t_2443, v_ls_244});
      V v_t_2445 = (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2438, heff_get_n(v_ce_240, 16, 17), v_t_2444));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_2445}), NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2ecompile_2erefcount_2ecallAs_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2ecallAs(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2ethreadSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ethreadSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ethreadSt_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ethreadSt(V v_th_240, V v_go_241, V v_s_242) {
top: ;
  V v_tags_243 = heff_take_field(v_th_240, 1);
  V v_at_244 = heff_get_n(v_th_240, 0, 2);
  switch (heff_tag_of(v_s_242)) {
  case TAG_CDrop: {
    heff_drop(v_go_241);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    return v_s_242;
  }
  case TAG_CLet: {
    heff_drop(v_go_241);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    return v_s_242;
  }
  case TAG_CDecl: {
    heff_drop(v_go_241);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    return v_s_242;
  }
  case TAG_CSet: {
    heff_drop(v_go_241);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    return v_s_242;
  }
  case TAG_CAbandon: {
    heff_drop(v_go_241);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    return v_s_242;
  }
  case TAG_CIf: {
    V v_c_2411 = heff_field(v_s_242, 0);
    V v_a_2412 = heff_field(v_s_242, 1);
    V v_b_2413 = heff_field(v_s_242, 2);
    V v_ru_24s_242_24CIf = heff_take_reuse_n(v_s_242, 7ULL, 3);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    V v_t_2414 = heff_tr(heff_call(heff_dup(v_go_241), 1, (V[]){v_a_2412}));
    V v_t_2415 = heff_tr(heff_call(v_go_241, 1, (V[]){v_b_2413}));
    return heff_tag_at_n(v_ru_24s_242_24CIf, TAG_CIf, 3, (V[]){v_c_2411, v_t_2414, v_t_2415});
  }
  case TAG_CSwitch: {
    V v_e_2416 = heff_field(v_s_242, 0);
    V v_arms_2417 = heff_field(v_s_242, 1);
    V v_r_2418 = heff_field(v_s_242, 2);
    V v_ru_24s_242_24CSwitch = heff_take_reuse_n(v_s_242, 7ULL, 3);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ethreadSt_lam0, 1, 1, (V[]){v_go_241}), v_arms_2417));
    return heff_tag_at_n(v_ru_24s_242_24CSwitch, TAG_CSwitch, 3, (V[]){v_e_2416, v_t_2429, v_r_2418});
  }
  case TAG_CReturn: {
    heff_drop(v_go_241);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    return v_s_242;
  }
  case TAG_CInPlace: {
    heff_drop(v_go_241);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    return v_s_242;
  }
  case TAG_CRoomed: {
    heff_drop(v_go_241);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    return v_s_242;
  }
  case TAG_CTail: {
    heff_drop(v_go_241);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    return v_s_242;
  }
  case TAG_CLoop: {
    V v_ps_2437 = heff_field(v_s_242, 0);
    V v_vs_2438 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CLoop = heff_take_reuse_n(v_s_242, 3ULL, 2);
    heff_drop(v_go_241);
    V v_t_2439 = (g_heff_2ecompile_2erefcount_2enthValue(v_at_244, heff_dup(v_vs_2438)));
    HeffT2 v_t_2440 = ({ V a_0 = v_tags_243; V a_1 = v_t_2439; HeffT2 r_ = (g_heff_2ecompile_2erefcount_2etagGiven_24cpr(a_0, a_1)); heff_drop(v_tags_243); heff_drop(v_t_2439); r_; });
    {
      V v_field_2442 = v_t_2440.f[1];
      int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
      if ((v_tag_2441 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24s_242_24CLoop, 2);
        V v_t_2443 = v_field_2442;
        return heff_tag_n(TAG_CLoopTo, 3, (V[]){v_t_2443, v_ps_2437, v_vs_2438});
      } else {
        heff_drop(v_field_2442);
        return heff_tag_at_n(v_ru_24s_242_24CLoop, TAG_CLoop, 2, (V[]){v_ps_2437, v_vs_2438});
      }
    }
  }
  case TAG_CLoopTo: {
    heff_drop(v_go_241);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    return v_s_242;
  }
  case TAG_CLabel: {
    heff_drop(v_go_241);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    return v_s_242;
  }
  case TAG_CJump: {
    heff_drop(v_go_241);
    heff_drop(v_tags_243);
    heff_drop(v_at_244);
    return v_s_242;
  }
  default: return heff_nomatch(v_s_242);
  }
}
V g_heff_2ecompile_2erefcount_2ethreadSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ethreadSt(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2ethreadSt_lam0(V self, V *args) {
  V v_x2_2419 = args[0];
  V v_go_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkCArm: {
    V v_t_2420 = heff_field(v_x2_2419, 0);
    V v_fs_2421 = heff_field(v_x2_2419, 1);
    V v_fl_2422 = heff_field(v_x2_2419, 2);
    V v_su_2423 = heff_field(v_x2_2419, 3);
    V v_pl_2424 = heff_field(v_x2_2419, 4);
    V v_tk_2425 = heff_field(v_x2_2419, 5);
    V v_body_2426 = heff_field(v_x2_2419, 6);
    V v_lv_2427 = heff_field(v_x2_2419, 7);
    V v_ru_24x2_2419_24MkCArm = heff_take_reuse_n(v_x2_2419, 255ULL, 8);
    V v_t_2428 = heff_tr(heff_call(v_go_241, 1, (V[]){v_body_2426}));
    return heff_tag_at_n(v_ru_24x2_2419_24MkCArm, TAG_MkCArm, 8, (V[]){v_t_2420, v_fs_2421, v_fl_2422, v_su_2423, v_pl_2424, v_tk_2425, v_t_2428, v_lv_2427});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
Clo g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461(V v_ce_240, V v_live_241, V v_p_242, V v_argv_243, V v_e_244, V v_rp_245) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_rp_245)) {
  case TAG_RepV: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  case TAG_RepFix: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_RepF64: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_RepInt: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_rp_245);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_e_244);
    heff_drop(v_rp_245);
    heff_drop(v_t_247);
    V v_t_248 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_243));
    return heff_tag_n(TAG_RPrim, 2, (V[]){v_p_242, v_t_248});
  } else {
    heff_drop(v_t_247);
    V v_t_2410;
    switch (heff_tag_of(v_rp_245)) {
    case TAG_RepV: {
      v_t_2410 = NTAG(TAG_False);
      break;
    }
    case TAG_RepFix: {
      v_t_2410 = NTAG(TAG_False);
      break;
    }
    case TAG_RepF64: {
      v_t_2410 = NTAG(TAG_False);
      break;
    }
    case TAG_RepInt: {
      v_t_2410 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_rp_245);
    }
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_rp_245);
      heff_drop(v_t_2410);
      V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
      V v_t_2412 = (g_list_2emap_24f889159142x1775976195(v_e_244, NTAG(TAG_RepV), MK_INT(0LL), heff_intSub(v_t_2411, MK_INT(1LL))));
      V v_t_2413 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_240, v_live_241, v_t_2412, v_argv_243));
      return heff_tag_n(TAG_RPrim, 2, (V[]){v_p_242, v_t_2413});
    } else {
      heff_drop(v_t_2410);
      V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
      V v_t_2415 = (g_list_2emap_24f889159142x1775976195(v_e_244, heff_dup(v_rp_245), MK_INT(0LL), heff_intSub(v_t_2414, MK_INT(1LL))));
      V v_t_2416 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_240, v_live_241, v_t_2415, v_argv_243));
      return heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_242, v_rp_245, v_t_2416});
    }
  }
}
V g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082_entry, 9, 0};

V g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082(V v_ce_240, V v_live_241, V v_want_242, V v_v_243, V v_e_244, V v_su_245, V v_n_246, V v_x9_247, V v_rp_248) {
top: ;
  switch (heff_tag_of(v_x9_247)) {
  case TAG_Nothing: {
    heff_drop(v_e_244);
    heff_drop(v_su_245);
    heff_drop(v_n_246);
    heff_drop(v_rp_248);
    V v_t_249 = (g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_249));
  }
  case TAG_Just: {
    V v_i_2410 = heff_field(v_x9_247, 0);
    V v_ru_24x9_247_24Just = heff_take_reuse_n(v_x9_247, 1ULL, 1);
    V v_t_2415;
    switch (heff_tag_of(v_rp_248)) {
    case TAG_RepV: {
      v_t_2415 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2415 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      break;
    }
    case TAG_RepF64: {
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2415 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      break;
    }
    case TAG_RepInt: {
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2415 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      break;
    }
    default: heff_nomatch(v_rp_248);
    }
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_e_244);
      heff_drop(v_su_245);
      heff_drop(v_n_246);
      heff_drop(v_rp_248);
      heff_drop(v_i_2410);
      heff_drop_cell(v_ru_24x9_247_24Just, 1);
      heff_drop(v_t_2415);
      V v_t_2416 = (g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(v_ce_240, v_live_241, v_v_243));
      return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2416));
    } else {
      heff_drop(v_v_243);
      heff_drop(v_t_2415);
      V v_t_2440;
      switch (heff_tag_of(v_e_244)) {
      case TAG_SVar: {
        V v_x_2417 = heff_dup(heff_field(v_e_244, 0));
        v_t_2440 = heff_tag_at_n(v_ru_24x9_247_24Just, TAG_Just, 1, (V[]){v_x_2417});
        break;
      }
      case TAG_SGlobal: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_244);
      }
      V v_t_2464;
      switch (heff_tag_of(v_e_244)) {
      case TAG_SVar: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SGlobal: {
        V v_g_2442 = heff_dup(heff_field(v_e_244, 0));
        v_t_2464 = heff_tag_n(TAG_Just, 1, (V[]){v_g_2442});
        break;
      }
      case TAG_SInt: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_244);
      }
      V v_t_2465 = (g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775(v_ce_240, v_live_241, v_e_244, heff_dup(v_rp_248), v_su_245, v_i_2410, v_n_246, v_t_2440, v_t_2464));
      return (g_heff_2ecompile_2erefcount_2ecoerce(v_rp_248, v_want_242, v_t_2465));
    }
  }
  default: return heff_nomatch(v_x9_247);
  }
}
V g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153(V v_ce_240, V v_lent_241, V v_live_242, V v_bi_243, V v_i_244, V v_e_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    V v_t_2434;
    switch (heff_tag_of(v_e_245)) {
    case TAG_SVar: {
      V v_x_247 = heff_dup(heff_field(v_e_245, 0));
      HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(heff_rfield(v_ce_240, 10), v_x_247));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          heff_drop(v_x_247);
          V v_x_2411 = v_field_2410;
          heff_drop(v_x_2411);
          v_t_2434 = NTAG(TAG_Nothing);
        } else {
          heff_drop(v_field_2410);
          v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_x_247});
        }
      }
      break;
    }
    case TAG_SGlobal: {
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SInt: {
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat: {
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SStr: {
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SBytes: {
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFixed: {
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat32: {
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrimFn: {
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrim: {
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_245);
    }
    HEFF_LAST return g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330(v_ce_240, v_lent_241, v_live_242, v_bi_243, v_i_244, v_e_245, v_t_2434);
  }
  case TAG_Just: {
    V v_a_2435 = heff_field(v_x8_246, 0);
    V v_ru_24x8_246_24Just = heff_take_reuse_n(v_x8_246, 1ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_242);
    heff_drop(v_i_244);
    heff_drop(v_e_245);
    return heff_tag_at_n(v_ru_24x8_246_24Just, TAG_Given, 1, (V[]){v_a_2435});
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153(a[0], a1, a[2], a3, a[4], a[5], a[6]); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_e_245, V v_es_246) {
top: ;
  V v_t_247 = (g_heff_2ecompile_2erefcount_2elentIn(heff_dup(v_ce_240), v_bi_243, heff_intAdd(heff_dup(v_i_244), MK_INT(1LL)), heff_dup(v_es_246)));
  V v_lent_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_live_241)));
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_246));
  V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, heff_dup(v_live_241)));
  V v_live_2412 = (g_prelude_2e_2b_2b(v_before_242, v_t_2411));
  V v_t_2413 = (g_heff_2ecompile_2erefcount_2eelemI(heff_dup(v_i_244), v_bi_243));
  V v_t_2414;
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_t_2413);
    v_t_2414 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_live_241; V a_2 = v_e_245; V r_ = (g_heff_2ecompile_2erefcount_2elentField(a_0, a_1, a_2)); heff_drop(v_live_241); r_; });
  } else {
    heff_drop(v_live_241);
    heff_drop(v_t_2413);
    v_t_2414 = NTAG(TAG_Nothing);
  }
  return ({ V a_0 = v_ce_240; V a_1 = v_lent_248; V a_2 = v_live_2412; V a_3 = v_bi_243; V a_4 = v_i_244; V a_5 = v_e_245; V a_6 = v_t_2414; V r_ = (g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_lent_248); r_; });
}
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_rp_247 = heff_field(v_x7_245, 0);
    V v_rps_248 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_i_244);
      heff_drop(v_rp_247);
      heff_drop(v_rps_248);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_249 = heff_field(v_x8_246, 0);
      V v_es_2410 = heff_field(v_x8_246, 1);
      heff_take_n(v_x8_246, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), v_bi_243, heff_dup(v_i_244), v_rp_247, heff_dup(v_e_249), heff_dup(v_es_2410)));
      V v_cell_2412 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_t_2413 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = heff_dup(v_i_244); V a_3 = v_e_249; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_249); r_; });
      V v_u_2414 = (g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(v_ce_240, v_live_241, v_t_2413, v_bi_243, heff_box_word((heff_unbox_word(v_i_244) + ((int64_t)1ULL))), v_rps_248, v_es_2410, heff_dup(v_cell_2412)));
      heff_drop(v_u_2414);
      return v_cell_2412;
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam2(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(V v_ce_240, V v_x_241, V v_a_242, V v_i_243, V v_rest_244, V v_after_245, V v_wb_246) {
top: ;
  V v_t_247 = (g_heff_2ecompile_2erefcount_2efvVal(heff_dup(v_i_243)));
  V v_wanted_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_wb_246)));
  V v_xs_2411 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam0, 1, 1, (V[]){v_wanted_248}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2412 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2411));
  V v_t_2413 = (g_list_2emap_24s1796125103x644876049(v_t_2412));
  V v_t_2414 = (g_heff_2ecompile_2erefcount_2efvVal(heff_dup(v_i_243)));
  V v_wanted_2415 = (g_prelude_2e_2b_2b(v_t_2414, heff_dup(v_wb_246)));
  V v_t_2417 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam1, 1, 1, (V[]){v_wanted_2415}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_ce_2418 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2417, heff_dup(v_wb_246), heff_dup(v_ce_240)));
  V v_t_2419 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_2418, heff_dup(v_wb_246), NTAG(TAG_RepV), v_i_243));
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_a_242}), v_t_2420});
  V v_t_2422 = heff_tag_n(TAG_CLet, 2, (V[]){heff_dup(v_x_241), heff_tag_n(TAG_RPrim, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2epeekPrim_get()), v_t_2421})});
  V v_t_2424 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam2, 1, 1, (V[]){v_wb_246}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, heff_dup(heff_rfield(v_ce_240, 6))});
  V v_t_2426 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2425, heff_dup(v_ce_240)));
  V v_ce_2427 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2424, heff_get_n(v_ce_240, 5, 17), v_t_2426));
  V v_t_2428 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2427, v_rest_244, v_after_245));
  return (g_prelude_2e_2b_2b(v_t_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2428})));
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam0(V self, V *args) {
  V v_v_249 = args[0];
  V v_wanted_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2410 = ({ V a_0 = v_v_249; V a_1 = v_wanted_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_249); heff_drop(v_wanted_248); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2410) == NTAG(TAG_True)));
  heff_drop(v_x1_2410);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam1(V self, V *args) {
  V v_v_2416 = args[0];
  V v_wanted_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2416; V a_1 = v_wanted_2415; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2416); heff_drop(v_wanted_2415); r_; });
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam2(V self, V *args) {
  V v_v_2423 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2423; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2423); heff_drop(v_wb_246); r_; });
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(V v_ce_240, V v_b_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_b_241)) {
  case TAG_ATail: {
    V v_t_242 = heff_field(v_b_241, 0);
    v_t_244 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_242)));
    break;
  }
  case TAG_ASts: {
    V v_ss_243 = heff_field(v_b_241, 0);
    v_t_244 = (g_heff_2ecompile_2erefcount_2efvSts(heff_dup(v_ss_243)));
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_wanted_245 = (g_prelude_2e_2b_2b(v_t_244, heff_dup(heff_rfield(v_ce_240, 5))));
  V v_xs_248 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam0, 1, 1, (V[]){v_wanted_245}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_249 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_248));
  V v_t_2410 = (g_list_2emap_24s1796125103x644876049(v_t_249));
  V v_t_2413;
  switch (heff_tag_of(v_b_241)) {
  case TAG_ATail: {
    V v_t_2411 = heff_field(v_b_241, 0);
    v_t_2413 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_2411)));
    break;
  }
  case TAG_ASts: {
    V v_ss_2412 = heff_field(v_b_241, 0);
    v_t_2413 = (g_heff_2ecompile_2erefcount_2efvSts(heff_dup(v_ss_2412)));
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_wanted_2414 = (g_prelude_2e_2b_2b(v_t_2413, heff_dup(heff_rfield(v_ce_240, 5))));
  V v_t_2416 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam1, 1, 1, (V[]){v_wanted_2414}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_ce_2417 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2416, heff_dup(heff_rfield(v_ce_240, 5)), v_ce_240));
  V v_t_2420;
  switch (heff_tag_of(v_b_241)) {
  case TAG_ATail: {
    V v_t_2418 = heff_field(v_b_241, 0);
    v_t_2420 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2417, heff_dup(v_t_2418)));
    break;
  }
  case TAG_ASts: {
    V v_ss_2419 = heff_field(v_b_241, 0);
    v_t_2420 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2417, heff_dup(v_ss_2419), NTAG(TAG_Nothing)));
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_2410, v_t_2420);
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_wanted_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_247 = ({ V a_0 = v_v_246; V a_1 = v_wanted_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_246); heff_drop(v_wanted_245); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
  heff_drop(v_x1_247);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam1(V self, V *args) {
  V v_v_2415 = args[0];
  V v_wanted_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2415; V a_1 = v_wanted_2414; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2415); heff_drop(v_wanted_2414); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam4(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam5(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam6(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry, 9, 0};

V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(V v_ce_240, V v_taken_241, V v_lent_242, V v_t_243, V v_vs_244, V v_fb_245, V v_leaves_246, V v_rd_247, V v_x10_248) {
top: ;
  V v_plain_249 = heff_take_field(v_rd_247, 0);
  V v_flats_2410 = heff_take_field(v_rd_247, 1);
  V v_sure_2411 = heff_take_field(v_rd_247, 5);
  V v_flat_2412 = heff_take_field(v_rd_247, 4);
  V v_names_2413 = heff_take_field(v_rd_247, 2);
  V v_counted_2414 = heff_get_n(v_rd_247, 3, 6);
  switch (heff_tag_of(v_x10_248)) {
  case TAG_MkPair: {
    V v_ru_2415 = heff_field(v_x10_248, 0);
    V v_b2_2416 = heff_field(v_x10_248, 1);
    V v_ru_24x10_248_24MkPair = heff_take_reuse_n(v_x10_248, 3ULL, 2);
    V v_t_2418;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2418 = NTAG(TAG_True);
    } else {
      switch (heff_tag_of(v_taken_241)) {
      case TAG_Nothing: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        v_t_2418 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_taken_241);
      }
    }
    V v_ys_2419 = v_names_2413;
    V v_t_2424;
    switch (heff_tag_of(v_ys_2419)) {
    case TAG_Nil: {
      v_t_2424 = heff_dup(v_fb_245);
      break;
    }
    case TAG_Cons: {
      v_t_2424 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam0, 1, 1, (V[]){v_ys_2419}), heff_dup(v_fb_245)));
      break;
    }
    default: heff_nomatch(v_ys_2419);
    }
    V v_t_2425 = ({ V a_0 = v_flat_2412; V a_1 = v_sure_2411; V a_2 = v_ru_2415; V a_3 = v_taken_241; V a_4 = v_vs_244; V a_5 = v_t_2424; V r_ = (g_heff_2ecompile_2erefcount_2etakeOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_flat_2412); heff_drop(v_t_2424); r_; });
    V v_t_2427;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2427 = heff_dup(v_counted_2414);
    } else {
      v_t_2427 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam1, 1, 1, (V[]){heff_dup(v_fb_245)}), heff_dup(v_vs_244)));
    }
    V v_owned_2428 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), v_t_2427));
    V v_wanted_2429 = (g_prelude_2e_2b_2b(heff_dup(v_fb_245), heff_dup(heff_rfield(v_ce_240, 5))));
    V v_t_2432 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam2, 1, 1, (V[]){v_wanted_2429}), v_owned_2428));
    V v_xs_2437 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam3, 1, 1, (V[]){heff_dup(v_taken_241)}), v_t_2432));
    V v_t_2438 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2437));
    V v_t_2439 = (g_list_2emap_24s1796125103x644876049(v_t_2438));
    V v_t_2441;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2441 = heff_dup(v_counted_2414);
    } else {
      v_t_2441 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam4, 1, 1, (V[]){heff_dup(v_fb_245)}), heff_dup(v_vs_244)));
    }
    V v_t_2443;
    switch (heff_tag_of(v_ru_2415)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x10_248_24MkPair, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2442 = heff_dup(heff_field(v_ru_2415, 0));
      v_t_2443 = heff_tag_at_n(v_ru_24x10_248_24MkPair, TAG_Cons, 2, (V[]){v_x_2442, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_2415);
    }
    V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2441, v_t_2443));
    V v_owned_2445 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), v_t_2444));
    V v_t_2447;
    switch (heff_tag_of(v_ru_2415)) {
    case TAG_Nothing: {
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2446 = heff_dup(heff_field(v_ru_2415, 0));
      v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2446, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_2415);
    }
    V v_wanted_2448 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_240, 5)), v_fb_245, v_t_2447));
    V v_t_2450 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam5, 1, 1, (V[]){v_wanted_2448}), v_owned_2445));
    V v_t_2457;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      V v_ys_2451 = v_counted_2414;
      V v_t_2456;
      switch (heff_tag_of(v_ys_2451)) {
      case TAG_Nil: {
        v_t_2456 = heff_dup(v_vs_244);
        break;
      }
      case TAG_Cons: {
        v_t_2456 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam6, 1, 1, (V[]){v_ys_2451}), heff_dup(v_vs_244)));
        break;
      }
      default: heff_nomatch(v_ys_2451);
      }
      v_t_2457 = (g_prelude_2e_2b_2b(v_t_2456, heff_dup(heff_rfield(v_ce_240, 6))));
    } else {
      heff_drop(v_counted_2414);
      v_t_2457 = heff_dup(heff_rfield(v_ce_240, 6));
    }
    V v_n_2458 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_244; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_vs_244); r_; });
    V v_t_2460;
    switch (heff_tag_of(v_ru_2415)) {
    case TAG_Nothing: {
      heff_drop(v_n_2458);
      v_t_2460 = heff_dup(v_ce_240);
      break;
    }
    case TAG_Just: {
      V v_ru_2459 = heff_field(v_ru_2415, 0);
      V v_ru_24ru_2415_24Just = heff_take_reuse_n(v_ru_2415, 1ULL, 1);
      v_t_2460 = (g_heff_2ecompile_2erefcount_2ewithKnown(v_ru_2459, heff_tag_at_n(v_ru_24ru_2415_24Just, TAG_KnownCell, 1, (V[]){v_n_2458}), heff_dup(v_ce_240)));
      break;
    }
    default: heff_nomatch(v_ru_2415);
    }
    V v_t_2461 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2457, v_t_2460));
    V v_ce_2462 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2450, heff_get_n(v_ce_240, 5, 17), v_t_2461));
    V v_t_2465;
    switch (heff_tag_of(v_b2_2416)) {
    case TAG_ATail: {
      V v_t_2463 = heff_field(v_b2_2416, 0);
      heff_take_n(v_b2_2416, 1ULL, 1);
      v_t_2465 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2462, v_t_2463));
      break;
    }
    case TAG_ASts: {
      V v_ss_2464 = heff_field(v_b2_2416, 0);
      heff_take_n(v_b2_2416, 1ULL, 1);
      v_t_2465 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2462, v_ss_2464, NTAG(TAG_Nothing)));
      break;
    }
    default: heff_nomatch(v_b2_2416);
    }
    V v_t_2466 = (g_prelude_2e_2b_2b(v_t_2439, v_t_2465));
    return heff_tag_n(TAG_MkCArm, 8, (V[]){v_t_243, v_plain_249, v_flats_2410, v_sure_2411, v_t_2418, v_t_2425, v_t_2466, v_leaves_246});
  }
  default: return heff_nomatch(v_x10_248);
  }
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(a[0], a1, a2, a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam0(V self, V *args) {
  V v_x_2422 = args[0];
  V v_ys_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2423 = ({ V a_0 = v_x_2422; V a_1 = v_ys_2419; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2422); heff_drop_tag(v_ys_2419, 2); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2423) == NTAG(TAG_True)));
  heff_drop(v_x1_2423);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam1(V self, V *args) {
  V v_v_2426 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2426; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2426); heff_drop(v_fb_245); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam2(V self, V *args) {
  V v_v_2430 = args[0];
  V v_wanted_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2431 = ({ V a_0 = v_v_2430; V a_1 = v_wanted_2429; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2430); heff_drop(v_wanted_2429); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2431) == NTAG(TAG_True)));
  heff_drop(v_x1_2431);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam3(V self, V *args) {
  V v_v_2433 = args[0];
  V v_taken_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435;
  switch (heff_tag_of(v_taken_241)) {
  case TAG_Nothing: {
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2434 = heff_field(v_taken_241, 0);
    heff_take_n(v_taken_241, 1ULL, 1);
    v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2434, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_taken_241);
  }
  V v_x1_2436 = ({ V a_0 = v_v_2433; V a_1 = v_t_2435; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2433); heff_drop(v_t_2435); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2436) == NTAG(TAG_True)));
  heff_drop(v_x1_2436);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam4(V self, V *args) {
  V v_v_2440 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2440; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2440); heff_drop(v_fb_245); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam5(V self, V *args) {
  V v_v_2449 = args[0];
  V v_wanted_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2449; V a_1 = v_wanted_2448; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2449); heff_drop(v_wanted_2448); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam6(V self, V *args) {
  V v_x_2454 = args[0];
  V v_ys_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2455 = ({ V a_0 = v_x_2454; V a_1 = v_ys_2451; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2454); heff_drop_tag(v_ys_2451, 2); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2455) == NTAG(TAG_True)));
  heff_drop(v_x1_2455);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str2, 0, "");
Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V v_ce_240, V v_x3_241) {
top: ;
  return (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(NTAG(TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565), ((V)&g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str0), ((V)&g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str1), ((V)&g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str2), v_ce_240, v_x3_241));
}
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3(V v_tok_240, V v_ce_241, V v_p_242, V v_args_243, V v_yes_244, V v_no_245, V v_fa_246, V v_wb_247) {
top: ;
  V v_wanted_248 = (g_prelude_2e_2b_2b(heff_dup(v_fa_246), heff_dup(v_wb_247)));
  V v_xs_2411 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_lam0, 1, 1, (V[]){v_wanted_248}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_t_2412 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_241), v_xs_2411));
  V v_t_2413 = (g_list_2emap_24s1796125103x644876049(v_t_2412));
  V v_wanted_2414 = (g_prelude_2e_2b_2b(v_fa_246, heff_dup(v_wb_247)));
  V v_t_2416 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_lam1, 1, 1, (V[]){v_wanted_2414}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_ce_2417 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2416, heff_dup(v_wb_247), heff_dup(v_ce_241)));
  HeffT2 v_t_2418 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_242));
  V v_t_2424;
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_sh_2421 = v_field_2420;
      V v_t_2422 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_2417, heff_dup(v_wb_247), heff_get_n(v_sh_2421, 0, 2), v_args_243));
      v_t_2424 = heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_242, v_t_2422});
    } else {
      heff_drop(v_field_2420);
      V v_t_2423 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_2417, heff_dup(v_wb_247), v_args_243));
      v_t_2424 = heff_tag_n(TAG_CondRel, 2, (V[]){v_p_242, v_t_2423});
    }
  }
  V v_t_2426 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_lam2, 1, 1, (V[]){heff_dup(v_wb_247)}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_t_2427 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2426, heff_dup(heff_rfield(v_ce_241, 5)), heff_dup(v_ce_241)));
  V v_t_2428 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2427, v_yes_244));
  V v_t_2430 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_lam3, 1, 1, (V[]){v_wb_247}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_t_2431 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2430, heff_dup(heff_rfield(v_ce_241, 5)), v_ce_241));
  V v_t_2432 = (g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(v_t_2431, v_no_245));
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_CIf, 3, (V[]){v_t_2424, v_t_2428, v_t_2432}), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_t_2413, v_t_2433));
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a5 = a[5]; V r = g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3(a[0], a[1], a[2], a[3], a4, a5, a[6], a[7]); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_lam0(V self, V *args) {
  V v_v_249 = args[0];
  V v_wanted_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2410 = ({ V a_0 = v_v_249; V a_1 = v_wanted_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_249); heff_drop(v_wanted_248); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2410) == NTAG(TAG_True)));
  heff_drop(v_x1_2410);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_lam1(V self, V *args) {
  V v_v_2415 = args[0];
  V v_wanted_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2415; V a_1 = v_wanted_2414; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2415); heff_drop(v_wanted_2414); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_lam2(V self, V *args) {
  V v_v_2425 = args[0];
  V v_wb_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2425; V a_1 = v_wb_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2425); heff_drop(v_wb_247); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_lam3(V self, V *args) {
  V v_v_2429 = args[0];
  V v_wb_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2429; V a_1 = v_wb_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2429); heff_drop(v_wb_247); r_; });
}
Clo g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2epeekArgs_24tok2(V v_tok_240, V v_ce_241, V v_x_242, V v_argv_243, V v_rest_244) {
top: ;
  V v_borrowed_245 = heff_take_field(v_ce_241, 6);
  V v_reprs_246 = heff_get_n(v_ce_241, 10, 17);
  switch (heff_tag_of(v_argv_243)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_rest_244);
    heff_drop(v_borrowed_245);
    heff_drop(v_reprs_246);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_argv1_247 = heff_field(v_argv_243, 0);
    V v_argv2_248 = heff_field(v_argv_243, 1);
    heff_take_n(v_argv_243, 3ULL, 2);
    switch (heff_tag_of(v_argv1_247)) {
    case TAG_SVar: {
      V v_a_249 = heff_field(v_argv1_247, 0);
      V v_ru_24argv1_247_24SVar = heff_take_reuse_n(v_argv1_247, 1ULL, 1);
      switch (heff_tag_of(v_argv2_248)) {
      case TAG_Nil: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_rest_244);
        heff_drop(v_borrowed_245);
        heff_drop(v_reprs_246);
        heff_drop(v_a_249);
        heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_i_2410 = heff_field(v_argv2_248, 0);
        V v_argv22_2411 = heff_field(v_argv2_248, 1);
        heff_take_n(v_argv2_248, 3ULL, 2);
        switch (heff_tag_of(v_argv22_2411)) {
        case TAG_Nil: {
          V v_t_2412 = ({ V a_0 = v_a_249; V a_1 = v_borrowed_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_borrowed_245); r_; });
          if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
            heff_drop(v_t_2412);
            HeffT2 v_t_2413 = ({ V a_0 = v_reprs_246; V a_1 = v_x_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_reprs_246); r_; });
            {
              V v_field_2415 = v_t_2413.f[1];
              int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
              if ((v_tag_2414 == ((int64_t)0ULL))) {
                V v_x_2416 = v_field_2415;
                switch (heff_tag_of(v_x_2416)) {
                case TAG_RepV: {
                  V v_t_2417 = (g_heff_2ecompile_2erefcount_2eintW(v_x_242, v_rest_244));
                  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
                    heff_drop(v_t_2417);
                    return heff_tag_at_n(v_ru_24argv1_247_24SVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_a_249, v_i_2410})});
                  } else {
                    heff_drop_cell(v_tok_240, 2);
                    heff_drop(v_a_249);
                    heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
                    heff_drop(v_i_2410);
                    heff_drop(v_t_2417);
                    return NTAG(TAG_Nothing);
                  }
                }
                case TAG_RepFix: {
                  heff_take_n(v_x_2416, 0ULL, 1);
                  heff_drop_cell(v_tok_240, 2);
                  heff_drop(v_rest_244);
                  heff_drop(v_a_249);
                  heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
                  heff_drop(v_i_2410);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepF64: {
                  heff_drop_cell(v_tok_240, 2);
                  heff_drop(v_rest_244);
                  heff_drop(v_a_249);
                  heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
                  heff_drop(v_i_2410);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepInt: {
                  heff_drop_cell(v_tok_240, 2);
                  heff_drop(v_rest_244);
                  heff_drop(v_a_249);
                  heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
                  heff_drop(v_i_2410);
                  return NTAG(TAG_Nothing);
                }
                default: return heff_nomatch(v_x_2416);
                }
              } else {
                heff_drop(v_field_2415);
                V v_t_2419 = (g_heff_2ecompile_2erefcount_2eintW(v_x_242, v_rest_244));
                if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
                  heff_drop(v_t_2419);
                  return heff_tag_at_n(v_ru_24argv1_247_24SVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_a_249, v_i_2410})});
                } else {
                  heff_drop_cell(v_tok_240, 2);
                  heff_drop(v_a_249);
                  heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
                  heff_drop(v_i_2410);
                  heff_drop(v_t_2419);
                  return NTAG(TAG_Nothing);
                }
              }
            }
          } else {
            heff_drop_cell(v_tok_240, 2);
            heff_drop(v_rest_244);
            heff_drop(v_reprs_246);
            heff_drop(v_a_249);
            heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
            heff_drop(v_i_2410);
            heff_drop(v_t_2412);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_argv22_2411, 0ULL, 2);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_rest_244);
          heff_drop(v_borrowed_245);
          heff_drop(v_reprs_246);
          heff_drop(v_a_249);
          heff_drop_cell(v_ru_24argv1_247_24SVar, 1);
          heff_drop(v_i_2410);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_argv22_2411);
        }
      }
      default: return heff_nomatch(v_argv2_248);
      }
    }
    case TAG_SGlobal: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SInt: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat: {
      heff_take_na(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SStr: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SBytes: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFixed: {
      heff_take_n(v_argv1_247, 0ULL, 2);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat32: {
      heff_take_na(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFn: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_argv1_247, 0ULL, 2);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_argv1_247, 0ULL, 3);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_argv1_247, 0ULL, 2);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_argv1_247, 0ULL, 4);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_argv1_247, 0ULL, 2);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_argv1_247);
    }
  }
  default: return heff_nomatch(v_argv_243);
  }
}
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2epeekArgs_24tok2(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3(V v_tok_240, V v_ce_241, V v_live_242, V v_t_243, V v_argv_244, V v_ts_245) {
top: ;
  V v_n_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_244));
  V v_t_247 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_246, MK_INT(1LL))));
  V v_t_2410 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3_lam0, 1, 1, (V[]){heff_dup(v_ts_245)}), v_t_247));
  V v_t_2411 = (g_heff_2ecompile_2erefcount_2eslotBits(v_t_2410));
  V v_n_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_244));
  V v_t_2413 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2412, MK_INT(1LL))));
  V v_rps_2416 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3_lam1, 1, 1, (V[]){heff_dup(v_ts_245)}), v_t_2413));
  V v_t_2417 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_241, v_live_242, heff_dup(v_rps_2416), v_argv_244));
  V v_t_2418 = (g_list_2ezipWith_24s870182194x1066240094(v_rps_2416, v_t_2417));
  return heff_tag_at_n(v_tok_240, TAG_RTag, 3, (V[]){v_t_243, v_t_2411, v_t_2418});
}
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3_lam0(V self, V *args) {
  V v_i_248 = args[0];
  V v_ts_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = ({ V a_0 = heff_dup(v_i_248); V a_1 = v_ts_245; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_245); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_248, v_t_249));
}
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_24tok3_lam1(V self, V *args) {
  V v_i_2414 = args[0];
  V v_ts_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = ({ V a_0 = heff_dup(v_i_2414); V a_1 = v_ts_245; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_245); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2414, v_t_2415));
}