// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565 57410
#define TAG_Given 9359
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_KnownCell 38933
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define LBL_after 294093302
#define LBL_at 9882
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_counted 1189688364
#define LBL_flat 9641024
#define LBL_flats 298871860
#define LBL_funs 9650075
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_names 305943394
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_plain 308106724
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tags 10047712
#define LBL_takes 311482598
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_sureRecs, LBL_ret};
V g_heff_2ecompile_2erefcount_2eagrees(V, V, V);
V g_heff_2ecompile_2erefcount_2eagrees_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eagrees_clo;
V g_heff_2ecompile_2erefcount_2eapplyLast(V, V, V);
V g_heff_2ecompile_2erefcount_2eapplyLast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eapplyLast_clo;
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_clo;
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_clo;
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_clo;
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_clo;
V g_heff_2ecompile_2erefcount_2eboolDone(V, V);
V g_heff_2ecompile_2erefcount_2eboolDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eboolDone_clo;
V g_heff_2ecompile_2erefcount_2ebuiltOf(V);
V g_heff_2ecompile_2erefcount_2ebuiltOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebuiltOf_clo;
V g_heff_2ecompile_2erefcount_2ecallAs(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecallAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecallAs_clo;
V g_heff_2ecompile_2erefcount_2ecoerce(V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_clo;
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_clo;
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(V, V, V);
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_clo;
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(V, V);
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461_clo;
V g_heff_2ecompile_2erefcount_2efieldMask(V, V, V);
V g_heff_2ecompile_2erefcount_2efieldMask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldMask_clo;
V g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
V g_heff_2ecompile_2erefcount_2efvOp(V);
V g_heff_2ecompile_2erefcount_2efvOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvOp_clo;
V g_heff_2ecompile_2erefcount_2efvRest(V, V);
V g_heff_2ecompile_2erefcount_2efvRest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvRest_clo;
V g_heff_2ecompile_2erefcount_2efvSts(V);
V g_heff_2ecompile_2erefcount_2efvSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvSts_clo;
V g_heff_2ecompile_2erefcount_2efvTl(V);
V g_heff_2ecompile_2erefcount_2efvTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_clo;
V g_heff_2ecompile_2erefcount_2efvVal(V);
V g_heff_2ecompile_2erefcount_2efvVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvVal_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2eintW(V, V);
V g_heff_2ecompile_2erefcount_2eintW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eintW_clo;
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(V, V);
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ekeptFrom_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_clo;
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo;
V g_heff_2ecompile_2erefcount_2elentField(V, V, V);
V g_heff_2ecompile_2erefcount_2elentField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentField_clo;
V g_heff_2ecompile_2erefcount_2elentIn(V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentIn_clo;
V g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_clo;
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_clo;
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_clo;
V g_heff_2ecompile_2erefcount_2enthValue(V, V);
V g_heff_2ecompile_2erefcount_2enthValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2enthValue_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2eoperandsOf(V);
V g_heff_2ecompile_2erefcount_2eoperandsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsOf_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs(V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_clo;
V g_heff_2ecompile_2erefcount_2epeekPrim_get(void);
V g_heff_2ecompile_2erefcount_2epow2(V);
V g_heff_2ecompile_2erefcount_2epow2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epow2_clo;
V g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082_clo;
V g_heff_2ecompile_2erefcount_2ereadsWith(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ereadsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereadsWith_clo;
V g_heff_2ecompile_2erefcount_2ereuseArgs(V, V);
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseV_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseV_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2esameAs(V, V, V);
V g_heff_2ecompile_2erefcount_2esameAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esameAs_clo;
V g_heff_2ecompile_2erefcount_2esameS(V, V);
V g_heff_2ecompile_2erefcount_2esameS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esameS_clo;
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etagGiven_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etakeIn_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeOf(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeOf_clo;
V g_heff_2ecompile_2erefcount_2etakesAt(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakesAt_clo;
V g_heff_2ecompile_2erefcount_2ethreadSt(V, V, V);
V g_heff_2ecompile_2erefcount_2ethreadSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ethreadSt_clo;
V g_heff_2ecompile_2erefcount_2eunboxOf(V, V);
V g_heff_2ecompile_2erefcount_2eunboxOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxOf_clo;
V g_heff_2ecompile_2erefcount_2eunboxParam(V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxParam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxParam_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(V, V, V);
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithFrame(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithFrame_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithFrame_clo;
V g_heff_2ecompile_2erefcount_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2ereprsEq(V, V);
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsEq_clo;
V g_list_2eall_24s1793250635x935291087(V);
V g_list_2eall_24s1793250635x935291087_entry(V self, V *a);
extern Clo g_list_2eall_24s1793250635x935291087_clo;
V g_list_2eany_24s1681212806x1534785672(V, V, V);
V g_list_2eany_24s1681212806x1534785672_entry(V self, V *a);
extern Clo g_list_2eany_24s1681212806x1534785672_clo;
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s477184376x1963488659(V, V);
V g_list_2efoldl_24s477184376x1963488659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s477184376x1963488659_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s826961155x1314392429(V, V);
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s826961155x1314392429_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f252863627x859179744(V, V, V, V);
V g_list_2emap_24f252863627x859179744_entry(V self, V *a);
extern Clo g_list_2emap_24f252863627x859179744_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s976303750x321235480(V);
V g_list_2emap_24s976303750x321235480_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1963842891x1660122411_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
Clo g_heff_2ecompile_2erefcount_2ewithPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithPath_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ewithPath(V v_owned_240, V v_after_241, V v_ce_242) {
top: ;
  return ({ V rv_4 = v_owned_240; V rv_5 = v_after_241; V rr_ = heff_rec_reuse_nf(v_ce_242, 65487ULL, 16, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__ret, 4294963455u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithPath(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithTakes_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ewithTakes(V v_ts_240, V v_ce_241) {
top: ;
  return ({ V rv_9 = v_ts_240; V rr_ = heff_rec_reuse_nf(v_ce_241, 65023ULL, 16, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__ret, 4294180863u, 0u); heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithTakes(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efreeGo_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2efreeGo(V v_bs_240, V v_seen_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_bs_240, v_v_244));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_v_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_x_2410 = v_field_248;
        heff_drop(v_x_2410);
        V t_0 = v_bs_240;
        V t_1 = v_seen_241;
        V t_2 = v_vs_245;
        V t_3 = v_acc_243;
        v_bs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      } else {
        heff_drop(v_field_248);
        HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_seen_241, v_v_244));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            heff_drop(v_v_244);
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            V v_x_2415 = v_field_2413;
            heff_drop(v_x_2415);
            V t_0 = v_bs_240;
            V t_1 = v_seen_241;
            V t_2 = v_vs_245;
            V t_3 = v_acc_243;
            v_bs_240 = t_0;
            v_seen_241 = t_1;
            v_x3_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          } else {
            heff_drop(v_field_2413);
            V v_t_2416 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_seen_241, heff_dup(v_v_244), NTAG(TAG_MkUnit)));
            V t_0 = v_bs_240;
            V t_1 = v_t_2416;
            V t_2 = v_vs_245;
            V t_3 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_v_244, v_acc_243});
            v_bs_240 = t_0;
            v_seen_241 = t_1;
            v_x3_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2efreeGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erefcount_2efvVal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvVal_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2efvVal(V v_v_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_240}), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_bs_245 = v_field_243;
    V v_ms_246 = v_field_244;
    V v_bs_247 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_245));
    V v_ms_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_246));
    V v_t_249 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_247; V r_ = (g_list_2efoldl_24s477184376x1963488659(a_0, a_1)); heff_drop(v_bs_247); r_; });
    return ({ V a_0 = v_t_249; V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_ms_248; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  }
}
V g_heff_2ecompile_2erefcount_2efvVal_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvVal(a[0]);
}
Clo g_heff_2ecompile_2erefcount_2efvOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvOp_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2efvOp(V v_o_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_240}), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_bs_245 = v_field_243;
    V v_ms_246 = v_field_244;
    V v_bs_247 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_245));
    V v_ms_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_246));
    V v_t_249 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_247; V r_ = (g_list_2efoldl_24s477184376x1963488659(a_0, a_1)); heff_drop(v_bs_247); r_; });
    return ({ V a_0 = v_t_249; V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_ms_248; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  }
}
V g_heff_2ecompile_2erefcount_2efvOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvOp(a[0]);
}
Clo g_heff_2ecompile_2erefcount_2efvRest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvRest_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2efvRest(V v_ss_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return (g_heff_2ecompile_2erefcount_2efvSts(v_ss_240));
  }
  case TAG_Just: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_ITl, 1, (V[]){v_t_242}), NTAG(TAG_Nil)});
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_240}), v_t_243});
    HeffT2 v_t_245 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_244));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_bs_248 = v_field_246;
      V v_ms_249 = v_field_247;
      V v_bs_2410 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_248));
      V v_ms_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_249));
      V v_t_2412 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2410; V r_ = (g_list_2efoldl_24s477184376x1963488659(a_0, a_1)); heff_drop(v_bs_2410); r_; });
      return ({ V a_0 = v_t_2412; V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_ms_2411; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2efvRest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvRest(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2elentIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentIn_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2elentIn(V v_ce_240, V v_bi_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_es_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2erefcount_2eelemI(heff_dup(v_i_242), v_bi_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_x1_2435;
      switch (heff_tag_of(v_e_244)) {
      case TAG_SVar: {
        V v_x_247 = heff_field(v_e_244, 0);
        V v_ru_24e_244_24SVar = heff_take_reuse_n(v_e_244, 1ULL, 1);
        HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(heff_rfield(v_ce_240, 10), v_x_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            heff_drop(v_x_247);
            heff_drop_cell(v_ru_24e_244_24SVar, 1);
            V v_x_2412 = v_field_2410;
            heff_drop(v_x_2412);
            v_x1_2435 = NTAG(TAG_Nothing);
          } else {
            heff_drop(v_field_2410);
            v_x1_2435 = heff_tag_at_n(v_ru_24e_244_24SVar, TAG_Just, 1, (V[]){v_x_247});
          }
        }
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_e_244, 0ULL, 1);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_e_244, 0ULL, 1);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_e_244, 0ULL, 3);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_e_244, 0ULL, 4);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2435 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_244);
      }
      V v_xs_2436 = (g_heff_2ecompile_2erefcount_2elentIn(v_ce_240, v_bi_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_es_245));
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        return v_xs_2436;
      }
      case TAG_Just: {
        V v_x_2437 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_x_2437, v_xs_2436});
      }
      default: return heff_nomatch(v_x1_2435);
      }
    } else {
      heff_drop(v_e_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_ce_240;
      V t_1 = v_bi_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_es_245;
      v_ce_240 = t_0;
      v_bi_241 = t_1;
      v_i_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erefcount_2elentIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2elentIn(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2eunboxParam_str0, 4, "box$");
Clo g_heff_2ecompile_2erefcount_2eunboxParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eunboxParam_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eunboxParam(V v_ce_240, V v_lent_241, V v_x_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(heff_rfield(v_ce_240, 10), v_x_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_245;
      heff_drop(v_x_247);
      HeffT2 v_t_248 = ({ V b_0 = heff_get_n(v_ce_240, 10, 16); V a_1 = v_x_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2415;
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        V v_rp_2413;
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          v_rp_2413 = v_x_2412;
        } else {
          heff_drop(v_field_2410);
          v_rp_2413 = NTAG(TAG_RepV);
        }
        V v_v_2414 = heff_tag_n(TAG_RLocal, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2eunboxParam_str0), heff_dup(v_x_242))});
        if ((heff_dup(v_lent_241) == NTAG(TAG_True))) {
          v_t_2415 = heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_2413, v_v_2414});
        } else {
          v_t_2415 = heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_2413, v_v_2414});
        }
      }
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, v_t_2415}), NTAG(TAG_Nil)});
    } else {
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_x_242);
      heff_drop(v_field_245);
      return NTAG(TAG_Nil);
    }
  }
}
V g_heff_2ecompile_2erefcount_2eunboxParam_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eunboxParam(a[0], a1, a[2]); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2erefcount_2etakeIn_24cpr(V v_ts_240, V v_live_241, V v_e_242, V v_l_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SVar: {
    V v_x_245 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_t_246 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_245, v_live_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_list_2eany_24s1681212806x1534785672(v_x_245, v_l_243, v_ts_240));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_RTakeField, 2, (V[]){v_x_245, v_i_244})}});
      } else {
        heff_drop(v_i_244);
        heff_drop(v_x_245);
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_i_244);
      heff_drop(v_x_245);
      heff_drop(v_t_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_SGlobal: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SInt: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFloat: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SStr: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SBytes: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFixed: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFloat32: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimFn: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_e_242, 0ULL, 4);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_i_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2esameS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esameS_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2esameS(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_x_244, v_y_246, 0)) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2esameS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2esameS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2erefcount_2ekeptFrom_24cpr(V v_ls_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_l_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_SVar: {
      heff_take_n(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SInt: {
      heff_take_n(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFloat: {
      heff_take_na(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SStr: {
      heff_take_n(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SBytes: {
      heff_take_n(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFixed: {
      heff_take_n(v_x22_243, 0ULL, 2);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFloat32: {
      heff_take_na(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimFn: {
      heff_take_n(v_x22_243, 0ULL, 1);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      heff_take_n(v_x22_243, 0ULL, 2);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_x22_243, 0ULL, 3);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_x22_243, 0ULL, 2);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      V v_e_2421 = heff_field(v_x22_243, 0);
      V v_l2_2422 = heff_field(v_x22_243, 1);
      V v_sh_2423 = heff_field(v_x22_243, 2);
      heff_take_n(v_x22_243, 7ULL, 4);
      if (heff_strEq_c(v_l_242, v_l2_2422)) {
        V v_t_2426 = ({ V a_0 = v_ls_240; V a_1 = v_sh_2423; V r_ = (g_heff_2ecompile_2erefcount_2esameS(a_0, a_1)); heff_drop(v_sh_2423); r_; });
        if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
          heff_drop(v_t_2426);
          switch (heff_tag_of(v_e_2421)) {
          case TAG_SVar: {
            V v_x_2427 = heff_field(v_e_2421, 0);
            heff_take_n(v_e_2421, 1ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2427}});
          }
          case TAG_SGlobal: {
            heff_take_n(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SInt: {
            heff_take_n(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SFloat: {
            heff_take_na(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SStr: {
            heff_take_n(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SBytes: {
            heff_take_n(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SFixed: {
            heff_take_n(v_e_2421, 0ULL, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SFloat32: {
            heff_take_na(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SPrimFn: {
            heff_take_n(v_e_2421, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLam: {
            heff_take_n(v_e_2421, 0ULL, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_STag: {
            heff_take_n(v_e_2421, 0ULL, 3);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SRec: {
            heff_take_n(v_e_2421, 0ULL, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SProj: {
            heff_take_n(v_e_2421, 0ULL, 4);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SPrim: {
            heff_take_n(v_e_2421, 0ULL, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_e_2421)}});
          }
        } else {
          heff_drop(v_e_2421);
          heff_drop(v_t_2426);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_e_2421);
        heff_drop(v_sh_2423);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_SPrim: {
      heff_take_n(v_x22_243, 0ULL, 2);
      heff_drop(v_l_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x22_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2eunboxOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eunboxOf_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eunboxOf(V v_rp_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_RLocal: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RDup: {
    V v_x_243 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24RDup = heff_take_reuse_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, heff_tag_at_n(v_ru_24v_241_24RDup, TAG_RLocal, 1, (V[]){v_x_243})});
  }
  case TAG_RClo: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGet: {
    V v_g_245 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24RGet = heff_take_reuse_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, heff_tag_at_n(v_ru_24v_241_24RGet, TAG_RGetRaw, 1, (V[]){v_g_245})});
  }
  case TAG_RGetRaw: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RInt: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFloat: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RStr: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RBytes: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFixed: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RF32: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RNTag: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RTag: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RTagIn: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RRec: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RRecIn: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RField: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RDupE: {
    V v_e_2435 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, v_e_2435});
  }
  case TAG_RFieldV: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGetN: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFieldU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGetNU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RWord: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RTakeField: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGetLabel: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrimFn: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrim: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RLam: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RCall: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RApply: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RBool: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RAbandon: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RBox: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RUnbox: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPeek: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrimU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrimAt: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFixU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RF32U: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RF64U: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erefcount_2eunboxOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eunboxOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2esameAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esameAs_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2esameAs(V v_ce_240, V v_x2_241, V v_g_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_s_243 = heff_field(v_x2_241, 0);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_ce_240, 11), heff_rfield(v_s_243, 0)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      HeffT2 v_t_247 = ({ V b_0 = heff_get_n(v_ce_240, 11, 16); V a_1 = v_g_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          V v_a_2411 = v_field_246;
          if ((v_tag_248 == ((int64_t)0ULL))) {
            V v_b_2413 = v_field_249;
            V v_t_2414 = (g_heff_2ecompile_2erepr_2ereprsEq(heff_rfield(v_a_2411, 0), heff_rfield(v_b_2413, 0)));
            if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
              heff_drop(v_t_2414);
              return ({ V b_0 = heff_get_n(v_a_2411, 1, 2); V b_1 = heff_get_n(v_b_2413, 1, 2); V r_ = (g_heff_2ecompile_2erepr_2ereprEq(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
            } else {
              heff_drop_rec(v_a_2411, 2);
              heff_drop_rec(v_b_2413, 2);
              heff_drop(v_t_2414);
              return NTAG(TAG_False);
            }
          } else {
            heff_drop(v_field_249);
            heff_drop_rec(v_a_2411, 2);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop(v_field_246);
          V v_ret_24bool = heff_bool(((v_tag_248 == ((int64_t)0ULL)) ? ({ V v_x_2416 = heff_dup(v_field_249); int c_ = 0; heff_drop(v_x_2416); c_; }) : 1));
          heff_drop(v_field_249);
          return v_ret_24bool;
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2esameAs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2esameAs(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erefcount_2eapplyLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eapplyLast_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eapplyLast(V v_ce_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_n_241);
    V v_t_243 = heff_tag_n(TAG_CReturn, 1, (V[]){NTAG(TAG_RAbandon)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2412;
    if (heff_intLt_c_lent(MK_INT(0LL), v_n_241, 1)) {
      if (heff_intLe_c(heff_dup(v_n_241), heff_dup(heff_rfield(v_ce_240, 3)))) {
        heff_drop_rec(v_ce_240, 16);
        heff_drop(v_n_241);
        v_t_2412 = heff_tag_n(TAG_CInPlace, 2, (V[]){v_f_244, v_vs_245});
      } else {
        if (heff_intLt_c(MK_INT(0LL), heff_get_n(v_ce_240, 3, 16))) {
          if (heff_intLe_c(v_n_241, MK_INT(4LL))) {
            v_t_2412 = heff_tag_n(TAG_CRoomed, 2, (V[]){v_f_244, v_vs_245});
          } else {
            v_t_2412 = heff_tag_n(TAG_CTail, 2, (V[]){v_f_244, v_vs_245});
          }
        } else {
          heff_drop(v_n_241);
          v_t_2412 = heff_tag_n(TAG_CTail, 2, (V[]){v_f_244, v_vs_245});
        }
      }
    } else {
      if (heff_intLt_c(MK_INT(0LL), heff_get_n(v_ce_240, 3, 16))) {
        if (heff_intLe_c(v_n_241, MK_INT(4LL))) {
          v_t_2412 = heff_tag_n(TAG_CRoomed, 2, (V[]){v_f_244, v_vs_245});
        } else {
          v_t_2412 = heff_tag_n(TAG_CTail, 2, (V[]){v_f_244, v_vs_245});
        }
      } else {
        heff_drop(v_n_241);
        v_t_2412 = heff_tag_n(TAG_CTail, 2, (V[]){v_f_244, v_vs_245});
      }
    }
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2eapplyLast_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eapplyLast(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2efieldMask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efieldMask_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2efieldMask(V v_used_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x3_242, 0);
    V v_vs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ecompile_2erefcount_2eelemS(v_v_243, v_used_240));
    V v_t_246;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      v_t_246 = (g_heff_2ecompile_2erefcount_2epow2(heff_dup(v_i_241)));
    } else {
      heff_drop(v_t_245);
      v_t_246 = MK_INT(0LL);
    }
    V v_t_247 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_vs_244));
    return heff_intAdd(v_t_246, v_t_247);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2efieldMask_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2efieldMask(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2ereuseOp_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(V v_ru_240, V v_n_241, V v_o_242) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_v_243 = heff_field(v_o_242, 0);
    V v_ru_24o_242_24OSimple = heff_take_reuse_n(v_o_242, 1ULL, 1);
    HeffT2 v_t_244 = (g_heff_2ecompile_2erefcount_2ereuseV_24cpr(v_ru_240, v_n_241, v_v_243));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_b_247 = v_field_245;
      V v_v2_248 = v_field_246;
      return ((HeffT2){{v_b_247, heff_tag_at_n(v_ru_24o_242_24OSimple, TAG_OSimple, 1, (V[]){v_v2_248})}});
    }
  }
  case TAG_OCall: {
    V v_g_249 = heff_field(v_o_242, 0);
    V v_argv_2410 = heff_field(v_o_242, 1);
    V v_ru_24o_242_24OCall = heff_take_reuse_n(v_o_242, 3ULL, 2);
    V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseOp_24cpr_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_argv_2410; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_argv_2410); r_; });
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkPair: {
      V v_b_2413 = heff_field(v_t_2412, 0);
      V v_as2_2414 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 3ULL, 2);
      return ((HeffT2){{v_b_2413, heff_tag_at_n(v_ru_24o_242_24OCall, TAG_OCall, 2, (V[]){v_g_249, v_as2_2414})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2412)}});
    }
  }
  case TAG_OApply: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), v_o_242}});
  }
  case TAG_OPrim: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), v_o_242}});
  }
  case TAG_OAbandon: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), v_o_242}});
  }
  case TAG_OBool: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), v_o_242}});
  }
  default: return ((HeffT2){{heff_nomatch(v_o_242)}});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseOp_24cpr_lam0(V self, V *args) {
  V v_v_2411 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_2411));
}
V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(V v_ru_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return ((HeffT2){{NTAG(TAG_False), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_SLet: {
      V v_x_245 = heff_field(v_x41_243, 0);
      V v_o_246 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 3ULL, 2);
      HeffT2 v_t_247 = (g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_o_246));
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        V v_b_2410 = v_field_248;
        V v_o2_2411 = v_field_249;
        if ((heff_dup(v_b_2410) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_b_2410);
          V v_t_2412 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SLet, 2, (V[]){v_x_245, v_o2_2411}), v_rest_244});
          return ((HeffT2){{NTAG(TAG_True), v_t_2412}});
        } else {
          heff_drop(v_b_2410);
          HeffT2 v_t_2413 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
          {
            V v_field_2414 = v_t_2413.f[0];
            V v_field_2415 = v_t_2413.f[1];
            V v_b_2416 = v_field_2414;
            V v_ss_2417 = v_field_2415;
            V v_t_2418 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SLet, 2, (V[]){v_x_245, v_o2_2411}), v_ss_2417});
            return ((HeffT2){{v_b_2416, v_t_2418}});
          }
        }
      }
    }
    case TAG_SDecl: {
      HeffT2 v_t_2420 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
      {
        V v_field_2421 = v_t_2420.f[0];
        V v_field_2422 = v_t_2420.f[1];
        V v_b_2423 = v_field_2421;
        V v_ss_2424 = v_field_2422;
        return ((HeffT2){{v_b_2423, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_x41_243, v_ss_2424})}});
      }
    }
    case TAG_SSet: {
      V v_x_2425 = heff_field(v_x41_243, 0);
      V v_o_2426 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 3ULL, 2);
      HeffT2 v_t_2427 = (g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_o_2426));
      {
        V v_field_2428 = v_t_2427.f[0];
        V v_field_2429 = v_t_2427.f[1];
        V v_b_2430 = v_field_2428;
        V v_o2_2431 = v_field_2429;
        if ((heff_dup(v_b_2430) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_b_2430);
          V v_t_2432 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SSet, 2, (V[]){v_x_2425, v_o2_2431}), v_rest_244});
          return ((HeffT2){{NTAG(TAG_True), v_t_2432}});
        } else {
          heff_drop(v_b_2430);
          HeffT2 v_t_2433 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
          {
            V v_field_2434 = v_t_2433.f[0];
            V v_field_2435 = v_t_2433.f[1];
            V v_b_2436 = v_field_2434;
            V v_ss_2437 = v_field_2435;
            V v_t_2438 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SSet, 2, (V[]){v_x_2425, v_o2_2431}), v_ss_2437});
            return ((HeffT2){{v_b_2436, v_t_2438}});
          }
        }
      }
    }
    case TAG_SIf: {
      V v_c_2439 = heff_field(v_x41_243, 0);
      V v_ts_2440 = heff_field(v_x41_243, 1);
      V v_fs_2441 = heff_field(v_x41_243, 2);
      heff_take_n(v_x41_243, 7ULL, 3);
      HeffT2 v_t_2442 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_ts_2440));
      {
        V v_field_2443 = v_t_2442.f[0];
        V v_field_2444 = v_t_2442.f[1];
        V v_bt_2445 = v_field_2443;
        V v_ts2_2446 = v_field_2444;
        HeffT2 v_t_2447 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_fs_2441));
        {
          V v_field_2448 = v_t_2447.f[0];
          V v_field_2449 = v_t_2447.f[1];
          V v_bf_2450 = v_field_2448;
          V v_fs2_2451 = v_field_2449;
          if ((heff_dup(v_bt_2445) == NTAG(TAG_True))) {
            heff_drop(v_ru_240);
            heff_drop(v_n_241);
            heff_drop(v_bt_2445);
            heff_drop(v_bf_2450);
            V v_t_2452 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SIf, 3, (V[]){v_c_2439, v_ts2_2446, v_fs2_2451}), v_rest_244});
            return ((HeffT2){{NTAG(TAG_True), v_t_2452}});
          } else {
            heff_drop(v_bt_2445);
            if ((heff_dup(v_bf_2450) == NTAG(TAG_True))) {
              heff_drop(v_ru_240);
              heff_drop(v_n_241);
              heff_drop(v_bf_2450);
              V v_t_2453 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SIf, 3, (V[]){v_c_2439, v_ts2_2446, v_fs2_2451}), v_rest_244});
              return ((HeffT2){{NTAG(TAG_True), v_t_2453}});
            } else {
              heff_drop(v_bf_2450);
              HeffT2 v_t_2454 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
              {
                V v_field_2455 = v_t_2454.f[0];
                V v_field_2456 = v_t_2454.f[1];
                V v_b_2457 = v_field_2455;
                V v_ss_2458 = v_field_2456;
                V v_t_2459 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SIf, 3, (V[]){v_c_2439, v_ts2_2446, v_fs2_2451}), v_ss_2458});
                return ((HeffT2){{v_b_2457, v_t_2459}});
              }
            }
          }
        }
      }
    }
    case TAG_SCase: {
      V v_v_2460 = heff_field(v_x41_243, 0);
      V v_arms_2461 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 3ULL, 2);
      V v_ps_2471 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr_lam0, 1, 2, (V[]){heff_dup(v_ru_240), heff_dup(v_n_241)}), v_arms_2461));
      V v_b_2472 = (g_list_2eany_24s910662703x1730636603(v_ps_2471));
      V v_as2_2473 = (g_list_2emap_24s1173914895x100384474(v_ps_2471));
      if ((heff_dup(v_b_2472) == NTAG(TAG_True))) {
        heff_drop(v_ru_240);
        heff_drop(v_n_241);
        heff_drop(v_b_2472);
        V v_t_2474 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SCase, 2, (V[]){v_v_2460, v_as2_2473}), v_rest_244});
        return ((HeffT2){{NTAG(TAG_True), v_t_2474}});
      } else {
        heff_drop(v_b_2472);
        HeffT2 v_t_2475 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_rest_244));
        {
          V v_field_2476 = v_t_2475.f[0];
          V v_field_2477 = v_t_2475.f[1];
          V v_b_2478 = v_field_2476;
          V v_ss_2479 = v_field_2477;
          V v_t_2480 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SCase, 2, (V[]){v_v_2460, v_as2_2473}), v_ss_2479});
          return ((HeffT2){{v_b_2478, v_t_2480}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x41_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr_lam0(V self, V *args) {
  V v_x4_2462 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x4_2462)) {
  case TAG_MkArm: {
    V v_t_2463 = heff_field(v_x4_2462, 0);
    V v_vs_2464 = heff_field(v_x4_2462, 1);
    V v_ss_2465 = heff_field(v_x4_2462, 2);
    V v_ru_24x4_2462_24MkArm = heff_take_reuse_n(v_x4_2462, 7ULL, 3);
    HeffT2 v_t_2466 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, v_ss_2465));
    {
      V v_field_2467 = v_t_2466.f[0];
      V v_field_2468 = v_t_2466.f[1];
      V v_b_2469 = v_field_2467;
      V v_x_2470 = v_field_2468;
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2469, heff_tag_at_n(v_ru_24x4_2462_24MkArm, TAG_MkArm, 3, (V[]){v_t_2463, v_vs_2464, v_x_2470})});
    }
  }
  default: return heff_nomatch(v_x4_2462);
  }
}
V g_heff_2ecompile_2erefcount_2eboolDone_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eboolDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eboolDone_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eboolDone(V v_ce_240, V v_o_241) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OSimple: {
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_Nil);
  }
  case TAG_OCall: {
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_Nil);
  }
  case TAG_OApply: {
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_Nil);
  }
  case TAG_OPrim: {
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_Nil);
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_ce_240, 16);
    return NTAG(TAG_Nil);
  }
  case TAG_OBool: {
    V v_xs_2412 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2eboolDone_lam0, 1, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(heff_rfield(v_ce_240, 4))));
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2edropsOf(v_ce_240, v_xs_2412));
    return (g_list_2emap_24s1796125103x644876049(v_t_2413));
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2erefcount_2eboolDone_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eboolDone(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2eboolDone_lam0(V self, V *args) {
  V v_v_2410 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = ({ V a_0 = v_v_2410; V b_1 = heff_get_n(v_ce_240, 5, 16); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(v_v_2410); heff_drop(b_1); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
  heff_drop(v_x1_2411);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2erefcount_2epeekArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2epeekArgs_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2epeekArgs(V v_ce_240, V v_x_241, V v_argv_242, V v_rest_243) {
top: ;
  switch (heff_tag_of(v_argv_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_rest_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_argv1_244 = heff_field(v_argv_242, 0);
    V v_argv2_245 = heff_field(v_argv_242, 1);
    V v_ru_24argv_242_24Cons = heff_take_reuse_n(v_argv_242, 3ULL, 2);
    switch (heff_tag_of(v_argv1_244)) {
    case TAG_SVar: {
      V v_a_246 = heff_field(v_argv1_244, 0);
      V v_ru_24argv1_244_24SVar = heff_take_reuse_n(v_argv1_244, 1ULL, 1);
      switch (heff_tag_of(v_argv2_245)) {
      case TAG_Nil: {
        heff_drop_rec(v_ce_240, 16);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24argv_242_24Cons, 2);
        heff_drop(v_a_246);
        heff_drop_cell(v_ru_24argv1_244_24SVar, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_i_247 = heff_field(v_argv2_245, 0);
        V v_argv22_248 = heff_field(v_argv2_245, 1);
        heff_take_n(v_argv2_245, 3ULL, 2);
        switch (heff_tag_of(v_argv22_248)) {
        case TAG_Nil: {
          V v_t_249 = (g_heff_2ecompile_2erefcount_2eelemS(v_a_246, heff_rfield(v_ce_240, 6)));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            HeffT2 v_t_2410 = ({ V b_0 = heff_get_n(v_ce_240, 10, 16); V a_1 = v_x_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            {
              V v_field_2412 = v_t_2410.f[1];
              int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
              if ((v_tag_2411 == ((int64_t)0ULL))) {
                V v_x_2414 = v_field_2412;
                switch (heff_tag_of(v_x_2414)) {
                case TAG_RepV: {
                  V v_t_2415 = (g_heff_2ecompile_2erefcount_2eintW(v_x_241, v_rest_243));
                  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
                    heff_drop(v_t_2415);
                    return heff_tag_at_n(v_ru_24argv1_244_24SVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24argv_242_24Cons, TAG_MkPair, 2, (V[]){v_a_246, v_i_247})});
                  } else {
                    heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                    heff_drop(v_a_246);
                    heff_drop_cell(v_ru_24argv1_244_24SVar, 1);
                    heff_drop(v_i_247);
                    heff_drop(v_t_2415);
                    return NTAG(TAG_Nothing);
                  }
                }
                case TAG_RepFix: {
                  heff_take_n(v_x_2414, 0ULL, 1);
                  heff_drop(v_rest_243);
                  heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                  heff_drop(v_a_246);
                  heff_drop_cell(v_ru_24argv1_244_24SVar, 1);
                  heff_drop(v_i_247);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepF64: {
                  heff_drop(v_rest_243);
                  heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                  heff_drop(v_a_246);
                  heff_drop_cell(v_ru_24argv1_244_24SVar, 1);
                  heff_drop(v_i_247);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepInt: {
                  heff_drop(v_rest_243);
                  heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                  heff_drop(v_a_246);
                  heff_drop_cell(v_ru_24argv1_244_24SVar, 1);
                  heff_drop(v_i_247);
                  return NTAG(TAG_Nothing);
                }
                default: return heff_nomatch(v_x_2414);
                }
              } else {
                heff_drop(v_field_2412);
                V v_t_2417 = (g_heff_2ecompile_2erefcount_2eintW(v_x_241, v_rest_243));
                if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
                  heff_drop(v_t_2417);
                  return heff_tag_at_n(v_ru_24argv1_244_24SVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24argv_242_24Cons, TAG_MkPair, 2, (V[]){v_a_246, v_i_247})});
                } else {
                  heff_drop_cell(v_ru_24argv_242_24Cons, 2);
                  heff_drop(v_a_246);
                  heff_drop_cell(v_ru_24argv1_244_24SVar, 1);
                  heff_drop(v_i_247);
                  heff_drop(v_t_2417);
                  return NTAG(TAG_Nothing);
                }
              }
            }
          } else {
            heff_drop_rec(v_ce_240, 16);
            heff_drop(v_rest_243);
            heff_drop_cell(v_ru_24argv_242_24Cons, 2);
            heff_drop(v_a_246);
            heff_drop_cell(v_ru_24argv1_244_24SVar, 1);
            heff_drop(v_i_247);
            heff_drop(v_t_249);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_argv22_248, 0ULL, 2);
          heff_drop_rec(v_ce_240, 16);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24argv_242_24Cons, 2);
          heff_drop(v_a_246);
          heff_drop_cell(v_ru_24argv1_244_24SVar, 1);
          heff_drop(v_i_247);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_argv22_248);
        }
      }
      default: return heff_nomatch(v_argv2_245);
      }
    }
    case TAG_SGlobal: {
      heff_take_n(v_argv1_244, 0ULL, 1);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_243);
      heff_drop(v_argv2_245);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SInt: {
      heff_take_n(v_argv1_244, 0ULL, 1);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_243);
      heff_drop(v_argv2_245);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat: {
      heff_take_na(v_argv1_244, 0ULL, 1);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_243);
      heff_drop(v_argv2_245);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SStr: {
      heff_take_n(v_argv1_244, 0ULL, 1);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_243);
      heff_drop(v_argv2_245);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SBytes: {
      heff_take_n(v_argv1_244, 0ULL, 1);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_243);
      heff_drop(v_argv2_245);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFixed: {
      heff_take_n(v_argv1_244, 0ULL, 2);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_243);
      heff_drop(v_argv2_245);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat32: {
      heff_take_na(v_argv1_244, 0ULL, 1);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_243);
      heff_drop(v_argv2_245);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFn: {
      heff_take_n(v_argv1_244, 0ULL, 1);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_243);
      heff_drop(v_argv2_245);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_argv1_244, 0ULL, 2);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_243);
      heff_drop(v_argv2_245);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_argv1_244, 0ULL, 3);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_243);
      heff_drop(v_argv2_245);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_argv1_244, 0ULL, 2);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_243);
      heff_drop(v_argv2_245);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_argv1_244, 0ULL, 4);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_243);
      heff_drop(v_argv2_245);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_argv1_244, 0ULL, 2);
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_rest_243);
      heff_drop(v_argv2_245);
      heff_drop_cell(v_ru_24argv_242_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_argv1_244);
    }
  }
  default: return heff_nomatch(v_argv_242);
  }
}
V g_heff_2ecompile_2erefcount_2epeekArgs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2epeekArgs(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2ecallAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecallAs_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2ecallAs(V v_ce_240, V v_g_241, V v_argv_242, V v_loop_243, V v_ls_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_ce_240, 2));
  V v_t_2411;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_s_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_s_246, 0)), heff_dup(v_g_241))) {
      V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_s_246, 1, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
      if (heff_intEq_c(v_t_248, v_t_249)) {
        v_t_2411 = (g_list_2eall_24s1793250635x935291087(v_loop_243));
      } else {
        v_t_2411 = NTAG(TAG_False);
      }
    } else {
      heff_drop_rec(v_s_246, 2);
      v_t_2411 = NTAG(TAG_False);
    }
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_g_241);
    heff_drop(v_ls_244);
    heff_drop(v_t_2411);
    V v_vs_2412 = (g_list_2emap_24s976303750x321235480(v_loop_243));
    V v_t_2413 = heff_get_n(v_ce_240, 2, 16);
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      heff_drop(v_vs_2412);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      V v_s_2414 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 1);
      V v_t_2415 = heff_tag_n(TAG_CLoop, 2, (V[]){heff_get_n(v_s_2414, 1, 2), v_vs_2412});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_2413);
    }
  } else {
    heff_drop(v_loop_243);
    heff_drop(v_t_2411);
    V v_t_2416 = (g_heff_2ecompile_2erefcount_2eagrees(heff_dup(v_ce_240), v_g_241, v_argv_242));
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_t_2416);
      V v_t_2417 = (g_list_2eall_24s1793250635x935291087(v_ls_244));
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_t_2417);
        HeffT2 v_t_2418 = ({ V b_0 = heff_get_n(v_ce_240, 11, 16); V a_1 = v_g_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2423;
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          v_t_2423 = heff_bool(((v_tag_2419 == ((int64_t)0ULL)) && ({ V v_x_2422 = heff_dup(v_field_2420); int c_ = 1; heff_drop(v_x_2422); c_; })));
          heff_drop(v_field_2420);
        }
        V v_t_2424 = (g_list_2emap_24s976303750x321235480(v_ls_244));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CJump, 3, (V[]){v_g_241, v_t_2423, v_t_2424}), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_t_2417);
        HeffT2 v_t_2425 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
        V v_t_2430;
        {
          V v_field_2427 = v_t_2425.f[1];
          int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
          if ((v_tag_2426 == ((int64_t)0ULL))) {
            V v_s_2429 = v_field_2427;
            v_t_2430 = heff_get_n(v_s_2429, 1, 2);
          } else {
            heff_drop(v_field_2427);
            v_t_2430 = NTAG(TAG_RepV);
          }
        }
        HeffT2 v_t_2431 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
        V v_t_2436;
        {
          V v_field_2433 = v_t_2431.f[1];
          int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
          if ((v_tag_2432 == ((int64_t)0ULL))) {
            V v_x_2435 = v_field_2433;
            v_t_2436 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2435, 1, 2)});
          } else {
            heff_drop(v_field_2433);
            v_t_2436 = NTAG(TAG_Nothing);
          }
        }
        V v_t_2437 = heff_tag_n(TAG_RCall, 4, (V[]){v_g_241, NTAG(TAG_False), v_t_2436, v_ls_244});
        V v_t_2438 = (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2430, heff_get_n(v_ce_240, 15, 16), v_t_2437));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_2438}), NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_t_2416);
      HeffT2 v_t_2439 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
      V v_t_2444;
      {
        V v_field_2441 = v_t_2439.f[1];
        int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
        if ((v_tag_2440 == ((int64_t)0ULL))) {
          V v_s_2443 = v_field_2441;
          v_t_2444 = heff_get_n(v_s_2443, 1, 2);
        } else {
          heff_drop(v_field_2441);
          v_t_2444 = NTAG(TAG_RepV);
        }
      }
      HeffT2 v_t_2445 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
      V v_t_2450;
      {
        V v_field_2447 = v_t_2445.f[1];
        int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
        if ((v_tag_2446 == ((int64_t)0ULL))) {
          V v_x_2449 = v_field_2447;
          v_t_2450 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2449, 1, 2)});
        } else {
          heff_drop(v_field_2447);
          v_t_2450 = NTAG(TAG_Nothing);
        }
      }
      V v_t_2451 = heff_tag_n(TAG_RCall, 4, (V[]){v_g_241, NTAG(TAG_False), v_t_2450, v_ls_244});
      V v_t_2452 = (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2444, heff_get_n(v_ce_240, 15, 16), v_t_2451));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_2452}), NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2ecompile_2erefcount_2ecallAs_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2ecallAs(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2ethreadSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ethreadSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ethreadSt_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ethreadSt(V v_th_240, V v_go_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_s_242)) {
  case TAG_CDrop: {
    heff_drop_rec(v_th_240, 2);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CLet: {
    heff_drop_rec(v_th_240, 2);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CDecl: {
    heff_drop_rec(v_th_240, 2);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CSet: {
    heff_drop_rec(v_th_240, 2);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CAbandon: {
    heff_drop_rec(v_th_240, 2);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CIf: {
    V v_c_249 = heff_field(v_s_242, 0);
    V v_a_2410 = heff_field(v_s_242, 1);
    V v_b_2411 = heff_field(v_s_242, 2);
    V v_ru_24s_242_24CIf = heff_take_reuse_n(v_s_242, 7ULL, 3);
    heff_drop_rec(v_th_240, 2);
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_go_241), 1, (V[]){v_a_2410}));
    V v_t_2413 = heff_tr(heff_call(v_go_241, 1, (V[]){v_b_2411}));
    return heff_tag_at_n(v_ru_24s_242_24CIf, TAG_CIf, 3, (V[]){v_c_249, v_t_2412, v_t_2413});
  }
  case TAG_CSwitch: {
    V v_e_2414 = heff_field(v_s_242, 0);
    V v_arms_2415 = heff_field(v_s_242, 1);
    V v_r_2416 = heff_field(v_s_242, 2);
    V v_ru_24s_242_24CSwitch = heff_take_reuse_n(v_s_242, 7ULL, 3);
    heff_drop_rec(v_th_240, 2);
    V v_t_2427 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ethreadSt_lam0, 1, 1, (V[]){v_go_241}), v_arms_2415));
    return heff_tag_at_n(v_ru_24s_242_24CSwitch, TAG_CSwitch, 3, (V[]){v_e_2414, v_t_2427, v_r_2416});
  }
  case TAG_CReturn: {
    heff_drop_rec(v_th_240, 2);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CInPlace: {
    heff_drop_rec(v_th_240, 2);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CRoomed: {
    heff_drop_rec(v_th_240, 2);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CTail: {
    heff_drop_rec(v_th_240, 2);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CLoop: {
    V v_ps_2435 = heff_field(v_s_242, 0);
    V v_vs_2436 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CLoop = heff_take_reuse_n(v_s_242, 3ULL, 2);
    heff_drop(v_go_241);
    V v_t_2437 = (g_heff_2ecompile_2erefcount_2enthValue(heff_take_field(v_th_240, 0), v_vs_2436));
    HeffT2 v_t_2438 = ({ V b_0 = heff_get_n(v_th_240, 1, 2); V a_1 = v_t_2437; HeffT2 r_ = (g_heff_2ecompile_2erefcount_2etagGiven_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2437); r_; });
    {
      V v_field_2440 = v_t_2438.f[1];
      int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
      if ((v_tag_2439 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24s_242_24CLoop, 2);
        V v_t_2442 = v_field_2440;
        return heff_tag_n(TAG_CLoopTo, 3, (V[]){v_t_2442, v_ps_2435, v_vs_2436});
      } else {
        heff_drop(v_field_2440);
        return heff_tag_at_n(v_ru_24s_242_24CLoop, TAG_CLoop, 2, (V[]){v_ps_2435, v_vs_2436});
      }
    }
  }
  case TAG_CLoopTo: {
    heff_drop_rec(v_th_240, 2);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CLabel: {
    heff_drop_rec(v_th_240, 2);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CJump: {
    heff_drop_rec(v_th_240, 2);
    heff_drop(v_go_241);
    return v_s_242;
  }
  default: return heff_nomatch(v_s_242);
  }
}
V g_heff_2ecompile_2erefcount_2ethreadSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ethreadSt(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2ethreadSt_lam0(V self, V *args) {
  V v_x2_2417 = args[0];
  V v_go_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkCArm: {
    V v_t_2418 = heff_field(v_x2_2417, 0);
    V v_fs_2419 = heff_field(v_x2_2417, 1);
    V v_fl_2420 = heff_field(v_x2_2417, 2);
    V v_su_2421 = heff_field(v_x2_2417, 3);
    V v_pl_2422 = heff_field(v_x2_2417, 4);
    V v_tk_2423 = heff_field(v_x2_2417, 5);
    V v_body_2424 = heff_field(v_x2_2417, 6);
    V v_lv_2425 = heff_field(v_x2_2417, 7);
    V v_ru_24x2_2417_24MkCArm = heff_take_reuse_n(v_x2_2417, 255ULL, 8);
    V v_t_2426 = heff_tr(heff_call(v_go_241, 1, (V[]){v_body_2424}));
    return heff_tag_at_n(v_ru_24x2_2417_24MkCArm, TAG_MkCArm, 8, (V[]){v_t_2418, v_fs_2419, v_fl_2420, v_su_2421, v_pl_2422, v_tk_2423, v_t_2426, v_lv_2425});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(V v_ce_240, V v_xs_241, V v_t_242, V v_fv_243) {
top: ;
  V v_owned_244 = (g_prelude_2e_2b_2b(heff_dup(v_xs_241), v_fv_243));
  V v_wanted_245 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_242)));
  V v_xs_247 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam0, 1, 1, (V[]){v_wanted_245}), v_owned_244));
  V v_t_2414 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam1, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_247));
  V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
  V v_t_2416 = (g_heff_2ecompile_2erefcount_2ewithFrame(NTAG(TAG_Nothing), v_t_2415, v_ce_240));
  V v_t_2417 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(NTAG(TAG_Nil), v_t_2416));
  V v_ce_2418 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2414, NTAG(TAG_Nil), v_t_2417));
  return (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2418, v_t_242));
}
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_wanted_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_246; V a_1 = v_wanted_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_246); heff_drop(v_wanted_245); r_; });
}
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_ce_240, 10, 16); V a_1 = v_x_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_248); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) ? ({ V v_x_2413 = heff_dup(v_field_2411); int c_ = 0; heff_drop(v_x_2413); c_; }) : 1));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461(V v_ce_240, V v_live_241, V v_p_242, V v_argv_243, V v_e_244, V v_rp_245) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_rp_245)) {
  case TAG_RepV: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  case TAG_RepFix: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_RepF64: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_RepInt: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_rp_245);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_e_244);
    heff_drop(v_rp_245);
    heff_drop(v_t_247);
    V v_t_248 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_243));
    return heff_tag_n(TAG_RPrim, 2, (V[]){v_p_242, v_t_248});
  } else {
    heff_drop(v_t_247);
    V v_t_2410;
    switch (heff_tag_of(v_rp_245)) {
    case TAG_RepV: {
      v_t_2410 = NTAG(TAG_False);
      break;
    }
    case TAG_RepFix: {
      v_t_2410 = NTAG(TAG_False);
      break;
    }
    case TAG_RepF64: {
      v_t_2410 = NTAG(TAG_False);
      break;
    }
    case TAG_RepInt: {
      v_t_2410 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_rp_245);
    }
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_rp_245);
      heff_drop(v_t_2410);
      V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
      V v_t_2412 = (g_list_2emap_24f252863627x859179744(v_e_244, NTAG(TAG_RepV), MK_INT(0LL), heff_intSub(v_t_2411, MK_INT(1LL))));
      V v_t_2413 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_240, v_live_241, v_t_2412, v_argv_243));
      return heff_tag_n(TAG_RPrim, 2, (V[]){v_p_242, v_t_2413});
    } else {
      heff_drop(v_t_2410);
      V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
      V v_t_2415 = (g_list_2emap_24f252863627x859179744(v_e_244, heff_dup(v_rp_245), MK_INT(0LL), heff_intSub(v_t_2414, MK_INT(1LL))));
      V v_t_2416 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_240, v_live_241, v_t_2415, v_argv_243));
      return heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_242, v_rp_245, v_t_2416});
    }
  }
}
V g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082_entry, 9, 0};

V g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082(V v_ce_240, V v_live_241, V v_want_242, V v_v_243, V v_e_244, V v_su_245, V v_n_246, V v_x9_247, V v_rp_248) {
top: ;
  switch (heff_tag_of(v_x9_247)) {
  case TAG_Nothing: {
    heff_drop(v_e_244);
    heff_drop(v_su_245);
    heff_drop(v_n_246);
    heff_drop(v_rp_248);
    V v_t_249 = (g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_249));
  }
  case TAG_Just: {
    V v_i_2410 = heff_field(v_x9_247, 0);
    V v_ru_24x9_247_24Just = heff_take_reuse_n(v_x9_247, 1ULL, 1);
    V v_t_2415;
    switch (heff_tag_of(v_rp_248)) {
    case TAG_RepV: {
      v_t_2415 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2415 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      break;
    }
    case TAG_RepF64: {
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2415 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      break;
    }
    case TAG_RepInt: {
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2415 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      break;
    }
    default: heff_nomatch(v_rp_248);
    }
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_e_244);
      heff_drop(v_su_245);
      heff_drop(v_n_246);
      heff_drop(v_rp_248);
      heff_drop(v_i_2410);
      heff_drop_cell(v_ru_24x9_247_24Just, 1);
      heff_drop(v_t_2415);
      V v_t_2416 = (g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(v_ce_240, v_live_241, v_v_243));
      return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2416));
    } else {
      heff_drop(v_v_243);
      heff_drop(v_t_2415);
      V v_t_2440;
      switch (heff_tag_of(v_e_244)) {
      case TAG_SVar: {
        V v_x_2417 = heff_dup(heff_field(v_e_244, 0));
        v_t_2440 = heff_tag_at_n(v_ru_24x9_247_24Just, TAG_Just, 1, (V[]){v_x_2417});
        break;
      }
      case TAG_SGlobal: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_drop_cell(v_ru_24x9_247_24Just, 1);
        v_t_2440 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_244);
      }
      V v_t_2464;
      switch (heff_tag_of(v_e_244)) {
      case TAG_SVar: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SGlobal: {
        V v_g_2442 = heff_dup(heff_field(v_e_244, 0));
        v_t_2464 = heff_tag_n(TAG_Just, 1, (V[]){v_g_2442});
        break;
      }
      case TAG_SInt: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_244);
      }
      V v_t_2465 = (g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775(v_ce_240, v_live_241, v_e_244, heff_dup(v_rp_248), v_su_245, v_i_2410, v_n_246, v_t_2440, v_t_2464));
      return (g_heff_2ecompile_2erefcount_2ecoerce(v_rp_248, v_want_242, v_t_2465));
    }
  }
  default: return heff_nomatch(v_x9_247);
  }
}
V g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153(V v_ce_240, V v_lent_241, V v_live_242, V v_bi_243, V v_i_244, V v_e_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    V v_t_2435;
    switch (heff_tag_of(v_e_245)) {
    case TAG_SVar: {
      V v_x_247 = heff_dup(heff_field(v_e_245, 0));
      HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(heff_rfield(v_ce_240, 10), v_x_247));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          heff_drop(v_x_247);
          V v_x_2412 = v_field_2410;
          heff_drop(v_x_2412);
          v_t_2435 = NTAG(TAG_Nothing);
        } else {
          heff_drop(v_field_2410);
          v_t_2435 = heff_tag_n(TAG_Just, 1, (V[]){v_x_247});
        }
      }
      break;
    }
    case TAG_SGlobal: {
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SInt: {
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat: {
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SStr: {
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SBytes: {
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFixed: {
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat32: {
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrimFn: {
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrim: {
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_245);
    }
    HEFF_LAST return g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330(v_ce_240, v_lent_241, v_live_242, v_bi_243, v_i_244, v_e_245, v_t_2435);
  }
  case TAG_Just: {
    V v_a_2436 = heff_field(v_x8_246, 0);
    V v_ru_24x8_246_24Just = heff_take_reuse_n(v_x8_246, 1ULL, 1);
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_242);
    heff_drop(v_i_244);
    heff_drop(v_e_245);
    return heff_tag_at_n(v_ru_24x8_246_24Just, TAG_Given, 1, (V[]){v_a_2436});
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153(a[0], a1, a[2], a3, a[4], a[5], a[6]); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_e_245, V v_es_246) {
top: ;
  V v_t_247 = (g_heff_2ecompile_2erefcount_2elentIn(heff_dup(v_ce_240), v_bi_243, heff_intAdd(heff_dup(v_i_244), MK_INT(1LL)), heff_dup(v_es_246)));
  V v_lent_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_live_241)));
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_246));
  V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, heff_dup(v_live_241)));
  V v_live_2412 = (g_prelude_2e_2b_2b(v_before_242, v_t_2411));
  V v_t_2413 = (g_heff_2ecompile_2erefcount_2eelemI(heff_dup(v_i_244), v_bi_243));
  V v_t_2414;
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_t_2413);
    v_t_2414 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_live_241; V a_2 = v_e_245; V r_ = (g_heff_2ecompile_2erefcount_2elentField(a_0, a_1, a_2)); heff_drop(v_live_241); r_; });
  } else {
    heff_drop(v_live_241);
    heff_drop(v_t_2413);
    v_t_2414 = NTAG(TAG_Nothing);
  }
  return ({ V a_0 = v_ce_240; V a_1 = v_lent_248; V a_2 = v_live_2412; V a_3 = v_bi_243; V a_4 = v_i_244; V a_5 = v_e_245; V a_6 = v_t_2414; V r_ = (g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_lent_248); r_; });
}
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_rp_247 = heff_field(v_x7_245, 0);
    V v_rps_248 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_i_244);
      heff_drop(v_rp_247);
      heff_drop(v_rps_248);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_249 = heff_field(v_x8_246, 0);
      V v_es_2410 = heff_field(v_x8_246, 1);
      heff_take_n(v_x8_246, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), v_bi_243, heff_dup(v_i_244), v_rp_247, heff_dup(v_e_249), heff_dup(v_es_2410)));
      V v_cell_2412 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_t_2413 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = heff_dup(v_i_244); V a_3 = v_e_249; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_249); r_; });
      V v_u_2414 = (g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(v_ce_240, v_live_241, v_t_2413, v_bi_243, heff_box_word((heff_unbox_word(v_i_244) + ((int64_t)1ULL))), v_rps_248, v_es_2410, heff_dup(v_cell_2412)));
      heff_drop(v_u_2414);
      return v_cell_2412;
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_str0, 10, "arrayIndex");
Clo g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(V v_ce_240, V v_live_241, V v_want_242, V v_o_243) {
top: ;
  switch (heff_tag_of(v_o_243)) {
  case TAG_OSimple: {
    V v_v_244 = heff_field(v_o_243, 0);
    heff_take_n(v_o_243, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, v_want_242, v_v_244);
  }
  case TAG_OCall: {
    V v_g_245 = heff_field(v_o_243, 0);
    V v_argv_246 = heff_field(v_o_243, 1);
    V v_ru_24o_243_24OCall = heff_take_reuse_n(v_o_243, 3ULL, 2);
    HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_ce_240, 11), v_g_245));
    V v_t_2412;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_s_2411 = v_field_249;
        v_t_2412 = heff_get_n(v_s_2411, 1, 2);
      } else {
        heff_drop(v_field_249);
        v_t_2412 = NTAG(TAG_RepV);
      }
    }
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, heff_tag_at_n(v_ru_24o_243_24OCall, TAG_OCall, 2, (V[]){v_g_245, v_argv_246})));
    return (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2412, v_want_242, v_t_2413));
  }
  case TAG_OApply: {
    V v_t_2416 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2416));
  }
  case TAG_OPrim: {
    V v_p_2417 = heff_field(v_o_243, 0);
    V v_argv_2418 = heff_field(v_o_243, 1);
    V v_ru_24o_243_24OPrim = heff_take_reuse_n(v_o_243, 3ULL, 2);
    if (heff_strEq_c_lent(v_p_2417, ((V)&g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_str0), 2)) {
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        V v_t_2420 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, heff_tag_at_n(v_ru_24o_243_24OPrim, TAG_OPrim, 2, (V[]){v_p_2417, v_argv_2418})));
        return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2420));
      }
      case TAG_RepFix: {
        heff_drop_cell(v_ru_24o_243_24OPrim, 2);
        V v_t_2422 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2418));
        return heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_2417, v_want_242, v_t_2422});
      }
      case TAG_RepF64: {
        heff_drop_cell(v_ru_24o_243_24OPrim, 2);
        V v_t_2423 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2418));
        return heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_2417, v_want_242, v_t_2423});
      }
      case TAG_RepInt: {
        heff_drop_cell(v_ru_24o_243_24OPrim, 2);
        V v_t_2424 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2418));
        return heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_2417, v_want_242, v_t_2424});
      }
      default: return heff_nomatch(v_want_242);
      }
    } else {
      V v_t_2425 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, heff_tag_at_n(v_ru_24o_243_24OPrim, TAG_OPrim, 2, (V[]){v_p_2417, v_argv_2418})));
      return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2425));
    }
  }
  case TAG_OAbandon: {
    V v_t_2426 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2426));
  }
  case TAG_OBool: {
    V v_t_2428 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2428));
  }
  default: return heff_nomatch(v_o_243);
  }
}
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam2(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(V v_ce_240, V v_x_241, V v_a_242, V v_i_243, V v_rest_244, V v_after_245, V v_wb_246) {
top: ;
  V v_t_247 = (g_heff_2ecompile_2erefcount_2efvVal(heff_dup(v_i_243)));
  V v_wanted_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_wb_246)));
  V v_xs_2411 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam0, 1, 1, (V[]){v_wanted_248}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2412 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2411));
  V v_t_2413 = (g_list_2emap_24s1796125103x644876049(v_t_2412));
  V v_t_2414 = (g_heff_2ecompile_2erefcount_2efvVal(heff_dup(v_i_243)));
  V v_wanted_2415 = (g_prelude_2e_2b_2b(v_t_2414, heff_dup(v_wb_246)));
  V v_t_2417 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam1, 1, 1, (V[]){v_wanted_2415}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_ce_2418 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2417, heff_dup(v_wb_246), heff_dup(v_ce_240)));
  V v_t_2419 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_2418, heff_dup(v_wb_246), NTAG(TAG_RepV), v_i_243));
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_a_242}), v_t_2420});
  V v_t_2422 = heff_tag_n(TAG_CLet, 2, (V[]){heff_dup(v_x_241), heff_tag_n(TAG_RPrim, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2epeekPrim_get()), v_t_2421})});
  V v_t_2424 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam2, 1, 1, (V[]){v_wb_246}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, heff_dup(heff_rfield(v_ce_240, 6))});
  V v_t_2426 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2425, heff_dup(v_ce_240)));
  V v_ce_2427 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2424, heff_get_n(v_ce_240, 5, 16), v_t_2426));
  V v_t_2428 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2427, v_rest_244, v_after_245));
  return (g_prelude_2e_2b_2b(v_t_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2428})));
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam0(V self, V *args) {
  V v_v_249 = args[0];
  V v_wanted_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2410 = ({ V a_0 = v_v_249; V a_1 = v_wanted_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_249); heff_drop(v_wanted_248); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2410) == NTAG(TAG_True)));
  heff_drop(v_x1_2410);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam1(V self, V *args) {
  V v_v_2416 = args[0];
  V v_wanted_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2416; V a_1 = v_wanted_2415; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2416); heff_drop(v_wanted_2415); r_; });
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_lam2(V self, V *args) {
  V v_v_2423 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2423; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2423); heff_drop(v_wb_246); r_; });
}
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377(V v_ce_240, V v_x_241, V v_o_242, V v_rest_243, V v_after_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nothing: {
    V v_fa_246 = (g_heff_2ecompile_2erefcount_2efvOp(heff_dup(v_o_242)));
    V v_known_247 = (g_heff_2ecompile_2erefcount_2ebuiltOf(heff_dup(v_o_242)));
    V v_t_2410;
    switch (heff_tag_of(v_after_244)) {
    case TAG_Nothing: {
      v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_rest_243)}), NTAG(TAG_Nil)});
      break;
    }
    case TAG_Just: {
      V v_t_248 = heff_dup(heff_field(v_after_244, 0));
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_248}), NTAG(TAG_Nil)});
      v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_rest_243)}), v_t_249});
      break;
    }
    default: heff_nomatch(v_after_244);
    }
    V v_t_2411 = (g_heff_2ecompile_2erefcount_2eoperandsOf(heff_dup(v_o_242)));
    V v_takes_2412 = (g_heff_2ecompile_2erefcount_2etakesAt(heff_dup(v_ce_240), NTAG(TAG_Nil), v_t_2410, v_t_2411));
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_rest_243), heff_dup(v_after_244)));
    V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2413, heff_dup(heff_rfield(v_ce_240, 5))));
    return ({ V a_0 = heff_dup(v_ce_240); V a_1 = heff_dup(v_x_241); V a_2 = v_fa_246; V a_3 = heff_clo_n(g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam0, 1, 3, (V[]){v_ce_240, v_x_241, v_o_242}); V a_4 = v_known_247; V a_5 = v_takes_2412; V a_6 = v_rest_243; V a_7 = v_after_244; V a_8 = v_t_2414; V r_ = (g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_known_247); r_; });
  }
  case TAG_Just: {
    V v_x71_2424 = heff_field(v_x7_245, 0);
    heff_drop(v_o_242);
    switch (heff_tag_of(v_x71_2424)) {
    case TAG_MkPair: {
      V v_a_2425 = heff_field(v_x71_2424, 0);
      V v_i_2426 = heff_field(v_x71_2424, 1);
      V v_t_2427 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_rest_243), heff_dup(v_after_244)));
      V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2427, heff_dup(heff_rfield(v_ce_240, 5))));
      return (g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646(v_ce_240, v_x_241, heff_dup(v_a_2425), heff_dup(v_i_2426), v_rest_243, v_after_244, v_t_2428));
    }
    default: return heff_nomatch(v_x71_2424);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_lam0(V self, V *args) {
  V v_ce2_2415 = args[0];
  V v_ce_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_o_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_ce_240, 10, 16); V a_1 = v_x_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2422;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    V v_t_2421;
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2418;
      v_t_2421 = v_x_2420;
    } else {
      heff_drop(v_field_2418);
      v_t_2421 = NTAG(TAG_RepV);
    }
    v_t_2422 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce2_2415), heff_dup(heff_rfield(v_ce2_2415, 5)), v_t_2421, heff_dup(v_o_242)));
  }
  V v_t_2423 = ({ V a_0 = v_ce2_2415; V a_1 = v_o_242; V r_ = (g_heff_2ecompile_2erefcount_2eboolDone(a_0, a_1)); heff_drop(v_o_242); r_; });
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_241, v_t_2422}), v_t_2423});
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(V v_ce_240, V v_b_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_b_241)) {
  case TAG_ATail: {
    V v_t_242 = heff_field(v_b_241, 0);
    v_t_244 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_242)));
    break;
  }
  case TAG_ASts: {
    V v_ss_243 = heff_field(v_b_241, 0);
    v_t_244 = (g_heff_2ecompile_2erefcount_2efvSts(heff_dup(v_ss_243)));
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_wanted_245 = (g_prelude_2e_2b_2b(v_t_244, heff_dup(heff_rfield(v_ce_240, 5))));
  V v_xs_248 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam0, 1, 1, (V[]){v_wanted_245}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_249 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_248));
  V v_t_2410 = (g_list_2emap_24s1796125103x644876049(v_t_249));
  V v_t_2413;
  switch (heff_tag_of(v_b_241)) {
  case TAG_ATail: {
    V v_t_2411 = heff_field(v_b_241, 0);
    v_t_2413 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_2411)));
    break;
  }
  case TAG_ASts: {
    V v_ss_2412 = heff_field(v_b_241, 0);
    v_t_2413 = (g_heff_2ecompile_2erefcount_2efvSts(heff_dup(v_ss_2412)));
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_wanted_2414 = (g_prelude_2e_2b_2b(v_t_2413, heff_dup(heff_rfield(v_ce_240, 5))));
  V v_t_2416 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam1, 1, 1, (V[]){v_wanted_2414}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_ce_2417 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2416, heff_dup(heff_rfield(v_ce_240, 5)), v_ce_240));
  V v_t_2420;
  switch (heff_tag_of(v_b_241)) {
  case TAG_ATail: {
    V v_t_2418 = heff_field(v_b_241, 0);
    v_t_2420 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2417, heff_dup(v_t_2418)));
    break;
  }
  case TAG_ASts: {
    V v_ss_2419 = heff_field(v_b_241, 0);
    v_t_2420 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2417, heff_dup(v_ss_2419), NTAG(TAG_Nothing)));
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_2410, v_t_2420);
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_wanted_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_247 = ({ V a_0 = v_v_246; V a_1 = v_wanted_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_246); heff_drop(v_wanted_245); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
  heff_drop(v_x1_247);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam1(V self, V *args) {
  V v_v_2415 = args[0];
  V v_wanted_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2415; V a_1 = v_wanted_2414; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2415); heff_drop(v_wanted_2414); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam4(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam5(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam6(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry, 9, 0};

V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(V v_ce_240, V v_taken_241, V v_lent_242, V v_t_243, V v_vs_244, V v_fb_245, V v_leaves_246, V v_rd_247, V v_x10_248) {
top: ;
  switch (heff_tag_of(v_x10_248)) {
  case TAG_MkPair: {
    V v_ru_249 = heff_field(v_x10_248, 0);
    V v_b2_2410 = heff_field(v_x10_248, 1);
    V v_ru_24x10_248_24MkPair = heff_take_reuse_n(v_x10_248, 3ULL, 2);
    V v_t_2412;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2412 = NTAG(TAG_True);
    } else {
      switch (heff_tag_of(v_taken_241)) {
      case TAG_Nothing: {
        v_t_2412 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        v_t_2412 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_taken_241);
      }
    }
    V v_ys_2413 = heff_take_field(v_rd_247, 2);
    V v_t_2418;
    switch (heff_tag_of(v_ys_2413)) {
    case TAG_Nil: {
      v_t_2418 = heff_dup(v_fb_245);
      break;
    }
    case TAG_Cons: {
      v_t_2418 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam0, 1, 1, (V[]){v_ys_2413}), heff_dup(v_fb_245)));
      break;
    }
    default: heff_nomatch(v_ys_2413);
    }
    V v_t_2419 = ({ V a_0 = heff_rfield(v_rd_247, 4); V a_1 = heff_rfield(v_rd_247, 5); V a_2 = v_ru_249; V a_3 = v_taken_241; V a_4 = v_vs_244; V a_5 = v_t_2418; V r_ = (g_heff_2ecompile_2erefcount_2etakeOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2418); r_; });
    V v_t_2421;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2421 = heff_dup(heff_rfield(v_rd_247, 3));
    } else {
      v_t_2421 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam1, 1, 1, (V[]){heff_dup(v_fb_245)}), heff_dup(v_vs_244)));
    }
    V v_owned_2422 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), v_t_2421));
    V v_wanted_2423 = (g_prelude_2e_2b_2b(heff_dup(v_fb_245), heff_dup(heff_rfield(v_ce_240, 5))));
    V v_t_2426 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam2, 1, 1, (V[]){v_wanted_2423}), v_owned_2422));
    V v_xs_2431 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam3, 1, 1, (V[]){heff_dup(v_taken_241)}), v_t_2426));
    V v_t_2432 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2431));
    V v_t_2433 = (g_list_2emap_24s1796125103x644876049(v_t_2432));
    V v_t_2435;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2435 = heff_dup(heff_rfield(v_rd_247, 3));
    } else {
      v_t_2435 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam4, 1, 1, (V[]){heff_dup(v_fb_245)}), heff_dup(v_vs_244)));
    }
    V v_t_2437;
    switch (heff_tag_of(v_ru_249)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x10_248_24MkPair, 2);
      v_t_2437 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2436 = heff_dup(heff_field(v_ru_249, 0));
      v_t_2437 = heff_tag_at_n(v_ru_24x10_248_24MkPair, TAG_Cons, 2, (V[]){v_x_2436, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_249);
    }
    V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2435, v_t_2437));
    V v_owned_2439 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), v_t_2438));
    V v_t_2441;
    switch (heff_tag_of(v_ru_249)) {
    case TAG_Nothing: {
      v_t_2441 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2440 = heff_dup(heff_field(v_ru_249, 0));
      v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2440, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_249);
    }
    V v_wanted_2442 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_240, 5)), v_fb_245, v_t_2441));
    V v_t_2444 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam5, 1, 1, (V[]){v_wanted_2442}), v_owned_2439));
    V v_t_2451;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      V v_ys_2445 = heff_dup(heff_rfield(v_rd_247, 3));
      V v_t_2450;
      switch (heff_tag_of(v_ys_2445)) {
      case TAG_Nil: {
        v_t_2450 = heff_dup(v_vs_244);
        break;
      }
      case TAG_Cons: {
        v_t_2450 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam6, 1, 1, (V[]){v_ys_2445}), heff_dup(v_vs_244)));
        break;
      }
      default: heff_nomatch(v_ys_2445);
      }
      v_t_2451 = (g_prelude_2e_2b_2b(v_t_2450, heff_dup(heff_rfield(v_ce_240, 6))));
    } else {
      v_t_2451 = heff_dup(heff_rfield(v_ce_240, 6));
    }
    V v_n_2452 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_244; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_vs_244); r_; });
    V v_t_2454;
    switch (heff_tag_of(v_ru_249)) {
    case TAG_Nothing: {
      heff_drop(v_n_2452);
      v_t_2454 = heff_dup(v_ce_240);
      break;
    }
    case TAG_Just: {
      V v_ru_2453 = heff_field(v_ru_249, 0);
      V v_ru_24ru_249_24Just = heff_take_reuse_n(v_ru_249, 1ULL, 1);
      v_t_2454 = (g_heff_2ecompile_2erefcount_2ewithKnown(v_ru_2453, heff_tag_at_n(v_ru_24ru_249_24Just, TAG_KnownCell, 1, (V[]){v_n_2452}), heff_dup(v_ce_240)));
      break;
    }
    default: heff_nomatch(v_ru_249);
    }
    V v_t_2455 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2451, v_t_2454));
    V v_ce_2456 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2444, heff_get_n(v_ce_240, 5, 16), v_t_2455));
    V v_t_2459;
    switch (heff_tag_of(v_b2_2410)) {
    case TAG_ATail: {
      V v_t_2457 = heff_field(v_b2_2410, 0);
      heff_take_n(v_b2_2410, 1ULL, 1);
      v_t_2459 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2456, v_t_2457));
      break;
    }
    case TAG_ASts: {
      V v_ss_2458 = heff_field(v_b2_2410, 0);
      heff_take_n(v_b2_2410, 1ULL, 1);
      v_t_2459 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2456, v_ss_2458, NTAG(TAG_Nothing)));
      break;
    }
    default: heff_nomatch(v_b2_2410);
    }
    V v_t_2460 = (g_prelude_2e_2b_2b(v_t_2433, v_t_2459));
    return heff_tag_n(TAG_MkCArm, 8, (V[]){v_t_243, heff_dup(heff_rfield(v_rd_247, 0)), heff_dup(heff_rfield(v_rd_247, 1)), heff_get_n(v_rd_247, 5, 6), v_t_2412, v_t_2419, v_t_2460, v_leaves_246});
  }
  default: return heff_nomatch(v_x10_248);
  }
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(a[0], a1, a2, a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam0(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ys_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2417 = ({ V a_0 = v_x_2416; V a_1 = v_ys_2413; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2416); heff_drop_tag(v_ys_2413, 2); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2417) == NTAG(TAG_True)));
  heff_drop(v_x1_2417);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam1(V self, V *args) {
  V v_v_2420 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2420; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2420); heff_drop(v_fb_245); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam2(V self, V *args) {
  V v_v_2424 = args[0];
  V v_wanted_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2425 = ({ V a_0 = v_v_2424; V a_1 = v_wanted_2423; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2424); heff_drop(v_wanted_2423); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2425) == NTAG(TAG_True)));
  heff_drop(v_x1_2425);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam3(V self, V *args) {
  V v_v_2427 = args[0];
  V v_taken_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429;
  switch (heff_tag_of(v_taken_241)) {
  case TAG_Nothing: {
    v_t_2429 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2428 = heff_field(v_taken_241, 0);
    heff_take_n(v_taken_241, 1ULL, 1);
    v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2428, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_taken_241);
  }
  V v_x1_2430 = ({ V a_0 = v_v_2427; V a_1 = v_t_2429; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2427); heff_drop(v_t_2429); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2430) == NTAG(TAG_True)));
  heff_drop(v_x1_2430);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam4(V self, V *args) {
  V v_v_2434 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2434; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2434); heff_drop(v_fb_245); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam5(V self, V *args) {
  V v_v_2443 = args[0];
  V v_wanted_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2443; V a_1 = v_wanted_2442; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2443); heff_drop(v_wanted_2442); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam6(V self, V *args) {
  V v_x_2448 = args[0];
  V v_ys_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2449 = ({ V a_0 = v_x_2448; V a_1 = v_ys_2445; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2448); heff_drop_tag(v_ys_2445, 2); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2449) == NTAG(TAG_True)));
  heff_drop(v_x1_2449);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(V v_ce_240, V v_taken_241, V v_lent_242, V v_t_243, V v_vs_244, V v_fb_245, V v_leaves_246, V v_p_247) {
top: ;
  V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
  V v_t_249 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_248, MK_INT(1LL))));
  V v_t_2410 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_vs_244), v_t_249));
  V v_ws_2415 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam0, 1, 1, (V[]){heff_dup(v_fb_245)}), v_t_2410));
  HeffT2 v_t_2416 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_ce_240, 13), v_t_243));
  V v_t_2421;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2418;
      v_t_2421 = v_x_2420;
    } else {
      heff_drop(v_field_2418);
      v_t_2421 = NTAG(TAG_Nil);
    }
  }
  V v_t_2422 = (g_std_2emap_2elookup_24s1963842891x1660122411(heff_rfield(v_ce_240, 12), v_t_243));
  V v_t_2423 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_t_2421; V a_2 = v_ws_2415; V a_3 = v_t_2422; V r_ = (g_heff_2ecompile_2erefcount_2ereadsWith(a_0, a_1, a_2, a_3)); heff_drop(v_t_2422); r_; });
  return (g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(v_ce_240, v_taken_241, v_lent_242, v_t_243, v_vs_244, v_fb_245, v_leaves_246, v_t_2423, v_p_247));
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(a[0], a1, a2, a[3], a[4], a[5], a[6], a[7]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam0(V self, V *args) {
  V v_p_2411 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414;
  switch (heff_tag_of(v_p_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_p_2411, 0);
    heff_take_n(v_p_2411, 1ULL, 2);
    v_t_2414 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_p_2411);
  }
  return ({ V a_0 = v_t_2414; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_t_2414); heff_drop(v_fb_245); r_; });
}
Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 16);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_p_248 = heff_field(v_x7_245, 0);
    V v_ps_249 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 16);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_i_244);
      heff_drop(v_p_248);
      heff_drop(v_ps_249);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_e_2410 = heff_field(v_x8_246, 0);
      V v_es_2411 = heff_field(v_x8_246, 1);
      heff_take_n(v_x8_246, 3ULL, 2);
      HeffT2 v_t_2412 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(heff_rfield(v_ce_240, 10), v_p_248));
      V v_t_2428;
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_x_2416 = v_field_2414;
          heff_drop(v_x_2416);
          V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_2411)));
          V v_t_2418 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_2417); r_; });
          V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2418, heff_dup(v_live_241)));
          V v_live_2420 = (g_prelude_2e_2b_2b(heff_dup(v_before_242), v_t_2419));
          HeffT2 v_t_2421 = ({ V a_0 = heff_rfield(v_ce_240, 10); V a_1 = v_p_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_p_248); r_; });
          V v_t_2427;
          {
            V v_field_2423 = v_t_2421.f[1];
            int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
            V v_t_2426;
            if ((v_tag_2422 == ((int64_t)0ULL))) {
              V v_x_2425 = v_field_2423;
              v_t_2426 = v_x_2425;
            } else {
              heff_drop(v_field_2423);
              v_t_2426 = NTAG(TAG_RepV);
            }
            v_t_2427 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2420, v_t_2426, heff_dup(v_e_2410)));
          }
          v_t_2428 = heff_tag_n(TAG_Given, 1, (V[]){v_t_2427});
        } else {
          heff_drop(v_p_248);
          heff_drop(v_field_2414);
          v_t_2428 = (g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), v_bi_243, heff_dup(v_i_244), heff_dup(v_e_2410), heff_dup(v_es_2411)));
        }
      }
      V v_cell_2429 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2428, heff_hole()});
      V v_u_2430 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2429));
      heff_drop(v_u_2430);
      V v_t_2431 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = heff_dup(v_i_244); V a_3 = v_e_2410; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_2410); r_; });
      V t_0 = v_ce_240;
      V t_1 = v_live_241;
      V t_2 = v_t_2431;
      V t_3 = v_bi_243;
      V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
      V t_5 = v_ps_249;
      V t_6 = v_es_2411;
      V t_7 = v_cell_2429;
      v_ce_240 = t_0;
      v_live_241 = t_1;
      v_before_242 = t_2;
      v_bi_243 = t_3;
      v_i_244 = t_4;
      v_x7_245 = t_5;
      v_x8_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7]); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str2, 0, "");
Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V v_ce_240, V v_x3_241) {
top: ;
  return (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(NTAG(TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565), ((V)&g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str0), ((V)&g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str1), ((V)&g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_str2), v_ce_240, v_x3_241));
}
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_b_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245;
    if ((heff_dup(v_b_244) == NTAG(TAG_True))) {
      heff_drop(v_b_244);
      v_t_245 = MK_INT(1LL);
    } else {
      heff_drop(v_b_244);
      v_t_245 = MK_INT(0LL);
    }
    V v_t_246 = (g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(v_f_240, v_xs_243));
    return heff_intAdd(v_t_245, heff_intMul(MK_INT(2LL), v_t_246));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(a[0], a1); heff_drop(a1); return r;
}