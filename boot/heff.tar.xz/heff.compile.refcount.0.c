// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CTail 59847
#define TAG_Given 9359
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_KnownCell 38933
#define TAG_MkCArm 24694
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_after 294093302
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_counted 1189688364
#define LBL_flat 9641024
#define LBL_flats 298871860
#define LBL_funs 9650075
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_names 305943394
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_plain 308106724
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sure 10037468
#define LBL_takes 311482598
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_ret};
V g_heff_2ecompile_2erefcount_2eagrees(V, V, V);
V g_heff_2ecompile_2erefcount_2eagrees_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eagrees_clo;
V g_heff_2ecompile_2erefcount_2eapplyLast(V, V, V);
V g_heff_2ecompile_2erefcount_2eapplyLast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eapplyLast_clo;
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_clo;
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_clo;
V g_heff_2ecompile_2erefcount_2eboolDone(V, V);
V g_heff_2ecompile_2erefcount_2eboolDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eboolDone_clo;
V g_heff_2ecompile_2erefcount_2eboolName_get(void);
V g_heff_2ecompile_2erefcount_2ecallAs(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecallAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecallAs_clo;
V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(V, V, V);
V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_clo;
V g_heff_2ecompile_2erefcount_2ecoerce(V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_clo;
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_clo;
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(V, V, V);
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_clo;
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(V, V);
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_clo;
V g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2efieldMask(V, V, V);
V g_heff_2ecompile_2erefcount_2efieldMask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldMask_clo;
V g_heff_2ecompile_2erefcount_2efieldNum_24s4728276x1588665507(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efieldNum_24s4728276x1588665507_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldNum_24s4728276x1588665507_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
V g_heff_2ecompile_2erefcount_2efvOp(V);
V g_heff_2ecompile_2erefcount_2efvOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvOp_clo;
V g_heff_2ecompile_2erefcount_2efvRest(V, V);
V g_heff_2ecompile_2erefcount_2efvRest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvRest_clo;
V g_heff_2ecompile_2erefcount_2efvSts(V);
V g_heff_2ecompile_2erefcount_2efvSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvSts_clo;
V g_heff_2ecompile_2erefcount_2efvTl(V);
V g_heff_2ecompile_2erefcount_2efvTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_clo;
V g_heff_2ecompile_2erefcount_2efvVal(V);
V g_heff_2ecompile_2erefcount_2efvVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvVal_clo;
V g_heff_2ecompile_2erefcount_2efvW(V, V, V);
V g_heff_2ecompile_2erefcount_2efvW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvW_clo;
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(V, V);
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_clo;
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_clo;
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo;
V g_heff_2ecompile_2erefcount_2elentField(V, V, V);
V g_heff_2ecompile_2erefcount_2elentField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentField_clo;
V g_heff_2ecompile_2erefcount_2elentIn(V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentIn_clo;
V g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330_clo;
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_clo;
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2epow2(V);
V g_heff_2ecompile_2erefcount_2epow2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epow2_clo;
V g_heff_2ecompile_2erefcount_2eprojAs_24s1034245672x791498949(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprojAs_24s1034245672x791498949_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprojAs_24s1034245672x791498949_clo;
V g_heff_2ecompile_2erefcount_2ereadsWith(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ereadsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereadsWith_clo;
V g_heff_2ecompile_2erefcount_2ereuseArgs(V, V);
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo;
V g_heff_2ecompile_2erefcount_2ereuseOp(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseOp_clo;
V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_clo;
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_clo;
V g_heff_2ecompile_2erefcount_2ereuseV(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseV_clo;
V g_heff_2ecompile_2erefcount_2esameAs(V, V, V);
V g_heff_2ecompile_2erefcount_2esameAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esameAs_clo;
V g_heff_2ecompile_2erefcount_2esameS(V, V);
V g_heff_2ecompile_2erefcount_2esameS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esameS_clo;
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_clo;
V g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481(V, V, V);
V g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo;
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo;
V g_heff_2ecompile_2erefcount_2etakeIn(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeIn_clo;
V g_heff_2ecompile_2erefcount_2etakeOf(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeOf_clo;
V g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868(V, V, V);
V g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868_clo;
V g_heff_2ecompile_2erefcount_2eunboxOf(V, V);
V g_heff_2ecompile_2erefcount_2eunboxOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxOf_clo;
V g_heff_2ecompile_2erefcount_2eunboxParam(V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxParam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxParam_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(V, V, V);
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2ereprsEq(V, V);
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsEq_clo;
V g_list_2eall_24s1793250635x935291087(V);
V g_list_2eall_24s1793250635x935291087_entry(V self, V *a);
extern Clo g_list_2eall_24s1793250635x935291087_clo;
V g_list_2eany_24s1681212806x1534785672(V, V, V);
V g_list_2eany_24s1681212806x1534785672_entry(V self, V *a);
extern Clo g_list_2eany_24s1681212806x1534785672_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s826961155x1314392429(V, V);
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s826961155x1314392429_clo;
V g_list_2emap_24s1341404685x1564972929(V);
V g_list_2emap_24s1341404685x1564972929_entry(V self, V *a);
extern Clo g_list_2emap_24s1341404685x1564972929_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s976303750x321235480(V);
V g_list_2emap_24s976303750x321235480_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1572068627x1632985590(V, V);
V g_prelude_2e_2b_2b_24f1572068627x1632985590_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1572068627x1632985590_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
Clo g_heff_2ecompile_2erefcount_2ewithPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithPath_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ewithPath(V v_owned_240, V v_after_241, V v_ce_242) {
top: ;
  return ({ V rv_4 = v_owned_240; V rv_5 = v_after_241; V rr_ = heff_rec_reuse_nf(v_ce_242, 32719ULL, 15, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__ret, 1073737983u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithPath(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithTakes_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ewithTakes(V v_ts_240, V v_ce_241) {
top: ;
  return ({ V rv_9 = v_ts_240; V rr_ = heff_rec_reuse_nf(v_ce_241, 32255ULL, 15, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__ret, 1072955391u, 0u); heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithTakes(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efreeGo_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2efreeGo(V v_bs_240, V v_seen_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_v_244), v_bs_240));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      V v_x3_247 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_v_244), v_seen_241));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        V v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_v_244), NTAG(TAG_MkUnit), v_seen_241));
        V t_0 = v_bs_240;
        V t_1 = v_t_248;
        V t_2 = v_vs_245;
        V t_3 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_v_244, v_acc_243});
        v_bs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      case TAG_Just: {
        heff_take_n(v_x3_247, 0ULL, 1);
        heff_drop(v_v_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_seen_241;
        V t_2 = v_vs_245;
        V t_3 = v_acc_243;
        v_bs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x3_247);
      }
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      heff_drop(v_v_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_seen_241;
      V t_2 = v_vs_245;
      V t_3 = v_acc_243;
      v_bs_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2efreeGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erefcount_2efvVal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvVal_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2efvVal(V v_v_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_240}), NTAG(TAG_Nil)});
  V v_x2_242 = (g_heff_2ecompile_2erefcount_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_241));
  switch (heff_tag_of(v_x2_242)) {
  case TAG_MkPair: {
    V v_bs_243 = heff_field(v_x2_242, 0);
    V v_ms_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_bs_245 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_243));
    V v_ms_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_244));
    V v_t_247 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_245; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_bs_245); r_; });
    return ({ V a_0 = v_t_247; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_246; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2erefcount_2efvVal_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvVal(a[0]);
}
Clo g_heff_2ecompile_2erefcount_2efvOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvOp_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2efvOp(V v_o_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_240}), NTAG(TAG_Nil)});
  V v_x2_242 = (g_heff_2ecompile_2erefcount_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_241));
  switch (heff_tag_of(v_x2_242)) {
  case TAG_MkPair: {
    V v_bs_243 = heff_field(v_x2_242, 0);
    V v_ms_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_bs_245 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_243));
    V v_ms_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_244));
    V v_t_247 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_245; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_bs_245); r_; });
    return ({ V a_0 = v_t_247; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_246; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2erefcount_2efvOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvOp(a[0]);
}
Clo g_heff_2ecompile_2erefcount_2efvRest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvRest_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2efvRest(V v_ss_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return (g_heff_2ecompile_2erefcount_2efvSts(v_ss_240));
  }
  case TAG_Just: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_ITl, 1, (V[]){v_t_242}), NTAG(TAG_Nil)});
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_240}), v_t_243});
    V v_x2_245 = (g_heff_2ecompile_2erefcount_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_244));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_bs_246 = heff_field(v_x2_245, 0);
      V v_ms_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      V v_bs_248 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_246));
      V v_ms_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_247));
      V v_t_2410 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_248; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_bs_248); r_; });
      return ({ V a_0 = v_t_2410; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_249; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2efvRest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvRest(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2elentIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentIn_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2elentIn(V v_ce_240, V v_bi_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 15);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_es_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2erefcount_2eelemI(heff_dup(v_i_242), v_bi_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_x1_2432;
      switch (heff_tag_of(v_e_244)) {
      case TAG_SVar: {
        V v_x_247 = heff_field(v_e_244, 0);
        V v_ru_24e_244_24SVar = heff_take_reuse_n(v_e_244, 1ULL, 1);
        V v_x3_248 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_247), heff_rfield(v_ce_240, 10)));
        switch (heff_tag_of(v_x3_248)) {
        case TAG_Nothing: {
          v_x1_2432 = heff_tag_at_n(v_ru_24e_244_24SVar, TAG_Just, 1, (V[]){v_x_247});
          break;
        }
        case TAG_Just: {
          heff_take_n(v_x3_248, 0ULL, 1);
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24e_244_24SVar, 1);
          v_x1_2432 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x3_248);
        }
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_e_244, 0ULL, 1);
        v_x1_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_e_244, 0ULL, 1);
        v_x1_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_e_244, 0ULL, 1);
        v_x1_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_e_244, 0ULL, 3);
        v_x1_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_e_244, 0ULL, 4);
        v_x1_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_e_244, 0ULL, 2);
        v_x1_2432 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_244);
      }
      V v_xs_2433 = (g_heff_2ecompile_2erefcount_2elentIn(v_ce_240, v_bi_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_es_245));
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        return v_xs_2433;
      }
      case TAG_Just: {
        V v_x_2434 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_x_2434, v_xs_2433});
      }
      default: return heff_nomatch(v_x1_2432);
      }
    } else {
      heff_drop(v_e_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_ce_240;
      V t_1 = v_bi_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_es_245;
      v_ce_240 = t_0;
      v_bi_241 = t_1;
      v_i_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erefcount_2elentIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2elentIn(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2eunboxParam_str0, 4, "box$");
Clo g_heff_2ecompile_2erefcount_2eunboxParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eunboxParam_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eunboxParam(V v_ce_240, V v_lent_241, V v_x_242) {
top: ;
  V v_x3_243 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), heff_rfield(v_ce_240, 10)));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 15);
    heff_drop(v_x_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 0ULL, 1);
    V v_x2_245 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get_n(v_ce_240, 10, 15); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_rp_247;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nothing: {
      v_rp_247 = NTAG(TAG_RepV);
      break;
    }
    case TAG_Just: {
      V v_x_246 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 1);
      v_rp_247 = v_x_246;
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_v_248 = heff_tag_at_n(v_ru_24x3_243_24Just, TAG_RLocal, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2eunboxParam_str0), heff_dup(v_x_242))});
    V v_t_249;
    if ((heff_dup(v_lent_241) == NTAG(TAG_True))) {
      v_t_249 = heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_247, v_v_248});
    } else {
      v_t_249 = heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_247, v_v_248});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, v_t_249}), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2erefcount_2eunboxParam_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eunboxParam(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2etakeIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etakeIn_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2etakeIn(V v_ts_240, V v_live_241, V v_e_242, V v_l_243, V v_i_244) {
top: ;
  V v_t_2428;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SVar: {
    V v_x_245 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SVar = heff_take_reuse_n(v_e_242, 1ULL, 1);
    v_t_2428 = heff_tag_at_n(v_ru_24e_242_24SVar, TAG_Just, 1, (V[]){v_x_245});
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_e_242, 0ULL, 1);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SInt: {
    heff_take_n(v_e_242, 0ULL, 1);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat: {
    heff_take_na(v_e_242, 0ULL, 1);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SStr: {
    heff_take_n(v_e_242, 0ULL, 1);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SBytes: {
    heff_take_n(v_e_242, 0ULL, 1);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFixed: {
    heff_take_n(v_e_242, 0ULL, 2);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat32: {
    heff_take_na(v_e_242, 0ULL, 1);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrimFn: {
    heff_take_n(v_e_242, 0ULL, 1);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_e_242, 0ULL, 2);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_e_242, 0ULL, 3);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_e_242, 0ULL, 2);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_e_242, 0ULL, 4);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_e_242, 0ULL, 2);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_242);
  }
  switch (heff_tag_of(v_t_2428)) {
  case TAG_Nothing: {
    heff_drop(v_l_243);
    heff_drop(v_i_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x_2429 = heff_field(v_t_2428, 0);
    V v_ru_24t_2428_24Just = heff_take_reuse_n(v_t_2428, 1ULL, 1);
    V v_t_2430 = (g_heff_2ecompile_2erefcount_2eelemS(heff_dup(v_x_2429), v_live_241));
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop(v_t_2430);
      V v_t_2431 = (g_list_2eany_24s1681212806x1534785672(heff_dup(v_x_2429), v_l_243, v_ts_240));
      if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
        heff_drop(v_t_2431);
        return heff_tag_at_n(v_ru_24t_2428_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_RTakeField, 2, (V[]){v_x_2429, v_i_244})});
      } else {
        heff_drop(v_i_244);
        heff_drop(v_x_2429);
        heff_drop_cell(v_ru_24t_2428_24Just, 1);
        heff_drop(v_t_2431);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_l_243);
      heff_drop(v_i_244);
      heff_drop(v_x_2429);
      heff_drop_cell(v_ru_24t_2428_24Just, 1);
      heff_drop(v_t_2430);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_t_2428);
  }
}
V g_heff_2ecompile_2erefcount_2etakeIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2etakeIn(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2esameS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esameS_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2esameS(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_x_244, v_y_246, 0)) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2esameS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2esameS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2eunboxOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eunboxOf_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eunboxOf(V v_rp_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_RLocal: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RDup: {
    V v_x_243 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24RDup = heff_take_reuse_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, heff_tag_at_n(v_ru_24v_241_24RDup, TAG_RLocal, 1, (V[]){v_x_243})});
  }
  case TAG_RClo: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGet: {
    V v_g_245 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24RGet = heff_take_reuse_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, heff_tag_at_n(v_ru_24v_241_24RGet, TAG_RGetRaw, 1, (V[]){v_g_245})});
  }
  case TAG_RGetRaw: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RInt: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFloat: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RStr: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RBytes: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFixed: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RF32: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RNTag: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RTag: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RTagIn: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RRec: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RRecIn: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RField: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RDupE: {
    V v_e_2434 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, v_e_2434});
  }
  case TAG_RFieldV: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGetN: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFieldU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGetNU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RWord: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RTakeField: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGetLabel: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrimFn: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrim: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RLam: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RCall: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RApply: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RBool: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RAbandon: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RBox: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RUnbox: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPeek: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrimU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFixU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RF32U: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RF64U: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erefcount_2eunboxOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eunboxOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2esameAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esameAs_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2esameAs(V v_ce_240, V v_x2_241, V v_g_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 15);
    heff_drop(v_g_242);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_s_243 = heff_field(v_x2_241, 0);
    V v_a_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_s_243, 0)), heff_rfield(v_ce_240, 11)));
    V v_b_245 = ({ V a_0 = v_g_242; V b_1 = heff_get_n(v_ce_240, 11, 15); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_a_244)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_b_245)) {
      case TAG_Nothing: {
        return NTAG(TAG_True);
      }
      case TAG_Just: {
        heff_take_n(v_b_245, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_b_245);
      }
    }
    case TAG_Just: {
      V v_a1_247 = heff_field(v_a_244, 0);
      heff_take_n(v_a_244, 1ULL, 1);
      switch (heff_tag_of(v_b_245)) {
      case TAG_Nothing: {
        heff_drop_rec(v_a1_247, 2);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_b1_248 = heff_field(v_b_245, 0);
        heff_take_n(v_b_245, 1ULL, 1);
        V v_t_249 = (g_heff_2ecompile_2erepr_2ereprsEq(heff_rfield(v_a1_247, 0), heff_rfield(v_b1_248, 0)));
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_t_249);
          return ({ V b_0 = heff_get_n(v_a1_247, 1, 2); V b_1 = heff_get_n(v_b1_248, 1, 2); V r_ = (g_heff_2ecompile_2erepr_2ereprEq(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
        } else {
          heff_drop_rec(v_a1_247, 2);
          heff_drop_rec(v_b1_248, 2);
          heff_drop(v_t_249);
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_b_245);
      }
    }
    default: return heff_nomatch(v_a_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2esameAs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2esameAs(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2eapplyLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eapplyLast_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eapplyLast(V v_ce_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 15);
    heff_drop(v_n_241);
    V v_t_243 = heff_tag_n(TAG_CReturn, 1, (V[]){NTAG(TAG_RAbandon)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2412;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_n_241))) {
      if (heff_intLe_c(heff_dup(v_n_241), heff_dup(heff_rfield(v_ce_240, 3)))) {
        heff_drop_rec(v_ce_240, 15);
        heff_drop(v_n_241);
        v_t_2412 = heff_tag_n(TAG_CInPlace, 2, (V[]){v_f_244, v_vs_245});
      } else {
        if (heff_intLt_c(MK_INT(0LL), heff_get_n(v_ce_240, 3, 15))) {
          if (heff_intLe_c(v_n_241, MK_INT(4LL))) {
            v_t_2412 = heff_tag_n(TAG_CRoomed, 2, (V[]){v_f_244, v_vs_245});
          } else {
            v_t_2412 = heff_tag_n(TAG_CTail, 2, (V[]){v_f_244, v_vs_245});
          }
        } else {
          heff_drop(v_n_241);
          v_t_2412 = heff_tag_n(TAG_CTail, 2, (V[]){v_f_244, v_vs_245});
        }
      }
    } else {
      if (heff_intLt_c(MK_INT(0LL), heff_get_n(v_ce_240, 3, 15))) {
        if (heff_intLe_c(v_n_241, MK_INT(4LL))) {
          v_t_2412 = heff_tag_n(TAG_CRoomed, 2, (V[]){v_f_244, v_vs_245});
        } else {
          v_t_2412 = heff_tag_n(TAG_CTail, 2, (V[]){v_f_244, v_vs_245});
        }
      } else {
        heff_drop(v_n_241);
        v_t_2412 = heff_tag_n(TAG_CTail, 2, (V[]){v_f_244, v_vs_245});
      }
    }
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2eapplyLast_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eapplyLast(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2efieldMask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efieldMask_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2efieldMask(V v_used_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x3_242, 0);
    V v_vs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ecompile_2erefcount_2eelemS(heff_dup(v_v_243), v_used_240));
    V v_t_246;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      v_t_246 = (g_heff_2ecompile_2erefcount_2epow2(heff_dup(v_i_241)));
    } else {
      heff_drop(v_t_245);
      v_t_246 = MK_INT(0LL);
    }
    V v_t_247 = (g_heff_2ecompile_2erefcount_2efieldMask(v_used_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_vs_244));
    return heff_intAdd(v_t_246, v_t_247);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2efieldMask_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2efieldMask(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(V v_ru_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_SLet: {
      V v_x_245 = heff_field(v_x41_243, 0);
      V v_o_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24SLet = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2erefcount_2ereuseOp(heff_dup(v_ru_240), heff_dup(v_n_241), v_o_246));
      V v_x5_2410;
      switch (heff_tag_of(v_t_247)) {
      case TAG_MkPair: {
        V v_b_248 = heff_field(v_t_247, 0);
        V v_o2_249 = heff_field(v_t_247, 1);
        V v_ru_24t_247_24MkPair = heff_take_reuse_n(v_t_247, 3ULL, 2);
        v_x5_2410 = heff_tag_at_n(v_ru_24t_247_24MkPair, TAG_MkPair, 2, (V[]){v_b_248, heff_tag_at_n(v_ru_24x41_243_24SLet, TAG_SLet, 2, (V[]){v_x_245, v_o2_249})});
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      switch (heff_tag_of(v_x5_2410)) {
      case TAG_MkPair: {
        V v_x51_2411 = heff_field(v_x5_2410, 0);
        V v_st_2412 = heff_field(v_x5_2410, 1);
        V v_ru_24x5_2410_24MkPair = heff_take_reuse_n(v_x5_2410, 3ULL, 2);
        if ((heff_dup(v_x51_2411) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_x51_2411);
          return heff_tag_at_n(v_ru_24x5_2410_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_st_2412, v_rest_244})});
        } else {
          heff_drop(v_x51_2411);
          V v_x2_2413 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(v_ru_240, v_n_241, v_rest_244));
          switch (heff_tag_of(v_x2_2413)) {
          case TAG_MkPair: {
            V v_b_2414 = heff_field(v_x2_2413, 0);
            V v_ss_2415 = heff_field(v_x2_2413, 1);
            heff_take_n(v_x2_2413, 3ULL, 2);
            return heff_tag_at_n(v_ru_24x5_2410_24MkPair, TAG_MkPair, 2, (V[]){v_b_2414, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_st_2412, v_ss_2415})});
          }
          default: return heff_nomatch(v_x2_2413);
          }
        }
      }
      default: return heff_nomatch(v_x5_2410);
      }
    }
    case TAG_SDecl: {
      V v_x2_2417 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(v_ru_240, v_n_241, v_rest_244));
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_MkPair: {
        V v_b_2418 = heff_field(v_x2_2417, 0);
        V v_ss_2419 = heff_field(v_x2_2417, 1);
        V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_b_2418, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_x41_243, v_ss_2419})});
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
    case TAG_SSet: {
      V v_x_2420 = heff_field(v_x41_243, 0);
      V v_o_2421 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24SSet = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      V v_t_2422 = (g_heff_2ecompile_2erefcount_2ereuseOp(heff_dup(v_ru_240), heff_dup(v_n_241), v_o_2421));
      V v_x5_2425;
      switch (heff_tag_of(v_t_2422)) {
      case TAG_MkPair: {
        V v_b_2423 = heff_field(v_t_2422, 0);
        V v_o2_2424 = heff_field(v_t_2422, 1);
        V v_ru_24t_2422_24MkPair = heff_take_reuse_n(v_t_2422, 3ULL, 2);
        v_x5_2425 = heff_tag_at_n(v_ru_24t_2422_24MkPair, TAG_MkPair, 2, (V[]){v_b_2423, heff_tag_at_n(v_ru_24x41_243_24SSet, TAG_SSet, 2, (V[]){v_x_2420, v_o2_2424})});
        break;
      }
      default: heff_nomatch(v_t_2422);
      }
      switch (heff_tag_of(v_x5_2425)) {
      case TAG_MkPair: {
        V v_x51_2426 = heff_field(v_x5_2425, 0);
        V v_st_2427 = heff_field(v_x5_2425, 1);
        V v_ru_24x5_2425_24MkPair = heff_take_reuse_n(v_x5_2425, 3ULL, 2);
        if ((heff_dup(v_x51_2426) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_x51_2426);
          return heff_tag_at_n(v_ru_24x5_2425_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_st_2427, v_rest_244})});
        } else {
          heff_drop(v_x51_2426);
          V v_x2_2428 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(v_ru_240, v_n_241, v_rest_244));
          switch (heff_tag_of(v_x2_2428)) {
          case TAG_MkPair: {
            V v_b_2429 = heff_field(v_x2_2428, 0);
            V v_ss_2430 = heff_field(v_x2_2428, 1);
            heff_take_n(v_x2_2428, 3ULL, 2);
            return heff_tag_at_n(v_ru_24x5_2425_24MkPair, TAG_MkPair, 2, (V[]){v_b_2429, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_st_2427, v_ss_2430})});
          }
          default: return heff_nomatch(v_x2_2428);
          }
        }
      }
      default: return heff_nomatch(v_x5_2425);
      }
    }
    case TAG_SIf: {
      V v_c_2431 = heff_field(v_x41_243, 0);
      V v_ts_2432 = heff_field(v_x41_243, 1);
      V v_fs_2433 = heff_field(v_x41_243, 2);
      V v_ru_24x41_243_24SIf = heff_take_reuse_n(v_x41_243, 7ULL, 3);
      V v_t_2434 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(heff_dup(v_ru_240), heff_dup(v_n_241), v_ts_2432));
      V v_x5_2441;
      switch (heff_tag_of(v_t_2434)) {
      case TAG_MkPair: {
        V v_bt_2435 = heff_field(v_t_2434, 0);
        V v_ts2_2436 = heff_field(v_t_2434, 1);
        V v_ru_24t_2434_24MkPair = heff_take_reuse_n(v_t_2434, 3ULL, 2);
        V v_t_2437 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(heff_dup(v_ru_240), heff_dup(v_n_241), v_fs_2433));
        switch (heff_tag_of(v_t_2437)) {
        case TAG_MkPair: {
          V v_bf_2438 = heff_field(v_t_2437, 0);
          V v_fs2_2439 = heff_field(v_t_2437, 1);
          heff_take_n(v_t_2437, 3ULL, 2);
          V v_t_2440;
          if ((heff_dup(v_bt_2435) == NTAG(TAG_True))) {
            heff_drop(v_bt_2435);
            heff_drop(v_bf_2438);
            v_t_2440 = NTAG(TAG_True);
          } else {
            heff_drop(v_bt_2435);
            v_t_2440 = v_bf_2438;
          }
          v_x5_2441 = heff_tag_at_n(v_ru_24t_2434_24MkPair, TAG_MkPair, 2, (V[]){v_t_2440, heff_tag_at_n(v_ru_24x41_243_24SIf, TAG_SIf, 3, (V[]){v_c_2431, v_ts2_2436, v_fs2_2439})});
          break;
        }
        default: heff_nomatch(v_t_2437);
        }
        break;
      }
      default: heff_nomatch(v_t_2434);
      }
      switch (heff_tag_of(v_x5_2441)) {
      case TAG_MkPair: {
        V v_x51_2442 = heff_field(v_x5_2441, 0);
        V v_st_2443 = heff_field(v_x5_2441, 1);
        V v_ru_24x5_2441_24MkPair = heff_take_reuse_n(v_x5_2441, 3ULL, 2);
        if ((heff_dup(v_x51_2442) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_x51_2442);
          return heff_tag_at_n(v_ru_24x5_2441_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_st_2443, v_rest_244})});
        } else {
          heff_drop(v_x51_2442);
          V v_x2_2444 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(v_ru_240, v_n_241, v_rest_244));
          switch (heff_tag_of(v_x2_2444)) {
          case TAG_MkPair: {
            V v_b_2445 = heff_field(v_x2_2444, 0);
            V v_ss_2446 = heff_field(v_x2_2444, 1);
            heff_take_n(v_x2_2444, 3ULL, 2);
            return heff_tag_at_n(v_ru_24x5_2441_24MkPair, TAG_MkPair, 2, (V[]){v_b_2445, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_st_2443, v_ss_2446})});
          }
          default: return heff_nomatch(v_x2_2444);
          }
        }
      }
      default: return heff_nomatch(v_x5_2441);
      }
    }
    case TAG_SCase: {
      V v_v_2447 = heff_field(v_x41_243, 0);
      V v_arms_2448 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24SCase = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      V v_t_2449 = (g_heff_2ecompile_2erefcount_2estArms_24s1092032099x1214316481(heff_dup(v_ru_240), heff_dup(v_n_241), v_arms_2448));
      V v_x5_2452;
      switch (heff_tag_of(v_t_2449)) {
      case TAG_MkPair: {
        V v_b_2450 = heff_field(v_t_2449, 0);
        V v_as2_2451 = heff_field(v_t_2449, 1);
        V v_ru_24t_2449_24MkPair = heff_take_reuse_n(v_t_2449, 3ULL, 2);
        v_x5_2452 = heff_tag_at_n(v_ru_24t_2449_24MkPair, TAG_MkPair, 2, (V[]){v_b_2450, heff_tag_at_n(v_ru_24x41_243_24SCase, TAG_SCase, 2, (V[]){v_v_2447, v_as2_2451})});
        break;
      }
      default: heff_nomatch(v_t_2449);
      }
      switch (heff_tag_of(v_x5_2452)) {
      case TAG_MkPair: {
        V v_x51_2453 = heff_field(v_x5_2452, 0);
        V v_st_2454 = heff_field(v_x5_2452, 1);
        V v_ru_24x5_2452_24MkPair = heff_take_reuse_n(v_x5_2452, 3ULL, 2);
        if ((heff_dup(v_x51_2453) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_x51_2453);
          return heff_tag_at_n(v_ru_24x5_2452_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_st_2454, v_rest_244})});
        } else {
          heff_drop(v_x51_2453);
          V v_x2_2455 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(v_ru_240, v_n_241, v_rest_244));
          switch (heff_tag_of(v_x2_2455)) {
          case TAG_MkPair: {
            V v_b_2456 = heff_field(v_x2_2455, 0);
            V v_ss_2457 = heff_field(v_x2_2455, 1);
            heff_take_n(v_x2_2455, 3ULL, 2);
            return heff_tag_at_n(v_ru_24x5_2452_24MkPair, TAG_MkPair, 2, (V[]){v_b_2456, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_st_2454, v_ss_2457})});
          }
          default: return heff_nomatch(v_x2_2455);
          }
        }
      }
      default: return heff_nomatch(v_x5_2452);
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938(V v_ru_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_TSeq: {
    V v_ss_243 = heff_field(v_x4_242, 0);
    V v_t_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TSeq = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_it_245 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(heff_dup(v_ru_240), heff_dup(v_n_241), heff_dup(v_ss_243)));
    switch (heff_tag_of(v_it_245)) {
    case TAG_MkPair: {
      V v_it1_246 = heff_field(v_it_245, 0);
      V v_ss2_247 = heff_field(v_it_245, 1);
      V v_ru_24it_245_24MkPair = heff_take_reuse_n(v_it_245, 3ULL, 2);
      if ((heff_dup(v_it1_246) == NTAG(TAG_True))) {
        heff_drop(v_ru_240);
        heff_drop(v_n_241);
        heff_drop(v_ss_243);
        heff_drop(v_it1_246);
        return heff_tag_at_n(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_at_n(v_ru_24x4_242_24TSeq, TAG_TSeq, 2, (V[]){v_ss2_247, v_t_244})});
      } else {
        heff_drop(v_it1_246);
        heff_drop(v_ss2_247);
        V v_t_248 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938(v_ru_240, v_n_241, v_t_244));
        switch (heff_tag_of(v_t_248)) {
        case TAG_MkPair: {
          V v_b_249 = heff_field(v_t_248, 0);
          V v_t2_2410 = heff_field(v_t_248, 1);
          heff_take_n(v_t_248, 3ULL, 2);
          return heff_tag_at_n(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){v_b_249, heff_tag_at_n(v_ru_24x4_242_24TSeq, TAG_TSeq, 2, (V[]){v_ss_243, v_t2_2410})});
        }
        default: return heff_nomatch(v_t_248);
        }
      }
    }
    default: return heff_nomatch(v_it_245);
    }
  }
  case TAG_TReturn: {
    V v_o_2411 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24TReturn = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_t_2412 = (g_heff_2ecompile_2erefcount_2ereuseOp(v_ru_240, v_n_241, v_o_2411));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkPair: {
      V v_b_2413 = heff_field(v_t_2412, 0);
      V v_o2_2414 = heff_field(v_t_2412, 1);
      V v_ru_24t_2412_24MkPair = heff_take_reuse_n(v_t_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_2412_24MkPair, TAG_MkPair, 2, (V[]){v_b_2413, heff_tag_at_n(v_ru_24x4_242_24TReturn, TAG_TReturn, 1, (V[]){v_o2_2414})});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_TLoop: {
    V v_vs_2415 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24TLoop = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_t_2417 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_vs_2415; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_vs_2415); r_; });
    switch (heff_tag_of(v_t_2417)) {
    case TAG_MkPair: {
      V v_b_2418 = heff_field(v_t_2417, 0);
      V v_vs2_2419 = heff_field(v_t_2417, 1);
      V v_ru_24t_2417_24MkPair = heff_take_reuse_n(v_t_2417, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_2417_24MkPair, TAG_MkPair, 2, (V[]){v_b_2418, heff_tag_at_n(v_ru_24x4_242_24TLoop, TAG_TLoop, 1, (V[]){v_vs2_2419})});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  case TAG_TIf: {
    V v_c_2420 = heff_field(v_x4_242, 0);
    V v_t_2421 = heff_field(v_x4_242, 1);
    V v_e_2422 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24TIf = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2423 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938(heff_dup(v_ru_240), heff_dup(v_n_241), v_t_2421));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_MkPair: {
      V v_bt_2424 = heff_field(v_t_2423, 0);
      V v_t2_2425 = heff_field(v_t_2423, 1);
      V v_ru_24t_2423_24MkPair = heff_take_reuse_n(v_t_2423, 3ULL, 2);
      V v_t_2426 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938(v_ru_240, v_n_241, v_e_2422));
      switch (heff_tag_of(v_t_2426)) {
      case TAG_MkPair: {
        V v_be_2427 = heff_field(v_t_2426, 0);
        V v_e2_2428 = heff_field(v_t_2426, 1);
        heff_take_n(v_t_2426, 3ULL, 2);
        V v_t_2429;
        if ((heff_dup(v_bt_2424) == NTAG(TAG_True))) {
          heff_drop(v_bt_2424);
          heff_drop(v_be_2427);
          v_t_2429 = NTAG(TAG_True);
        } else {
          heff_drop(v_bt_2424);
          v_t_2429 = v_be_2427;
        }
        return heff_tag_at_n(v_ru_24t_2423_24MkPair, TAG_MkPair, 2, (V[]){v_t_2429, heff_tag_at_n(v_ru_24x4_242_24TIf, TAG_TIf, 3, (V[]){v_c_2420, v_t2_2425, v_e2_2428})});
      }
      default: return heff_nomatch(v_t_2426);
      }
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  case TAG_TCase: {
    V v_v_2430 = heff_field(v_x4_242, 0);
    V v_arms_2431 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TCase = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2432 = (g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868(v_ru_240, v_n_241, v_arms_2431));
    switch (heff_tag_of(v_t_2432)) {
    case TAG_MkPair: {
      V v_b_2433 = heff_field(v_t_2432, 0);
      V v_as2_2434 = heff_field(v_t_2432, 1);
      V v_ru_24t_2432_24MkPair = heff_take_reuse_n(v_t_2432, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_2432_24MkPair, TAG_MkPair, 2, (V[]){v_b_2433, heff_tag_at_n(v_ru_24x4_242_24TCase, TAG_TCase, 2, (V[]){v_v_2430, v_as2_2434})});
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_lam0(V self, V *args) {
  V v_v_2416 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_2416));
}
V g_heff_2ecompile_2erefcount_2eboolDone_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eboolDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eboolDone_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eboolDone(V v_ce_240, V v_o_241) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OSimple: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nil);
  }
  case TAG_OCall: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nil);
  }
  case TAG_OApply: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nil);
  }
  case TAG_OPrim: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nil);
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nil);
  }
  case TAG_OBool: {
    V v_xs_2412 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2eboolDone_lam0, 1, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(heff_rfield(v_ce_240, 4))));
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2edropsOf(v_ce_240, v_xs_2412));
    return (g_list_2emap_24s1796125103x644876049(v_t_2413));
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2erefcount_2eboolDone_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eboolDone(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2eboolDone_lam0(V self, V *args) {
  V v_v_2410 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = ({ V a_0 = v_v_2410; V b_1 = heff_get_n(v_ce_240, 5, 15); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
  heff_drop(v_x1_2411);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2erefcount_2ecallAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecallAs_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2ecallAs(V v_ce_240, V v_g_241, V v_as_242, V v_loop_243, V v_ls_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_ce_240, 2));
  V v_t_2411;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_s_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_s_246, 0)), heff_dup(v_g_241))) {
      V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_s_246, 1, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_242));
      if (heff_intEq_c(v_t_248, v_t_249)) {
        v_t_2411 = (g_list_2eall_24s1793250635x935291087(v_loop_243));
      } else {
        v_t_2411 = NTAG(TAG_False);
      }
    } else {
      heff_drop_rec(v_s_246, 2);
      v_t_2411 = NTAG(TAG_False);
    }
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_g_241);
    heff_drop(v_ls_244);
    heff_drop(v_t_2411);
    V v_vs_2412 = (g_list_2emap_24s976303750x321235480(v_loop_243));
    V v_t_2413 = heff_get_n(v_ce_240, 2, 15);
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      heff_drop(v_vs_2412);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      V v_s_2414 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 1);
      V v_t_2415 = heff_tag_n(TAG_CLoop, 2, (V[]){heff_get_n(v_s_2414, 1, 2), v_vs_2412});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_2413);
    }
  } else {
    heff_drop(v_loop_243);
    heff_drop(v_t_2411);
    V v_t_2416 = (g_heff_2ecompile_2erefcount_2eagrees(heff_dup(v_ce_240), heff_dup(v_g_241), v_as_242));
    V v_t_2417;
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_t_2416);
      v_t_2417 = (g_list_2eall_24s1793250635x935291087(v_ls_244));
    } else {
      heff_drop(v_t_2416);
      v_t_2417 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_t_2417);
      V v_x3_2418 = ({ V a_0 = heff_dup(v_g_241); V b_1 = heff_get_n(v_ce_240, 11, 15); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2420;
      switch (heff_tag_of(v_x3_2418)) {
      case TAG_Nothing: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_2418, 0ULL, 1);
        v_t_2420 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_2418);
      }
      V v_t_2421 = (g_list_2emap_24s976303750x321235480(v_ls_244));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CJump, 3, (V[]){v_g_241, v_t_2420, v_t_2421}), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_t_2417);
      V v_x1_2422 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_241), heff_rfield(v_ce_240, 11)));
      V v_t_2424;
      switch (heff_tag_of(v_x1_2422)) {
      case TAG_Nothing: {
        v_t_2424 = NTAG(TAG_RepV);
        break;
      }
      case TAG_Just: {
        V v_s_2423 = heff_field(v_x1_2422, 0);
        heff_take_n(v_x1_2422, 1ULL, 1);
        v_t_2424 = heff_get_n(v_s_2423, 1, 2);
        break;
      }
      default: heff_nomatch(v_x1_2422);
      }
      V v_x3_2425 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_241), heff_rfield(v_ce_240, 11)));
      V v_t_2427;
      switch (heff_tag_of(v_x3_2425)) {
      case TAG_Nothing: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2426 = heff_field(v_x3_2425, 0);
        V v_ru_24x3_2425_24Just = heff_take_reuse_n(v_x3_2425, 1ULL, 1);
        v_t_2427 = heff_tag_at_n(v_ru_24x3_2425_24Just, TAG_Just, 1, (V[]){heff_get_n(v_x_2426, 1, 2)});
        break;
      }
      default: heff_nomatch(v_x3_2425);
      }
      V v_t_2428 = heff_tag_n(TAG_RCall, 4, (V[]){v_g_241, NTAG(TAG_False), v_t_2427, v_ls_244});
      V v_t_2429 = (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2424, heff_get_n(v_ce_240, 14, 15), v_t_2428));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_2429}), NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2ecompile_2erefcount_2ecallAs_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2ecallAs(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(V v_ce_240, V v_xs_241, V v_t_242, V v_fv_243) {
top: ;
  V v_owned_244 = (g_prelude_2e_2b_2b(heff_dup(v_xs_241), v_fv_243));
  V v_wanted_245 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_242)));
  V v_xs_247 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam0, 1, 1, (V[]){v_wanted_245}), v_owned_244));
  V v_t_2411 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam1, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_247));
  V v_n_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
  V v_t_2413 = ({ V rv_2 = NTAG(TAG_Nothing); V rv_3 = v_n_2412; V rv_9 = NTAG(TAG_Nil); V rv_14 = NTAG(TAG_RepV); V rr_ = heff_rec_reuse_nf(v_ce_240, 15859ULL, 15, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__ret, 267648783u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 9) = rv_9; heff_rfield(rr_, 14) = rv_14; rr_; });
  V v_t_2414 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(NTAG(TAG_Nil), v_t_2413));
  V v_ce_2415 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2411, NTAG(TAG_Nil), v_t_2414));
  return (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2415, v_t_242));
}
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_wanted_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_246; V a_1 = v_wanted_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wanted_245); r_; });
}
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_249 = ({ V a_0 = v_x_248; V b_1 = heff_get_n(v_ce_240, 10, 15); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nothing: {
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    heff_take_n(v_x3_249, 0ULL, 1);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_249);
  }
}
Clo g_heff_2ecompile_2erefcount_2efieldNum_24s4728276x1588665507_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efieldNum_24s4728276x1588665507_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2efieldNum_24s4728276x1588665507(V v_ce_240, V v_live_241, V v_e_242, V v_rp_243, V v_i_244, V v_n_245, V v_x8_246, V v_g_247) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_g_247)) {
    case TAG_Nothing: {
      V v_t_248 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, NTAG(TAG_RepV), v_e_242));
      return heff_tag_n(TAG_RGetNU, 4, (V[]){v_rp_243, v_t_248, v_i_244, v_n_245});
    }
    case TAG_Just: {
      V v_g1_249 = heff_field(v_g_247, 0);
      V v_ru_24g_247_24Just = heff_take_reuse_n(v_g_247, 1ULL, 1);
      heff_drop_rec(v_ce_240, 15);
      heff_drop(v_live_241);
      heff_drop(v_e_242);
      heff_drop(v_n_245);
      return heff_tag_n(TAG_RFieldU, 3, (V[]){v_rp_243, heff_tag_at_n(v_ru_24g_247_24Just, TAG_RGetRaw, 1, (V[]){v_g1_249}), v_i_244});
    }
    default: return heff_nomatch(v_g_247);
    }
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_x8_246, 0);
    V v_ru_24x8_246_24Just = heff_take_reuse_n(v_x8_246, 1ULL, 1);
    heff_drop(v_e_242);
    heff_drop(v_g_247);
    V v_t_2411 = ({ V a_0 = heff_dup(v_x_2410); V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop_rec(v_ce_240, 15);
      heff_drop(v_n_245);
      heff_drop(v_t_2411);
      return heff_tag_n(TAG_RFieldU, 3, (V[]){v_rp_243, heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2410}), v_i_244});
    } else {
      heff_drop(v_t_2411);
      V v_t_2412 = ({ V a_0 = heff_dup(v_x_2410); V b_1 = heff_get_n(v_ce_240, 6, 15); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_n_245);
        heff_drop(v_t_2412);
        return heff_tag_n(TAG_RFieldU, 3, (V[]){v_rp_243, heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2410}), v_i_244});
      } else {
        heff_drop(v_t_2412);
        return heff_tag_n(TAG_RGetNU, 4, (V[]){v_rp_243, heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2410}), v_i_244, v_n_245});
      }
    }
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erefcount_2efieldNum_24s4728276x1588665507_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efieldNum_24s4728276x1588665507(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2ecompile_2erefcount_2eprojAs_24s1034245672x791498949_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eprojAs_24s1034245672x791498949_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2eprojAs_24s1034245672x791498949(V v_ce_240, V v_live_241, V v_want_242, V v_v_243, V v_e_244, V v_n_245, V v_x8_246, V v_rp_247) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    heff_drop(v_e_244);
    heff_drop(v_n_245);
    heff_drop(v_rp_247);
    V v_t_248 = (g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_248));
  }
  case TAG_Just: {
    V v_i_249 = heff_field(v_x8_246, 0);
    V v_ru_24x8_246_24Just = heff_take_reuse_n(v_x8_246, 1ULL, 1);
    V v_t_2413;
    switch (heff_tag_of(v_rp_247)) {
    case TAG_RepV: {
      v_t_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2413 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      break;
    }
    case TAG_RepF64: {
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2413 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      break;
    }
    default: heff_nomatch(v_rp_247);
    }
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_e_244);
      heff_drop(v_n_245);
      heff_drop(v_rp_247);
      heff_drop(v_i_249);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_t_2413);
      V v_t_2414 = (g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(v_ce_240, v_live_241, v_v_243));
      return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2414));
    } else {
      heff_drop(v_v_243);
      heff_drop(v_t_2413);
      V v_t_2438;
      switch (heff_tag_of(v_e_244)) {
      case TAG_SVar: {
        V v_x_2415 = heff_dup(heff_field(v_e_244, 0));
        v_t_2438 = heff_tag_at_n(v_ru_24x8_246_24Just, TAG_Just, 1, (V[]){v_x_2415});
        break;
      }
      case TAG_SGlobal: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_244);
      }
      V v_t_2462;
      switch (heff_tag_of(v_e_244)) {
      case TAG_SVar: {
        v_t_2462 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SGlobal: {
        V v_g_2440 = heff_dup(heff_field(v_e_244, 0));
        v_t_2462 = heff_tag_n(TAG_Just, 1, (V[]){v_g_2440});
        break;
      }
      case TAG_SInt: {
        v_t_2462 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_t_2462 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_t_2462 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_t_2462 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_t_2462 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_t_2462 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2462 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_t_2462 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_t_2462 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_t_2462 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_t_2462 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_t_2462 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_244);
      }
      V v_t_2463 = (g_heff_2ecompile_2erefcount_2efieldNum_24s4728276x1588665507(v_ce_240, v_live_241, v_e_244, heff_dup(v_rp_247), v_i_249, v_n_245, v_t_2438, v_t_2462));
      return (g_heff_2ecompile_2erefcount_2ecoerce(v_rp_247, v_want_242, v_t_2463));
    }
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erefcount_2eprojAs_24s1034245672x791498949_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eprojAs_24s1034245672x791498949(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153(V v_ce_240, V v_lent_241, V v_live_242, V v_bi_243, V v_i_244, V v_e_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    V v_t_2432;
    switch (heff_tag_of(v_e_245)) {
    case TAG_SVar: {
      V v_x_247 = heff_dup(heff_field(v_e_245, 0));
      V v_x3_248 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_247), heff_rfield(v_ce_240, 10)));
      switch (heff_tag_of(v_x3_248)) {
      case TAG_Nothing: {
        v_t_2432 = heff_tag_n(TAG_Just, 1, (V[]){v_x_247});
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_248, 0ULL, 1);
        heff_drop(v_x_247);
        v_t_2432 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x3_248);
      }
      break;
    }
    case TAG_SGlobal: {
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SInt: {
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat: {
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SStr: {
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SBytes: {
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFixed: {
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat32: {
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrimFn: {
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrim: {
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_245);
    }
    HEFF_LAST return g_heff_2ecompile_2erefcount_2elentVarOr_24s1954346914x231669330(v_ce_240, v_lent_241, v_live_242, v_bi_243, v_i_244, v_e_245, v_t_2432);
  }
  case TAG_Just: {
    V v_a_2433 = heff_field(v_x8_246, 0);
    V v_ru_24x8_246_24Just = heff_take_reuse_n(v_x8_246, 1ULL, 1);
    heff_drop_rec(v_ce_240, 15);
    heff_drop(v_live_242);
    heff_drop(v_i_244);
    heff_drop(v_e_245);
    return heff_tag_at_n(v_ru_24x8_246_24Just, TAG_Given, 1, (V[]){v_a_2433});
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153(a[0], a1, a[2], a3, a[4], a[5], a[6]); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_e_245, V v_es_246) {
top: ;
  V v_t_247 = (g_heff_2ecompile_2erefcount_2elentIn(heff_dup(v_ce_240), v_bi_243, heff_intAdd(heff_dup(v_i_244), MK_INT(1LL)), heff_dup(v_es_246)));
  V v_lent_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_live_241)));
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_246));
  V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, heff_dup(v_live_241)));
  V v_live_2412 = (g_prelude_2e_2b_2b(v_before_242, v_t_2411));
  V v_t_2413 = (g_heff_2ecompile_2erefcount_2eelemI(heff_dup(v_i_244), v_bi_243));
  V v_t_2414;
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_t_2413);
    v_t_2414 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_live_241; V a_2 = v_e_245; V r_ = (g_heff_2ecompile_2erefcount_2elentField(a_0, a_1, a_2)); heff_drop(v_live_241); r_; });
  } else {
    heff_drop(v_live_241);
    heff_drop(v_t_2413);
    v_t_2414 = NTAG(TAG_Nothing);
  }
  return ({ V a_0 = v_ce_240; V a_1 = v_lent_248; V a_2 = v_live_2412; V a_3 = v_bi_243; V a_4 = v_i_244; V a_5 = v_e_245; V a_6 = v_t_2414; V r_ = (g_heff_2ecompile_2erefcount_2elentOr_24s175848436x1417992153(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_lent_248); r_; });
}
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_rp_247 = heff_field(v_x7_245, 0);
    V v_rps_248 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_i_244);
      heff_drop(v_rp_247);
      heff_drop(v_rps_248);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_249 = heff_field(v_x8_246, 0);
      V v_es_2410 = heff_field(v_x8_246, 1);
      heff_take_n(v_x8_246, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), v_bi_243, heff_dup(v_i_244), v_rp_247, heff_dup(v_e_249), heff_dup(v_es_2410)));
      V v_cell_2412 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_t_2413 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = heff_dup(v_i_244); V a_3 = v_e_249; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_249); r_; });
      V v_u_2414 = (g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(v_ce_240, v_live_241, v_t_2413, v_bi_243, heff_intAdd(v_i_244, MK_INT(1LL)), v_rps_248, v_es_2410, heff_dup(v_cell_2412)));
      heff_drop(v_u_2414);
      return v_cell_2412;
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(V v_ce_240, V v_live_241, V v_want_242, V v_o_243) {
top: ;
  switch (heff_tag_of(v_o_243)) {
  case TAG_OSimple: {
    V v_v_244 = heff_field(v_o_243, 0);
    heff_take_n(v_o_243, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, v_want_242, v_v_244);
  }
  case TAG_OCall: {
    V v_g_245 = heff_field(v_o_243, 0);
    V v_as_246 = heff_field(v_o_243, 1);
    V v_ru_24o_243_24OCall = heff_take_reuse_n(v_o_243, 3ULL, 2);
    V v_x1_247 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_245), heff_rfield(v_ce_240, 11)));
    V v_t_249;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nothing: {
      v_t_249 = NTAG(TAG_RepV);
      break;
    }
    case TAG_Just: {
      V v_s_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      v_t_249 = heff_get_n(v_s_248, 1, 2);
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    V v_t_2410 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, heff_tag_at_n(v_ru_24o_243_24OCall, TAG_OCall, 2, (V[]){v_g_245, v_as_246})));
    return (g_heff_2ecompile_2erefcount_2ecoerce(v_t_249, v_want_242, v_t_2410));
  }
  case TAG_OApply: {
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2413));
  }
  case TAG_OPrim: {
    V v_t_2416 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2416));
  }
  case TAG_OAbandon: {
    V v_t_2417 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2417));
  }
  case TAG_OBool: {
    V v_t_2419 = (g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2419));
  }
  default: return heff_nomatch(v_o_243);
  }
}
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(V v_ce_240, V v_b_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_b_241)) {
  case TAG_ATail: {
    V v_t_242 = heff_field(v_b_241, 0);
    v_t_244 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_242)));
    break;
  }
  case TAG_ASts: {
    V v_ss_243 = heff_field(v_b_241, 0);
    v_t_244 = (g_heff_2ecompile_2erefcount_2efvSts(heff_dup(v_ss_243)));
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_wanted_245 = (g_prelude_2e_2b_2b(v_t_244, heff_dup(heff_rfield(v_ce_240, 5))));
  V v_xs_248 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam0, 1, 1, (V[]){v_wanted_245}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_249 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_248));
  V v_t_2410 = (g_list_2emap_24s1796125103x644876049(v_t_249));
  V v_t_2413;
  switch (heff_tag_of(v_b_241)) {
  case TAG_ATail: {
    V v_t_2411 = heff_field(v_b_241, 0);
    v_t_2413 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_2411)));
    break;
  }
  case TAG_ASts: {
    V v_ss_2412 = heff_field(v_b_241, 0);
    v_t_2413 = (g_heff_2ecompile_2erefcount_2efvSts(heff_dup(v_ss_2412)));
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_wanted_2414 = (g_prelude_2e_2b_2b(v_t_2413, heff_dup(heff_rfield(v_ce_240, 5))));
  V v_t_2416 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam1, 1, 1, (V[]){v_wanted_2414}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_ce_2417 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2416, heff_dup(heff_rfield(v_ce_240, 5)), v_ce_240));
  V v_t_2420;
  switch (heff_tag_of(v_b_241)) {
  case TAG_ATail: {
    V v_t_2418 = heff_field(v_b_241, 0);
    v_t_2420 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2417, heff_dup(v_t_2418)));
    break;
  }
  case TAG_ASts: {
    V v_ss_2419 = heff_field(v_b_241, 0);
    v_t_2420 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2417, heff_dup(v_ss_2419), NTAG(TAG_Nothing)));
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_2410, v_t_2420);
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_wanted_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_247 = ({ V a_0 = v_v_246; V a_1 = v_wanted_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wanted_245); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
  heff_drop(v_x1_247);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdArm_24s1670601808x835334478_lam1(V self, V *args) {
  V v_v_2415 = args[0];
  V v_wanted_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2415; V a_1 = v_wanted_2414; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wanted_2414); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam4(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam5(V self, V *args);
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam6(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry, 9, 0};

V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(V v_ce_240, V v_taken_241, V v_lent_242, V v_t_243, V v_vs_244, V v_fb_245, V v_leaves_246, V v_rd_247, V v_x10_248) {
top: ;
  switch (heff_tag_of(v_x10_248)) {
  case TAG_MkPair: {
    V v_ru_249 = heff_field(v_x10_248, 0);
    V v_b2_2410 = heff_field(v_x10_248, 1);
    V v_ru_24x10_248_24MkPair = heff_take_reuse_n(v_x10_248, 3ULL, 2);
    V v_t_2412;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2412 = NTAG(TAG_True);
    } else {
      switch (heff_tag_of(v_taken_241)) {
      case TAG_Nothing: {
        v_t_2412 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        v_t_2412 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_taken_241);
      }
    }
    V v_ys_2413 = heff_take_field(v_rd_247, 2);
    V v_t_2418;
    switch (heff_tag_of(v_ys_2413)) {
    case TAG_Nil: {
      v_t_2418 = heff_dup(v_fb_245);
      break;
    }
    case TAG_Cons: {
      v_t_2418 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam0, 1, 1, (V[]){v_ys_2413}), heff_dup(v_fb_245)));
      break;
    }
    default: heff_nomatch(v_ys_2413);
    }
    V v_t_2419 = ({ V a_0 = heff_rfield(v_rd_247, 4); V a_1 = heff_rfield(v_rd_247, 5); V a_2 = v_ru_249; V a_3 = v_taken_241; V a_4 = v_vs_244; V a_5 = v_t_2418; V r_ = (g_heff_2ecompile_2erefcount_2etakeOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2418); r_; });
    V v_t_2421;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2421 = heff_dup(heff_rfield(v_rd_247, 3));
    } else {
      v_t_2421 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam1, 1, 1, (V[]){heff_dup(v_fb_245)}), heff_dup(v_vs_244)));
    }
    V v_owned_2422 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), v_t_2421));
    V v_wanted_2423 = (g_prelude_2e_2b_2b(heff_dup(v_fb_245), heff_dup(heff_rfield(v_ce_240, 5))));
    V v_t_2426 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam2, 1, 1, (V[]){v_wanted_2423}), v_owned_2422));
    V v_xs_2431 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam3, 1, 1, (V[]){heff_dup(v_taken_241)}), v_t_2426));
    V v_t_2432 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2431));
    V v_t_2433 = (g_list_2emap_24s1796125103x644876049(v_t_2432));
    V v_t_2435;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2435 = heff_dup(heff_rfield(v_rd_247, 3));
    } else {
      v_t_2435 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam4, 1, 1, (V[]){heff_dup(v_fb_245)}), heff_dup(v_vs_244)));
    }
    V v_t_2437;
    switch (heff_tag_of(v_ru_249)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x10_248_24MkPair, 2);
      v_t_2437 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2436 = heff_dup(heff_field(v_ru_249, 0));
      v_t_2437 = heff_tag_at_n(v_ru_24x10_248_24MkPair, TAG_Cons, 2, (V[]){v_x_2436, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_249);
    }
    V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2435, v_t_2437));
    V v_owned_2439 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), v_t_2438));
    V v_t_2441;
    switch (heff_tag_of(v_ru_249)) {
    case TAG_Nothing: {
      v_t_2441 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2440 = heff_dup(heff_field(v_ru_249, 0));
      v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2440, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_249);
    }
    V v_wanted_2442 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_240, 5)), v_fb_245, v_t_2441));
    V v_t_2444 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam5, 1, 1, (V[]){v_wanted_2442}), v_owned_2439));
    V v_t_2451;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      V v_ys_2445 = heff_dup(heff_rfield(v_rd_247, 3));
      V v_t_2450;
      switch (heff_tag_of(v_ys_2445)) {
      case TAG_Nil: {
        v_t_2450 = heff_dup(v_vs_244);
        break;
      }
      case TAG_Cons: {
        v_t_2450 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam6, 1, 1, (V[]){v_ys_2445}), heff_dup(v_vs_244)));
        break;
      }
      default: heff_nomatch(v_ys_2445);
      }
      v_t_2451 = (g_prelude_2e_2b_2b(v_t_2450, heff_dup(heff_rfield(v_ce_240, 6))));
    } else {
      v_t_2451 = heff_dup(heff_rfield(v_ce_240, 6));
    }
    V v_n_2452 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_244; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_vs_244); r_; });
    V v_t_2454;
    switch (heff_tag_of(v_ru_249)) {
    case TAG_Nothing: {
      heff_drop(v_n_2452);
      v_t_2454 = heff_dup(v_ce_240);
      break;
    }
    case TAG_Just: {
      V v_ru_2453 = heff_field(v_ru_249, 0);
      V v_ru_24ru_249_24Just = heff_take_reuse_n(v_ru_249, 1ULL, 1);
      v_t_2454 = (g_heff_2ecompile_2erefcount_2ewithKnown(v_ru_2453, heff_tag_at_n(v_ru_24ru_249_24Just, TAG_KnownCell, 1, (V[]){v_n_2452}), heff_dup(v_ce_240)));
      break;
    }
    default: heff_nomatch(v_ru_249);
    }
    V v_t_2455 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2451, v_t_2454));
    V v_ce_2456 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2444, heff_get_n(v_ce_240, 5, 15), v_t_2455));
    V v_t_2459;
    switch (heff_tag_of(v_b2_2410)) {
    case TAG_ATail: {
      V v_t_2457 = heff_field(v_b2_2410, 0);
      heff_take_n(v_b2_2410, 1ULL, 1);
      v_t_2459 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2456, v_t_2457));
      break;
    }
    case TAG_ASts: {
      V v_ss_2458 = heff_field(v_b2_2410, 0);
      heff_take_n(v_b2_2410, 1ULL, 1);
      v_t_2459 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2456, v_ss_2458, NTAG(TAG_Nothing)));
      break;
    }
    default: heff_nomatch(v_b2_2410);
    }
    V v_t_2460 = (g_prelude_2e_2b_2b(v_t_2433, v_t_2459));
    return heff_tag_n(TAG_MkCArm, 8, (V[]){v_t_243, heff_dup(heff_rfield(v_rd_247, 0)), heff_dup(heff_rfield(v_rd_247, 1)), heff_get_n(v_rd_247, 5, 6), v_t_2412, v_t_2419, v_t_2460, v_leaves_246});
  }
  default: return heff_nomatch(v_x10_248);
  }
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(a[0], a1, a2, a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam0(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ys_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2417 = ({ V a_0 = v_x_2416; V a_1 = v_ys_2413; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop_tag(v_ys_2413, 2); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2417) == NTAG(TAG_True)));
  heff_drop(v_x1_2417);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam1(V self, V *args) {
  V v_v_2420 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2420; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_fb_245); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam2(V self, V *args) {
  V v_v_2424 = args[0];
  V v_wanted_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2425 = ({ V a_0 = v_v_2424; V a_1 = v_wanted_2423; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wanted_2423); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2425) == NTAG(TAG_True)));
  heff_drop(v_x1_2425);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam3(V self, V *args) {
  V v_v_2427 = args[0];
  V v_taken_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429;
  switch (heff_tag_of(v_taken_241)) {
  case TAG_Nothing: {
    v_t_2429 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2428 = heff_field(v_taken_241, 0);
    heff_take_n(v_taken_241, 1ULL, 1);
    v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2428, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_taken_241);
  }
  V v_x1_2430 = ({ V a_0 = v_v_2427; V a_1 = v_t_2429; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_t_2429); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2430) == NTAG(TAG_True)));
  heff_drop(v_x1_2430);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam4(V self, V *args) {
  V v_v_2434 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2434; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_fb_245); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam5(V self, V *args) {
  V v_v_2443 = args[0];
  V v_wanted_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2443; V a_1 = v_wanted_2442; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wanted_2442); r_; });
}
V g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362_lam6(V self, V *args) {
  V v_x_2448 = args[0];
  V v_ys_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2449 = ({ V a_0 = v_x_2448; V a_1 = v_ys_2445; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop_tag(v_ys_2445, 2); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2449) == NTAG(TAG_True)));
  heff_drop(v_x1_2449);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(V v_ce_240, V v_taken_241, V v_lent_242, V v_t_243, V v_vs_244, V v_fb_245, V v_leaves_246, V v_p_247) {
top: ;
  V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
  V v_t_249 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_248, MK_INT(1LL))));
  V v_t_2410 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_vs_244), v_t_249));
  V v_ws_2415 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam0, 1, 1, (V[]){heff_dup(v_fb_245)}), v_t_2410));
  V v_x2_2416 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_t_243), heff_rfield(v_ce_240, 13)));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    heff_take_n(v_x2_2416, 1ULL, 1);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  V v_t_2419 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_t_243), heff_rfield(v_ce_240, 12)));
  V v_t_2420 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_t_2418; V a_2 = v_ws_2415; V a_3 = v_t_2419; V r_ = (g_heff_2ecompile_2erefcount_2ereadsWith(a_0, a_1, a_2, a_3)); heff_drop(v_t_2419); r_; });
  return (g_heff_2ecompile_2erefcount_2earmRead_24s1428581620x1272513362(v_ce_240, v_taken_241, v_lent_242, v_t_243, v_vs_244, v_fb_245, v_leaves_246, v_t_2420, v_p_247));
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(a[0], a1, a2, a[3], a[4], a[5], a[6], a[7]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_lam0(V self, V *args) {
  V v_p_2411 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414;
  switch (heff_tag_of(v_p_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_p_2411, 0);
    heff_take_n(v_p_2411, 1ULL, 2);
    v_t_2414 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_p_2411);
  }
  return ({ V a_0 = v_t_2414; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_fb_245); r_; });
}
Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 15);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_p_248 = heff_field(v_x7_245, 0);
    V v_ps_249 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 15);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_i_244);
      heff_drop(v_p_248);
      heff_drop(v_ps_249);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_e_2410 = heff_field(v_x8_246, 0);
      V v_es_2411 = heff_field(v_x8_246, 1);
      heff_take_n(v_x8_246, 3ULL, 2);
      V v_x3_2412 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_p_248), heff_rfield(v_ce_240, 10)));
      V v_t_2414;
      switch (heff_tag_of(v_x3_2412)) {
      case TAG_Nothing: {
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_2412, 0ULL, 1);
        v_t_2414 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_2412);
      }
      V v_t_2423;
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_2411)));
        V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_2415); r_; });
        V v_t_2417 = (g_prelude_2e_2b_2b(v_t_2416, heff_dup(v_live_241)));
        V v_live_2418 = (g_prelude_2e_2b_2b(heff_dup(v_before_242), v_t_2417));
        V v_x2_2419 = (g_map_2elookup_24s1546226666x2146984184(v_p_248, heff_rfield(v_ce_240, 10)));
        V v_t_2421;
        switch (heff_tag_of(v_x2_2419)) {
        case TAG_Nothing: {
          v_t_2421 = NTAG(TAG_RepV);
          break;
        }
        case TAG_Just: {
          V v_x_2420 = heff_field(v_x2_2419, 0);
          heff_take_n(v_x2_2419, 1ULL, 1);
          v_t_2421 = v_x_2420;
          break;
        }
        default: heff_nomatch(v_x2_2419);
        }
        V v_t_2422 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2418, v_t_2421, heff_dup(v_e_2410)));
        v_t_2423 = heff_tag_n(TAG_Given, 1, (V[]){v_t_2422});
      } else {
        heff_drop(v_p_248);
        heff_drop(v_t_2414);
        v_t_2423 = (g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), v_bi_243, heff_dup(v_i_244), heff_dup(v_e_2410), heff_dup(v_es_2411)));
      }
      V v_cell_2424 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
      V v_u_2425 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2424));
      heff_drop(v_u_2425);
      V v_t_2426 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = heff_dup(v_i_244); V a_3 = v_e_2410; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_2410); r_; });
      V t_0 = v_ce_240;
      V t_1 = v_live_241;
      V t_2 = v_t_2426;
      V t_3 = v_bi_243;
      V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
      V t_5 = v_ps_249;
      V t_6 = v_es_2411;
      V t_7 = v_cell_2424;
      v_ce_240 = t_0;
      v_live_241 = t_1;
      v_before_242 = t_2;
      v_bi_243 = t_3;
      v_i_244 = t_4;
      v_x7_245 = t_5;
      v_x8_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V v_ce_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_TSeq: {
    V v_ss_242 = heff_field(v_x3_241, 0);
    V v_t_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 2);
    return (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_240, v_ss_242, heff_tag_n(TAG_Just, 1, (V[]){v_t_243})));
  }
  case TAG_TReturn: {
    V v_x31_244 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24TReturn = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_OSimple: {
      V v_t_246 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_get_n(v_ce_240, 14, 15), v_x31_244));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_241_24TReturn, TAG_CReturn, 1, (V[]){v_t_246}), NTAG(TAG_Nil)});
    }
    case TAG_OCall: {
      V v_g_247 = heff_field(v_x31_244, 0);
      V v_as_248 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24TReturn, 1);
      return (g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(v_ce_240, v_g_247, v_as_248));
    }
    case TAG_OApply: {
      V v_f_249 = heff_field(v_x31_244, 0);
      V v_as_2410 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24OApply = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_t_2411 = heff_dup(heff_rfield(v_ce_240, 14));
      V v_t_2413;
      switch (heff_tag_of(v_t_2411)) {
      case TAG_RepV: {
        v_t_2413 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        heff_take_n(v_t_2411, 0ULL, 1);
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_241_24TReturn, 1);
        heff_drop_cell(v_ru_24x31_244_24OApply, 2);
        heff_drop(v_t_2413);
        V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2410));
        V v_t_2415 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_249, v_as_2410})));
        return (g_heff_2ecompile_2erefcount_2eapplyLast(v_ce_240, v_t_2414, v_t_2415));
      } else {
        heff_drop(v_t_2413);
        V v_t_2416 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_get_n(v_ce_240, 14, 15), heff_tag_at_n(v_ru_24x31_244_24OApply, TAG_OApply, 2, (V[]){v_f_249, v_as_2410})));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_241_24TReturn, TAG_CReturn, 1, (V[]){v_t_2416}), NTAG(TAG_Nil)});
      }
    }
    case TAG_OPrim: {
      V v_t_2419 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_get_n(v_ce_240, 14, 15), v_x31_244));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_241_24TReturn, TAG_CReturn, 1, (V[]){v_t_2419}), NTAG(TAG_Nil)});
    }
    case TAG_OAbandon: {
      V v_t_2420 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_get_n(v_ce_240, 14, 15), v_x31_244));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_241_24TReturn, TAG_CReturn, 1, (V[]){v_t_2420}), NTAG(TAG_Nil)});
    }
    case TAG_OBool: {
      V v_c_2421 = heff_field(v_x31_244, 0);
      V v_ru_24x31_244_24OBool = heff_take_reuse_n(v_x31_244, 1ULL, 1);
      V v_t_2422 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_240), NTAG(TAG_Nil), NTAG(TAG_RepV), heff_tag_at_n(v_ru_24x3_241_24TReturn, TAG_OBool, 1, (V[]){v_c_2421})));
      V v_t_2423 = (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), heff_dup(heff_rfield(v_ce_240, 14)), heff_tag_at_n(v_ru_24x31_244_24OBool, TAG_RLocal, 1, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2eboolName_get())})));
      V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_2423}), NTAG(TAG_Nil)});
      V v_t_2425 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), heff_get_n(v_ce_240, 4, 15)));
      V v_t_2426 = (g_prelude_2e_2b_2b_24f1572068627x1632985590(v_t_2424, v_t_2425));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2eboolName_get()), v_t_2422}), v_t_2426});
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  case TAG_TLoop: {
    V v_as_2427 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24TLoop = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_t_2428 = heff_dup(heff_rfield(v_ce_240, 2));
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Nothing: {
      heff_drop_rec(v_ce_240, 15);
      heff_drop(v_as_2427);
      V v_t_2429 = heff_tag_at_n(v_ru_24x3_241_24TLoop, TAG_CReturn, 1, (V[]){NTAG(TAG_RAbandon)});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_s_2430 = heff_field(v_t_2428, 0);
      heff_take_n(v_t_2428, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24TLoop, 1);
      return (g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(v_ce_240, heff_get_n(v_s_2430, 0, 2), v_as_2427));
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
  case TAG_TIf: {
    V v_x31_2431 = heff_field(v_x3_241, 0);
    V v_t_2432 = heff_field(v_x3_241, 1);
    V v_e_2433 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    switch (heff_tag_of(v_x31_2431)) {
    case TAG_PTrue: {
      return ({ V a_0 = v_ce_240; V a_1 = v_x31_2431; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2432}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2433}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PFalse: {
      return ({ V a_0 = v_ce_240; V a_1 = v_x31_2431; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2432}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2433}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PRel: {
      V v_p_2434 = heff_field(v_x31_2431, 0);
      V v_a_2435 = heff_field(v_x31_2431, 1);
      V v_b_2436 = heff_field(v_x31_2431, 2);
      heff_take_n(v_x31_2431, 7ULL, 3);
      V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2436), NTAG(TAG_Nil)});
      V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2436, NTAG(TAG_Nil)});
      V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2435), v_t_2438})));
      V v_t_2440 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2439; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_2439); r_; });
      V v_t_2441 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_2432)));
      V v_t_2442 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_e_2433)));
      V v_t_2443 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_240, 5)), v_t_2441, v_t_2442));
      return ({ V a_0 = v_ce_240; V a_1 = v_p_2434; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2435, v_t_2437}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2432}); V b_4 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2433}); V a_5 = v_t_2440; V a_6 = v_t_2443; V r_ = (g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(a_0, a_1, a_2, b_3, b_4, a_5, a_6)); heff_drop(b_3); heff_drop(b_4); r_; });
    }
    case TAG_PBool: {
      return ({ V a_0 = v_ce_240; V a_1 = v_x31_2431; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2432}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2433}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PNot: {
      return ({ V a_0 = v_ce_240; V a_1 = v_x31_2431; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2432}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2433}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PIf: {
      return ({ V a_0 = v_ce_240; V a_1 = v_x31_2431; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2432}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2433}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PLet: {
      return ({ V a_0 = v_ce_240; V a_1 = v_x31_2431; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2432}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2433}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_x31_2431);
    }
  }
  case TAG_TCase: {
    V v_v_2452 = heff_field(v_x3_241, 0);
    V v_arms_2453 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24TCase = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2454 = (g_list_2emap_24s1341404685x1564972929(v_arms_2453));
    V v_t_2455 = (g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(v_ce_240, NTAG(TAG_True), v_v_2452, v_t_2454));
    return heff_tag_at_n(v_ru_24x3_241_24TCase, TAG_Cons, 2, (V[]){v_t_2455, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_b_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245;
    if ((heff_dup(v_b_244) == NTAG(TAG_True))) {
      heff_drop(v_b_244);
      v_t_245 = MK_INT(1LL);
    } else {
      heff_drop(v_b_244);
      v_t_245 = MK_INT(0LL);
    }
    V v_t_246 = (g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(v_f_240, v_xs_243));
    return heff_intAdd(v_t_245, heff_intMul(MK_INT(2LL), v_t_246));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(a[0], a1); heff_drop(a1); return r;
}