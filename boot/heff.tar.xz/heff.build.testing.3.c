// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_Holds 53574
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkPath 49630
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Signalled 34337
#define TAG_TemporaryDirectory 61563
#define TAG_Throw 56084
#define TAG_TimedOut 6056
#define TAG_UseColor 15915
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define TAG_Wrong 41905
#define TAG_Wrote 42089
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_bind 9519364
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_file 9638467
#define LBL_files 298792593
#define LBL_fmap 9641981
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_hmap 9701563
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_malg 9839318
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_pattern 1588251091
#define LBL_pending 1696753626
#define LBL_place 308106529
#define LBL_property 1899481104
#define LBL_reports 1326460931
#define LBL_ret 322331
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_update 1108295668
#define LBL_wrong 314763719
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_owner__launch__place__top__path__limit[] = {LBL_owner, LBL_launch, LBL_place, LBL_top, LBL_path, LBL_limit};
V g_co_2e_3c_2b_3e_24s373441151x488264545_get(void);
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_co_2eop_24s59066675x636147158(V, V, V);
V g_co_2eop_24s59066675x636147158_entry(V self, V *a);
extern Clo g_co_2eop_24s59066675x636147158_clo;
V g_co_2eop_24s747777320x140686263(V, V, V);
V g_co_2eop_24s747777320x140686263_entry(V self, V *a);
extern Clo g_co_2eop_24s747777320x140686263_clo;
V g_co_2eop_24s907744994x1234676051(V, V);
V g_co_2eop_24s907744994x1234676051_entry(V self, V *a);
extern Clo g_co_2eop_24s907744994x1234676051_clo;
V g_co_2eop_24s91617614x2132230022(V, V, V, V);
V g_co_2eop_24s91617614x2132230022_entry(V self, V *a);
extern Clo g_co_2eop_24s91617614x2132230022_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2etesting_2eaddRes(V, V);
V g_heff_2ebuild_2etesting_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eaddRes_clo;
V g_heff_2ebuild_2etesting_2ebrokenJob(V, V);
V g_heff_2ebuild_2etesting_2ebrokenJob_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ebrokenJob_clo;
V g_heff_2ebuild_2etesting_2eexpectErrorsLine_get(void);
HeffT2 g_heff_2ebuild_2etesting_2efirstDiffering_24cpr(V, V, V);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_clo;
V g_heff_2ebuild_2etesting_2egoldenPath(V, V, V);
V g_heff_2ebuild_2etesting_2egoldenPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenPath_clo;
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116(V, V, V);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_clo;
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054(V, V, V, V);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_clo;
V g_heff_2ebuild_2etesting_2elevelsSelected(V, V);
V g_heff_2ebuild_2etesting_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elevelsSelected_clo;
V g_heff_2ebuild_2etesting_2enoRes_get(void);
V g_heff_2ebuild_2etesting_2epassedOver(V, V);
V g_heff_2ebuild_2etesting_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2epassedOver_clo;
V g_heff_2ebuild_2etesting_2eplaceBefore(V, V);
V g_heff_2ebuild_2etesting_2eplaceBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eplaceBefore_clo;
V g_heff_2ebuild_2etesting_2eprintFails_24s989015257x334337726(V, V, V);
V g_heff_2ebuild_2etesting_2eprintFails_24s989015257x334337726_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eprintFails_24s989015257x334337726_clo;
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119(V, V);
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119_clo;
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_clo;
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_clo;
V g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427_clo;
V g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111(V, V, V, V);
V g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_clo;
V g_heff_2ebuild_2etesting_2esubtestJobs(V, V, V, V);
V g_heff_2ebuild_2etesting_2esubtestJobs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2esubtestJobs_clo;
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2esubtestJobs_24dps_clo;
V g_heff_2ebuild_2etesting_2etestArgs(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestArgs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestArgs_clo;
V g_heff_2ebuild_2etesting_2etestFiles_24s1258542757x912825536(V);
V g_heff_2ebuild_2etesting_2etestFiles_24s1258542757x912825536_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFiles_24s1258542757x912825536_clo;
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528(V, V);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_clo;
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_clo;
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_clo;
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_clo;
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_clo;
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_clo;
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_clo;
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176(V, V, V);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_clo;
V g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514_clo;
V g_list_2eall_24s1461376987x321850093(V);
V g_list_2eall_24s1461376987x321850093_entry(V self, V *a);
extern Clo g_list_2eall_24s1461376987x321850093_clo;
V g_list_2eany_24s1287956370x756381573(V, V);
V g_list_2eany_24s1287956370x756381573_entry(V self, V *a);
extern Clo g_list_2eany_24s1287956370x756381573_clo;
V g_list_2eascending_24s408704122x680527522(V, V, V);
V g_list_2eascending_24s408704122x680527522_entry(V self, V *a);
extern Clo g_list_2eascending_24s408704122x680527522_clo;
V g_list_2edescending_24s604988964x1962429671(V, V, V);
V g_list_2edescending_24s604988964x1962429671_entry(V self, V *a);
extern Clo g_list_2edescending_24s604988964x1962429671_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1564248594x622634626(V, V, V);
V g_list_2efoldl_24f1564248594x622634626_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1564248594x622634626_clo;
V g_list_2efoldl_24f319030394x1380151895(V, V, V);
V g_list_2efoldl_24f319030394x1380151895_entry(V self, V *a);
extern Clo g_list_2efoldl_24f319030394x1380151895_clo;
V g_list_2efoldl_24f496521120x176206934(V, V, V);
V g_list_2efoldl_24f496521120x176206934_entry(V self, V *a);
extern Clo g_list_2efoldl_24f496521120x176206934_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s122741325x871243494(V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_clo;
V g_list_2ekeepIf_24s458067099x815639923(V);
V g_list_2ekeepIf_24s458067099x815639923_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s458067099x815639923_clo;
V g_list_2ekeepIf_24s741838803x941779121(V);
V g_list_2ekeepIf_24s741838803x941779121_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s741838803x941779121_clo;
V g_list_2ekeepIf_24s742867582x682687968(V, V);
V g_list_2ekeepIf_24s742867582x682687968_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s742867582x682687968_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1498757180x165099811(V);
V g_list_2emap_24s1498757180x165099811_entry(V self, V *a);
extern Clo g_list_2emap_24s1498757180x165099811_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s1264244840x54231393(V, V);
V g_list_2emergeRuns_24s1264244840x54231393_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s1264244840x54231393_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2einstanceShowString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceShowString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceShowString_2eescapedFrom_241_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781(V);
V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_entry(V self, V *a);
extern Clo g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s1283316583x974970592(V);
V g_std_2eprocess_2ewithProcess_24s1283316583x974970592_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1283316583x974970592_clo;

static V g_heff_2ebuild_2etesting_2enoRes_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2enoRes_st;
static V g_heff_2ebuild_2etesting_2enoRes_init(void) {
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2ebuild_2etesting_2enoRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2enoRes_st)) return g_heff_2ebuild_2etesting_2enoRes_val;
  return heff_global(&g_heff_2ebuild_2etesting_2enoRes_val, &g_heff_2ebuild_2etesting_2enoRes_st, g_heff_2ebuild_2etesting_2enoRes_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eexpectErrorsLine_str0, 22, "-- test: expect errors");

static V g_heff_2ebuild_2etesting_2eexpectErrorsLine_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2eexpectErrorsLine_st;
static V g_heff_2ebuild_2etesting_2eexpectErrorsLine_init(void) {
  return ((V)&g_heff_2ebuild_2etesting_2eexpectErrorsLine_str0);
}
V g_heff_2ebuild_2etesting_2eexpectErrorsLine_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2eexpectErrorsLine_st)) return g_heff_2ebuild_2etesting_2eexpectErrorsLine_val;
  return heff_global(&g_heff_2ebuild_2etesting_2eexpectErrorsLine_val, &g_heff_2ebuild_2etesting_2eexpectErrorsLine_st, g_heff_2ebuild_2etesting_2eexpectErrorsLine_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenPath_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenPath_str1, 7, ".golden");
Clo g_heff_2ebuild_2etesting_2egoldenPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenPath_entry, 3, 0};

V g_heff_2ebuild_2etesting_2egoldenPath(V v_st_240, V v_f_241, V v_name_242) {
top: ;
  int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
  V v_t_244 = heff_strSlice(heff_dup(v_f_241), heff_box_word(v_t_243), heff_strLength_lent(v_f_241, 0));
  V v_t_246;
  if (heff_strEq_c(v_t_244, ((V)&g_heff_2ebuild_2etesting_2egoldenPath_str0))) {
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
    v_t_246 = heff_strSlice(v_f_241, MK_INT(0LL), heff_box_word(v_t_245));
  } else {
    v_t_246 = v_f_241;
  }
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2etesting_2egoldenPath_str1))));
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_name_242));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  return ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_249); r_; });
}
V g_heff_2ebuild_2etesting_2egoldenPath_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2egoldenPath(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2esubtestJobs_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2etesting_2esubtestJobs_str1, 3, " / ");
Clo g_heff_2ebuild_2etesting_2esubtestJobs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2esubtestJobs_entry, 4, 0};

V g_heff_2ebuild_2etesting_2esubtestJobs(V v_sel_240, V v_j_241, V v_k_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_j_241, 6);
    heff_drop(v_k_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_n_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_n_244), NTAG(TAG_Nil)});
    V v_s_247 = heff_dup(heff_rfield(v_j_241, 3));
    V v_t_248 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2esubtestJobs_str0); V a_1 = v_s_247; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2esubtestJobs_str1), v_s_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_247); r_; });
    V v_t_249 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_t_246, v_t_248, heff_dup(heff_rfield(v_j_241, 4))));
    V v_t_2410 = ({ V a_0 = v_sel_240; V a_1 = v_t_249; V r_ = (g_heff_2ebuild_2etesting_2elevelsSelected(a_0, a_1)); heff_drop(v_t_249); r_; });
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_k_242), NTAG(TAG_Nil)});
      V v_t_2412 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 2)), v_t_2411));
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_244, NTAG(TAG_Nil)});
      V v_t_2414 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 4)), v_t_2413));
      V v_t_2415 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(heff_rfield(v_j_241, 0)), heff_dup(heff_rfield(v_j_241, 1)), v_t_2412, heff_dup(heff_rfield(v_j_241, 3)), v_t_2414, heff_dup(heff_rfield(v_j_241, 5))});
      V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
      V v_u_2417 = (g_heff_2ebuild_2etesting_2esubtestJobs_24dps(v_sel_240, v_j_241, heff_intAdd(v_k_242, MK_INT(1LL)), v_rest_245, heff_dup(v_cell_2416)));
      heff_drop(v_u_2417);
      return v_cell_2416;
    } else {
      heff_drop(v_n_244);
      heff_drop(v_t_2410);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_245;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2etesting_2esubtestJobs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2etesting_2esubtestJobs(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2etesting_2epassedOver_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2epassedOver_str1, 0, "");
Clo g_heff_2ebuild_2etesting_2epassedOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2epassedOver_entry, 2, 0};

V g_heff_2ebuild_2etesting_2epassedOver(V v_opts_240, V v_os_241) {
top: ;
  if (!heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 1)), ((V)&g_heff_2ebuild_2etesting_2epassedOver_str0))) {
    V v_x1_242 = (g_list_2ekeepIf_24s458067099x815639923(heff_dup(v_os_241)));
    switch (heff_tag_of(v_x1_242)) {
    case TAG_Nil: {
      V v_p_243 = heff_get_n(v_opts_240, 1, 4);
      V v_t_2411;
      if (heff_strEq_c_lent(v_p_243, ((V)&g_heff_2ebuild_2etesting_2epassedOver_str1), 2)) {
        heff_drop(v_p_243);
        v_t_2411 = NTAG(TAG_Nil);
      } else {
        V v_t_244 = ({ V a_0 = MK_INT(47LL); V a_1 = v_p_243; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_243); r_; });
        V v_t_245 = (g_list_2emap_24s1007499915x73800978(v_t_244));
        HeffT2 v_t_246 = (g_regex_2eallRead_24cpr(v_t_245));
        {
          V v_field_248 = v_t_246.f[1];
          int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
          if ((v_tag_247 == ((int64_t)0ULL))) {
            V v_why_249 = v_field_248;
            heff_drop(v_why_249);
            v_t_2411 = NTAG(TAG_Nil);
          } else {
            V v_sel_2410 = v_field_248;
            v_t_2411 = v_sel_2410;
          }
        }
      }
      V v_x1_2412 = ({ V a_0 = v_t_2411; V a_1 = v_os_241; V r_ = (g_list_2eany_24s1287956370x756381573(a_0, a_1)); heff_drop(v_os_241); r_; });
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2412) == NTAG(TAG_True)));
      heff_drop(v_x1_2412);
      return v_ret_24bool;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_242, 0ULL, 2);
      heff_drop_rec(v_opts_240, 4);
      heff_drop(v_os_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_242);
    }
  } else {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_os_241);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2etesting_2epassedOver_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2epassedOver(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestArgs_str0, 6, "--seed");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestArgs_str1, 5, "--run");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestArgs_str2, 6, "--jobs");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestArgs_str3, 4, "test");
Clo g_heff_2ebuild_2etesting_2etestArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestArgs_entry, 4, 0};

V g_heff_2ebuild_2etesting_2etestArgs(V v_seed_240, V v_pattern_241, V v_jobs_242, V v_given_243) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_244 = heff_field(v_seed_240, 0);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_244), NTAG(TAG_Nil)});
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestArgs_str0), v_t_245});
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_249;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_247 = heff_field(v_pattern_241, 0);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_247), NTAG(TAG_Nil)});
    v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestArgs_str1), v_t_248});
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_2412;
  switch (heff_tag_of(v_jobs_242)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_2410 = heff_field(v_jobs_242, 0);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_2410), NTAG(TAG_Nil)});
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestArgs_str2), v_t_2411});
    break;
  }
  default: heff_nomatch(v_jobs_242);
  }
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_given_243));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_249, v_t_2413));
  V v_t_2415 = (g_prelude_2e_2b_2b(v_t_246, v_t_2414));
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestArgs_str3), v_t_2415});
}
V g_heff_2ebuild_2etesting_2etestArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2etesting_2etestArgs(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_str3, 1, ".");
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam1(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam1, 1, 0};
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam8(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam8, 1, 0};
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam10(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam10, 2, 0};
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam11(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam11, 1, 0};
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam13(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam12(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam12, 1, 0};
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam15(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam14(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam17(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam16(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam6(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_entry, 2, 0};

V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_MkPair: {
      V v_top_247 = heff_field(v_x11_245, 0);
      V v_p_248 = heff_field(v_x11_245, 1);
      heff_take_n(v_x11_245, 3ULL, 2);
      V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_248)));
      V v_t_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_249; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
      V v_a_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_ReadDirectory, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam1_clo)});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
      V v_c_2436 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam2, 3, 1, (V[]){v_path_249})));
      return heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam6, 2, 5, (V[]){v_c_2436, v_p_248, v_rest_246, v_acc_241, v_top_247});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528(a[0], a[1]);
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam1(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam4(V self, V *args) {
  V v_n_2427 = args[0];
  V v_path_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2427));
  return (g_std_2epath_2ejoin(v_path_249, v_t_2428));
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_z_2425 = args[1];
  V v_z_2426 = args[2];
  V v_path_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2425);
  V v_x_2429 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam4, 1, 1, (V[]){v_path_249}), v_x_2424));
  V v_x_2430 = (g_list_2emap_24s219049803x1458391381(v_x_2429));
  V f_ = v_z_2426;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam5(V self, V *args) {
  V v_n_2432 = args[0];
  V v_path_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2432));
  return (g_std_2epath_2ejoin(v_path_249, v_t_2433));
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_z_2420 = args[1];
  V v_z_2421 = args[2];
  V v_path_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_err_2422 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    V v_t_2423 = heff_tag_at_n(v_ru_24x_2419_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2422})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2423, heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam3, 3, 1, (V[]){v_path_249}), v_z_2420, v_z_2421));
  }
  case TAG_Right: {
    V v_x_2431 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    heff_drop(v_z_2420);
    V v_x_2434 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam5, 1, 1, (V[]){v_path_249}), v_x_2431));
    V v_x_2435 = (g_list_2emap_24s219049803x1458391381(v_x_2434));
    V f_ = v_z_2421;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2435});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam8(V self, V *args) {
  V v_s_2440 = args[0];
  return v_s_2440;
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam10(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  heff_drop(v_hd_2457);
  V f_ = v_k_2458;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam11(V self, V *args) {
  V v_r_2467 = args[0];
  return v_r_2467;
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam13(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  V v_x_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2479);
  V f_ = v_k_2480;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2478});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam12(V self, V *args) {
  V v_x_2475 = args[0];
  switch (heff_tag_of(v_x_2475)) {
  case TAG_Left: {
    V v_err_2476 = heff_field(v_x_2475, 0);
    V v_ru_24x_2475_24Left = heff_take_reuse_n(v_x_2475, 1ULL, 1);
    V v_t_2477 = heff_tag_at_n(v_ru_24x_2475_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2476})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2477));
  }
  case TAG_Right: {
    V v_x_2478 = heff_field(v_x_2475, 0);
    heff_take_n(v_x_2475, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam13, 2, 1, (V[]){v_x_2478});
  }
  default: return heff_nomatch(v_x_2475);
  }
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam15(V self, V *args) {
  V v_x_2484 = args[0];
  V v_k_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2484)) {
  case TAG_Left: {
    heff_take_n(v_x_2484, 0ULL, 1);
    V f_ = v_k_2483;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2484, 0ULL, 1);
    V f_ = v_k_2483;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2484);
  }
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam14(V self, V *args) {
  V v_hd_2482 = args[0];
  V v_k_2483 = args[1];
  V v_c_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2481;
  args[0] = v_hd_2482;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam15, 1, 1, (V[]){v_k_2483});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam17(V self, V *args) {
  V v_n_2491 = args[0];
  V v_st_2450 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2492 = (g_std_2epath_2eparse(heff_dup(v_st_2450), v_p_248));
  V v_t_2493 = (g_std_2epath_2eparse(heff_dup(v_st_2450), v_n_2491));
  V v_t_2494 = (g_std_2epath_2ejoin(v_t_2492, v_t_2493));
  V v_t_2495 = ({ V a_0 = v_st_2450; V a_1 = v_t_2494; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2450); heff_drop(v_t_2494); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_t_2495});
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam16(V self, V *args) {
  V v_x_2488 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_2437 = heff_env(self)[2];
  V v_k_2438 = heff_env(self)[3];
  V v_y_2456 = heff_env(self)[4];
  V v_st_2450 = heff_env(self)[5];
  V v_p_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  if ((heff_dup(v_x_2488) == NTAG(TAG_True))) {
    heff_drop(v_x_2488);
    heff_drop(v_y_2456);
    heff_drop(v_st_2450);
    heff_drop(v_p_248);
    V v_t_2489 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528(v_rest_246, v_acc_241));
    V f_ = v_t_2489;
    heff_room[0] = v_hd_2437;
    heff_room[1] = v_k_2438;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2488);
    V v_t_2490 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_str3); V a_3 = v_y_2456; V r_ = (g_list_2ekeepIf_24s122741325x871243494(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
    V v_t_2496 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_246, heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam17, 1, 2, (V[]){v_st_2450, v_p_248}), v_t_2490));
    V v_t_2497 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528(v_t_2496, v_acc_241));
    V f_ = v_t_2497;
    heff_room[0] = v_hd_2437;
    heff_room[1] = v_k_2438;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam9(V self, V *args) {
  V v_x_2449 = args[0];
  V v_x_2439 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_2437 = heff_env(self)[4];
  V v_k_2438 = heff_env(self)[5];
  V v_top_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2450;
  if (heff_strEq_c(v_x_2449, ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_str0))) {
    v_st_2450 = NTAG(TAG_Windows);
  } else {
    v_st_2450 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2439)) {
  case TAG_Left: {
    heff_take_n(v_x_2439, 0ULL, 1);
    heff_drop(v_top_247);
    heff_drop(v_st_2450);
    int64_t v_t_2452 = (heff_unbox_word(heff_strLength_lent(v_p_248, 0)) - ((int64_t)3ULL));
    V v_t_2453 = heff_strSlice(heff_dup(v_p_248), heff_box_word(v_t_2452), heff_strLength_lent(v_p_248, 0));
    if (heff_strEq_c(v_t_2453, ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_str1))) {
      V v_t_2454 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528(v_rest_246, heff_tag_n(TAG_Cons, 2, (V[]){v_p_248, v_acc_241})));
      V f_ = v_t_2454;
      heff_room[0] = v_hd_2437;
      heff_room[1] = v_k_2438;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_248);
      V v_t_2455 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528(v_rest_246, v_acc_241));
      V f_ = v_t_2455;
      heff_room[0] = v_hd_2437;
      heff_room[1] = v_k_2438;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Right: {
    V v_y_2456 = heff_field(v_x_2439, 0);
    V v_ru_24x_2439_24Right = heff_take_reuse_n(v_x_2439, 1ULL, 1);
    V v_c_2487;
    if ((heff_dup(v_top_247) == NTAG(TAG_True))) {
      heff_drop(v_top_247);
      heff_drop_cell(v_ru_24x_2439_24Right, 1);
      v_c_2487 = ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam10_clo);
    } else {
      heff_drop(v_top_247);
      V v_st_2459 = heff_dup(v_st_2450);
      V v_d_2460 = heff_dup(v_p_248);
      V v_t_2461 = (g_std_2epath_2eparse(heff_dup(v_st_2459), v_d_2460));
      V v_t_2462 = (g_std_2epath_2eparse(heff_dup(v_st_2459), ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_str2)));
      V v_t_2463 = (g_std_2epath_2ejoin(v_t_2461, v_t_2462));
      V v_s_2464 = ({ V a_0 = v_st_2459; V a_1 = v_t_2463; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2459); heff_drop(v_t_2463); r_; });
      V v_path_2465 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2464));
      V v_t_2466 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2465; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2465); r_; });
      V v_a_2468 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2466, ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam11_clo)});
      V v_t_2469 = heff_tag_at_n(v_ru_24x_2439_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2468})});
      V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
      V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
      V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
      V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
      V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
      V v_c_2481 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2474}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam12_clo)));
      v_c_2487 = heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam14, 2, 1, (V[]){v_c_2481});
    }
    V f_ = v_c_2487;
    heff_room[0] = heff_dup(v_hd_2437);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam16, 1, 7, (V[]){v_rest_246, v_acc_241, v_hd_2437, v_k_2438, v_y_2456, v_st_2450, v_p_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2439);
  }
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_2437 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_2438 = heff_env(self)[4];
  V v_top_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam8_clo)})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2437, 2)), 1, (V[]){v_t_2447}));
  V f_ = heff_dup(heff_rfield(v_hd_2437, 1));
  heff_room[0] = v_t_2448;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam9, 1, 7, (V[]){v_x_2439, v_p_248, v_rest_246, v_acc_241, v_hd_2437, v_k_2438, v_top_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam6(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_c_2436 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_top_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2436;
  args[0] = heff_dup(v_hd_2437);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_lam7, 1, 6, (V[]){v_hd_2437, v_p_248, v_rest_246, v_acc_241, v_k_2438, v_top_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str0, 36, "\012heff test: a change; tested again\012\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str1, 19, "heff test: tested (");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str2, 3, "), ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str3, 8, "all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str4, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str5, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str6, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str7, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str8, 33, "; tested again at the next change");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str10, 60, "heff test: cannot run heff; tested again at the next change\012");
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_entry, 4, 0};

V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442(V v_argv_240, V v_n_241, V v_p_242, V v_p_243) {
top: ;
  V v_t_246;
  if ((heff_peek_word(v_n_241) == ((int64_t)0ULL))) {
    v_t_246 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam0_clo);
  } else {
    v_t_246 = heff_tr(heff_call(((V)&g_co_2eop_24s59066675x636147158_clo), 1, (V[]){((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str0)}));
  }
  return heff_tail(v_t_246, 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam1, 1, 4, (V[]){v_p_242, v_argv_240, v_n_241, v_p_243})});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2430 = args[1];
  V v_k_2431 = args[2];
  V v_n_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = heff_box_word((heff_unbox_word(v_n_241) + ((int64_t)1ULL)));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2428);
  V f_ = v_k_2411;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam5, 3, 1, (V[]){v_n_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_intShow(heff_box_word((heff_peek_word(v_n_241) + ((int64_t)1ULL))));
  V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str1), v_t_2413), ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str2));
  V v_t_2415 = heff_get_n(v_x_2412, 0, 3);
  V v_t_2418;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Exited: {
    V v_n_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    if (heff_intEq_c(v_n_2416, MK_INT(0LL))) {
      v_t_2418 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str3);
    } else {
      v_t_2418 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str4);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2415, 0ULL, 1);
    v_t_2418 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str5);
    break;
  }
  case TAG_TimedOut: {
    v_t_2418 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str6);
    break;
  }
  case TAG_NotRun: {
    v_t_2418 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str7);
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2414, v_t_2418), ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str8));
  V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str9)), NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_call(heff_take_field(v_p_242, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})}));
  V f_ = heff_get_n(v_p_242, 1, 3);
  heff_room[0] = v_t_2427;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam4, 1, 2, (V[]){v_k_2411, v_n_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam8(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_2445 = args[1];
  V v_k_2446 = args[2];
  V v_n_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2444);
  heff_drop(v_hd_2445);
  V f_ = v_k_2446;
  args[0] = heff_box_word((heff_unbox_word(v_n_241) + ((int64_t)1ULL)));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_2434 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2443);
  V f_ = v_k_2434;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam8, 3, 1, (V[]){v_n_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam6(V self, V *args) {
  V v_s_2433 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_s_2433);
  V v_k_2434 = heff_take_field(v_p_242, 0);
  V v_t_2435 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_str10), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_call(heff_take_field(v_p_242, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})}));
  V f_ = heff_get_n(v_p_242, 1, 3);
  heff_room[0] = v_t_2442;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam7, 1, 2, (V[]){v_k_2434, v_n_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam9(V self, V *args) {
  V v_x_2449 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2449;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_p_242;
  heff_room[2] = v_p_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_argv_240 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_248, v_argv_240, heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_c_2410 = (g_std_2eprocess_2ewithProcess_24s1283316583x974970592(v_t_249));
  V v_k_2411 = heff_dup(heff_rfield(v_p_242, 0));
  V v_t_2432 = heff_tr(heff_call(v_c_2410, 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam3, 1, 3, (V[]){heff_dup(v_n_241), heff_dup(v_p_242), v_k_2411})}));
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2432, heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam6, 1, 2, (V[]){heff_dup(v_p_242), v_n_241})})});
  V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_242, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})}));
  V f_ = heff_dup(heff_rfield(v_p_242, 1));
  heff_room[0] = v_t_2448;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam9, 1, 2, (V[]){v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_argv_240 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_247);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442_lam2, 1, 4, (V[]){v_argv_240, v_p_242, v_n_241, v_p_243})));
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_str0, 46, "heff test: --watch is not given with --update\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_str2, 4, "test");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_str5, 4, "test");
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam5(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam5, 1, 0};
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam2(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_entry, 5, 0};

V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243(V v_seed_240, V v_pattern_241, V v_jobs_242, V v_x4_243, V v_given_244) {
top: ;
  if ((heff_dup(v_x4_243) == NTAG(TAG_True))) {
    heff_drop(v_given_244);
    return ((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam0_clo);
  } else {
    V v_c_2416 = (g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387(v_seed_240, v_pattern_241, v_jobs_242, NTAG(TAG_False)));
    return heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam2, 2, 5, (V[]){v_c_2416, v_given_244, heff_dup(v_seed_240), heff_dup(v_pattern_241), heff_dup(v_jobs_242)});
  }
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243(a0, a1, a2, a3, a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(2LL), v_hd_245, v_k_246));
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_t_247 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_str0), NTAG(TAG_MkUnit)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2414;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam1, 1, 2, (V[]){v_hd_245, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam5(V self, V *args) {
  V v_s_2422 = args[0];
  return v_s_2422;
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam8(V self, V *args) {
  V v_x_2442 = args[0];
  V v_given_244 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_st_2432 = heff_env(self)[4];
  V v_x_2440 = heff_env(self)[5];
  V v_hd_2417 = heff_env(self)[6];
  V v_k_2418 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2445;
  switch (heff_tag_of(v_given_244)) {
  case TAG_Nil: {
    v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_str5), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())});
    break;
  }
  case TAG_Cons: {
    v_t_2445 = (g_prelude_2e_2b_2b(heff_dup(v_given_244), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
    break;
  }
  default: heff_nomatch(v_given_244);
  }
  V v_t_2446 = ({ V a_0 = v_seed_240; V a_1 = v_pattern_241; V a_2 = v_jobs_242; V a_3 = v_given_244; V r_ = (g_heff_2ebuild_2etesting_2etestArgs(a_0, a_1, a_2, a_3)); heff_drop(v_seed_240); heff_drop(v_pattern_241); heff_drop(v_jobs_242); r_; });
  V v_t_2447 = heff_tr(heff_call(((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1221543448x1864317957_clo), 1, (V[]){v_t_2446}));
  return ({ V a_0 = v_st_2432; V a_1 = v_t_2445; V a_2 = v_t_2447; V a_3 = v_x_2440; V a_4 = v_x_2442; V a_5 = v_hd_2417; V a_6 = v_k_2418; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s833122206x481038514(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2440); heff_drop(v_k_2418); r_; });
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_seed_240 = heff_env(self)[0];
  V v_pattern_241 = heff_env(self)[1];
  V v_jobs_242 = heff_env(self)[2];
  V v_given_244 = heff_env(self)[3];
  V v_hd_2417 = heff_env(self)[4];
  V v_st_2432 = heff_env(self)[5];
  V v_k_2418 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x_2440;
  switch (heff_tag_of(v_x_2437)) {
  case TAG_Nil: {
    v_x_2440 = ((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2438 = heff_field(v_x_2437, 0);
    V v_xs_2439 = heff_field(v_x_2437, 1);
    heff_take_n(v_x_2437, 3ULL, 2);
    v_x_2440 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_str4); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
    break;
  }
  default: heff_nomatch(v_x_2437);
  }
  V v_t_2441 = (g_heff_2ebuild_2etesting_2etestArgs(v_seed_240, v_pattern_241, v_jobs_242, heff_dup(v_given_244)));
  return (g_heff_2ebuild_2etesting_2etestedAgain_24s41698043x653883442(v_t_2441, MK_INT(0LL), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam8, 1, 8, (V[]){v_given_244, v_seed_240, v_pattern_241, v_jobs_242, v_st_2432, v_x_2440, v_hd_2417, v_k_2418})));
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_given_244 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_seed_240 = heff_env(self)[2];
  V v_pattern_241 = heff_env(self)[3];
  V v_jobs_242 = heff_env(self)[4];
  V v_k_2418 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2432;
  if (heff_strEq_c(v_x_2431, ((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_str1))) {
    v_st_2432 = NTAG(TAG_Windows);
  } else {
    v_st_2432 = NTAG(TAG_Posix);
  }
  V v_paths_2435;
  switch (heff_tag_of(v_given_244)) {
  case TAG_Nil: {
    v_paths_2435 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_str2), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())});
    break;
  }
  case TAG_Cons: {
    v_paths_2435 = (g_prelude_2e_2b_2b(heff_dup(v_given_244), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
    break;
  }
  default: heff_nomatch(v_given_244);
  }
  V v_c_2436 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(heff_dup(v_st_2432), NTAG(TAG_Nil), v_paths_2435));
  V f_ = v_c_2436;
  heff_room[0] = heff_dup(v_hd_2417);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam7, 1, 7, (V[]){v_seed_240, v_pattern_241, v_jobs_242, v_given_244, v_hd_2417, v_st_2432, v_k_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_given_244 = heff_env(self)[1];
  V v_seed_240 = heff_env(self)[2];
  V v_pattern_241 = heff_env(self)[3];
  V v_jobs_242 = heff_env(self)[4];
  V v_k_2418 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2421);
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam5_clo)})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2417, 2)), 1, (V[]){v_t_2429}));
  V f_ = heff_dup(heff_rfield(v_hd_2417, 1));
  heff_room[0] = v_t_2430;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam6, 1, 6, (V[]){v_given_244, v_hd_2417, v_seed_240, v_pattern_241, v_jobs_242, v_k_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_given_244 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_seed_240 = heff_env(self)[2];
  V v_pattern_241 = heff_env(self)[3];
  V v_jobs_242 = heff_env(self)[4];
  V v_k_2418 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2419);
  V v_c_2420 = (g_heff_2ebuild_2etesting_2etestFiles_24s1258542757x912825536(heff_dup(v_given_244)));
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_2417);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam4, 1, 6, (V[]){v_hd_2417, v_given_244, v_seed_240, v_pattern_241, v_jobs_242, v_k_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_given_244 = heff_env(self)[1];
  V v_seed_240 = heff_env(self)[2];
  V v_pattern_241 = heff_env(self)[3];
  V v_jobs_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestsWatched_24s2010710907x68461243_lam3, 1, 6, (V[]){v_given_244, v_hd_2417, v_seed_240, v_pattern_241, v_jobs_242, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_str0, 10, "heff-test-");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_str1, 21, "no directory for it: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_str2, 5, "win32");
V g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_entry, 4, 0};

V g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111(V v_sel_240, V v_j_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam1, 1, 4, (V[]){v_hd_242, v_j_241, v_k_243, heff_dup(v_sel_240)})});
}
V g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam2(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_j_241 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_sel_240 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_err_2425 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    heff_drop(v_x_2413);
    heff_drop(v_sel_240);
    heff_drop_rec(v_hd_242, 3);
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_str1), heff_get_n(v_err_2425, 2, 3));
    V v_x_2427 = (g_heff_2ebuild_2etesting_2ebrokenJob(v_j_241, v_t_2426));
    V f_ = v_k_243;
    args[0] = v_x_2427;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_dir_2428 = heff_field(v_x_2424, 0);
    V v_ru_24x_2424_24Right = heff_take_reuse_n(v_x_2424, 1ULL, 1);
    V v_t_2429;
    if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_str2))) {
      v_t_2429 = NTAG(TAG_Windows);
    } else {
      v_t_2429 = NTAG(TAG_Posix);
    }
    V v_t_2430 = ({ V a_0 = v_t_2429; V a_1 = v_dir_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2429); heff_drop(v_dir_2428); r_; });
    return ({ V a_0 = v_ru_24x_2424_24Right; V a_1 = v_sel_240; V a_2 = v_j_241; V a_3 = v_t_2430; V a_4 = v_hd_242; V a_5 = v_k_243; V r_ = (g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_sel_240); r_; });
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_j_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_sel_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_TemporaryDirectory, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_str0), ((V)&g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(((V)&g_co_2eop_24s747777320x140686263_clo), 1, (V[]){v_t_2421}));
  V v_c_2423 = heff_tr(g_std_2efilesystem_2efromSystem_24s1003849434x1875331781(v_t_2422));
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2erunJob_24s251593768x2014232111_lam3, 1, 5, (V[]){v_j_241, v_k_243, v_x_2413, v_sel_240, v_hd_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str0, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str1, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str2, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str3, 44, "not kept yet: `heff test --update` writes it");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str4, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str5, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str10, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str11, 7, ", line ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str13, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str14, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str16, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str17, 1, "\"");
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam1(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam1, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam4, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam5(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam5, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam8(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam8, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam10(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam9(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam9, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam11(V self, V *args);
Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_entry, 7, 0};

V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831(V v_update_240, V v_dir_241, V v_path_242, V v_text_243, V v_x5_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    if ((heff_dup(v_update_240) == NTAG(TAG_True))) {
      V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_dir_241));
      V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
      V v_a_2410 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam0_clo)});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
      V v_c_2423 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam1_clo)));
      return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam3, 1, 4, (V[]){v_path_242, v_text_243, v_z_245, v_z_246})});
    } else {
      heff_drop(v_dir_241);
      heff_drop(v_text_243);
      heff_drop(v_z_245);
      V v_t_2446 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str2), v_path_242), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str3)})});
      return heff_tail(v_z_246, 1, (V[]){v_t_2446});
    }
  }
  case TAG_Just: {
    V v_kept_2447 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24Just = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    heff_drop(v_dir_241);
    if (heff_strEq_c_lent(v_kept_2447, v_text_243, 0)) {
      heff_drop(v_path_242);
      heff_drop(v_text_243);
      heff_drop(v_z_245);
      heff_drop(v_kept_2447);
      heff_drop_cell(v_ru_24x5_244_24Just, 1);
      return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_Holds)});
    } else {
      if ((heff_dup(v_update_240) == NTAG(TAG_True))) {
        heff_drop(v_kept_2447);
        V v_path_2448 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_242)));
        V v_t_2449 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2448; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2448); r_; });
        V v_a_2451 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2449, v_text_243, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam8_clo)});
        V v_t_2452 = heff_tag_at_n(v_ru_24x5_244_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2451})});
        V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
        V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
        V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
        V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
        V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
        V v_c_2464 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam9_clo)));
        return heff_tail(v_c_2464, 2, (V[]){v_z_245, heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam11, 1, 2, (V[]){v_path_242, v_z_246})});
      } else {
        heff_drop(v_z_245);
        heff_drop_cell(v_ru_24x5_244_24Just, 1);
        V v_t_2469 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str6); V a_1 = v_kept_2447; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str7), v_kept_2447, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_kept_2447); r_; });
        V v_t_2470 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str8); V a_1 = v_text_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str9), v_text_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_243); r_; });
        HeffT2 v_t_2471 = (g_heff_2ebuild_2etesting_2efirstDiffering_24cpr(MK_INT(1LL), v_t_2469, v_t_2470));
        {
          V v_field_2472 = v_t_2471.f[0];
          V v_field_2473 = v_t_2471.f[1];
          V v_n_2474 = v_field_2472;
          V v_x22_2475 = v_field_2473;
          V v_x_2484;
          switch (heff_tag_of(v_x22_2475)) {
          case TAG_MkPair: {
            V v_kept_2476 = heff_field(v_x22_2475, 0);
            V v_text_2477 = heff_field(v_x22_2475, 1);
            V v_ru_24x22_2475_24MkPair = heff_take_reuse_n(v_x22_2475, 3ULL, 2);
            V v_t_2478 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str10), v_path_242), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str11));
            V v_t_2479 = heff_strAppend(v_t_2478, heff_intShow(v_n_2474));
            V v_t_2480 = ({ V a_0 = v_kept_2476; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str12); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_kept_2476); r_; });
            V v_t_2481 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str13), v_t_2480), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str14));
            V v_t_2482 = ({ V a_0 = v_text_2477; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str15); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_text_2477); r_; });
            V v_t_2483 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str16), v_t_2482), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str17));
            v_x_2484 = heff_tag_at_n(v_ru_24x22_2475_24MkPair, TAG_Wrong, 2, (V[]){v_t_2479, heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_2481, v_t_2483})});
            break;
          }
          default: heff_nomatch(v_x22_2475);
          }
          return heff_tail(v_z_246, 1, (V[]){v_x_2484});
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_err_2418 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Left = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    V v_t_2419 = heff_tag_at_n(v_ru_24x_2417_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2418})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2419));
  }
  case TAG_Right: {
    V v_x_2420 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam2, 2, 1, (V[]){v_x_2420});
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam4(V self, V *args) {
  V v_r_2427 = args[0];
  return v_r_2427;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam6(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_x_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Left: {
    V v_err_2436 = heff_field(v_x_2435, 0);
    V v_ru_24x_2435_24Left = heff_take_reuse_n(v_x_2435, 1ULL, 1);
    V v_t_2437 = heff_tag_at_n(v_ru_24x_2435_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2436})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2437));
  }
  case TAG_Right: {
    V v_x_2438 = heff_field(v_x_2435, 0);
    heff_take_n(v_x_2435, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam6, 2, 1, (V[]){v_x_2438});
  }
  default: return heff_nomatch(v_x_2435);
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam7(V self, V *args) {
  V v_x_2442 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Left: {
    V v_ru_24x_2442_24Left = heff_take_reuse_n(v_x_2442, 0ULL, 1);
    V v_t_2444 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str0), v_path_242), heff_tag_at_n(v_ru_24x_2442_24Left, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str1)})});
    V f_ = v_z_246;
    args[0] = v_t_2444;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2442, 0ULL, 1);
    V f_ = v_z_246;
    args[0] = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2442);
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_text_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2424);
  V v_path_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_242)));
  V v_t_2426 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2425; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2425); r_; });
  V v_a_2428 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2426, v_text_243, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam4_clo)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  V v_c_2441 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam5_clo)));
  V f_ = v_c_2441;
  heff_room[0] = v_z_245;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam7, 1, 2, (V[]){v_path_242, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam8(V self, V *args) {
  V v_r_2450 = args[0];
  return v_r_2450;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam10(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_x_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2462);
  V f_ = v_k_2463;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2461});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam9(V self, V *args) {
  V v_x_2458 = args[0];
  switch (heff_tag_of(v_x_2458)) {
  case TAG_Left: {
    V v_err_2459 = heff_field(v_x_2458, 0);
    V v_ru_24x_2458_24Left = heff_take_reuse_n(v_x_2458, 1ULL, 1);
    V v_t_2460 = heff_tag_at_n(v_ru_24x_2458_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2459})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2460));
  }
  case TAG_Right: {
    V v_x_2461 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam10, 2, 1, (V[]){v_x_2461});
  }
  default: return heff_nomatch(v_x_2458);
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_lam11(V self, V *args) {
  V v_x_2465 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2465)) {
  case TAG_Left: {
    V v_ru_24x_2465_24Left = heff_take_reuse_n(v_x_2465, 0ULL, 1);
    V v_t_2467 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str4), v_path_242), heff_tag_at_n(v_ru_24x_2465_24Left, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831_str5)})});
    V f_ = v_z_246;
    args[0] = v_t_2467;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2465, 0ULL, 1);
    V f_ = v_z_246;
    args[0] = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2465);
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str3, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str4, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str5, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str6, 112, "a golden text's name is a file's under the directory: letters, digits, `-`, `_` and `.`, not first, between `/`s");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str7, 5, "win32");
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam4, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam5(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam5, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_entry, 3, 0};

V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116(V v_update_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_name_243 = heff_field(v_x3_242, 0);
    V v_text_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str0); V a_1 = v_name_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str1), v_name_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x1_246 = ({ V a_0 = v_t_245; V r_ = (g_list_2eall_24s1461376987x321850093(a_0)); heff_drop(v_t_245); r_; });
    if (!(heff_dup(v_x1_246) == NTAG(TAG_True))) {
      heff_drop(v_f_241);
      heff_drop(v_text_244);
      heff_drop(v_x1_246);
      V v_t_247 = ({ V a_0 = v_name_243; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str2); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_name_243); r_; });
      V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str3), v_t_247), ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str4));
      V v_x_249 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str5), v_t_248), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str6)})});
      return heff_clo_n(g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam0, 2, 1, (V[]){v_x_249});
    } else {
      heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
      heff_drop(v_x1_246);
      return heff_clo_n(g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam1, 2, 4, (V[]){v_f_241, v_name_243, heff_dup(v_update_240), v_text_244});
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  return v_s_2414;
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam4(V self, V *args) {
  V v_r_2428 = args[0];
  return v_r_2428;
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam6(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_x_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Left: {
    V v_err_2437 = heff_field(v_x_2436, 0);
    V v_ru_24x_2436_24Left = heff_take_reuse_n(v_x_2436, 1ULL, 1);
    V v_t_2438 = heff_tag_at_n(v_ru_24x_2436_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2437})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2438));
  }
  case TAG_Right: {
    V v_x_2439 = heff_field(v_x_2436, 0);
    heff_take_n(v_x_2436, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam6, 2, 1, (V[]){v_x_2439});
  }
  default: return heff_nomatch(v_x_2436);
  }
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_st_2424 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_update_240 = heff_env(self)[3];
  V v_text_244 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_s_2444 = (g_heff_2ebuild_2etesting_2egoldenPath(heff_dup(v_st_2424), heff_dup(v_f_241), heff_dup(v_name_243)));
  HeffT3 v_t_2445 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2424), v_s_2444));
  V v_t_2455;
  {
    V v_field_2446 = v_t_2445.f[0];
    V v_field_2447 = v_t_2445.f[1];
    V v_field_2448 = v_t_2445.f[2];
    V v_d_2449 = v_field_2446;
    V v_a_2450 = v_field_2447;
    V v_xs_2451 = v_field_2448;
    V v_t_2452 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2451));
    V v_xs_2453 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2452; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2452); r_; });
    V v_t_2454 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2453));
    v_t_2455 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2449, v_a_2450, v_t_2454});
  }
  V v_t_2456 = ({ V a_0 = v_st_2424; V a_1 = v_t_2455; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2455); r_; });
  V v_t_2457 = (g_heff_2ebuild_2etesting_2egoldenPath(v_st_2424, v_f_241, v_name_243));
  V v_t_2460;
  switch (heff_tag_of(v_x_2443)) {
  case TAG_Left: {
    heff_take_n(v_x_2443, 0ULL, 1);
    v_t_2460 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2459 = heff_field(v_x_2443, 0);
    V v_ru_24x_2443_24Right = heff_take_reuse_n(v_x_2443, 1ULL, 1);
    v_t_2460 = heff_tag_at_n(v_ru_24x_2443_24Right, TAG_Just, 1, (V[]){v_y_2459});
    break;
  }
  default: heff_nomatch(v_x_2443);
  }
  return ({ V a_0 = v_update_240; V a_1 = v_t_2456; V a_2 = v_t_2457; V a_3 = v_text_244; V a_4 = v_t_2460; V a_5 = v_hd_2412; V a_6 = v_k_2413; V r_ = (g_heff_2ebuild_2etesting_2egoldenAgainst_24s229249986x873006831(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_update_240); r_; });
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_hd_2412 = heff_env(self)[2];
  V v_update_240 = heff_env(self)[3];
  V v_text_244 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2424;
  if (heff_strEq_c(v_x_2423, ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_str7))) {
    v_st_2424 = NTAG(TAG_Windows);
  } else {
    v_st_2424 = NTAG(TAG_Posix);
  }
  V v_s_2425 = (g_heff_2ebuild_2etesting_2egoldenPath(heff_dup(v_st_2424), heff_dup(v_f_241), heff_dup(v_name_243)));
  V v_path_2426 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2425));
  V v_t_2427 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2426; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2426); r_; });
  V v_a_2429 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2427, ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam4_clo)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_c_2442 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam5_clo)));
  V f_ = v_c_2442;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam7, 1, 7, (V[]){v_st_2424, v_f_241, v_name_243, v_update_240, v_text_244, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_f_241 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_update_240 = heff_env(self)[2];
  V v_text_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){v_t_2421}));
  V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
  args[0] = v_t_2422;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116_lam3, 1, 6, (V[]){v_f_241, v_name_243, v_hd_2412, v_update_240, v_text_244, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_str0, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_str1, 1, "\012");
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam4, 4, 0};
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_entry, 4, 0};

V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054(V v_update_240, V v_f_241, V v_o_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_update_240);
    heff_drop(v_f_241);
    return heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam0, 2, 1, (V[]){v_o_242});
  }
  case TAG_Cons: {
    V v_g_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_c_248 = (g_heff_2ebuild_2etesting_2egoldenSaid_24s717915515x1271429116(v_update_240, heff_dup(v_f_241), v_g_246));
    return heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam1, 2, 5, (V[]){v_c_248, v_update_240, v_f_241, v_o_242, v_rest_247});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_o_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_o_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam3(V self, V *args) {
  V v_s_2435 = args[0];
  V v_h_2433 = heff_env(self)[0];
  V v_hd_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2436 = heff_tr(heff_call(v_h_2433, 1, (V[]){v_s_2435}));
  V f_ = v_c_2436;
  heff_room[0] = heff_dup(v_hd_2429);
  heff_room[1] = heff_get_n(v_hd_2429, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_g_2439 = heff_env(self)[0];
  V v_k_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2444 = heff_tr(heff_call(v_g_2439, 1, (V[]){v_x_2443}));
  V f_ = v_k_2442;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam4(V self, V *args) {
  V v_g_2439 = args[0];
  V v_c_2440 = args[1];
  V v_hd_2441 = args[2];
  V v_k_2442 = args[3];
  V f_ = v_c_2440;
  args[0] = v_hd_2441;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam5, 1, 2, (V[]){v_g_2439, v_k_2442});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam7(V self, V *args) {
  V v_x_2447 = args[0];
  V v_g_2445 = heff_env(self)[0];
  V v_hd_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2448 = heff_tr(heff_call(v_g_2445, 1, (V[]){v_x_2447}));
  V f_ = heff_get_n(v_hd_2429, 0, 3);
  args[0] = v_t_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam6(V self, V *args) {
  V v_g_2445 = args[0];
  V v_m_2446 = args[1];
  V v_hd_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2429, 1));
  args[0] = v_m_2446;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam7, 1, 2, (V[]){v_g_2445, v_hd_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam8(V self, V *args) {
  V v_c_2449 = args[0];
  V v_hd_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2449;
  heff_room[0] = heff_dup(v_hd_2429);
  heff_room[1] = heff_get_n(v_hd_2429, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam9(V self, V *args) {
  V v_a_2453 = args[0];
  V v_lit_2414 = heff_env(self)[0];
  V v_lit_2415 = heff_env(self)[1];
  V v_lit_2416 = heff_env(self)[2];
  V v_lit_2417 = heff_env(self)[3];
  V v_lit_2418 = heff_env(self)[4];
  V v_lit_2419 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_a_2453);
  V v_t_2454 = (g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054(v_lit_2414, v_lit_2415, v_lit_2416, v_lit_2417));
  V f_ = v_t_2454;
  heff_room[0] = v_lit_2418;
  heff_room[1] = v_lit_2419;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_update_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_o_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Holds: {
    V v_t_2412 = (g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054(v_update_240, v_f_241, v_o_242, v_rest_247));
    V f_ = v_t_2412;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Wrote: {
    V v_path_2413 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Wrote = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_lit_2414 = v_update_240;
    V v_lit_2415 = v_f_241;
    V v_lit_2416 = v_o_242;
    V v_lit_2417 = v_rest_247;
    V v_lit_2418 = heff_dup(v_hd_249);
    V v_lit_2419 = v_k_2410;
    V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_str0), v_path_2413), ((V)&g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_str1));
    V v_t_2421 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2420, NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Wrote, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    V v_p_2428 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2427});
    V v_hd_2429 = v_hd_249;
    V v_t_2451;
    switch (heff_tag_of(v_p_2428)) {
    case TAG_InL: {
      V v_x_2430 = heff_field(v_p_2428, 0);
      V v_ru_24p_2428_24InL = heff_take_reuse_n(v_p_2428, 1ULL, 1);
      V v_t_2437;
      switch (heff_tag_of(v_x_2430)) {
      case TAG_Throw: {
        V v_s_2431 = heff_field(v_x_2430, 0);
        V v_ru_24x_2430_24Throw = heff_take_reuse_n(v_x_2430, 1ULL, 1);
        v_t_2437 = heff_tag_at_n(v_ru_24x_2430_24Throw, TAG_Throw, 1, (V[]){v_s_2431});
        break;
      }
      case TAG_Catch: {
        V v_c_2432 = heff_field(v_x_2430, 0);
        V v_h_2433 = heff_field(v_x_2430, 1);
        V v_ru_24x_2430_24Catch = heff_take_reuse_n(v_x_2430, 3ULL, 2);
        V v_t_2434 = heff_tr(heff_call(v_c_2432, 2, (V[]){heff_dup(v_hd_2429), heff_dup(heff_rfield(v_hd_2429, 0))}));
        v_t_2437 = heff_tag_at_n(v_ru_24x_2430_24Catch, TAG_Catch, 2, (V[]){v_t_2434, heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam3, 1, 2, (V[]){v_h_2433, heff_dup(v_hd_2429)})});
        break;
      }
      default: heff_nomatch(v_x_2430);
      }
      v_t_2451 = heff_tag_at_n(v_ru_24p_2428_24InL, TAG_InL, 1, (V[]){v_t_2437});
      break;
    }
    case TAG_InR: {
      V v_y_2438 = heff_field(v_p_2428, 0);
      V v_ru_24p_2428_24InR = heff_take_reuse_n(v_p_2428, 1ULL, 1);
      V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam4_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam6, 2, 1, (V[]){heff_dup(v_hd_2429)})}), heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam8, 1, 1, (V[]){heff_dup(v_hd_2429)}), v_y_2438}));
      v_t_2451 = heff_tag_at_n(v_ru_24p_2428_24InR, TAG_InR, 1, (V[]){v_t_2450});
      break;
    }
    default: heff_nomatch(v_p_2428);
    }
    V v_t_2452 = heff_tr(heff_call(heff_take_field(v_hd_2429, 2), 1, (V[]){v_t_2451}));
    V f_ = heff_get_n(v_hd_2429, 1, 3);
    heff_room[0] = v_t_2452;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam9, 1, 6, (V[]){v_lit_2414, v_lit_2415, v_lit_2416, v_lit_2417, v_lit_2418, v_lit_2419});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Wrong: {
    V v_note_2455 = heff_field(v_x_2411, 0);
    V v_why_2456 = heff_field(v_x_2411, 1);
    V v_ru_24x_2411_24Wrong = heff_take_reuse_n(v_x_2411, 3ULL, 2);
    heff_drop(v_update_240);
    heff_drop(v_f_241);
    heff_drop(v_rest_247);
    heff_drop(v_hd_249);
    V v_t_2457 = heff_tag_at_n(v_ru_24x_2411_24Wrong, TAG_Cons, 2, (V[]){v_note_2455, NTAG(TAG_Nil)});
    V v_t_2458 = (g_prelude_2e_2b_2b(heff_take_field(v_o_242, 8), v_t_2457));
    V v_x_2459 = ({ V rv_1 = NTAG(TAG_False); V rv_2 = NTAG(TAG_Nothing); V rv_8 = v_t_2458; V rv_9 = heff_tag_n(TAG_Just, 1, (V[]){v_why_2456}); V rr_ = heff_rec_reuse_nf(v_o_242, 3321ULL, 12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, 15794115u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
    V f_ = v_k_2410;
    args[0] = v_x_2459;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_update_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_o_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054_lam2, 1, 6, (V[]){v_update_240, v_f_241, v_o_242, v_rest_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam2(V self, V *args);
Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_entry, 3, 0};

V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176(V v_update_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_update_240);
    heff_drop(v_f_241);
    return ((V)&g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_dup(heff_rfield(v_o_245, 1));
    V v_c_2410;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_c_2410 = (g_heff_2ebuild_2etesting_2egoldensGo_24s1068484738x909051054(heff_dup(v_update_240), heff_dup(v_f_241), heff_dup(v_o_245), heff_get_n(v_o_245, 11, 12)));
    } else {
      heff_drop(v_t_247);
      v_c_2410 = heff_clo_n(g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam1, 2, 1, (V[]){v_o_245});
    }
    return heff_clo_n(g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam2, 2, 4, (V[]){v_c_2410, v_update_240, v_f_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_o_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_o_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2412 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_update_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2414 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176(v_update_240, v_f_241, v_rest_246));
  V f_ = v_c_2414;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam4, 1, 2, (V[]){v_k_2412, v_x_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_update_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_lam3, 1, 5, (V[]){v_update_240, v_f_241, v_rest_246, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str0, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str1, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str2, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str4, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str7, 8, ", tests ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str8, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str10, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str11, 8, " skipped");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str12, 1, "\012");
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_entry, 6, 0};

V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462(V v_f_240, V v_wrong_241, V v_ts_242, V v_os_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_UseColor, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2412}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam1, 1, 6, (V[]){v_ts_242, v_f_240, v_hd_244, v_os_243, v_wrong_241, v_k_245})});
}
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam0(V self, V *args) {
  V v_b_246 = args[0];
  return v_b_246;
}
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam4(V self, V *args) {
  V v_x_2459 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_wrong_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2459);
  V v_t_2460 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_t_2461 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_242; V r_ = (g_list_2efoldl_24f319030394x1380151895(a_0, a_1, a_2)); heff_drop(v_ts_242); r_; });
  V v_t_2462 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_243));
  V v_t_2463 = (g_list_2efoldl_24f1564248594x622634626(MK_INT(1LL), MK_INT(0LL), v_os_243));
  V v_t_2464 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_os_243; V r_ = (g_list_2efoldl_24f496521120x176206934(a_0, a_1, a_2)); heff_drop(v_os_243); r_; });
  V v_x_2465 = heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), v_t_2460, v_t_2461, v_wrong_241, v_t_2462, v_t_2463, v_t_2464});
  V f_ = v_k_245;
  args[0] = v_x_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_wrong_241 = heff_env(self)[2];
  V v_f_240 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2419);
  V v_x1_2420 = (g_list_2ekeepIf_24s741838803x941779121(heff_dup(v_ts_242)));
  V v_t_2428;
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_Nil: {
    V v_x1_2421 = (g_list_2ekeepIf_24s458067099x815639923(heff_dup(v_os_243)));
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_wrong_241)) {
      case TAG_Nil: {
        v_t_2428 = ((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str0);
        break;
      }
      case TAG_Cons: {
        v_t_2428 = ((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str1);
        break;
      }
      default: heff_nomatch(v_wrong_241);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2421, 0ULL, 2);
      v_t_2428 = ((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str2);
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2420, 0ULL, 2);
    v_t_2428 = ((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str3);
    break;
  }
  default: heff_nomatch(v_x1_2420);
  }
  V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2428, v_f_240), ((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str4));
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_t_2431 = (g_list_2efoldl_24f319030394x1380151895(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_t_2432 = heff_intShow(heff_intSub(v_t_2430, v_t_2431));
  V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2429, v_t_2432), ((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str5));
  V v_t_2434 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_t_2435 = heff_strAppend(v_t_2433, heff_intShow(v_t_2434));
  V v_os_2436 = heff_dup(v_os_243);
  V v_t_2449;
  switch (heff_tag_of(v_os_2436)) {
  case TAG_Nil: {
    v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str6);
    break;
  }
  case TAG_Cons: {
    V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_2436));
    V v_t_2440 = (g_list_2efoldl_24f1564248594x622634626(MK_INT(1LL), MK_INT(0LL), v_os_2436));
    V v_t_2441 = (g_list_2efoldl_24f496521120x176206934(MK_INT(1LL), MK_INT(0LL), v_os_2436));
    V v_t_2442 = heff_intSub(heff_intSub(v_t_2439, v_t_2440), v_t_2441);
    V v_t_2443 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str7), heff_intShow(v_t_2442));
    V v_t_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_2436));
    V v_t_2445 = heff_strAppend(heff_strAppend(v_t_2443, ((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str8)), heff_intShow(v_t_2444));
    V v_n_2446 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_os_2436; V r_ = (g_list_2efoldl_24f496521120x176206934(a_0, a_1, a_2)); heff_drop_tag(v_os_2436, 2); r_; });
    V v_t_2448;
    if (heff_intEq_c_lent(v_n_2446, MK_INT(0LL), 2)) {
      heff_drop(v_n_2446);
      v_t_2448 = ((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str9);
    } else {
      V v_t_2447 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str10), heff_intShow(v_n_2446));
      v_t_2448 = heff_strAppend(v_t_2447, ((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str11));
    }
    v_t_2449 = heff_strAppend(v_t_2445, v_t_2448);
    break;
  }
  default: heff_nomatch(v_os_2436);
  }
  V v_str_2450 = heff_strAppend(v_t_2435, v_t_2449);
  V v_t_2451 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2450, ((V)&g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_str12)), NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})}));
  V f_ = heff_get_n(v_hd_244, 1, 3);
  heff_room[0] = v_t_2458;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam4, 1, 4, (V[]){v_ts_242, v_os_243, v_wrong_241, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_ts_242 = heff_env(self)[3];
  V v_wrong_241 = heff_env(self)[4];
  V v_f_240 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2417);
  V v_c_2418 = (g_heff_2ebuild_2etesting_2eprintOutcomes_24s899797995x642599119(v_x_2414, heff_dup(v_os_243)));
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam3, 1, 6, (V[]){v_ts_242, v_os_243, v_wrong_241, v_f_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_os_243 = heff_env(self)[3];
  V v_wrong_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2415 = (g_list_2ekeepIf_24s741838803x941779121(heff_dup(v_ts_242)));
  V v_c_2416 = (g_heff_2ebuild_2etesting_2eprintFails_24s989015257x334337726(heff_dup(v_f_240), heff_dup(v_x_2414), v_t_2415));
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_lam2, 1, 7, (V[]){v_x_2414, v_os_243, v_hd_244, v_ts_242, v_wrong_241, v_f_240, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427_lam0(V self, V *args);
Clo g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427_entry, 6, 0};

V g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427(V v_opts_240, V v_done_241, V v_x3_242, V v_acc_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_done_241);
    heff_drop(v_z_244);
    return heff_tail(v_z_245, 1, (V[]){v_acc_243});
  }
  case TAG_Cons: {
    V v_r_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_pending_248 = heff_take_field(v_r_246, 1);
    V v_at_249 = heff_get_n(v_r_246, 0, 3);
    V v_p_2410 = v_pending_248;
    V v_file_2411 = heff_take_field(v_p_2410, 0);
    V v_outcomes_2412 = heff_take_field(v_p_2410, 3);
    V v_wrong_2413 = heff_take_field(v_p_2410, 1);
    V v_reports_2414 = heff_get_n(v_p_2410, 2, 7);
    V v_x2_2415 = (g_list_2ekeepIf_24s742867582x682687968(v_at_249, heff_dup(v_done_241)));
    V v_t_2425;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      v_t_2425 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      V v_ru_24x2_2415_24Cons = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
      V v_t_2424;
      switch (heff_tag_of(v_xs_2417)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_2415_24Cons, 2);
        V v_t_2418 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_2416, NTAG(TAG_Nil)});
        v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        V v_y_2419 = heff_field(v_xs_2417, 0);
        V v_ys_2420 = heff_field(v_xs_2417, 1);
        heff_take_n(v_xs_2417, 3ULL, 2);
        V v_t_2421 = (g_heff_2ebuild_2etesting_2eplaceBefore(heff_rfield(v_x_2416, 1), heff_rfield(v_y_2419, 1)));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          V v_t_2422 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_2416, NTAG(TAG_Nil)});
          v_t_2424 = (g_list_2eascending_24s408704122x680527522(heff_dup(v_y_2419), heff_tag_at_n(v_ru_24x2_2415_24Cons, TAG_Cons, 2, (V[]){v_y_2419, v_t_2422}), v_ys_2420));
        } else {
          heff_drop(v_t_2421);
          V v_t_2423 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_2416, NTAG(TAG_Nil)});
          v_t_2424 = (g_list_2edescending_24s604988964x1962429671(heff_dup(v_y_2419), heff_tag_at_n(v_ru_24x2_2415_24Cons, TAG_Cons, 2, (V[]){v_y_2419, v_t_2423}), v_ys_2420));
        }
        break;
      }
      default: heff_nomatch(v_xs_2417);
      }
      v_t_2425 = (g_list_2emergeRuns_24s1264244840x54231393(NTAG(TAG_Nil), v_t_2424));
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    V v_more_2426 = (g_list_2emap_24s1498757180x165099811(v_t_2425));
    V v_t_2427 = (g_prelude_2e_2b_2b(v_outcomes_2412, v_more_2426));
    V v_c_2428 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176(heff_dup(heff_rfield(v_opts_240, 3)), heff_dup(v_file_2411), v_t_2427));
    return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427_lam0, 1, 9, (V[]){v_opts_240, v_acc_243, v_done_241, v_rest_247, v_z_244, v_z_245, v_file_2411, v_wrong_2413, v_reports_2414})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427_lam1(V self, V *args) {
  V v_x_2442 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_opts_240 = heff_env(self)[1];
  V v_done_241 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2443 = (g_heff_2ebuild_2etesting_2eaddRes(v_acc_243, v_x_2442));
  return (g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427(v_opts_240, v_done_241, v_rest_247, v_t_2443, v_z_244, v_z_245));
}
V g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427_lam0(V self, V *args) {
  V v_x_2429 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_done_241 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_file_2411 = heff_env(self)[6];
  V v_wrong_2413 = heff_env(self)[7];
  V v_reports_2414 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2430 = (g_heff_2ebuild_2etesting_2epassedOver(heff_dup(v_opts_240), heff_dup(v_x_2429)));
  if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
    heff_drop(v_x_2429);
    heff_drop(v_file_2411);
    heff_drop(v_wrong_2413);
    heff_drop(v_reports_2414);
    heff_drop(v_t_2430);
    V v_a_2431 = v_acc_243;
    V v_files_2432 = heff_take_field(v_a_2431, 0);
    V v_expectErrors_2433 = heff_take_field(v_a_2431, 1);
    V v_total_2434 = heff_take_field(v_a_2431, 2);
    V v_failed_2435 = heff_take_field(v_a_2431, 3);
    V v_unchecked_2436 = heff_take_field(v_a_2431, 4);
    V v_tests_2437 = heff_take_field(v_a_2431, 5);
    V v_testsFailed_2438 = heff_take_field(v_a_2431, 6);
    V v_testsSkipped_2439 = heff_get_n(v_a_2431, 7, 8);
    V v_t_2440 = (g_prelude_2e_2b_2b(v_unchecked_2436, NTAG(TAG_Nil)));
    V v_t_2441 = heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){heff_intAdd(v_files_2432, MK_INT(0LL)), heff_intAdd(v_expectErrors_2433, MK_INT(0LL)), heff_intAdd(v_total_2434, MK_INT(0LL)), heff_intAdd(v_failed_2435, MK_INT(0LL)), v_t_2440, heff_intAdd(v_tests_2437, MK_INT(0LL)), heff_intAdd(v_testsFailed_2438, MK_INT(0LL)), heff_intAdd(v_testsSkipped_2439, MK_INT(0LL))});
    return (g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427(v_opts_240, v_done_241, v_rest_247, v_t_2441, v_z_244, v_z_245));
  } else {
    heff_drop(v_t_2430);
    return (g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462(v_file_2411, v_wrong_2413, v_reports_2414, v_x_2429, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2ereportReady_24s388452831x652264427_lam1, 1, 6, (V[]){v_acc_243, v_opts_240, v_done_241, v_rest_247, v_z_244, v_z_245})));
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str0, 40, "files that do not check as they should:\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str1, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str3, 27, "heff test: no tests match '");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str4, 1, "'");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str6, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str7, 18, " expectations hold");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str9, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str10, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str12, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str13, 8, " skipped");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str14, 11, " tests hold");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str15, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str16, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str18, 2, " (");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str19, 22, " with expected errors)");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str20, 27, " files check as they should");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str21, 1, "\012");
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam6(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam6, 2, 0};
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam3(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_entry, 4, 0};

V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731(V v_opts_240, V v_acc_241, V v_p_242, V v_p_243) {
top: ;
  V v_ws_244 = heff_dup(heff_rfield(v_acc_241, 4));
  V v_t_2421;
  switch (heff_tag_of(v_ws_244)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam0_clo);
    break;
  }
  case TAG_Cons: {
    v_t_2421 = heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam1, 2, 1, (V[]){v_ws_244});
    break;
  }
  default: heff_nomatch(v_ws_244);
  }
  return heff_tail(v_t_2421, 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam3, 1, 4, (V[]){v_opts_240, v_acc_241, v_p_242, v_p_243})});
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ws_244 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2419);
  V v_t_2420 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str1), v_ws_244));
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(v_t_2420, v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_ws_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tag_n(TAG_Write, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str0), NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_249, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})}));
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  args[0] = v_t_2418;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam2, 1, 3, (V[]){v_ws_244, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_2423 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2423, v_k_2424));
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_opts_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str3), heff_get_n(v_opts_240, 1, 4));
  V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str4)), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str5));
  V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2426, NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2423, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})}));
  V f_ = heff_dup(heff_rfield(v_hd_2423, 1));
  args[0] = v_t_2434;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam5, 1, 2, (V[]){v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam6(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam8(V self, V *args) {
  V v_x_2473 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2473);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_241, 3)))) {
    heff_drop_rec(v_acc_241, 8);
    return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_p_242, v_p_243));
  } else {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_241, 6)))) {
      heff_drop_rec(v_acc_241, 8);
      return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_p_242, v_p_243));
    } else {
      V v_t_2474 = heff_get_n(v_acc_241, 4, 8);
      switch (heff_tag_of(v_t_2474)) {
      case TAG_Nil: {
        heff_drop_rec(v_p_242, 3);
        V f_ = v_p_243;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24t_2474_24Cons = heff_take_reuse_n(v_t_2474, 0ULL, 2);
        return (g_co_2eop_24s40508559x1835373952_24tok2(v_ru_24t_2474_24Cons, MK_INT(1LL), v_p_242, v_p_243));
      }
      default: return heff_nomatch(v_t_2474);
      }
    }
  }
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2439);
  V v_t_2440 = heff_intSub(heff_dup(heff_rfield(v_acc_241, 2)), heff_dup(heff_rfield(v_acc_241, 3)));
  V v_t_2441 = heff_strAppend(heff_intShow(v_t_2440), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str6));
  V v_t_2442 = heff_intShow(heff_dup(heff_rfield(v_acc_241, 2)));
  V v_t_2443 = heff_strAppend(heff_strAppend(v_t_2441, v_t_2442), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str7));
  V v_tests_2444 = heff_dup(heff_rfield(v_acc_241, 5));
  V v_failed_2445 = heff_dup(heff_rfield(v_acc_241, 6));
  V v_skipped_2446 = heff_dup(heff_rfield(v_acc_241, 7));
  V v_t_2452;
  if (heff_intEq_c_lent(v_tests_2444, MK_INT(0LL), 2)) {
    heff_drop(v_tests_2444);
    heff_drop(v_failed_2445);
    heff_drop(v_skipped_2446);
    v_t_2452 = ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str8);
  } else {
    V v_t_2447 = heff_intSub(heff_intSub(heff_dup(v_tests_2444), v_failed_2445), heff_dup(v_skipped_2446));
    V v_t_2448 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str9), heff_intShow(v_t_2447));
    V v_t_2449 = heff_strAppend(heff_strAppend(v_t_2448, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str10)), heff_intShow(v_tests_2444));
    V v_t_2451;
    if (heff_intEq_c_lent(v_skipped_2446, MK_INT(0LL), 2)) {
      heff_drop(v_skipped_2446);
      v_t_2451 = ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str11);
    } else {
      V v_t_2450 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str12), heff_intShow(v_skipped_2446));
      v_t_2451 = heff_strAppend(v_t_2450, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str13));
    }
    v_t_2452 = heff_strAppend(heff_strAppend(v_t_2449, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str14)), v_t_2451);
  }
  V v_r_2453 = heff_dup(v_acc_241);
  V v_files_2454 = heff_take_field(v_r_2453, 0);
  V v_unchecked_2455 = heff_take_field(v_r_2453, 4);
  V v_expectErrors_2456 = heff_get_n(v_r_2453, 1, 8);
  V v_t_2457 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_unchecked_2455; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_unchecked_2455); r_; });
  V v_t_2458 = heff_intShow(heff_intSub(heff_dup(v_files_2454), v_t_2457));
  V v_t_2459 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str15), v_t_2458), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str16));
  V v_t_2460 = heff_strAppend(v_t_2459, heff_intShow(v_files_2454));
  V v_t_2462;
  if (heff_intEq_c_lent(v_expectErrors_2456, MK_INT(0LL), 2)) {
    heff_drop(v_expectErrors_2456);
    v_t_2462 = ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str17);
  } else {
    V v_t_2461 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str18), heff_intShow(v_expectErrors_2456));
    v_t_2462 = heff_strAppend(v_t_2461, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str19));
  }
  V v_t_2463 = heff_strAppend(heff_strAppend(v_t_2460, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str20)), v_t_2462);
  V v_str_2464 = heff_strAppend(heff_strAppend(v_t_2443, v_t_2452), v_t_2463);
  V v_t_2465 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2464, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str21)), NTAG(TAG_MkUnit)});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_242, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})}));
  V f_ = heff_dup(heff_rfield(v_p_242, 1));
  heff_room[0] = v_t_2472;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam8, 1, 3, (V[]){v_acc_241, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2422);
  V v_t_2438;
  if ((heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 1)), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_str2)) ? 0 : heff_intEq_c(heff_dup(heff_rfield(v_acc_241, 5)), MK_INT(0LL)))) {
    v_t_2438 = heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam4, 2, 1, (V[]){v_opts_240});
  } else {
    heff_drop_rec(v_opts_240, 4);
    v_t_2438 = ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam6_clo);
  }
  V f_ = v_t_2438;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_lam7, 1, 3, (V[]){v_acc_241, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}