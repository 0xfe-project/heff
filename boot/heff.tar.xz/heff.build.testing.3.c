// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_Finish 61316
#define TAG_Holds 53574
#define TAG_Inherited 58190
#define TAG_Later 62002
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_MkWith 3751
#define TAG_NotRun 12703
#define TAG_Pend 2230
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Settled 45257
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Wait 10206
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_Wrong 41905
#define TAG_Wrote 42089
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_file 9638467
#define LBL_files 298792593
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_integrations 139286697
#define LBL_jobs 9763101
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_pattern 1588251091
#define LBL_place 308106529
#define LBL_property 1899481104
#define LBL_reports 1326460931
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_update 1108295668
#define LBL_wrong 314763719
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_owner__launch__place__top__path__limit[] = {LBL_owner, LBL_launch, LBL_place, LBL_top, LBL_path, LBL_limit};
static uint32_t shape_seed__pattern__jobs__update[] = {LBL_seed, LBL_pattern, LBL_jobs, LBL_update};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_clo;
V g_heff_2ebuild_2etesting_2eaddRes(V, V);
V g_heff_2ebuild_2etesting_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eaddRes_clo;
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_clo;
V g_heff_2ebuild_2etesting_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_clo;
V g_heff_2ebuild_2etesting_2egoldenPath(V, V, V);
V g_heff_2ebuild_2etesting_2egoldenPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenPath_clo;
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916(V, V, V, V);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_clo;
V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_clo;
V g_heff_2ebuild_2etesting_2elevelsSelected(V, V);
V g_heff_2ebuild_2etesting_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elevelsSelected_clo;
V g_heff_2ebuild_2etesting_2enoRes_get(void);
V g_heff_2ebuild_2etesting_2epassedOver(V, V);
V g_heff_2ebuild_2etesting_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2epassedOver_clo;
V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_clo;
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_clo;
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307_clo;
V g_heff_2ebuild_2etesting_2esubtestJobs(V, V, V, V);
V g_heff_2ebuild_2etesting_2esubtestJobs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2esubtestJobs_clo;
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2esubtestJobs_24dps_clo;
V g_heff_2ebuild_2etesting_2etestArgs(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestArgs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestArgs_clo;
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_clo;
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386(V, V);
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_clo;
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(V, V, V);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_clo;
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_clo;
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287(V, V, V);
V g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287_clo;
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_clo;
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_clo;
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_clo;
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_clo;
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(V, V, V, V);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_clo;
V g_list_2eall_24s1461376987x321850093(V);
V g_list_2eall_24s1461376987x321850093_entry(V self, V *a);
extern Clo g_list_2eall_24s1461376987x321850093_clo;
V g_list_2eany_24s1287956370x756381573(V, V);
V g_list_2eany_24s1287956370x756381573_entry(V self, V *a);
extern Clo g_list_2eany_24s1287956370x756381573_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1300477078x2058851060(V, V);
V g_list_2efoldl_24s1300477078x2058851060_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1300477078x2058851060_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s122741325x871243494(V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_clo;
V g_list_2ekeepIf_24s458067099x815639923(V);
V g_list_2ekeepIf_24s458067099x815639923_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s458067099x815639923_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2einstanceShowString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceShowString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceShowString_2eescapedFrom_241_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2elevelsOf_2ecut_240(V, V, V, V, V, V);
V g_regex_2elevelsOf_2ecut_240_entry(V self, V *a);
extern Clo g_regex_2elevelsOf_2ecut_240_clo;
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(V, V);
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s1454779957x1076453187(V, V, V);
V g_std_2eprocess_2ewithProcess_24s1454779957x1076453187_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1454779957x1076453187_clo;
V g_std_2ereactor_2estart_24s591229604x2094993252(V, V, V, V, V);
V g_std_2ereactor_2estart_24s591229604x2094993252_entry(V self, V *a);
extern Clo g_std_2ereactor_2estart_24s591229604x2094993252_clo;

static V g_heff_2ebuild_2etesting_2enoRes_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2enoRes_st;
static V g_heff_2ebuild_2etesting_2enoRes_init(void) {
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2ebuild_2etesting_2enoRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2enoRes_st)) return g_heff_2ebuild_2etesting_2enoRes_val;
  return heff_global(&g_heff_2ebuild_2etesting_2enoRes_val, &g_heff_2ebuild_2etesting_2enoRes_st, g_heff_2ebuild_2etesting_2enoRes_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eexpectErrorsLine_str0, 22, "-- test: expect errors");

static V g_heff_2ebuild_2etesting_2eexpectErrorsLine_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2eexpectErrorsLine_st;
static V g_heff_2ebuild_2etesting_2eexpectErrorsLine_init(void) {
  return ((V)&g_heff_2ebuild_2etesting_2eexpectErrorsLine_str0);
}
V g_heff_2ebuild_2etesting_2eexpectErrorsLine_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2eexpectErrorsLine_st)) return g_heff_2ebuild_2etesting_2eexpectErrorsLine_val;
  return heff_global(&g_heff_2ebuild_2etesting_2eexpectErrorsLine_val, &g_heff_2ebuild_2etesting_2eexpectErrorsLine_st, g_heff_2ebuild_2etesting_2eexpectErrorsLine_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenPath_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenPath_str1, 7, ".golden");
Clo g_heff_2ebuild_2etesting_2egoldenPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenPath_entry, 3, 0};

V g_heff_2ebuild_2etesting_2egoldenPath(V v_st_240, V v_f_241, V v_name_242) {
top: ;
  int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
  V v_t_244 = heff_strSlice(heff_dup(v_f_241), heff_box_word(v_t_243), heff_strLength_lent(v_f_241, 0));
  V v_t_246;
  if (heff_strEq_c(v_t_244, ((V)&g_heff_2ebuild_2etesting_2egoldenPath_str0))) {
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
    v_t_246 = heff_strSlice(v_f_241, MK_INT(0LL), heff_box_word(v_t_245));
  } else {
    v_t_246 = v_f_241;
  }
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2etesting_2egoldenPath_str1))));
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_name_242));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  return ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_249); r_; });
}
V g_heff_2ebuild_2etesting_2egoldenPath_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2egoldenPath(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2esubtestJobs_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2etesting_2esubtestJobs_str1, 3, " / ");
Clo g_heff_2ebuild_2etesting_2esubtestJobs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2esubtestJobs_entry, 4, 0};

V g_heff_2ebuild_2etesting_2esubtestJobs(V v_sel_240, V v_j_241, V v_k_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_j_241, 6);
    heff_drop(v_k_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_n_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_n_244), NTAG(TAG_Nil)});
    V v_s_247 = heff_dup(heff_rfield(v_j_241, 3));
    V v_t_248 = ({ V a_0 = v_s_247; V b_1 = ((V)&g_heff_2ebuild_2etesting_2esubtestJobs_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2esubtestJobs_str1), v_s_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_247); heff_drop(b_1); r_; });
    V v_t_249 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_t_246, v_t_248, heff_dup(heff_rfield(v_j_241, 4))));
    V v_t_2410 = ({ V a_0 = v_sel_240; V a_1 = v_t_249; V r_ = (g_heff_2ebuild_2etesting_2elevelsSelected(a_0, a_1)); heff_drop(v_t_249); r_; });
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_k_242), NTAG(TAG_Nil)});
      V v_t_2412 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 2)), v_t_2411));
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_244, NTAG(TAG_Nil)});
      V v_t_2414 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 4)), v_t_2413));
      V v_t_2415 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(heff_rfield(v_j_241, 0)), heff_dup(heff_rfield(v_j_241, 1)), v_t_2412, heff_dup(heff_rfield(v_j_241, 3)), v_t_2414, heff_dup(heff_rfield(v_j_241, 5))});
      V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
      V v_u_2417 = (g_heff_2ebuild_2etesting_2esubtestJobs_24dps(v_sel_240, v_j_241, heff_intAdd(v_k_242, MK_INT(1LL)), v_rest_245, heff_dup(v_cell_2416)));
      heff_drop(v_u_2417);
      return v_cell_2416;
    } else {
      heff_drop(v_n_244);
      heff_drop(v_t_2410);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_245;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2etesting_2esubtestJobs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2etesting_2esubtestJobs(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2etesting_2epassedOver_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2epassedOver_str1, 0, "");
Clo g_heff_2ebuild_2etesting_2epassedOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2epassedOver_entry, 2, 0};

V g_heff_2ebuild_2etesting_2epassedOver(V v_opts_240, V v_os_241) {
top: ;
  if (!heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 1)), ((V)&g_heff_2ebuild_2etesting_2epassedOver_str0))) {
    V v_x1_242 = (g_list_2ekeepIf_24s458067099x815639923(heff_dup(v_os_241)));
    switch (heff_tag_of(v_x1_242)) {
    case TAG_Nil: {
      V v_p_243 = heff_get_n(v_opts_240, 1, 4);
      V v_t_2411;
      if (heff_strEq_c_lent(v_p_243, ((V)&g_heff_2ebuild_2etesting_2epassedOver_str1), 2)) {
        heff_drop(v_p_243);
        v_t_2411 = NTAG(TAG_Nil);
      } else {
        V v_t_244 = ({ V a_0 = v_p_243; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_False); V a_4 = MK_INT(0LL); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2elevelsOf_2ecut_240(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_243); r_; });
        V v_t_245 = (g_list_2emap_24s1007499915x73800978(v_t_244));
        HeffT2 v_t_246 = (g_regex_2eallRead_24cpr(v_t_245));
        {
          V v_field_248 = v_t_246.f[1];
          int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
          if ((v_tag_247 == ((int64_t)0ULL))) {
            V v_why_249 = v_field_248;
            heff_drop(v_why_249);
            v_t_2411 = NTAG(TAG_Nil);
          } else {
            V v_sel_2410 = v_field_248;
            v_t_2411 = v_sel_2410;
          }
        }
      }
      V v_x1_2412 = ({ V a_0 = v_t_2411; V a_1 = v_os_241; V r_ = (g_list_2eany_24s1287956370x756381573(a_0, a_1)); heff_drop(v_os_241); r_; });
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2412) == NTAG(TAG_True)));
      heff_drop(v_x1_2412);
      return v_ret_24bool;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_242, 0ULL, 2);
      heff_drop_rec(v_opts_240, 4);
      heff_drop(v_os_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_242);
    }
  } else {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_os_241);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2etesting_2epassedOver_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2epassedOver(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestArgs_str0, 6, "--seed");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestArgs_str1, 5, "--run");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestArgs_str2, 6, "--jobs");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestArgs_str3, 4, "test");
Clo g_heff_2ebuild_2etesting_2etestArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestArgs_entry, 4, 0};

V g_heff_2ebuild_2etesting_2etestArgs(V v_seed_240, V v_pattern_241, V v_jobs_242, V v_given_243) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_244 = heff_field(v_seed_240, 0);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_244), NTAG(TAG_Nil)});
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestArgs_str0), v_t_245});
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_249;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_247 = heff_field(v_pattern_241, 0);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_247), NTAG(TAG_Nil)});
    v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestArgs_str1), v_t_248});
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_2412;
  switch (heff_tag_of(v_jobs_242)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_2410 = heff_field(v_jobs_242, 0);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_2410), NTAG(TAG_Nil)});
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestArgs_str2), v_t_2411});
    break;
  }
  default: heff_nomatch(v_jobs_242);
  }
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_given_243));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_249, v_t_2413));
  V v_t_2415 = (g_prelude_2e_2b_2b(v_t_246, v_t_2414));
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestArgs_str3), v_t_2415});
}
V g_heff_2ebuild_2etesting_2etestArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2etesting_2etestArgs(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_str3, 1, ".");
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam1(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam1, 1, 0};
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam5(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam5, 1, 0};
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam7(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam7, 2, 0};
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam8(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam8, 3, 0};
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam10(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam12(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam11(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam3(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_entry, 3, 0};

V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(V v_e_240, V v_x1_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    V v_x_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam0, 2, 1, (V[]){v_x_243});
  }
  case TAG_Cons: {
    V v_x11_246 = heff_field(v_x1_241, 0);
    V v_rest_247 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_MkPair: {
      V v_top_248 = heff_field(v_x11_246, 0);
      V v_p_249 = heff_field(v_x11_246, 1);
      heff_take_n(v_x11_246, 3ULL, 2);
      V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_249)));
      V v_c_2411 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_2410));
      V v_t_2412 = (g_exception_2eattempted(heff_dup(v_e_240)));
      V v_c_2417 = heff_tr(heff_call(v_c_2411, 2, (V[]){v_t_2412, ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam1_clo)}));
      return heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam3, 2, 6, (V[]){v_c_2417, v_e_240, v_p_249, v_rest_247, v_acc_242, v_top_248});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_x_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2414 = (g_list_2emap_24s219049803x1458391381(v_x_2413));
  return heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam2, 2, 1, (V[]){v_x_2414});
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam5(V self, V *args) {
  V v_s_2421 = args[0];
  return v_s_2421;
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam7(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_hd_2450 = args[1];
  V v_k_2451 = args[2];
  heff_drop(v_hd_2450);
  V f_ = v_k_2451;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2449});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam10(V self, V *args) {
  V v_x_2455 = args[0];
  V v_k_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2455)) {
  case TAG_Left: {
    heff_take_n(v_x_2455, 0ULL, 1);
    V f_ = v_k_2454;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2455, 0ULL, 1);
    V f_ = v_k_2454;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2455);
  }
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam9(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  V v_c_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2452;
  args[0] = v_hd_2453;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam10, 1, 1, (V[]){v_k_2454});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam12(V self, V *args) {
  V v_n_2462 = args[0];
  V v_st_2430 = heff_env(self)[0];
  V v_p_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463 = (g_std_2epath_2eparse(heff_dup(v_st_2430), v_p_249));
  V v_t_2464 = (g_std_2epath_2eparse(heff_dup(v_st_2430), v_n_2462));
  V v_t_2465 = (g_std_2epath_2ejoin(v_t_2463, v_t_2464));
  V v_t_2466 = ({ V a_0 = v_st_2430; V a_1 = v_t_2465; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2430); heff_drop(v_t_2465); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_t_2466});
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam11(V self, V *args) {
  V v_x_2459 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_rest_247 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_hd_2418 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  V v_y_2436 = heff_env(self)[5];
  V v_st_2430 = heff_env(self)[6];
  V v_p_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  if ((heff_dup(v_x_2459) == NTAG(TAG_True))) {
    heff_drop(v_x_2459);
    heff_drop(v_y_2436);
    heff_drop(v_st_2430);
    heff_drop(v_p_249);
    V v_t_2460 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(v_e_240, v_rest_247, v_acc_242));
    V f_ = v_t_2460;
    heff_room[0] = v_hd_2418;
    heff_room[1] = v_k_2419;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2459);
    V v_t_2461 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_str3); V a_3 = v_y_2436; V r_ = (g_list_2ekeepIf_24s122741325x871243494(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
    V v_t_2467 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_247, heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam12, 1, 2, (V[]){v_st_2430, v_p_249}), v_t_2461));
    V v_t_2468 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(v_e_240, v_t_2467, v_acc_242));
    V f_ = v_t_2468;
    heff_room[0] = v_hd_2418;
    heff_room[1] = v_k_2419;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_p_249 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_acc_242 = heff_env(self)[4];
  V v_hd_2418 = heff_env(self)[5];
  V v_k_2419 = heff_env(self)[6];
  V v_top_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_st_2430;
  if (heff_strEq_c(v_x_2429, ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_str0))) {
    v_st_2430 = NTAG(TAG_Windows);
  } else {
    v_st_2430 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    heff_take_n(v_x_2420, 0ULL, 1);
    heff_drop(v_top_248);
    heff_drop(v_st_2430);
    int64_t v_t_2432 = (heff_unbox_word(heff_strLength_lent(v_p_249, 0)) - ((int64_t)3ULL));
    V v_t_2433 = heff_strSlice(heff_dup(v_p_249), heff_box_word(v_t_2432), heff_strLength_lent(v_p_249, 0));
    if (heff_strEq_c(v_t_2433, ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_str1))) {
      V v_t_2434 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(v_e_240, v_rest_247, heff_tag_n(TAG_Cons, 2, (V[]){v_p_249, v_acc_242})));
      V f_ = v_t_2434;
      heff_room[0] = v_hd_2418;
      heff_room[1] = v_k_2419;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_249);
      V v_t_2435 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(v_e_240, v_rest_247, v_acc_242));
      V f_ = v_t_2435;
      heff_room[0] = v_hd_2418;
      heff_room[1] = v_k_2419;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Right: {
    V v_y_2436 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    V v_c_2458;
    if ((heff_dup(v_top_248) == NTAG(TAG_True))) {
      heff_drop(v_top_248);
      v_c_2458 = ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam7_clo);
    } else {
      heff_drop(v_top_248);
      V v_e_2439 = heff_dup(v_e_240);
      V v_st_2440 = heff_dup(v_st_2430);
      V v_d_2441 = heff_dup(v_p_249);
      V v_t_2442 = (g_std_2epath_2eparse(heff_dup(v_st_2440), v_d_2441));
      V v_t_2443 = (g_std_2epath_2eparse(heff_dup(v_st_2440), ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_str2)));
      V v_t_2444 = (g_std_2epath_2ejoin(v_t_2442, v_t_2443));
      V v_s_2445 = ({ V a_0 = v_st_2440; V a_1 = v_t_2444; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2440); heff_drop(v_t_2444); r_; });
      V v_path_2446 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2445));
      V v_c_2447 = ({ V a_0 = heff_dup(v_e_2439); V a_1 = v_path_2446; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2446); r_; });
      V v_t_2448 = (g_exception_2eattempted(v_e_2439));
      V v_c_2452 = heff_tr(heff_call(v_c_2447, 2, (V[]){v_t_2448, ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam8_clo)}));
      v_c_2458 = heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam9, 2, 1, (V[]){v_c_2452});
    }
    V f_ = v_c_2458;
    heff_room[0] = heff_dup(v_hd_2418);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam11, 1, 8, (V[]){v_e_240, v_rest_247, v_acc_242, v_hd_2418, v_k_2419, v_y_2436, v_st_2430, v_p_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2418 = heff_env(self)[1];
  V v_p_249 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_acc_242 = heff_env(self)[4];
  V v_k_2419 = heff_env(self)[5];
  V v_top_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam5_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2428, heff_dup(v_hd_2418), heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam6, 1, 8, (V[]){v_x_2420, v_p_249, v_e_240, v_rest_247, v_acc_242, v_hd_2418, v_k_2419, v_top_248})));
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_249 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_acc_242 = heff_env(self)[4];
  V v_top_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_lam4, 1, 7, (V[]){v_e_240, v_hd_2418, v_p_249, v_rest_247, v_acc_242, v_k_2419, v_top_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str1, 4, "test");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str2, 3, "src");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str3, 77, "heff test: no src/ nor test/ here: test at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str4, 3, "src");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str5, 4, "test");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str6, 77, "heff test: no src/ nor test/ here: test at the project's root, or give FILEs\012");
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam4, 1, 0};
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam10(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam2(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_entry, 2, 0};

V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386(V v_e_240, V v_given_241) {
top: ;
  switch (heff_tag_of(v_given_241)) {
  case TAG_Nil: {
    V v_path_242 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str0)));
    V v_c_243 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_242));
    V v_t_244 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_249 = heff_tr(heff_call(v_c_243, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam0_clo)}));
    return heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam2, 2, 2, (V[]){v_c_249, v_e_240});
  }
  case TAG_Cons: {
    V v_t_2476 = (g_list_2emap_24s1420651609x666245096(v_given_241));
    return (g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(v_e_240, v_t_2476, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_241);
  }
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386(a[0], a[1]);
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_246 = (g_list_2emap_24s219049803x1458391381(v_x_245));
  return heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam1, 2, 1, (V[]){v_x_246});
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2420 = (g_list_2emap_24s219049803x1458391381(v_x_2419));
  return heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam5, 2, 1, (V[]){v_x_2420});
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam8(V self, V *args) {
  V v_x_2444 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2444);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam7(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), v_hd_2410, heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam8, 1, 1, (V[]){v_k_2411})));
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam10(V self, V *args) {
  V v_x_2469 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2469);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam9(V self, V *args) {
  V v_x_2461 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2461);
  V v_t_2462 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2468}), v_hd_2410, heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam10, 1, 1, (V[]){v_k_2411})));
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_ru_24x_2424_24Left = heff_take_reuse_n(v_x_2424, 0ULL, 1);
    V v_t_2427;
    switch (heff_tag_of(v_x_2415)) {
    case TAG_Nothing: {
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x_2415, 0ULL, 1);
      v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str2), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_x_2415);
    }
    V v_it_2428 = (g_prelude_2e_2b_2b(v_t_2427, NTAG(TAG_Nil)));
    switch (heff_tag_of(v_it_2428)) {
    case TAG_Nil: {
      V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str3), NTAG(TAG_MkUnit)});
      V v_t_2430 = heff_tag_at_n(v_ru_24x_2424_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam7, 1, 3, (V[]){v_e_240, v_hd_2410, v_k_2411})));
    }
    case TAG_Cons: {
      heff_drop_cell(v_ru_24x_2424_24Left, 1);
      V v_t_2447 = (g_list_2emap_24s1420651609x666245096(v_it_2428));
      V v_t_2448 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(v_e_240, v_t_2447, NTAG(TAG_Nil)));
      V f_ = v_t_2448;
      heff_room[0] = v_hd_2410;
      heff_room[1] = v_k_2411;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it_2428);
    }
  }
  case TAG_Right: {
    V v_ru_24x_2424_24Right = heff_take_reuse_n(v_x_2424, 0ULL, 1);
    V v_t_2451;
    switch (heff_tag_of(v_x_2415)) {
    case TAG_Nothing: {
      v_t_2451 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x_2415, 0ULL, 1);
      v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str4), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_x_2415);
    }
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str5), NTAG(TAG_Nil)});
    V v_it_2453 = (g_prelude_2e_2b_2b(v_t_2451, v_t_2452));
    switch (heff_tag_of(v_it_2453)) {
    case TAG_Nil: {
      V v_t_2454 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str6), NTAG(TAG_MkUnit)});
      V v_t_2455 = heff_tag_at_n(v_ru_24x_2424_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
      V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
      V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam9, 1, 3, (V[]){v_e_240, v_hd_2410, v_k_2411})));
    }
    case TAG_Cons: {
      heff_drop_cell(v_ru_24x_2424_24Right, 1);
      V v_t_2472 = (g_list_2emap_24s1420651609x666245096(v_it_2453));
      V v_t_2473 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(v_e_240, v_t_2472, NTAG(TAG_Nil)));
      V f_ = v_t_2473;
      heff_room[0] = v_hd_2410;
      heff_room[1] = v_k_2411;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it_2453);
    }
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2415;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    heff_take_n(v_x_2412, 0ULL, 1);
    v_x_2415 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2414 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Right = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    v_x_2415 = heff_tag_at_n(v_ru_24x_2412_24Right, TAG_Just, 1, (V[]){v_y_2414});
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_path_2416 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_str1)));
  V v_c_2417 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_2416));
  V v_t_2418 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2423 = heff_tr(heff_call(v_c_2417, 2, (V[]){v_t_2418, ((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam4_clo)}));
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_2410);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam6, 1, 4, (V[]){v_x_2415, v_e_240, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam2(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_lam3, 1, 3, (V[]){v_e_240, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str0, 36, "\012heff test: a change; tested again\012\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str1, 19, "heff test: tested (");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str2, 3, "), ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str3, 8, "all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str4, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str5, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str6, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str7, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str8, 33, "; tested again at the next change");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str10, 60, "heff test: cannot run heff; tested again at the next change\012");
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam4, 1, 0};
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam11(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam10(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam12(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_entry, 5, 0};

V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274(V v_e_240, V v_argv_241, V v_n_242, V v_p_243, V v_p_244) {
top: ;
  V v_t_2414;
  if (heff_intEq_c_lent(v_n_242, MK_INT(0LL), 2)) {
    v_t_2414 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam0_clo);
  } else {
    V v_t_247 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str0), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    v_t_2414 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})}));
  }
  return heff_tail(v_t_2414, 2, (V[]){heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam1, 1, 5, (V[]){v_e_240, v_p_243, v_argv_241, v_n_242, v_p_244})});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam4(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam3(V self, V *args) {
  V v_p_2418 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420;
  switch (heff_tag_of(v_p_2418)) {
  case TAG_MkWith: {
    V v_x_2419 = heff_field(v_p_2418, 0);
    heff_take_n(v_p_2418, 1ULL, 1);
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_p_2418);
  }
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Wait, 2, (V[]){v_t_2420, ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam4_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V f_ = ((V)&g_co_2eop_24s310169282x2049378029_clo);
  heff_room[0] = v_e_240;
  heff_room[1] = v_t_2428;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_hd_2450 = args[1];
  V v_k_2451 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2449);
  heff_drop(v_hd_2450);
  V f_ = v_k_2451;
  args[0] = heff_intAdd(v_n_242, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam7(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_2431 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2448);
  V f_ = v_k_2431;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam8, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2430 = heff_env(self)[2];
  V v_k_2431 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2433 = heff_intShow(heff_intAdd(heff_dup(v_n_242), MK_INT(1LL)));
  V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str1), v_t_2433), ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str2));
  V v_t_2435 = heff_get_n(v_x_2432, 0, 3);
  V v_t_2439;
  switch (heff_tag_of(v_t_2435)) {
  case TAG_Exited: {
    V v_n_2436 = heff_field(v_t_2435, 0);
    heff_take_n(v_t_2435, 1ULL, 1);
    if (heff_intEq_c(v_n_2436, MK_INT(0LL))) {
      v_t_2439 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str3);
    } else {
      v_t_2439 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str4);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2439 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str5);
    break;
  }
  case TAG_TimedOut: {
    v_t_2439 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str6);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2439 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str7);
    break;
  }
  default: heff_nomatch(v_t_2435);
  }
  V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2434, v_t_2439), ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str8));
  V v_t_2441 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str9)), NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), v_hd_2430, heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam7, 1, 2, (V[]){v_k_2431, v_n_242})));
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam5(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_c_2429 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2429;
  args[0] = heff_dup(v_hd_2430);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam6, 1, 4, (V[]){v_n_242, v_e_240, v_hd_2430, v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam11(V self, V *args) {
  V v_x_2463 = args[0];
  V v_hd_2464 = args[1];
  V v_k_2465 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2463);
  heff_drop(v_hd_2464);
  V f_ = v_k_2465;
  args[0] = heff_intAdd(v_n_242, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam10(V self, V *args) {
  V v_x_2462 = args[0];
  V v_k_2454 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2462);
  V f_ = v_k_2454;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam11, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam9(V self, V *args) {
  V v_err_2452 = args[0];
  V v_hd_2453 = args[1];
  V v_k_2454 = args[2];
  V v_e_240 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_err_2452);
  V v_t_2455 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_str10), NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2460})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2461}), v_hd_2453, heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam10, 1, 2, (V[]){v_k_2454, v_n_242})));
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam12(V self, V *args) {
  V v_x_2467 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2467;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_p_243;
  heff_room[2] = v_p_244;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_argv_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2416, v_argv_241, heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_c_2429 = (g_std_2eprocess_2ewithProcess_24s1454779957x1076453187(heff_dup(v_e_240), v_t_2417, heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam3, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam5, 2, 3, (V[]){v_c_2429, heff_dup(v_n_242), heff_dup(v_e_240)}), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam9, 3, 2, (V[]){heff_dup(v_e_240), v_n_242})})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2466}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam12, 1, 2, (V[]){v_p_243, v_p_244})));
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_argv_241 = heff_env(self)[2];
  V v_n_242 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2415);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(heff_dup(v_e_240), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1496497907x535344274_lam2, 1, 5, (V[]){v_argv_241, v_e_240, v_n_242, v_p_243, v_p_244})));
}
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam1(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam1, 1, 0};
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam5(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam5, 1, 0};
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam4, 1, 0};
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam6(V self, V *args);
Clo g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_entry, 9, 0};

V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437(V v_lit_240, V v_e_241, V v_sel_242, V v_jobs_243, V v_x4_244, V v_pending_245, V v_done_246, V v_p_247, V v_p_248) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    if (heff_intEq_c_lent(v_pending_245, MK_INT(0LL), 2)) {
      heff_drop(v_lit_240);
      heff_drop(v_e_241);
      heff_drop(v_sel_242);
      heff_drop(v_jobs_243);
      heff_drop(v_pending_245);
      heff_drop(v_p_247);
      return heff_tail(v_p_248, 1, (V[]){v_done_246});
    } else {
      V v_t_2411 = heff_tag_n(TAG_Finish, 3, (V[]){heff_dup(v_lit_240), NTAG(TAG_True), ((V)&g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam0_clo)});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_241), heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam2, 1, 8, (V[]){v_done_246, v_lit_240, v_e_241, v_sel_242, v_jobs_243, v_pending_245, v_p_247, v_p_248})));
    }
  }
  case TAG_Cons: {
    V v_j_2419 = heff_field(v_x4_244, 0);
    V v_rest_2420 = heff_field(v_x4_244, 1);
    heff_take_n(v_x4_244, 3ULL, 2);
    if (heff_intLt_c_lent(v_pending_245, v_jobs_243, 0)) {
      V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_clo), 3, (V[]){heff_dup(v_e_241), heff_dup(v_sel_242), v_j_2419}));
      V v_c_2422 = heff_tr(heff_call(((V)&g_std_2ereactor_2estart_24s591229604x2094993252_clo), 3, (V[]){heff_dup(v_lit_240), heff_dup(v_e_241), v_t_2421}));
      return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam3, 1, 9, (V[]){v_lit_240, v_e_241, v_sel_242, v_jobs_243, v_rest_2420, v_pending_245, v_done_246, v_p_247, v_p_248})});
    } else {
      V v_t_2428 = heff_tag_n(TAG_Finish, 3, (V[]){heff_dup(v_lit_240), NTAG(TAG_True), ((V)&g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam4_clo)});
      V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
      V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_241), heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam6, 1, 10, (V[]){v_rest_2420, v_done_246, v_lit_240, v_e_241, v_sel_242, v_jobs_243, v_j_2419, v_pending_245, v_p_247, v_p_248})));
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam1(V self, V *args) {
  V v_l_2410 = args[0];
  return v_l_2410;
}
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam0(V self, V *args) {
  V v_use_249 = args[0];
  V f_ = v_use_249;
  args[0] = ((V)&g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam1_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_done_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_sel_242 = heff_env(self)[3];
  V v_jobs_243 = heff_env(self)[4];
  V v_pending_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  V v_p_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_x_2414)));
  V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s1300477078x2058851060(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2414));
  V v_t_2418 = (g_prelude_2e_2b_2b(v_x_2414, v_done_246));
  return (g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437(v_lit_240, v_e_241, v_sel_242, v_jobs_243, v_t_2416, heff_intSub(v_pending_245, v_t_2417), v_t_2418, v_p_247, v_p_248));
}
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_sel_242 = heff_env(self)[2];
  V v_jobs_243 = heff_env(self)[3];
  V v_rest_2420 = heff_env(self)[4];
  V v_pending_245 = heff_env(self)[5];
  V v_done_246 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  V v_p_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Nothing: {
    return (g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437(v_lit_240, v_e_241, v_sel_242, v_jobs_243, v_rest_2420, heff_intAdd(v_pending_245, MK_INT(1LL)), v_done_246, v_p_247, v_p_248));
  }
  case TAG_Just: {
    V v_f_2424 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    V v_t_2425 = (g_prelude_2e_2b_2b(v_rest_2420, heff_dup(heff_rfield(v_f_2424, 3))));
    return (g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437(v_lit_240, v_e_241, v_sel_242, v_jobs_243, v_t_2425, v_pending_245, heff_tag_n(TAG_Cons, 2, (V[]){v_f_2424, v_done_246}), v_p_247, v_p_248));
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam5(V self, V *args) {
  V v_l_2427 = args[0];
  return v_l_2427;
}
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam4(V self, V *args) {
  V v_use_2426 = args[0];
  V f_ = v_use_2426;
  args[0] = ((V)&g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam5_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_rest_2420 = heff_env(self)[0];
  V v_done_246 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_e_241 = heff_env(self)[3];
  V v_sel_242 = heff_env(self)[4];
  V v_jobs_243 = heff_env(self)[5];
  V v_j_2419 = heff_env(self)[6];
  V v_pending_245 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  V v_p_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_x_2431)));
  V v_ys_2433 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2432; V r_ = (g_list_2efoldl_24s1300477078x2058851060(a_0, a_1)); heff_drop(v_t_2432); r_; });
  V v_t_2434 = (g_prelude_2e_2b_2b(v_rest_2420, v_ys_2433));
  V v_t_2435 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2431));
  V v_t_2436 = (g_prelude_2e_2b_2b(v_x_2431, v_done_246));
  return (g_heff_2ebuild_2etesting_2erunJobs_24s618214124x1716549437(v_lit_240, v_e_241, v_sel_242, v_jobs_243, heff_tag_n(TAG_Cons, 2, (V[]){v_j_2419, v_t_2434}), heff_intSub(v_pending_245, v_t_2435), v_t_2436, v_p_247, v_p_248));
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str3, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str4, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str5, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str6, 112, "a golden text's name is a file's under the directory: letters, digits, `-`, `_` and `.`, not first, between `/`s");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str7, 5, "win32");
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam4, 3, 0};
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_entry, 4, 0};

V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916(V v_e_240, V v_update_241, V v_f_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_MkPair: {
    V v_name_244 = heff_field(v_x3_243, 0);
    V v_text_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24MkPair = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_t_246 = ({ V a_0 = v_name_244; V b_1 = ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str1), v_name_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    V v_x1_247 = ({ V a_0 = v_t_246; V r_ = (g_list_2eall_24s1461376987x321850093(a_0)); heff_drop(v_t_246); r_; });
    if (!(heff_dup(v_x1_247) == NTAG(TAG_True))) {
      heff_drop(v_e_240);
      heff_drop(v_f_242);
      heff_drop(v_text_245);
      heff_drop(v_x1_247);
      V v_t_248 = ({ V a_0 = v_name_244; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str2); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_name_244); r_; });
      V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str3), v_t_248), ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str4));
      V v_x_2410 = heff_tag_at_n(v_ru_24x3_243_24MkPair, TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str5), v_t_249), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str6)})});
      return heff_clo_n(g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam0, 2, 1, (V[]){v_x_2410});
    } else {
      heff_drop_cell(v_ru_24x3_243_24MkPair, 2);
      heff_drop(v_x1_247);
      return heff_clo_n(g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam1, 2, 5, (V[]){v_e_240, v_f_242, v_name_244, heff_dup(v_update_241), v_text_245});
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam2(V self, V *args) {
  V v_s_2415 = args[0];
  return v_s_2415;
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2430 = args[1];
  V v_k_2431 = args[2];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_st_2424 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_name_244 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_update_241 = heff_env(self)[4];
  V v_text_245 = heff_env(self)[5];
  V v_hd_2413 = heff_env(self)[6];
  V v_k_2414 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_s_2434 = (g_heff_2ebuild_2etesting_2egoldenPath(heff_dup(v_st_2424), heff_dup(v_f_242), heff_dup(v_name_244)));
  HeffT3 v_t_2435 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2424), v_s_2434));
  V v_t_2445;
  {
    V v_field_2436 = v_t_2435.f[0];
    V v_field_2437 = v_t_2435.f[1];
    V v_field_2438 = v_t_2435.f[2];
    V v_d_2439 = v_field_2436;
    V v_a_2440 = v_field_2437;
    V v_xs_2441 = v_field_2438;
    V v_t_2442 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2441));
    V v_xs_2443 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2442; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2442); r_; });
    V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2443));
    v_t_2445 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2439, v_a_2440, v_t_2444});
  }
  V v_t_2446 = ({ V a_0 = v_st_2424; V a_1 = v_t_2445; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2445); r_; });
  V v_t_2447 = (g_heff_2ebuild_2etesting_2egoldenPath(v_st_2424, v_f_242, v_name_244));
  V v_t_2450;
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    heff_take_n(v_x_2433, 0ULL, 1);
    v_t_2450 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2449 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Right = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    v_t_2450 = heff_tag_at_n(v_ru_24x_2433_24Right, TAG_Just, 1, (V[]){v_y_2449});
    break;
  }
  default: heff_nomatch(v_x_2433);
  }
  return ({ V a_0 = v_e_240; V a_1 = v_update_241; V a_2 = v_t_2446; V a_3 = v_t_2447; V a_4 = v_text_245; V a_5 = v_t_2450; V a_6 = v_hd_2413; V a_7 = v_k_2414; V r_ = (g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_update_241); r_; });
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_name_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_update_241 = heff_env(self)[4];
  V v_text_245 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2424;
  if (heff_strEq_c(v_x_2423, ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_str7))) {
    v_st_2424 = NTAG(TAG_Windows);
  } else {
    v_st_2424 = NTAG(TAG_Posix);
  }
  V v_s_2425 = (g_heff_2ebuild_2etesting_2egoldenPath(heff_dup(v_st_2424), heff_dup(v_f_242), heff_dup(v_name_244)));
  V v_path_2426 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2425));
  V v_c_2427 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2426; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2426); r_; });
  V v_t_2428 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2432 = heff_tr(heff_call(v_c_2427, 2, (V[]){v_t_2428, ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam4_clo)}));
  V f_ = v_c_2432;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam5, 1, 8, (V[]){v_st_2424, v_f_242, v_name_244, v_e_240, v_update_241, v_text_245, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_name_244 = heff_env(self)[2];
  V v_update_241 = heff_env(self)[3];
  V v_text_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam2_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2422, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916_lam3, 1, 7, (V[]){v_f_242, v_name_244, v_e_240, v_hd_2413, v_update_241, v_text_245, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_str0, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_str1, 1, "\012");
V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_entry, 5, 0};

V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454(V v_e_240, V v_update_241, V v_f_242, V v_o_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_f_242);
    return heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_lam0, 2, 1, (V[]){v_o_243});
  }
  case TAG_Cons: {
    V v_g_247 = heff_field(v_x4_244, 0);
    V v_rest_248 = heff_field(v_x4_244, 1);
    heff_take_n(v_x4_244, 3ULL, 2);
    V v_c_249 = (g_heff_2ebuild_2etesting_2egoldenSaid_24s999000889x259732916(heff_dup(v_e_240), v_update_241, heff_dup(v_f_242), v_g_247));
    return heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_lam1, 2, 6, (V[]){v_c_249, v_e_240, heff_dup(v_update_241), v_f_242, v_o_243, v_rest_248});
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_o_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_o_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_update_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_o_243 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2423);
  V v_t_2424 = ({ V a_0 = v_e_240; V a_1 = v_update_241; V a_2 = v_f_242; V a_3 = v_o_243; V a_4 = v_rest_248; V r_ = (g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_update_241); r_; });
  V f_ = v_t_2424;
  heff_room[0] = v_hd_2410;
  heff_room[1] = v_k_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_update_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_o_243 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Holds: {
    V v_t_2413 = ({ V a_0 = v_e_240; V a_1 = v_update_241; V a_2 = v_f_242; V a_3 = v_o_243; V a_4 = v_rest_248; V r_ = (g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_update_241); r_; });
    V f_ = v_t_2413;
    heff_room[0] = v_hd_2410;
    heff_room[1] = v_k_2411;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Wrote: {
    V v_path_2414 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Wrote = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_str0), v_path_2414), ((V)&g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_str1));
    V v_t_2416 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2415, NTAG(TAG_MkUnit)});
    V v_t_2417 = heff_tag_at_n(v_ru_24x_2412_24Wrote, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_lam3, 1, 7, (V[]){v_e_240, v_update_241, v_f_242, v_o_243, v_rest_248, v_hd_2410, v_k_2411})));
  }
  case TAG_Wrong: {
    V v_note_2425 = heff_field(v_x_2412, 0);
    V v_why_2426 = heff_field(v_x_2412, 1);
    V v_ru_24x_2412_24Wrong = heff_take_reuse_n(v_x_2412, 3ULL, 2);
    heff_drop(v_e_240);
    heff_drop(v_update_241);
    heff_drop(v_f_242);
    heff_drop(v_rest_248);
    heff_drop(v_hd_2410);
    V v_t_2427 = heff_tag_at_n(v_ru_24x_2412_24Wrong, TAG_Cons, 2, (V[]){v_note_2425, NTAG(TAG_Nil)});
    V v_t_2428 = (g_prelude_2e_2b_2b(heff_take_field(v_o_243, 8), v_t_2427));
    V v_x_2429 = ({ V rv_1 = NTAG(TAG_False); V rv_2 = NTAG(TAG_Nothing); V rv_8 = v_t_2428; V rv_9 = heff_tag_n(TAG_Just, 1, (V[]){v_why_2426}); V rr_ = heff_rec_reuse_nf(v_o_243, 3321ULL, 12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, 15794115u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
    V f_ = v_k_2411;
    args[0] = v_x_2429;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_update_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_o_243 = heff_env(self)[4];
  V v_rest_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_lam2, 1, 7, (V[]){v_e_240, v_update_241, v_f_242, v_o_243, v_rest_248, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam3(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_entry, 8, 0};

V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966(V v_e_240, V v_tk_241, V v_opts_242, V v_x3_243, V v_acc_244, V v_ready_245, V v_p_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    V v_t_248 = heff_tag_n(TAG_End, 2, (V[]){v_tk_241, NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam0, 1, 6, (V[]){v_e_240, v_opts_242, v_ready_245, v_acc_244, v_p_246, v_p_247})));
  }
  case TAG_Cons: {
    V v_f_2412 = heff_field(v_x3_243, 0);
    V v_rest_2413 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_tk_241), heff_dup(v_f_2412), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam2_clo)})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2416, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam3, 1, 9, (V[]){v_e_240, v_opts_242, v_f_2412, v_p_246, v_ready_245, v_acc_244, v_tk_241, v_rest_2413, v_p_247})));
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_opts_242 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439(v_e_240, v_opts_242, v_x_2411, v_p_246, v_p_247));
}
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_opts_242 = heff_env(self)[1];
  V v_ready_245 = heff_env(self)[2];
  V v_acc_244 = heff_env(self)[3];
  V v_p_246 = heff_env(self)[4];
  V v_p_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2410);
  return (g_heff_2ebuild_2etesting_2erunReady_24s1162321297x12710307(heff_dup(v_e_240), heff_dup(v_opts_242), v_ready_245, v_acc_244, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam1, 1, 4, (V[]){v_e_240, v_opts_242, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_pr_2421 = heff_env(self)[0];
  V v_acc_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_tk_241 = heff_env(self)[3];
  V v_opts_242 = heff_env(self)[4];
  V v_rest_2413 = heff_env(self)[5];
  V v_ready_245 = heff_env(self)[6];
  V v_hd_2422 = heff_env(self)[7];
  V v_k_2423 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2426);
  switch (heff_tag_of(v_pr_2421)) {
  case TAG_Done: {
    V v_r_2427 = heff_field(v_pr_2421, 0);
    heff_take_n(v_pr_2421, 1ULL, 1);
    V v_t_2428 = (g_heff_2ebuild_2etesting_2eaddRes(v_acc_244, v_r_2427));
    return (g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966(v_e_240, v_tk_241, v_opts_242, v_rest_2413, v_t_2428, v_ready_245, v_hd_2422, v_k_2423));
  }
  case TAG_Later: {
    V v_r_2429 = heff_field(v_pr_2421, 0);
    heff_take_n(v_pr_2421, 1ULL, 1);
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_2429, NTAG(TAG_Nil)});
    V v_t_2431 = (g_prelude_2e_2b_2b(v_ready_245, v_t_2430));
    return (g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966(v_e_240, v_tk_241, v_opts_242, v_rest_2413, v_acc_244, v_t_2431, v_hd_2422, v_k_2423));
  }
  default: return heff_nomatch(v_pr_2421);
  }
}
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam5(V self, V *args) {
  V v_pr_2421 = args[0];
  V v_hd_2422 = args[1];
  V v_k_2423 = args[2];
  V v_x_2417 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_acc_244 = heff_env(self)[2];
  V v_tk_241 = heff_env(self)[3];
  V v_opts_242 = heff_env(self)[4];
  V v_rest_2413 = heff_env(self)[5];
  V v_ready_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2424 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_hd_2422), heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam6, 1, 9, (V[]){v_pr_2421, v_acc_244, v_e_240, v_tk_241, v_opts_242, v_rest_2413, v_ready_245, v_hd_2422, v_k_2423})));
}
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_k_2432 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2432;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2440});
  heff_room[1] = v_p_246;
  heff_room[2] = v_p_247;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_k_2432 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_p_2434 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2439 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_242, heff_dup(v_x_2438)));
  if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
    heff_drop(v_x_2438);
    heff_drop(v_e_240);
    heff_drop_rec(v_p_2434, 7);
    heff_drop(v_t_2439);
    V f_ = v_k_2432;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_p_246;
    heff_room[2] = v_p_247;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2439);
    return (g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(v_e_240, heff_dup(heff_rfield(v_p_2434, 0)), heff_dup(heff_rfield(v_p_2434, 1)), heff_get_n(v_p_2434, 2, 7), v_x_2438, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam8, 1, 3, (V[]){v_k_2432, v_p_246, v_p_247})));
  }
}
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ready_245 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_acc_244 = heff_env(self)[3];
  V v_tk_241 = heff_env(self)[4];
  V v_opts_242 = heff_env(self)[5];
  V v_rest_2413 = heff_env(self)[6];
  V v_p_246 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_at_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ready_245));
  V v_k_2432 = heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam5, 3, 7, (V[]){v_x_2417, heff_dup(v_e_240), v_acc_244, v_tk_241, heff_dup(v_opts_242), v_rest_2413, v_ready_245});
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Settled: {
    V v_r_2433 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    heff_drop(v_e_240);
    heff_drop_rec(v_opts_242, 4);
    heff_drop(v_at_2420);
    V f_ = v_k_2432;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_r_2433});
    heff_room[1] = v_p_246;
    heff_room[2] = v_p_247;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Pend: {
    V v_p_2434 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    V v_t_2435 = heff_dup(heff_rfield(v_p_2434, 4));
    switch (heff_tag_of(v_t_2435)) {
    case TAG_Nil: {
      heff_drop(v_at_2420);
      V v_t_2436 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_2434, 3)), NTAG(TAG_Nil)));
      V v_c_2437 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(heff_dup(v_e_240), heff_rfield(v_opts_242, 3), heff_dup(heff_rfield(v_p_2434, 0)), v_t_2436));
      V f_ = v_c_2437;
      heff_room[0] = heff_dup(v_p_246);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam7, 1, 6, (V[]){v_opts_242, v_k_2432, v_p_246, v_p_247, v_e_240, v_p_2434});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_take_n(v_t_2435, 0ULL, 2);
      return (g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471(v_e_240, v_opts_242, v_at_2420, v_p_2434, v_k_2432, v_p_246, v_p_247));
    }
    default: return heff_nomatch(v_t_2435);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_opts_242 = heff_env(self)[1];
  V v_f_2412 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_ready_245 = heff_env(self)[4];
  V v_acc_244 = heff_env(self)[5];
  V v_tk_241 = heff_env(self)[6];
  V v_rest_2413 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2418 = (g_heff_2ebuild_2etesting_2etestOneF_24s1419521504x644427287(heff_dup(v_e_240), heff_dup(v_opts_242), v_f_2412));
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_p_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_lam4, 1, 9, (V[]){v_ready_245, v_x_2417, v_e_240, v_acc_244, v_tk_241, v_opts_242, v_rest_2413, v_p_246, v_p_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_str3, 1, "\012");
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam0, 3, 0};
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_entry, 5, 0};

V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949(V v_lit_240, V v_lit_241, V v_lit_242, V v_e_243, V v_f_244) {
top: ;
  V v_path_245 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_f_244)));
  V v_c_246 = ({ V a_0 = heff_dup(v_e_243); V a_1 = v_path_245; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_245); r_; });
  V v_t_247 = (g_exception_2eattempted(heff_dup(v_e_243)));
  V v_c_2411 = heff_tr(heff_call(v_c_246, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam1, 2, 6, (V[]){v_c_2411, v_e_243, v_f_244, v_lit_240, v_lit_241, v_lit_242});
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_249 = args[1];
  V v_k_2410 = args[2];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_f_244 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2417 = heff_rec_n(4, shape_seed__pattern__jobs__update, (V[]){v_lit_240, v_lit_241, v_lit_242, NTAG(TAG_False)});
  V v_j_2418 = heff_strFind(((V)&g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_str0), ((V)&g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_str1), MK_INT(0LL));
  V v_t_2419;
  if (heff_intLt_c_lent(v_j_2418, MK_INT(0LL), 2)) {
    heff_drop(v_j_2418);
    v_t_2419 = MK_INT(0LL);
  } else {
    v_t_2419 = v_j_2418;
  }
  V v_t_2420 = heff_bool(heff_strEq_c(heff_strSlice_lent(((V)&g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_str2), MK_INT(0LL), v_t_2419, 3), heff_dup(g_heff_2ebuild_2etesting_2eexpectErrorsLine_get())));
  heff_drop(v_t_2419);
  return ({ V a_0 = v_e_243; V a_1 = v_t_2417; V a_2 = v_f_244; V a_3 = v_t_2420; V a_4 = v_x_2416; V a_5 = v_hd_2412; V a_6 = v_k_2413; V r_ = (g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2420); r_; });
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_y_2421 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_f_244 = heff_env(self)[5];
  V v_hd_2412 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2423 = heff_rec_n(4, shape_seed__pattern__jobs__update, (V[]){v_lit_240, v_lit_241, v_lit_242, NTAG(TAG_False)});
  V v_d_2424 = heff_strLength_lent(v_y_2421, 0);
  V v_j_2425 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_str3), v_y_2421, MK_INT(0LL), 5);
  V v_t_2426;
  if (heff_intLt_c_lent(v_j_2425, MK_INT(0LL), 2)) {
    heff_drop(v_j_2425);
    v_t_2426 = v_d_2424;
  } else {
    heff_drop(v_d_2424);
    v_t_2426 = v_j_2425;
  }
  V v_t_2427 = heff_bool(heff_strEq_c(heff_strSlice_lent(v_y_2421, MK_INT(0LL), v_t_2426, 2), heff_dup(g_heff_2ebuild_2etesting_2eexpectErrorsLine_get())));
  heff_drop(v_y_2421);
  heff_drop(v_t_2426);
  return ({ V a_0 = v_e_243; V a_1 = v_t_2423; V a_2 = v_f_244; V a_3 = v_t_2427; V a_4 = v_x_2422; V a_5 = v_hd_2412; V a_6 = v_k_2413; V r_ = (g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2427); r_; });
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_hd_2412 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    heff_take_n(v_x_2414, 0ULL, 1);
    return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_243), heff_dup(v_f_244), heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam3, 1, 7, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243, v_f_244, v_hd_2412, v_k_2413})));
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_243), heff_dup(v_f_244), heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam4, 1, 8, (V[]){v_lit_240, v_lit_241, v_lit_242, v_y_2421, v_e_243, v_f_244, v_hd_2412, v_k_2413})));
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_f_244 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_lam2, 1, 7, (V[]){v_e_243, v_f_244, v_hd_2412, v_lit_240, v_lit_241, v_lit_242, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}