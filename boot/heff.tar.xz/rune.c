// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_rune_2evalidFrom(V, V);
V g_rune_2evalidFrom_entry(V self, V *a);
extern Clo g_rune_2evalidFrom_clo;
Clo g_rune_2evalidFrom_clo = {{0x80000000u, K_CLO, 0}, g_rune_2evalidFrom_entry, 2, 0};

V g_rune_2evalidFrom(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return NTAG(TAG_True);
  } else {
    if ((heff_runeEq_c(heff_strRuneAt_lent(v_s_240, v_i_241, 0), MK_INT(65533LL)) && ({ V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(65533LL), NTAG(TAG_Nil)}); int c_ = ({ V v_t_244 = heff_strOfRunes(heff_dup(v_t_242)); int c_ = !heff_strEq_c(heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(3LL))), heff_dup(v_t_244)); heff_drop(v_t_244); c_; }); heff_drop(v_t_242); c_; }))) {
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    } else {
      V v_t_243 = heff_intAdd(heff_dup(v_i_241), heff_strRuneWidth_lent(v_s_240, v_i_241, 2));
      V t_0 = v_s_240;
      V t_1 = v_t_243;
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_rune_2evalidFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_rune_2evalidFrom(a0, a[1]); heff_drop(a0); return r;
}