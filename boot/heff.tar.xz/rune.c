// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_rune_2efromInt_get(void);
V g_runeFromInt_get(void);

static V g_rune_2efromInt_val;
static HEFF_ONCE g_rune_2efromInt_st;
static V g_rune_2efromInt_init(void) {
  return heff_dup(g_runeFromInt_get());
}
V g_rune_2efromInt_get(void) {
  if (HEFF_DONE(g_rune_2efromInt_st)) return g_rune_2efromInt_val;
  return heff_global(&g_rune_2efromInt_val, &g_rune_2efromInt_st, g_rune_2efromInt_init);
}