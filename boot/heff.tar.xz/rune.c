// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_rune_2efromInt_get(void);
V g_runeFromInt_get(void);

static V g_rune_2efromInt_val;
static int g_rune_2efromInt_st;
static V g_rune_2efromInt_init(void) {
  return heff_dup(g_runeFromInt_get());
}
V g_rune_2efromInt_get(void) {
  if (g_rune_2efromInt_st == 2) return g_rune_2efromInt_val;
  if (g_rune_2efromInt_st == 1) heff_fail("defined by itself");
  g_rune_2efromInt_st = 1;
  g_rune_2efromInt_val = heff_tr(g_rune_2efromInt_init());
  g_rune_2efromInt_st = 2;
  return g_rune_2efromInt_val;
}