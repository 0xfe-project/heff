// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_rune_2eisSpace(V);
V g_rune_2eisSpace_entry(V self, V *a);
extern Clo g_rune_2eisSpace_clo;
V g_rune_2evalidFrom(V, V);
V g_rune_2evalidFrom_entry(V self, V *a);
extern Clo g_rune_2evalidFrom_clo;
Clo g_rune_2evalidFrom_clo = {{0x80000000u, K_CLO, 0}, g_rune_2evalidFrom_entry, 2, 0};

V g_rune_2evalidFrom(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return NTAG(TAG_True);
  } else {
    if (heff_runeEq_c(heff_strRuneAt_lent(v_s_240, v_i_241, 0), MK_INT(65533LL))) {
      V v_t_244 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(3LL)));
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(65533LL), NTAG(TAG_Nil)});
      if (heff_strEq_c(v_t_244, heff_strOfRunes(v_t_245))) {
        V v_t_247 = heff_intAdd(heff_dup(v_i_241), heff_strRuneWidth_lent(v_s_240, v_i_241, 2));
        V t_0 = v_s_240;
        V t_1 = v_t_247;
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        heff_drop(v_i_241);
        return NTAG(TAG_False);
      }
    } else {
      V v_t_248 = heff_intAdd(heff_dup(v_i_241), heff_strRuneWidth_lent(v_s_240, v_i_241, 2));
      V t_0 = v_s_240;
      V t_1 = v_t_248;
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_rune_2evalidFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_rune_2evalidFrom(a0, a[1]); heff_drop(a0); return r;
}
Clo g_rune_2eisSpace_clo = {{0x80000000u, K_CLO, 0}, g_rune_2eisSpace_entry, 1, 0};

V g_rune_2eisSpace(V v_x1_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_runeEq_c(heff_dup(v_x1_240), MK_INT(32LL)) || (heff_runeEq_c(heff_dup(v_x1_240), MK_INT(9LL)) || (heff_runeEq_c(heff_dup(v_x1_240), MK_INT(10LL)) || (heff_runeEq_c(heff_dup(v_x1_240), MK_INT(13LL)) || (heff_runeEq_c(heff_dup(v_x1_240), MK_INT(11LL)) || heff_runeEq_c(heff_dup(v_x1_240), MK_INT(12LL))))))));
  heff_drop(v_x1_240);
  return v_ret_24bool;
}
V g_rune_2eisSpace_entry(V self, V *a) {
  (void)self;
  return g_rune_2eisSpace(a[0]);
}