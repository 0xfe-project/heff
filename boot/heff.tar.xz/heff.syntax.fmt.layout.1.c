// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Looser 37443
#define TAG_Named 2049
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_env 310119
#define LBL_groups 709681407
#define LBL_i 323
#define LBL_ix 10134
#define LBL_ops 319788
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_trail 311979552
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
HeffT2 g_heff_2esyntax_2ecst_2eprogramGo_24cpr(V, V);
HeffT2 g_heff_2esyntax_2efixity_2efindG_24cpr(V, V);
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofOf(V);
V g_heff_2esyntax_2efmt_2elayout_2eeofOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLine(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLine_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLine_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtAttached_24cpr(V);
V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(V, V);
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2erender2(V);
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo;
V g_heff_2esyntax_2efmt_2elayout_2ereplaceAll(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_clo;
V g_heff_2esyntax_2efmt_2elex_2eblockScan(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2eblockScan_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eblockScan_clo;
V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2ehardline_get(void);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_str0, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2ereplaceAll(V v_pat_240, V v_rep_241, V v_s_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_pat_240, 0)) == ((int64_t)0ULL))) {
    return ({ V a_0 = v_rep_241; V a_1 = v_s_242; V b_2 = NTAG(TAG_Nil); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  } else {
    V v_x2_244 = ({ V a_0 = v_pat_240; V a_1 = v_s_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(v_pat_240, v_s_242, MK_INT(0LL), 4); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_242); r_; });
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      heff_drop(v_rep_241);
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_str0);
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      return ({ V a_0 = v_rep_241; V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ereplaceAll(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ecomment_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ecomment_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ecomment_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ecomment_str3, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ecomment_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ecomment(V v_s_240) {
top: ;
  V v_x2_241 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2ecomment_str0); V a_1 = v_s_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2efmt_2elayout_2ecomment_str1), v_s_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_s_244 = ((V)&g_heff_2esyntax_2efmt_2elayout_2ecomment_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_s_244 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  if (heff_strEq_c_lent(v_s_244, ((V)&g_heff_2esyntax_2efmt_2elayout_2ecomment_str3), 2)) {
    heff_drop(v_s_244);
    return NTAG(TAG_None);
  } else {
    return heff_tag_n(TAG_Text, 1, (V[]){v_s_244});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ecomment(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V v_s_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_intLe_c_lent(v_b_242, v_a_241, 0)) {
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_a_241, 0)) == ((int64_t)10ULL))) {
      heff_drop(v_a_241);
      heff_drop(v_b_242);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_a_241, MK_INT(1LL));
      V t_2 = v_b_242;
      v_s_240 = t_0;
      v_a_241 = t_1;
      v_b_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2enewlineIn(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_f_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Atom: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EParen: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Named: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Tup: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Seg: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Braces: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Update: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EUSet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_InstB: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFSet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFDefault: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Sum: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECon: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EField: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ENeg: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETilde: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_App: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Op: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Ops: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpRhs: {
      V v_op_2464 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      HeffT2 v_t_2468 = (g_heff_2esyntax_2efixity_2efindG_24cpr(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr_lam0, 1, 1, (V[]){heff_dup(v_op_2464)}), heff_dup(heff_rfield(v_f_240, 0))));
      {
        V v_field_2470 = v_t_2468.f[1];
        int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
        if ((v_tag_2469 == ((int64_t)0ULL))) {
          V v_x_2472 = v_field_2470;
          heff_drop(v_x_2472);
          HeffT2 v_t_2473 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(v_f_240, v_rs_243));
          {
            V v_field_2475 = v_t_2473.f[1];
            int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
            if ((v_tag_2474 == ((int64_t)0ULL))) {
              V v_ops_2477 = v_field_2475;
              V v_f_2478 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_op_2464, 1, 9), v_ops_2477});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2478}});
            } else {
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              heff_drop_rec(v_op_2464, 9);
              heff_drop(v_field_2475);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop_rec(v_f_240, 2);
          heff_drop(v_rs_243);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop_rec(v_op_2464, 9);
          heff_drop(v_field_2470);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_Ann: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_BVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_BImp: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_BAnn: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_BPat: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Lam: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Case: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAlt: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_If: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Do: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESBind: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELetElse: {
      heff_take_n(v_x21_242, 0ULL, 7);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELetMut: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAssign: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWhile: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFor: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EJump: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EReturn: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ENest: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EArrow: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_IfThen: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETry: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECatch: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWith: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr_lam0(V self, V *args) {
  V v_g_2466 = args[0];
  V v_op_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2467 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_op_2464, 1, 9)}));
  return ({ V a_0 = v_t_2467; V b_1 = heff_get_n(v_g_2466, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V v_f_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return heff_tag_n(TAG_Just, 1, (V[]){v_m_241});
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_os_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(v_f_240), heff_dup(v_m_241), heff_dup(v_o_243)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Tighter: {
      heff_drop(v_m_241);
      V t_0 = v_f_240;
      V t_1 = heff_dup(v_o_243);
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Looser: {
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Same: {
      heff_take_n(v_t_245, 0ULL, 1);
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Unrelated: {
      heff_drop(v_f_240);
      heff_drop(v_m_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_m_241);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(V v_env_240, V v_rhsLast_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_rhsLast_241, 9);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_kw_244 = heff_field(v_x41_243, 0);
      V v_ds_245 = heff_field(v_x41_243, 1);
      HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 3), heff_dup(heff_rfield(v_rhsLast_241, 7))));
      V v_t_2411;
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_x_2410 = v_field_248;
          heff_drop(v_x_2410);
          v_t_2411 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(heff_dup(v_env_240), v_rhsLast_241));
        } else {
          heff_drop_rec(v_rhsLast_241, 9);
          heff_drop(v_field_248);
          v_t_2411 = heff_dup(g_std_2edoc_2ehardline_get());
        }
      }
      V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_244)));
      V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(v_env_240, MK_INT(0LL), v_ds_245));
      V v_t_2414 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
      V v_t_2415 = (g_std_2edoc_2e_3c_3e(v_t_2412, v_t_2414));
      return (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2415));
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(V v_env_240, V v_i_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x4_242, 0);
    V v_ds_244 = heff_field(v_x4_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_243));
    V v_t_246 = (g_heff_2esyntax_2ecst_2efirstD(v_d_243));
    V v_t_247 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_243)));
    V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_246, v_t_247, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_lam0, 1, 1, (V[]){heff_dup(v_d_243)})));
    V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_ds_244));
    V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_t_249, v_t_2410));
    return (g_std_2edoc_2e_3c_3e(v_t_245, v_t_2411));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_lam0(V self, V *args) {
  V v_e_248 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_248; V a_1 = v_d_243; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_243); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(v_s_240, heff_dup(v_i_241)));
  V v_t_243 = (g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(v_s_240, v_t_242));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(v_s_240, v_i_241));
    HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2eeolEnd(v_s_240, v_t_244);
  } else {
    heff_drop(v_t_243);
    V v_j_245 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(v_s_240, heff_dup(v_i_241)));
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_245, 0)) == ((int64_t)123ULL))) {
      V v_t_247 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(v_j_245, MK_INT(1LL)));
      if ((heff_unbox_word(v_t_247) == ((int64_t)45ULL))) {
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(v_s_240, v_i_241));
        V v_r_2410 = (g_heff_2esyntax_2efmt_2elex_2eblockScan(v_s_240, v_t_249, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)));
        V t_0 = v_s_240;
        V t_1 = heff_get_n(v_r_2410, 0, 5);
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        return v_i_241;
      }
    } else {
      heff_drop(v_j_245);
      return v_i_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2etrailEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps(V v_doc_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x2_241, 0);
    V v_cs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2eexpectLine(v_doc_240, heff_dup(v_c_243)));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_c_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_doc_240;
      V t_1 = v_cs_244;
      V t_2 = v_cell_246;
      v_doc_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_c_243);
      heff_drop(v_cs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtAttached_24cpr(V v_at_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_242 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_at_240, 0)), MK_INT(0LL), MK_INT(0LL), v_t_241, MK_INT(0LL)});
  HeffT2 v_t_243 = (g_heff_2esyntax_2ecst_2eprogramGo_24cpr(v_t_242, NTAG(TAG_Nil)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop_rec(v_at_240, 2);
      V v_e_247 = v_field_245;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_247}});
    } else {
      V v_ds_248 = v_field_245;
      V v_eof_249 = (g_heff_2esyntax_2efmt_2elayout_2eeofOf(heff_rfield(v_at_240, 0)));
      V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(heff_get_n(v_at_240, 1, 2), MK_INT(0LL), NTAG(TAG_False), v_eof_249, v_ds_248));
      V v_f_2411 = (g_heff_2esyntax_2efmt_2elayout_2erender2(v_t_2410));
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2411}});
    }
  }
}