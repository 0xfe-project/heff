// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Looser 37443
#define TAG_MkDAlts 45152
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_col 308218
#define LBL_elseOf 646984731
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_groups 709681407
#define LBL_hungOn 741036848
#define LBL_ifLink 754803170
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_ops 319788
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_raw 322210
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_trail 311979552
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__hungOn__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_rhsOf, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_hungOn, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsChainDoc, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
HeffT2 g_heff_2esyntax_2efixity_2efindG_24cpr(V, V);
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo(V);
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eendsInDo_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLine(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLine_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLine_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2_clo;
V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enamesDoc(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enamesDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enamesDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2enearGo(V, V);
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2esig(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2esig_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esig_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
HeffT5 g_heff_2esyntax_2efmt_2elex_2eblockScan_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void);
V g_list_2eall_24s78096928x1476871221(V, V, V);
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a);
extern Clo g_list_2eall_24s78096928x1476871221_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1854884545x892082821(V, V);
V g_list_2efoldl_24s1854884545x892082821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854884545x892082821_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s2139359291x1524787922(V);
V g_list_2emap_24s2139359291x1524787922_entry(V self, V *a);
extern Clo g_list_2emap_24s2139359291x1524787922_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2e_3c_3e_24tok2(V, V, V);
V g_std_2edoc_2e_3c_3e_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_24tok2_clo;
V g_std_2edoc_2econcatWith_24s593061764x1986092725(V, V);
V g_std_2edoc_2econcatWith_24s593061764x1986092725_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s593061764x1986092725_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2egroup_24tok2(V, V);
V g_std_2edoc_2egroup_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_24tok2_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0, 1, "\001");

static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankMark_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankMark_val, &g_heff_2esyntax_2efmt_2elayout_2eblankMark_st, g_heff_2esyntax_2efmt_2elayout_2eblankMark_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ecomment_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ecomment_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ecomment_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ecomment_str3, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ecomment_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ecomment(V v_s_240) {
top: ;
  V v_x2_241 = ({ V a_0 = v_s_240; V b_1 = ((V)&g_heff_2esyntax_2efmt_2elayout_2ecomment_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2efmt_2elayout_2ecomment_str1), v_s_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_s_244 = ((V)&g_heff_2esyntax_2efmt_2elayout_2ecomment_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_s_244 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  if (heff_strEq_c_lent(v_s_244, ((V)&g_heff_2esyntax_2efmt_2elayout_2ecomment_str3), 2)) {
    heff_drop(v_s_244);
    return NTAG(TAG_None);
  } else {
    return heff_tag_n(TAG_Text, 1, (V[]){v_s_244});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ecomment(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etok_str0, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etok_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etok(V v_env_240, V v_t_241) {
top: ;
  V v_t_2414;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
    v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 1), heff_dup(heff_rfield(v_t_241, 7))));
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_x_245 = v_field_244;
        switch (heff_tag_of(v_x_245)) {
        case TAG_Nil: {
          v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
          break;
        }
        case TAG_Cons: {
          V v_ru_24x_245_24Cons = heff_take_reuse_n(v_x_245, 0ULL, 2);
          V v_t_2412;
          if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
            v_t_2412 = NTAG(TAG_Nil);
          } else {
            HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 1), heff_dup(heff_rfield(v_t_241, 7))));
            {
              V v_field_2410 = v_t_248.f[1];
              int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
              if ((v_tag_249 == ((int64_t)0ULL))) {
                V v_x_2411 = v_field_2410;
                v_t_2412 = v_x_2411;
              } else {
                heff_drop(v_field_2410);
                v_t_2412 = NTAG(TAG_Nil);
              }
            }
          }
          V v_t_2413 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24f1134152647x940271785(a_0, a_1)); heff_drop(v_t_2412); r_; });
          v_t_2414 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24x_245_24Cons, v_t_2413, heff_dup(g_std_2edoc_2ehardline_get())));
          break;
        }
        default: heff_nomatch(v_x_245);
        }
      } else {
        heff_drop(v_field_244);
        v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
  }
  HeffT2 v_t_2415 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 2), heff_dup(heff_rfield(v_t_241, 7))));
  V v_t_2419;
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2417;
      v_t_2419 = v_x_2418;
    } else {
      heff_drop(v_field_2417);
      v_t_2419 = NTAG(TAG_Nil);
    }
  }
  V v_t_2420 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_s_2421 = heff_dup(heff_rfield(v_t_241, 2));
  V v_t_2422;
  if (heff_strEq_c_lent(v_s_2421, ((V)&g_heff_2esyntax_2efmt_2elayout_2etok_str0), 2)) {
    heff_drop(v_s_2421);
    v_t_2422 = NTAG(TAG_None);
  } else {
    v_t_2422 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2421});
  }
  V v_t_2423;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_t_241, 9);
    v_t_2423 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    v_t_2423 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_t_241));
  }
  V v_t_2424 = (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2423));
  V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2420, v_t_2424));
  HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2425);
}
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etok(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_blank_244 = heff_dup(heff_rfield(v_c_242, 1));
    V v_text_245 = heff_dup(heff_rfield(v_c_242, 0));
    V v_t_246;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      if ((heff_dup(v_blank_244) == NTAG(TAG_True))) {
        heff_drop(v_blank_244);
        v_t_246 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_blank_244);
        v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      heff_drop(v_blank_244);
      v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_247 = ({ V a_0 = v_text_245; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ecomment(a_0)); heff_drop(v_text_245); r_; });
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(v_cs_243, heff_intAdd(v_i_241, MK_INT(1LL))));
    V v_t_249 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_248));
    V v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_247, v_t_249));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_246, v_t_2410);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangs_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2455 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2455));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    V v_body_2479 = heff_field(v_e_240, 3);
    V t_0 = v_body_2479;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_EArrow: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangs(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V v_s_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_intLe_c_lent(v_b_242, v_a_241, 0)) {
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_a_241, 0)) == ((int64_t)10ULL))) {
      heff_drop(v_a_241);
      heff_drop(v_b_242);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_a_241, MK_INT(1LL));
      V t_2 = v_b_242;
      v_s_240 = t_0;
      v_a_241 = t_1;
      v_b_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2enewlineIn(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    V v_op_2461 = heff_field(v_x1_240, 0);
    V v_e_2462 = heff_field(v_x1_240, 1);
    V v_t_2463 = heff_dup(heff_rfield(v_op_2461, 6));
    if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
      heff_drop(v_t_2463);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2463);
      V v_t_2464 = (g_heff_2esyntax_2ecst_2efirstE(v_e_2462));
      return heff_get_n(v_t_2464, 6, 9);
    }
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_EArrow: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Op: {
    V v_a_241 = heff_field(v_e_240, 0);
    V v_op_242 = heff_field(v_e_240, 1);
    V v_b_243 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    HeffT2 v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_dup(v_b_243)));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_bf_247 = v_field_245;
      V v_rest_248 = v_field_246;
      V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_242), v_rest_248));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_b_243);
        heff_drop(v_t_249);
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_242, v_bf_247}), v_rest_248});
        return ((HeffT2){{v_a_241, v_t_2410}});
      } else {
        heff_drop(v_bf_247);
        heff_drop(v_rest_248);
        heff_drop(v_t_249);
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_242, v_b_243}), NTAG(TAG_Nil)});
        return ((HeffT2){{v_a_241, v_t_2411}});
      }
    }
  }
  default: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0, 2, "->");
Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_OpRhs: {
      V v_op_243 = heff_field(v_x11_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_op_243, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
    }
    default: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epListGo_str0, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epListGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_pOne_241);
    heff_drop(v_commas_243);
    heff_drop(v_isFirst_244);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_ps_246 = heff_field(v_x3_242, 1);
    V v_t_2410;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    } else {
      switch (heff_tag_of(v_commas_243)) {
      case TAG_Nil: {
        v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_dup(heff_field(v_commas_243, 0));
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_247));
        v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epListGo_str0)})));
        break;
      }
      default: heff_nomatch(v_commas_243);
      }
    }
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_pOne_241), 1, (V[]){heff_dup(v_p_245)}));
    V v_t_2412;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      heff_drop(v_isFirst_244);
      v_t_2412 = v_commas_243;
    } else {
      heff_drop(v_isFirst_244);
      v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = v_commas_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_commas_243); r_; });
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(v_env_240, v_pOne_241, v_ps_246, v_t_2412, NTAG(TAG_False)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2epListGo(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_f_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Atom: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EParen: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Named: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Tup: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Seg: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Braces: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Update: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EUSet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_InstB: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFSet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFDefault: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Sum: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECon: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EField: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ENeg: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETilde: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_App: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Op: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Ops: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpRhs: {
      V v_op_2464 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      HeffT2 v_t_2467 = (g_heff_2esyntax_2efixity_2efindG_24cpr(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr_lam0, 1, 1, (V[]){heff_dup(v_op_2464)}), heff_rfield(v_f_240, 0)));
      {
        V v_field_2469 = v_t_2467.f[1];
        int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
        if ((v_tag_2468 == ((int64_t)0ULL))) {
          V v_x_2470 = v_field_2469;
          heff_drop(v_x_2470);
          HeffT2 v_t_2471 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(v_f_240, v_rs_243));
          {
            V v_field_2473 = v_t_2471.f[1];
            int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
            if ((v_tag_2472 == ((int64_t)0ULL))) {
              V v_ops_2474 = v_field_2473;
              V v_f_2475 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_op_2464, 1, 9), v_ops_2474});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2475}});
            } else {
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              heff_drop_rec(v_op_2464, 9);
              heff_drop(v_field_2473);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop_rec(v_f_240, 2);
          heff_drop(v_rs_243);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop_rec(v_op_2464, 9);
          heff_drop(v_field_2469);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_Ann: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_BVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_BImp: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_BAnn: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_BPat: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Lam: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Case: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAlt: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_If: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Do: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESBind: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELetElse: {
      heff_take_n(v_x21_242, 0ULL, 7);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELetMut: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAssign: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWhile: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFor: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EJump: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EReturn: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ENest: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EArrow: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_IfThen: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETry: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECatch: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWith: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr_lam0(V self, V *args) {
  V v_g_2466 = args[0];
  V v_op_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_op_2464, 1, 9); V b_1 = heff_get_n(v_g_2466, 2, 5); V r_ = (g_list_2eany_24s1006624359x760861690(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V v_f_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return heff_tag_n(TAG_Just, 1, (V[]){v_m_241});
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_os_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(v_f_240), heff_dup(v_m_241), heff_dup(v_o_243)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Tighter: {
      heff_drop(v_m_241);
      V t_0 = v_f_240;
      V t_1 = heff_dup(v_o_243);
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Looser: {
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Same: {
      heff_take_n(v_t_245, 0ULL, 1);
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Unrelated: {
      heff_drop(v_f_240);
      heff_drop(v_m_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_m_241);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2455 = heff_field(v_x1_240, 1);
    V v_x1_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2455)));
    switch (heff_tag_of(v_x1_2456)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x_2457 = heff_field(v_x1_2456, 0);
      V v_rev_2458 = heff_field(v_x1_2456, 1);
      heff_take_n(v_x1_2456, 3ULL, 2);
      V v_t_2459 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_2458));
      V v_init2_2460 = v_t_2459;
      heff_drop(v_init2_2460);
      V v_it12_2461 = v_x_2457;
      switch (heff_tag_of(v_it12_2461)) {
      case TAG_EParen: {
        V v_e_2463 = heff_field(v_it12_2461, 1);
        heff_take_n(v_it12_2461, 2ULL, 3);
        return ({ V a_0 = v_e_2463; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop(v_e_2463); r_; });
      }
      default: {
        return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop(v_it12_2461); r_; });
      }
      }
    }
    default: return heff_nomatch(v_x1_2456);
    }
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_EArrow: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangsLast(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2455 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2455));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_True);
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_True);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_EArrow: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eopensBlock(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2415;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_245 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      V v_ix_246 = heff_take_field(v_t_245, 7);
      V v_blank_247 = heff_get_n(v_t_245, 8, 9);
      HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 1), v_ix_246));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        V v_t_2414;
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_2410;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_Nil: {
            v_t_2414 = v_blank_247;
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_x_2411, 0);
            heff_take_n(v_x_2411, 1ULL, 2);
            heff_drop(v_blank_247);
            v_t_2414 = heff_get_n(v_x_2412, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
        } else {
          heff_drop(v_field_2410);
          v_t_2414 = v_blank_247;
        }
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2416, v_t_2417, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2420));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2421));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2422));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_lam0(V self, V *args) {
  V v_e_2418 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14));
  heff_room[0] = v_e_2418;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2415;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_245 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      V v_ix_246 = heff_take_field(v_t_245, 7);
      V v_blank_247 = heff_get_n(v_t_245, 8, 9);
      HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 1), v_ix_246));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        V v_t_2414;
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_2410;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_Nil: {
            v_t_2414 = v_blank_247;
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_x_2411, 0);
            heff_take_n(v_x_2411, 1ULL, 2);
            heff_drop(v_blank_247);
            v_t_2414 = heff_get_n(v_x_2412, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
        } else {
          heff_drop(v_field_2410);
          v_t_2414 = v_blank_247;
        }
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2416, v_t_2417, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2420));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2421));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2422));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_lam0(V self, V *args) {
  V v_e_2418 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15));
  heff_room[0] = v_e_2418;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, "=");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 4, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam45_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam48_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam49_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam50_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(17, shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__hungOn__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam28_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam29_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam30_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam31_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam34_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam35_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam40_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam41_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam42_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam43_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam44_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam45_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam48_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam49_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam50_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam51_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2elay_st)) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2elay_val, &g_heff_2esyntax_2efmt_2elayout_2elay_st, g_heff_2esyntax_2efmt_2elayout_2elay_init);
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  if (heff_intEq_c_lent(v_i_2411, MK_INT(0LL), 2)) {
    heff_drop(v_i_2411);
    return v_d_247;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2444 = args[0];
  V v_e_2445 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2446 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2444));
  V v_one_2447 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_240}));
  V v_t_2448 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_2445));
  V v_b_2452;
  if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
    heff_drop(v_t_2448);
    V v_d_2449 = heff_tr(heff_call(v_one_2447, 1, (V[]){v_e_2445}));
    v_b_2452 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2449});
  } else {
    heff_drop(v_t_2448);
    V v_t_2450 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e_2445));
    if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
      heff_drop(v_t_2450);
      V v_d_2451 = heff_tr(heff_call(v_one_2447, 1, (V[]){v_e_2445}));
      v_b_2452 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2451});
    } else {
      heff_drop(v_t_2450);
      v_b_2452 = heff_tr(heff_call(v_one_2447, 1, (V[]){v_e_2445}));
    }
  }
  V v_t_2453 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), v_b_2452));
  V v_t_2454 = (g_std_2edoc_2e_3c_3e(v_a_2446, v_t_2453));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2454));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2465 = args[0];
  V v_k_2464 = heff_env(self)[0];
  V v_d_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2466 = heff_intSub(v_k_2464, v_i_2465);
  if (heff_intEq_c_lent(v_i_2466, MK_INT(0LL), 2)) {
    heff_drop(v_i_2466);
    return v_d_2463;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2466, v_d_2463});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2464 = args[0];
  V v_d_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2464, v_d_2463})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_t_2472 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_2472));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_comma_2487 = args[0];
  V v_f_2488 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2489 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2487));
  V v_d_2490 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 16)), 2, (V[]){v_env_240, v_f_2488}));
  V v_t_2491 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2490})));
  V v_t_2492 = (g_std_2edoc_2e_3c_3e(v_a_2489, v_t_2491));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2492));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_i_24101 = args[0];
  V v_k_24100 = heff_env(self)[0];
  V v_d_2499 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24102 = heff_intSub(v_k_24100, v_i_24101);
  if (heff_intEq_c_lent(v_i_24102, MK_INT(0LL), 2)) {
    heff_drop(v_i_24102);
    return v_d_2499;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24102, v_d_2499});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_k_24100 = args[0];
  V v_d_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 1, 2, (V[]){v_k_24100, v_d_2499})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_comma_24128 = args[0];
  V v_f_24129 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_24130 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_24128));
  V v_d_24131 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 16)), 2, (V[]){v_env_240, v_f_24129}));
  V v_t_24132 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24131})));
  V v_t_24133 = (g_std_2edoc_2e_3c_3e(v_a_24130, v_t_24132));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_24133));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_i_24144 = args[0];
  V v_k_24143 = heff_env(self)[0];
  V v_d_24142 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24145 = heff_intSub(v_k_24143, v_i_24144);
  if (heff_intEq_c_lent(v_i_24145, MK_INT(0LL), 2)) {
    heff_drop(v_i_24145);
    return v_d_24142;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24145, v_d_24142});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_k_24143 = args[0];
  V v_d_24142 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 1, 2, (V[]){v_k_24143, v_d_24142})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_bar_24201 = args[0];
  V v_a_24202 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_o_24184 = heff_env(self)[1];
  V v_c_24187 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24203 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24184, 4, 9), heff_get_n(v_c_24187, 3, 9)));
  V v_t_24204;
  if ((heff_dup(v_x1_24203) == NTAG(TAG_True))) {
    heff_drop(v_x1_24203);
    v_t_24204 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24203);
    v_t_24204 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24205 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24201));
  V v_b_24206 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24202}));
  V v_t_24207 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24206));
  V v_t_24208 = (g_std_2edoc_2e_3c_3e(v_a_24205, v_t_24207));
  return (g_std_2edoc_2e_3c_3e(v_t_24204, v_t_24208));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_i_24215 = args[0];
  V v_k_24214 = heff_env(self)[0];
  V v_d_24213 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24216 = heff_intSub(v_k_24214, v_i_24215);
  if (heff_intEq_c_lent(v_i_24216, MK_INT(0LL), 2)) {
    heff_drop(v_i_24216);
    return v_d_24213;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24216, v_d_24213});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_k_24214 = args[0];
  V v_d_24213 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 1, 2, (V[]){v_k_24214, v_d_24213})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_a_24222 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24223 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24222}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24223));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_r_24250 = args[0];
  V v_op_24240 = heff_env(self)[0];
  V v_bf_24245 = heff_env(self)[1];
  V v_rest_24246 = heff_env(self)[2];
  V v_env_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24251 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_24250));
  V v_t_24252;
  if ((heff_dup(v_x1_24251) == NTAG(TAG_True))) {
    heff_drop(v_x1_24251);
    v_t_24252 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24251);
    v_t_24252 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24253 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_24240, v_bf_24245}), v_rest_24246});
  V v_t_24254 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 3, (V[]){v_env_240, v_t_24253, v_r_24250}));
  return (g_std_2edoc_2e_3c_3e(v_t_24252, v_t_24254));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_i_24382 = args[0];
  V v_k_24381 = heff_env(self)[0];
  V v_d_24380 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24383 = heff_intSub(v_k_24381, v_i_24382);
  if (heff_intEq_c_lent(v_i_24383, MK_INT(0LL), 2)) {
    heff_drop(v_i_24383);
    return v_d_24380;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24383, v_d_24380});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_k_24381 = args[0];
  V v_d_24380 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 1, 2, (V[]){v_k_24381, v_d_24380})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_i_24446 = args[0];
  V v_k_24445 = heff_env(self)[0];
  V v_d_24442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24447 = heff_intSub(v_k_24445, v_i_24446);
  if (heff_intEq_c_lent(v_i_24447, MK_INT(0LL), 2)) {
    heff_drop(v_i_24447);
    return v_d_24442;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24447, v_d_24442});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_k_24445 = args[0];
  V v_d_24442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 1, 2, (V[]){v_k_24445, v_d_24442})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_i_24465 = args[0];
  V v_k_24464 = heff_env(self)[0];
  V v_d_24461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24466 = heff_intSub(v_k_24464, v_i_24465);
  if (heff_intEq_c_lent(v_i_24466, MK_INT(0LL), 2)) {
    heff_drop(v_i_24466);
    return v_d_24461;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24466, v_d_24461});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_k_24464 = args[0];
  V v_d_24461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 1, 2, (V[]){v_k_24464, v_d_24461})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_i_24517 = args[0];
  V v_k_24516 = heff_env(self)[0];
  V v_d_24515 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24518 = heff_intSub(v_k_24516, v_i_24517);
  if (heff_intEq_c_lent(v_i_24518, MK_INT(0LL), 2)) {
    heff_drop(v_i_24518);
    return v_d_24515;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24518, v_d_24515});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_k_24516 = args[0];
  V v_d_24515 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 1, 2, (V[]){v_k_24516, v_d_24515})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_i_24548 = args[0];
  V v_k_24547 = heff_env(self)[0];
  V v_d_24538 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24549 = heff_intSub(v_k_24547, v_i_24548);
  if (heff_intEq_c_lent(v_i_24549, MK_INT(0LL), 2)) {
    heff_drop(v_i_24549);
    return v_d_24538;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24549, v_d_24538});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_k_24547 = args[0];
  V v_d_24538 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 1, 2, (V[]){v_k_24547, v_d_24538})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24Atom = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24e0_241_24Atom, v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2412 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2412));
  }
  case TAG_Named: {
    V v_o_2413 = heff_field(v_e0_241, 0);
    V v_x_2414 = heff_field(v_e0_241, 1);
    V v_k_2415 = heff_field(v_e0_241, 2);
    V v_e_2416 = heff_field(v_e0_241, 3);
    V v_c_2417 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2418 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2413));
    V v_a_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2414));
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2415));
    V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_2416}));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2421));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_a_2419, v_t_2424));
    V v_t_2426 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2417));
    V v_t_2427 = (g_std_2edoc_2e_3c_3e(v_t_2425, v_t_2426));
    return (g_std_2edoc_2e_3c_3e(v_t_2418, v_t_2427));
  }
  case TAG_Tup: {
    V v_o_2428 = heff_field(v_e0_241, 0);
    V v_es_2429 = heff_field(v_e0_241, 1);
    V v_commas_2430 = heff_field(v_e0_241, 2);
    V v_c_2431 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_es_2429)) {
    case TAG_Nil: {
      heff_drop(v_commas_2430);
      V v_t_2432 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2428));
      V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2431));
      return (g_std_2edoc_2e_3c_3e(v_t_2432, v_t_2433));
    }
    case TAG_Cons: {
      V v_e1_2434 = heff_field(v_es_2429, 0);
      V v_more_2435 = heff_field(v_es_2429, 1);
      V v_ru_24es_2429_24Cons = heff_take_reuse_n(v_es_2429, 3ULL, 2);
      V v_t_2436 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2428)));
      V v_t_2437 = heff_tag_at_n(v_ru_24es_2429_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_one_2438 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_240)}));
      V v_t_2439 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e1_2434));
      V v_t_2443;
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop(v_t_2439);
        V v_d_2440 = heff_tr(heff_call(v_one_2438, 1, (V[]){v_e1_2434}));
        v_t_2443 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2440});
      } else {
        heff_drop(v_t_2439);
        V v_t_2441 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e1_2434));
        if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
          heff_drop(v_t_2441);
          V v_d_2442 = heff_tr(heff_call(v_one_2438, 1, (V[]){v_e1_2434}));
          v_t_2443 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2442});
        } else {
          heff_drop(v_t_2441);
          v_t_2443 = heff_tr(heff_call(v_one_2438, 1, (V[]){v_e1_2434}));
        }
      }
      V v_t_2455 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2430; V a_3 = v_more_2435; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2430); heff_drop(v_more_2435); r_; });
      V v_x1_2456 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2428, 4, 9), heff_dup(heff_rfield(v_c_2431, 3))));
      V v_t_2457;
      if ((heff_dup(v_x1_2456) == NTAG(TAG_True))) {
        heff_drop(v_x1_2456);
        v_t_2457 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2456);
        v_t_2457 = heff_dup(g_std_2edoc_2elinebreak_get());
      }
      V v_t_2458 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2431));
      V v_t_2459 = (g_std_2edoc_2e_3c_3e(v_t_2457, v_t_2458));
      V v_t_2460 = (g_std_2edoc_2e_3c_3e(v_t_2455, v_t_2459));
      V v_t_2461 = (g_std_2edoc_2e_3c_3e(v_t_2443, v_t_2460));
      V v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2437, v_t_2461));
      V v_d_2463 = (g_std_2edoc_2e_3c_3e(v_t_2436, v_t_2462));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2463})})));
    }
    default: return heff_nomatch(v_es_2429);
    }
  }
  case TAG_Seg: {
    V v_v_2467 = heff_field(v_e0_241, 0);
    V v_cc_2468 = heff_field(v_e0_241, 1);
    V v_spec_2469 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_2470 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_v_2467}));
    V v_t_2471 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_2468));
    V v_t_2473 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 1, 1, (V[]){v_env_240}); V a_2 = v_spec_2469; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_spec_2469); r_; });
    V v_t_2474 = (g_std_2edoc_2e_3c_3e(v_t_2471, v_t_2473));
    return (g_std_2edoc_2e_3c_3e(v_t_2470, v_t_2474));
  }
  case TAG_Braces: {
    V v_o_2475 = heff_field(v_e0_241, 0);
    V v_fs_2476 = heff_field(v_e0_241, 1);
    V v_commas_2477 = heff_field(v_e0_241, 2);
    V v_c_2478 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_fs_2476)) {
    case TAG_Nil: {
      heff_drop(v_commas_2477);
      V v_t_2479 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2475));
      V v_t_2480 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2478));
      return (g_std_2edoc_2e_3c_3e(v_t_2479, v_t_2480));
    }
    case TAG_Cons: {
      V v_f1_2481 = heff_field(v_fs_2476, 0);
      V v_more_2482 = heff_field(v_fs_2476, 1);
      V v_ru_24fs_2476_24Cons = heff_take_reuse_n(v_fs_2476, 3ULL, 2);
      V v_a_2483 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2475)));
      V v_d_2484 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 16)), 2, (V[]){heff_dup(v_env_240), v_f1_2481}));
      V v_t_2485 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), heff_tag_at_n(v_ru_24fs_2476_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2484})));
      V v_t_2486 = (g_std_2edoc_2e_3c_3e(v_a_2483, v_t_2485));
      V v_t_2493 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2477; V a_3 = v_more_2482; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2477); heff_drop(v_more_2482); r_; });
      V v_x1_2494 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2475, 4, 9), heff_dup(heff_rfield(v_c_2478, 3))));
      V v_t_2495;
      if ((heff_dup(v_x1_2494) == NTAG(TAG_True))) {
        heff_drop(v_x1_2494);
        v_t_2495 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2494);
        v_t_2495 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_2496 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2478));
      V v_t_2497 = (g_std_2edoc_2e_3c_3e(v_t_2495, v_t_2496));
      V v_t_2498 = (g_std_2edoc_2e_3c_3e(v_t_2493, v_t_2497));
      V v_d_2499 = (g_std_2edoc_2e_3c_3e(v_t_2486, v_t_2498));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 1, (V[]){v_d_2499})})));
    }
    default: return heff_nomatch(v_fs_2476);
    }
  }
  case TAG_Update: {
    V v_o_24103 = heff_field(v_e0_241, 0);
    V v_r_24104 = heff_field(v_e0_241, 1);
    V v_bar_24105 = heff_field(v_e0_241, 2);
    V v_fs_24106 = heff_field(v_e0_241, 3);
    V v_commas_24107 = heff_field(v_e0_241, 4);
    V v_c_24108 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_fs_24106)) {
    case TAG_Nil: {
      heff_drop(v_commas_24107);
      V v_a_24109 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24103));
      V v_a_24110 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24104}));
      V v_a_24111 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24105));
      V v_b_24112 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24108));
      V v_t_24113 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_24112));
      V v_t_24114 = (g_std_2edoc_2e_3c_3e(v_a_24111, v_t_24113));
      V v_t_24115 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_t_24114));
      V v_t_24116 = (g_std_2edoc_2e_3c_3e(v_a_24110, v_t_24115));
      V v_t_24117 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_t_24116));
      return (g_std_2edoc_2e_3c_3e(v_a_24109, v_t_24117));
    }
    case TAG_Cons: {
      V v_f1_24118 = heff_field(v_fs_24106, 0);
      V v_more_24119 = heff_field(v_fs_24106, 1);
      V v_ru_24fs_24106_24Cons = heff_take_reuse_n(v_fs_24106, 3ULL, 2);
      V v_a_24120 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24103)));
      V v_d_24121 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24104}));
      V v_t_24122 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), heff_tag_at_n(v_ru_24fs_24106_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24121})));
      V v_t_24123 = (g_std_2edoc_2e_3c_3e(v_a_24120, v_t_24122));
      V v_a_24124 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24105));
      V v_d_24125 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 16)), 2, (V[]){heff_dup(v_env_240), v_f1_24118}));
      V v_t_24126 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24125})));
      V v_t_24127 = (g_std_2edoc_2e_3c_3e(v_a_24124, v_t_24126));
      V v_t_24134 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_24107; V a_3 = v_more_24119; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_24107); heff_drop(v_more_24119); r_; });
      V v_x1_24135 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24103, 4, 9), heff_dup(heff_rfield(v_c_24108, 3))));
      V v_t_24136;
      if ((heff_dup(v_x1_24135) == NTAG(TAG_True))) {
        heff_drop(v_x1_24135);
        v_t_24136 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24135);
        v_t_24136 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_24137 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24108));
      V v_t_24138 = (g_std_2edoc_2e_3c_3e(v_t_24136, v_t_24137));
      V v_t_24139 = (g_std_2edoc_2e_3c_3e(v_t_24134, v_t_24138));
      V v_t_24140 = (g_std_2edoc_2e_3c_3e(v_t_24127, v_t_24139));
      V v_t_24141 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24140));
      V v_d_24142 = (g_std_2edoc_2e_3c_3e(v_t_24123, v_t_24141));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 1, (V[]){v_d_24142})})));
    }
    default: return heff_nomatch(v_fs_24106);
    }
  }
  case TAG_EUSet: {
    V v_x_24146 = heff_field(v_e0_241, 0);
    V v_eq_24147 = heff_field(v_e0_241, 1);
    V v_e_24148 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24149 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_x_24146}));
    V v_b_24150 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24147));
    V v_t_24151 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24150));
    V v_t_24152 = (g_std_2edoc_2e_3c_3e(v_a_24149, v_t_24151));
    V v_t_24153 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24148}));
    return (g_std_2edoc_2e_3c_3e(v_t_24152, v_t_24153));
  }
  case TAG_InstB: {
    V v_o_24154 = heff_field(v_e0_241, 0);
    V v_o2_24155 = heff_field(v_e0_241, 1);
    V v_d_24156 = heff_field(v_e0_241, 2);
    V v_c1_24157 = heff_field(v_e0_241, 3);
    V v_c_24158 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24159 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24154));
    V v_t_24160 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_24155));
    V v_t_24161 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24156}));
    V v_t_24162 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_24157));
    V v_t_24163 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24158));
    V v_t_24164 = (g_std_2edoc_2e_3c_3e(v_t_24162, v_t_24163));
    V v_t_24165 = (g_std_2edoc_2e_3c_3e(v_t_24161, v_t_24164));
    V v_t_24166 = (g_std_2edoc_2e_3c_3e(v_t_24160, v_t_24165));
    return (g_std_2edoc_2e_3c_3e(v_t_24159, v_t_24166));
  }
  case TAG_EFSet: {
    V v_x_24167 = heff_field(v_e0_241, 0);
    V v_eq_24168 = heff_field(v_e0_241, 1);
    V v_e_24169 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24170 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24167));
    V v_b_24171 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24168));
    V v_t_24172 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24171));
    V v_t_24173 = (g_std_2edoc_2e_3c_3e(v_a_24170, v_t_24172));
    V v_t_24174 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24169}));
    return (g_std_2edoc_2e_3c_3e(v_t_24173, v_t_24174));
  }
  case TAG_EFDefault: {
    V v_d_24175 = heff_field(v_e0_241, 0);
    V v_eq_24176 = heff_field(v_e0_241, 1);
    V v_e_24177 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24178 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24175}));
    V v_b_24179 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24176));
    V v_t_24180 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_b_24179));
    V v_t_24181 = (g_std_2edoc_2e_3c_3e(v_a_24178, v_t_24180));
    V v_t_24182 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24177}));
    return (g_std_2edoc_2e_3c_3e(v_t_24181, v_t_24182));
  }
  case TAG_Sum: {
    V v_kw_24183 = heff_field(v_e0_241, 0);
    V v_o_24184 = heff_field(v_e0_241, 1);
    V v_alts_24185 = heff_field(v_e0_241, 2);
    V v_bars_24186 = heff_field(v_e0_241, 3);
    V v_c_24187 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    switch (heff_tag_of(v_alts_24185)) {
    case TAG_Nil: {
      heff_drop(v_bars_24186);
      V v_a_24188 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24183));
      V v_a_24189 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24184));
      V v_b_24190 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24187));
      V v_t_24191 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24190));
      V v_t_24192 = (g_std_2edoc_2e_3c_3e(v_a_24189, v_t_24191));
      V v_t_24193 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_t_24192));
      return (g_std_2edoc_2e_3c_3e(v_a_24188, v_t_24193));
    }
    case TAG_Cons: {
      V v_a1_24194 = heff_field(v_alts_24185, 0);
      V v_more_24195 = heff_field(v_alts_24185, 1);
      V v_ru_24alts_24185_24Cons = heff_take_reuse_n(v_alts_24185, 3ULL, 2);
      V v_a_24196 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24183));
      V v_a_24197 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24184)));
      V v_b_24198 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_24194}));
      V v_t_24199 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24alts_24185_24Cons, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24198));
      V v_t_24200 = (g_std_2edoc_2e_3c_3e(v_a_24197, v_t_24199));
      V v_a_24209 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 2, 3, (V[]){heff_dup(v_env_240), v_o_24184, heff_dup(v_c_24187)}); V a_2 = v_bars_24186; V a_3 = v_more_24195; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_24186); heff_drop(v_more_24195); r_; });
      V v_b_24210 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24187));
      V v_t_24211 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19)}), v_b_24210));
      V v_t_24212 = (g_std_2edoc_2e_3c_3e(v_a_24209, v_t_24211));
      V v_d_24213 = (g_std_2edoc_2e_3c_3e(v_t_24200, v_t_24212));
      V v_b_24217 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 1, (V[]){v_d_24213})})));
      V v_t_24218 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24217));
      return (g_std_2edoc_2e_3c_3e(v_a_24196, v_t_24218));
    }
    default: return heff_nomatch(v_alts_24185);
    }
  }
  case TAG_ECon: {
    V v_c_24219 = heff_field(v_e0_241, 0);
    V v_args_24220 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ECon = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_t_24221 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24219));
    V v_t_24224 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 1, 1, (V[]){v_env_240}); V a_2 = v_args_24220; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24220); r_; });
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24ECon, v_t_24221, v_t_24224));
  }
  case TAG_EField: {
    V v_e_24225 = heff_field(v_e0_241, 0);
    V v_f_24226 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EField = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_t_24227 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24225}));
    V v_t_24228 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_f_24226));
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24EField, v_t_24227, v_t_24228));
  }
  case TAG_ENeg: {
    V v_m_24229 = heff_field(v_e0_241, 0);
    V v_e_24230 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ENeg = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_t_24231 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24229));
    V v_t_24232 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24230}));
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24ENeg, v_t_24231, v_t_24232));
  }
  case TAG_ETilde: {
    V v_m_24233 = heff_field(v_e0_241, 0);
    V v_e_24234 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ETilde = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_t_24235 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24233));
    V v_t_24236 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24234}));
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24ETilde, v_t_24235, v_t_24236));
  }
  case TAG_App: {
    V v_h_24237 = heff_field(v_e0_241, 0);
    V v_args_24238 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
    heff_room[0] = v_env_240;
    heff_room[1] = MK_INT(0LL);
    heff_room[2] = v_h_24237;
    heff_room[3] = v_args_24238;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  case TAG_Op: {
    V v_a_24239 = heff_field(v_e0_241, 0);
    V v_op_24240 = heff_field(v_e0_241, 1);
    V v_b_24241 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    HeffT2 v_t_24242 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_dup(v_b_24241)));
    {
      V v_field_24243 = v_t_24242.f[0];
      V v_field_24244 = v_t_24242.f[1];
      V v_bf_24245 = v_field_24243;
      V v_rest_24246 = v_field_24244;
      V v_t_24247 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_24240), v_rest_24246));
      if ((heff_dup(v_t_24247) == NTAG(TAG_True))) {
        heff_drop(v_b_24241);
        heff_drop(v_t_24247);
        V v_t_24248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_24240), heff_dup(v_bf_24245)}), heff_dup(v_rest_24246)});
        V v_t_24249 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 3, (V[]){heff_dup(v_env_240), v_t_24248, v_a_24239}));
        V v_f_24255 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 1, 4, (V[]){heff_dup(v_op_24240), heff_dup(v_bf_24245), heff_dup(v_rest_24246), v_env_240});
        V v_t_24256 = heff_tr(heff_call(heff_dup(v_f_24255), 1, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_24240, v_bf_24245})}));
        V v_t_24257 = (g_list_2emap(v_f_24255, v_rest_24246));
        V v_ds_24258 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24256, v_t_24257});
        V v_t_24259 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24258; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop_tag(v_ds_24258, 2); r_; });
        V v_t_24260 = (g_std_2edoc_2e_3c_3e(v_t_24249, v_t_24259));
        return (g_std_2edoc_2egroup(v_t_24260));
      } else {
        heff_drop(v_bf_24245);
        heff_drop(v_rest_24246);
        heff_drop(v_t_24247);
        V v_t_24261 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_24240), heff_dup(v_b_24241)}), NTAG(TAG_Nil)});
        V v_t_24262 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 3, (V[]){heff_dup(v_env_240), v_t_24261, v_a_24239}));
        V v_x1_24263 = ({ V b_0 = heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_24240), heff_dup(v_b_24241)}); V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(b_0)); heff_drop(b_0); r_; });
        V v_t_24264;
        if ((heff_dup(v_x1_24263) == NTAG(TAG_True))) {
          heff_drop(v_x1_24263);
          v_t_24264 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_24263);
          v_t_24264 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_t_24265 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_24240), heff_dup(v_b_24241)}), NTAG(TAG_Nil)});
        V v_t_24266 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 3, (V[]){v_env_240, v_t_24265, heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_24240, v_b_24241})}));
        V v_t_24267 = (g_std_2edoc_2e_3c_3e(v_t_24264, v_t_24266));
        V v_ds_24268 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24267, NTAG(TAG_Nil)});
        V v_t_24269 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24268; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop_tag(v_ds_24268, 2); r_; });
        V v_t_24270 = (g_std_2edoc_2e_3c_3e(v_t_24262, v_t_24269));
        return (g_std_2edoc_2egroup(v_t_24270));
      }
    }
  }
  case TAG_Ops: {
    V v_a_24271 = heff_field(v_e0_241, 0);
    V v_rest_24272 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
    heff_room[0] = v_env_240;
    heff_room[1] = v_a_24271;
    heff_room[2] = v_rest_24272;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_OpRhs: {
    V v_op_24273 = heff_field(v_e0_241, 0);
    V v_e_24274 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24OpRhs = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_a_24275 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24273));
    V v_b_24276 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24274}));
    V v_t_24277 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24OpRhs, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24276));
    return (g_std_2edoc_2e_3c_3e(v_a_24275, v_t_24277));
  }
  case TAG_Ann: {
    V v_e_24278 = heff_field(v_e0_241, 0);
    V v_cc_24279 = heff_field(v_e0_241, 1);
    V v_ty_24280 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24281 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24278}));
    V v_b_24282 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24279));
    V v_t_24283 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24282));
    V v_t_24284 = (g_std_2edoc_2e_3c_3e(v_a_24281, v_t_24283));
    V v_t_24285 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_24280}));
    V v_d_24286 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24285));
    V v_t_24287 = (g_std_2edoc_2e_3c_3e(v_t_24284, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24286})));
    return (g_std_2edoc_2egroup(v_t_24287));
  }
  case TAG_BVar: {
    V v_t_24288 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24BVar = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24e0_241_24BVar, v_env_240, v_t_24288));
  }
  case TAG_BImp: {
    V v_o_24289 = heff_field(v_e0_241, 0);
    V v_x_24290 = heff_field(v_e0_241, 1);
    V v_c_24291 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_24292 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24289));
    V v_t_24293 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24290));
    V v_t_24294 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24291));
    V v_t_24295 = (g_std_2edoc_2e_3c_3e(v_t_24293, v_t_24294));
    return (g_std_2edoc_2e_3c_3e(v_t_24292, v_t_24295));
  }
  case TAG_BAnn: {
    V v_o_24296 = heff_field(v_e0_241, 0);
    V v_x_24297 = heff_field(v_e0_241, 1);
    V v_cc_24298 = heff_field(v_e0_241, 2);
    V v_ty_24299 = heff_field(v_e0_241, 3);
    V v_c_24300 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24301 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24296));
    V v_a_24302 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24297));
    V v_a_24303 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24298));
    V v_b_24304 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24299}));
    V v_t_24305 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24304));
    V v_t_24306 = (g_std_2edoc_2e_3c_3e(v_a_24303, v_t_24305));
    V v_t_24307 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_t_24306));
    V v_t_24308 = (g_std_2edoc_2e_3c_3e(v_a_24302, v_t_24307));
    V v_t_24309 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24300));
    V v_t_24310 = (g_std_2edoc_2e_3c_3e(v_t_24308, v_t_24309));
    return (g_std_2edoc_2e_3c_3e(v_t_24301, v_t_24310));
  }
  case TAG_BPat: {
    V v_p_24311 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return ({ V a_0 = v_env_240; V a_1 = v_p_24311; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24311); r_; });
  }
  case TAG_Lam: {
    V v_bs_24312 = heff_field(v_e0_241, 0);
    V v_binders_24313 = heff_field(v_e0_241, 1);
    V v_arrow_24314 = heff_field(v_e0_241, 2);
    V v_body_24315 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24316 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24312));
    V v_t_24317 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24318 = (g_list_2emap(v_t_24317, v_binders_24313));
    V v_a_24319 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26); V a_1 = v_t_24318; V r_ = (g_std_2edoc_2econcatWith_24s593061764x1986092725(a_0, a_1)); heff_drop(v_t_24318); r_; });
    V v_b_24320 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24314));
    V v_t_24321 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24320));
    V v_t_24322 = (g_std_2edoc_2e_3c_3e(v_a_24319, v_t_24321));
    V v_t_24323 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24315));
    V v_t_24327;
    if ((heff_dup(v_t_24323) == NTAG(TAG_True))) {
      heff_drop(v_t_24323);
      V v_t_24324 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24315}));
      v_t_24327 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_t_24324));
    } else {
      heff_drop(v_t_24323);
      V v_t_24325 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 2, (V[]){v_env_240, v_body_24315}));
      V v_d_24326 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24325));
      v_t_24327 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24326})));
    }
    V v_t_24328 = (g_std_2edoc_2e_3c_3e(v_t_24322, v_t_24327));
    return (g_std_2edoc_2e_3c_3e(v_t_24316, v_t_24328));
  }
  case TAG_Case: {
    V v_kw_24329 = heff_field(v_e0_241, 0);
    V v_scrut_24330 = heff_field(v_e0_241, 1);
    V v_of2_24331 = heff_field(v_e0_241, 2);
    V v_alts_24332 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24333 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24329));
    V v_a_24334 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_scrut_24330}));
    V v_b_24335 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24331));
    V v_t_24336 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_b_24335));
    V v_t_24337 = (g_std_2edoc_2e_3c_3e(v_a_24334, v_t_24336));
    V v_t_24338 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_t_24337));
    V v_t_24339 = (g_std_2edoc_2e_3c_3e(v_a_24333, v_t_24338));
    V v_t_24340 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24332; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622(a_0, a_1, a_2)); heff_drop(v_alts_24332); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24339, v_t_24340));
  }
  case TAG_EAlt: {
    V v_p_24341 = heff_field(v_e0_241, 0);
    V v_arrow_24342 = heff_field(v_e0_241, 1);
    V v_body_24343 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24344 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24341; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24341); r_; });
    V v_b_24345 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24342));
    V v_t_24346 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24345));
    V v_t_24347 = (g_std_2edoc_2e_3c_3e(v_a_24344, v_t_24346));
    V v_t_24348 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_body_24343}));
    return (g_std_2edoc_2e_3c_3e(v_t_24347, v_t_24348));
  }
  case TAG_If: {
    V v_kw_24349 = heff_field(v_e0_241, 0);
    V v_c_24350 = heff_field(v_e0_241, 1);
    V v_th_24351 = heff_field(v_e0_241, 2);
    V v_a_24352 = heff_field(v_e0_241, 3);
    V v_el_24353 = heff_field(v_e0_241, 4);
    V v_b_24354 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_t_24355 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_240), v_kw_24349, v_c_24350, v_th_24351, v_a_24352}));
    V v_t_24356 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_240, v_el_24353, v_b_24354}));
    V v_t_24357 = (g_std_2edoc_2e_3c_3e(v_t_24355, v_t_24356));
    return (g_std_2edoc_2egroup(v_t_24357));
  }
  case TAG_Do: {
    V v_kw_24358 = heff_field(v_e0_241, 0);
    V v_stmts_24359 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24Do = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_t_24360 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24358));
    V v_t_24361 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24359; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop(v_stmts_24359); r_; });
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24Do, v_t_24360, v_t_24361));
  }
  case TAG_ESBind: {
    V v_x_24362 = heff_field(v_e0_241, 0);
    V v_arrow_24363 = heff_field(v_e0_241, 1);
    V v_e_24364 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24365 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_x_24362; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_24362); r_; });
    V v_b_24366 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24363));
    V v_t_24367 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24366));
    V v_t_24368 = (g_std_2edoc_2e_3c_3e(v_a_24365, v_t_24367));
    V v_t_24369 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24364}));
    return (g_std_2edoc_2e_3c_3e(v_t_24368, v_t_24369));
  }
  case TAG_ELet: {
    V v_kw_24370 = heff_field(v_e0_241, 0);
    V v_p_24371 = heff_field(v_e0_241, 1);
    V v_ann_24372 = heff_field(v_e0_241, 2);
    V v_eq_24373 = heff_field(v_e0_241, 3);
    V v_e_24374 = heff_field(v_e0_241, 4);
    V v_body_24375 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_body_24375)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){v_env_240, v_kw_24370, v_p_24371, v_ann_24372, v_eq_24373, v_e_24374});
    }
    case TAG_Just: {
      V v_it1_24376 = heff_field(v_body_24375, 0);
      V v_ru_24body_24375_24Just = heff_take_reuse_n(v_body_24375, 1ULL, 1);
      switch (heff_tag_of(v_it1_24376)) {
      case TAG_MkPair: {
        V v_i_24377 = heff_field(v_it1_24376, 0);
        V v_b_24378 = heff_field(v_it1_24376, 1);
        V v_ru_24it1_24376_24MkPair = heff_take_reuse_n(v_it1_24376, 3ULL, 2);
        V v_t_24379 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_240, v_kw_24370, v_p_24371, v_ann_24372, v_eq_24373, v_e_24374, v_i_24377, v_b_24378}));
        V v_d_24380 = (g_std_2edoc_2egroup_24tok2(v_ru_24it1_24376_24MkPair, v_t_24379));
        return heff_tag_at_n(v_ru_24body_24375_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 1, 1, (V[]){v_d_24380})});
      }
      default: return heff_nomatch(v_it1_24376);
      }
    }
    default: return heff_nomatch(v_body_24375);
    }
  }
  case TAG_ELetElse: {
    V v_kw_24384 = heff_field(v_e0_241, 0);
    V v_p_24385 = heff_field(v_e0_241, 1);
    V v_ann_24386 = heff_field(v_e0_241, 2);
    V v_eq_24387 = heff_field(v_e0_241, 3);
    V v_e_24388 = heff_field(v_e0_241, 4);
    V v_el_24389 = heff_field(v_e0_241, 5);
    V v_ss_24390 = heff_field(v_e0_241, 6);
    heff_take_n(v_e0_241, 127ULL, 7);
    V v_a_24391 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_240), v_kw_24384, v_p_24385, v_ann_24386, v_eq_24387, v_e_24388}));
    V v_b_24392 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_el_24389));
    V v_t_24393 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), v_b_24392));
    V v_t_24394 = (g_std_2edoc_2e_3c_3e(v_a_24391, v_t_24393));
    V v_t_24402;
    switch (heff_tag_of(v_ss_24390)) {
    case TAG_Nil: {
      v_t_24402 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(v_env_240, MK_INT(0LL), v_ss_24390));
      break;
    }
    case TAG_Cons: {
      V v_s1_24395 = heff_dup(heff_field(v_ss_24390, 0));
      V v_it2_24396 = heff_dup(heff_field(v_ss_24390, 1));
      switch (heff_tag_of(v_it2_24396)) {
      case TAG_Nil: {
        V v_t_24397 = (g_heff_2esyntax_2ecst_2efirstE(v_s1_24395));
        V v_t_24398 = heff_get_n(v_t_24397, 6, 9);
        if ((heff_dup(v_t_24398) == NTAG(TAG_True))) {
          heff_drop(v_s1_24395);
          heff_drop(v_t_24398);
          v_t_24402 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_ss_24390; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop_tag(v_ss_24390, 2); r_; });
        } else {
          heff_drop_tag(v_ss_24390, 2);
          heff_drop(v_t_24398);
          V v_t_24399 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_s1_24395}));
          v_t_24402 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), v_t_24399));
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_it2_24396, 0ULL, 2);
        heff_drop(v_s1_24395);
        v_t_24402 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_ss_24390; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop_tag(v_ss_24390, 2); r_; });
        break;
      }
      default: heff_nomatch(v_it2_24396);
      }
      break;
    }
    default: heff_nomatch(v_ss_24390);
    }
    return (g_std_2edoc_2e_3c_3e(v_t_24394, v_t_24402));
  }
  case TAG_ELetMut: {
    V v_kw_24403 = heff_field(v_e0_241, 0);
    V v_m_24404 = heff_field(v_e0_241, 1);
    V v_x_24405 = heff_field(v_e0_241, 2);
    V v_ann_24406 = heff_field(v_e0_241, 3);
    V v_eq_24407 = heff_field(v_e0_241, 4);
    V v_e_24408 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24409 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24403));
    V v_a_24410 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24404));
    V v_b_24411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24405));
    V v_t_24412 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), v_b_24411));
    V v_t_24413 = (g_std_2edoc_2e_3c_3e(v_a_24410, v_t_24412));
    V v_t_24414 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), v_t_24413));
    V v_t_24415 = (g_std_2edoc_2e_3c_3e(v_a_24409, v_t_24414));
    V v_a_24423;
    switch (heff_tag_of(v_ann_24406)) {
    case TAG_Nothing: {
      v_a_24423 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_it1_24416 = heff_field(v_ann_24406, 0);
      V v_ru_24ann_24406_24Just = heff_take_reuse_n(v_ann_24406, 1ULL, 1);
      switch (heff_tag_of(v_it1_24416)) {
      case TAG_MkPair: {
        V v_cc_24417 = heff_field(v_it1_24416, 0);
        V v_ty_24418 = heff_field(v_it1_24416, 1);
        V v_ru_24it1_24416_24MkPair = heff_take_reuse_n(v_it1_24416, 3ULL, 2);
        V v_a_24419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24417));
        V v_b_24420 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24418}));
        V v_t_24421 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24it1_24416_24MkPair, heff_tag_at_n(v_ru_24ann_24406_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), v_b_24420));
        V v_t_24422 = (g_std_2edoc_2e_3c_3e(v_a_24419, v_t_24421));
        v_a_24423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), v_t_24422));
        break;
      }
      default: heff_nomatch(v_it1_24416);
      }
      break;
    }
    default: heff_nomatch(v_ann_24406);
    }
    V v_b_24424 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24407));
    V v_t_24425 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), v_b_24424));
    V v_t_24426 = (g_std_2edoc_2e_3c_3e(v_a_24423, v_t_24425));
    V v_t_24427 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24408}));
    V v_t_24428 = (g_std_2edoc_2e_3c_3e(v_t_24426, v_t_24427));
    return (g_std_2edoc_2e_3c_3e(v_t_24415, v_t_24428));
  }
  case TAG_EAssign: {
    V v_x_24429 = heff_field(v_e0_241, 0);
    V v_k_24430 = heff_field(v_e0_241, 1);
    V v_e_24431 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24432 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24429));
    V v_b_24433 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_24430));
    V v_t_24434 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), v_b_24433));
    V v_t_24435 = (g_std_2edoc_2e_3c_3e(v_a_24432, v_t_24434));
    V v_t_24436 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24431}));
    return (g_std_2edoc_2e_3c_3e(v_t_24435, v_t_24436));
  }
  case TAG_EWhile: {
    V v_kw_24437 = heff_field(v_e0_241, 0);
    V v_c_24438 = heff_field(v_e0_241, 1);
    V v_d_24439 = heff_field(v_e0_241, 2);
    V v_body_24440 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24441 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24437));
    V v_d_24442 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24438}));
    V v_b_24443 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24439));
    V v_t_24444 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), v_b_24443));
    V v_t_24448 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 1, 1, (V[]){v_d_24442})}), v_t_24444));
    V v_t_24449 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), v_t_24448));
    V v_t_24450 = (g_std_2edoc_2e_3c_3e(v_a_24441, v_t_24449));
    V v_t_24451 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24440; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop(v_body_24440); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24450, v_t_24451));
  }
  case TAG_EFor: {
    V v_kw_24452 = heff_field(v_e0_241, 0);
    V v_p_24453 = heff_field(v_e0_241, 1);
    V v_i_24454 = heff_field(v_e0_241, 2);
    V v_c_24455 = heff_field(v_e0_241, 3);
    V v_d_24456 = heff_field(v_e0_241, 4);
    V v_body_24457 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24458 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24452));
    V v_a_24459 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24453; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24453); r_; });
    V v_a_24460 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_i_24454));
    V v_d_24461 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24455}));
    V v_b_24462 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24456));
    V v_t_24463 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), v_b_24462));
    V v_t_24467 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 1, 1, (V[]){v_d_24461})}), v_t_24463));
    V v_t_24468 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), v_t_24467));
    V v_t_24469 = (g_std_2edoc_2e_3c_3e(v_a_24460, v_t_24468));
    V v_t_24470 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), v_t_24469));
    V v_t_24471 = (g_std_2edoc_2e_3c_3e(v_a_24459, v_t_24470));
    V v_t_24472 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), v_t_24471));
    V v_t_24473 = (g_std_2edoc_2e_3c_3e(v_a_24458, v_t_24472));
    V v_t_24474 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop(v_body_24457); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24473, v_t_24474));
  }
  case TAG_EJump: {
    V v_kw_24475 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24EJump = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24e0_241_24EJump, v_env_240, v_kw_24475));
  }
  case TAG_EReturn: {
    V v_kw_24476 = heff_field(v_e0_241, 0);
    V v_e_24477 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_a_24478 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24476));
    V v_d_24479 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24477}));
    V v_t_24480 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24479})));
    return (g_std_2edoc_2e_3c_3e(v_a_24478, v_t_24480));
  }
  case TAG_ENest: {
    V v_o_24481 = heff_field(v_e0_241, 0);
    V v_arrow_24482 = heff_field(v_e0_241, 1);
    V v_e_24483 = heff_field(v_e0_241, 2);
    V v_c_24484 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24485 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24481));
    V v_a_24486 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24482));
    V v_b_24487 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24483}));
    V v_t_24488 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), v_b_24487));
    V v_t_24489 = (g_std_2edoc_2e_3c_3e(v_a_24486, v_t_24488));
    V v_t_24490 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24484));
    V v_t_24491 = (g_std_2edoc_2e_3c_3e(v_t_24489, v_t_24490));
    return (g_std_2edoc_2e_3c_3e(v_t_24485, v_t_24491));
  }
  case TAG_EArrow: {
    V v_arrow_24492 = heff_field(v_e0_241, 0);
    V v_e_24493 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EArrow = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_a_24494 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24492));
    V v_b_24495 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24493}));
    V v_t_24496 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24EArrow, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), v_b_24495));
    return (g_std_2edoc_2e_3c_3e(v_a_24494, v_t_24496));
  }
  case TAG_IfThen: {
    V v_kw_24497 = heff_field(v_e0_241, 0);
    V v_c_24498 = heff_field(v_e0_241, 1);
    V v_th_24499 = heff_field(v_e0_241, 2);
    V v_a_24500 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24501 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){v_env_240, v_kw_24497, v_c_24498, v_th_24499, v_a_24500}));
    return (g_std_2edoc_2egroup(v_t_24501));
  }
  case TAG_ETry: {
    V v_kw_24502 = heff_field(v_e0_241, 0);
    V v_ty_24503 = heff_field(v_e0_241, 1);
    V v_body_24504 = heff_field(v_e0_241, 2);
    V v_c_24505 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24506 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24502));
    V v_t_24509;
    switch (heff_tag_of(v_ty_24503)) {
    case TAG_Nothing: {
      v_t_24509 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_t_24507 = heff_field(v_ty_24503, 0);
      V v_ru_24ty_24503_24Just = heff_take_reuse_n(v_ty_24503, 1ULL, 1);
      V v_t_24508 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_t_24507}));
      v_t_24509 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ty_24503_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), v_t_24508));
      break;
    }
    default: heff_nomatch(v_ty_24503);
    }
    V v_d_24510 = ({ V a_0 = heff_dup(v_env_240); V a_1 = MK_INT(0LL); V a_2 = v_body_24504; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop(v_body_24504); r_; });
    V v_t_24511 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_c_24505}));
    V v_t_24512 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_24511));
    V v_t_24513 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24510}), v_t_24512));
    V v_t_24514 = (g_std_2edoc_2e_3c_3e(v_t_24509, v_t_24513));
    V v_d_24515 = (g_std_2edoc_2e_3c_3e(v_t_24506, v_t_24514));
    return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 1, 1, (V[]){v_d_24515})});
  }
  case TAG_ECatch: {
    V v_kw_24519 = heff_field(v_e0_241, 0);
    V v_b_24520 = heff_field(v_e0_241, 1);
    V v_arrow_24521 = heff_field(v_e0_241, 2);
    V v_body_24522 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24523 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24519));
    V v_a_24524 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 2, (V[]){heff_dup(v_env_240), v_b_24520}));
    V v_b_24525 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24521));
    V v_t_24526 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), v_b_24525));
    V v_t_24527 = (g_std_2edoc_2e_3c_3e(v_a_24524, v_t_24526));
    V v_t_24528 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), v_t_24527));
    V v_t_24529 = (g_std_2edoc_2e_3c_3e(v_a_24523, v_t_24528));
    V v_d_24530 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24522; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop(v_body_24522); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24529, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24530})));
  }
  case TAG_EWith: {
    V v_kw_24531 = heff_field(v_e0_241, 0);
    V v_e_24532 = heff_field(v_e0_241, 1);
    V v_a_24533 = heff_field(v_e0_241, 2);
    V v_x_24534 = heff_field(v_e0_241, 3);
    V v_d_24535 = heff_field(v_e0_241, 4);
    V v_body_24536 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24537 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24531));
    V v_d_24538 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24532}));
    V v_a_24539 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_a_24533));
    V v_a_24540 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_x_24534; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_24534); r_; });
    V v_b_24541 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24535));
    V v_t_24542 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), v_b_24541));
    V v_t_24543 = (g_std_2edoc_2e_3c_3e(v_a_24540, v_t_24542));
    V v_t_24544 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), v_t_24543));
    V v_t_24545 = (g_std_2edoc_2e_3c_3e(v_a_24539, v_t_24544));
    V v_t_24546 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), v_t_24545));
    V v_t_24550 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 1, 1, (V[]){v_d_24538})}), v_t_24546));
    V v_t_24551 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), v_t_24550));
    V v_t_24552 = (g_std_2edoc_2e_3c_3e(v_a_24537, v_t_24551));
    V v_t_24553 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24536; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop(v_body_24536); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24552, v_t_24553));
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_env_24554 = args[0];
  V v_e_24555 = args[1];
  V v_t_24556 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24555));
  if ((heff_dup(v_t_24556) == NTAG(TAG_True))) {
    heff_drop(v_t_24556);
    V v_t_24557 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24554, v_e_24555}));
    return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)}), v_t_24557));
  } else {
    heff_drop(v_t_24556);
    V v_t_24558 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 2, (V[]){v_env_24554, v_e_24555}));
    V v_t_24559 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24558));
    return (g_std_2edoc_2egroup(v_t_24559));
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_env_24560 = args[0];
  V v_kw_24561 = args[1];
  V v_p_24562 = args[2];
  V v_ann_24563 = args[3];
  V v_eq_24564 = args[4];
  V v_e_24565 = args[5];
  V v_a_24566 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24560), v_kw_24561));
  V v_b_24567 = ({ V a_0 = heff_dup(v_env_24560); V a_1 = v_p_24562; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24562); r_; });
  V v_t_24568 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), v_b_24567));
  V v_t_24569 = (g_std_2edoc_2e_3c_3e(v_a_24566, v_t_24568));
  V v_a_24577;
  switch (heff_tag_of(v_ann_24563)) {
  case TAG_Nothing: {
    v_a_24577 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24570 = heff_field(v_ann_24563, 0);
    V v_ru_24ann_24563_24Just = heff_take_reuse_n(v_ann_24563, 1ULL, 1);
    switch (heff_tag_of(v_it1_24570)) {
    case TAG_MkPair: {
      V v_cc_24571 = heff_field(v_it1_24570, 0);
      V v_ty_24572 = heff_field(v_it1_24570, 1);
      V v_ru_24it1_24570_24MkPair = heff_take_reuse_n(v_it1_24570, 3ULL, 2);
      V v_a_24573 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24560), v_cc_24571));
      V v_b_24574 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24560), v_ty_24572}));
      V v_t_24575 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24it1_24570_24MkPair, heff_tag_at_n(v_ru_24ann_24563_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), v_b_24574));
      V v_t_24576 = (g_std_2edoc_2e_3c_3e(v_a_24573, v_t_24575));
      v_a_24577 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), v_t_24576));
      break;
    }
    default: heff_nomatch(v_it1_24570);
    }
    break;
  }
  default: heff_nomatch(v_ann_24563);
  }
  V v_b_24578 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24560), v_eq_24564));
  V v_t_24579 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), v_b_24578));
  V v_t_24580 = (g_std_2edoc_2e_3c_3e(v_a_24577, v_t_24579));
  V v_t_24581 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24560, v_e_24565}));
  V v_t_24582 = (g_std_2edoc_2e_3c_3e(v_t_24580, v_t_24581));
  return (g_std_2edoc_2e_3c_3e(v_t_24569, v_t_24582));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_env_24583 = args[0];
  V v_kw_24584 = args[1];
  V v_p_24585 = args[2];
  V v_ann_24586 = args[3];
  V v_eq_24587 = args[4];
  V v_e_24588 = args[5];
  V v_i_24589 = args[6];
  V v_b_24590 = args[7];
  V v_d_24591 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_24583), v_kw_24584, v_p_24585, v_ann_24586, v_eq_24587, v_e_24588}));
  V v_t_24592 = heff_dup(heff_rfield(v_i_24589, 6));
  V v_t_24595;
  if ((heff_dup(v_t_24592) == NTAG(TAG_True))) {
    heff_drop(v_t_24592);
    v_t_24595 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24592);
    V v_t_24593 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24590));
    V v_x1_24594 = heff_get_n(v_t_24593, 6, 9);
    if ((heff_dup(v_x1_24594) == NTAG(TAG_True))) {
      heff_drop(v_x1_24594);
      v_t_24595 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24594);
      v_t_24595 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24596 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24583), v_i_24589));
  V v_b_24612;
  switch (heff_tag_of(v_b_24590)) {
  case TAG_ELet: {
    V v_it6_24602 = heff_dup(heff_field(v_b_24590, 5));
    switch (heff_tag_of(v_it6_24602)) {
    case TAG_Nothing: {
      v_b_24612 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24583, v_b_24590}));
      break;
    }
    case TAG_Just: {
      V v_it61_24603 = heff_field(v_it6_24602, 0);
      heff_take_n(v_it6_24602, 1ULL, 1);
      switch (heff_tag_of(v_b_24590)) {
      case TAG_ELet: {
        V v_kw2_24604 = heff_field(v_b_24590, 0);
        V v_p2_24605 = heff_field(v_b_24590, 1);
        V v_ann2_24606 = heff_field(v_b_24590, 2);
        V v_eq2_24607 = heff_field(v_b_24590, 3);
        V v_e2_24608 = heff_field(v_b_24590, 4);
        heff_take_n(v_b_24590, 31ULL, 6);
        switch (heff_tag_of(v_it61_24603)) {
        case TAG_MkPair: {
          V v_i2_24610 = heff_field(v_it61_24603, 0);
          V v_b2_24611 = heff_field(v_it61_24603, 1);
          heff_take_n(v_it61_24603, 3ULL, 2);
          v_b_24612 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_24583, v_kw2_24604, v_p2_24605, v_ann2_24606, v_eq2_24607, v_e2_24608, v_i2_24610, v_b2_24611}));
          break;
        }
        default: heff_nomatch(v_it61_24603);
        }
        break;
      }
      default: heff_nomatch(v_b_24590);
      }
      break;
    }
    default: heff_nomatch(v_it6_24602);
    }
    break;
  }
  default: {
    v_b_24612 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24583, v_b_24590}));
    break;
  }
  }
  V v_t_24613 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), v_b_24612));
  V v_t_24614 = (g_std_2edoc_2e_3c_3e(v_a_24596, v_t_24613));
  V v_t_24615 = (g_std_2edoc_2e_3c_3e(v_t_24595, v_t_24614));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24591}), v_t_24615));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_i_24624 = args[0];
  V v_k_24623 = heff_env(self)[0];
  V v_d_24622 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24625 = heff_intSub(v_k_24623, v_i_24624);
  if (heff_intEq_c_lent(v_i_24625, MK_INT(0LL), 2)) {
    heff_drop(v_i_24625);
    return v_d_24622;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24625, v_d_24622});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_k_24623 = args[0];
  V v_d_24622 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 1, 2, (V[]){v_k_24623, v_d_24622})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_env_24616 = args[0];
  V v_kw_24617 = args[1];
  V v_c_24618 = args[2];
  V v_th_24619 = args[3];
  V v_a_24620 = args[4];
  V v_a_24621 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24616), v_kw_24617));
  V v_d_24622 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24616), v_c_24618}));
  V v_t_24626 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){v_d_24622})})));
  V v_t_24627 = (g_std_2edoc_2e_3c_3e(v_a_24621, v_t_24626));
  V v_t_24628 = heff_dup(heff_rfield(v_th_24619, 6));
  V v_t_24631;
  if ((heff_dup(v_t_24628) == NTAG(TAG_True))) {
    heff_drop(v_t_24628);
    v_t_24631 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24628);
    V v_t_24629 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24620));
    V v_x1_24630 = heff_get_n(v_t_24629, 6, 9);
    if ((heff_dup(v_x1_24630) == NTAG(TAG_True))) {
      heff_drop(v_x1_24630);
      v_t_24631 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24630);
      v_t_24631 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24632 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24616), v_th_24619));
  V v_d_24633 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24616, v_a_24620}));
  V v_t_24634 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24633})));
  V v_t_24635 = (g_std_2edoc_2e_3c_3e(v_a_24632, v_t_24634));
  V v_t_24636 = (g_std_2edoc_2e_3c_3e(v_t_24631, v_t_24635));
  V v_t_24637 = (g_std_2edoc_2e_3c_3e(v_t_24627, v_t_24636));
  return (g_std_2edoc_2egroup(v_t_24637));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_env_24638 = args[0];
  V v_el_24639 = args[1];
  V v_b_24640 = args[2];
  switch (heff_tag_of(v_b_24640)) {
  case TAG_If: {
    V v_kw_24641 = heff_dup(heff_field(v_b_24640, 0));
    V v_c_24642 = heff_dup(heff_field(v_b_24640, 1));
    V v_th_24643 = heff_dup(heff_field(v_b_24640, 2));
    V v_a_24644 = heff_dup(heff_field(v_b_24640, 3));
    V v_el2_24645 = heff_dup(heff_field(v_b_24640, 4));
    V v_b2_24646 = heff_dup(heff_field(v_b_24640, 5));
    V v_t_24647 = heff_dup(heff_rfield(v_el_24639, 6));
    V v_t_24650;
    if ((heff_dup(v_t_24647) == NTAG(TAG_True))) {
      heff_drop_tag(v_b_24640, 6);
      heff_drop(v_t_24647);
      v_t_24650 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24647);
      V v_t_24648 = ({ V a_0 = v_b_24640; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_b_24640, 6); r_; });
      V v_x1_24649 = heff_get_n(v_t_24648, 6, 9);
      if ((heff_dup(v_x1_24649) == NTAG(TAG_True))) {
        heff_drop(v_x1_24649);
        v_t_24650 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24649);
        v_t_24650 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24651 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24638), v_el_24639));
    V v_b_24652 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_24638), v_kw_24641, v_c_24642, v_th_24643, v_a_24644}));
    V v_t_24653 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), v_b_24652));
    V v_t_24654 = (g_std_2edoc_2e_3c_3e(v_a_24651, v_t_24653));
    V v_t_24655 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_24638, v_el2_24645, v_b2_24646}));
    V v_t_24656 = (g_std_2edoc_2e_3c_3e(v_t_24654, v_t_24655));
    return (g_std_2edoc_2e_3c_3e(v_t_24650, v_t_24656));
  }
  default: {
    V v_t_24657 = heff_dup(heff_rfield(v_el_24639, 6));
    V v_t_24660;
    if ((heff_dup(v_t_24657) == NTAG(TAG_True))) {
      heff_drop(v_t_24657);
      v_t_24660 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24657);
      V v_t_24658 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24640));
      V v_x1_24659 = heff_get_n(v_t_24658, 6, 9);
      if ((heff_dup(v_x1_24659) == NTAG(TAG_True))) {
        heff_drop(v_x1_24659);
        v_t_24660 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24659);
        v_t_24660 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24661 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24638), v_el_24639));
    V v_d_24662 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24638, v_b_24640}));
    V v_t_24663 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24662})));
    V v_t_24664 = (g_std_2edoc_2e_3c_3e(v_a_24661, v_t_24663));
    return (g_std_2edoc_2e_3c_3e(v_t_24660, v_t_24664));
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_a_24679 = args[0];
  V v_one_24678 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24680 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24679));
  V v_x1_24681 = heff_get_n(v_t_24680, 6, 9);
  V v_t_24682;
  if ((heff_dup(v_x1_24681) == NTAG(TAG_True))) {
    heff_drop(v_x1_24681);
    v_t_24682 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24681);
    v_t_24682 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24683 = heff_tr(heff_call(v_one_24678, 1, (V[]){v_a_24679}));
  return (g_std_2edoc_2e_3c_3e(v_t_24682, v_t_24683));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_a_24696 = args[0];
  V v_one_24695 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24697 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24696));
  V v_x1_24698 = heff_get_n(v_t_24697, 6, 9);
  V v_t_24699;
  if ((heff_dup(v_x1_24698) == NTAG(TAG_True))) {
    heff_drop(v_x1_24698);
    v_t_24699 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24698);
    v_t_24699 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24700 = heff_tr(heff_call(v_one_24695, 1, (V[]){v_a_24696}));
  return (g_std_2edoc_2e_3c_3e(v_t_24699, v_t_24700));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_a_24706 = args[0];
  V v_one_24705 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24707 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24706));
  V v_x1_24708 = heff_get_n(v_t_24707, 6, 9);
  V v_t_24709;
  if ((heff_dup(v_x1_24708) == NTAG(TAG_True))) {
    heff_drop(v_x1_24708);
    v_t_24709 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24708);
    v_t_24709 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24710 = heff_tr(heff_call(v_one_24705, 1, (V[]){v_a_24706}));
  return (g_std_2edoc_2e_3c_3e(v_t_24709, v_t_24710));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_a_24719 = args[0];
  V v_one_24718 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24720 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24719));
  V v_x1_24721 = heff_get_n(v_t_24720, 6, 9);
  V v_t_24722;
  if ((heff_dup(v_x1_24721) == NTAG(TAG_True))) {
    heff_drop(v_x1_24721);
    v_t_24722 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24721);
    v_t_24722 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24723 = heff_tr(heff_call(v_one_24718, 1, (V[]){v_a_24719}));
  return (g_std_2edoc_2e_3c_3e(v_t_24722, v_t_24723));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_env_24665 = args[0];
  V v_hang_24666 = args[1];
  V v_h_24667 = args[2];
  V v_args_24668 = args[3];
  V v_x1_24669 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_24668)));
  switch (heff_tag_of(v_x1_24669)) {
  case TAG_Nil: {
    heff_drop(v_hang_24666);
    heff_drop(v_args_24668);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24665;
    args[1] = v_h_24667;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Cons: {
    V v_x_24670 = heff_field(v_x1_24669, 0);
    V v_rev_24671 = heff_field(v_x1_24669, 1);
    V v_ru_24x1_24669_24Cons = heff_take_reuse_n(v_x1_24669, 3ULL, 2);
    V v_init2_24672 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_24671));
    switch (heff_tag_of(v_x_24670)) {
    case TAG_EParen: {
      V v_o_24673 = heff_field(v_x_24670, 0);
      V v_e_24674 = heff_field(v_x_24670, 1);
      V v_c_24675 = heff_field(v_x_24670, 2);
      heff_take_n(v_x_24670, 7ULL, 3);
      V v_t_24676 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_24674));
      if ((heff_dup(v_t_24676) == NTAG(TAG_True))) {
        heff_drop(v_args_24668);
        heff_drop(v_t_24676);
        V v_t_24677 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24665), v_h_24667}));
        V v_one_24678 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24665)}));
        V v_d_24684 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){v_one_24678}); V a_2 = v_init2_24672; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24672); r_; });
        V v_t_24685 = (g_std_2edoc_2e_3c_3e(v_t_24677, heff_tag_at_n(v_ru_24x1_24669_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24684})));
        V v_a_24686 = (g_std_2edoc_2egroup(v_t_24685));
        V v_t_24687 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24665), v_o_24673));
        V v_t_24688 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24665), v_e_24674}));
        V v_t_24689 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24665, v_c_24675));
        V v_t_24690 = (g_std_2edoc_2e_3c_3e(v_t_24688, v_t_24689));
        V v_d_24691 = (g_std_2edoc_2e_3c_3e(v_t_24687, v_t_24690));
        V v_t_24692;
        if (heff_intEq_c_lent(v_hang_24666, MK_INT(0LL), 2)) {
          heff_drop(v_hang_24666);
          v_t_24692 = v_d_24691;
        } else {
          v_t_24692 = heff_tag_n(TAG_Nest, 2, (V[]){v_hang_24666, v_d_24691});
        }
        V v_t_24693 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), v_t_24692));
        return (g_std_2edoc_2e_3c_3e(v_a_24686, v_t_24693));
      } else {
        heff_drop(v_hang_24666);
        heff_drop(v_init2_24672);
        heff_drop(v_o_24673);
        heff_drop(v_e_24674);
        heff_drop(v_c_24675);
        heff_drop(v_t_24676);
        V v_t_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24665), v_h_24667}));
        V v_one_24695 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24665}));
        V v_d_24701 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 1, 1, (V[]){v_one_24695}); V a_2 = v_args_24668; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24668); r_; });
        V v_t_24702 = (g_std_2edoc_2e_3c_3e(v_t_24694, heff_tag_at_n(v_ru_24x1_24669_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24701})));
        return (g_std_2edoc_2egroup(v_t_24702));
      }
    }
    default: {
      V v_t_24703 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_24670));
      if ((heff_dup(v_t_24703) == NTAG(TAG_True))) {
        heff_drop(v_args_24668);
        heff_drop(v_t_24703);
        V v_t_24704 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24665), v_h_24667}));
        V v_one_24705 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24665)}));
        V v_d_24711 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 1, 1, (V[]){v_one_24705}); V a_2 = v_init2_24672; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24672); r_; });
        V v_t_24712 = (g_std_2edoc_2e_3c_3e(v_t_24704, heff_tag_at_n(v_ru_24x1_24669_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24711})));
        V v_a_24713 = (g_std_2edoc_2egroup(v_t_24712));
        V v_d_24714 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24665, v_x_24670}));
        V v_t_24715;
        if (heff_intEq_c_lent(v_hang_24666, MK_INT(0LL), 2)) {
          heff_drop(v_hang_24666);
          v_t_24715 = v_d_24714;
        } else {
          v_t_24715 = heff_tag_n(TAG_Nest, 2, (V[]){v_hang_24666, v_d_24714});
        }
        V v_t_24716 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68)}), v_t_24715));
        return (g_std_2edoc_2e_3c_3e(v_a_24713, v_t_24716));
      } else {
        heff_drop(v_hang_24666);
        heff_drop(v_x_24670);
        heff_drop(v_init2_24672);
        heff_drop(v_t_24703);
        V v_t_24717 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24665), v_h_24667}));
        V v_one_24718 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24665}));
        V v_d_24724 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){v_one_24718}); V a_2 = v_args_24668; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24668); r_; });
        V v_t_24725 = (g_std_2edoc_2e_3c_3e(v_t_24717, heff_tag_at_n(v_ru_24x1_24669_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24724})));
        return (g_std_2edoc_2egroup(v_t_24725));
      }
    }
    }
  }
  default: return heff_nomatch(v_x1_24669);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_env_24726 = args[0];
  V v_e_24727 = args[1];
  switch (heff_tag_of(v_e_24727)) {
  case TAG_App: {
    V v_h_24728 = heff_dup(heff_field(v_e_24727, 0));
    V v_args_24729 = heff_dup(heff_field(v_e_24727, 1));
    V v_t_24730 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e_24727));
    if ((heff_dup(v_t_24730) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_24727, 2);
      heff_drop(v_t_24730);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
      heff_room[0] = v_env_24726;
      heff_room[1] = MK_INT(2LL);
      heff_room[2] = v_h_24728;
      heff_room[3] = v_args_24729;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    } else {
      heff_drop(v_h_24728);
      heff_drop(v_args_24729);
      heff_drop(v_t_24730);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_24726;
      args[1] = v_e_24727;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24726;
    args[1] = v_e_24727;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_env_24731 = args[0];
  V v_rest_24732 = args[1];
  V v_e_24733 = args[2];
  switch (heff_tag_of(v_e_24733)) {
  case TAG_Braces: {
    V v_o_24734 = heff_field(v_e_24733, 0);
    V v_fs_24735 = heff_field(v_e_24733, 1);
    V v_commas_24736 = heff_field(v_e_24733, 2);
    V v_c_24737 = heff_field(v_e_24733, 3);
    heff_take_n(v_e_24733, 15ULL, 4);
    switch (heff_tag_of(v_fs_24735)) {
    case TAG_Nil: {
      heff_drop(v_rest_24732);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_24731;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24734, v_fs_24735, v_commas_24736, v_c_24737});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_24738 = heff_dup(heff_field(v_fs_24735, 0));
      V v_rest2_24739 = heff_dup(heff_field(v_fs_24735, 1));
      switch (heff_tag_of(v_rest2_24739)) {
      case TAG_Nil: {
        V v_t_24740 = ({ V a_0 = v_rest_24732; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_24732); r_; });
        if ((heff_dup(v_t_24740) == NTAG(TAG_True))) {
          heff_drop(v_t_24740);
          V v_x1_24741 = heff_dup(v_d_24738);
          V v_x1_24898;
          switch (heff_tag_of(v_x1_24741)) {
          case TAG_Atom: {
            heff_take_n(v_x1_24741, 0ULL, 1);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_EParen: {
            heff_take_n(v_x1_24741, 0ULL, 3);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_Named: {
            heff_take_n(v_x1_24741, 0ULL, 5);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_Tup: {
            heff_take_n(v_x1_24741, 0ULL, 4);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_Seg: {
            heff_take_n(v_x1_24741, 0ULL, 3);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_Braces: {
            heff_take_n(v_x1_24741, 0ULL, 4);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_Update: {
            heff_take_n(v_x1_24741, 0ULL, 6);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_EUSet: {
            heff_take_n(v_x1_24741, 0ULL, 3);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_InstB: {
            heff_take_n(v_x1_24741, 0ULL, 5);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_EFSet: {
            heff_take_n(v_x1_24741, 0ULL, 3);
            v_x1_24898 = NTAG(TAG_True);
            break;
          }
          case TAG_EFDefault: {
            V v_eq_24780 = heff_field(v_x1_24741, 1);
            heff_take_n(v_x1_24741, 2ULL, 3);
            v_x1_24898 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_eq_24780, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69)));
            heff_drop_rec(v_eq_24780, 9);
            break;
          }
          case TAG_Sum: {
            heff_take_n(v_x1_24741, 0ULL, 5);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_ECon: {
            heff_take_n(v_x1_24741, 0ULL, 2);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_EField: {
            heff_take_n(v_x1_24741, 0ULL, 2);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_ENeg: {
            heff_take_n(v_x1_24741, 0ULL, 2);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_ETilde: {
            heff_take_n(v_x1_24741, 0ULL, 2);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_App: {
            heff_take_n(v_x1_24741, 0ULL, 2);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_Op: {
            heff_take_n(v_x1_24741, 0ULL, 3);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_Ops: {
            heff_take_n(v_x1_24741, 0ULL, 2);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_OpRhs: {
            heff_take_n(v_x1_24741, 0ULL, 2);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_Ann: {
            heff_take_n(v_x1_24741, 0ULL, 3);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_BVar: {
            heff_take_n(v_x1_24741, 0ULL, 1);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_BImp: {
            heff_take_n(v_x1_24741, 0ULL, 3);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_BAnn: {
            heff_take_n(v_x1_24741, 0ULL, 5);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_BPat: {
            heff_take_n(v_x1_24741, 0ULL, 1);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_Lam: {
            heff_take_n(v_x1_24741, 0ULL, 4);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_Case: {
            heff_take_n(v_x1_24741, 0ULL, 4);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_EAlt: {
            heff_take_n(v_x1_24741, 0ULL, 3);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_If: {
            heff_take_n(v_x1_24741, 0ULL, 6);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_Do: {
            heff_take_n(v_x1_24741, 0ULL, 2);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_ESBind: {
            heff_take_n(v_x1_24741, 0ULL, 3);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_ELet: {
            heff_take_n(v_x1_24741, 0ULL, 6);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_ELetElse: {
            heff_take_n(v_x1_24741, 0ULL, 7);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_ELetMut: {
            heff_take_n(v_x1_24741, 0ULL, 6);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_EAssign: {
            heff_take_n(v_x1_24741, 0ULL, 3);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_EWhile: {
            heff_take_n(v_x1_24741, 0ULL, 4);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_EFor: {
            heff_take_n(v_x1_24741, 0ULL, 6);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_EJump: {
            heff_take_n(v_x1_24741, 0ULL, 1);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_EReturn: {
            heff_take_n(v_x1_24741, 0ULL, 2);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_x1_24741, 0ULL, 4);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_EArrow: {
            heff_take_n(v_x1_24741, 0ULL, 2);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_IfThen: {
            heff_take_n(v_x1_24741, 0ULL, 4);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_x1_24741, 0ULL, 4);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_ECatch: {
            heff_take_n(v_x1_24741, 0ULL, 4);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_x1_24741, 0ULL, 6);
            v_x1_24898 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x1_24741);
          }
          if (!(heff_dup(v_x1_24898) == NTAG(TAG_True))) {
            heff_drop(v_x1_24898);
            switch (heff_tag_of(v_commas_24736)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_24735, 2);
              V v_t_24899 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24731), v_o_24734));
              V v_t_24900 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24731), v_d_24738}));
              V v_t_24901 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24731, v_c_24737));
              V v_t_24902 = (g_std_2edoc_2e_3c_3e(v_t_24900, v_t_24901));
              return (g_std_2edoc_2e_3c_3e(v_t_24899, v_t_24902));
            }
            case TAG_Cons: {
              heff_drop(v_d_24738);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_24731;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24734, v_fs_24735, v_commas_24736, v_c_24737});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_24736);
            }
          } else {
            heff_drop(v_d_24738);
            heff_drop(v_x1_24898);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_24731;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24734, v_fs_24735, v_commas_24736, v_c_24737});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          }
        } else {
          heff_drop(v_d_24738);
          heff_drop(v_t_24740);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_24731;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24734, v_fs_24735, v_commas_24736, v_c_24737});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_24739, 0ULL, 2);
        heff_drop(v_rest_24732);
        heff_drop(v_d_24738);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_24731;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24734, v_fs_24735, v_commas_24736, v_c_24737});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_24739);
      }
    }
    default: return heff_nomatch(v_fs_24735);
    }
  }
  default: {
    heff_drop(v_rest_24732);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24731;
    args[1] = v_e_24733;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_env_24907 = args[0];
  V v_b_24908 = args[1];
  switch (heff_tag_of(v_b_24908)) {
  case TAG_BVar: {
    V v_t_24909 = heff_field(v_b_24908, 0);
    V v_ru_24b_24908_24BVar = heff_take_reuse_n(v_b_24908, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24b_24908_24BVar, v_env_24907, v_t_24909));
  }
  case TAG_BImp: {
    V v_o_24910 = heff_field(v_b_24908, 0);
    V v_x_24911 = heff_field(v_b_24908, 1);
    V v_c_24912 = heff_field(v_b_24908, 2);
    heff_take_n(v_b_24908, 7ULL, 3);
    V v_t_24913 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24907), v_o_24910));
    V v_t_24914 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24907), v_x_24911));
    V v_t_24915 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24907, v_c_24912));
    V v_t_24916 = (g_std_2edoc_2e_3c_3e(v_t_24914, v_t_24915));
    return (g_std_2edoc_2e_3c_3e(v_t_24913, v_t_24916));
  }
  case TAG_BAnn: {
    V v_o_24917 = heff_field(v_b_24908, 0);
    V v_x_24918 = heff_field(v_b_24908, 1);
    V v_cc_24919 = heff_field(v_b_24908, 2);
    V v_ty_24920 = heff_field(v_b_24908, 3);
    V v_c_24921 = heff_field(v_b_24908, 4);
    heff_take_n(v_b_24908, 31ULL, 5);
    V v_t_24922 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24907), v_o_24917));
    V v_a_24923 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24907), v_x_24918));
    V v_a_24924 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24907), v_cc_24919));
    V v_b_24925 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24907), v_ty_24920}));
    V v_t_24926 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70)}), v_b_24925));
    V v_t_24927 = (g_std_2edoc_2e_3c_3e(v_a_24924, v_t_24926));
    V v_t_24928 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71)}), v_t_24927));
    V v_t_24929 = (g_std_2edoc_2e_3c_3e(v_a_24923, v_t_24928));
    V v_t_24930 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24907, v_c_24921));
    V v_t_24931 = (g_std_2edoc_2e_3c_3e(v_t_24929, v_t_24930));
    return (g_std_2edoc_2e_3c_3e(v_t_24922, v_t_24931));
  }
  case TAG_BPat: {
    V v_p_24932 = heff_field(v_b_24908, 0);
    heff_take_n(v_b_24908, 1ULL, 1);
    return ({ V a_0 = v_env_24907; V a_1 = v_p_24932; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24932); r_; });
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24907;
    args[1] = v_b_24908;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_env_24933 = args[0];
  V v_rest_24934 = args[1];
  V v_r_24935 = args[2];
  switch (heff_tag_of(v_r_24935)) {
  case TAG_OpRhs: {
    V v_op_24936 = heff_field(v_r_24935, 0);
    V v_e_24937 = heff_field(v_r_24935, 1);
    V v_ru_24r_24935_24OpRhs = heff_take_reuse_n(v_r_24935, 3ULL, 2);
    V v_a_24938 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24933), v_op_24936));
    V v_b_24939 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 3, (V[]){v_env_24933, v_rest_24934, v_e_24937}));
    V v_t_24940 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24r_24935_24OpRhs, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), v_b_24939));
    return (g_std_2edoc_2e_3c_3e(v_a_24938, v_t_24940));
  }
  default: {
    heff_drop(v_rest_24934);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24933;
    args[1] = v_r_24935;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_env_24941 = args[0];
  V v_r_24942 = args[1];
  switch (heff_tag_of(v_r_24942)) {
  case TAG_OpRhs: {
    V v_op_24943 = heff_field(v_r_24942, 0);
    V v_e_24944 = heff_field(v_r_24942, 1);
    V v_ru_24r_24942_24OpRhs = heff_take_reuse_n(v_r_24942, 3ULL, 2);
    V v_a_24945 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24941), v_op_24943));
    V v_b_24946 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24941, v_e_24944}));
    V v_t_24947 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24r_24942_24OpRhs, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)}), v_b_24946));
    return (g_std_2edoc_2e_3c_3e(v_a_24945, v_t_24947));
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24941;
    args[1] = v_r_24942;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_r_24960 = args[0];
  V v_env_24948 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24961 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_24960));
  V v_t_24962;
  if ((heff_dup(v_x1_24961) == NTAG(TAG_True))) {
    heff_drop(v_x1_24961);
    v_t_24962 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24961);
    v_t_24962 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24963 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 2, (V[]){v_env_24948, v_r_24960}));
  return (g_std_2edoc_2e_3c_3e(v_t_24962, v_t_24963));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_r_24969 = args[0];
  V v_env_24948 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24970 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_24969));
  V v_t_24971;
  if ((heff_dup(v_x1_24970) == NTAG(TAG_True))) {
    heff_drop(v_x1_24970);
    v_t_24971 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24970);
    v_t_24971 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24972 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 2, (V[]){v_env_24948, v_r_24969}));
  return (g_std_2edoc_2e_3c_3e(v_t_24971, v_t_24972));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_env_24948 = args[0];
  V v_first_24949 = args[1];
  V v_rest_24950 = args[2];
  V v_f_24951 = heff_dup(heff_rfield(v_env_24948, 6));
  HeffT2 v_t_24952 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(heff_dup(v_f_24951), heff_dup(v_rest_24950)));
  {
    V v_field_24954 = v_t_24952.f[1];
    int64_t v_tag_24953 = ((int64_t)v_t_24952.f[0]);
    V v_t_24958;
    if ((v_tag_24953 == ((int64_t)0ULL))) {
      V v_it1_24955 = v_field_24954;
      switch (heff_tag_of(v_it1_24955)) {
      case TAG_Nil: {
        heff_drop(v_f_24951);
        v_t_24958 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_o_24956 = heff_field(v_it1_24955, 0);
        V v_os_24957 = heff_field(v_it1_24955, 1);
        heff_take_n(v_it1_24955, 3ULL, 2);
        v_t_24958 = ({ V a_0 = v_f_24951; V a_1 = v_o_24956; V a_2 = v_os_24957; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_os_24957); r_; });
        break;
      }
      default: heff_nomatch(v_it1_24955);
      }
    } else {
      heff_drop(v_f_24951);
      heff_drop(v_field_24954);
      v_t_24958 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_24958)) {
    case TAG_Nothing: {
      V v_t_24959 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24948), v_first_24949}));
      V v_t_24964 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 1, 1, (V[]){v_env_24948}); V a_2 = v_rest_24950; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_24950); r_; });
      V v_t_24965 = (g_std_2edoc_2e_3c_3e(v_t_24959, v_t_24964));
      return (g_std_2edoc_2egroup(v_t_24965));
    }
    case TAG_Just: {
      V v_m_24966 = heff_field(v_t_24958, 0);
      heff_take_n(v_t_24958, 1ULL, 1);
      V v_t_24967 = (g_list_2eall_24s78096928x1476871221(heff_dup(heff_rfield(v_env_24948, 6)), heff_dup(v_m_24966), v_rest_24950));
      if ((heff_dup(v_t_24967) == NTAG(TAG_True))) {
        heff_drop(v_m_24966);
        heff_drop(v_t_24967);
        V v_t_24968 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24948), v_first_24949}));
        V v_t_24973 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 1, 1, (V[]){v_env_24948}); V a_2 = v_rest_24950; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_24950); r_; });
        V v_t_24974 = (g_std_2edoc_2e_3c_3e(v_t_24968, v_t_24973));
        return (g_std_2edoc_2egroup(v_t_24974));
      } else {
        heff_drop(v_t_24967);
        V v_t_24975 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13)), 5, (V[]){v_env_24948, v_m_24966, v_first_24949, NTAG(TAG_Nil), v_rest_24950}));
        return (g_std_2edoc_2egroup(v_t_24975));
      }
    }
    default: return heff_nomatch(v_t_24958);
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_env_24976 = args[0];
  V v_m_24977 = args[1];
  V v_f_24978 = args[2];
  V v_acc_24979 = args[3];
  V v_rs_24980 = args[4];
  switch (heff_tag_of(v_rs_24980)) {
  case TAG_Nil: {
    heff_drop(v_m_24977);
    V v_t_24981 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_24979));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
    args[0] = v_env_24976;
    args[1] = v_f_24978;
    args[2] = v_t_24981;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_r_24982 = heff_field(v_rs_24980, 0);
    V v_rest2_24983 = heff_field(v_rs_24980, 1);
    V v_ru_24rs_24980_24Cons = heff_take_reuse_n(v_rs_24980, 3ULL, 2);
    switch (heff_tag_of(v_r_24982)) {
    case TAG_OpRhs: {
      V v_op_24984 = heff_dup(heff_field(v_r_24982, 0));
      V v_e_24985 = heff_dup(heff_field(v_r_24982, 1));
      V v_t_24986 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_24976, 6)), heff_dup(v_m_24977), heff_dup(heff_rfield(v_op_24984, 1))));
      switch (heff_tag_of(v_t_24986)) {
      case TAG_Tighter: {
        heff_drop_cell(v_ru_24rs_24980_24Cons, 2);
        heff_drop_rec(v_op_24984, 9);
        heff_drop(v_e_24985);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
        args[0] = v_env_24976;
        args[1] = v_m_24977;
        args[2] = v_f_24978;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_24982, v_acc_24979});
        args[4] = v_rest2_24983;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Looser: {
        heff_drop_cell(v_ru_24rs_24980_24Cons, 2);
        heff_drop_rec(v_op_24984, 9);
        heff_drop(v_e_24985);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
        args[0] = v_env_24976;
        args[1] = v_m_24977;
        args[2] = v_f_24978;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_24982, v_acc_24979});
        args[4] = v_rest2_24983;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Same: {
        V v_ru_24t_24986_24Same = heff_take_reuse_n(v_t_24986, 0ULL, 1);
        V v_t_24988 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_24979));
        V v_t_24989 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 3, (V[]){heff_dup(v_env_24976), v_f_24978, v_t_24988}));
        V v_x1_24990 = ({ V a_0 = v_r_24982; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a_0)); heff_drop_tag(v_r_24982, 2); r_; });
        V v_t_24991;
        if ((heff_dup(v_x1_24990) == NTAG(TAG_True))) {
          heff_drop(v_x1_24990);
          v_t_24991 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_24990);
          v_t_24991 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_a_24992 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24976), v_op_24984));
        V v_b_24993 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13)), 5, (V[]){v_env_24976, v_m_24977, v_e_24985, NTAG(TAG_Nil), v_rest2_24983}));
        V v_t_24994 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24rs_24980_24Cons, heff_tag_at_n(v_ru_24t_24986_24Same, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), v_b_24993));
        V v_t_24995 = (g_std_2edoc_2e_3c_3e(v_a_24992, v_t_24994));
        V v_t_24996 = (g_std_2edoc_2e_3c_3e(v_t_24991, v_t_24995));
        return (g_std_2edoc_2e_3c_3e(v_t_24989, v_t_24996));
      }
      case TAG_Unrelated: {
        heff_drop_cell(v_ru_24rs_24980_24Cons, 2);
        heff_drop_rec(v_op_24984, 9);
        heff_drop(v_e_24985);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
        args[0] = v_env_24976;
        args[1] = v_m_24977;
        args[2] = v_f_24978;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_24982, v_acc_24979});
        args[4] = v_rest2_24983;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_24986, 0ULL, 1);
        heff_drop_cell(v_ru_24rs_24980_24Cons, 2);
        heff_drop_rec(v_op_24984, 9);
        heff_drop(v_e_24985);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
        args[0] = v_env_24976;
        args[1] = v_m_24977;
        args[2] = v_f_24978;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_24982, v_acc_24979});
        args[4] = v_rest2_24983;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      default: return heff_nomatch(v_t_24986);
      }
    }
    default: {
      heff_drop_cell(v_ru_24rs_24980_24Cons, 2);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
      args[0] = v_env_24976;
      args[1] = v_m_24977;
      args[2] = v_f_24978;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_24982, v_acc_24979});
      args[4] = v_rest2_24983;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    }
  }
  default: return heff_nomatch(v_rs_24980);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_env_24998 = args[0];
  V v_a_24999 = args[1];
  switch (heff_tag_of(v_a_24999)) {
  case TAG_EAlt: {
    V v_p_241000 = heff_field(v_a_24999, 0);
    V v_arrow_241001 = heff_field(v_a_24999, 1);
    V v_body_241002 = heff_field(v_a_24999, 2);
    heff_take_n(v_a_24999, 7ULL, 3);
    V v_a_241003 = ({ V a_0 = heff_dup(v_env_24998); V a_1 = v_p_241000; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_241000); r_; });
    V v_b_241004 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24998), v_arrow_241001));
    V v_t_241005 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), v_b_241004));
    V v_t_241006 = (g_std_2edoc_2e_3c_3e(v_a_241003, v_t_241005));
    V v_t_241007 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24998, v_body_241002}));
    return (g_std_2edoc_2e_3c_3e(v_t_241006, v_t_241007));
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24998;
    args[1] = v_a_24999;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_env_241008 = args[0];
  V v_s_241009 = args[1];
  switch (heff_tag_of(v_s_241009)) {
  case TAG_If: {
    V v_d_241016 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241008, v_s_241009}));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(-2LL), v_d_241016});
  }
  case TAG_ESBind: {
    V v_x_241017 = heff_field(v_s_241009, 0);
    V v_arrow_241018 = heff_field(v_s_241009, 1);
    V v_e_241019 = heff_field(v_s_241009, 2);
    heff_take_n(v_s_241009, 7ULL, 3);
    V v_a_241020 = ({ V a_0 = heff_dup(v_env_241008); V a_1 = v_x_241017; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_241017); r_; });
    V v_b_241021 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241008), v_arrow_241018));
    V v_t_241022 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), v_b_241021));
    V v_t_241023 = (g_std_2edoc_2e_3c_3e(v_a_241020, v_t_241022));
    V v_t_241024 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241008, v_e_241019}));
    return (g_std_2edoc_2e_3c_3e(v_t_241023, v_t_241024));
  }
  case TAG_IfThen: {
    V v_d_241029 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241008, v_s_241009}));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(-2LL), v_d_241029});
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241008;
    args[1] = v_s_241009;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_env_241030 = args[0];
  V v_f_241031 = args[1];
  switch (heff_tag_of(v_f_241031)) {
  case TAG_EUSet: {
    V v_x_241032 = heff_field(v_f_241031, 0);
    V v_eq_241033 = heff_field(v_f_241031, 1);
    V v_e_241034 = heff_field(v_f_241031, 2);
    heff_take_n(v_f_241031, 7ULL, 3);
    V v_a_241035 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241030), v_x_241032}));
    V v_b_241036 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241030), v_eq_241033));
    V v_t_241037 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), v_b_241036));
    V v_t_241038 = (g_std_2edoc_2e_3c_3e(v_a_241035, v_t_241037));
    V v_t_241039 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241030, v_e_241034}));
    return (g_std_2edoc_2e_3c_3e(v_t_241038, v_t_241039));
  }
  case TAG_EFSet: {
    V v_x_241040 = heff_field(v_f_241031, 0);
    V v_eq_241041 = heff_field(v_f_241031, 1);
    V v_e_241042 = heff_field(v_f_241031, 2);
    heff_take_n(v_f_241031, 7ULL, 3);
    V v_a_241043 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241030), v_x_241040));
    V v_b_241044 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241030), v_eq_241041));
    V v_t_241045 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), v_b_241044));
    V v_t_241046 = (g_std_2edoc_2e_3c_3e(v_a_241043, v_t_241045));
    V v_t_241047 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241030, v_e_241042}));
    return (g_std_2edoc_2e_3c_3e(v_t_241046, v_t_241047));
  }
  case TAG_EFDefault: {
    V v_d_241048 = heff_field(v_f_241031, 0);
    V v_eq_241049 = heff_field(v_f_241031, 1);
    V v_e_241050 = heff_field(v_f_241031, 2);
    heff_take_n(v_f_241031, 7ULL, 3);
    V v_a_241051 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241030), v_d_241048}));
    V v_b_241052 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241030), v_eq_241049));
    V v_t_241053 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), v_b_241052));
    V v_t_241054 = (g_std_2edoc_2e_3c_3e(v_a_241051, v_t_241053));
    V v_t_241055 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241030, v_e_241050}));
    return (g_std_2edoc_2e_3c_3e(v_t_241054, v_t_241055));
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241030;
    args[1] = v_f_241031;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_x212_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop_rec(v_eq_243, 9);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_x212_244, 0);
        V v_more_247 = heff_field(v_x212_244, 1);
        V v_ru_24x212_244_24Cons = heff_take_reuse_n(v_x212_244, 3ULL, 2);
        V v_t_248 = heff_dup(heff_rfield(v_eq_243, 6));
        V v_t_2410;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_t_248);
          V v_t_249 = (g_list_2eany_24s1092144743x1559898298(v_bars_245));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
          } else {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2eline_get());
          }
        }
        V v_a_2411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_243)));
        V v_b_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2413 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24x212_244_24Cons, heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_2412));
        V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_a_2411, v_t_2413));
        V v_t_2424 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 3, (V[]){v_eq_243, heff_dup(v_bars_245), v_env_240}); V a_2 = v_bars_245; V a_3 = v_more_247; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_245); heff_drop(v_more_247); r_; });
        V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2424));
        V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2425));
        return (g_std_2edoc_2egroup(v_t_2426));
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2415 = args[0];
  V v_a_2416 = args[1];
  V v_eq_243 = heff_env(self)[0];
  V v_bars_245 = heff_env(self)[1];
  V v_env_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_get_n(v_eq_243, 6, 9);
  V v_t_2419;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_bars_245);
    heff_drop(v_t_2417);
    v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = ({ V a_0 = v_bars_245; V r_ = (g_list_2eany_24s1092144743x1559898298(a_0)); heff_drop(v_bars_245); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2415));
  V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2416}));
  V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2421));
  V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
  return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2423));
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_ix_244 = heff_take_field(v_t_243, 7);
    V v_blank_245 = heff_get_n(v_t_243, 8, 9);
    HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = v_ix_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2413;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      V v_t_2412;
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_248;
        switch (heff_tag_of(v_x_249)) {
        case TAG_Nil: {
          v_t_2412 = v_blank_245;
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_x_249, 0);
          heff_take_n(v_x_249, 1ULL, 2);
          heff_drop(v_blank_245);
          v_t_2412 = heff_get_n(v_x_2410, 1, 2);
          break;
        }
        default: heff_nomatch(v_x_249);
        }
      } else {
        heff_drop(v_field_248);
        v_t_2412 = v_blank_245;
      }
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str3, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str7, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2422;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_2412;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkTF: {
        V v_xs_245 = heff_field(v_x_243, 0);
        switch (heff_tag_of(v_xs_245)) {
        case TAG_Nil: {
          v_t_2412 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str0), ((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str1), ((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_xs_245, 0);
          v_t_2412 = heff_dup(v_x_2410);
          break;
        }
        default: heff_nomatch(v_xs_245);
        }
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_ix_2413 = heff_take_field(v_t_2412, 7);
      V v_blank_2414 = heff_get_n(v_t_2412, 8, 9);
      HeffT2 v_t_2415 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 1), v_ix_2413));
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        V v_t_2421;
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_x_2418 = v_field_2417;
          switch (heff_tag_of(v_x_2418)) {
          case TAG_Nil: {
            v_t_2421 = v_blank_2414;
            break;
          }
          case TAG_Cons: {
            V v_x_2419 = heff_field(v_x_2418, 0);
            heff_take_n(v_x_2418, 1ULL, 2);
            heff_drop(v_blank_2414);
            v_t_2421 = heff_get_n(v_x_2419, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2418);
          }
        } else {
          heff_drop(v_field_2417);
          v_t_2421 = v_blank_2414;
        }
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          v_t_2422 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2421);
          v_t_2422 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2422 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2430;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_xs_2423 = heff_field(v_x_243, 0);
      switch (heff_tag_of(v_xs_2423)) {
      case TAG_Nil: {
        v_t_2430 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str3), ((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str4), ((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str5), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
        break;
      }
      case TAG_Cons: {
        V v_x_2428 = heff_field(v_xs_2423, 0);
        v_t_2430 = heff_dup(v_x_2428);
        break;
      }
      default: heff_nomatch(v_xs_2423);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2439;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_ty_2434 = heff_field(v_x_243, 3);
      V v_x15_2435 = heff_field(v_x_243, 4);
      switch (heff_tag_of(v_x15_2435)) {
      case TAG_Nothing: {
        v_t_2439 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_ty_2434)));
        break;
      }
      case TAG_Just: {
        V v_x151_2436 = heff_field(v_x15_2435, 0);
        switch (heff_tag_of(v_x151_2436)) {
        case TAG_MkPair: {
          V v_d_2438 = heff_field(v_x151_2436, 1);
          v_t_2439 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_d_2438)));
          break;
        }
        default: heff_nomatch(v_x151_2436);
        }
        break;
      }
      default: heff_nomatch(v_x15_2435);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2430, v_t_2439, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2461 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2460, v_t_2461));
    V v_t_2463 = (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2462));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2463));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0(V self, V *args) {
  V v_e_2440 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_env_2441 = v_e_2440;
  V v_x2_2442 = v_x_243;
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkTF: {
    V v_xs_2443 = heff_field(v_x2_2442, 0);
    V v_commas_2444 = heff_field(v_x2_2442, 1);
    V v_cc_2445 = heff_field(v_x2_2442, 2);
    V v_ty_2446 = heff_field(v_x2_2442, 3);
    V v_d_2447 = heff_field(v_x2_2442, 4);
    heff_take_n(v_x2_2442, 31ULL, 5);
    V v_t_2448 = (g_list_2emap_24s2139359291x1524787922(v_xs_2443));
    V v_a_2449 = ({ V a_0 = heff_dup(v_env_2441); V a_1 = v_t_2448; V a_2 = v_commas_2444; V r_ = (g_heff_2esyntax_2efmt_2elayout_2enamesDoc(a_0, a_1, a_2)); heff_drop(v_t_2448); heff_drop(v_commas_2444); r_; });
    V v_b_2450 = (g_heff_2esyntax_2efmt_2elayout_2esig(heff_dup(v_env_2441), v_cc_2445, v_ty_2446));
    V v_t_2451 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str6)}), v_b_2450));
    V v_t_2452 = (g_std_2edoc_2e_3c_3e(v_a_2449, v_t_2451));
    V v_t_2459;
    switch (heff_tag_of(v_d_2447)) {
    case TAG_Nothing: {
      heff_drop(v_env_2441);
      v_t_2459 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_x21_2453 = heff_field(v_d_2447, 0);
      V v_ru_24d_2447_24Just = heff_take_reuse_n(v_d_2447, 1ULL, 1);
      switch (heff_tag_of(v_x21_2453)) {
      case TAG_MkPair: {
        V v_eq_2454 = heff_field(v_x21_2453, 0);
        V v_d_2455 = heff_field(v_x21_2453, 1);
        V v_ru_24x21_2453_24MkPair = heff_take_reuse_n(v_x21_2453, 3ULL, 2);
        V v_t_2456 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_2441), v_eq_2454));
        V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_2441, v_d_2455}));
        V v_t_2458 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24x21_2453_24MkPair, v_t_2456, v_t_2457));
        v_t_2459 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24d_2447_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str7)}), v_t_2458));
        break;
      }
      default: heff_nomatch(v_x21_2453);
      }
      break;
    }
    default: heff_nomatch(v_d_2447);
    }
    return (g_std_2edoc_2e_3c_3e(v_t_2452, v_t_2459));
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(V v_env_240, V v_i_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x4_242, 0);
    V v_ds_244 = heff_field(v_x4_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_243));
    V v_t_246 = (g_heff_2esyntax_2ecst_2efirstD(v_d_243));
    V v_t_247 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_243)));
    V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_246, v_t_247, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_lam0, 1, 1, (V[]){heff_dup(v_d_243)})));
    V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_ds_244));
    V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_t_249, v_t_2410));
    return (g_std_2edoc_2e_3c_3e(v_t_245, v_t_2411));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_lam0(V self, V *args) {
  V v_e_248 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_248; V a_1 = v_d_243; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_243); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2enearGo_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2enearGo(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_c_242, 1));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_cs_243);
      heff_drop(v_t_244);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_acc_241});
    } else {
      heff_drop(v_t_244);
      V t_0 = v_cs_243;
      V t_1 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_acc_241});
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2enearGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str15, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str16, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefName_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefName(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str0);
  }
  case TAG_DFixity: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str1);
  }
  case TAG_DSig: {
    V v_d1_244 = heff_field(v_d_240, 0);
    switch (heff_tag_of(v_d1_244)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str2);
    }
    case TAG_Cons: {
      V v_n_248 = heff_field(v_d1_244, 0);
      V v_d12_249 = heff_field(v_d1_244, 1);
      switch (heff_tag_of(v_d12_249)) {
      case TAG_Nil: {
        V v_x2_2410 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_248)));
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Nil: {
          return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str3);
        }
        case TAG_Cons: {
          V v_x_2411 = heff_field(v_x2_2410, 0);
          V v_xs_2412 = heff_field(v_x2_2410, 1);
          heff_take_n(v_x2_2410, 3ULL, 2);
          return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str4); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        }
        default: return heff_nomatch(v_x2_2410);
        }
      }
      case TAG_Cons: {
        return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str5);
      }
      default: return heff_nomatch(v_d12_249);
      }
    }
    default: return heff_nomatch(v_d1_244);
    }
  }
  case TAG_DInstance: {
    V v_n_2416 = heff_field(v_d_240, 1);
    V v_x2_2419 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2416)));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str6);
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str7); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  case TAG_DEqn: {
    V v_n_2422 = heff_field(v_d_240, 0);
    V v_x2_2427 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2422)));
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str8);
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      V v_xs_2429 = heff_field(v_x2_2427, 1);
      heff_take_n(v_x2_2427, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str9); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
    }
    default: return heff_nomatch(v_x2_2427);
    }
  }
  case TAG_DData: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str10);
  }
  case TAG_DType: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str11);
  }
  case TAG_DTheory: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str12);
  }
  case TAG_DMutual: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str13);
  }
  case TAG_DPrimitive: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str14);
  }
  case TAG_DTest: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str15);
  }
  case TAG_DWatch: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str16);
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2edefName(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V v_s_240, V v_i_241) {
top: ;
  V v_s_242 = heff_dup(v_s_240);
  V v_j_243 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(v_s_240, heff_dup(v_i_241)));
  V v_t_249;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_242, v_j_243, 0)) == ((int64_t)45ULL))) {
    V v_t_244 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(v_s_242, heff_dup(v_j_243)));
    V v_x_245 = heff_intSub(v_t_244, heff_dup(v_j_243));
    if (heff_intLe_c(MK_INT(2LL), v_x_245)) {
      V v_t_246 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(v_s_242, v_j_243));
      V v_c_247 = heff_strByteAt(v_s_242, v_t_246);
      v_t_249 = heff_bool(((((int64_t)0ULL) <= heff_peek_word(v_c_247)) ? ({ V v_t_248 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_dup(v_c_247)))); int c_ = ({ V v_t_2420 = heff_strFind(heff_dup(v_t_248), heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)); int c_ = !heff_intLe_c_lent(MK_INT(0LL), v_t_2420, 1); heff_drop(v_t_2420); c_; }); heff_drop(v_t_248); c_; }) : 1));
      heff_drop(v_c_247);
    } else {
      heff_drop(v_s_242);
      heff_drop(v_j_243);
      v_t_249 = NTAG(TAG_False);
    }
  } else {
    heff_drop(v_s_242);
    heff_drop(v_j_243);
    v_t_249 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(v_s_240, v_i_241));
    return ({ V a_0 = v_s_240; V a_1 = v_t_2410; V r_ = (g_heff_2esyntax_2efmt_2elex_2eeolEnd(a_0, a_1)); heff_drop(v_s_240); r_; });
  } else {
    heff_drop(v_t_249);
    V v_j_2411 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(v_s_240, heff_dup(v_i_241)));
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_2411, 0)) == ((int64_t)123ULL)) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_2411), MK_INT(1LL)))) == ((int64_t)45ULL)))) {
      heff_drop(v_j_2411);
      V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(v_s_240, v_i_241));
      HeffT5 v_t_2413 = (g_heff_2esyntax_2efmt_2elex_2eblockScan_24cpr(v_s_240, v_t_2412, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)));
      V v_t_2419;
      {
        V v_field_2414 = v_t_2413.f[0];
        heff_drop(v_t_2413.f[1]);
        heff_drop(v_t_2413.f[2]);
        heff_drop(v_t_2413.f[3]);
        heff_drop(v_t_2413.f[4]);
        v_t_2419 = v_field_2414;
      }
      V t_0 = v_s_240;
      V t_1 = v_t_2419;
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_s_240);
      heff_drop(v_j_2411);
      return v_i_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etrailEnd(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str0, 2, "--");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str1, 4, "-- |");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str3, 4, "-- |");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str4, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eexpectLine_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eexpectLine(V v_doc_240, V v_c_241) {
top: ;
  V v_blank_242 = heff_take_field(v_c_241, 1);
  V v_text_243 = heff_get_n(v_c_241, 0, 2);
  if (!(heff_dup(v_blank_242) == NTAG(TAG_True))) {
    heff_drop(v_blank_242);
    if (heff_strEq_c(heff_strSlice_lent(v_text_243, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str0))) {
      if ((heff_dup(v_doc_240) == NTAG(TAG_True))) {
        if (heff_strEq_c(heff_strSlice_lent(v_text_243, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str1))) {
          V v_s_244 = heff_strSlice(heff_dup(v_text_243), MK_INT(4LL), heff_strLength(v_text_243));
          V v_t_245 = (g_prelude_2eskipSpaces(v_s_244, MK_INT(0LL), MK_INT(1LL)));
          int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_s_244, 0)) - ((int64_t)1ULL));
          V v_t_247 = (g_prelude_2eskipSpaces(v_s_244, heff_box_word(v_t_246), MK_INT(-1LL)));
          V v_t_248 = heff_strSlice(v_s_244, v_t_245, heff_intAdd(v_t_247, MK_INT(1LL)));
          V v_x1_249 = heff_bool(heff_strEq_c_lent(v_t_248, ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str2), 2));
          heff_drop(v_t_248);
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
          heff_drop(v_x1_249);
          return v_ret_24bool;
        } else {
          heff_drop(v_text_243);
          return NTAG(TAG_False);
        }
      } else {
        if (!heff_strEq_c(heff_strSlice_lent(v_text_243, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str3))) {
          V v_s_2410 = heff_strSlice(heff_dup(v_text_243), MK_INT(2LL), heff_strLength(v_text_243));
          V v_t_2411 = (g_prelude_2eskipSpaces(v_s_2410, MK_INT(0LL), MK_INT(1LL)));
          int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_s_2410, 0)) - ((int64_t)1ULL));
          V v_t_2413 = (g_prelude_2eskipSpaces(v_s_2410, heff_box_word(v_t_2412), MK_INT(-1LL)));
          V v_t_2414 = heff_strSlice(v_s_2410, v_t_2411, heff_intAdd(v_t_2413, MK_INT(1LL)));
          V v_x1_2415 = heff_bool(heff_strEq_c_lent(v_t_2414, ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str4), 2));
          heff_drop(v_t_2414);
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2415) == NTAG(TAG_True)));
          heff_drop(v_x1_2415);
          return v_ret_24bool;
        } else {
          heff_drop(v_text_243);
          return NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_text_243);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_blank_242);
    heff_drop(v_text_243);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eexpectLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eexpectLine(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps(V v_doc_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x2_241, 0);
    V v_cs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2eexpectLine(v_doc_240, heff_dup(v_c_243)));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_c_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_doc_240;
      V t_1 = v_cs_244;
      V t_2 = v_cell_246;
      v_doc_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_c_243);
      heff_drop(v_cs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, "doctest");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str1, 7, "doctest");
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_eof_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 1), heff_get_n(v_eof_243, 7, 9)));
    V v_t_249;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_247;
        v_t_249 = v_x_248;
      } else {
        heff_drop(v_field_247);
        v_t_249 = NTAG(TAG_Nil);
      }
    }
    return ({ V a_0 = v_env_240; V a_1 = v_t_249; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_240, 7); heff_drop(v_t_249); r_; });
  }
  case TAG_Cons: {
    V v_d_2410 = heff_field(v_x5_244, 0);
    V v_ds_2411 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_2410));
    V v_t_2454;
    switch (heff_tag_of(v_d_2410)) {
    case TAG_DImport: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DMutual: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2452 = heff_dup(heff_field(v_d_2410, 0));
      v_t_2454 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_w_2452, 0)), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0)));
      heff_drop_rec(v_w_2452, 9);
      break;
    }
    default: heff_nomatch(v_d_2410);
    }
    V v_t_24206;
    if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      heff_drop(v_t_2454);
      V v_t_2455 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2410));
      V v_t_2456 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2410)));
      V v_t_2458 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2455, v_t_2456, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_2410)})));
      V v_t_2459 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_2410); r_; });
      V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2459, v_eof_243, v_ds_2411));
      v_t_24206 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2460));
    } else {
      heff_drop(v_t_2454);
      V v_t_2461 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_t_2461);
        V v_env_2462 = heff_dup(v_env_240);
        V v_lead_2463 = heff_take_field(v_env_2462, 1);
        V v_inline_2464 = heff_take_field(v_env_2462, 2);
        V v_src_2465 = heff_get_n(v_env_2462, 0, 7);
        V v_first_2466 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2410));
        V v_ix_2467 = heff_take_field(v_first_2466, 7);
        V v_start_2468 = heff_get_n(v_first_2466, 3, 9);
        V v_t_2469 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_2410));
        V v_t_2470 = ({ V a_0 = v_t_2469; V a_1 = heff_dup(v_d_2410); V a_2 = v_ds_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefLast(a_0, a_1, a_2)); heff_drop(v_t_2469); r_; });
        V v_last2_2471 = (g_heff_2esyntax_2ecst_2elastD(v_t_2470));
        HeffT2 v_t_2472 = ({ V a_0 = v_lead_2463; V a_1 = heff_dup(v_ix_2467); HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_lead_2463); r_; });
        V v_t_2476;
        {
          V v_field_2474 = v_t_2472.f[1];
          int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
          if ((v_tag_2473 == ((int64_t)0ULL))) {
            V v_x_2475 = v_field_2474;
            v_t_2476 = v_x_2475;
          } else {
            heff_drop(v_field_2474);
            v_t_2476 = NTAG(TAG_Nil);
          }
        }
        V v_t_2477 = ({ V a_0 = v_t_2476; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a_0, a_1)); heff_drop(v_t_2476); r_; });
        HeffT2 v_t_2478 = ({ V a_0 = v_inline_2464; V a_1 = v_ix_2467; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_inline_2464); r_; });
        V v_t_2482;
        {
          V v_field_2480 = v_t_2478.f[1];
          int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
          if ((v_tag_2479 == ((int64_t)0ULL))) {
            V v_x_2481 = v_field_2480;
            v_t_2482 = v_x_2481;
          } else {
            heff_drop(v_field_2480);
            v_t_2482 = NTAG(TAG_Nil);
          }
        }
        V v_t_2483 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2482; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2482); r_; });
        V v_b_2484 = (g_heff_2esyntax_2efmt_2elayout_2etrailEnd(heff_dup(v_src_2465), heff_get_n(v_last2_2471, 4, 9)));
        V v_t_2485 = ({ V b_0 = heff_strSlice(v_src_2465, v_start_2468, v_b_2484); V r_ = (g_heff_2esyntax_2efmt_2elayout_2ecomment(b_0)); heff_drop(b_0); r_; });
        V v_t_2486 = (g_std_2edoc_2e_3c_3e(v_t_2483, v_t_2485));
        V v_t_2487 = (g_std_2edoc_2e_3c_3e(v_t_2477, v_t_2486));
        V v_t_2488 = ({ V a_0 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_2410); r_; });
        V v_t_2489 = ({ V a_0 = v_t_2488; V a_1 = v_ds_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(a_0, a_1)); heff_drop(v_t_2488); r_; });
        V v_t_2490 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_t_2489));
        v_t_24206 = (g_std_2edoc_2e_3c_3e(v_t_2487, v_t_2490));
      } else {
        heff_drop(v_t_2461);
        V v_env_2491 = heff_dup(v_env_240);
        V v_d_2492 = heff_dup(v_d_2410);
        V v_expect_24186;
        switch (heff_tag_of(v_d_2492)) {
        case TAG_DImport: {
          heff_take_n(v_d_2492, 0ULL, 1);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DFixity: {
          heff_take_n(v_d_2492, 0ULL, 2);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DSig: {
          heff_take_n(v_d_2492, 0ULL, 4);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DInstance: {
          heff_take_n(v_d_2492, 0ULL, 4);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DEqn: {
          heff_take_n(v_d_2492, 0ULL, 5);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DData: {
          heff_take_n(v_d_2492, 0ULL, 5);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DType: {
          heff_take_n(v_d_2492, 0ULL, 5);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DTheory: {
          heff_take_n(v_d_2492, 0ULL, 5);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DMutual: {
          V v_ds_24125 = heff_field(v_d_2492, 1);
          V v_ru_24d_2492_24DMutual = heff_take_reuse_n(v_d_2492, 2ULL, 2);
          V v_x1_24126 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_24125));
          switch (heff_tag_of(v_x1_24126)) {
          case TAG_Nil: {
            heff_drop_rec(v_env_2491, 7);
            heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
            v_expect_24186 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_x_24127 = heff_field(v_x1_24126, 0);
            heff_take_n(v_x1_24126, 1ULL, 2);
            switch (heff_tag_of(v_x_24127)) {
            case TAG_DImport: {
              heff_take_n(v_x_24127, 0ULL, 1);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DFixity: {
              heff_take_n(v_x_24127, 0ULL, 2);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DSig: {
              heff_take_n(v_x_24127, 0ULL, 4);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DInstance: {
              heff_take_n(v_x_24127, 0ULL, 4);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DEqn: {
              heff_take_n(v_x_24127, 0ULL, 5);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DData: {
              heff_take_n(v_x_24127, 0ULL, 5);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DType: {
              heff_take_n(v_x_24127, 0ULL, 5);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DTheory: {
              heff_take_n(v_x_24127, 0ULL, 5);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DMutual: {
              heff_take_n(v_x_24127, 0ULL, 2);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DPrimitive: {
              heff_take_n(v_x_24127, 0ULL, 4);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DTest: {
              heff_take_n(v_x_24127, 0ULL, 2);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DWatch: {
              V v_w_24168 = heff_field(v_x_24127, 0);
              V v_e_24169 = heff_field(v_x_24127, 1);
              heff_take_n(v_x_24127, 3ULL, 2);
              V v_t_24170 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_w_24168, 0)), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str1)));
              heff_drop_rec(v_w_24168, 9);
              V v_t_24171 = (g_heff_2esyntax_2ecst_2elastE(v_e_24169));
              V v_t_24172 = heff_intAdd(heff_get_n(v_t_24171, 7, 9), MK_INT(1LL));
              HeffT2 v_t_24173 = ({ V b_0 = heff_get_n(v_env_2491, 1, 7); V a_1 = v_t_24172; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              V v_t_24177;
              {
                V v_field_24175 = v_t_24173.f[1];
                int64_t v_tag_24174 = ((int64_t)v_t_24173.f[0]);
                if ((v_tag_24174 == ((int64_t)0ULL))) {
                  V v_x_24176 = v_field_24175;
                  v_t_24177 = v_x_24176;
                } else {
                  heff_drop(v_field_24175);
                  v_t_24177 = NTAG(TAG_Nil);
                }
              }
              v_expect_24186 = ({ V a_0 = v_ru_24d_2492_24DMutual; V a_1 = v_t_24170; V a_2 = v_t_24177; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2(a_0, a_1, a_2)); heff_drop(v_t_24170); r_; });
              break;
            }
            default: heff_nomatch(v_x_24127);
            }
            break;
          }
          default: heff_nomatch(v_x1_24126);
          }
          break;
        }
        case TAG_DPrimitive: {
          heff_take_n(v_d_2492, 0ULL, 4);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DTest: {
          heff_take_n(v_d_2492, 0ULL, 2);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DWatch: {
          heff_take_n(v_d_2492, 0ULL, 2);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d_2492);
        }
        V v_t_24187 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2410));
        V v_t_24188 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2410)));
        V v_t_24190 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_24187, v_t_24188, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){heff_dup(v_d_2410)})));
        V v_d_24191 = (g_list_2efoldl_24f1134152647x940271785(heff_dup(g_std_2edoc_2eemptyDoc_get()), v_expect_24186));
        V v_env_24192 = v_env_240;
        V v_t_24193 = (g_heff_2esyntax_2ecst_2elastD(v_d_2410));
        V v_ix_24194 = heff_intAdd(heff_get_n(v_t_24193, 7, 9), MK_INT(1LL));
        V v_n_24195 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_expect_24186; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_expect_24186); r_; });
        V v_t_24203;
        if (heff_intEq_c_lent(v_n_24195, MK_INT(0LL), 2)) {
          heff_drop(v_ix_24194);
          heff_drop(v_n_24195);
          v_t_24203 = v_env_24192;
        } else {
          HeffT2 v_t_24196 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_24192, 1), heff_dup(v_ix_24194)));
          V v_t_24200;
          {
            V v_field_24198 = v_t_24196.f[1];
            int64_t v_tag_24197 = ((int64_t)v_t_24196.f[0]);
            if ((v_tag_24197 == ((int64_t)0ULL))) {
              V v_x_24199 = v_field_24198;
              v_t_24200 = v_x_24199;
            } else {
              heff_drop(v_field_24198);
              v_t_24200 = NTAG(TAG_Nil);
            }
          }
          V v_t_24201 = ({ V a_0 = v_n_24195; V a_1 = v_t_24200; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_24200); r_; });
          V v_t_24202 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_env_24192, 1), v_ix_24194, v_t_24201));
          v_t_24203 = ({ V rv_1 = v_t_24202; V rr_ = heff_rec_reuse_nf(v_env_24192, 125ULL, 7, shape_src__lead__inline__trail__noLead__noTrail__fix, 16371u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        V v_t_24204 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_t_24203, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_ds_2411));
        V v_t_24205 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24191}), v_t_24204));
        v_t_24206 = (g_std_2edoc_2e_3c_3e(v_t_24190, v_t_24205));
      }
    }
    return (g_std_2edoc_2e_3c_3e(v_t_2412, v_t_24206));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2457 = args[0];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2457; V a_1 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2410); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_24189 = args[0];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_24189; V a_1 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2410); r_; });
}