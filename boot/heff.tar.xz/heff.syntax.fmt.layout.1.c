// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Looser 37443
#define TAG_MkTF 48839
#define TAG_Nest 8345
#define TAG_Same 22203
#define TAG_Tighter 5275
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define LBL_blank 295177582
#define LBL_cmt 308164
#define LBL_col 308218
#define LBL_end 310101
#define LBL_err 310239
#define LBL_first 298798794
#define LBL_i 323
#define LBL_imports 10411951
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_raw 322210
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_trail 311979552
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_imports__text[] = {LBL_imports, LBL_text};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2eimports_2ereadGo(V, V, V);
V g_heff_2esyntax_2efmt_2eimports_2ereadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2ereadGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofOf(V);
V g_heff_2esyntax_2efmt_2elayout_2eeofOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2efmtLexed(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2efmtLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2efmtLexed_clo;
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo;
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(V, V);
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enearGo(V, V);
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etfDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etfDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_clo;
V g_heff_2esyntax_2efmt_2elex_2eblockScan(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2eblockScan_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eblockScan_clo;
V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void);
V g_list_2efoldl_24s1759289969x319536741(V, V);
V g_list_2efoldl_24s1759289969x319536741_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1759289969x319536741_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2ehardline_get(void);
Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V v_f_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return heff_tag_n(TAG_Just, 1, (V[]){v_m_241});
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_os_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(v_f_240), heff_dup(v_m_241), heff_dup(v_o_243)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Tighter: {
      heff_drop(v_m_241);
      V t_0 = v_f_240;
      V t_1 = heff_dup(v_o_243);
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Looser: {
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Same: {
      heff_take_n(v_t_245, 0ULL, 1);
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Unrelated: {
      heff_drop(v_f_240);
      heff_drop(v_m_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_m_241);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(V v_env_240, V v_rhsLast_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_rhsLast_241, 9);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_kw_244 = heff_field(v_x41_243, 0);
      V v_ds_245 = heff_field(v_x41_243, 1);
      V v_t_246 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_rhsLast_241, 7)), heff_rfield(v_env_240, 3)));
      V v_t_248;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        heff_drop_rec(v_rhsLast_241, 9);
        v_t_248 = heff_dup(g_std_2edoc_2ehardline_get());
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_246, 0ULL, 1);
        v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(heff_dup(v_env_240), v_rhsLast_241));
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_244)));
      V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(v_env_240, MK_INT(0LL), v_ds_245));
      V v_d_2411 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2410));
      V v_t_2412 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2411})));
      return (g_std_2edoc_2e_3c_3e(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2417;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_2410;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkTF: {
        V v_x_246 = heff_field(v_x_243, 0);
        v_t_2410 = heff_dup(v_x_246);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_x2_2411 = (g_map_2elookup_24s567992785x1569911877(heff_take_field(v_t_2410, 7), heff_rfield(v_env_240, 1)));
      V v_x1_2413;
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_Nothing: {
        v_x1_2413 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        heff_take_n(v_x2_2411, 1ULL, 1);
        v_x1_2413 = v_x_2412;
        break;
      }
      default: heff_nomatch(v_x2_2411);
      }
      V v_t_2416;
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Nil: {
        v_t_2416 = heff_get_n(v_t_2410, 8, 9);
        break;
      }
      case TAG_Cons: {
        V v_x_2414 = heff_field(v_x1_2413, 0);
        heff_take_n(v_x1_2413, 1ULL, 2);
        heff_drop_rec(v_t_2410, 9);
        v_t_2416 = heff_get_n(v_x_2414, 1, 2);
        break;
      }
      default: heff_nomatch(v_x1_2413);
      }
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        v_t_2417 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2416);
        v_t_2417 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      v_t_2417 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2422;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_x_2418 = heff_field(v_x_243, 0);
      v_t_2422 = heff_dup(v_x_2418);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2430;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_ty_2425 = heff_field(v_x_243, 2);
      V v_x14_2426 = heff_field(v_x_243, 3);
      switch (heff_tag_of(v_x14_2426)) {
      case TAG_Nothing: {
        v_t_2430 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_ty_2425)));
        break;
      }
      case TAG_Just: {
        V v_x141_2427 = heff_field(v_x14_2426, 0);
        switch (heff_tag_of(v_x141_2427)) {
        case TAG_MkPair: {
          V v_d_2429 = heff_field(v_x141_2427, 1);
          v_t_2430 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_d_2429)));
          break;
        }
        default: heff_nomatch(v_x141_2427);
        }
        break;
      }
      default: heff_nomatch(v_x14_2426);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2432 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2422, v_t_2430, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2434 = (g_std_2edoc_2e_3c_3e(v_t_2432, v_t_2433));
    V v_t_2435 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2434));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2435));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0(V self, V *args) {
  V v_e_2431 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2431; V a_1 = v_x_243; V r_ = (g_heff_2esyntax_2efmt_2elayout_2etfDoc(a_0, a_1)); heff_drop(v_x_243); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2enearGo_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2enearGo(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_c_242, 1));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_cs_243);
      heff_drop(v_t_244);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_acc_241});
    } else {
      heff_drop(v_t_244);
      V t_0 = v_cs_243;
      V t_1 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_acc_241});
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2enearGo(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(V v_s_240, V v_j_241) {
top: ;
  if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(45LL))) {
    V v_t_243 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(heff_dup(v_s_240), heff_dup(v_j_241)));
    V v_x_244 = heff_intSub(v_t_243, heff_dup(v_j_241));
    if (heff_intLe_c(MK_INT(2LL), v_x_244)) {
      V v_t_246 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(heff_dup(v_s_240), v_j_241));
      V v_c_247 = heff_strByteAt(v_s_240, v_t_246);
      V v_x1_2412;
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_c_247))) {
        V v_t_249 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_c_247)));
        V v_x3_2410 = (g_prelude_2eindexFrom(v_t_249, heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)));
        switch (heff_tag_of(v_x3_2410)) {
        case TAG_Nothing: {
          v_x1_2412 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_x3_2410, 0ULL, 1);
          v_x1_2412 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x3_2410);
        }
      } else {
        heff_drop(v_c_247);
        v_x1_2412 = NTAG(TAG_False);
      }
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2412) == NTAG(TAG_True)));
      heff_drop(v_x1_2412);
      return v_ret_24bool;
    } else {
      heff_drop(v_s_240);
      heff_drop(v_j_241);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_j_241);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(heff_dup(v_s_240), heff_dup(v_i_241)));
  V v_t_243 = (g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(heff_dup(v_s_240), v_t_242));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(heff_dup(v_s_240), v_i_241));
    HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2eeolEnd(v_s_240, v_t_244);
  } else {
    heff_drop(v_t_243);
    V v_j_245 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(heff_dup(v_s_240), heff_dup(v_i_241)));
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_245)), MK_INT(123LL))) {
      V v_t_247 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(v_j_245, MK_INT(1LL)));
      if (heff_intEq_c(v_t_247, MK_INT(45LL))) {
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(heff_dup(v_s_240), v_i_241));
        V v_r_2410 = (g_heff_2esyntax_2efmt_2elex_2eblockScan(heff_dup(v_s_240), v_t_249, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)));
        V t_0 = v_s_240;
        V t_1 = heff_get_n(v_r_2410, 0, 5);
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        heff_drop(v_s_240);
        return v_i_241;
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_j_245);
      return v_i_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etrailEnd(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eeofOf_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eeofOf_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eeofOf_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eeofOf_str3, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eeofOf_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eeofOf_str5, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2eeofOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eeofOf_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eeofOf(V v_ts_240) {
top: ;
  V v_i_241 = heff_intSub(heff_arrayLength(heff_dup(v_ts_240)), MK_INT(1LL));
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_241))) {
    if (heff_intLt_c(heff_dup(v_i_241), heff_arrayLength(heff_dup(v_ts_240)))) {
      V v_t_244 = heff_arrayIndex(v_ts_240, v_i_241);
      return v_t_244;
    } else {
      heff_drop(v_ts_240);
      heff_drop(v_i_241);
      return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eeofOf_str0), ((V)&g_heff_2esyntax_2efmt_2elayout_2eeofOf_str1), ((V)&g_heff_2esyntax_2efmt_2elayout_2eeofOf_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
  } else {
    heff_drop(v_ts_240);
    heff_drop(v_i_241);
    return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eeofOf_str3), ((V)&g_heff_2esyntax_2efmt_2elayout_2eeofOf_str4), ((V)&g_heff_2esyntax_2efmt_2elayout_2eeofOf_str5), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eeofOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eeofOf(a[0]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(V v_f_240, V v_src_241) {
top: ;
  V v_imps_242 = (g_heff_2esyntax_2efmt_2eimports_2ereadGo(heff_dup(v_src_241), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_243 = (g_list_2efoldl_24s1759289969x319536741(heff_dup(v_src_241), v_imps_242));
  V v_hdr_244 = heff_rec_n(2, shape_imports__text, (V[]){v_imps_242, v_t_243});
  V v_t_245 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_246 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(heff_rfield(v_hdr_244, 1)), v_t_245, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  return (g_heff_2esyntax_2efmt_2elayout_2efmtLexed(v_f_240, v_src_241, v_hdr_244, v_t_246));
}
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(a[0], a[1]);
}