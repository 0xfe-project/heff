// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_FloatAcos 708
#define TAG_FloatAdd 6390
#define TAG_FloatAsin 15893
#define TAG_FloatAtan 16606
#define TAG_FloatAtan2 55855
#define TAG_FloatCos 8668
#define TAG_FloatDiv 9446
#define TAG_FloatEq 13032
#define TAG_FloatExp 10866
#define TAG_FloatFloor 58439
#define TAG_FloatFromInt 61384
#define TAG_FloatLe 13237
#define TAG_FloatLog 17305
#define TAG_FloatLt 13252
#define TAG_FloatMul 18457
#define TAG_FloatPow 21165
#define TAG_FloatSin 23853
#define TAG_FloatSqrt 26286
#define TAG_FloatSub 24213
#define TAG_FloatTan 24566
#define TAG_HS 9084
#define TAG_MkWrapper 39179
#define TAG_OfFixed 17267
#define TAG_UFixed 18334
#define TAG_UFn 31401
#define TAG_UOp 31682
#define TAG_URel 1603
#define TAG_UToDouble 51807
#define TAG_WordAdd 60179
#define TAG_WordDiv 63235
#define TAG_WordEq 48587
#define TAG_WordLe 48792
#define TAG_WordLt 48807
#define TAG_WordMod 6526
#define TAG_WordMul 6720
#define TAG_WordQuot 65290
#define TAG_WordRem 11030
#define TAG_WordSub 12476
#define TAG_WordToFloat 50865
#define LBL_body 9524841
#define LBL_byFun 295539138
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_inLam 301681229
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_sureRecs 1275638267
#define LBL_tokens 1078955205
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
V g_heff_2ecompile_2eemitc_2eaddLam(V, V, V);
V g_heff_2ecompile_2eemitc_2eaddLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eaddLam_clo;
V g_heff_2ecompile_2eemitc_2eagainTo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eagainTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eagainTo_clo;
V g_heff_2ecompile_2eemitc_2ecallBound(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallBound_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
HeffT6 g_heff_2ecompile_2eemitc_2eckOf_24cpr(V, V, V);
V g_heff_2ecompile_2eemitc_2edeclOf(V, V);
V g_heff_2ecompile_2eemitc_2edeclOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edeclOf_clo;
V g_heff_2ecompile_2eemitc_2eelemI(V, V);
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemI_clo;
V g_heff_2ecompile_2eemitc_2elamC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamC_clo;
V g_heff_2ecompile_2eemitc_2eletGoIndexGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eletGoIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eletGoIndexGo_clo;
V g_heff_2ecompile_2eemitc_2emangleChar(V);
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleChar_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_clo;
V g_heff_2ecompile_2eemitc_2enumbersOf(V, V);
V g_heff_2ecompile_2eemitc_2enumbersOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbersOf_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2eshapeH(V, V, V);
V g_heff_2ecompile_2eemitc_2eshapeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeH_clo;
V g_heff_2ecompile_2eemitc_2eslotFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo;
V g_heff_2ecompile_2eemitc_2eunboxed(V);
V g_heff_2ecompile_2eemitc_2eunboxed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eunboxed_clo;
V g_heff_2ecompile_2eemitc_2eusedBy(V, V);
V g_heff_2ecompile_2eemitc_2eusedBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eusedBy_clo;
HeffT2 g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_intShow_get(void);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1257949983x1023832813(V, V);
V g_list_2efoldl_24f1257949983x1023832813_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1257949983x1023832813_clo;
V g_list_2efoldl_24f675617784x1820039874(V, V);
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a);
extern Clo g_list_2efoldl_24f675617784x1820039874_clo;
V g_list_2efoldl_24f891411706x655200538(V, V);
V g_list_2efoldl_24f891411706x655200538_entry(V self, V *a);
extern Clo g_list_2efoldl_24f891411706x655200538_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1483820613x1826490246(V, V);
V g_list_2efoldl_24s1483820613x1826490246_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1483820613x1826490246_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1668908788x1049324851(V, V);
V g_list_2efoldl_24s1668908788x1049324851_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1668908788x1049324851_clo;
V g_list_2efoldl_24s2138447488x1597606028(V, V);
V g_list_2efoldl_24s2138447488x1597606028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2138447488x1597606028_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s640776339x1223679834(V);
V g_list_2emap_24s640776339x1223679834_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1737719962x691725464(V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s1737719962x691725464_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1737719962x691725464_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s490727218x2138671(V, V, V, V, V);
V g_list_2ezipWith_24s490727218x2138671_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s490727218x2138671_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2e_2b_2b_24f132290754x1091834184(V, V, V, V);
V g_prelude_2e_2b_2b_24f132290754x1091834184_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f132290754x1091834184_clo;
V g_prelude_2e_2b_2b_24f543054808x1503188303(V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f543054808x1503188303_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f543054808x1503188303_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2ecompile_2eemitc_2emangleW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emangleW_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2emangleW(V v_s_240, V v_i_241, V v_box_24j_242, V v_acc_243) {
  int64_t v_j_242 = heff_unbox_word(v_box_24j_242);
top: ;
  if ((v_j_242 < heff_unbox_word(heff_strLength_lent(v_s_240, 0)))) {
    V v_c_244 = heff_strByteAt_lent(v_s_240, heff_box_word(v_j_242), 2);
    if ((((((int64_t)97ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)57ULL)))))) {
      heff_drop(v_c_244);
      V t_0 = v_s_240;
      V t_1 = v_i_241;
      int64_t t_2 = (v_j_242 + ((int64_t)1ULL));
      V t_3 = v_acc_243;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      heff_drop(v_c_244);
      if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_j_242)) {
        return heff_strAppend(v_acc_243, heff_strSlice_lent(v_s_240, v_i_241, heff_box_word(v_j_242), 6));
      } else {
        V v_t_245 = (g_heff_2ecompile_2eemitc_2emangleChar(heff_strByteAt_lent(v_s_240, heff_box_word(v_j_242), 2)));
        V v_t_246 = heff_strAppend(v_acc_243, heff_strSlice_lent(v_s_240, v_i_241, heff_box_word(v_j_242), 6));
        V t_0 = v_s_240;
        V t_1 = heff_box_word((v_j_242 + ((int64_t)1ULL)));
        int64_t t_2 = (v_j_242 + ((int64_t)1ULL));
        V t_3 = heff_strAppend(v_t_246, v_t_245);
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
    }
  } else {
    if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_j_242)) {
      return heff_strAppend(v_acc_243, heff_strSlice_lent(v_s_240, v_i_241, heff_box_word(v_j_242), 6));
    } else {
      V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleChar(heff_strByteAt_lent(v_s_240, heff_box_word(v_j_242), 2)));
      V v_t_248 = heff_strAppend(v_acc_243, heff_strSlice_lent(v_s_240, v_i_241, heff_box_word(v_j_242), 6));
      V t_0 = v_s_240;
      V t_1 = heff_box_word((v_j_242 + ((int64_t)1ULL)));
      int64_t t_2 = (v_j_242 + ((int64_t)1ULL));
      V t_3 = heff_strAppend(v_t_248, v_t_247);
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2emangleW(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eslotFrom_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eslotFrom(V v_base_240, V v_m_241, V v_h_242, V v_taken_243) {
top: ;
  HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(v_taken_243, heff_intAdd_lent(v_base_240, v_h_242, 0)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      heff_drop(v_x_247);
      V v_t_248 = heff_intMod(heff_intAdd(v_h_242, MK_INT(1LL)), heff_dup(v_m_241));
      V t_0 = v_base_240;
      V t_1 = v_m_241;
      V t_2 = v_t_248;
      V t_3 = v_taken_243;
      v_base_240 = t_0;
      v_m_241 = t_1;
      v_h_242 = t_2;
      v_taken_243 = t_3;
      goto top;
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_246);
      return heff_intAdd(v_base_240, v_h_242);
    }
  }
}
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2eslotFrom(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str0, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str1, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str2, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str3, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str4, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str5, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str6, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str7, 17, "heff_from_int_f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str8, 4, "sqrt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str9, 14, "heff_floor_f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str10, 8, "heff_sin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str11, 8, "heff_cos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str12, 8, "heff_tan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str13, 4, "asin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str14, 4, "acos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str15, 4, "atan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str16, 5, "atan2");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str17, 8, "heff_exp");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str18, 8, "heff_log");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str19, 3, "pow");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str20, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str21, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str22, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str23, 13, "heff_word_div");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str24, 13, "heff_word_mod");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str25, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str26, 1, "%");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str27, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str28, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str29, 2, "<=");
Clo g_heff_2ecompile_2eemitc_2eunboxed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eunboxed_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eunboxed(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_FloatAdd: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str0)});
  }
  case TAG_FloatSub: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str1)});
  }
  case TAG_FloatMul: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str2)});
  }
  case TAG_FloatDiv: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str3)});
  }
  case TAG_FloatEq: {
    return heff_tag_n(TAG_URel, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str4)});
  }
  case TAG_FloatLt: {
    return heff_tag_n(TAG_URel, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str5)});
  }
  case TAG_FloatLe: {
    return heff_tag_n(TAG_URel, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str6)});
  }
  case TAG_FloatFromInt: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str7)});
  }
  case TAG_FloatSqrt: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str8)});
  }
  case TAG_FloatFloor: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str9)});
  }
  case TAG_FloatSin: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str10)});
  }
  case TAG_FloatCos: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str11)});
  }
  case TAG_FloatTan: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str12)});
  }
  case TAG_FloatAsin: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str13)});
  }
  case TAG_FloatAcos: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str14)});
  }
  case TAG_FloatAtan: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str15)});
  }
  case TAG_FloatAtan2: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str16)});
  }
  case TAG_FloatExp: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str17)});
  }
  case TAG_FloatLog: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str18)});
  }
  case TAG_FloatPow: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str19)});
  }
  case TAG_OfFixed: {
    V v_w_241 = heff_field(v_p_240, 0);
    V v_op_242 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24OfFixed = heff_take_reuse_n(v_p_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_240_24OfFixed, TAG_UFixed, 2, (V[]){v_w_241, v_op_242});
  }
  case TAG_WordAdd: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str20)});
  }
  case TAG_WordSub: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str21)});
  }
  case TAG_WordMul: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str22)});
  }
  case TAG_WordDiv: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str23)});
  }
  case TAG_WordMod: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str24)});
  }
  case TAG_WordQuot: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str25)});
  }
  case TAG_WordRem: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str26)});
  }
  case TAG_WordEq: {
    return heff_tag_n(TAG_URel, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str27)});
  }
  case TAG_WordLt: {
    return heff_tag_n(TAG_URel, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str28)});
  }
  case TAG_WordLe: {
    return heff_tag_n(TAG_URel, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str29)});
  }
  case TAG_WordToFloat: {
    return NTAG(TAG_UToDouble);
  }
  default: {
    V v_t_243 = ({ V a_0 = v_p_240; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_240); r_; });
    return heff_tag_n(TAG_UFn, 1, (V[]){v_t_243});
  }
  }
}
V g_heff_2ecompile_2eemitc_2eunboxed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eunboxed(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str1, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str2, 8, "heff_tr(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str5, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str7, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str8, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str10, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str13, 3, "({ ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str14, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str15, 6, " r_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str17, 4, ")); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str18, 7, " r_; })");
Clo g_heff_2ecompile_2eemitc_2ecallBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallBound_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ecallBound(V v_ty_240, V v_g_241, V v_tr_242, V v_w_243, V v_bs_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_bs_244)));
  V v_x2_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1483820613x1826490246(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str1); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410;
  if ((heff_dup(v_tr_242) == NTAG(TAG_True))) {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str2);
  } else {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str3);
  }
  V v_t_2414;
  switch (heff_tag_of(v_w_243)) {
  case TAG_Nothing: {
    V v_t_2411 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str4)));
    v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str5), v_t_2411);
    break;
  }
  case TAG_Just: {
    V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str6)));
    v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str7), v_t_2413), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str8));
    break;
  }
  default: heff_nomatch(v_w_243);
  }
  V v_x2_2415 = (g_list_2emap_24s640776339x1223679834(heff_dup(v_bs_244)));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str9);
    break;
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str10); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_244));
  V v_x2_2420 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s2138447488x1597606028(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_t_2423;
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nil: {
    v_t_2423 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str11);
    break;
  }
  case TAG_Cons: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_xs_2422 = heff_field(v_x2_2420, 1);
    heff_take_n(v_x2_2420, 3ULL, 2);
    v_t_2423 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str12); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2420);
  }
  V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str13), v_t_249), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str14));
  V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, v_ty_240), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str15));
  V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2410, v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str16));
  V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2425, v_t_2426), v_t_2418);
  V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str17)), v_t_2423);
  return heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str18));
}
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ecallBound(a[0], a1, a2, a3, a[4]); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str0, 4, "_lam");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str1, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str2, 30, "(V self, V *args); static Clo ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str3, 33, "_clo = {{0x80000000u, K_CLO, 0}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str5, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str6, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str7, 18, "(V self, V *args);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str8, 4, "  V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str9, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str11, 8, " = args[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str12, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str13, 4, "  V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str14, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str16, 18, " = heff_env(self)[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str17, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str18, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str19, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str20, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str21, 19, "(V self, V *args) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str23, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str24, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str25, 5, "_clo)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str26, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str27, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str28, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str29, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str30, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str31, 11, "heff_clo_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str32, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str33, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str34, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str35, 1, ")");
V g_heff_2ecompile_2eemitc_2elamC_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2elamC_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2elamC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elamC_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2elamC(V v_k_240, V v_xs_241, V v_fv_242, V v_held_243, V v_body_244, V v_s_245) {
top: ;
  V v_inLam_246 = heff_take_field(v_k_240, 5);
  V v_exp_247 = heff_get_n(v_k_240, 0, 6);
  V v_s_248 = v_s_245;
  V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_s_248, 0)), ((V)&g_heff_2ecompile_2eemitc_2elamC_str0));
  V v_t_2410 = heff_intShow(heff_dup(heff_rfield(v_s_248, 1)));
  V v_t_2411 = heff_intAdd(heff_take_field(v_s_248, 1), MK_INT(1LL));
  V v_t_2412 = ({ V rv_1 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_s_248, 253ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_x2_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_t_249, v_t_2410), v_t_2412});
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = heff_tr(heff_call(v_inLam_246, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_t_2416, 1, 6), 1, (V[]){v_body_244}));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2415}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_s_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      V v_n_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_2428;
      switch (heff_tag_of(v_fv_242)) {
      case TAG_Nil: {
        V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str1), heff_dup(v_x_2414)), ((V)&g_heff_2ecompile_2eemitc_2elamC_str2));
        V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, heff_dup(v_x_2414)), ((V)&g_heff_2ecompile_2eemitc_2elamC_str3));
        V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2423, heff_dup(v_x_2414)), ((V)&g_heff_2ecompile_2eemitc_2elamC_str4));
        V v_t_2425 = heff_strAppend(v_t_2424, heff_intShow(v_n_2421));
        v_t_2428 = heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemitc_2elamC_str5));
        break;
      }
      case TAG_Cons: {
        heff_drop(v_n_2421);
        v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str6), heff_dup(v_x_2414)), ((V)&g_heff_2ecompile_2eemitc_2elamC_str7));
        break;
      }
      default: heff_nomatch(v_fv_242);
      }
      V v_k_2429 = heff_dup(v_x_2414);
      V v_xs_2430 = heff_dup(v_xs_241);
      V v_fv_2431 = heff_dup(v_fv_242);
      V v_body_2432 = v_x_2419;
      V v_t_2433 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2430));
      V v_t_2434 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2433, MK_INT(1LL))));
      V v_t_2435 = (g_list_2ezipWith_24s1737719962x691725464(((V)&g_heff_2ecompile_2eemitc_2elamC_str8), ((V)&g_heff_2ecompile_2eemitc_2elamC_str9), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elamC_str10), ((V)&g_heff_2ecompile_2eemitc_2elamC_str11), ((V)&g_heff_2ecompile_2eemitc_2elamC_str12), v_xs_2430, v_t_2434));
      V v_t_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fv_2431));
      V v_t_2437 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2436, MK_INT(1LL))));
      V v_t_2438 = (g_list_2ezipWith_24s1737719962x691725464(((V)&g_heff_2ecompile_2eemitc_2elamC_str13), ((V)&g_heff_2ecompile_2eemitc_2elamC_str14), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elamC_str15), ((V)&g_heff_2ecompile_2eemitc_2elamC_str16), ((V)&g_heff_2ecompile_2eemitc_2elamC_str17), v_fv_2431, v_t_2437));
      V v_t_2439 = heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elamC_str18), NTAG(TAG_Nil)});
      V v_t_2440 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2439, ((V)&g_heff_2ecompile_2eemitc_2elamC_str19), v_body_2432));
      V v_t_2441 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2440));
      V v_ys_2442 = (g_prelude_2e_2b_2b(v_t_2435, v_t_2441));
      V v_t_2443 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str20), v_k_2429), ((V)&g_heff_2ecompile_2eemitc_2elamC_str21));
      V v_x2_2444 = heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_Cons, 2, (V[]){v_t_2443, v_ys_2442});
      V v_t_2447;
      switch (heff_tag_of(v_x2_2444)) {
      case TAG_Nil: {
        v_t_2447 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str22);
        break;
      }
      case TAG_Cons: {
        V v_x_2445 = heff_field(v_x2_2444, 0);
        V v_xs_2446 = heff_field(v_x2_2444, 1);
        heff_take_n(v_x2_2444, 3ULL, 2);
        v_t_2447 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str23); V a_1 = v_x_2445; V a_2 = v_xs_2446; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2446); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2444);
      }
      V v_m_2448 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2eaddLam_clo), 2, (V[]){v_t_2428, v_t_2447}));
      V v_f_2470 = heff_clo_n(g_heff_2ecompile_2eemitc_2elamC_lam0, 1, 5, (V[]){v_exp_247, v_held_243, v_fv_242, v_x_2414, v_xs_241});
      V v_s_2471 = v_s_2420;
      V v_x2_2472 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_s_2471}));
      switch (heff_tag_of(v_x2_2472)) {
      case TAG_MkPair: {
        V v_x_2473 = heff_field(v_x2_2472, 0);
        V v_s_2474 = heff_field(v_x2_2472, 1);
        heff_take_n(v_x2_2472, 3ULL, 2);
        return heff_tail(v_f_2470, 2, (V[]){v_x_2473, v_s_2474});
      }
      default: return heff_nomatch(v_x2_2472);
      }
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2elamC(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eemitc_2elamC_lam1(V self, V *args) {
  V v_s_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  V v_fv_242 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_xs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_s_2451}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_s_2454 = heff_field(v_x2_2452, 1);
    V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
    V v_x_2469;
    switch (heff_tag_of(v_fv_242)) {
    case TAG_Nil: {
      heff_drop(v_xs_241);
      heff_drop(v_x_2453);
      v_x_2469 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str24), v_x_2414), ((V)&g_heff_2ecompile_2eemitc_2elamC_str25));
      break;
    }
    case TAG_Cons: {
      V v_t_2457 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
      V v_t_2458 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fv_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_fv_242, 2); r_; });
      V v_t_2464;
      switch (heff_tag_of(v_x_2453)) {
      case TAG_Nil: {
        v_t_2464 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str26);
        break;
      }
      case TAG_Cons: {
        V v_t_2463;
        switch (heff_tag_of(v_x_2453)) {
        case TAG_Nil: {
          v_t_2463 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str27);
          break;
        }
        case TAG_Cons: {
          V v_x_2461 = heff_field(v_x_2453, 0);
          V v_xs_2462 = heff_field(v_x_2453, 1);
          heff_take_n(v_x_2453, 3ULL, 2);
          v_t_2463 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str28); V a_1 = v_x_2461; V a_2 = v_xs_2462; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2462); r_; });
          break;
        }
        default: heff_nomatch(v_x_2453);
        }
        v_t_2464 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str29), v_t_2463), ((V)&g_heff_2ecompile_2eemitc_2elamC_str30));
        break;
      }
      default: heff_nomatch(v_x_2453);
      }
      V v_t_2465 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str31), v_x_2414), ((V)&g_heff_2ecompile_2eemitc_2elamC_str32));
      V v_t_2466 = heff_strAppend(v_t_2465, heff_intShow(v_t_2457));
      V v_t_2467 = heff_strAppend(heff_strAppend(v_t_2466, ((V)&g_heff_2ecompile_2eemitc_2elamC_str33)), heff_intShow(v_t_2458));
      V v_t_2468 = heff_strAppend(heff_strAppend(v_t_2467, ((V)&g_heff_2ecompile_2eemitc_2elamC_str34)), v_t_2464);
      v_x_2469 = heff_strAppend(v_t_2468, ((V)&g_heff_2ecompile_2eemitc_2elamC_str35));
      break;
    }
    default: heff_nomatch(v_fv_242);
    }
    return heff_tag_re_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2469, v_s_2454});
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_heff_2ecompile_2eemitc_2elamC_lam0(V self, V *args) {
  V v_u_2449 = args[0];
  V v_exp_247 = heff_env(self)[0];
  V v_held_243 = heff_env(self)[1];
  V v_fv_242 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_xs_241 = heff_env(self)[4];
  heff_drop(v_u_2449);
  heff_clo_take(self, 5);
  V v_m_2450 = (g_prelude_2etraverse_24s1362847681x1386678580(v_exp_247, v_held_243));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2elamC_lam1, 1, 4, (V[]){v_m_2450, v_fv_242, v_x_2414, v_xs_241});
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str0, 3, " t_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str1, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str3, 5, "goto ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str4, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str5, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str7, 5, " = t_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str8, 1, ";");
Clo g_heff_2ecompile_2eemitc_2eagainTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eagainTo_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eagainTo(V v_label_240, V v_ts_241, V v_ps_242, V v_vs_243) {
top: ;
  V v_t_244 = (g_list_2ezipWith_24s1876717925x1404326288(v_ts_241, heff_dup(v_vs_243)));
  V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_243));
  V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
  V v_t_247 = (g_list_2ezipWith_24s490727218x2138671(((V)&g_heff_2ecompile_2eemitc_2eagainTo_str0), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str1), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str2), v_t_244, v_t_246));
  V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_vs_243); r_; });
  V v_t_249 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_248, MK_INT(1LL))));
  V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eagainTo_str3), v_label_240), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str4));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = (g_prelude_2e_2b_2b_24f543054808x1503188303(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str5), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str6), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str7), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str8), v_ps_242, v_t_249));
  return (g_prelude_2e_2b_2b(v_t_247, v_t_2412));
}
V g_heff_2ecompile_2eemitc_2eagainTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eagainTo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eemitc_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eelemI_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_i_240, v_j_242, 0)) {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eelemI(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str1, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str2, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str3, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str4, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str6, 3, ") {");

HeffT2 g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr(V v_tu_240, V v_key_241, V v_rs_242, V v_x4_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_tu_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_z_244}});
  }
  case TAG_Just: {
    V v_x41_245 = heff_field(v_x4_243, 0);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkWrapper: {
      V v_ws_246 = heff_field(v_x41_245, 0);
      V v_body_247 = heff_field(v_x41_245, 1);
      HeffT6 v_t_248 = (g_heff_2ecompile_2eemitc_2eckOf_24cpr(v_rs_242, v_tu_240, MK_INT(0LL)));
      {
        V v_field_2410 = v_t_248.f[1];
        heff_drop(v_t_248.f[0]);
        heff_drop(v_t_248.f[2]);
        heff_drop(v_t_248.f[3]);
        heff_drop(v_t_248.f[4]);
        heff_drop(v_t_248.f[5]);
        V v_m_2415 = heff_tr(heff_call(v_field_2410, 1, (V[]){heff_dup(v_body_247)}));
        V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x2_2416, 0);
          V v_s_2418 = heff_field(v_x2_2416, 1);
          V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
          V v_t_2419 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str0)));
          V v_t_2420 = (g_heff_2ecompile_2eemitc_2eckOf(v_rs_242, heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL)));
          V v_t_2421 = (g_heff_2ecompile_2eemitc_2eparamList(v_t_2420, heff_dup(v_ws_246)));
          V v_t_2422 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str1), NTAG(TAG_Nil)});
          V v_t_2423 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2422, ((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str2), v_x_2417));
          V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str3), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str4), v_t_2419));
          V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str5)), v_t_2421);
          V v_x_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr_str6)), v_t_2423});
          return ((HeffT2){{v_x_2426, v_s_2418}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2416)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x41_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
Clo g_heff_2ecompile_2eemitc_2eletGoIndexGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eletGoIndexGo_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eletGoIndexGo(V v_i_240, V v_x2_241, V v_t_242, V v_r_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_t2_246 = heff_field(v_x21_244, 0);
      V v_r2_247 = heff_field(v_x21_244, 1);
      if ((heff_strEq_c_lent(v_t_242, v_t2_246, 0) && heff_strEq_c_lent(v_r_243, v_r2_247, 0))) {
        return v_i_240;
      } else {
        V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
        V t_1 = v_rest_245;
        V t_2 = v_t_242;
        V t_3 = v_r_243;
        v_i_240 = t_0;
        v_x2_241 = t_1;
        v_t_242 = t_2;
        v_r_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eletGoIndexGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2eletGoIndexGo(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_str0, 4, "$tok");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_str2, 2, ".c");
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam3(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_entry, 11, 0};

V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866(V v_lit_240, V v_lit_241, V v_lit_242, V v_ce_243, V v_s_244, V v_shapes_245, V v_prims_246, V v_strs_247, V v_protos_248, V v_lams_249, V v_x9_2410) {
top: ;
  switch (heff_tag_of(v_x9_2410)) {
  case TAG_MkPair: {
    V v_m_2411 = heff_field(v_x9_2410, 0);
    V v_ps_2412 = heff_field(v_x9_2410, 1);
    V v_ru_24x9_2410_24MkPair = heff_take_reuse_n(v_x9_2410, 3ULL, 2);
    V v_t_2413 = (g_list_2efoldl_24f891411706x655200538(NTAG(TAG_Nil), heff_dup(v_ps_2412)));
    V v_t_2414 = heff_tag_at_n(v_ru_24x9_2410_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2415 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2414, v_t_2413));
    V v_t_2416 = ({ V a_0 = heff_dup(v_ce_243); V a_1 = v_t_2415; V r_ = (g_heff_2ecompile_2eemitc_2enumbersOf(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = (g_heff_2ecompile_2eemitc_2eusedBy(v_shapes_245, heff_dup(v_ps_2412)));
    V v_t_2418 = (g_list_2emap_24s2073083146x1445066245(v_t_2417));
    V v_xs_2419 = (g_heff_2ecompile_2eemitc_2eusedBy(v_prims_246, heff_dup(v_ps_2412)));
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
    V v_t_2421 = (g_list_2efoldl_24s1668908788x1049324851(NTAG(TAG_Nil), v_t_2420));
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_2412)));
    V v_xs_2443 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam0, 2, 1, (V[]){heff_dup(v_ce_243)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2422; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
    V v_m_2444 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_2443; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_2443); r_; });
    V v_t_2445 = ({ V a_0 = v_m_2444; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2444); r_; });
    V v_t_2446 = (g_list_2efoldl_24f675617784x1820039874(NTAG(TAG_Nil), v_t_2445));
    V v_t_2450 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam2, 2, 1, (V[]){v_ce_243}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2446; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2446); r_; });
    V v_t_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2412));
    V v_t_2455 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam3, 2, 4, (V[]){heff_dup(v_s_244), heff_dup(v_strs_247), heff_dup(v_protos_248), heff_dup(v_lams_249)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2451; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2451); r_; });
    V v_t_2456 = (g_prelude_2e_2b_2b(v_t_2450, v_t_2455));
    V v_t_2457 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2456));
    V v_t_2458 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2457));
    V v_ys_2459 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2458));
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_241, heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_ys_2459})});
    V v_t_2461 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_str1); V a_1 = v_lit_240; V a_2 = v_t_2460; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2460, 2); r_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_m_2411, ((V)&g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_str2)), v_t_2461});
  }
  default: return heff_nomatch(v_x9_2410);
  }
}
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V a8 = a[8]; V a9 = a[9]; V r = g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866(a[0], a[1], a[2], a[3], a4, a5, a6, a7, a8, a9, a[10]); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); heff_drop(a8); heff_drop(a9); return r;
}
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam1(V self, V *args) {
  V v_acc_2432 = args[0];
  V v_x_2433 = args[1];
  V v_ce_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_get_n(heff_get_n(v_ce_2429, 2, 3), 10, 11);
  HeffT2 v_t_2435 = ({ V b_0 = heff_get_n(v_t_2434, 0, 2); V a_1 = v_x_2433; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2437 = v_t_2435.f[1];
    int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
    V v_t_2439;
    if ((v_tag_2436 == ((int64_t)0ULL))) {
      V v_x_2438 = v_field_2437;
      v_t_2439 = v_x_2438;
    } else {
      heff_drop(v_field_2437);
      v_t_2439 = NTAG(TAG_Nil);
    }
    V v_t_2440 = (g_prelude_2e_2b_2b_24f132290754x1091834184(v_acc_2432, heff_dup(v_x_2433), ((V)&g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_str0), v_t_2439));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2433, v_t_2440});
  }
}
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam0(V self, V *args) {
  V v_acc_2423 = args[0];
  V v_x_2424 = args[1];
  V v_ce_243 = heff_env(self)[0];
  V v_t_2442;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_MkPair: {
    V v_d_2425 = heff_field(v_x_2424, 0);
    V v_ru_24x_2424_24MkPair = heff_take_reuse_n(v_x_2424, 1ULL, 2);
    V v_body_2427 = heff_take_field(v_d_2425, 2);
    V v_key_2428 = heff_get_n(v_d_2425, 0, 3);
    V v_ce_2429 = v_ce_243;
    V v_t_2430 = (g_heff_2ecompile_2eir_2eglobalsGo(v_body_2427));
    V v_t_2431 = (g_list_2efoldl_24f1257949983x1023832813(NTAG(TAG_Nil), v_t_2430));
    V v_t_2441 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam1, 2, 1, (V[]){v_ce_2429}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2431; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2431); r_; });
    v_t_2442 = heff_tag_at_n(v_ru_24x_2424_24MkPair, TAG_Cons, 2, (V[]){v_key_2428, v_t_2441});
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  return (g_prelude_2e_2b_2b(v_t_2442, v_acc_2423));
}
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam2(V self, V *args) {
  V v_acc_2447 = args[0];
  V v_x_2448 = args[1];
  V v_ce_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = (g_heff_2ecompile_2eemitc_2edeclOf(v_ce_243, v_x_2448));
  return (g_prelude_2e_2b_2b(v_t_2449, v_acc_2447));
}
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam3(V self, V *args) {
  V v_acc_2452 = args[0];
  V v_x_2453 = args[1];
  V v_s_244 = heff_env(self)[0];
  V v_strs_247 = heff_env(self)[1];
  V v_protos_248 = heff_env(self)[2];
  V v_lams_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2454 = ({ V a_0 = v_s_244; V a_1 = v_strs_247; V a_2 = v_protos_248; V a_3 = v_lams_249; V a_4 = v_x_2453; V r_ = (g_heff_2ecompile_2eemitc_2eownLines(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_244); heff_drop(v_strs_247); heff_drop(v_protos_248); heff_drop(v_lams_249); heff_drop(v_x_2453); r_; });
  return (g_prelude_2e_2b_2b(v_t_2454, v_acc_2452));
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeH_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeH_str1, 1, ",");
Clo g_heff_2ecompile_2eemitc_2eshapeH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eshapeH_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eshapeH(V v_ce_240, V v_sh_241, V v_rest_242) {
top: ;
  V v_t_243 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 7, 11);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_sh_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    V v_t_248;
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      v_t_248 = v_x_247;
    } else {
      heff_drop(v_field_246);
      v_t_248 = NTAG(TAG_Nil);
    }
    V v_x2_249 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_248));
    V v_t_2412;
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nil: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eshapeH_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_xs_2411 = heff_field(v_x2_249, 1);
      heff_take_n(v_x2_249, 3ULL, 2);
      v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeH_str1); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
      break;
    }
    default: heff_nomatch(v_x2_249);
    }
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2412}), v_rest_242});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_sh_241}), v_t_2413});
  }
}
V g_heff_2ecompile_2eemitc_2eshapeH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eshapeH(a[0], a[1], a[2]);
}