// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_HS 9084
#define TAG_Leaf 13717
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_Plus 9189
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_lams 9809570
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_op 10312
#define LBL_owner 307523277
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_sureRecs 1275638267
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
V g_heff_2ecompile_2eemitc_2eaddLam(V, V, V);
V g_heff_2ecompile_2eemitc_2eaddLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eaddLam_clo;
V g_heff_2ecompile_2eemitc_2ebind(V, V, V);
V g_heff_2ecompile_2eemitc_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ebind_clo;
V g_heff_2ecompile_2eemitc_2ecallBound(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallBound_clo;
V g_heff_2ecompile_2eemitc_2eelemI(V, V);
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemI_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efloatSymbols_get(void);
V g_heff_2ecompile_2eemitc_2eisAlnum(V);
V g_heff_2ecompile_2eemitc_2eisAlnum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eisAlnum_clo;
V g_heff_2ecompile_2eemitc_2elamC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamC_clo;
V g_heff_2ecompile_2eemitc_2elamLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamLines_clo;
V g_heff_2ecompile_2eemitc_2emangleChar(V);
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleChar_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2enewLam(V);
V g_heff_2ecompile_2eemitc_2enewLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enewLam_clo;
V g_heff_2ecompile_2eemitc_2eperformNodes(V, V);
V g_heff_2ecompile_2eemitc_2eperformNodes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eperformNodes_clo;
V g_heff_2ecompile_2eemitc_2eplainOperand(V);
V g_heff_2ecompile_2eemitc_2eplainOperand_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eplainOperand_clo;
V g_heff_2ecompile_2eemitc_2eplusDone(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eplusDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eplusDone_clo;
V g_heff_2ecompile_2eemitc_2eprimCloDef(V);
V g_heff_2ecompile_2eemitc_2eprimCloDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimCloDef_clo;
V g_heff_2ecompile_2eemitc_2erelSymbol(V, V);
V g_heff_2ecompile_2eemitc_2erelSymbol_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erelSymbol_clo;
V g_heff_2ecompile_2eemitc_2erunEnd(V, V);
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erunEnd_clo;
V g_heff_2ecompile_2eemitc_2eshapeDef(V);
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo;
V g_heff_2ecompile_2eemitc_2eshapeH(V, V, V);
V g_heff_2ecompile_2eemitc_2eshapeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeH_clo;
V g_heff_2ecompile_2eemitc_2eslotFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo;
V g_heff_2ecompile_2eemitc_2etraverseC(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
V g_heff_2ecompile_2eprims_2eprimArityGo(V, V);
V g_heff_2ecompile_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eprimArityGo_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_intShow_get(void);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1483820613x1826490246(V, V);
V g_list_2efoldl_24s1483820613x1826490246_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1483820613x1826490246_clo;
V g_list_2efoldl_24s2138447488x1597606028(V, V);
V g_list_2efoldl_24s2138447488x1597606028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2138447488x1597606028_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2elookupBy(V, V, V);
V g_list_2elookupBy_entry(V self, V *a);
extern Clo g_list_2elookupBy_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1293205645x619162872(V, V, V, V);
V g_list_2emap_24f1293205645x619162872_entry(V self, V *a);
extern Clo g_list_2emap_24f1293205645x619162872_clo;
V g_list_2emap_24f1638246995x433291654(V, V, V);
V g_list_2emap_24f1638246995x433291654_entry(V self, V *a);
extern Clo g_list_2emap_24f1638246995x433291654_clo;
V g_list_2emap_24s640776339x1223679834(V);
V g_list_2emap_24s640776339x1223679834_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_clo;
V g_map_2elookup_24s1338854231x236594845(V, V);
V g_map_2elookup_24s1338854231x236594845_entry(V self, V *a);
extern Clo g_map_2elookup_24s1338854231x236594845_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_strEq_get(void);
Clo g_heff_2ecompile_2eemitc_2emangleW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emangleW_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2emangleW(V v_s_240, V v_i_241, V v_j_242, V v_acc_243) {
top: ;
  V v_t_245;
  if (heff_intLt_c(heff_dup(v_j_242), heff_strLength_lent(v_s_240, 0))) {
    v_t_245 = (g_heff_2ecompile_2eemitc_2eisAlnum(heff_strByteAt_lent(v_s_240, v_j_242, 0)));
  } else {
    v_t_245 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V t_0 = v_s_240;
    V t_1 = v_i_241;
    V t_2 = heff_intAdd(v_j_242, MK_INT(1LL));
    V t_3 = v_acc_243;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_j_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  } else {
    heff_drop(v_t_245);
    if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_j_242))) {
      return heff_strAppend(v_acc_243, heff_strSlice(v_s_240, v_i_241, v_j_242));
    } else {
      V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleChar(heff_strByteAt_lent(v_s_240, v_j_242, 0)));
      V v_t_248 = heff_strAppend(heff_strSlice_lent(v_s_240, v_i_241, v_j_242, 2), v_t_247);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(heff_dup(v_j_242), MK_INT(1LL));
      V t_2 = heff_intAdd(v_j_242, MK_INT(1LL));
      V t_3 = heff_strAppend(v_acc_243, v_t_248);
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emangleW(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eslotFrom_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eslotFrom(V v_base_240, V v_m_241, V v_h_242, V v_taken_243) {
top: ;
  V v_x3_244 = (g_map_2elookup_24s1338854231x236594845(heff_intAdd(heff_dup(v_base_240), heff_dup(v_h_242)), v_taken_243));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    return heff_intAdd(v_base_240, v_h_242);
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    V v_t_246 = heff_intMod(heff_intAdd(v_h_242, MK_INT(1LL)), heff_dup(v_m_241));
    V t_0 = v_base_240;
    V t_1 = v_m_241;
    V t_2 = v_t_246;
    V t_3 = v_taken_243;
    v_base_240 = t_0;
    v_m_241 = t_1;
    v_h_242 = t_2;
    v_taken_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2eslotFrom(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2enewLam_str0, 4, "_lam");
Clo g_heff_2ecompile_2eemitc_2enewLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enewLam_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2enewLam(V v_s_240) {
top: ;
  V v_t_241 = heff_intShow(heff_dup(heff_rfield(v_s_240, 1)));
  V v_t_242 = heff_strAppend(heff_dup(heff_rfield(v_s_240, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enewLam_str0), v_t_241));
  V v_t_243 = heff_intAdd(heff_take_field(v_s_240, 1), MK_INT(1LL));
  V v_t_244 = ({ V rv_1 = v_t_243; V rr_ = heff_rec_reuse_nf(v_s_240, 253ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_t_244});
}
V g_heff_2ecompile_2eemitc_2enewLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2enewLam(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str1, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str2, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str3, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str4, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str6, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str7, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str8, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str9, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str10, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str11, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str20, 0, "");
Clo g_heff_2ecompile_2eemitc_2erelSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2erelSymbol_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2erelSymbol(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_x2_242 = ({ V a_0 = heff_dup(g_strEq_get()); V a_1 = v_p_240; V b_2 = heff_dup(g_heff_2ecompile_2eemitc_2efloatSymbols_get()); V r_ = (g_list_2elookupBy(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str0);
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x2_242, 0);
      heff_take_n(v_x2_242, 1ULL, 1);
      return v_x_243;
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  case TAG_Just: {
    V v_fp_244 = heff_field(v_x2_241, 0);
    heff_drop(v_p_240);
    V v_t_245 = heff_dup(heff_rfield(v_fp_244, 1));
    switch (heff_tag_of(v_t_245)) {
    case TAG_OpAdd: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str1);
    }
    case TAG_OpSub: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str2);
    }
    case TAG_OpMul: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str3);
    }
    case TAG_OpDiv: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str4);
    }
    case TAG_OpRem: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str5);
    }
    case TAG_OpEq: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str6);
    }
    case TAG_OpLt: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str7);
    }
    case TAG_OpLe: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str8);
    }
    case TAG_OpAnd: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str9);
    }
    case TAG_OpOr: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str10);
    }
    case TAG_OpXor: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str11);
    }
    case TAG_OpShl: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str12);
    }
    case TAG_OpShr: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str13);
    }
    case TAG_OpShow: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str14);
    }
    case TAG_OpFromInt: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str15);
    }
    case TAG_OpToInt: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str16);
    }
    case TAG_OpSqrt: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str17);
    }
    case TAG_OpFromFloat: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str18);
    }
    case TAG_OpToFloat: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str19);
    }
    case TAG_OpFloor: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str20);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2erelSymbol_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2erelSymbol(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str1, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str2, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str3, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str4, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str5, 8, "heff_tr(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str8, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str10, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str11, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str14, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str16, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str17, 4, ")); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str18, 7, " r_; })");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str19, 6, " r_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str20, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str21, 3, "({ ");
Clo g_heff_2ecompile_2eemitc_2ecallBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallBound_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2ecallBound(V v_g_240, V v_tr_241, V v_w_242, V v_bs_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_bs_243)));
  V v_x2_245 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1483820613x1826490246(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str1); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_2411;
  switch (heff_tag_of(v_w_242)) {
  case TAG_Nothing: {
    v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str2);
    break;
  }
  case TAG_Just: {
    V v_r_249 = heff_field(v_w_242, 0);
    switch (heff_tag_of(v_r_249)) {
    case TAG_RepV: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str3);
      break;
    }
    case TAG_RepFix: {
      V v_w_2410 = heff_field(v_r_249, 0);
      v_t_2411 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_2410));
      break;
    }
    case TAG_RepF64: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str4);
      break;
    }
    default: heff_nomatch(v_r_249);
    }
    break;
  }
  default: heff_nomatch(v_w_242);
  }
  V v_t_2412;
  if ((heff_dup(v_tr_241) == NTAG(TAG_True))) {
    v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str5);
  } else {
    v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str6);
  }
  V v_t_2416;
  switch (heff_tag_of(v_w_242)) {
  case TAG_Nothing: {
    V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str7)));
    v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str8), v_t_2413);
    break;
  }
  case TAG_Just: {
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str9)));
    v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str10), v_t_2415), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str11));
    break;
  }
  default: heff_nomatch(v_w_242);
  }
  V v_t_2417 = heff_strAppend(v_t_2412, heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str12)));
  V v_x2_2418 = (g_list_2emap_24s640776339x1223679834(heff_dup(v_bs_243)));
  V v_t_2421;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str13);
    break;
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    v_t_2421 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str14); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_243));
  V v_x2_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s2138447488x1597606028(a_0, a_1)); heff_drop(v_t_2422); r_; });
  V v_t_2426;
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_Nil: {
    v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str15);
    break;
  }
  case TAG_Cons: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_xs_2425 = heff_field(v_x2_2423, 1);
    heff_take_n(v_x2_2423, 3ULL, 2);
    v_t_2426 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str16); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2423);
  }
  V v_t_2427 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str17), heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str18)));
  V v_t_2428 = heff_strAppend(v_t_2417, heff_strAppend(v_t_2421, v_t_2427));
  V v_t_2429 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str19), v_t_2428));
  V v_t_2430 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str20), v_t_2429));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str21), v_t_2430);
}
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2ecallBound(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str0, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str2, 33, "_clo = {{0x80000000u, K_CLO, 0}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str3, 30, "(V self, V *args); static Clo ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str4, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str5, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str6, 18, "(V self, V *args);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str8, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str9, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str10, 5, "_clo)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str11, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str13, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str14, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str15, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str16, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str17, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str18, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str19, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str20, 11, "heff_clo_n(");
V g_heff_2ecompile_2eemitc_2elamC_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2elamC_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2elamC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elamC_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2elamC(V v_k_240, V v_xs_241, V v_fv_242, V v_held_243, V v_body_244, V v_s_245) {
top: ;
  V v_x2_246 = (g_heff_2ecompile_2eemitc_2enewLam(v_s_245));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_body_244}));
    return (g_heff_2ecompile_2eemitc_2ebind(v_t_249, heff_clo_n(g_heff_2ecompile_2eemitc_2elamC_lam0, 2, 5, (V[]){v_xs_241, v_fv_242, v_x_247, v_k_240, v_held_243}), v_s_248));
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2elamC(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eemitc_2elamC_lam1(V self, V *args) {
  V v_u_2425 = args[0];
  V v_z_2426 = args[1];
  V v_k_240 = heff_env(self)[0];
  V v_held_243 = heff_env(self)[1];
  V v_fv_242 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_xs_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2425);
  V v_m_2427 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_held_243));
  V v_x2_2428 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_z_2426}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_s_2430 = heff_field(v_x2_2428, 1);
    V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
    V v_t_2433;
    switch (heff_tag_of(v_fv_242)) {
    case TAG_Nil: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_fv_242);
    }
    V v_x_2446;
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop(v_fv_242);
      heff_drop(v_xs_241);
      heff_drop(v_x_2429);
      heff_drop(v_t_2433);
      v_x_2446 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str9), heff_strAppend(v_x_247, ((V)&g_heff_2ecompile_2eemitc_2elamC_str10)));
    } else {
      heff_drop(v_t_2433);
      V v_t_2434 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
      V v_t_2435 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fv_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_fv_242); r_; });
      V v_t_2441;
      switch (heff_tag_of(v_x_2429)) {
      case TAG_Nil: {
        v_t_2441 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str11);
        break;
      }
      case TAG_Cons: {
        V v_t_2440;
        switch (heff_tag_of(v_x_2429)) {
        case TAG_Nil: {
          v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str12);
          break;
        }
        case TAG_Cons: {
          V v_x_2438 = heff_field(v_x_2429, 0);
          V v_xs_2439 = heff_field(v_x_2429, 1);
          heff_take_n(v_x_2429, 3ULL, 2);
          v_t_2440 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str13); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
          break;
        }
        default: heff_nomatch(v_x_2429);
        }
        v_t_2441 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str14), heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2eemitc_2elamC_str15)));
        break;
      }
      default: heff_nomatch(v_x_2429);
      }
      V v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str16), heff_strAppend(v_t_2441, ((V)&g_heff_2ecompile_2eemitc_2elamC_str17)));
      V v_t_2443 = heff_strAppend(heff_intShow(v_t_2435), v_t_2442);
      V v_t_2444 = heff_strAppend(heff_intShow(v_t_2434), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str18), v_t_2443));
      V v_t_2445 = heff_strAppend(v_x_247, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str19), v_t_2444));
      v_x_2446 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str20), v_t_2445);
    }
    return heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){v_x_2446, v_s_2430});
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_heff_2ecompile_2eemitc_2elamC_lam0(V self, V *args) {
  V v_ls_2410 = args[0];
  V v_z_2411 = args[1];
  V v_xs_241 = heff_env(self)[0];
  V v_fv_242 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_k_240 = heff_env(self)[3];
  V v_held_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_n_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_t_2419;
  switch (heff_tag_of(v_fv_242)) {
  case TAG_Nil: {
    V v_t_2413 = heff_strAppend(heff_intShow(v_n_2412), ((V)&g_heff_2ecompile_2eemitc_2elamC_str0));
    V v_t_2414 = heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str1), v_t_2413));
    V v_t_2415 = heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str2), v_t_2414));
    V v_t_2416 = heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str3), v_t_2415));
    v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str4), v_t_2416);
    break;
  }
  case TAG_Cons: {
    heff_drop(v_n_2412);
    v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str5), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2ecompile_2eemitc_2elamC_str6)));
    break;
  }
  default: heff_nomatch(v_fv_242);
  }
  V v_x2_2420 = (g_heff_2ecompile_2eemitc_2elamLines(heff_dup(v_x_247), heff_dup(v_xs_241), heff_dup(v_fv_242), v_ls_2410));
  V v_t_2423;
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nil: {
    v_t_2423 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str7);
    break;
  }
  case TAG_Cons: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_xs_2422 = heff_field(v_x2_2420, 1);
    heff_take_n(v_x2_2420, 3ULL, 2);
    v_t_2423 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str8); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2420);
  }
  V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2eaddLam_clo), 2, (V[]){v_t_2419, v_t_2423}));
  return (g_heff_2ecompile_2eemitc_2ebind(v_t_2424, heff_clo_n(g_heff_2ecompile_2eemitc_2elamC_lam1, 2, 5, (V[]){v_k_240, v_held_243, v_fv_242, v_x_247, v_xs_241}), v_z_2411));
}
Clo g_heff_2ecompile_2eemitc_2eplainOperand_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eplainOperand_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eplainOperand(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RLocal: {
    return NTAG(TAG_True);
  }
  case TAG_RDup: {
    return NTAG(TAG_True);
  }
  case TAG_RClo: {
    return NTAG(TAG_False);
  }
  case TAG_RGet: {
    return NTAG(TAG_False);
  }
  case TAG_RGetRaw: {
    return NTAG(TAG_False);
  }
  case TAG_RInt: {
    return NTAG(TAG_True);
  }
  case TAG_RFloat: {
    return NTAG(TAG_False);
  }
  case TAG_RStr: {
    return NTAG(TAG_True);
  }
  case TAG_RBytes: {
    return NTAG(TAG_False);
  }
  case TAG_RFixed: {
    return NTAG(TAG_False);
  }
  case TAG_RF32: {
    return NTAG(TAG_False);
  }
  case TAG_RNTag: {
    return NTAG(TAG_True);
  }
  case TAG_RTag: {
    return NTAG(TAG_False);
  }
  case TAG_RTagIn: {
    return NTAG(TAG_False);
  }
  case TAG_RRec: {
    return NTAG(TAG_False);
  }
  case TAG_RRecIn: {
    return NTAG(TAG_False);
  }
  case TAG_RField: {
    return NTAG(TAG_False);
  }
  case TAG_RDupE: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldV: {
    return NTAG(TAG_False);
  }
  case TAG_RGetN: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldU: {
    return NTAG(TAG_False);
  }
  case TAG_RGetNU: {
    return NTAG(TAG_False);
  }
  case TAG_RWord: {
    return NTAG(TAG_False);
  }
  case TAG_RTakeField: {
    return NTAG(TAG_False);
  }
  case TAG_RGetLabel: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimFn: {
    return NTAG(TAG_False);
  }
  case TAG_RPrim: {
    return NTAG(TAG_False);
  }
  case TAG_RLam: {
    return NTAG(TAG_False);
  }
  case TAG_RCall: {
    return NTAG(TAG_False);
  }
  case TAG_RApply: {
    return NTAG(TAG_False);
  }
  case TAG_RBool: {
    return NTAG(TAG_False);
  }
  case TAG_RAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_RBox: {
    return NTAG(TAG_False);
  }
  case TAG_RUnbox: {
    return NTAG(TAG_False);
  }
  case TAG_RPeek: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimU: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimAt: {
    return NTAG(TAG_False);
  }
  case TAG_RFixU: {
    return NTAG(TAG_False);
  }
  case TAG_RF32U: {
    return NTAG(TAG_False);
  }
  case TAG_RF64U: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2eplainOperand_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eplainOperand(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemitc_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eelemI_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_i_240), heff_dup(v_j_242))) {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eelemI(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_str2, 34, "(V p, V k) { return heff_provider_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_str3, 9, "(p, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_str4, 22, "static V heff_perform_");
Clo g_heff_2ecompile_2eemitc_2eperformNodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eperformNodes_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eperformNodes(V v_x1_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_t_243 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_str0), heff_dup(v_k_242), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_str1), v_k_242, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_t_244 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_t_243; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_243); r_; });
    V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_str2), heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_str3)));
    V v_t_246 = heff_strAppend(heff_intShow(heff_dup(v_n_241)), v_t_245);
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_str4), v_t_246), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, heff_intAdd(v_n_241, MK_INT(1LL))});
  }
  case TAG_Plus: {
    V v_a_248 = heff_field(v_x1_240, 0);
    V v_b_249 = heff_field(v_x1_240, 1);
    V v_x4_2410 = (g_heff_2ecompile_2eemitc_2eperformNodes(v_a_248, heff_intAdd(heff_dup(v_n_241), MK_INT(1LL))));
    switch (heff_tag_of(v_x4_2410)) {
    case TAG_MkPair: {
      V v_la_2411 = heff_field(v_x4_2410, 0);
      V v_na_2412 = heff_field(v_x4_2410, 1);
      heff_take_n(v_x4_2410, 3ULL, 2);
      V v_t_2413 = (g_heff_2ecompile_2eemitc_2eperformNodes(v_b_249, heff_dup(v_na_2412)));
      return (g_heff_2ecompile_2eemitc_2eplusDone(v_n_241, v_la_2411, v_na_2412, v_t_2413));
    }
    default: return heff_nomatch(v_x4_2410);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2eperformNodes_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eperformNodes(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str0, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str1, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str3, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str5, 4, "); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str6, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str7, 42, "_entry(V self, V *a) { (void)self; return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str8, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str9, 8, "_entry, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str10, 38, "_clo = {{0x80000000u, K_CLO, 0}, prim_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str11, 16, "static Clo prim_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str12, 14, "static V prim_");
Clo g_heff_2ecompile_2eemitc_2eprimCloDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprimCloDef_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eprimCloDef(V v_p_240) {
top: ;
  V v_t_241 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2ecompile_2eprims_2eallPrims_get()); V r_ = (g_heff_2ecompile_2eprims_2eprimArityGo(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_n_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_x2_243 = (g_list_2emap_24f1293205645x619162872(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str0), ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str1), MK_INT(0LL), heff_intSub(heff_dup(v_n_242), MK_INT(1LL))));
    V v_t_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str3); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str4), heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str5)));
    V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str6), heff_dup(v_p_240)), v_t_247);
    V v_t_249 = heff_strAppend(heff_dup(v_p_240), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str7), v_t_248));
    V v_t_2410 = heff_strAppend(heff_intShow(v_n_242), ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str8));
    V v_t_2411 = heff_strAppend(heff_dup(v_p_240), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str9), v_t_2410));
    V v_t_2412 = heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str10), v_t_2411));
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str11), v_t_2412), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str12), v_t_249), v_t_2413});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eemitc_2eprimCloDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprimCloDef(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str0, 2, "__");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str1, 2, "__");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str2, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str5, 6, "[] = {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str6, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str7, 22, "static uint32_t shape_");
Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eshapeDef_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eshapeDef(V v_key_240) {
top: ;
  V v_t_241 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str0), heff_dup(v_key_240), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str1), v_key_240, MK_INT(0LL), 5), NTAG(TAG_Nil)));
  V v_x2_242 = (g_list_2emap_24f1638246995x433291654(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str2), MK_INT(0LL), v_t_241));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str4); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str5), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str6)));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str7), heff_strAppend(v_key_240, v_t_246));
}
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eshapeDef(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str0, 64, "static V heff_perform(V p, V k) { return heff_perform_0(p, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str2, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str3, 9, "_get(); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str5, 35, "static V heff_entry(void) { return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str6, 0, "");
Clo g_heff_2ecompile_2eemitc_2erunEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2erunEnd_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2erunEnd(V v_eff_240, V v_ce_241) {
top: ;
  V v_x1_242 = (g_heff_2ecompile_2eemitc_2eperformNodes(v_eff_240, MK_INT(0LL)));
  V v_t_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    v_t_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str0), NTAG(TAG_Nil)});
  V v_t_247 = (g_prelude_2e_2b_2b(v_t_245, v_t_246));
  V v_t_248 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2erunEnd_str1)));
  V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erunEnd_str2), v_t_248), ((V)&g_heff_2ecompile_2eemitc_2erunEnd_str3));
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str4), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erunEnd_str5), v_t_249), v_t_2410});
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str6), v_t_2411}));
}
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2erunEnd(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeH_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeH_str1, 1, ",");
Clo g_heff_2ecompile_2eemitc_2eshapeH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eshapeH_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eshapeH(V v_ce_240, V v_sh_241, V v_rest_242) {
top: ;
  V v_t_243 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 7, 8);
  V v_x2_244 = ({ V a_0 = heff_dup(v_sh_241); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_x2_247 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2eshapeH_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeH_str1); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2410}), v_rest_242});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_sh_241}), v_t_2411});
}
V g_heff_2ecompile_2eemitc_2eshapeH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eshapeH(a[0], a[1], a[2]);
}