// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DoneOrErrno 39355
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_HS 9084
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_inLam 301681229
#define LBL_op 10312
#define LBL_result 1012715336
#define LBL_stmts 311127493
#define LBL_sureRecs 1275638267
#define LBL_tag 324116
V g_heff_2ecompile_2eemitc_2eaddLam(V, V, V);
V g_heff_2ecompile_2eemitc_2eaddLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eaddLam_clo;
V g_heff_2ecompile_2eemitc_2eagainTo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eagainTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eagainTo_clo;
V g_heff_2ecompile_2eemitc_2ebind(V, V, V);
V g_heff_2ecompile_2eemitc_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ebind_clo;
V g_heff_2ecompile_2eemitc_2ecallBound(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallBound_clo;
V g_heff_2ecompile_2eemitc_2eelemI(V, V);
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemI_clo;
V g_heff_2ecompile_2eemitc_2efloatSymbols_get(void);
V g_heff_2ecompile_2eemitc_2eisAlnum(V);
V g_heff_2ecompile_2eemitc_2eisAlnum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eisAlnum_clo;
V g_heff_2ecompile_2eemitc_2elamC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamC_clo;
V g_heff_2ecompile_2eemitc_2elamLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamLines_clo;
V g_heff_2ecompile_2eemitc_2eletGoIndexGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eletGoIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eletGoIndexGo_clo;
V g_heff_2ecompile_2eemitc_2emangleChar(V);
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleChar_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
HeffT2 g_heff_2ecompile_2eemitc_2enewLam_24cpr(V);
V g_heff_2ecompile_2eemitc_2enulLines(V, V, V);
V g_heff_2ecompile_2eemitc_2enulLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enulLines_clo;
V g_heff_2ecompile_2eemitc_2eperformNodes(V, V);
V g_heff_2ecompile_2eemitc_2eperformNodes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eperformNodes_clo;
HeffT2 g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(V, V);
HeffT2 g_heff_2ecompile_2eemitc_2eplusDone_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprimCloDef(V);
V g_heff_2ecompile_2eemitc_2eprimCloDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimCloDef_clo;
V g_heff_2ecompile_2eemitc_2erelSymbol(V, V);
V g_heff_2ecompile_2eemitc_2erelSymbol_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erelSymbol_clo;
V g_heff_2ecompile_2eemitc_2erunEnd(V, V);
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erunEnd_clo;
V g_heff_2ecompile_2eemitc_2eshapeDef(V);
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo;
V g_heff_2ecompile_2eemitc_2eshapeH(V, V, V);
V g_heff_2ecompile_2eemitc_2eshapeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeH_clo;
V g_heff_2ecompile_2eemitc_2eslotFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
HeffT2 g_heff_2ecompile_2eprims_2eprimArityGo_24cpr(V, V);
V g_intShow_get(void);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1483820613x1826490246(V, V);
V g_list_2efoldl_24s1483820613x1826490246_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1483820613x1826490246_clo;
V g_list_2efoldl_24s2138447488x1597606028(V, V);
V g_list_2efoldl_24s2138447488x1597606028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2138447488x1597606028_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
HeffT2 g_list_2elookupBy_24cpr(V, V, V);
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1293205645x619162872(V, V, V, V);
V g_list_2emap_24f1293205645x619162872_entry(V self, V *a);
extern Clo g_list_2emap_24f1293205645x619162872_clo;
V g_list_2emap_24f583754813x1054900711(V, V, V);
V g_list_2emap_24f583754813x1054900711_entry(V self, V *a);
extern Clo g_list_2emap_24f583754813x1054900711_clo;
V g_list_2emap_24s640776339x1223679834(V);
V g_list_2emap_24s640776339x1223679834_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s1877091673x1588480570(V, V, V, V, V);
V g_list_2ezipWith_24s1877091673x1588480570_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1877091673x1588480570_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1727312714x1365290191(V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1727312714x1365290191_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1727312714x1365290191_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
HeffT2 g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_strEq_get(void);
Clo g_heff_2ecompile_2eemitc_2emangleW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emangleW_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2emangleW(V v_s_240, V v_i_241, V v_box_24j_242, V v_acc_243) {
  int64_t v_j_242 = heff_unbox_word(v_box_24j_242);
top: ;
  if ((v_j_242 < heff_unbox_word(heff_strLength_lent(v_s_240, 0)))) {
    V v_t_245 = (g_heff_2ecompile_2eemitc_2eisAlnum(heff_strByteAt_lent(v_s_240, heff_box_word(v_j_242), 2)));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = v_s_240;
      V t_1 = v_i_241;
      int64_t t_2 = (v_j_242 + ((int64_t)1ULL));
      V t_3 = v_acc_243;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_245);
      if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_j_242)) {
        return heff_strAppend(v_acc_243, heff_strSlice_lent(v_s_240, v_i_241, heff_box_word(v_j_242), 6));
      } else {
        V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleChar(heff_strByteAt_lent(v_s_240, heff_box_word(v_j_242), 2)));
        V v_t_248 = heff_strAppend(heff_strSlice_lent(v_s_240, v_i_241, heff_box_word(v_j_242), 6), v_t_247);
        V t_0 = v_s_240;
        V t_1 = heff_box_word((v_j_242 + ((int64_t)1ULL)));
        int64_t t_2 = (v_j_242 + ((int64_t)1ULL));
        V t_3 = heff_strAppend(v_acc_243, v_t_248);
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
    }
  } else {
    if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_j_242)) {
      return heff_strAppend(v_acc_243, heff_strSlice_lent(v_s_240, v_i_241, heff_box_word(v_j_242), 6));
    } else {
      V v_t_2410 = (g_heff_2ecompile_2eemitc_2emangleChar(heff_strByteAt_lent(v_s_240, heff_box_word(v_j_242), 2)));
      V v_t_2411 = heff_strAppend(heff_strSlice_lent(v_s_240, v_i_241, heff_box_word(v_j_242), 6), v_t_2410);
      V t_0 = v_s_240;
      V t_1 = heff_box_word((v_j_242 + ((int64_t)1ULL)));
      int64_t t_2 = (v_j_242 + ((int64_t)1ULL));
      V t_3 = heff_strAppend(v_acc_243, v_t_2411);
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2emangleW(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eslotFrom_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eslotFrom(V v_base_240, V v_m_241, V v_h_242, V v_taken_243) {
top: ;
  HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(v_taken_243, heff_intAdd(heff_dup(v_base_240), heff_dup(v_h_242))));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_246;
      heff_drop(v_x_248);
      V v_t_249 = heff_intMod(heff_intAdd(v_h_242, MK_INT(1LL)), heff_dup(v_m_241));
      V t_0 = v_base_240;
      V t_1 = v_m_241;
      V t_2 = v_t_249;
      V t_3 = v_taken_243;
      v_base_240 = t_0;
      v_m_241 = t_1;
      v_h_242 = t_2;
      v_taken_243 = t_3;
      goto top;
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_246);
      return heff_intAdd(v_base_240, v_h_242);
    }
  }
}
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2eslotFrom(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str1, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str2, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str3, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str4, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str6, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str7, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str8, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str9, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str10, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str11, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str20, 0, "");
Clo g_heff_2ecompile_2eemitc_2erelSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2erelSymbol_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2erelSymbol(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    HeffT2 v_t_242 = (g_list_2elookupBy_24cpr(heff_dup(g_strEq_get()), v_p_240, heff_dup(g_heff_2ecompile_2eemitc_2efloatSymbols_get())));
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_244;
        return v_x_246;
      } else {
        heff_drop(v_field_244);
        return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str0);
      }
    }
  }
  case TAG_Just: {
    V v_fp_247 = heff_field(v_x2_241, 0);
    heff_drop(v_p_240);
    V v_t_248 = heff_dup(heff_rfield(v_fp_247, 1));
    switch (heff_tag_of(v_t_248)) {
    case TAG_OpAdd: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str1);
    }
    case TAG_OpSub: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str2);
    }
    case TAG_OpMul: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str3);
    }
    case TAG_OpDiv: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str4);
    }
    case TAG_OpRem: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str5);
    }
    case TAG_OpEq: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str6);
    }
    case TAG_OpLt: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str7);
    }
    case TAG_OpLe: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str8);
    }
    case TAG_OpAnd: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str9);
    }
    case TAG_OpOr: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str10);
    }
    case TAG_OpXor: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str11);
    }
    case TAG_OpShl: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str12);
    }
    case TAG_OpShr: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str13);
    }
    case TAG_OpShow: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str14);
    }
    case TAG_OpFromInt: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str15);
    }
    case TAG_OpToInt: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str16);
    }
    case TAG_OpSqrt: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str17);
    }
    case TAG_OpFromFloat: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str18);
    }
    case TAG_OpToFloat: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str19);
    }
    case TAG_OpFloor: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str20);
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2erelSymbol_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2erelSymbol(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str1, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str2, 8, "heff_tr(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str5, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str7, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str8, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str11, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str13, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str14, 4, ")); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str15, 7, " r_; })");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str16, 6, " r_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str17, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str18, 3, "({ ");
Clo g_heff_2ecompile_2eemitc_2ecallBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallBound_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ecallBound(V v_ty_240, V v_g_241, V v_tr_242, V v_w_243, V v_bs_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_bs_244)));
  V v_x2_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1483820613x1826490246(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str1); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410;
  if ((heff_dup(v_tr_242) == NTAG(TAG_True))) {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str2);
  } else {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str3);
  }
  V v_t_2414;
  switch (heff_tag_of(v_w_243)) {
  case TAG_Nothing: {
    V v_t_2411 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str4)));
    v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str5), v_t_2411);
    break;
  }
  case TAG_Just: {
    V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str6)));
    v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str7), v_t_2413), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str8));
    break;
  }
  default: heff_nomatch(v_w_243);
  }
  V v_t_2415 = heff_strAppend(v_t_2410, heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str9)));
  V v_x2_2416 = (g_list_2emap_24s640776339x1223679834(heff_dup(v_bs_244)));
  V v_t_2419;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nil: {
    v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str10);
    break;
  }
  case TAG_Cons: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_xs_2418 = heff_field(v_x2_2416, 1);
    heff_take_n(v_x2_2416, 3ULL, 2);
    v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str11); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_244));
  V v_x2_2421 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s2138447488x1597606028(a_0, a_1)); heff_drop(v_t_2420); r_; });
  V v_t_2424;
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_Nil: {
    v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_xs_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str13); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2421);
  }
  V v_t_2425 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str14), heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str15)));
  V v_t_2426 = heff_strAppend(v_t_2415, heff_strAppend(v_t_2419, v_t_2425));
  V v_t_2427 = heff_strAppend(v_ty_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str16), v_t_2426));
  V v_t_2428 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str17), v_t_2427));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str18), v_t_2428);
}
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ecallBound(a[0], a1, a2, a3, a[4]); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str0, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str2, 33, "_clo = {{0x80000000u, K_CLO, 0}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str3, 30, "(V self, V *args); static Clo ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str4, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str5, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str6, 18, "(V self, V *args);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str8, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str9, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str10, 5, "_clo)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str11, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str13, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str14, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str15, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str16, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str17, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str18, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str19, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str20, 11, "heff_clo_n(");
V g_heff_2ecompile_2eemitc_2elamC_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2elamC_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2elamC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elamC_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2elamC(V v_k_240, V v_xs_241, V v_fv_242, V v_held_243, V v_body_244, V v_s_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2ecompile_2eemitc_2enewLam_24cpr(v_s_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_x_249 = v_field_247;
    V v_s_2410 = v_field_248;
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 5)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2412 = heff_tr(heff_call(heff_get_n(v_t_2411, 1, 6), 1, (V[]){v_body_244}));
    return (g_heff_2ecompile_2eemitc_2ebind(v_t_2412, heff_clo_n(g_heff_2ecompile_2eemitc_2elamC_lam0, 2, 5, (V[]){v_xs_241, v_fv_242, v_x_249, v_k_240, v_held_243}), v_s_2410));
  }
}
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2elamC(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eemitc_2elamC_lam1(V self, V *args) {
  V v_u_2428 = args[0];
  V v_z_2429 = args[1];
  V v_k_240 = heff_env(self)[0];
  V v_held_243 = heff_env(self)[1];
  V v_fv_242 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_xs_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2428);
  V v_m_2430 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_held_243));
  V v_x2_2431 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_z_2429}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_s_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    V v_x_2448;
    switch (heff_tag_of(v_fv_242)) {
    case TAG_Nil: {
      heff_drop(v_xs_241);
      heff_drop(v_x_2432);
      v_x_2448 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str9), heff_strAppend(v_x_249, ((V)&g_heff_2ecompile_2eemitc_2elamC_str10)));
      break;
    }
    case TAG_Cons: {
      V v_t_2436 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
      V v_t_2437 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fv_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_fv_242, 2); r_; });
      V v_t_2443;
      switch (heff_tag_of(v_x_2432)) {
      case TAG_Nil: {
        v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str11);
        break;
      }
      case TAG_Cons: {
        V v_t_2442;
        switch (heff_tag_of(v_x_2432)) {
        case TAG_Nil: {
          v_t_2442 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str12);
          break;
        }
        case TAG_Cons: {
          V v_x_2440 = heff_field(v_x_2432, 0);
          V v_xs_2441 = heff_field(v_x_2432, 1);
          heff_take_n(v_x_2432, 3ULL, 2);
          v_t_2442 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str13); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
          break;
        }
        default: heff_nomatch(v_x_2432);
        }
        v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str14), heff_strAppend(v_t_2442, ((V)&g_heff_2ecompile_2eemitc_2elamC_str15)));
        break;
      }
      default: heff_nomatch(v_x_2432);
      }
      V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str16), heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2eemitc_2elamC_str17)));
      V v_t_2445 = heff_strAppend(heff_intShow(v_t_2437), v_t_2444);
      V v_t_2446 = heff_strAppend(heff_intShow(v_t_2436), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str18), v_t_2445));
      V v_t_2447 = heff_strAppend(v_x_249, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str19), v_t_2446));
      v_x_2448 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str20), v_t_2447);
      break;
    }
    default: heff_nomatch(v_fv_242);
    }
    return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){v_x_2448, v_s_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2eemitc_2elamC_lam0(V self, V *args) {
  V v_ls_2413 = args[0];
  V v_z_2414 = args[1];
  V v_xs_241 = heff_env(self)[0];
  V v_fv_242 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_k_240 = heff_env(self)[3];
  V v_held_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_n_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_t_2422;
  switch (heff_tag_of(v_fv_242)) {
  case TAG_Nil: {
    V v_t_2416 = heff_strAppend(heff_intShow(v_n_2415), ((V)&g_heff_2ecompile_2eemitc_2elamC_str0));
    V v_t_2417 = heff_strAppend(heff_dup(v_x_249), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str1), v_t_2416));
    V v_t_2418 = heff_strAppend(heff_dup(v_x_249), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str2), v_t_2417));
    V v_t_2419 = heff_strAppend(heff_dup(v_x_249), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str3), v_t_2418));
    v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str4), v_t_2419);
    break;
  }
  case TAG_Cons: {
    heff_drop(v_n_2415);
    v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str5), heff_strAppend(heff_dup(v_x_249), ((V)&g_heff_2ecompile_2eemitc_2elamC_str6)));
    break;
  }
  default: heff_nomatch(v_fv_242);
  }
  V v_x2_2423 = (g_heff_2ecompile_2eemitc_2elamLines(heff_dup(v_x_249), heff_dup(v_xs_241), heff_dup(v_fv_242), v_ls_2413));
  V v_t_2426;
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_Nil: {
    v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str7);
    break;
  }
  case TAG_Cons: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_xs_2425 = heff_field(v_x2_2423, 1);
    heff_take_n(v_x2_2423, 3ULL, 2);
    v_t_2426 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str8); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2423);
  }
  V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2eaddLam_clo), 2, (V[]){v_t_2422, v_t_2426}));
  return (g_heff_2ecompile_2eemitc_2ebind(v_t_2427, heff_clo_n(g_heff_2ecompile_2eemitc_2elamC_lam1, 2, 5, (V[]){v_k_240, v_held_243, v_fv_242, v_x_249, v_xs_241}), v_z_2414));
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str0, 3, " t_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str1, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str3, 5, "goto ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str4, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str5, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str7, 5, " = t_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str8, 1, ";");
Clo g_heff_2ecompile_2eemitc_2eagainTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eagainTo_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eagainTo(V v_label_240, V v_ts_241, V v_ps_242, V v_vs_243) {
top: ;
  V v_t_244 = (g_list_2ezipWith_24s1876717925x1404326288(v_ts_241, heff_dup(v_vs_243)));
  V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_243));
  V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
  V v_t_247 = (g_list_2ezipWith_24s1877091673x1588480570(((V)&g_heff_2ecompile_2eemitc_2eagainTo_str0), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str1), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str2), v_t_244, v_t_246));
  V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eagainTo_str3), heff_strAppend(v_label_240, ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str4)));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_vs_243); r_; });
  V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
  V v_t_2412 = (g_prelude_2e_2b_2b_24f1727312714x1365290191(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str5), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str6), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str7), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str8), v_ps_242, v_t_2411));
  return (g_prelude_2e_2b_2b(v_t_247, v_t_2412));
}
V g_heff_2ecompile_2eemitc_2eagainTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eagainTo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eemitc_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eelemI_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_i_240, v_j_242, 0)) {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eelemI(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eplusDone_24cpr_str0, 9, "(q, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eplusDone_24cpr_str1, 22, "(q, k) : heff_perform_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eplusDone_24cpr_str2, 120, "(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l \? heff_perform_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eplusDone_24cpr_str3, 22, "static V heff_perform_");

HeffT2 g_heff_2ecompile_2eemitc_2eplusDone_24cpr(V v_n_240, V v_la_241, V v_na_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_lb_244 = heff_field(v_x4_243, 0);
    V v_nb_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_intShow(heff_intAdd(heff_dup(v_n_240), MK_INT(1LL)));
    V v_t_247 = heff_strAppend(heff_intShow(v_na_242), ((V)&g_heff_2ecompile_2eemitc_2eplusDone_24cpr_str0));
    V v_t_248 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eplusDone_24cpr_str1), v_t_247));
    V v_t_249 = heff_strAppend(heff_intShow(v_n_240), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eplusDone_24cpr_str2), v_t_248));
    V v_t_2410 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eplusDone_24cpr_str3), v_t_249), NTAG(TAG_Nil)});
    V v_t_2411 = (g_prelude_2e_2b_2b(v_lb_244, v_t_2410));
    V v_f_2412 = (g_prelude_2e_2b_2b(v_la_241, v_t_2411));
    return ((HeffT2){{v_f_2412, v_nb_245}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
Clo g_heff_2ecompile_2eemitc_2eperformNodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eperformNodes_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eperformNodes(V v_x1_240, V v_n_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(v_x1_240, v_n_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2eemitc_2eperformNodes_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eperformNodes(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemitc_2eletGoIndexGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eletGoIndexGo_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eletGoIndexGo(V v_i_240, V v_x2_241, V v_t_242, V v_r_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_t2_246 = heff_field(v_x21_244, 0);
      V v_r2_247 = heff_field(v_x21_244, 1);
      if (heff_strEq_c_lent(v_t_242, v_t2_246, 0)) {
        if (heff_strEq_c_lent(v_r_243, v_r2_247, 0)) {
          return v_i_240;
        } else {
          V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
          V t_1 = v_rest_245;
          V t_2 = v_t_242;
          V t_3 = v_r_243;
          v_i_240 = t_0;
          v_x2_241 = t_1;
          v_t_242 = t_2;
          v_r_243 = t_3;
          goto top;
        }
      } else {
        V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
        V t_1 = v_rest_245;
        V t_2 = v_t_242;
        V t_3 = v_r_243;
        v_i_240 = t_0;
        v_x2_241 = t_1;
        v_t_242 = t_2;
        v_r_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eletGoIndexGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2eletGoIndexGo(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2enulLines_str0, 43, "`: a string with a NUL in it, given to C\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enulLines_str1, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enulLines_str2, 12, "      r = 0;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enulLines_str3, 17, "      heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enulLines_str4, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enulLines_str5, 5, "_left");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enulLines_str6, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enulLines_str7, 9, "(EINVAL);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enulLines_str8, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enulLines_str9, 5, "_left");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enulLines_str10, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enulLines_str11, 9, "(EINVAL);");
Clo g_heff_2ecompile_2eemitc_2enulLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enulLines_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2enulLines(V v_md_240, V v_leaf_241, V v_b_242) {
top: ;
  V v_t_243 = heff_take_field(v_b_242, 3);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Gives: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_leaf_241);
    V v_t_245 = heff_strAppend(heff_get_n(v_b_242, 0, 5), ((V)&g_heff_2ecompile_2eemitc_2enulLines_str0));
    V v_t_246 = heff_strAppend(v_md_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enulLines_str1), v_t_245));
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2enulLines_str2), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enulLines_str3), v_t_246), v_t_247});
  }
  case TAG_GivesOrErrno: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_md_240);
    heff_drop_rec(v_b_242, 5);
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enulLines_str4), heff_strAppend(v_leaf_241, ((V)&g_heff_2ecompile_2eemitc_2enulLines_str5)));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enulLines_str6), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2enulLines_str7)));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  case TAG_DoneOrErrno: {
    heff_drop(v_md_240);
    heff_drop_rec(v_b_242, 5);
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enulLines_str8), heff_strAppend(v_leaf_241, ((V)&g_heff_2ecompile_2eemitc_2enulLines_str9)));
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enulLines_str10), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2enulLines_str11)));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2eemitc_2enulLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2enulLines(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str0, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str1, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str3, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str5, 4, "); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str6, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str7, 42, "_entry(V self, V *a) { (void)self; return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str8, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str9, 8, "_entry, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str10, 38, "_clo = {{0x80000000u, K_CLO, 0}, prim_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str11, 16, "static Clo prim_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str12, 14, "static V prim_");
Clo g_heff_2ecompile_2eemitc_2eprimCloDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprimCloDef_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eprimCloDef(V v_p_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2eprims_2eprimArityGo_24cpr(v_p_240, heff_dup(g_heff_2ecompile_2eprims_2eallPrims_get())));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_n_245 = v_field_243;
      V v_x2_246 = (g_list_2emap_24f1293205645x619162872(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str0), ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str1), MK_INT(0LL), heff_intSub(heff_dup(v_n_245), MK_INT(1LL))));
      V v_t_249;
      switch (heff_tag_of(v_x2_246)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_xs_248 = heff_field(v_x2_246, 1);
        heff_take_n(v_x2_246, 3ULL, 2);
        v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str3); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
        break;
      }
      default: heff_nomatch(v_x2_246);
      }
      V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str4), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str5)));
      V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str6), heff_dup(v_p_240)), v_t_2410);
      V v_t_2412 = heff_strAppend(heff_dup(v_p_240), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str7), v_t_2411));
      V v_t_2413 = heff_strAppend(heff_intShow(v_n_245), ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str8));
      V v_t_2414 = heff_strAppend(heff_dup(v_p_240), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str9), v_t_2413));
      V v_t_2415 = heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str10), v_t_2414));
      V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str11), v_t_2415), NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str12), v_t_2412), v_t_2416});
    } else {
      heff_drop(v_p_240);
      heff_drop(v_field_243);
      return NTAG(TAG_Nil);
    }
  }
}
V g_heff_2ecompile_2eemitc_2eprimCloDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprimCloDef(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str0, 2, "__");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str1, 2, "__");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str2, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str5, 6, "[] = {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str6, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str7, 22, "static uint32_t shape_");
Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eshapeDef_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eshapeDef(V v_key_240) {
top: ;
  V v_t_241 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str0); V a_1 = v_key_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str1), v_key_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_x2_242 = (g_list_2emap_24f583754813x1054900711(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str2), MK_INT(0LL), v_t_241));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str4); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str5), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str6)));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str7), heff_strAppend(v_key_240, v_t_246));
}
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eshapeDef(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str0, 64, "static V heff_perform(V p, V k) { return heff_perform_0(p, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str2, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str3, 9, "_get(); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str5, 35, "static V heff_entry(void) { return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str6, 0, "");
Clo g_heff_2ecompile_2eemitc_2erunEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2erunEnd_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2erunEnd(V v_eff_240, V v_ce_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(v_eff_240, MK_INT(0LL)));
  V v_t_247;
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_x_245 = v_field_243;
    V v_y_246 = v_field_244;
    heff_drop(v_y_246);
    v_t_247 = v_x_245;
  }
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str0), NTAG(TAG_Nil)});
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_247, v_t_248));
  V v_t_2410 = ({ V b_0 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2erunEnd_str1); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
  V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erunEnd_str2), v_t_2410), ((V)&g_heff_2ecompile_2eemitc_2erunEnd_str3));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str4), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erunEnd_str5), v_t_2411), v_t_2412});
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str6), v_t_2413}));
}
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2erunEnd(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeH_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeH_str1, 1, ",");
Clo g_heff_2ecompile_2eemitc_2eshapeH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eshapeH_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eshapeH(V v_ce_240, V v_sh_241, V v_rest_242) {
top: ;
  V v_t_243 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 7, 10);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_sh_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_249;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_246;
      v_t_249 = v_x_248;
    } else {
      heff_drop(v_field_246);
      v_t_249 = NTAG(TAG_Nil);
    }
  }
  V v_x2_2410 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_249));
  V v_t_2413;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eshapeH_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take_n(v_x2_2410, 3ULL, 2);
    v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeH_str1); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2413}), v_rest_242});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_sh_241}), v_t_2414});
}
V g_heff_2ecompile_2eemitc_2eshapeH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eshapeH(a[0], a[1], a[2]);
}