// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Leaf 13717
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_Plus 9189
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define LBL_exp 310423
#define LBL_lams 9809570
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_op 10312
#define LBL_owner 307523277
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
V g_heff_2ecompile_2eemitc_2ecallBound(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallBound_clo;
V g_heff_2ecompile_2eemitc_2ecallHead(V, V, V);
V g_heff_2ecompile_2eemitc_2ecallHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallHead_clo;
V g_heff_2ecompile_2eemitc_2eelemI(V, V);
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemI_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efloatSymbols_get(void);
V g_heff_2ecompile_2eemitc_2eisAlnum(V);
V g_heff_2ecompile_2eemitc_2eisAlnum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eisAlnum_clo;
V g_heff_2ecompile_2eemitc_2elamC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamC_clo;
V g_heff_2ecompile_2eemitc_2elamLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamLines_clo;
V g_heff_2ecompile_2eemitc_2emangleChar(V);
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleChar_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2enewLam(V);
V g_heff_2ecompile_2eemitc_2enewLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enewLam_clo;
V g_heff_2ecompile_2eemitc_2epartsMost_get(void);
V g_heff_2ecompile_2eemitc_2eperformNodes(V, V);
V g_heff_2ecompile_2eemitc_2eperformNodes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eperformNodes_clo;
V g_heff_2ecompile_2eemitc_2eplusDone(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eplusDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eplusDone_clo;
V g_heff_2ecompile_2eemitc_2eprimCloDef(V);
V g_heff_2ecompile_2eemitc_2eprimCloDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimCloDef_clo;
V g_heff_2ecompile_2eemitc_2erelSymbol(V, V);
V g_heff_2ecompile_2eemitc_2erelSymbol_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erelSymbol_clo;
V g_heff_2ecompile_2eemitc_2erunEnd(V, V);
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erunEnd_clo;
V g_heff_2ecompile_2eemitc_2eshapeDef(V);
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo;
V g_heff_2ecompile_2eemitc_2eslotFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo;
V g_heff_2ecompile_2eemitc_2etraverseC(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
V g_heff_2ecompile_2eprims_2eprimArityGo(V, V);
V g_heff_2ecompile_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eprimArityGo_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1483820613x1826490246(V, V);
V g_list_2efoldl_24s1483820613x1826490246_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1483820613x1826490246_clo;
V g_list_2efoldl_24s2138447488x1597606028(V, V);
V g_list_2efoldl_24s2138447488x1597606028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2138447488x1597606028_clo;
V g_list_2elookupBy(V, V, V);
V g_list_2elookupBy_entry(V self, V *a);
extern Clo g_list_2elookupBy_clo;
V g_list_2emap_24f1801471045x554404499(V, V, V, V);
V g_list_2emap_24f1801471045x554404499_entry(V self, V *a);
extern Clo g_list_2emap_24f1801471045x554404499_clo;
V g_list_2emap_24f2000583729x2114721175(V, V, V);
V g_list_2emap_24f2000583729x2114721175_entry(V self, V *a);
extern Clo g_list_2emap_24f2000583729x2114721175_clo;
V g_list_2emap_24s640776339x1223679834(V);
V g_list_2emap_24s640776339x1223679834_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_clo;
V g_map_2elookup_24s1338854231x236594845(V, V);
V g_map_2elookup_24s1338854231x236594845_entry(V self, V *a);
extern Clo g_map_2elookup_24s1338854231x236594845_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_strEq_get(void);
Clo g_heff_2ecompile_2eemitc_2emangleW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emangleW_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2emangleW(V v_s_240, V v_i_241, V v_j_242, V v_acc_243) {
top: ;
  V v_t_245;
  if (heff_intLt_c(heff_dup(v_j_242), heff_strLength(heff_dup(v_s_240)))) {
    v_t_245 = (g_heff_2ecompile_2eemitc_2eisAlnum(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_242))));
  } else {
    v_t_245 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V t_0 = v_s_240;
    V t_1 = v_i_241;
    V t_2 = heff_intAdd(v_j_242, MK_INT(1LL));
    V t_3 = v_acc_243;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_j_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  } else {
    heff_drop(v_t_245);
    if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_j_242))) {
      return heff_strAppend(v_acc_243, heff_strSlice(v_s_240, v_i_241, v_j_242));
    } else {
      V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleChar(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_242))));
      V v_t_248 = heff_strAppend(heff_strSlice(heff_dup(v_s_240), v_i_241, heff_dup(v_j_242)), v_t_247);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(heff_dup(v_j_242), MK_INT(1LL));
      V t_2 = heff_intAdd(v_j_242, MK_INT(1LL));
      V t_3 = heff_strAppend(v_acc_243, v_t_248);
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emangleW(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eslotFrom_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eslotFrom(V v_base_240, V v_m_241, V v_h_242, V v_taken_243) {
top: ;
  V v_x3_244 = (g_map_2elookup_24s1338854231x236594845(heff_intAdd(heff_dup(v_base_240), heff_dup(v_h_242)), v_taken_243));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    return heff_intAdd(v_base_240, v_h_242);
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    V v_t_246 = heff_intMod(heff_intAdd(v_h_242, MK_INT(1LL)), heff_dup(v_m_241));
    V t_0 = v_base_240;
    V t_1 = v_m_241;
    V t_2 = v_t_246;
    V t_3 = v_taken_243;
    v_base_240 = t_0;
    v_m_241 = t_1;
    v_h_242 = t_2;
    v_taken_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2eslotFrom(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2enewLam_str0, 4, "_lam");
Clo g_heff_2ecompile_2eemitc_2enewLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enewLam_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2enewLam(V v_s_240) {
top: ;
  V v_t_241 = heff_intShow(heff_dup(heff_rfield(v_s_240, 1)));
  V v_t_242 = heff_strAppend(heff_dup(heff_rfield(v_s_240, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enewLam_str0), v_t_241));
  V v_t_243 = heff_intAdd(heff_take_field(v_s_240, 1), MK_INT(1LL));
  V v_t_244 = ({ V rv_1 = v_t_243; V rr_ = heff_rec_reuse_nf(v_s_240, 253ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_t_244});
}
V g_heff_2ecompile_2eemitc_2enewLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2enewLam(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str1, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str2, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str3, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str4, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str6, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str7, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str8, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str9, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str10, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str11, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erelSymbol_str20, 0, "");
Clo g_heff_2ecompile_2eemitc_2erelSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2erelSymbol_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2erelSymbol(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_x2_242 = ({ V a_0 = heff_dup(g_strEq_get()); V a_1 = v_p_240; V b_2 = heff_dup(g_heff_2ecompile_2eemitc_2efloatSymbols_get()); V r_ = (g_list_2elookupBy(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str0);
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x2_242, 0);
      heff_take_n(v_x2_242, 1ULL, 1);
      return v_x_243;
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  case TAG_Just: {
    V v_fp_244 = heff_field(v_x2_241, 0);
    heff_drop(v_p_240);
    V v_t_245 = heff_dup(heff_rfield(v_fp_244, 1));
    switch (heff_tag_of(v_t_245)) {
    case TAG_OpAdd: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str1);
    }
    case TAG_OpSub: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str2);
    }
    case TAG_OpMul: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str3);
    }
    case TAG_OpDiv: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str4);
    }
    case TAG_OpRem: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str5);
    }
    case TAG_OpEq: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str6);
    }
    case TAG_OpLt: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str7);
    }
    case TAG_OpLe: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str8);
    }
    case TAG_OpAnd: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str9);
    }
    case TAG_OpOr: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str10);
    }
    case TAG_OpXor: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str11);
    }
    case TAG_OpShl: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str12);
    }
    case TAG_OpShr: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str13);
    }
    case TAG_OpShow: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str14);
    }
    case TAG_OpFromInt: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str15);
    }
    case TAG_OpToInt: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str16);
    }
    case TAG_OpSqrt: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str17);
    }
    case TAG_OpFromFloat: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str18);
    }
    case TAG_OpToFloat: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str19);
    }
    case TAG_OpFloor: {
      return ((V)&g_heff_2ecompile_2eemitc_2erelSymbol_str20);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2erelSymbol_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2erelSymbol(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str1, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str2, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str3, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str8, 4, ")); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str9, 7, " r_; })");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str10, 6, " r_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str11, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str12, 3, "({ ");
Clo g_heff_2ecompile_2eemitc_2ecallBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallBound_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2ecallBound(V v_g_240, V v_tr_241, V v_w_242, V v_bs_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_bs_243)));
  V v_x2_245 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1483820613x1826490246(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str1); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_x1_2410;
  switch (heff_tag_of(v_w_242)) {
  case TAG_Nothing: {
    v_x1_2410 = NTAG(TAG_RepV);
    break;
  }
  case TAG_Just: {
    V v_r_249 = heff_field(v_w_242, 0);
    v_x1_2410 = heff_dup(v_r_249);
    break;
  }
  default: heff_nomatch(v_w_242);
  }
  V v_t_2412;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_RepV: {
    v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str2);
    break;
  }
  case TAG_RepFix: {
    V v_w_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2412 = ({ V a_0 = v_w_2411; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2411); r_; });
    break;
  }
  case TAG_RepF64: {
    v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str3);
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  V v_t_2413 = (g_heff_2ecompile_2eemitc_2ecallHead(v_g_240, v_tr_241, v_w_242));
  V v_x2_2414 = (g_list_2emap_24s640776339x1223679834(heff_dup(v_bs_243)));
  V v_t_2417;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nil: {
    v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_xs_2416 = heff_field(v_x2_2414, 1);
    heff_take_n(v_x2_2414, 3ULL, 2);
    v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str5); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_243));
  V v_x2_2419 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s2138447488x1597606028(a_0, a_1)); heff_drop(v_t_2418); r_; });
  V v_t_2422;
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nil: {
    v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_xs_2421 = heff_field(v_x2_2419, 1);
    heff_take_n(v_x2_2419, 3ULL, 2);
    v_t_2422 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str7); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2419);
  }
  V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str8), heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str9)));
  V v_t_2424 = heff_strAppend(v_t_2413, heff_strAppend(v_t_2417, v_t_2423));
  V v_t_2425 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str10), v_t_2424));
  V v_t_2426 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str11), v_t_2425));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str12), v_t_2426);
}
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2ecallBound(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str0, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str2, 33, "_clo = {{0x80000000u, K_CLO, 0}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str3, 30, "(V self, V *args); static Clo ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str4, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str5, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str6, 18, "(V self, V *args);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str8, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str9, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str10, 5, "_clo)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str11, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str13, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str14, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str15, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str16, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str17, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str18, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str19, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str20, 11, "heff_clo_n(");
Clo g_heff_2ecompile_2eemitc_2elamC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elamC_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2elamC(V v_k_240, V v_xs_241, V v_fv_242, V v_held_243, V v_body_244, V v_s_245) {
top: ;
  V v_x2_246 = (g_heff_2ecompile_2eemitc_2enewLam(v_s_245));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = heff_tr(heff_call(heff_take_field(v_k_240, 1), 1, (V[]){v_body_244}));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      V v_n_2413 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_2420;
      switch (heff_tag_of(v_fv_242)) {
      case TAG_Nil: {
        V v_t_2414 = heff_strAppend(heff_intShow(v_n_2413), ((V)&g_heff_2ecompile_2eemitc_2elamC_str0));
        V v_t_2415 = heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str1), v_t_2414));
        V v_t_2416 = heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str2), v_t_2415));
        V v_t_2417 = heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str3), v_t_2416));
        v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str4), v_t_2417);
        break;
      }
      case TAG_Cons: {
        heff_drop(v_n_2413);
        v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str5), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2ecompile_2eemitc_2elamC_str6)));
        break;
      }
      default: heff_nomatch(v_fv_242);
      }
      V v_x2_2421 = (g_heff_2ecompile_2eemitc_2elamLines(heff_dup(v_x_247), heff_dup(v_xs_241), heff_dup(v_fv_242), v_x_2411));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str8); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      V v_m_2425 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_held_243));
      V v_t_2426 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_2412, 0)), v_t_2424});
      V v_t_2427 = heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_t_2426, heff_dup(heff_rfield(v_s_2412, 2))});
      V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_2412, 0)), v_t_2420});
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, heff_take_field(v_s_2412, 3)});
      V v_t_2430 = ({ V rv_2 = v_t_2427; V rv_3 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_s_2412, 243ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 65295u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_x2_2431 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_t_2430}));
      switch (heff_tag_of(v_x2_2431)) {
      case TAG_MkPair: {
        V v_x_2432 = heff_field(v_x2_2431, 0);
        V v_s_2433 = heff_field(v_x2_2431, 1);
        V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
        V v_t_2436;
        switch (heff_tag_of(v_fv_242)) {
        case TAG_Nil: {
          v_t_2436 = NTAG(TAG_True);
          break;
        }
        case TAG_Cons: {
          v_t_2436 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_fv_242);
        }
        V v_x_2449;
        if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
          heff_drop(v_xs_241);
          heff_drop(v_fv_242);
          heff_drop(v_x_2432);
          heff_drop(v_t_2436);
          v_x_2449 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str9), heff_strAppend(v_x_247, ((V)&g_heff_2ecompile_2eemitc_2elamC_str10)));
        } else {
          heff_drop(v_t_2436);
          V v_t_2437 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
          V v_t_2438 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fv_242; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_fv_242); r_; });
          V v_t_2444;
          switch (heff_tag_of(v_x_2432)) {
          case TAG_Nil: {
            v_t_2444 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str11);
            break;
          }
          case TAG_Cons: {
            V v_t_2443;
            switch (heff_tag_of(v_x_2432)) {
            case TAG_Nil: {
              v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str12);
              break;
            }
            case TAG_Cons: {
              V v_x_2441 = heff_field(v_x_2432, 0);
              V v_xs_2442 = heff_field(v_x_2432, 1);
              heff_take_n(v_x_2432, 3ULL, 2);
              v_t_2443 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str13); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
              break;
            }
            default: heff_nomatch(v_x_2432);
            }
            v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str14), heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2eemitc_2elamC_str15)));
            break;
          }
          default: heff_nomatch(v_x_2432);
          }
          V v_t_2445 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str16), heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eemitc_2elamC_str17)));
          V v_t_2446 = heff_strAppend(heff_intShow(v_t_2438), v_t_2445);
          V v_t_2447 = heff_strAppend(heff_intShow(v_t_2437), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str18), v_t_2446));
          V v_t_2448 = heff_strAppend(v_x_247, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str19), v_t_2447));
          v_x_2449 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str20), v_t_2448);
        }
        return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){v_x_2449, v_s_2433});
      }
      default: return heff_nomatch(v_x2_2431);
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2elamC(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2eemitc_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eelemI_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_i_240), heff_dup(v_j_242))) {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eelemI(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_str1, 34, "(V p, V k) { return heff_provider_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_str2, 9, "(p, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_str3, 22, "static V heff_perform_");
Clo g_heff_2ecompile_2eemitc_2eperformNodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eperformNodes_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eperformNodes(V v_x1_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_t_243 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_str0), heff_dup(v_k_242), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_244 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_t_243; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_243); r_; });
    V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_str1), heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_str2)));
    V v_t_246 = heff_strAppend(heff_intShow(heff_dup(v_n_241)), v_t_245);
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_str3), v_t_246), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, heff_intAdd(v_n_241, MK_INT(1LL))});
  }
  case TAG_Plus: {
    V v_a_248 = heff_field(v_x1_240, 0);
    V v_b_249 = heff_field(v_x1_240, 1);
    V v_x4_2410 = (g_heff_2ecompile_2eemitc_2eperformNodes(v_a_248, heff_intAdd(heff_dup(v_n_241), MK_INT(1LL))));
    switch (heff_tag_of(v_x4_2410)) {
    case TAG_MkPair: {
      V v_la_2411 = heff_field(v_x4_2410, 0);
      V v_na_2412 = heff_field(v_x4_2410, 1);
      heff_take_n(v_x4_2410, 3ULL, 2);
      V v_t_2413 = (g_heff_2ecompile_2eemitc_2eperformNodes(v_b_249, heff_dup(v_na_2412)));
      return (g_heff_2ecompile_2eemitc_2eplusDone(v_n_241, v_la_2411, v_na_2412, v_t_2413));
    }
    default: return heff_nomatch(v_x4_2410);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2eperformNodes_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eperformNodes(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str0, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str1, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str3, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str5, 4, "); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str6, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str7, 42, "_entry(V self, V *a) { (void)self; return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str8, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str9, 8, "_entry, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str10, 38, "_clo = {{0x80000000u, K_CLO, 0}, prim_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str11, 16, "static Clo prim_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimCloDef_str12, 14, "static V prim_");
Clo g_heff_2ecompile_2eemitc_2eprimCloDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprimCloDef_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eprimCloDef(V v_p_240) {
top: ;
  V v_t_241 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2ecompile_2eprims_2eallPrims_get()); V r_ = (g_heff_2ecompile_2eprims_2eprimArityGo(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_n_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_x2_243 = (g_list_2emap_24f1801471045x554404499(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str0), ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str1), MK_INT(0LL), heff_intSub(heff_dup(v_n_242), MK_INT(1LL))));
    V v_t_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str3); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str4), heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str5)));
    V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str6), heff_dup(v_p_240)), v_t_247);
    V v_t_249 = heff_strAppend(heff_dup(v_p_240), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str7), v_t_248));
    V v_t_2410 = heff_strAppend(heff_intShow(v_n_242), ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str8));
    V v_t_2411 = heff_strAppend(heff_dup(v_p_240), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str9), v_t_2410));
    V v_t_2412 = heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str10), v_t_2411));
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str11), v_t_2412), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str12), v_t_249), v_t_2413});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eemitc_2eprimCloDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprimCloDef(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str0, 2, "__");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str1, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str3, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str4, 6, "[] = {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str5, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeDef_str6, 22, "static uint32_t shape_");
Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eshapeDef_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eshapeDef(V v_key_240) {
top: ;
  V v_t_241 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str0), heff_dup(v_key_240), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_x2_242 = (g_list_2emap_24f2000583729x2114721175(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str1), MK_INT(0LL), v_t_241));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str3); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str4), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str5)));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str6), heff_strAppend(v_key_240, v_t_246));
}
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eshapeDef(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str0, 64, "static V heff_perform(V p, V k) { return heff_perform_0(p, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str2, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str3, 9, "_get(); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str5, 35, "static V heff_entry(void) { return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str6, 0, "");
Clo g_heff_2ecompile_2eemitc_2erunEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2erunEnd_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2erunEnd(V v_eff_240, V v_ce_241) {
top: ;
  V v_x1_242 = (g_heff_2ecompile_2eemitc_2eperformNodes(v_eff_240, MK_INT(0LL)));
  V v_t_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    v_t_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str0), NTAG(TAG_Nil)});
  V v_t_247 = (g_prelude_2e_2b_2b(v_t_245, v_t_246));
  V v_t_248 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2erunEnd_str1)));
  V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erunEnd_str2), v_t_248), ((V)&g_heff_2ecompile_2eemitc_2erunEnd_str3));
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str4), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erunEnd_str5), v_t_249), v_t_2410});
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str6), v_t_2411}));
}
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2erunEnd(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

static V g_heff_2ecompile_2eemitc_2epartsMost_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2epartsMost_st;
static V g_heff_2ecompile_2eemitc_2epartsMost_init(void) {
  return MK_INT(64LL);
}
V g_heff_2ecompile_2eemitc_2epartsMost_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2epartsMost_st)) return g_heff_2ecompile_2eemitc_2epartsMost_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2epartsMost_val, &g_heff_2ecompile_2eemitc_2epartsMost_st, g_heff_2ecompile_2eemitc_2epartsMost_init);
}