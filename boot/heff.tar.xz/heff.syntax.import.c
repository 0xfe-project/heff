// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_alias 294261354
#define LBL_end 310101
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_name 9869138
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
static uint32_t shape_imports__implicit__text[] = {LBL_imports, LBL_implicit, LBL_text};
static uint32_t shape_name__alias__span[] = {LBL_name, LBL_alias, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(V, V);
V g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_clo;
V g_heff_2esyntax_2eimport_2ehasDot(V, V);
V g_heff_2esyntax_2eimport_2ehasDot_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2ehasDot_clo;
V g_heff_2esyntax_2eimport_2eimplicitImports_get(void);
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportOf(V, V, V);
V g_heff_2esyntax_2eimport_2eimportOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportOf_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2eisAlias(V);
V g_heff_2esyntax_2eimport_2eisAlias_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eisAlias_clo;
V g_heff_2esyntax_2eimport_2elineEndAt(V, V);
V g_heff_2esyntax_2eimport_2elineEndAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2elineEndAt_clo;
V g_heff_2esyntax_2eimport_2enameChar(V);
V g_heff_2esyntax_2eimport_2enameChar_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2enameChar_clo;
V g_heff_2esyntax_2eimport_2erenameTo(V, V);
V g_heff_2esyntax_2eimport_2erenameTo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenameTo_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_heff_2esyntax_2eimport_2espaces(V);
V g_heff_2esyntax_2eimport_2espaces_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2espaces_clo;
V g_heff_2esyntax_2eimport_2espaces_24acc(V, V);
V g_heff_2esyntax_2eimport_2espaces_24acc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2espaces_24acc_clo;
V g_heff_2esyntax_2eimport_2etrimEnd(V);
V g_heff_2esyntax_2eimport_2etrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2etrimEnd_clo;
V g_heff_2esyntax_2eimport_2etrimStart(V);
V g_heff_2esyntax_2eimport_2etrimStart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2etrimStart_clo;
V g_heff_2esyntax_2eimport_2ewordsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2ewordsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2ewordsGo_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s776002836x391891384(V, V);
V g_list_2efoldl_24s776002836x391891384_entry(V self, V *a);
extern Clo g_list_2efoldl_24s776002836x391891384_clo;
V g_list_2efoldl_24s947555161x768980202(V, V);
V g_list_2efoldl_24s947555161x768980202_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947555161x768980202_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2esyntax_2eimport_2enameChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2enameChar_entry, 1, 0};

V g_heff_2esyntax_2eimport_2enameChar(V v_c_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(v_c_240), MK_INT(46LL)) || (heff_intEq_c(heff_dup(v_c_240), MK_INT(95LL)) || (heff_intEq_c(heff_dup(v_c_240), MK_INT(45LL)) || (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(122LL)) || (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL))))) : (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))))))));
  heff_drop(v_c_240);
  return v_ret_24bool;
}
V g_heff_2esyntax_2eimport_2enameChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2enameChar(a[0]);
}
Clo g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_entry, 2, 0};

V g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_True);
  } else {
    V v_t_243 = (g_heff_2esyntax_2eimport_2enameChar(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(a[0], a[1]);
}
Clo g_heff_2esyntax_2eimport_2ehasDot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2ehasDot_entry, 2, 0};

V g_heff_2esyntax_2eimport_2ehasDot(V v_x_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_x_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    return NTAG(TAG_False);
  } else {
    if (heff_intEq_c(heff_strByteAt_lent(v_x_240, v_i_241, 0), MK_INT(46LL))) {
      heff_drop(v_x_240);
      heff_drop(v_i_241);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2eimport_2ehasDot_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2ehasDot(a[0], a[1]);
}
Clo g_heff_2esyntax_2eimport_2eisAlias_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eisAlias_entry, 1, 0};

V g_heff_2esyntax_2eimport_2eisAlias(V v_x_240) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_x_240, 0))) {
    if (heff_intLe_c(MK_INT(65LL), heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) {
      if (heff_intLe_c(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2), MK_INT(90LL))) {
        V v_x1_244 = (g_heff_2esyntax_2eimport_2ehasDot(heff_dup(v_x_240), MK_INT(0LL)));
        if ((heff_dup(v_x1_244) == NTAG(TAG_True))) {
          heff_drop(v_x_240);
          heff_drop(v_x1_244);
          return NTAG(TAG_False);
        } else {
          heff_drop(v_x1_244);
          if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_x_240, 0))) {
            return (g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(v_x_240, MK_INT(0LL)));
          } else {
            heff_drop(v_x_240);
            return NTAG(TAG_False);
          }
        }
      } else {
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2eimport_2eisAlias_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2eisAlias(a[0]);
}
Clo g_heff_2esyntax_2eimport_2elineEndAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2elineEndAt_entry, 2, 0};

V g_heff_2esyntax_2eimport_2elineEndAt(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return heff_strLength(v_src_240);
  } else {
    if (heff_intEq_c(heff_strByteAt_lent(v_src_240, v_i_241, 0), MK_INT(10LL))) {
      heff_drop(v_src_240);
      return v_i_241;
    } else {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2eimport_2elineEndAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2elineEndAt(a[0], a[1]);
}
Clo g_heff_2esyntax_2eimport_2etrimEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2etrimEnd_entry, 1, 0};

V g_heff_2esyntax_2eimport_2etrimEnd(V v_s_240) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_s_240, 0))) {
    V v_t_242 = heff_intSub(heff_strLength_lent(v_s_240, 0), MK_INT(1LL));
    if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_t_242, 2), MK_INT(32LL))) {
      V v_t_244 = heff_intSub(heff_strLength_lent(v_s_240, 0), MK_INT(1LL));
      V t_0 = heff_strSlice(v_s_240, MK_INT(0LL), v_t_244);
      v_s_240 = t_0;
      goto top;
    } else {
      return v_s_240;
    }
  } else {
    return v_s_240;
  }
}
V g_heff_2esyntax_2eimport_2etrimEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2etrimEnd(a[0]);
}
Clo g_heff_2esyntax_2eimport_2etrimStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2etrimStart_entry, 1, 0};

V g_heff_2esyntax_2eimport_2etrimStart(V v_s_240) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_s_240, 0))) {
    if (heff_intEq_c(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2), MK_INT(32LL))) {
      V v_t_243 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength(v_s_240));
      V t_0 = v_t_243;
      v_s_240 = t_0;
      goto top;
    } else {
      return v_s_240;
    }
  } else {
    return v_s_240;
  }
}
V g_heff_2esyntax_2eimport_2etrimStart_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2etrimStart(a[0]);
}
Clo g_heff_2esyntax_2eimport_2ewordsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2ewordsGo_entry, 4, 0};

V g_heff_2esyntax_2eimport_2ewordsGo(V v_s_240, V v_start_241, V v_i_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_242))) {
    V v_t_246;
    if (heff_intLt_c(heff_dup(v_start_241), heff_dup(v_i_242))) {
      v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice(v_s_240, v_start_241, v_i_242), v_acc_243});
    } else {
      heff_drop(v_s_240);
      heff_drop(v_start_241);
      heff_drop(v_i_242);
      v_t_246 = v_acc_243;
    }
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_246));
  } else {
    if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_242, 0), MK_INT(32LL))) {
      V v_t_249;
      if (heff_intLt_c(heff_dup(v_start_241), heff_dup(v_i_242))) {
        v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_start_241, v_i_242, 2), v_acc_243});
      } else {
        heff_drop(v_start_241);
        v_t_249 = v_acc_243;
      }
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_t_249;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      V t_0 = v_s_240;
      V t_1 = v_start_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_acc_243;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2esyntax_2eimport_2ewordsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2ewordsGo(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2eimport_2espaces_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eimport_2espaces_str1, 1, " ");
Clo g_heff_2esyntax_2eimport_2espaces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2espaces_entry, 1, 0};

V g_heff_2esyntax_2eimport_2espaces(V v_n_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2esyntax_2eimport_2espaces_str0);
  } else {
    V v_s_242 = ((V)&g_heff_2esyntax_2eimport_2espaces_str1);
    return (g_heff_2esyntax_2eimport_2espaces_24acc(heff_intSub(v_n_240, MK_INT(1LL)), v_s_242));
  }
}
V g_heff_2esyntax_2eimport_2espaces_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2espaces(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2eimport_2espaces_24acc_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eimport_2espaces_24acc_str1, 1, " ");
Clo g_heff_2esyntax_2eimport_2espaces_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2espaces_24acc_entry, 2, 0};

V g_heff_2esyntax_2eimport_2espaces_24acc(V v_n_240, V v_acc_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return heff_strAppend(v_acc_241, ((V)&g_heff_2esyntax_2eimport_2espaces_24acc_str0));
  } else {
    V v_s_243 = heff_strAppend(v_acc_241, ((V)&g_heff_2esyntax_2eimport_2espaces_24acc_str1));
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_s_243;
    v_n_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
}
V g_heff_2esyntax_2eimport_2espaces_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2espaces_24acc(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportOf_str0, 2, "as");
Clo g_heff_2esyntax_2eimport_2eimportOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eimportOf_entry, 3, 0};

V g_heff_2esyntax_2eimport_2eimportOf(V v_i_240, V v_e_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_e_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_Nil: {
      if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_m_243, 0))) {
        V v_t_246 = (g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(heff_dup(v_m_243), MK_INT(0LL)));
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          V v_t_247 = heff_rec_n(3, shape_name__alias__span, (V[]){heff_dup(v_m_243), NTAG(TAG_Nothing), heff_rec_n(2, shape_start__end, (V[]){v_i_240, v_e_241})});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
        } else {
          heff_drop(v_i_240);
          heff_drop(v_e_241);
          heff_drop(v_t_246);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        return NTAG(TAG_Nothing);
      }
    }
    case TAG_Cons: {
      V v_x321_248 = heff_field(v_x32_244, 0);
      V v_x322_249 = heff_field(v_x32_244, 1);
      if (heff_strEq_c_lent(v_x321_248, ((V)&g_heff_2esyntax_2eimport_2eimportOf_str0), 2)) {
        switch (heff_tag_of(v_x322_249)) {
        case TAG_Nil: {
          heff_drop(v_i_240);
          heff_drop(v_e_241);
          return NTAG(TAG_Nothing);
        }
        case TAG_Cons: {
          V v_a_2411 = heff_field(v_x322_249, 0);
          V v_x3222_2412 = heff_field(v_x322_249, 1);
          switch (heff_tag_of(v_x3222_2412)) {
          case TAG_Nil: {
            if (heff_intLt_c(MK_INT(0LL), heff_strLength_lent(v_m_243, 0))) {
              V v_t_2414 = (g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(heff_dup(v_m_243), MK_INT(0LL)));
              if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
                heff_drop(v_t_2414);
                V v_t_2415 = (g_heff_2esyntax_2eimport_2eisAlias(heff_dup(v_a_2411)));
                if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
                  heff_drop(v_t_2415);
                  V v_t_2416 = heff_rec_n(3, shape_name__alias__span, (V[]){heff_dup(v_m_243), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_a_2411)}), heff_rec_n(2, shape_start__end, (V[]){v_i_240, v_e_241})});
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
                } else {
                  heff_drop(v_i_240);
                  heff_drop(v_e_241);
                  heff_drop(v_t_2415);
                  return NTAG(TAG_Nothing);
                }
              } else {
                heff_drop(v_i_240);
                heff_drop(v_e_241);
                heff_drop(v_t_2414);
                return NTAG(TAG_Nothing);
              }
            } else {
              heff_drop(v_i_240);
              heff_drop(v_e_241);
              return NTAG(TAG_Nothing);
            }
          }
          case TAG_Cons: {
            heff_drop(v_i_240);
            heff_drop(v_e_241);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_x3222_2412);
          }
        }
        default: return heff_nomatch(v_x322_249);
        }
      } else {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x32_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2eimport_2eimportOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2eimport_2eimportOf(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportsGo_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportsGo_str1, 2, "--");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportsGo_str2, 7, "import ");
Clo g_heff_2esyntax_2eimport_2eimportsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eimportsGo_entry, 3, 0};

V g_heff_2esyntax_2eimport_2eimportsGo(V v_src_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_acc_242)));
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    V v_t_246 = ({ V a_0 = v_src_240; V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s947555161x768980202(a_0, a_1)); heff_drop(v_t_245); r_; });
    return heff_rec_n(3, shape_imports__implicit__text, (V[]){v_t_244, NTAG(TAG_Nil), v_t_246});
  } else {
    V v_x_247 = (g_heff_2esyntax_2eimport_2elineEndAt(heff_dup(v_src_240), heff_dup(v_i_241)));
    V v_line_248 = heff_strSlice_lent(v_src_240, v_i_241, v_x_247, 0);
    V v_t_249 = (g_heff_2esyntax_2eimport_2etrimStart(heff_dup(v_line_248)));
    V v_x_2410 = (g_heff_2esyntax_2eimport_2etrimEnd(v_t_249));
    V v_t_2412 = heff_bool((heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2esyntax_2eimport_2eimportsGo_str0), 2) || heff_strEq_c(heff_strSlice_lent(v_x_2410, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2esyntax_2eimport_2eimportsGo_str1))));
    heff_drop(v_x_2410);
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_i_241);
      heff_drop(v_line_248);
      heff_drop(v_t_2412);
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_x_247, MK_INT(1LL));
      V t_2 = v_acc_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_2412);
      if (heff_strEq_c(heff_strSlice_lent(v_line_248, MK_INT(0LL), MK_INT(7LL), 6), ((V)&g_heff_2esyntax_2eimport_2eimportsGo_str2))) {
        V v_t_2414 = heff_strSlice(heff_dup(v_line_248), MK_INT(7LL), heff_strLength(v_line_248));
        V v_t_2415 = (g_heff_2esyntax_2eimport_2etrimStart(v_t_2414));
        V v_s_2416 = (g_heff_2esyntax_2eimport_2etrimEnd(v_t_2415));
        V v_t_2417 = (g_heff_2esyntax_2eimport_2ewordsGo(v_s_2416, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2418 = ({ V a_0 = v_i_241; V a_1 = heff_dup(v_x_247); V a_2 = v_t_2417; V r_ = (g_heff_2esyntax_2eimport_2eimportOf(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          heff_drop(v_x_247);
          V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_acc_242)));
          V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
          V v_t_2421 = ({ V a_0 = v_src_240; V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s947555161x768980202(a_0, a_1)); heff_drop(v_t_2420); r_; });
          return heff_rec_n(3, shape_imports__implicit__text, (V[]){v_t_2419, NTAG(TAG_Nil), v_t_2421});
        }
        case TAG_Just: {
          V v_imp_2422 = heff_field(v_t_2418, 0);
          heff_take_n(v_t_2418, 1ULL, 1);
          V t_0 = v_src_240;
          V t_1 = heff_intAdd(v_x_247, MK_INT(1LL));
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_imp_2422, v_acc_242});
          v_src_240 = t_0;
          v_i_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_t_2418);
        }
      } else {
        heff_drop(v_i_241);
        heff_drop(v_x_247);
        heff_drop(v_line_248);
        V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_acc_242)));
        V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
        V v_t_2425 = ({ V a_0 = v_src_240; V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24s947555161x768980202(a_0, a_1)); heff_drop(v_t_2424); r_; });
        return heff_rec_n(3, shape_imports__implicit__text, (V[]){v_t_2423, NTAG(TAG_Nil), v_t_2425});
      }
    }
  }
}
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2eimportsGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eimplicitImports_str0, 7, "builtin");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimplicitImports_str1, 7, "prelude");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimplicitImports_str2, 4, "list");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimplicitImports_str3, 4, "List");

static V g_heff_2esyntax_2eimport_2eimplicitImports_val;
static HEFF_ONCE g_heff_2esyntax_2eimport_2eimplicitImports_st;
static V g_heff_2esyntax_2eimport_2eimplicitImports_init(void) {
  V v_t_240 = heff_rec_n(3, shape_name__alias__span, (V[]){((V)&g_heff_2esyntax_2eimport_2eimplicitImports_str0), NTAG(TAG_Nothing), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  V v_t_241 = heff_rec_n(3, shape_name__alias__span, (V[]){((V)&g_heff_2esyntax_2eimport_2eimplicitImports_str1), NTAG(TAG_Nothing), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  V v_t_242 = heff_rec_n(3, shape_name__alias__span, (V[]){((V)&g_heff_2esyntax_2eimport_2eimplicitImports_str2), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2eimport_2eimplicitImports_str3)}), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_243})});
}
V g_heff_2esyntax_2eimport_2eimplicitImports_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2eimport_2eimplicitImports_st)) return g_heff_2esyntax_2eimport_2eimplicitImports_val;
  return heff_global(&g_heff_2esyntax_2eimport_2eimplicitImports_val, &g_heff_2esyntax_2eimport_2eimplicitImports_st, g_heff_2esyntax_2eimport_2eimplicitImports_init);
}

static V g_heff_2esyntax_2eimport_2eimplicitModules_val;
static HEFF_ONCE g_heff_2esyntax_2eimport_2eimplicitModules_st;
static V g_heff_2esyntax_2eimport_2eimplicitModules_init(void) {
  return (g_list_2emap_24s1817208647x1282894070(heff_dup(g_heff_2esyntax_2eimport_2eimplicitImports_get())));
}
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2eimport_2eimplicitModules_st)) return g_heff_2esyntax_2eimport_2eimplicitModules_val;
  return heff_global(&g_heff_2esyntax_2eimport_2eimplicitModules_val, &g_heff_2esyntax_2eimport_2eimplicitModules_st, g_heff_2esyntax_2eimport_2eimplicitModules_init);
}
Clo g_heff_2esyntax_2eimport_2eimportsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eimportsOf_entry, 2, 0};

V g_heff_2esyntax_2eimport_2eimportsOf(V v_ms_240, V v_src_241) {
top: ;
  V v_r_242 = (g_heff_2esyntax_2eimport_2eimportsGo(v_src_241, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ms_240)));
  V v_t_244 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s776002836x391891384(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, heff_take_field(v_r_242, 0)));
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_240));
  V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s776002836x391891384(a_0, a_1)); heff_drop(v_t_246); r_; });
  return ({ V rv_0 = v_t_245; V rv_1 = v_t_247; V rr_ = heff_rec_reuse_nf(v_r_242, 4ULL, 3, shape_imports__implicit__text, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2eimportsOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2eimport_2erenameTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2erenameTo_entry, 2, 0};

V g_heff_2esyntax_2eimport_2erenameTo(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_x_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_from_244 = heff_field(v_x11_242, 0);
      V v_to_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c_lent(v_from_244, v_x_241, 0)) {
        heff_drop(v_x_241);
        return heff_dup(v_to_245);
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2eimport_2erenameTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2erenameTo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2eimport_2erenamed_lam0(V self, V *args);
V g_heff_2esyntax_2eimport_2erenamed_lam1(V self, V *args);
Clo g_heff_2esyntax_2eimport_2erenamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2erenamed_entry, 2, 0};

V g_heff_2esyntax_2eimport_2erenamed(V v_rs_240, V v_imps_241) {
top: ;
  V v_t_244 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eimport_2erenamed_lam0, 1, 1, (V[]){heff_dup(v_rs_240)}), heff_take_field(v_imps_241, 0)));
  V v_t_247 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eimport_2erenamed_lam1, 1, 1, (V[]){heff_dup(v_rs_240)}), heff_take_field(v_imps_241, 1)));
  return ({ V rv_0 = v_t_244; V rv_1 = v_t_247; V rr_ = heff_rec_reuse_nf(v_imps_241, 4ULL, 3, shape_imports__implicit__text, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2erenamed(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2eimport_2erenamed_lam0(V self, V *args) {
  V v_i_242 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_name_243 = ({ V a_0 = v_rs_240; V a_1 = heff_take_field(v_i_242, 0); V r_ = (g_heff_2esyntax_2eimport_2erenameTo(a_0, a_1)); heff_drop(v_rs_240); r_; });
  return ({ V rv_0 = v_name_243; V rr_ = heff_rec_reuse_nf(v_i_242, 6ULL, 3, shape_name__alias__span, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
}
V g_heff_2esyntax_2eimport_2erenamed_lam1(V self, V *args) {
  V v_i_245 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_name_246 = ({ V a_0 = v_rs_240; V a_1 = heff_take_field(v_i_245, 0); V r_ = (g_heff_2esyntax_2eimport_2erenameTo(a_0, a_1)); heff_drop(v_rs_240); r_; });
  return ({ V rv_0 = v_name_246; V rr_ = heff_rec_reuse_nf(v_i_245, 6ULL, 3, shape_name__alias__span, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
}