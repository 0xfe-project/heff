// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_alias 294261354
#define LBL_claim 296100950
#define LBL_end 310101
#define LBL_error 298143266
#define LBL_exposes 1070285678
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_listed 844633320
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tags 10047712
#define LBL_text 10052084
static uint32_t shape_imports__implicit__claim__text[] = {LBL_imports, LBL_implicit, LBL_claim, LBL_text};
static uint32_t shape_name__alias__span[] = {LBL_name, LBL_alias, LBL_span};
static uint32_t shape_name__listed__exposes__span__error[] = {LBL_name, LBL_listed, LBL_exposes, LBL_span, LBL_error};
static uint32_t shape_name__tags__span[] = {LBL_name, LBL_tags, LBL_span};
static uint32_t shape_span__msg[] = {LBL_span, LBL_msg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(V, V);
V g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_clo;
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(V, V);
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_clo;
HeffT2 g_heff_2esyntax_2eimport_2eclaimAt_24cpr(V, V);
HeffT2 g_heff_2esyntax_2eimport_2eclaimListed_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2eimport_2eclaimNamed_24cpr(V, V, V, V);
V g_heff_2esyntax_2eimport_2eclaimSays_get(void);
V g_heff_2esyntax_2eimport_2eclaimThen(V, V, V, V, V);
V g_heff_2esyntax_2eimport_2eclaimThen_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eclaimThen_clo;
HeffT2 g_heff_2esyntax_2eimport_2ecloseOf_24cpr(V, V, V);
V g_heff_2esyntax_2eimport_2edoneI(V, V, V);
V g_heff_2esyntax_2eimport_2edoneI_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2edoneI_clo;
HeffT2 g_heff_2esyntax_2eimport_2eentriesGo_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2eimport_2eentryOf_24cpr(V, V);
V g_heff_2esyntax_2eimport_2ehasDot(V, V);
V g_heff_2esyntax_2eimport_2ehasDot_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2ehasDot_clo;
V g_heff_2esyntax_2eimport_2eidentChar(V);
V g_heff_2esyntax_2eimport_2eidentChar_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eidentChar_clo;
V g_heff_2esyntax_2eimport_2eimplicitImports_get(void);
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
HeffT2 g_heff_2esyntax_2eimport_2eimportOf_24cpr(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2eisAlias(V);
V g_heff_2esyntax_2eimport_2eisAlias_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eisAlias_clo;
V g_heff_2esyntax_2eimport_2eisIdent(V);
V g_heff_2esyntax_2eimport_2eisIdent_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eisIdent_clo;
V g_heff_2esyntax_2eimport_2elineEndAt(V, V);
V g_heff_2esyntax_2eimport_2elineEndAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2elineEndAt_clo;
V g_heff_2esyntax_2eimport_2enameChar(V);
V g_heff_2esyntax_2eimport_2enameChar_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2enameChar_clo;
V g_heff_2esyntax_2eimport_2enameEnd(V, V);
V g_heff_2esyntax_2eimport_2enameEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2enameEnd_clo;
HeffT2 g_heff_2esyntax_2eimport_2enameEntry_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2eimport_2eoperatorIn_24cpr(V);
V g_heff_2esyntax_2eimport_2epiecesGo(V, V, V, V, V, V);
V g_heff_2esyntax_2eimport_2epiecesGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2epiecesGo_clo;
V g_heff_2esyntax_2eimport_2erenameTo(V, V);
V g_heff_2esyntax_2eimport_2erenameTo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenameTo_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
V g_heff_2esyntax_2eimport_2eskipWhite(V, V, V);
V g_heff_2esyntax_2eimport_2eskipWhite_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eskipWhite_clo;
V g_heff_2esyntax_2eimport_2eskipWhiteBack(V, V, V);
V g_heff_2esyntax_2eimport_2eskipWhiteBack_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eskipWhiteBack_clo;
V g_heff_2esyntax_2eimport_2espaces(V);
V g_heff_2esyntax_2eimport_2espaces_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2espaces_clo;
V g_heff_2esyntax_2eimport_2espaces_24acc(V, V);
V g_heff_2esyntax_2eimport_2espaces_24acc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2espaces_24acc_clo;
V g_heff_2esyntax_2eimport_2etrimEnd(V);
V g_heff_2esyntax_2eimport_2etrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2etrimEnd_clo;
V g_heff_2esyntax_2eimport_2etrimStart(V);
V g_heff_2esyntax_2eimport_2etrimStart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2etrimStart_clo;
V g_heff_2esyntax_2eimport_2ewordsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2ewordsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2ewordsGo_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1644479985x1191070221(V, V);
V g_list_2efoldl_24s1644479985x1191070221_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1644479985x1191070221_clo;
V g_list_2efoldl_24s947555161x768980202(V, V);
V g_list_2efoldl_24s947555161x768980202_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947555161x768980202_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2esyntax_2eimport_2enameChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2enameChar_entry, 1, 0};

V g_heff_2esyntax_2eimport_2enameChar(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_ret_24bool = heff_bool(((v_c_240 == ((int64_t)46ULL)) || ((v_c_240 == ((int64_t)95ULL)) || ((v_c_240 == ((int64_t)45ULL)) || ((((int64_t)97ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)122ULL)) || ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))) : (heff_intLe_c(MK_INT(48LL), heff_box_word(v_c_240)) && heff_intLe_c(heff_box_word(v_c_240), MK_INT(57LL))))) : ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))) : ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))))))));
  return v_ret_24bool;
}
V g_heff_2esyntax_2eimport_2enameChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2enameChar(a[0]);
}
Clo g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_entry, 2, 0};

V g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return NTAG(TAG_True);
  } else {
    V v_t_243 = (g_heff_2esyntax_2eimport_2enameChar(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2eimport_2ehasDot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2ehasDot_entry, 2, 0};

V g_heff_2esyntax_2eimport_2ehasDot(V v_x_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) <= v_i_241)) {
    return NTAG(TAG_False);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_x_240, heff_box_word(v_i_241), 2)) == ((int64_t)46ULL))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_x_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2eimport_2ehasDot_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2ehasDot(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2eimport_2eisAlias_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eisAlias_entry, 1, 0};

V g_heff_2esyntax_2eimport_2eisAlias(V v_x_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
    if ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)90ULL))) {
        V v_x1_244 = (g_heff_2esyntax_2eimport_2ehasDot(v_x_240, MK_INT(0LL)));
        if ((heff_dup(v_x1_244) == NTAG(TAG_True))) {
          heff_drop(v_x1_244);
          return NTAG(TAG_False);
        } else {
          heff_drop(v_x1_244);
          if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
            return (g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(v_x_240, MK_INT(0LL)));
          } else {
            return NTAG(TAG_False);
          }
        }
      } else {
        return NTAG(TAG_False);
      }
    } else {
      return NTAG(TAG_False);
    }
  } else {
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2eimport_2eisAlias_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2eisAlias(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2eimport_2elineEndAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2elineEndAt_entry, 2, 0};

V g_heff_2esyntax_2eimport_2elineEndAt(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return heff_strLength_lent(v_src_240, 0);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)10ULL))) {
      return v_i_241;
    } else {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2eimport_2elineEndAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2elineEndAt(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2eimport_2etrimEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2etrimEnd_entry, 1, 0};

V g_heff_2esyntax_2eimport_2etrimEnd(V v_s_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_240, 0)))) {
    int64_t v_t_242 = (heff_unbox_word(heff_strLength_lent(v_s_240, 0)) - ((int64_t)1ULL));
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_t_242), 2)) == ((int64_t)32ULL))) {
      int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_s_240, 0)) - ((int64_t)1ULL));
      V t_0 = heff_strSlice(v_s_240, MK_INT(0LL), heff_box_word(v_t_244));
      v_s_240 = t_0;
      goto top;
    } else {
      return v_s_240;
    }
  } else {
    return v_s_240;
  }
}
V g_heff_2esyntax_2eimport_2etrimEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2etrimEnd(a[0]);
}
Clo g_heff_2esyntax_2eimport_2etrimStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2etrimStart_entry, 1, 0};

V g_heff_2esyntax_2eimport_2etrimStart(V v_s_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_240, 0)))) {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) == ((int64_t)32ULL))) {
      V v_t_243 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength(v_s_240));
      V t_0 = v_t_243;
      v_s_240 = t_0;
      goto top;
    } else {
      return v_s_240;
    }
  } else {
    return v_s_240;
  }
}
V g_heff_2esyntax_2eimport_2etrimStart_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2etrimStart(a[0]);
}
Clo g_heff_2esyntax_2eimport_2ewordsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2ewordsGo_entry, 4, 0};

V g_heff_2esyntax_2eimport_2ewordsGo(V v_s_240, V v_start_241, V v_box_24i_242, V v_acc_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_242)) {
    V v_t_246;
    if (heff_intLt_c_lent(v_start_241, heff_box_word(v_i_242), 2)) {
      v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_start_241, heff_box_word(v_i_242), 6), v_acc_243});
    } else {
      heff_drop(v_start_241);
      v_t_246 = v_acc_243;
    }
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_246));
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_242), 2)) == ((int64_t)32ULL))) {
      V v_t_249;
      if (heff_intLt_c_lent(v_start_241, heff_box_word(v_i_242), 2)) {
        v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_start_241, heff_box_word(v_i_242), 6), v_acc_243});
      } else {
        heff_drop(v_start_241);
        v_t_249 = v_acc_243;
      }
      V t_0 = v_s_240;
      V t_1 = heff_box_word((v_i_242 + ((int64_t)1ULL)));
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = v_t_249;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      V t_0 = v_s_240;
      V t_1 = v_start_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = v_acc_243;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2esyntax_2eimport_2ewordsGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2ewordsGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2eimport_2espaces_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eimport_2espaces_str1, 1, " ");
Clo g_heff_2esyntax_2eimport_2espaces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2espaces_entry, 1, 0};

V g_heff_2esyntax_2eimport_2espaces(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2esyntax_2eimport_2espaces_str0);
  } else {
    V v_s_242 = ((V)&g_heff_2esyntax_2eimport_2espaces_str1);
    return (g_heff_2esyntax_2eimport_2espaces_24acc(heff_intSub(v_n_240, MK_INT(1LL)), v_s_242));
  }
}
V g_heff_2esyntax_2eimport_2espaces_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2espaces(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2eimport_2espaces_24acc_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eimport_2espaces_24acc_str1, 1, " ");
Clo g_heff_2esyntax_2eimport_2espaces_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2espaces_24acc_entry, 2, 0};

V g_heff_2esyntax_2eimport_2espaces_24acc(V v_n_240, V v_acc_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return heff_strAppend(v_acc_241, ((V)&g_heff_2esyntax_2eimport_2espaces_24acc_str0));
  } else {
    V v_s_243 = heff_strAppend(v_acc_241, ((V)&g_heff_2esyntax_2eimport_2espaces_24acc_str1));
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_s_243;
    v_n_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
}
V g_heff_2esyntax_2eimport_2espaces_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2espaces_24acc(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportOf_24cpr_str0, 2, "as");

HeffT2 g_heff_2esyntax_2eimport_2eimportOf_24cpr(V v_i_240, V v_e_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_e_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_Nil: {
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_m_243, 0)))) {
        V v_t_246 = (g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(v_m_243, MK_INT(0LL)));
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          V v_t_247 = heff_rec_n(3, shape_name__alias__span, (V[]){v_m_243, NTAG(TAG_Nothing), heff_rec_n(2, shape_start__end, (V[]){v_i_240, v_e_241})});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_247}});
        } else {
          heff_drop(v_i_240);
          heff_drop(v_e_241);
          heff_drop(v_m_243);
          heff_drop(v_t_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        heff_drop(v_m_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_Cons: {
      V v_x321_248 = heff_field(v_x32_244, 0);
      V v_x322_249 = heff_field(v_x32_244, 1);
      heff_take_n(v_x32_244, 3ULL, 2);
      if (heff_strEq_c(v_x321_248, ((V)&g_heff_2esyntax_2eimport_2eimportOf_24cpr_str0))) {
        switch (heff_tag_of(v_x322_249)) {
        case TAG_Nil: {
          heff_drop(v_i_240);
          heff_drop(v_e_241);
          heff_drop(v_m_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_a_2411 = heff_field(v_x322_249, 0);
          V v_x3222_2412 = heff_field(v_x322_249, 1);
          heff_take_n(v_x322_249, 3ULL, 2);
          switch (heff_tag_of(v_x3222_2412)) {
          case TAG_Nil: {
            if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_m_243, 0)))) {
              V v_t_2414 = (g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(v_m_243, MK_INT(0LL)));
              if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
                heff_drop(v_t_2414);
                V v_t_2415 = (g_heff_2esyntax_2eimport_2eisAlias(v_a_2411));
                if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
                  heff_drop(v_t_2415);
                  V v_t_2416 = heff_rec_n(3, shape_name__alias__span, (V[]){v_m_243, heff_tag_n(TAG_Just, 1, (V[]){v_a_2411}), heff_rec_n(2, shape_start__end, (V[]){v_i_240, v_e_241})});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
                } else {
                  heff_drop(v_i_240);
                  heff_drop(v_e_241);
                  heff_drop(v_m_243);
                  heff_drop(v_a_2411);
                  heff_drop(v_t_2415);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              } else {
                heff_drop(v_i_240);
                heff_drop(v_e_241);
                heff_drop(v_m_243);
                heff_drop(v_a_2411);
                heff_drop(v_t_2414);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              heff_drop(v_i_240);
              heff_drop(v_e_241);
              heff_drop(v_m_243);
              heff_drop(v_a_2411);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          case TAG_Cons: {
            heff_take_n(v_x3222_2412, 0ULL, 2);
            heff_drop(v_i_240);
            heff_drop(v_e_241);
            heff_drop(v_m_243);
            heff_drop(v_a_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x3222_2412)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x322_249)}});
        }
      } else {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        heff_drop(v_m_243);
        heff_drop(v_x322_249);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x32_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2esyntax_2eimport_2eidentChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eidentChar_entry, 1, 0};

V g_heff_2esyntax_2eimport_2eidentChar(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_ret_24bool = heff_bool(((v_c_240 == ((int64_t)95ULL)) || ((v_c_240 == ((int64_t)39ULL)) || ((((int64_t)97ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)122ULL)) || ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))) : (heff_intLe_c(MK_INT(48LL), heff_box_word(v_c_240)) && heff_intLe_c(heff_box_word(v_c_240), MK_INT(57LL))))) : ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))) : ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL))))))));
  return v_ret_24bool;
}
V g_heff_2esyntax_2eimport_2eidentChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2eidentChar(a[0]);
}
Clo g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_entry, 2, 0};

V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return NTAG(TAG_True);
  } else {
    V v_t_243 = (g_heff_2esyntax_2eimport_2eidentChar(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2eimport_2eisIdent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eisIdent_entry, 1, 0};

V g_heff_2esyntax_2eimport_2eisIdent(V v_x_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
    if ((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)57ULL))) {
        return NTAG(TAG_False);
      } else {
        return (g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(v_x_240, MK_INT(0LL)));
      }
    } else {
      return (g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(v_x_240, MK_INT(0LL)));
    }
  } else {
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2eimport_2eisIdent_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2eisIdent(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2eimport_2eskipWhite_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eskipWhite_entry, 3, 0};

V g_heff_2esyntax_2eimport_2eskipWhite(V v_s_240, V v_i_241, V v_end_242) {
top: ;
  if (heff_intLt_c_lent(v_i_241, v_end_242, 0)) {
    V v_c_244 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
    if ((heff_peek_word(v_c_244) == ((int64_t)32ULL))) {
      heff_drop(v_c_244);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_end_242;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_end_242 = t_2;
      goto top;
    } else {
      if ((heff_peek_word(v_c_244) == ((int64_t)10ULL))) {
        heff_drop(v_c_244);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_end_242;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_end_242 = t_2;
        goto top;
      } else {
        if ((heff_peek_word(v_c_244) == ((int64_t)13ULL))) {
          heff_drop(v_c_244);
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = v_end_242;
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_end_242 = t_2;
          goto top;
        } else {
          if ((heff_unbox_word(v_c_244) == ((int64_t)9ULL))) {
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
            V t_2 = v_end_242;
            v_s_240 = t_0;
            v_i_241 = t_1;
            v_end_242 = t_2;
            goto top;
          } else {
            heff_drop(v_end_242);
            return v_i_241;
          }
        }
      }
    }
  } else {
    heff_drop(v_end_242);
    return v_i_241;
  }
}
V g_heff_2esyntax_2eimport_2eskipWhite_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2eskipWhite(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2eimport_2eskipWhiteBack_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eskipWhiteBack_entry, 3, 0};

V g_heff_2esyntax_2eimport_2eskipWhiteBack(V v_s_240, V v_start_241, V v_j_242) {
top: ;
  if (heff_intLt_c_lent(v_start_241, v_j_242, 0)) {
    V v_c_244 = heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_j_242), MK_INT(1LL)));
    if ((heff_peek_word(v_c_244) == ((int64_t)32ULL))) {
      heff_drop(v_c_244);
      V t_0 = v_s_240;
      V t_1 = v_start_241;
      V t_2 = heff_intSub(v_j_242, MK_INT(1LL));
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_j_242 = t_2;
      goto top;
    } else {
      if ((heff_peek_word(v_c_244) == ((int64_t)10ULL))) {
        heff_drop(v_c_244);
        V t_0 = v_s_240;
        V t_1 = v_start_241;
        V t_2 = heff_intSub(v_j_242, MK_INT(1LL));
        v_s_240 = t_0;
        v_start_241 = t_1;
        v_j_242 = t_2;
        goto top;
      } else {
        if ((heff_peek_word(v_c_244) == ((int64_t)13ULL))) {
          heff_drop(v_c_244);
          V t_0 = v_s_240;
          V t_1 = v_start_241;
          V t_2 = heff_intSub(v_j_242, MK_INT(1LL));
          v_s_240 = t_0;
          v_start_241 = t_1;
          v_j_242 = t_2;
          goto top;
        } else {
          if ((heff_unbox_word(v_c_244) == ((int64_t)9ULL))) {
            V t_0 = v_s_240;
            V t_1 = v_start_241;
            V t_2 = heff_intSub(v_j_242, MK_INT(1LL));
            v_s_240 = t_0;
            v_start_241 = t_1;
            v_j_242 = t_2;
            goto top;
          } else {
            heff_drop(v_start_241);
            return v_j_242;
          }
        }
      }
    }
  } else {
    heff_drop(v_start_241);
    return v_j_242;
  }
}
V g_heff_2esyntax_2eimport_2eskipWhiteBack_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2eskipWhiteBack(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2eimport_2ecloseOf_24cpr(V v_s_240, V v_i_241, V v_depth_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    heff_drop(v_depth_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)40ULL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_intAdd(v_depth_242, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_depth_242 = t_2;
      goto top;
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)41ULL))) {
        if (heff_intEq_c_lent(v_depth_242, MK_INT(1LL), 2)) {
          heff_drop(v_depth_242);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = heff_intSub(v_depth_242, MK_INT(1LL));
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_depth_242 = t_2;
          goto top;
        }
      } else {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_depth_242;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_depth_242 = t_2;
        goto top;
      }
    }
  }
}
Clo g_heff_2esyntax_2eimport_2epiecesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2epiecesGo_entry, 6, 0};

V g_heff_2esyntax_2eimport_2epiecesGo(V v_s_240, V v_from_241, V v_i_242, V v_b_243, V v_depth_244, V v_acc_245) {
top: ;
  if (heff_intLe_c_lent(v_b_243, v_i_242, 0)) {
    heff_drop(v_i_242);
    heff_drop(v_depth_244);
    V v_a_247 = (g_heff_2esyntax_2eimport_2eskipWhite(v_s_240, v_from_241, heff_dup(v_b_243)));
    V v_t_248 = (g_heff_2esyntax_2eimport_2eskipWhiteBack(v_s_240, heff_dup(v_a_247), v_b_243));
    V v_xs_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_a_247, v_t_248}), v_acc_245});
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)40ULL))) {
      V t_0 = v_s_240;
      V t_1 = v_from_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_b_243;
      V t_4 = heff_intAdd(v_depth_244, MK_INT(1LL));
      V t_5 = v_acc_245;
      v_s_240 = t_0;
      v_from_241 = t_1;
      v_i_242 = t_2;
      v_b_243 = t_3;
      v_depth_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)41ULL))) {
        V t_0 = v_s_240;
        V t_1 = v_from_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        V t_3 = v_b_243;
        V t_4 = heff_intSub(v_depth_244, MK_INT(1LL));
        V t_5 = v_acc_245;
        v_s_240 = t_0;
        v_from_241 = t_1;
        v_i_242 = t_2;
        v_b_243 = t_3;
        v_depth_244 = t_4;
        v_acc_245 = t_5;
        goto top;
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)44ULL))) {
          if (heff_intEq_c_lent(v_depth_244, MK_INT(0LL), 2)) {
            V v_a_2414 = (g_heff_2esyntax_2eimport_2eskipWhite(v_s_240, v_from_241, heff_dup(v_i_242)));
            V v_t_2415 = (g_heff_2esyntax_2eimport_2eskipWhiteBack(v_s_240, heff_dup(v_a_2414), heff_dup(v_i_242)));
            V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_a_2414, v_t_2415}), v_acc_245});
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
            V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
            V t_3 = v_b_243;
            V t_4 = v_depth_244;
            V t_5 = v_t_2416;
            v_s_240 = t_0;
            v_from_241 = t_1;
            v_i_242 = t_2;
            v_b_243 = t_3;
            v_depth_244 = t_4;
            v_acc_245 = t_5;
            goto top;
          } else {
            V t_0 = v_s_240;
            V t_1 = v_from_241;
            V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
            V t_3 = v_b_243;
            V t_4 = v_depth_244;
            V t_5 = v_acc_245;
            v_s_240 = t_0;
            v_from_241 = t_1;
            v_i_242 = t_2;
            v_b_243 = t_3;
            v_depth_244 = t_4;
            v_acc_245 = t_5;
            goto top;
          }
        } else {
          V t_0 = v_s_240;
          V t_1 = v_from_241;
          V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
          V t_3 = v_b_243;
          V t_4 = v_depth_244;
          V t_5 = v_acc_245;
          v_s_240 = t_0;
          v_from_241 = t_1;
          v_i_242 = t_2;
          v_b_243 = t_3;
          v_depth_244 = t_4;
          v_acc_245 = t_5;
          goto top;
        }
      }
    }
  }
}
V g_heff_2esyntax_2eimport_2epiecesGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2epiecesGo(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eoperatorIn_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eimport_2eoperatorIn_24cpr_str1, 2, "..");
HEFF_LIT(g_heff_2esyntax_2eimport_2eoperatorIn_24cpr_str2, 1, " ");

HeffT2 g_heff_2esyntax_2eimport_2eoperatorIn_24cpr(V v_t_240) {
top: ;
  if ((((int64_t)2ULL) < heff_unbox_word(heff_strLength_lent(v_t_240, 0)))) {
    if ((heff_unbox_word(heff_strByteAt_lent(v_t_240, MK_INT(0LL), 2)) == ((int64_t)40ULL))) {
      int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_t_240, 0)) - ((int64_t)1ULL));
      if ((heff_unbox_word(heff_strByteAt_lent(v_t_240, heff_box_word(v_t_243), 2)) == ((int64_t)41ULL))) {
        int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_t_240, 0)) - ((int64_t)1ULL));
        V v_t_246 = (g_heff_2esyntax_2eimport_2etrimStart(heff_strSlice_lent(v_t_240, MK_INT(1LL), heff_box_word(v_t_245), 6)));
        V v_x_247 = (g_heff_2esyntax_2eimport_2etrimEnd(v_t_246));
        if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2esyntax_2eimport_2eoperatorIn_24cpr_str0), 2)) {
          heff_drop(v_x_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        } else {
          if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2esyntax_2eimport_2eoperatorIn_24cpr_str1), 2)) {
            heff_drop(v_x_247);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          } else {
            if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2esyntax_2eimport_2eoperatorIn_24cpr_str2), v_x_247, MK_INT(0LL), 5))) {
              heff_drop(v_x_247);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            } else {
              if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_247, 0)))) {
                if ((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_247, MK_INT(0LL), 2)))) {
                  if ((heff_unbox_word(heff_strByteAt_lent(v_x_247, MK_INT(0LL), 2)) <= ((int64_t)57ULL))) {
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_247}});
                  } else {
                    V v_t_2414 = (g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(v_x_247, MK_INT(0LL)));
                    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
                      heff_drop(v_x_247);
                      heff_drop(v_t_2414);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    } else {
                      heff_drop(v_t_2414);
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_247}});
                    }
                  }
                } else {
                  V v_t_2415 = (g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(v_x_247, MK_INT(0LL)));
                  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
                    heff_drop(v_x_247);
                    heff_drop(v_t_2415);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  } else {
                    heff_drop(v_t_2415);
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_247}});
                  }
                }
              } else {
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_247}});
              }
            }
          }
        }
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  } else {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eclaimSays_str0, 54, "a module claim lists names: `x`, `T`, `T(..)`, `(<+>)`");

static V g_heff_2esyntax_2eimport_2eclaimSays_val;
static HEFF_ONCE g_heff_2esyntax_2eimport_2eclaimSays_st;
static V g_heff_2esyntax_2eimport_2eclaimSays_init(void) {
  return ((V)&g_heff_2esyntax_2eimport_2eclaimSays_str0);
}
V g_heff_2esyntax_2eimport_2eclaimSays_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2eimport_2eclaimSays_st)) return g_heff_2esyntax_2eimport_2eclaimSays_val;
  return heff_global(&g_heff_2esyntax_2eimport_2eclaimSays_val, &g_heff_2esyntax_2eimport_2eclaimSays_st, g_heff_2esyntax_2eimport_2eclaimSays_init);
}

HeffT2 g_heff_2esyntax_2eimport_2enameEntry_24cpr(V v_s_240, V v_sp_241, V v_tags_242) {
top: ;
  V v_t_243 = heff_strSlice(heff_dup(v_s_240), heff_dup(heff_rfield(v_sp_241, 0)), heff_dup(heff_rfield(v_sp_241, 1)));
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_243, 0)))) {
    if ((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_t_243, MK_INT(0LL), 2)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_t_243, MK_INT(0LL), 2)) <= ((int64_t)57ULL))) {
        HeffT2 v_t_247 = ({ V a_0 = v_t_243; HeffT2 r_ = (g_heff_2esyntax_2eimport_2eoperatorIn_24cpr(a_0)); heff_drop(v_t_243); r_; });
        {
          V v_field_249 = v_t_247.f[1];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          if ((v_tag_248 == ((int64_t)0ULL))) {
            V v_op_2411 = v_field_249;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__tags__span, (V[]){v_op_2411, v_tags_242, v_sp_241})}});
          } else {
            heff_drop(v_tags_242);
            heff_drop(v_field_249);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_sp_241, heff_dup(g_heff_2esyntax_2eimport_2eclaimSays_get())})}});
          }
        }
      } else {
        V v_t_2412 = (g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(v_t_243, MK_INT(0LL)));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop(v_t_2412);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__tags__span, (V[]){v_t_243, v_tags_242, v_sp_241})}});
        } else {
          heff_drop(v_t_2412);
          HeffT2 v_t_2413 = ({ V a_0 = v_t_243; HeffT2 r_ = (g_heff_2esyntax_2eimport_2eoperatorIn_24cpr(a_0)); heff_drop(v_t_243); r_; });
          {
            V v_field_2415 = v_t_2413.f[1];
            int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
            if ((v_tag_2414 == ((int64_t)0ULL))) {
              V v_op_2417 = v_field_2415;
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__tags__span, (V[]){v_op_2417, v_tags_242, v_sp_241})}});
            } else {
              heff_drop(v_tags_242);
              heff_drop(v_field_2415);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_sp_241, heff_dup(g_heff_2esyntax_2eimport_2eclaimSays_get())})}});
            }
          }
        }
      }
    } else {
      V v_t_2418 = (g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(v_t_243, MK_INT(0LL)));
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop(v_t_2418);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__tags__span, (V[]){v_t_243, v_tags_242, v_sp_241})}});
      } else {
        heff_drop(v_t_2418);
        HeffT2 v_t_2419 = ({ V a_0 = v_t_243; HeffT2 r_ = (g_heff_2esyntax_2eimport_2eoperatorIn_24cpr(a_0)); heff_drop(v_t_243); r_; });
        {
          V v_field_2421 = v_t_2419.f[1];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            V v_op_2423 = v_field_2421;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__tags__span, (V[]){v_op_2423, v_tags_242, v_sp_241})}});
          } else {
            heff_drop(v_tags_242);
            heff_drop(v_field_2421);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_sp_241, heff_dup(g_heff_2esyntax_2eimport_2eclaimSays_get())})}});
          }
        }
      }
    }
  } else {
    HeffT2 v_t_2424 = ({ V a_0 = v_t_243; HeffT2 r_ = (g_heff_2esyntax_2eimport_2eoperatorIn_24cpr(a_0)); heff_drop(v_t_243); r_; });
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      if ((v_tag_2425 == ((int64_t)0ULL))) {
        V v_op_2428 = v_field_2426;
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__tags__span, (V[]){v_op_2428, v_tags_242, v_sp_241})}});
      } else {
        heff_drop(v_tags_242);
        heff_drop(v_field_2426);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_sp_241, heff_dup(g_heff_2esyntax_2eimport_2eclaimSays_get())})}});
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eentryOf_24cpr_str0, 4, "(..)");
HEFF_LIT(g_heff_2esyntax_2eimport_2eentryOf_24cpr_str1, 16, "an empty entry: ");
HEFF_LIT(g_heff_2esyntax_2eimport_2eentryOf_24cpr_str2, 16, "an empty entry: ");

HeffT2 g_heff_2esyntax_2eimport_2eentryOf_24cpr(V v_s_240, V v_sp_241) {
top: ;
  V v_t_242 = heff_intSub(heff_dup(heff_rfield(v_sp_241, 1)), heff_dup(heff_rfield(v_sp_241, 0)));
  if (heff_intLt_c(MK_INT(4LL), v_t_242)) {
    V v_s_244 = heff_strSlice(heff_dup(v_s_240), heff_dup(heff_rfield(v_sp_241, 0)), heff_dup(heff_rfield(v_sp_241, 1)));
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_s_244, 0)) - ((int64_t)4ULL));
    V v_t_246 = heff_strSlice(heff_dup(v_s_244), heff_box_word(v_t_245), heff_strLength(v_s_244));
    if (heff_strEq_c(v_t_246, ((V)&g_heff_2esyntax_2eimport_2eentryOf_24cpr_str0))) {
      V v_t_248 = heff_intSub(heff_take_field(v_sp_241, 1), MK_INT(4LL));
      V v_t_249 = (g_heff_2esyntax_2eimport_2eskipWhiteBack(v_s_240, heff_dup(heff_rfield(v_sp_241, 0)), v_t_248));
      V v_t_2410 = ({ V rv_1 = v_t_249; V rr_ = heff_rec_reuse_nf(v_sp_241, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return (g_heff_2esyntax_2eimport_2enameEntry_24cpr(v_s_240, v_t_2410, NTAG(TAG_True)));
    } else {
      if (heff_intEq_c(heff_dup(heff_rfield(v_sp_241, 1)), heff_dup(heff_rfield(v_sp_241, 0)))) {
        V v_f_2412 = heff_rec_n(2, shape_span__msg, (V[]){v_sp_241, heff_strAppend(((V)&g_heff_2esyntax_2eimport_2eentryOf_24cpr_str1), heff_dup(g_heff_2esyntax_2eimport_2eclaimSays_get()))});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
      } else {
        return (g_heff_2esyntax_2eimport_2enameEntry_24cpr(v_s_240, v_sp_241, NTAG(TAG_False)));
      }
    }
  } else {
    if (heff_intEq_c(heff_dup(heff_rfield(v_sp_241, 1)), heff_dup(heff_rfield(v_sp_241, 0)))) {
      V v_f_2414 = heff_rec_n(2, shape_span__msg, (V[]){v_sp_241, heff_strAppend(((V)&g_heff_2esyntax_2eimport_2eentryOf_24cpr_str2), heff_dup(g_heff_2esyntax_2eimport_2eclaimSays_get()))});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
    } else {
      return (g_heff_2esyntax_2eimport_2enameEntry_24cpr(v_s_240, v_sp_241, NTAG(TAG_False)));
    }
  }
}

HeffT2 g_heff_2esyntax_2eimport_2eentriesGo_24cpr(V v_s_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_f_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return ((HeffT2){{v_f_243, NTAG(TAG_Nothing)}});
  }
  case TAG_Cons: {
    V v_sp_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_246 = (g_heff_2esyntax_2eimport_2eentryOf_24cpr(v_s_240, v_sp_244));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_rest_245);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_err_2410 = v_field_248;
        V v_f_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
        return ((HeffT2){{v_f_2411, heff_tag_n(TAG_Just, 1, (V[]){v_err_2410})}});
      } else {
        V v_x_2412 = v_field_248;
        V t_0 = v_s_240;
        V t_1 = v_rest_245;
        V t_2 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_2412, v_acc_242});
        v_s_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2esyntax_2eimport_2enameEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2enameEnd_entry, 2, 0};

V g_heff_2esyntax_2eimport_2enameEnd(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_s_240, 0))) {
    V v_t_243 = (g_heff_2esyntax_2eimport_2enameChar(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_243);
      return v_i_241;
    }
  } else {
    return v_i_241;
  }
}
V g_heff_2esyntax_2eimport_2enameEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2enameEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eclaimListed_24cpr_str0, 0, "");

HeffT2 g_heff_2esyntax_2eimport_2eclaimListed_24cpr(V v_src_240, V v_i_241, V v_name_242, V v_open_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2esyntax_2eimport_2ecloseOf_24cpr(v_src_240, heff_dup(v_open_243), MK_INT(0LL)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_close_248 = v_field_246;
      V v_t_249 = (g_heff_2esyntax_2eimport_2elineEndAt(v_src_240, heff_intAdd(heff_dup(v_close_248), MK_INT(1LL))));
      V v_s_2410 = heff_strSlice(heff_dup(v_src_240), heff_intAdd(heff_dup(v_close_248), MK_INT(1LL)), v_t_249);
      V v_t_2411 = (g_heff_2esyntax_2eimport_2etrimStart(v_s_2410));
      V v_t_2412 = (g_heff_2esyntax_2eimport_2etrimEnd(v_t_2411));
      if (heff_strEq_c(v_t_2412, ((V)&g_heff_2esyntax_2eimport_2eclaimListed_24cpr_str0))) {
        V v_t_2414 = (g_heff_2esyntax_2eimport_2eskipWhite(v_src_240, heff_intAdd(heff_dup(v_open_243), MK_INT(1LL)), heff_dup(v_close_248)));
        if (heff_intEq_c_lent(v_t_2414, v_close_248, 1)) {
          heff_drop(v_open_243);
          V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){v_i_241, heff_intAdd(v_close_248, MK_INT(1LL))});
          V v_f_2417 = heff_rec_n(5, shape_name__listed__exposes__span__error, (V[]){v_name_242, NTAG(TAG_True), NTAG(TAG_Nil), v_t_2416, NTAG(TAG_Nothing)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2417}});
        } else {
          V v_t_2418 = (g_heff_2esyntax_2eimport_2epiecesGo(v_src_240, heff_intAdd(heff_dup(v_open_243), MK_INT(1LL)), heff_intAdd(v_open_243, MK_INT(1LL)), heff_dup(v_close_248), MK_INT(0LL), NTAG(TAG_Nil)));
          HeffT2 v_t_2419 = (g_heff_2esyntax_2eimport_2eentriesGo_24cpr(v_src_240, v_t_2418, NTAG(TAG_Nil)));
          {
            V v_field_2420 = v_t_2419.f[0];
            V v_field_2421 = v_t_2419.f[1];
            V v_es_2422 = v_field_2420;
            V v_err_2423 = v_field_2421;
            V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){v_i_241, heff_intAdd(v_close_248, MK_INT(1LL))});
            V v_f_2425 = heff_rec_n(5, shape_name__listed__exposes__span__error, (V[]){v_name_242, NTAG(TAG_True), v_es_2422, v_t_2424, v_err_2423});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2425}});
          }
        }
      } else {
        heff_drop(v_i_241);
        heff_drop(v_name_242);
        heff_drop(v_open_243);
        heff_drop(v_close_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_i_241);
      heff_drop(v_name_242);
      heff_drop(v_open_243);
      heff_drop(v_field_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eclaimNamed_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eimport_2eclaimNamed_24cpr_str1, 0, "");

HeffT2 g_heff_2esyntax_2eimport_2eclaimNamed_24cpr(V v_src_240, V v_i_241, V v_j_242, V v_k_243) {
top: ;
  V v_name_244 = heff_strSlice_lent(v_src_240, v_j_242, v_k_243, 0);
  V v_x_245 = (g_heff_2esyntax_2eimport_2eskipWhite(v_src_240, heff_dup(v_k_243), heff_strLength_lent(v_src_240, 0)));
  if (heff_intLt_c(heff_dup(v_x_245), heff_strLength_lent(v_src_240, 0))) {
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_x_245, 0)) == ((int64_t)40ULL))) {
      heff_drop(v_k_243);
      HEFF_LAST return g_heff_2esyntax_2eimport_2eclaimListed_24cpr(v_src_240, v_i_241, heff_tag_n(TAG_Just, 1, (V[]){v_name_244}), v_x_245);
    } else {
      heff_drop(v_x_245);
      V v_t_248 = (g_heff_2esyntax_2eimport_2elineEndAt(v_src_240, heff_dup(v_k_243)));
      V v_s_249 = heff_strSlice_lent(v_src_240, v_k_243, v_t_248, 4);
      V v_t_2410 = (g_heff_2esyntax_2eimport_2etrimStart(v_s_249));
      V v_t_2411 = (g_heff_2esyntax_2eimport_2etrimEnd(v_t_2410));
      if (heff_strEq_c(v_t_2411, ((V)&g_heff_2esyntax_2eimport_2eclaimNamed_24cpr_str0))) {
        V v_t_2413 = heff_rec_n(5, shape_name__listed__exposes__span__error, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_name_244}), NTAG(TAG_False), NTAG(TAG_Nil), heff_rec_n(2, shape_start__end, (V[]){v_i_241, v_k_243}), NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2413}});
      } else {
        heff_drop(v_i_241);
        heff_drop(v_k_243);
        heff_drop(v_name_244);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    heff_drop(v_x_245);
    V v_t_2414 = (g_heff_2esyntax_2eimport_2elineEndAt(v_src_240, heff_dup(v_k_243)));
    V v_s_2415 = heff_strSlice_lent(v_src_240, v_k_243, v_t_2414, 4);
    V v_t_2416 = (g_heff_2esyntax_2eimport_2etrimStart(v_s_2415));
    V v_t_2417 = (g_heff_2esyntax_2eimport_2etrimEnd(v_t_2416));
    if (heff_strEq_c(v_t_2417, ((V)&g_heff_2esyntax_2eimport_2eclaimNamed_24cpr_str1))) {
      V v_t_2419 = heff_rec_n(5, shape_name__listed__exposes__span__error, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_name_244}), NTAG(TAG_False), NTAG(TAG_Nil), heff_rec_n(2, shape_start__end, (V[]){v_i_241, v_k_243}), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2419}});
    } else {
      heff_drop(v_i_241);
      heff_drop(v_k_243);
      heff_drop(v_name_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eclaimAt_24cpr_str0, 6, "module");

HeffT2 g_heff_2esyntax_2eimport_2eclaimAt_24cpr(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_intAdd(heff_dup(v_i_241), MK_INT(6LL)), heff_strLength_lent(v_src_240, 0))) {
    V v_t_243 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(6LL)));
    if (heff_strEq_c(v_t_243, ((V)&g_heff_2esyntax_2eimport_2eclaimAt_24cpr_str0))) {
      V v_t_245 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(6LL)));
      V v_x1_246 = (g_heff_2esyntax_2eimport_2eidentChar(v_t_245));
      if ((heff_dup(v_x1_246) == NTAG(TAG_True))) {
        heff_drop(v_i_241);
        heff_drop(v_x1_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_x1_246);
        V v_x_247 = (g_heff_2esyntax_2eimport_2eskipWhite(v_src_240, heff_intAdd(heff_dup(v_i_241), MK_INT(6LL)), heff_strLength_lent(v_src_240, 0)));
        if (heff_intLt_c(heff_dup(v_x_247), heff_strLength_lent(v_src_240, 0))) {
          if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_x_247, 0)) == ((int64_t)40ULL))) {
            return (g_heff_2esyntax_2eimport_2eclaimListed_24cpr(v_src_240, v_i_241, NTAG(TAG_Nothing), v_x_247));
          } else {
            V v_x_2410 = (g_heff_2esyntax_2eimport_2enameEnd(v_src_240, heff_dup(v_x_247)));
            if (heff_intEq_c_lent(v_x_2410, v_x_247, 0)) {
              heff_drop(v_i_241);
              heff_drop(v_x_247);
              heff_drop(v_x_2410);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            } else {
              return ({ V a_0 = v_src_240; V a_1 = v_i_241; V a_2 = v_x_247; V a_3 = v_x_2410; HeffT2 r_ = (g_heff_2esyntax_2eimport_2eclaimNamed_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_247); r_; });
            }
          }
        } else {
          V v_x_2412 = (g_heff_2esyntax_2eimport_2enameEnd(v_src_240, heff_dup(v_x_247)));
          if (heff_intEq_c_lent(v_x_2412, v_x_247, 0)) {
            heff_drop(v_i_241);
            heff_drop(v_x_247);
            heff_drop(v_x_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          } else {
            return ({ V a_0 = v_src_240; V a_1 = v_i_241; V a_2 = v_x_247; V a_3 = v_x_2412; HeffT2 r_ = (g_heff_2esyntax_2eimport_2eclaimNamed_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_247); r_; });
          }
        }
      }
    } else {
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  } else {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
Clo g_heff_2esyntax_2eimport_2edoneI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2edoneI_entry, 3, 0};

V g_heff_2esyntax_2eimport_2edoneI(V v_src_240, V v_claim_241, V v_acc_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_acc_242)));
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  V v_s_245 = ({ V a_0 = v_src_240; V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s947555161x768980202(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_2412;
  switch (heff_tag_of(v_claim_241)) {
  case TAG_Nothing: {
    v_t_2412 = v_s_245;
    break;
  }
  case TAG_Just: {
    V v_h_246 = heff_dup(heff_field(v_claim_241, 0));
    V v_sp_247 = heff_get_n(v_h_246, 3, 5);
    V v_t_248 = heff_strSlice(heff_dup(v_s_245), MK_INT(0LL), heff_dup(heff_rfield(v_sp_247, 0)));
    V v_t_249 = heff_intSub(heff_dup(heff_rfield(v_sp_247, 1)), heff_take_field(v_sp_247, 0));
    V v_t_2410 = (g_heff_2esyntax_2eimport_2espaces(v_t_249));
    V v_t_2411 = heff_strSlice(heff_dup(v_s_245), heff_get_n(v_sp_247, 1, 2), heff_strLength(v_s_245));
    v_t_2412 = heff_strAppend(v_t_248, heff_strAppend(v_t_2410, v_t_2411));
    break;
  }
  default: heff_nomatch(v_claim_241);
  }
  return heff_rec_n(4, shape_imports__implicit__claim__text, (V[]){v_t_243, NTAG(TAG_Nil), v_claim_241, v_t_2412});
}
V g_heff_2esyntax_2eimport_2edoneI_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2edoneI(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eclaimThen_str0, 48, "the module claim comes first, before its imports");
Clo g_heff_2esyntax_2eimport_2eclaimThen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eclaimThen_entry, 5, 0};

V g_heff_2esyntax_2eimport_2eclaimThen(V v_src_240, V v_i_241, V v_claim_242, V v_acc_243, V v_again_244) {
top: ;
  switch (heff_tag_of(v_claim_242)) {
  case TAG_Nothing: {
    HeffT2 v_t_245 = (g_heff_2esyntax_2eimport_2eclaimAt_24cpr(v_src_240, v_i_241));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_h_249 = v_field_247;
        V v_t_2413;
        switch (heff_tag_of(v_acc_243)) {
        case TAG_Nil: {
          v_t_2413 = heff_dup(v_h_249);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_acc_243, 0ULL, 2);
          V v_t_2412 = heff_rec_n(2, shape_span__msg, (V[]){heff_dup(heff_rfield(v_h_249, 3)), ((V)&g_heff_2esyntax_2eimport_2eclaimThen_str0)});
          v_t_2413 = heff_rec_n(5, shape_name__listed__exposes__span__error, (V[]){heff_dup(heff_rfield(v_h_249, 0)), heff_dup(heff_rfield(v_h_249, 1)), heff_dup(heff_rfield(v_h_249, 2)), heff_dup(heff_rfield(v_h_249, 3)), heff_tag_n(TAG_Just, 1, (V[]){v_t_2412})});
          break;
        }
        default: heff_nomatch(v_acc_243);
        }
        V v_t_2414 = heff_get_n(heff_get_n(v_h_249, 3, 5), 1, 2);
        V v_t_2415 = ({ V a_0 = v_src_240; V a_1 = v_t_2414; V r_ = (g_heff_2esyntax_2eimport_2elineEndAt(a_0, a_1)); heff_drop(v_src_240); r_; });
        return heff_tail(v_again_244, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_2413}), heff_intAdd(v_t_2415, MK_INT(1LL))});
      } else {
        heff_drop(v_again_244);
        heff_drop(v_field_247);
        V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_acc_243)));
        V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
        V v_s_2418 = ({ V a_0 = v_src_240; V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s947555161x768980202(a_0, a_1)); heff_drop(v_t_2417); r_; });
        return heff_rec_n(4, shape_imports__implicit__claim__text, (V[]){v_t_2416, NTAG(TAG_Nil), NTAG(TAG_Nothing), v_s_2418});
      }
    }
  }
  case TAG_Just: {
    heff_drop(v_i_241);
    heff_drop(v_again_244);
    return (g_heff_2esyntax_2eimport_2edoneI(v_src_240, v_claim_242, v_acc_243));
  }
  default: return heff_nomatch(v_claim_242);
  }
}
V g_heff_2esyntax_2eimport_2eclaimThen_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2eclaimThen(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportsGo_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportsGo_str1, 2, "--");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportsGo_str2, 7, "import ");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportsGo_str3, 6, "module");
V g_heff_2esyntax_2eimport_2eimportsGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2eimport_2eimportsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eimportsGo_entry, 4, 0};

V g_heff_2esyntax_2eimport_2eimportsGo(V v_src_240, V v_i_241, V v_claim_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return (g_heff_2esyntax_2eimport_2edoneI(v_src_240, v_claim_242, v_acc_243));
  } else {
    V v_x_245 = (g_heff_2esyntax_2eimport_2elineEndAt(v_src_240, heff_dup(v_i_241)));
    V v_line_246 = heff_strSlice_lent(v_src_240, v_i_241, v_x_245, 0);
    V v_t_247 = (g_heff_2esyntax_2eimport_2etrimStart(heff_dup(v_line_246)));
    V v_x_248 = (g_heff_2esyntax_2eimport_2etrimEnd(v_t_247));
    if (heff_strEq_c_lent(v_x_248, ((V)&g_heff_2esyntax_2eimport_2eimportsGo_str0), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_line_246);
      heff_drop(v_x_248);
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_x_245, MK_INT(1LL));
      V t_2 = v_claim_242;
      V t_3 = v_acc_243;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_claim_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      if (heff_strEq_c(heff_strSlice(v_x_248, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2esyntax_2eimport_2eimportsGo_str1))) {
        heff_drop(v_i_241);
        heff_drop(v_line_246);
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_x_245, MK_INT(1LL));
        V t_2 = v_claim_242;
        V t_3 = v_acc_243;
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_claim_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      } else {
        if (heff_strEq_c(heff_strSlice_lent(v_line_246, MK_INT(0LL), MK_INT(7LL), 6), ((V)&g_heff_2esyntax_2eimport_2eimportsGo_str2))) {
          V v_t_2412 = heff_strSlice(heff_dup(v_line_246), MK_INT(7LL), heff_strLength(v_line_246));
          V v_t_2413 = (g_heff_2esyntax_2eimport_2etrimStart(v_t_2412));
          V v_s_2414 = (g_heff_2esyntax_2eimport_2etrimEnd(v_t_2413));
          V v_t_2415 = ({ V a_0 = v_s_2414; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2eimport_2ewordsGo(a_0, a_1, a_2, a_3)); heff_drop(v_s_2414); r_; });
          HeffT2 v_t_2416 = (g_heff_2esyntax_2eimport_2eimportOf_24cpr(v_i_241, heff_dup(v_x_245), v_t_2415));
          {
            V v_field_2418 = v_t_2416.f[1];
            int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
            if ((v_tag_2417 == ((int64_t)0ULL))) {
              V v_imp_2420 = v_field_2418;
              V t_0 = v_src_240;
              V t_1 = heff_intAdd(v_x_245, MK_INT(1LL));
              V t_2 = v_claim_242;
              V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_imp_2420, v_acc_243});
              v_src_240 = t_0;
              v_i_241 = t_1;
              v_claim_242 = t_2;
              v_acc_243 = t_3;
              goto top;
            } else {
              heff_drop(v_x_245);
              heff_drop(v_field_2418);
              return (g_heff_2esyntax_2eimport_2edoneI(v_src_240, v_claim_242, v_acc_243));
            }
          }
        } else {
          heff_drop(v_x_245);
          if (heff_strEq_c(heff_strSlice(v_line_246, MK_INT(0LL), MK_INT(6LL)), ((V)&g_heff_2esyntax_2eimport_2eimportsGo_str3))) {
            return (g_heff_2esyntax_2eimport_2eclaimThen(heff_dup(v_src_240), v_i_241, v_claim_242, heff_dup(v_acc_243), heff_clo_n(g_heff_2esyntax_2eimport_2eimportsGo_lam0, 2, 2, (V[]){v_src_240, v_acc_243})));
          } else {
            heff_drop(v_i_241);
            return (g_heff_2esyntax_2eimport_2edoneI(v_src_240, v_claim_242, v_acc_243));
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2eimportsGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2eimport_2eimportsGo_lam0(V self, V *args) {
  V v_h_2422 = args[0];
  V v_j_2423 = args[1];
  V v_src_240 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, v_j_2423, v_h_2422, v_acc_243));
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eimplicitImports_str0, 7, "builtin");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimplicitImports_str1, 7, "prelude");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimplicitImports_str2, 4, "list");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimplicitImports_str3, 4, "List");

static V g_heff_2esyntax_2eimport_2eimplicitImports_val;
static HEFF_ONCE g_heff_2esyntax_2eimport_2eimplicitImports_st;
static V g_heff_2esyntax_2eimport_2eimplicitImports_init(void) {
  V v_t_240 = heff_rec_n(3, shape_name__alias__span, (V[]){((V)&g_heff_2esyntax_2eimport_2eimplicitImports_str0), NTAG(TAG_Nothing), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  V v_t_241 = heff_rec_n(3, shape_name__alias__span, (V[]){((V)&g_heff_2esyntax_2eimport_2eimplicitImports_str1), NTAG(TAG_Nothing), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  V v_t_242 = heff_rec_n(3, shape_name__alias__span, (V[]){((V)&g_heff_2esyntax_2eimport_2eimplicitImports_str2), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2eimport_2eimplicitImports_str3)}), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_243})});
}
V g_heff_2esyntax_2eimport_2eimplicitImports_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2eimport_2eimplicitImports_st)) return g_heff_2esyntax_2eimport_2eimplicitImports_val;
  return heff_global(&g_heff_2esyntax_2eimport_2eimplicitImports_val, &g_heff_2esyntax_2eimport_2eimplicitImports_st, g_heff_2esyntax_2eimport_2eimplicitImports_init);
}

static V g_heff_2esyntax_2eimport_2eimplicitModules_val;
static HEFF_ONCE g_heff_2esyntax_2eimport_2eimplicitModules_st;
static V g_heff_2esyntax_2eimport_2eimplicitModules_init(void) {
  return (g_list_2emap_24s1817208647x1282894070(heff_dup(g_heff_2esyntax_2eimport_2eimplicitImports_get())));
}
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2eimport_2eimplicitModules_st)) return g_heff_2esyntax_2eimport_2eimplicitModules_val;
  return heff_global(&g_heff_2esyntax_2eimport_2eimplicitModules_val, &g_heff_2esyntax_2eimport_2eimplicitModules_st, g_heff_2esyntax_2eimport_2eimplicitModules_init);
}
Clo g_heff_2esyntax_2eimport_2eimportsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eimportsOf_entry, 2, 0};

V g_heff_2esyntax_2eimport_2eimportsOf(V v_ms_240, V v_src_241) {
top: ;
  V v_r_242 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_241, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ms_240)));
  V v_t_244 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s1644479985x1191070221(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, heff_take_field(v_r_242, 0)));
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_240));
  V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s1644479985x1191070221(a_0, a_1)); heff_drop(v_t_246); r_; });
  return ({ V rv_0 = v_t_245; V rv_1 = v_t_247; V rr_ = heff_rec_reuse_nf(v_r_242, 12ULL, 4, shape_imports__implicit__claim__text, 240u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2eimportsOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2eimport_2erenameTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2erenameTo_entry, 2, 0};

V g_heff_2esyntax_2eimport_2erenameTo(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_x_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_from_244 = heff_field(v_x11_242, 0);
      V v_to_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c_lent(v_from_244, v_x_241, 0)) {
        heff_drop(v_x_241);
        return heff_dup(v_to_245);
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2eimport_2erenameTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2erenameTo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2eimport_2erenamed_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2eimport_2erenamed_24cpr_lam1(V self, V *args);

HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V v_rs_240, V v_imps_241) {
top: ;
  V v_f_244 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eimport_2erenamed_24cpr_lam0, 1, 1, (V[]){heff_dup(v_rs_240)}), heff_take_field(v_imps_241, 0)));
  V v_f_247 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eimport_2erenamed_24cpr_lam1, 1, 1, (V[]){heff_dup(v_rs_240)}), heff_take_field(v_imps_241, 1)));
  V v_f_248 = heff_take_field(v_imps_241, 2);
  V v_f_249 = heff_get_n(v_imps_241, 3, 4);
  return ((HeffT4){{v_f_244, v_f_247, v_f_248, v_f_249}});
}
V g_heff_2esyntax_2eimport_2erenamed_24cpr_lam0(V self, V *args) {
  V v_i_242 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_name_243 = ({ V a_0 = v_rs_240; V a_1 = heff_take_field(v_i_242, 0); V r_ = (g_heff_2esyntax_2eimport_2erenameTo(a_0, a_1)); heff_drop(v_rs_240); r_; });
  return ({ V rv_0 = v_name_243; V rr_ = heff_rec_reuse_nf(v_i_242, 6ULL, 3, shape_name__alias__span, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
}
V g_heff_2esyntax_2eimport_2erenamed_24cpr_lam1(V self, V *args) {
  V v_i_245 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_name_246 = ({ V a_0 = v_rs_240; V a_1 = heff_take_field(v_i_245, 0); V r_ = (g_heff_2esyntax_2eimport_2erenameTo(a_0, a_1)); heff_drop(v_rs_240); r_; });
  return ({ V rv_0 = v_name_246; V rr_ = heff_rec_reuse_nf(v_i_245, 6ULL, 3, shape_name__alias__span, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
}
Clo g_heff_2esyntax_2eimport_2erenamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2erenamed_entry, 2, 0};

V g_heff_2esyntax_2eimport_2erenamed(V v_rs_240, V v_imps_241) {
top: ;
  HeffT4 v_t_242 = (g_heff_2esyntax_2eimport_2erenamed_24cpr(v_rs_240, v_imps_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_field_246 = v_t_242.f[3];
    return heff_rec_n(4, shape_imports__implicit__claim__text, (V[]){v_field_243, v_field_244, v_field_245, v_field_246});
  }
}
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2erenamed(a0, a[1]); heff_drop(a0); return r;
}