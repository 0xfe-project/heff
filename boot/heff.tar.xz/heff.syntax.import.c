// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_alias 294261354
#define LBL_claim 296100950
#define LBL_end 310101
#define LBL_error 298143266
#define LBL_exposes 1070285678
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_listed 844633320
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tags 10047712
#define LBL_text 10052084
static uint32_t shape_imports__implicit__claim__text[] = {LBL_imports, LBL_implicit, LBL_claim, LBL_text};
static uint32_t shape_name__alias__span[] = {LBL_name, LBL_alias, LBL_span};
static uint32_t shape_name__listed__exposes__span__error[] = {LBL_name, LBL_listed, LBL_exposes, LBL_span, LBL_error};
static uint32_t shape_name__tags__span[] = {LBL_name, LBL_tags, LBL_span};
static uint32_t shape_span__msg[] = {LBL_span, LBL_msg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(V, V);
V g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_clo;
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(V, V);
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_clo;
HeffT2 g_heff_2esyntax_2eimport_2eclaimAt_24cpr(V, V);
HeffT2 g_heff_2esyntax_2eimport_2eclaimListed_24cpr(V, V, V, V);
V g_heff_2esyntax_2eimport_2eclaimSays_get(void);
HeffT2 g_heff_2esyntax_2eimport_2ecloseOf_24cpr(V, V, V);
V g_heff_2esyntax_2eimport_2edoneI(V, V, V);
V g_heff_2esyntax_2eimport_2edoneI_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2edoneI_clo;
HeffT2 g_heff_2esyntax_2eimport_2eentriesGo_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2eimport_2eentryOf_24cpr(V, V);
V g_heff_2esyntax_2eimport_2ehasDot(V, V);
V g_heff_2esyntax_2eimport_2ehasDot_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2ehasDot_clo;
V g_heff_2esyntax_2eimport_2eimplicitImports_get(void);
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2elineEndAt(V, V);
V g_heff_2esyntax_2eimport_2elineEndAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2elineEndAt_clo;
V g_heff_2esyntax_2eimport_2enameEnd(V, V);
V g_heff_2esyntax_2eimport_2enameEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2enameEnd_clo;
HeffT2 g_heff_2esyntax_2eimport_2enameEntry_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2eimport_2eoperatorIn_24cpr(V);
V g_heff_2esyntax_2eimport_2epiecesGo(V, V, V, V, V, V);
V g_heff_2esyntax_2eimport_2epiecesGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2epiecesGo_clo;
V g_heff_2esyntax_2eimport_2erenameTo(V, V);
V g_heff_2esyntax_2eimport_2erenameTo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenameTo_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
V g_heff_2esyntax_2eimport_2eskipWhite(V, V, V);
V g_heff_2esyntax_2eimport_2eskipWhite_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eskipWhite_clo;
V g_heff_2esyntax_2eimport_2eskipWhiteBack(V, V, V);
V g_heff_2esyntax_2eimport_2eskipWhiteBack_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eskipWhiteBack_clo;
V g_heff_2esyntax_2eimport_2espaces(V);
V g_heff_2esyntax_2eimport_2espaces_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2espaces_clo;
V g_heff_2esyntax_2eimport_2espaces_24acc(V, V);
V g_heff_2esyntax_2eimport_2espaces_24acc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2espaces_24acc_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2063245892x1543682505(V, V);
V g_list_2efoldl_24s2063245892x1543682505_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2063245892x1543682505_clo;
V g_list_2efoldl_24s947555161x768980202(V, V);
V g_list_2efoldl_24s947555161x768980202_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947555161x768980202_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
Clo g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_entry, 2, 0};

V g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return NTAG(TAG_True);
  } else {
    V v_c_242 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2);
    if (((heff_peek_word(v_c_242) == ((int64_t)46ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)95ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)45ULL)) || (((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))))))))) {
      heff_drop(v_c_242);
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_c_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2eimport_2ehasDot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2ehasDot_entry, 2, 0};

V g_heff_2esyntax_2eimport_2ehasDot(V v_x_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) <= v_i_241)) {
    return NTAG(TAG_False);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_x_240, heff_box_word(v_i_241), 2)) == ((int64_t)46ULL))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_x_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2eimport_2ehasDot_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2ehasDot(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2eimport_2elineEndAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2elineEndAt_entry, 2, 0};

V g_heff_2esyntax_2eimport_2elineEndAt(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return heff_strLength_lent(v_src_240, 0);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)10ULL))) {
      return v_i_241;
    } else {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2eimport_2elineEndAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2elineEndAt(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2eimport_2espaces_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eimport_2espaces_str1, 1, " ");
Clo g_heff_2esyntax_2eimport_2espaces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2espaces_entry, 1, 0};

V g_heff_2esyntax_2eimport_2espaces(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2esyntax_2eimport_2espaces_str0);
  } else {
    V v_s_241 = ((V)&g_heff_2esyntax_2eimport_2espaces_str1);
    return (g_heff_2esyntax_2eimport_2espaces_24acc(heff_intSub(v_n_240, MK_INT(1LL)), v_s_241));
  }
}
V g_heff_2esyntax_2eimport_2espaces_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2espaces(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2eimport_2espaces_24acc_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eimport_2espaces_24acc_str1, 1, " ");
Clo g_heff_2esyntax_2eimport_2espaces_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2espaces_24acc_entry, 2, 0};

V g_heff_2esyntax_2eimport_2espaces_24acc(V v_n_240, V v_acc_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return heff_strAppend(v_acc_241, ((V)&g_heff_2esyntax_2eimport_2espaces_24acc_str0));
  } else {
    V v_s_242 = heff_strAppend(v_acc_241, ((V)&g_heff_2esyntax_2eimport_2espaces_24acc_str1));
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_s_242;
    v_n_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
}
V g_heff_2esyntax_2eimport_2espaces_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2espaces_24acc(a[0], a[1]);
}
Clo g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_entry, 2, 0};

V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return NTAG(TAG_True);
  } else {
    V v_c_242 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2);
    if (((heff_peek_word(v_c_242) == ((int64_t)95ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)39ULL)) || (((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL)))))))) {
      heff_drop(v_c_242);
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_c_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2eimport_2eskipWhite_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eskipWhite_entry, 3, 0};

V g_heff_2esyntax_2eimport_2eskipWhite(V v_s_240, V v_i_241, V v_end_242) {
top: ;
  if (heff_intLt_c_lent(v_i_241, v_end_242, 0)) {
    V v_c_243 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
    if (((heff_peek_word(v_c_243) == ((int64_t)32ULL)) || ((heff_peek_word(v_c_243) == ((int64_t)9ULL)) || ((heff_peek_word(v_c_243) == ((int64_t)10ULL)) || (heff_peek_word(v_c_243) == ((int64_t)13ULL)))))) {
      heff_drop(v_c_243);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_end_242;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_end_242 = t_2;
      goto top;
    } else {
      heff_drop(v_end_242);
      heff_drop(v_c_243);
      return v_i_241;
    }
  } else {
    heff_drop(v_end_242);
    return v_i_241;
  }
}
V g_heff_2esyntax_2eimport_2eskipWhite_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2eskipWhite(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2eimport_2eskipWhiteBack_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eskipWhiteBack_entry, 3, 0};

V g_heff_2esyntax_2eimport_2eskipWhiteBack(V v_s_240, V v_start_241, V v_j_242) {
top: ;
  if (heff_intLt_c_lent(v_start_241, v_j_242, 0)) {
    V v_c_243 = heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_j_242), MK_INT(1LL)));
    if (((heff_peek_word(v_c_243) == ((int64_t)32ULL)) || ((heff_peek_word(v_c_243) == ((int64_t)9ULL)) || ((heff_peek_word(v_c_243) == ((int64_t)10ULL)) || (heff_peek_word(v_c_243) == ((int64_t)13ULL)))))) {
      heff_drop(v_c_243);
      V t_0 = v_s_240;
      V t_1 = v_start_241;
      V t_2 = heff_intSub(v_j_242, MK_INT(1LL));
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_j_242 = t_2;
      goto top;
    } else {
      heff_drop(v_start_241);
      heff_drop(v_c_243);
      return v_j_242;
    }
  } else {
    heff_drop(v_start_241);
    return v_j_242;
  }
}
V g_heff_2esyntax_2eimport_2eskipWhiteBack_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2eskipWhiteBack(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2eimport_2ecloseOf_24cpr(V v_s_240, V v_i_241, V v_depth_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    heff_drop(v_depth_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)40ULL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_intAdd(v_depth_242, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_depth_242 = t_2;
      goto top;
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)41ULL))) {
        if (heff_intEq_c_lent(v_depth_242, MK_INT(1LL), 2)) {
          heff_drop(v_depth_242);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = heff_intSub(v_depth_242, MK_INT(1LL));
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_depth_242 = t_2;
          goto top;
        }
      } else {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_depth_242;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_depth_242 = t_2;
        goto top;
      }
    }
  }
}
Clo g_heff_2esyntax_2eimport_2epiecesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2epiecesGo_entry, 6, 0};

V g_heff_2esyntax_2eimport_2epiecesGo(V v_s_240, V v_from_241, V v_i_242, V v_b_243, V v_depth_244, V v_acc_245) {
top: ;
  if (heff_intLe_c_lent(v_b_243, v_i_242, 0)) {
    heff_drop(v_i_242);
    heff_drop(v_depth_244);
    V v_a_246 = (g_heff_2esyntax_2eimport_2eskipWhite(v_s_240, v_from_241, heff_dup(v_b_243)));
    V v_t_247 = (g_heff_2esyntax_2eimport_2eskipWhiteBack(v_s_240, heff_dup(v_a_246), v_b_243));
    V v_xs_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_a_246, v_t_247}), v_acc_245});
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)40ULL))) {
      V t_0 = v_s_240;
      V t_1 = v_from_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_b_243;
      V t_4 = heff_intAdd(v_depth_244, MK_INT(1LL));
      V t_5 = v_acc_245;
      v_s_240 = t_0;
      v_from_241 = t_1;
      v_i_242 = t_2;
      v_b_243 = t_3;
      v_depth_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)41ULL))) {
        V t_0 = v_s_240;
        V t_1 = v_from_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        V t_3 = v_b_243;
        V t_4 = heff_intSub(v_depth_244, MK_INT(1LL));
        V t_5 = v_acc_245;
        v_s_240 = t_0;
        v_from_241 = t_1;
        v_i_242 = t_2;
        v_b_243 = t_3;
        v_depth_244 = t_4;
        v_acc_245 = t_5;
        goto top;
      } else {
        if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)44ULL)) && heff_intEq_c_lent(v_depth_244, MK_INT(0LL), 2))) {
          V v_a_249 = (g_heff_2esyntax_2eimport_2eskipWhite(v_s_240, v_from_241, heff_dup(v_i_242)));
          V v_t_2410 = (g_heff_2esyntax_2eimport_2eskipWhiteBack(v_s_240, heff_dup(v_a_249), heff_dup(v_i_242)));
          V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_a_249, v_t_2410}), v_acc_245});
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
          V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
          V t_3 = v_b_243;
          V t_4 = v_depth_244;
          V t_5 = v_t_2411;
          v_s_240 = t_0;
          v_from_241 = t_1;
          v_i_242 = t_2;
          v_b_243 = t_3;
          v_depth_244 = t_4;
          v_acc_245 = t_5;
          goto top;
        } else {
          V t_0 = v_s_240;
          V t_1 = v_from_241;
          V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
          V t_3 = v_b_243;
          V t_4 = v_depth_244;
          V t_5 = v_acc_245;
          v_s_240 = t_0;
          v_from_241 = t_1;
          v_i_242 = t_2;
          v_b_243 = t_3;
          v_depth_244 = t_4;
          v_acc_245 = t_5;
          goto top;
        }
      }
    }
  }
}
V g_heff_2esyntax_2eimport_2epiecesGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2epiecesGo(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eoperatorIn_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eimport_2eoperatorIn_24cpr_str1, 2, "..");
HEFF_LIT(g_heff_2esyntax_2eimport_2eoperatorIn_24cpr_str2, 1, " ");

HeffT2 g_heff_2esyntax_2eimport_2eoperatorIn_24cpr(V v_t_240) {
top: ;
  if (((((int64_t)2ULL) < heff_unbox_word(heff_strLength_lent(v_t_240, 0))) && ((heff_unbox_word(heff_strByteAt_lent(v_t_240, MK_INT(0LL), 2)) == ((int64_t)40ULL)) && ({ int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_t_240, 0)) - ((int64_t)1ULL)); int c_ = ({ V v_t_249 = heff_strByteAt_lent(v_t_240, heff_box_word(v_t_241), 2); int c_ = (heff_peek_word(v_t_249) == ((int64_t)41ULL)); heff_drop(v_t_249); c_; }); c_; })))) {
    int64_t v_t_242 = (heff_unbox_word(heff_strLength_lent(v_t_240, 0)) - ((int64_t)1ULL));
    V v_s_243 = heff_strSlice_lent(v_t_240, MK_INT(1LL), heff_box_word(v_t_242), 6);
    V v_t_244 = (g_prelude_2eskipSpaces(v_s_243, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_s_243, 0)) - ((int64_t)1ULL));
    V v_t_246 = (g_prelude_2eskipSpaces(v_s_243, heff_box_word(v_t_245), MK_INT(-1LL)));
    V v_x_247 = heff_strSlice(v_s_243, v_t_244, heff_intAdd(v_t_246, MK_INT(1LL)));
    if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2esyntax_2eimport_2eoperatorIn_24cpr_str0), 2)) {
      heff_drop(v_x_247);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2esyntax_2eimport_2eoperatorIn_24cpr_str1), 2)) {
        heff_drop(v_x_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2esyntax_2eimport_2eoperatorIn_24cpr_str2), v_x_247, MK_INT(0LL), 5))) {
          heff_drop(v_x_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        } else {
          if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_247, 0)))) {
            if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_247, MK_INT(0LL), 2))) ? !(heff_unbox_word(heff_strByteAt_lent(v_x_247, MK_INT(0LL), 2)) <= ((int64_t)57ULL)) : 1)) {
              V v_t_248 = (g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(v_x_247, MK_INT(0LL)));
              if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
                heff_drop(v_x_247);
                heff_drop(v_t_248);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              } else {
                heff_drop(v_t_248);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_247}});
              }
            } else {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_247}});
            }
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_247}});
          }
        }
      }
    }
  } else {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eclaimSays_str0, 54, "a module claim lists names: `x`, `T`, `T(..)`, `(<+>)`");

static V g_heff_2esyntax_2eimport_2eclaimSays_val;
static HEFF_ONCE g_heff_2esyntax_2eimport_2eclaimSays_st;
static V g_heff_2esyntax_2eimport_2eclaimSays_init(void) {
  return ((V)&g_heff_2esyntax_2eimport_2eclaimSays_str0);
}
V g_heff_2esyntax_2eimport_2eclaimSays_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2eimport_2eclaimSays_st)) return g_heff_2esyntax_2eimport_2eclaimSays_val;
  return heff_global(&g_heff_2esyntax_2eimport_2eclaimSays_val, &g_heff_2esyntax_2eimport_2eclaimSays_st, g_heff_2esyntax_2eimport_2eclaimSays_init);
}

HeffT2 g_heff_2esyntax_2eimport_2enameEntry_24cpr(V v_s_240, V v_sp_241, V v_tags_242) {
top: ;
  V v_x_243 = heff_strSlice(heff_dup(v_s_240), heff_dup(heff_rfield(v_sp_241, 0)), heff_dup(heff_rfield(v_sp_241, 1)));
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_243, 0)))) {
    if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_243, MK_INT(0LL), 2))) ? !(heff_unbox_word(heff_strByteAt_lent(v_x_243, MK_INT(0LL), 2)) <= ((int64_t)57ULL)) : 1)) {
      V v_t_244 = (g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(v_x_243, MK_INT(0LL)));
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop(v_t_244);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__tags__span, (V[]){v_x_243, v_tags_242, v_sp_241})}});
      } else {
        heff_drop(v_t_244);
        HeffT2 v_t_245 = ({ V a_0 = v_x_243; HeffT2 r_ = (g_heff_2esyntax_2eimport_2eoperatorIn_24cpr(a_0)); heff_drop(v_x_243); r_; });
        {
          V v_field_247 = v_t_245.f[1];
          int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
          if ((v_tag_246 == ((int64_t)0ULL))) {
            V v_op_248 = v_field_247;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__tags__span, (V[]){v_op_248, v_tags_242, v_sp_241})}});
          } else {
            heff_drop(v_tags_242);
            heff_drop(v_field_247);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_sp_241, heff_dup(g_heff_2esyntax_2eimport_2eclaimSays_get())})}});
          }
        }
      }
    } else {
      HeffT2 v_t_249 = ({ V a_0 = v_x_243; HeffT2 r_ = (g_heff_2esyntax_2eimport_2eoperatorIn_24cpr(a_0)); heff_drop(v_x_243); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_op_2412 = v_field_2411;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__tags__span, (V[]){v_op_2412, v_tags_242, v_sp_241})}});
        } else {
          heff_drop(v_tags_242);
          heff_drop(v_field_2411);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_sp_241, heff_dup(g_heff_2esyntax_2eimport_2eclaimSays_get())})}});
        }
      }
    }
  } else {
    HeffT2 v_t_2413 = ({ V a_0 = v_x_243; HeffT2 r_ = (g_heff_2esyntax_2eimport_2eoperatorIn_24cpr(a_0)); heff_drop(v_x_243); r_; });
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        V v_op_2416 = v_field_2415;
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__tags__span, (V[]){v_op_2416, v_tags_242, v_sp_241})}});
      } else {
        heff_drop(v_tags_242);
        heff_drop(v_field_2415);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_sp_241, heff_dup(g_heff_2esyntax_2eimport_2eclaimSays_get())})}});
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eentryOf_24cpr_str0, 4, "(..)");
HEFF_LIT(g_heff_2esyntax_2eimport_2eentryOf_24cpr_str1, 16, "an empty entry: ");
HEFF_LIT(g_heff_2esyntax_2eimport_2eentryOf_24cpr_str2, 16, "an empty entry: ");

HeffT2 g_heff_2esyntax_2eimport_2eentryOf_24cpr(V v_s_240, V v_sp_241) {
top: ;
  V v_t_242 = heff_intSub(heff_dup(heff_rfield(v_sp_241, 1)), heff_dup(heff_rfield(v_sp_241, 0)));
  if (heff_intLt_c(MK_INT(4LL), v_t_242)) {
    V v_s_243 = heff_strSlice(heff_dup(v_s_240), heff_dup(heff_rfield(v_sp_241, 0)), heff_dup(heff_rfield(v_sp_241, 1)));
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_s_243, 0)) - ((int64_t)4ULL));
    V v_t_245 = heff_strSlice(heff_dup(v_s_243), heff_box_word(v_t_244), heff_strLength(v_s_243));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2esyntax_2eimport_2eentryOf_24cpr_str0))) {
      V v_t_246 = heff_intSub(heff_take_field(v_sp_241, 1), MK_INT(4LL));
      V v_t_247 = (g_heff_2esyntax_2eimport_2eskipWhiteBack(v_s_240, heff_dup(heff_rfield(v_sp_241, 0)), v_t_246));
      V v_t_248 = ({ V rv_1 = v_t_247; V rr_ = heff_rec_reuse_nf(v_sp_241, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return (g_heff_2esyntax_2eimport_2enameEntry_24cpr(v_s_240, v_t_248, NTAG(TAG_True)));
    } else {
      if (heff_intEq_c(heff_dup(heff_rfield(v_sp_241, 1)), heff_dup(heff_rfield(v_sp_241, 0)))) {
        V v_f_249 = heff_rec_n(2, shape_span__msg, (V[]){v_sp_241, heff_strAppend(((V)&g_heff_2esyntax_2eimport_2eentryOf_24cpr_str1), heff_dup(g_heff_2esyntax_2eimport_2eclaimSays_get()))});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
      } else {
        return (g_heff_2esyntax_2eimport_2enameEntry_24cpr(v_s_240, v_sp_241, NTAG(TAG_False)));
      }
    }
  } else {
    if (heff_intEq_c(heff_dup(heff_rfield(v_sp_241, 1)), heff_dup(heff_rfield(v_sp_241, 0)))) {
      V v_f_2410 = heff_rec_n(2, shape_span__msg, (V[]){v_sp_241, heff_strAppend(((V)&g_heff_2esyntax_2eimport_2eentryOf_24cpr_str2), heff_dup(g_heff_2esyntax_2eimport_2eclaimSays_get()))});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
    } else {
      return (g_heff_2esyntax_2eimport_2enameEntry_24cpr(v_s_240, v_sp_241, NTAG(TAG_False)));
    }
  }
}

HeffT2 g_heff_2esyntax_2eimport_2eentriesGo_24cpr(V v_s_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_f_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return ((HeffT2){{v_f_243, NTAG(TAG_Nothing)}});
  }
  case TAG_Cons: {
    V v_sp_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_246 = (g_heff_2esyntax_2eimport_2eentryOf_24cpr(v_s_240, v_sp_244));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_rest_245);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_err_249 = v_field_248;
        V v_f_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
        return ((HeffT2){{v_f_2410, heff_tag_n(TAG_Just, 1, (V[]){v_err_249})}});
      } else {
        V v_x_2411 = v_field_248;
        V t_0 = v_s_240;
        V t_1 = v_rest_245;
        V t_2 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_2411, v_acc_242});
        v_s_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2esyntax_2eimport_2enameEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2enameEnd_entry, 2, 0};

V g_heff_2esyntax_2eimport_2enameEnd(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_s_240, 0))) {
    V v_c_242 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
    if (((heff_peek_word(v_c_242) == ((int64_t)46ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)95ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)45ULL)) || (((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))))))))) {
      heff_drop(v_c_242);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_c_242);
      return v_i_241;
    }
  } else {
    return v_i_241;
  }
}
V g_heff_2esyntax_2eimport_2enameEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2enameEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eclaimListed_24cpr_str0, 0, "");

HeffT2 g_heff_2esyntax_2eimport_2eclaimListed_24cpr(V v_src_240, V v_i_241, V v_name_242, V v_open_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2esyntax_2eimport_2ecloseOf_24cpr(v_src_240, heff_dup(v_open_243), MK_INT(0LL)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_close_247 = v_field_246;
      V v_t_248 = (g_heff_2esyntax_2eimport_2elineEndAt(v_src_240, heff_intAdd(heff_dup(v_close_247), MK_INT(1LL))));
      V v_s_249 = heff_strSlice(heff_dup(v_src_240), heff_intAdd(heff_dup(v_close_247), MK_INT(1LL)), v_t_248);
      V v_t_2410 = (g_prelude_2eskipSpaces(v_s_249, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_s_249, 0)) - ((int64_t)1ULL));
      V v_t_2412 = (g_prelude_2eskipSpaces(v_s_249, heff_box_word(v_t_2411), MK_INT(-1LL)));
      V v_t_2413 = heff_strSlice(v_s_249, v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
      if (heff_strEq_c(v_t_2413, ((V)&g_heff_2esyntax_2eimport_2eclaimListed_24cpr_str0))) {
        V v_t_2414 = (g_heff_2esyntax_2eimport_2eskipWhite(v_src_240, heff_intAdd(heff_dup(v_open_243), MK_INT(1LL)), heff_dup(v_close_247)));
        if (heff_intEq_c_lent(v_t_2414, v_close_247, 1)) {
          heff_drop(v_open_243);
          V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){v_i_241, heff_intAdd(v_close_247, MK_INT(1LL))});
          V v_f_2416 = heff_rec_n(5, shape_name__listed__exposes__span__error, (V[]){v_name_242, NTAG(TAG_True), NTAG(TAG_Nil), v_t_2415, NTAG(TAG_Nothing)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
        } else {
          V v_t_2417 = (g_heff_2esyntax_2eimport_2epiecesGo(v_src_240, heff_intAdd(heff_dup(v_open_243), MK_INT(1LL)), heff_intAdd(v_open_243, MK_INT(1LL)), heff_dup(v_close_247), MK_INT(0LL), NTAG(TAG_Nil)));
          HeffT2 v_t_2418 = (g_heff_2esyntax_2eimport_2eentriesGo_24cpr(v_src_240, v_t_2417, NTAG(TAG_Nil)));
          {
            V v_field_2419 = v_t_2418.f[0];
            V v_field_2420 = v_t_2418.f[1];
            V v_es_2421 = v_field_2419;
            V v_err_2422 = v_field_2420;
            V v_t_2423 = heff_rec_n(2, shape_start__end, (V[]){v_i_241, heff_intAdd(v_close_247, MK_INT(1LL))});
            V v_f_2424 = heff_rec_n(5, shape_name__listed__exposes__span__error, (V[]){v_name_242, NTAG(TAG_True), v_es_2421, v_t_2423, v_err_2422});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
          }
        }
      } else {
        heff_drop(v_i_241);
        heff_drop(v_name_242);
        heff_drop(v_open_243);
        heff_drop(v_close_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_i_241);
      heff_drop(v_name_242);
      heff_drop(v_open_243);
      heff_drop(v_field_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eclaimAt_24cpr_str0, 6, "module");
HEFF_LIT(g_heff_2esyntax_2eimport_2eclaimAt_24cpr_str1, 0, "");

HeffT2 g_heff_2esyntax_2eimport_2eclaimAt_24cpr(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_intAdd(heff_dup(v_i_241), MK_INT(6LL)), heff_strLength_lent(v_src_240, 0))) {
    V v_t_242 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(6LL)));
    if (heff_strEq_c(v_t_242, ((V)&g_heff_2esyntax_2eimport_2eclaimAt_24cpr_str0))) {
      V v_c_243 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(6LL)));
      if (((heff_peek_word(v_c_243) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_243) == ((int64_t)39ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_243)) ? !(heff_peek_word(v_c_243) <= ((int64_t)57ULL)) : 1)))))) {
        heff_drop(v_c_243);
        V v_x_244 = (g_heff_2esyntax_2eimport_2eskipWhite(v_src_240, heff_intAdd(heff_dup(v_i_241), MK_INT(6LL)), heff_strLength_lent(v_src_240, 0)));
        if ((heff_intLt_c(heff_dup(v_x_244), heff_strLength_lent(v_src_240, 0)) && (heff_unbox_word(heff_strByteAt_lent(v_src_240, v_x_244, 0)) == ((int64_t)40ULL)))) {
          return ({ V a_0 = v_src_240; V a_1 = v_i_241; V a_2 = NTAG(TAG_Nothing); V a_3 = v_x_244; HeffT2 r_ = (g_heff_2esyntax_2eimport_2eclaimListed_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_src_240); r_; });
        } else {
          V v_x_245 = (g_heff_2esyntax_2eimport_2enameEnd(v_src_240, heff_dup(v_x_244)));
          if (heff_intEq_c_lent(v_x_245, v_x_244, 0)) {
            heff_drop(v_src_240);
            heff_drop(v_i_241);
            heff_drop(v_x_244);
            heff_drop(v_x_245);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          } else {
            V v_src_246 = v_src_240;
            V v_i_247 = v_i_241;
            V v_j_248 = v_x_244;
            V v_k_249 = v_x_245;
            V v_x_2410 = heff_strSlice_lent(v_src_246, v_j_248, v_k_249, 2);
            V v_x_2411 = (g_heff_2esyntax_2eimport_2eskipWhite(v_src_246, heff_dup(v_k_249), heff_strLength_lent(v_src_246, 0)));
            if ((heff_intLt_c(heff_dup(v_x_2411), heff_strLength_lent(v_src_246, 0)) && (heff_unbox_word(heff_strByteAt_lent(v_src_246, v_x_2411, 0)) == ((int64_t)40ULL)))) {
              heff_drop(v_k_249);
              return ({ V a_0 = v_src_246; V a_1 = v_i_247; V a_2 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2410}); V a_3 = v_x_2411; HeffT2 r_ = (g_heff_2esyntax_2eimport_2eclaimListed_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_src_246); r_; });
            } else {
              heff_drop(v_x_2411);
              V v_t_2412 = (g_heff_2esyntax_2eimport_2elineEndAt(v_src_246, heff_dup(v_k_249)));
              V v_s_2413 = heff_strSlice_lent(v_src_246, v_k_249, v_t_2412, 5);
              V v_t_2414 = (g_prelude_2eskipSpaces(v_s_2413, MK_INT(0LL), MK_INT(1LL)));
              int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_s_2413, 0)) - ((int64_t)1ULL));
              V v_t_2416 = (g_prelude_2eskipSpaces(v_s_2413, heff_box_word(v_t_2415), MK_INT(-1LL)));
              V v_t_2417 = heff_strSlice(v_s_2413, v_t_2414, heff_intAdd(v_t_2416, MK_INT(1LL)));
              if (heff_strEq_c(v_t_2417, ((V)&g_heff_2esyntax_2eimport_2eclaimAt_24cpr_str1))) {
                V v_t_2418 = heff_rec_n(5, shape_name__listed__exposes__span__error, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2410}), NTAG(TAG_False), NTAG(TAG_Nil), heff_rec_n(2, shape_start__end, (V[]){v_i_247, v_k_249}), NTAG(TAG_Nothing)});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2418}});
              } else {
                heff_drop(v_i_247);
                heff_drop(v_k_249);
                heff_drop(v_x_2410);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          }
        }
      } else {
        heff_drop(v_src_240);
        heff_drop(v_i_241);
        heff_drop(v_c_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_src_240);
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  } else {
    heff_drop(v_src_240);
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
Clo g_heff_2esyntax_2eimport_2edoneI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2edoneI_entry, 3, 0};

V g_heff_2esyntax_2eimport_2edoneI(V v_src_240, V v_claim_241, V v_acc_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_acc_242)));
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  V v_s_245 = ({ V a_0 = v_src_240; V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s947555161x768980202(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_2413;
  switch (heff_tag_of(v_claim_241)) {
  case TAG_Nothing: {
    v_t_2413 = v_s_245;
    break;
  }
  case TAG_Just: {
    V v_h_246 = heff_dup(heff_field(v_claim_241, 0));
    V v_sp_247 = heff_get_n(v_h_246, 3, 5);
    V v_start_248 = heff_take_field(v_sp_247, 0);
    V v_end_249 = heff_get_n(v_sp_247, 1, 2);
    V v_t_2410 = (g_heff_2esyntax_2eimport_2espaces(heff_intSub(heff_dup(v_end_249), heff_dup(v_start_248))));
    V v_t_2411 = heff_strAppend(heff_strSlice_lent(v_s_245, MK_INT(0LL), v_start_248, 6), v_t_2410);
    V v_t_2412 = heff_strSlice(heff_dup(v_s_245), v_end_249, heff_strLength(v_s_245));
    v_t_2413 = heff_strAppend(v_t_2411, v_t_2412);
    break;
  }
  default: heff_nomatch(v_claim_241);
  }
  return heff_rec_n(4, shape_imports__implicit__claim__text, (V[]){v_t_243, NTAG(TAG_Nil), v_claim_241, v_t_2413});
}
V g_heff_2esyntax_2eimport_2edoneI_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2edoneI(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportsGo_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportsGo_str1, 2, "--");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportsGo_str2, 6, "import");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportsGo_str3, 2, "as");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportsGo_str4, 6, "module");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimportsGo_str5, 48, "the module claim comes first, before its imports");
V g_heff_2esyntax_2eimport_2eimportsGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2eimport_2eimportsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eimportsGo_entry, 4, 0};

V g_heff_2esyntax_2eimport_2eimportsGo(V v_src_240, V v_i_241, V v_claim_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return (g_heff_2esyntax_2eimport_2edoneI(v_src_240, v_claim_242, v_acc_243));
  } else {
    V v_x_244 = (g_heff_2esyntax_2eimport_2elineEndAt(v_src_240, heff_dup(v_i_241)));
    V v_x_245 = heff_strSlice_lent(v_src_240, v_i_241, v_x_244, 0);
    V v_t_246 = (g_prelude_2eskipSpaces(v_x_245, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_x_245, 0)) - ((int64_t)1ULL));
    V v_t_248 = (g_prelude_2eskipSpaces(v_x_245, heff_box_word(v_t_247), MK_INT(-1LL)));
    V v_x_249 = heff_strSlice(heff_dup(v_x_245), v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
    if ((heff_strEq_c_lent(v_x_249, ((V)&g_heff_2esyntax_2eimport_2eimportsGo_str0), 2) || heff_strEq_c(heff_strSlice_lent(v_x_249, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2esyntax_2eimport_2eimportsGo_str1)))) {
      heff_drop(v_i_241);
      heff_drop(v_x_245);
      heff_drop(v_x_249);
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_x_244, MK_INT(1LL));
      V t_2 = v_claim_242;
      V t_3 = v_acc_243;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_claim_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_249);
      V v_w_2410 = ((V)&g_heff_2esyntax_2eimport_2eimportsGo_str2);
      V v_line_2411 = heff_dup(v_x_245);
      V v_t_2412 = heff_strSlice(heff_dup(v_line_2411), MK_INT(0LL), heff_strLength_lent(v_w_2410, 0));
      V v_t_2414;
      if (heff_strEq_c_lent(v_t_2412, v_w_2410, 1)) {
        if ((heff_unbox_word(heff_strLength_lent(v_w_2410, 0)) < heff_unbox_word(heff_strLength_lent(v_line_2411, 0)))) {
          V v_c_2413 = heff_strByteAt(v_line_2411, heff_strLength(v_w_2410));
          v_t_2414 = heff_bool(((heff_peek_word(v_c_2413) == ((int64_t)32ULL)) || ((heff_peek_word(v_c_2413) == ((int64_t)9ULL)) || ((heff_peek_word(v_c_2413) == ((int64_t)10ULL)) || (heff_peek_word(v_c_2413) == ((int64_t)13ULL))))));
          heff_drop(v_c_2413);
        } else {
          heff_drop(v_w_2410);
          heff_drop(v_line_2411);
          v_t_2414 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_w_2410);
        heff_drop(v_line_2411);
        v_t_2414 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_i_2415 = v_i_241;
        V v_e_2416 = heff_dup(v_x_244);
        V v_t_2417 = heff_strSlice(heff_dup(v_x_245), MK_INT(6LL), heff_strLength(v_x_245));
        V v_x3_2418 = ({ V a_0 = v_t_2417; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewordsFrom(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); r_; });
        V v_t_2434;
        switch (heff_tag_of(v_x3_2418)) {
        case TAG_Nil: {
          heff_drop(v_i_2415);
          heff_drop(v_e_2416);
          v_t_2434 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_m_2419 = heff_field(v_x3_2418, 0);
          V v_x32_2420 = heff_field(v_x3_2418, 1);
          heff_take_n(v_x3_2418, 3ULL, 2);
          switch (heff_tag_of(v_x32_2420)) {
          case TAG_Nil: {
            if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_m_2419, 0)))) {
              V v_t_2421 = (g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(v_m_2419, MK_INT(0LL)));
              if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
                heff_drop(v_t_2421);
                V v_t_2422 = heff_rec_n(3, shape_name__alias__span, (V[]){v_m_2419, NTAG(TAG_Nothing), heff_rec_n(2, shape_start__end, (V[]){v_i_2415, v_e_2416})});
                v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2422});
              } else {
                heff_drop(v_i_2415);
                heff_drop(v_e_2416);
                heff_drop(v_m_2419);
                heff_drop(v_t_2421);
                v_t_2434 = NTAG(TAG_Nothing);
              }
            } else {
              heff_drop(v_i_2415);
              heff_drop(v_e_2416);
              heff_drop(v_m_2419);
              v_t_2434 = NTAG(TAG_Nothing);
            }
            break;
          }
          case TAG_Cons: {
            V v_x321_2423 = heff_field(v_x32_2420, 0);
            V v_x322_2424 = heff_field(v_x32_2420, 1);
            heff_take_n(v_x32_2420, 3ULL, 2);
            if (heff_strEq_c(v_x321_2423, ((V)&g_heff_2esyntax_2eimport_2eimportsGo_str3))) {
              switch (heff_tag_of(v_x322_2424)) {
              case TAG_Nil: {
                heff_drop(v_i_2415);
                heff_drop(v_e_2416);
                heff_drop(v_m_2419);
                v_t_2434 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Cons: {
                V v_a_2425 = heff_field(v_x322_2424, 0);
                V v_x3222_2426 = heff_field(v_x322_2424, 1);
                heff_take_n(v_x322_2424, 3ULL, 2);
                switch (heff_tag_of(v_x3222_2426)) {
                case TAG_Nil: {
                  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_m_2419, 0)))) {
                    V v_t_2427 = (g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(v_m_2419, MK_INT(0LL)));
                    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
                      heff_drop(v_t_2427);
                      V v_x_2428 = heff_dup(v_a_2425);
                      V v_t_2430;
                      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_2428, 0)))) {
                        if ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_2428, MK_INT(0LL), 2)))) {
                          if ((heff_unbox_word(heff_strByteAt_lent(v_x_2428, MK_INT(0LL), 2)) <= ((int64_t)90ULL))) {
                            V v_x1_2429 = (g_heff_2esyntax_2eimport_2ehasDot(v_x_2428, MK_INT(0LL)));
                            if (!(heff_dup(v_x1_2429) == NTAG(TAG_True))) {
                              heff_drop(v_x1_2429);
                              if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_2428, 0)))) {
                                v_t_2430 = ({ V a_0 = v_x_2428; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2eimport_2eallChars_24s1213243865x432450295(a_0, a_1)); heff_drop(v_x_2428); r_; });
                              } else {
                                heff_drop(v_x_2428);
                                v_t_2430 = NTAG(TAG_False);
                              }
                            } else {
                              heff_drop(v_x_2428);
                              heff_drop(v_x1_2429);
                              v_t_2430 = NTAG(TAG_False);
                            }
                          } else {
                            heff_drop(v_x_2428);
                            v_t_2430 = NTAG(TAG_False);
                          }
                        } else {
                          heff_drop(v_x_2428);
                          v_t_2430 = NTAG(TAG_False);
                        }
                      } else {
                        heff_drop(v_x_2428);
                        v_t_2430 = NTAG(TAG_False);
                      }
                      if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
                        heff_drop(v_t_2430);
                        V v_t_2431 = heff_rec_n(3, shape_name__alias__span, (V[]){v_m_2419, heff_tag_n(TAG_Just, 1, (V[]){v_a_2425}), heff_rec_n(2, shape_start__end, (V[]){v_i_2415, v_e_2416})});
                        v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2431});
                      } else {
                        heff_drop(v_i_2415);
                        heff_drop(v_e_2416);
                        heff_drop(v_m_2419);
                        heff_drop(v_a_2425);
                        heff_drop(v_t_2430);
                        v_t_2434 = NTAG(TAG_Nothing);
                      }
                    } else {
                      heff_drop(v_i_2415);
                      heff_drop(v_e_2416);
                      heff_drop(v_m_2419);
                      heff_drop(v_a_2425);
                      heff_drop(v_t_2427);
                      v_t_2434 = NTAG(TAG_Nothing);
                    }
                  } else {
                    heff_drop(v_i_2415);
                    heff_drop(v_e_2416);
                    heff_drop(v_m_2419);
                    heff_drop(v_a_2425);
                    v_t_2434 = NTAG(TAG_Nothing);
                  }
                  break;
                }
                case TAG_Cons: {
                  heff_take_n(v_x3222_2426, 0ULL, 2);
                  heff_drop(v_i_2415);
                  heff_drop(v_e_2416);
                  heff_drop(v_m_2419);
                  heff_drop(v_a_2425);
                  v_t_2434 = NTAG(TAG_Nothing);
                  break;
                }
                default: heff_nomatch(v_x3222_2426);
                }
                break;
              }
              default: heff_nomatch(v_x322_2424);
              }
            } else {
              heff_drop(v_i_2415);
              heff_drop(v_e_2416);
              heff_drop(v_m_2419);
              heff_drop(v_x322_2424);
              v_t_2434 = NTAG(TAG_Nothing);
            }
            break;
          }
          default: heff_nomatch(v_x32_2420);
          }
          break;
        }
        default: heff_nomatch(v_x3_2418);
        }
        switch (heff_tag_of(v_t_2434)) {
        case TAG_Nothing: {
          heff_drop(v_x_244);
          return (g_heff_2esyntax_2eimport_2edoneI(v_src_240, v_claim_242, v_acc_243));
        }
        case TAG_Just: {
          V v_imp_2435 = heff_field(v_t_2434, 0);
          heff_take_n(v_t_2434, 1ULL, 1);
          V t_0 = v_src_240;
          V t_1 = heff_intAdd(v_x_244, MK_INT(1LL));
          V t_2 = v_claim_242;
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_imp_2435, v_acc_243});
          v_src_240 = t_0;
          v_i_241 = t_1;
          v_claim_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_t_2434);
        }
      } else {
        heff_drop(v_x_244);
        heff_drop(v_t_2414);
        if (heff_strEq_c(heff_strSlice(v_x_245, MK_INT(0LL), MK_INT(6LL)), ((V)&g_heff_2esyntax_2eimport_2eimportsGo_str4))) {
          V v_src_2436 = heff_dup(v_src_240);
          V v_i_2437 = v_i_241;
          V v_claim_2438 = v_claim_242;
          V v_acc_2439 = heff_dup(v_acc_243);
          V v_again_2442 = heff_clo_n(g_heff_2esyntax_2eimport_2eimportsGo_lam0, 2, 2, (V[]){v_src_240, v_acc_243});
          switch (heff_tag_of(v_claim_2438)) {
          case TAG_Nothing: {
            HeffT2 v_t_2443 = (g_heff_2esyntax_2eimport_2eclaimAt_24cpr(heff_dup(v_src_2436), v_i_2437));
            {
              V v_field_2445 = v_t_2443.f[1];
              int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
              if ((v_tag_2444 == ((int64_t)0ULL))) {
                V v_h_2446 = v_field_2445;
                V v_t_2450;
                switch (heff_tag_of(v_acc_2439)) {
                case TAG_Nil: {
                  v_t_2450 = heff_dup(v_h_2446);
                  break;
                }
                case TAG_Cons: {
                  heff_take_n(v_acc_2439, 0ULL, 2);
                  V v_t_2449 = heff_rec_n(2, shape_span__msg, (V[]){heff_dup(heff_rfield(v_h_2446, 3)), ((V)&g_heff_2esyntax_2eimport_2eimportsGo_str5)});
                  v_t_2450 = heff_rec_n(5, shape_name__listed__exposes__span__error, (V[]){heff_dup(heff_rfield(v_h_2446, 0)), heff_dup(heff_rfield(v_h_2446, 1)), heff_dup(heff_rfield(v_h_2446, 2)), heff_dup(heff_rfield(v_h_2446, 3)), heff_tag_n(TAG_Just, 1, (V[]){v_t_2449})});
                  break;
                }
                default: heff_nomatch(v_acc_2439);
                }
                V v_t_2451 = heff_get_n(heff_get_n(v_h_2446, 3, 5), 1, 2);
                V v_t_2452 = ({ V a_0 = v_src_2436; V a_1 = v_t_2451; V r_ = (g_heff_2esyntax_2eimport_2elineEndAt(a_0, a_1)); heff_drop(v_src_2436); r_; });
                return heff_tail(v_again_2442, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_2450}), heff_intAdd(v_t_2452, MK_INT(1LL))});
              } else {
                heff_drop_clo(v_again_2442, 2);
                heff_drop(v_field_2445);
                V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_acc_2439)));
                V v_t_2454 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_2439));
                V v_s_2455 = ({ V a_0 = v_src_2436; V a_1 = v_t_2454; V r_ = (g_list_2efoldl_24s947555161x768980202(a_0, a_1)); heff_drop(v_t_2454); r_; });
                return heff_rec_n(4, shape_imports__implicit__claim__text, (V[]){v_t_2453, NTAG(TAG_Nil), NTAG(TAG_Nothing), v_s_2455});
              }
            }
          }
          case TAG_Just: {
            heff_drop(v_i_2437);
            heff_drop_clo(v_again_2442, 2);
            return (g_heff_2esyntax_2eimport_2edoneI(v_src_2436, v_claim_2438, v_acc_2439));
          }
          default: return heff_nomatch(v_claim_2438);
          }
        } else {
          heff_drop(v_i_241);
          return (g_heff_2esyntax_2eimport_2edoneI(v_src_240, v_claim_242, v_acc_243));
        }
      }
    }
  }
}
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2eimportsGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2eimport_2eimportsGo_lam0(V self, V *args) {
  V v_h_2440 = args[0];
  V v_j_2441 = args[1];
  V v_src_240 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, v_j_2441, v_h_2440, v_acc_243));
}
HEFF_LIT(g_heff_2esyntax_2eimport_2eimplicitImports_str0, 7, "builtin");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimplicitImports_str1, 7, "prelude");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimplicitImports_str2, 4, "list");
HEFF_LIT(g_heff_2esyntax_2eimport_2eimplicitImports_str3, 4, "List");

static V g_heff_2esyntax_2eimport_2eimplicitImports_val;
static HEFF_ONCE g_heff_2esyntax_2eimport_2eimplicitImports_st;
static V g_heff_2esyntax_2eimport_2eimplicitImports_init(void) {
  V v_t_240 = heff_rec_n(3, shape_name__alias__span, (V[]){((V)&g_heff_2esyntax_2eimport_2eimplicitImports_str0), NTAG(TAG_Nothing), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  V v_t_241 = heff_rec_n(3, shape_name__alias__span, (V[]){((V)&g_heff_2esyntax_2eimport_2eimplicitImports_str1), NTAG(TAG_Nothing), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  V v_t_242 = heff_rec_n(3, shape_name__alias__span, (V[]){((V)&g_heff_2esyntax_2eimport_2eimplicitImports_str2), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2eimport_2eimplicitImports_str3)}), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_243})});
}
V g_heff_2esyntax_2eimport_2eimplicitImports_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2eimport_2eimplicitImports_st)) return g_heff_2esyntax_2eimport_2eimplicitImports_val;
  return heff_global(&g_heff_2esyntax_2eimport_2eimplicitImports_val, &g_heff_2esyntax_2eimport_2eimplicitImports_st, g_heff_2esyntax_2eimport_2eimplicitImports_init);
}

static V g_heff_2esyntax_2eimport_2eimplicitModules_val;
static HEFF_ONCE g_heff_2esyntax_2eimport_2eimplicitModules_st;
static V g_heff_2esyntax_2eimport_2eimplicitModules_init(void) {
  return (g_list_2emap_24s1817208647x1282894070(heff_dup(g_heff_2esyntax_2eimport_2eimplicitImports_get())));
}
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2eimport_2eimplicitModules_st)) return g_heff_2esyntax_2eimport_2eimplicitModules_val;
  return heff_global(&g_heff_2esyntax_2eimport_2eimplicitModules_val, &g_heff_2esyntax_2eimport_2eimplicitModules_st, g_heff_2esyntax_2eimport_2eimplicitModules_init);
}
Clo g_heff_2esyntax_2eimport_2eimportsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2eimportsOf_entry, 2, 0};

V g_heff_2esyntax_2eimport_2eimportsOf(V v_ms_240, V v_src_241) {
top: ;
  V v_r_242 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_241, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ms_240)));
  V v_t_244 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s2063245892x1543682505(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, heff_take_field(v_r_242, 0)));
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_240));
  V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s2063245892x1543682505(a_0, a_1)); heff_drop(v_t_246); r_; });
  return ({ V rv_0 = v_t_245; V rv_1 = v_t_247; V rr_ = heff_rec_reuse_nf(v_r_242, 12ULL, 4, shape_imports__implicit__claim__text, 240u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eimport_2eimportsOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2eimport_2erenameTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2erenameTo_entry, 2, 0};

V g_heff_2esyntax_2eimport_2erenameTo(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_x_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_from_244 = heff_field(v_x11_242, 0);
      V v_to_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c_lent(v_from_244, v_x_241, 0)) {
        heff_drop(v_x_241);
        return heff_dup(v_to_245);
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2eimport_2erenameTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2erenameTo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2eimport_2erenamed_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2eimport_2erenamed_24cpr_lam1(V self, V *args);

HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V v_rs_240, V v_imps_241) {
top: ;
  V v_imports_242 = heff_take_field(v_imps_241, 0);
  V v_implicit_243 = heff_take_field(v_imps_241, 1);
  V v_claim_244 = heff_take_field(v_imps_241, 2);
  V v_text_245 = heff_get_n(v_imps_241, 3, 4);
  V v_f_249 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eimport_2erenamed_24cpr_lam0, 1, 1, (V[]){heff_dup(v_rs_240)}), v_imports_242));
  V v_f_2413 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eimport_2erenamed_24cpr_lam1, 1, 1, (V[]){heff_dup(v_rs_240)}), v_implicit_243));
  V v_f_2414 = v_claim_244;
  V v_f_2415 = v_text_245;
  return ((HeffT4){{v_f_249, v_f_2413, v_f_2414, v_f_2415}});
}
V g_heff_2esyntax_2eimport_2erenamed_24cpr_lam0(V self, V *args) {
  V v_i_246 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_name_247 = ({ V a_0 = v_rs_240; V a_1 = heff_take_field(v_i_246, 0); V r_ = (g_heff_2esyntax_2eimport_2erenameTo(a_0, a_1)); heff_drop(v_rs_240); r_; });
  V v_span_248 = heff_take_field(v_i_246, 2);
  return ({ V rv_0 = v_name_247; V rv_2 = v_span_248; V rr_ = heff_rec_reuse_nf(v_i_246, 2ULL, 3, shape_name__alias__span, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2esyntax_2eimport_2erenamed_24cpr_lam1(V self, V *args) {
  V v_i_2410 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_name_2411 = ({ V a_0 = v_rs_240; V a_1 = heff_take_field(v_i_2410, 0); V r_ = (g_heff_2esyntax_2eimport_2erenameTo(a_0, a_1)); heff_drop(v_rs_240); r_; });
  V v_span_2412 = heff_take_field(v_i_2410, 2);
  return ({ V rv_0 = v_name_2411; V rv_2 = v_span_2412; V rr_ = heff_rec_reuse_nf(v_i_2410, 2ULL, 3, shape_name__alias__span, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
}
Clo g_heff_2esyntax_2eimport_2erenamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eimport_2erenamed_entry, 2, 0};

V g_heff_2esyntax_2eimport_2erenamed(V v_rs_240, V v_imps_241) {
top: ;
  HeffT4 v_t_242 = (g_heff_2esyntax_2eimport_2erenamed_24cpr(v_rs_240, v_imps_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_field_246 = v_t_242.f[3];
    return heff_rec_n(4, shape_imports__implicit__claim__text, (V[]){v_field_243, v_field_244, v_field_245, v_field_246});
  }
}
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eimport_2erenamed(a0, a[1]); heff_drop(a0); return r;
}