// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Leaf 13717
#define TAG_MkArm 55352
#define TAG_Plus 9189
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_defs 9574869
#define LBL_emitted 749050271
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_facts 298546081
#define LBL_fresh 299054408
#define LBL_gs 10067
#define LBL_js 10160
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_pre 320797
#define LBL_prec 9944807
#define LBL_source 1050636102
#define LBL_text 10052084
static uint32_t shape_code__prec[] = {LBL_code, LBL_prec};
static uint32_t shape_emitted__fresh[] = {LBL_emitted, LBL_fresh};
static uint32_t shape_entries__fresh[] = {LBL_entries, LBL_fresh};
static uint32_t shape_js__arity__lazy__bounce[] = {LBL_js, LBL_arity, LBL_lazy, LBL_bounce};
static uint32_t shape_lines__env[] = {LBL_lines, LBL_env};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eemit_2earmJs(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmJs_clo;
V g_heff_2ecompile_2eemit_2eassembled(V, V, V);
V g_heff_2ecompile_2eemit_2eassembled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eassembled_clo;
V g_heff_2ecompile_2eemit_2ebindName(V, V);
V g_heff_2ecompile_2eemit_2ebindName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindName_clo;
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(V, V, V);
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_clo;
V g_heff_2ecompile_2eemit_2ebounceGive(V, V, V);
V g_heff_2ecompile_2eemit_2ebounceGive_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebounceGive_clo;
V g_heff_2ecompile_2eemit_2ebundleAll(V, V);
V g_heff_2ecompile_2eemit_2ebundleAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleAll_clo;
V g_heff_2ecompile_2eemit_2ecallName(V, V);
V g_heff_2ecompile_2eemit_2ecallName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallName_clo;
V g_heff_2ecompile_2eemit_2ecallsHelper(V, V);
V g_heff_2ecompile_2eemit_2ecallsHelper_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallsHelper_clo;
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707(V, V, V);
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_clo;
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519(V, V, V);
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(V, V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_clo;
V g_heff_2ecompile_2eemit_2ecellPrim(V, V);
V g_heff_2ecompile_2eemit_2ecellPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecellPrim_clo;
V g_heff_2ecompile_2eemit_2ecompileJsWith(V, V);
V g_heff_2ecompile_2eemit_2ecompileJsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJsWith_clo;
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(V, V, V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_clo;
V g_heff_2ecompile_2eemit_2eemitKept(V, V, V, V);
V g_heff_2ecompile_2eemit_2eemitKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eemitKept_clo;
V g_heff_2ecompile_2eemit_2eemitKeptIn(V, V, V, V);
V g_heff_2ecompile_2eemit_2eemitKeptIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eemitKeptIn_clo;
V g_heff_2ecompile_2eemit_2eextStr_get(void);
V g_heff_2ecompile_2eemit_2ehandlerOf(V, V);
V g_heff_2ecompile_2eemit_2ehandlerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehandlerOf_clo;
V g_heff_2ecompile_2eemit_2eifLines(V, V, V, V);
V g_heff_2ecompile_2eemit_2eifLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eifLines_clo;
V g_heff_2ecompile_2eemit_2eimportLinesOf(V);
V g_heff_2ecompile_2eemit_2eimportLinesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eimportLinesOf_clo;
V g_heff_2ecompile_2eemit_2einfoOne(V, V, V, V);
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2einfoOne_clo;
V g_heff_2ecompile_2eemit_2ejsAt(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ejsAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsAt_clo;
V g_heff_2ecompile_2eemit_2ejsNameOf(V, V);
V g_heff_2ecompile_2eemit_2ejsNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsNameOf_clo;
V g_heff_2ecompile_2eemit_2ejsSource(V, V);
V g_heff_2ecompile_2eemit_2ejsSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsSource_clo;
V g_heff_2ecompile_2eemit_2ejsVer(V, V, V);
V g_heff_2ecompile_2eemit_2ejsVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsVer_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2eletBound(V, V, V);
V g_heff_2ecompile_2eemit_2eletBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eletBound_clo;
V g_heff_2ecompile_2eemit_2eloops(V);
V g_heff_2ecompile_2eemit_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eloops_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2enubGo_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2enubGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_24dps_clo;
V g_heff_2ecompile_2eemit_2eprimCall(V, V);
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimCall_clo;
V g_heff_2ecompile_2eemit_2eprimOp(V);
V g_heff_2ecompile_2eemit_2eprimOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimOp_clo;
V g_heff_2ecompile_2eemit_2eprimTest(V, V, V);
V g_heff_2ecompile_2eemit_2eprimTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimTest_clo;
V g_heff_2ecompile_2eemit_2eprimUnary(V);
V g_heff_2ecompile_2eemit_2eprimUnary_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimUnary_clo;
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584(V, V, V, V);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_clo;
V g_heff_2ecompile_2eemit_2eprovIndexGo(V, V, V);
V g_heff_2ecompile_2eemit_2eprovIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovIndexGo_clo;
V g_heff_2ecompile_2eemit_2eprovStrHelpers(V, V);
V g_heff_2ecompile_2eemit_2eprovStrHelpers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovStrHelpers_clo;
V g_heff_2ecompile_2eemit_2erunStr_get(void);
V g_heff_2ecompile_2eemit_2eruntime(V);
V g_heff_2ecompile_2eemit_2eruntime_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntime_clo;
V g_heff_2ecompile_2eemit_2eruntimeFor(V, V, V, V);
V g_heff_2ecompile_2eemit_2eruntimeFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntimeFor_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeRes(V);
V g_heff_2ecompile_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeRes_clo;
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(V, V, V);
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_clo;
V g_heff_2ecompile_2eemit_2eseqsOf(V);
V g_heff_2ecompile_2eemit_2eseqsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eseqsOf_clo;
V g_heff_2ecompile_2eemit_2esetStmt(V, V, V, V);
V g_heff_2ecompile_2eemit_2esetStmt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esetStmt_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(V, V, V);
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_clo;
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577(V, V, V);
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_clo;
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(V, V, V, V);
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_clo;
V g_heff_2ecompile_2eemit_2estrHelpers_get(void);
V g_heff_2ecompile_2eemit_2esumStr_get(void);
V g_heff_2ecompile_2eemit_2eswitchLines(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2eswitchLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eswitchLines_clo;
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(V, V, V);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V, V, V);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo;
V g_heff_2ecompile_2eemit_2eworldStr_get(void);
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2elower_2elowerErased(V, V);
V g_heff_2ecompile_2elower_2elowerErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerErased_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s184951243x1948563855(V);
V g_list_2eany_24s184951243x1948563855_entry(V self, V *a);
extern Clo g_list_2eany_24s184951243x1948563855_clo;
V g_list_2efilter_24s1820448628x561773228(V, V, V, V);
V g_list_2efilter_24s1820448628x561773228_entry(V self, V *a);
extern Clo g_list_2efilter_24s1820448628x561773228_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2118756600x1920057229(V, V);
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s963266017x1719814548(V, V);
V g_list_2efoldl_24s963266017x1719814548_entry(V self, V *a);
extern Clo g_list_2efoldl_24s963266017x1719814548_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s357242026x384251201(V);
V g_list_2emap_24s357242026x384251201_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2estrFind(V, V, V);
V g_prelude_2estrFind_entry(V self, V *a);
extern Clo g_prelude_2estrFind_clo;
Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecatMaybesL_entry, 1, 0};

V g_heff_2ecompile_2eemit_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecatMaybesL(a[0]);
}
Clo g_heff_2ecompile_2eemit_2enubGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enubGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2enubGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_list_2eany(v_t_244, v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_xs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2eemit_2enubGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_xs_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enubGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str0, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str5, 10, " \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str6, 1, " ");
Clo g_heff_2ecompile_2eemit_2eprimTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimTest_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprimTest(V v_op_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_245;
  if (heff_intLt_c(heff_dup(heff_rfield(v_a_241, 1)), MK_INT(2LL))) {
    V v_t_244 = heff_strAppend(heff_get_n(v_a_241, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimTest_str0));
    v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str1), v_t_244);
  } else {
    v_t_245 = heff_get_n(v_a_241, 0, 2);
  }
  V v_t_248;
  if (heff_intLt_c(heff_dup(heff_rfield(v_b_242, 1)), MK_INT(2LL))) {
    V v_t_247 = heff_strAppend(heff_get_n(v_b_242, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimTest_str2));
    v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str3), v_t_247);
  } else {
    v_t_248 = heff_get_n(v_b_242, 0, 2);
  }
  V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str4), heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemit_2eprimTest_str5)));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str6), heff_strAppend(v_op_240, v_t_249));
  return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_245, v_t_2410), MK_INT(0LL)});
}
V g_heff_2ecompile_2eemit_2eprimTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimTest(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str4, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str8, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str9, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str11, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str14, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str16, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str17, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str18, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str19, 1, "$");
Clo g_heff_2ecompile_2eemit_2eprimCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimCall_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprimCall(V v_p_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_as_241)) {
  case TAG_Nil: {
    V v_x2_242 = (g_list_2emap_24s357242026x384251201(v_as_241));
    V v_t_245;
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str2), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str3)));
    V v_code_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str4), heff_strAppend(v_p_240, v_t_246));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_247, MK_INT(3LL)});
  }
  case TAG_Cons: {
    V v_a_248 = heff_dup(heff_field(v_as_241, 0));
    V v_as2_249 = heff_dup(heff_field(v_as_241, 1));
    switch (heff_tag_of(v_as2_249)) {
    case TAG_Nil: {
      V v_t_2410 = (g_heff_2ecompile_2eemit_2eprimUnary(heff_dup(v_p_240)));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nothing: {
        heff_drop(v_a_248);
        V v_x2_2411 = (g_list_2emap_24s357242026x384251201(v_as_241));
        V v_t_2414;
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_Nil: {
          v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_x2_2411, 0);
          V v_xs_2413 = heff_field(v_x2_2411, 1);
          heff_take_n(v_x2_2411, 3ULL, 2);
          v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str6); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2411);
        }
        V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str7), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str8)));
        V v_code_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str9), heff_strAppend(v_p_240, v_t_2415));
        return heff_rec_n(2, shape_code__prec, (V[]){v_code_2416, MK_INT(3LL)});
      }
      case TAG_Just: {
        V v_f_2417 = heff_field(v_t_2410, 0);
        heff_take_n(v_t_2410, 1ULL, 1);
        heff_drop(v_p_240);
        heff_drop_tag(v_as_241, 2);
        return heff_tail(v_f_2417, 1, (V[]){v_a_248});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_Cons: {
      V v_b_2418 = heff_field(v_as2_249, 0);
      V v_as22_2419 = heff_field(v_as2_249, 1);
      heff_take_n(v_as2_249, 3ULL, 2);
      switch (heff_tag_of(v_as22_2419)) {
      case TAG_Nil: {
        V v_t_2420 = (g_heff_2ecompile_2eemit_2eprimOp(heff_dup(v_p_240)));
        switch (heff_tag_of(v_t_2420)) {
        case TAG_Nothing: {
          heff_drop(v_a_248);
          heff_drop(v_b_2418);
          V v_x2_2421 = (g_list_2emap_24s357242026x384251201(v_as_241));
          V v_t_2424;
          switch (heff_tag_of(v_x2_2421)) {
          case TAG_Nil: {
            v_t_2424 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str10);
            break;
          }
          case TAG_Cons: {
            V v_x_2422 = heff_field(v_x2_2421, 0);
            V v_xs_2423 = heff_field(v_x2_2421, 1);
            heff_take_n(v_x2_2421, 3ULL, 2);
            v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str11); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2421);
          }
          V v_t_2425 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str12), heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str13)));
          V v_code_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str14), heff_strAppend(v_p_240, v_t_2425));
          return heff_rec_n(2, shape_code__prec, (V[]){v_code_2426, MK_INT(3LL)});
        }
        case TAG_Just: {
          V v_f_2427 = heff_field(v_t_2420, 0);
          heff_take_n(v_t_2420, 1ULL, 1);
          heff_drop(v_p_240);
          heff_drop_tag(v_as_241, 2);
          return heff_tail(v_f_2427, 2, (V[]){v_a_248, v_b_2418});
        }
        default: return heff_nomatch(v_t_2420);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_as22_2419, 0ULL, 2);
        heff_drop(v_a_248);
        heff_drop(v_b_2418);
        V v_x2_2430 = (g_list_2emap_24s357242026x384251201(v_as_241));
        V v_t_2433;
        switch (heff_tag_of(v_x2_2430)) {
        case TAG_Nil: {
          v_t_2433 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str15);
          break;
        }
        case TAG_Cons: {
          V v_x_2431 = heff_field(v_x2_2430, 0);
          V v_xs_2432 = heff_field(v_x2_2430, 1);
          heff_take_n(v_x2_2430, 3ULL, 2);
          v_t_2433 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str16); V a_1 = v_x_2431; V a_2 = v_xs_2432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2432); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2430);
        }
        V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str17), heff_strAppend(v_t_2433, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str18)));
        V v_code_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str19), heff_strAppend(v_p_240, v_t_2434));
        return heff_rec_n(2, shape_code__prec, (V[]){v_code_2435, MK_INT(3LL)});
      }
      default: return heff_nomatch(v_as22_2419);
      }
    }
    default: return heff_nomatch(v_as2_249);
    }
  }
  default: return heff_nomatch(v_as_241);
  }
}
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimCall(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2ecallsHelper_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecallsHelper_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecallsHelper(V v_p_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_as_241)) {
  case TAG_Nil: {
    V v_x1_242 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_242) == NTAG(TAG_True)));
    heff_drop(v_x1_242);
    return v_ret_24bool;
  }
  case TAG_Cons: {
    V v_as2_244 = heff_field(v_as_241, 1);
    switch (heff_tag_of(v_as2_244)) {
    case TAG_Nil: {
      V v_x3_245 = (g_heff_2ecompile_2eemit_2eprimUnary(v_p_240));
      switch (heff_tag_of(v_x3_245)) {
      case TAG_Nothing: {
        return NTAG(TAG_True);
      }
      case TAG_Just: {
        heff_take_n(v_x3_245, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x3_245);
      }
    }
    case TAG_Cons: {
      V v_as21_247 = heff_field(v_as2_244, 0);
      V v_as22_248 = heff_field(v_as2_244, 1);
      switch (heff_tag_of(v_as21_247)) {
      case TAG_SVar: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_2410 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_2410)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2410, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_2410);
          }
        }
        case TAG_Cons: {
          V v_x1_2414 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2414) == NTAG(TAG_True)));
          heff_drop(v_x1_2414);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      case TAG_SGlobal: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_2416 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_2416)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2416, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_2416);
          }
        }
        case TAG_Cons: {
          V v_x1_2420 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2420) == NTAG(TAG_True)));
          heff_drop(v_x1_2420);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      case TAG_SInt: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_2422 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_2422)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2422, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_2422);
          }
        }
        case TAG_Cons: {
          V v_as222_2425 = heff_field(v_as22_248, 1);
          switch (heff_tag_of(v_as222_2425)) {
          case TAG_Nil: {
            V v_x1_2426 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
            V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2426) == NTAG(TAG_True)));
            heff_drop(v_x1_2426);
            return v_ret_24bool;
          }
          case TAG_Cons: {
            V v_x1_2429 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
            V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2429) == NTAG(TAG_True)));
            heff_drop(v_x1_2429);
            return v_ret_24bool;
          }
          default: return heff_nomatch(v_as222_2425);
          }
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      case TAG_SFloat: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_2431 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_2431)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2431, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_2431);
          }
        }
        case TAG_Cons: {
          V v_x1_2435 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2435) == NTAG(TAG_True)));
          heff_drop(v_x1_2435);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      case TAG_SStr: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_2437 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_2437)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2437, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_2437);
          }
        }
        case TAG_Cons: {
          V v_x1_2441 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2441) == NTAG(TAG_True)));
          heff_drop(v_x1_2441);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      case TAG_SBytes: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_2443 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_2443)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2443, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_2443);
          }
        }
        case TAG_Cons: {
          V v_x1_2447 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2447) == NTAG(TAG_True)));
          heff_drop(v_x1_2447);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      case TAG_SFixed: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_2450 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_2450)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2450, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_2450);
          }
        }
        case TAG_Cons: {
          V v_x1_2454 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2454) == NTAG(TAG_True)));
          heff_drop(v_x1_2454);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      case TAG_SFloat32: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_2456 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_2456)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2456, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_2456);
          }
        }
        case TAG_Cons: {
          V v_x1_2460 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2460) == NTAG(TAG_True)));
          heff_drop(v_x1_2460);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      case TAG_SPrimFn: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_2462 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_2462)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2462, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_2462);
          }
        }
        case TAG_Cons: {
          V v_x1_2466 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2466) == NTAG(TAG_True)));
          heff_drop(v_x1_2466);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      case TAG_SLam: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_2469 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_2469)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2469, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_2469);
          }
        }
        case TAG_Cons: {
          V v_x1_2473 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2473) == NTAG(TAG_True)));
          heff_drop(v_x1_2473);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      case TAG_STag: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_2477 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_2477)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2477, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_2477);
          }
        }
        case TAG_Cons: {
          V v_x1_2481 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2481) == NTAG(TAG_True)));
          heff_drop(v_x1_2481);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      case TAG_SRec: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_2484 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_2484)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2484, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_2484);
          }
        }
        case TAG_Cons: {
          V v_x1_2488 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2488) == NTAG(TAG_True)));
          heff_drop(v_x1_2488);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      case TAG_SProj: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_2493 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_2493)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2493, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_2493);
          }
        }
        case TAG_Cons: {
          V v_x1_2497 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2497) == NTAG(TAG_True)));
          heff_drop(v_x1_2497);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      case TAG_SPrim: {
        switch (heff_tag_of(v_as22_248)) {
        case TAG_Nil: {
          V v_x3_24100 = (g_heff_2ecompile_2eemit_2eprimOp(v_p_240));
          switch (heff_tag_of(v_x3_24100)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x3_24100, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x3_24100);
          }
        }
        case TAG_Cons: {
          V v_x1_24104 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24104) == NTAG(TAG_True)));
          heff_drop(v_x1_24104);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_248);
        }
      }
      default: return heff_nomatch(v_as21_247);
      }
    }
    default: return heff_nomatch(v_as2_244);
    }
  }
  default: return heff_nomatch(v_as_241);
  }
}
V g_heff_2ecompile_2eemit_2ecallsHelper_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ecallsHelper(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallName_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallName_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallName_str2, 1, "x");
Clo g_heff_2ecompile_2eemit_2ecallName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecallName_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecallName(V v_env_240, V v_g_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_g_241); V b_1 = heff_get_n(v_env_240, 0, 5); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = heff_intSub(heff_strLength_lent(v_g_241, 0), MK_INT(1LL));
    V v_t_244 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_g_241), v_t_243));
    V v_t_245 = ({ V a_0 = v_g_241; V a_1 = v_t_244; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_244); r_; });
    V v_s_246 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_245, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2ecallName_str0)));
    V v_t_248;
    if (heff_strEq_c_lent(v_s_246, ((V)&g_heff_2ecompile_2eemit_2ecallName_str1), 2)) {
      heff_drop(v_s_246);
      v_t_248 = ((V)&g_heff_2ecompile_2eemit_2ecallName_str2);
    } else {
      v_t_248 = v_s_246;
    }
    return (g_heff_2ecompile_2eemit_2esafeRes(v_t_248));
  }
  case TAG_Just: {
    V v_i_249 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    heff_drop(v_g_241);
    return heff_get_n(v_i_249, 0, 4);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemit_2ecallName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecallName(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str3, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str5, 4, ") : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str7, 3, "500");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str8, 12, " \? new $Bnc(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str9, 16, "return ++$dep > ");
Clo g_heff_2ecompile_2eemit_2ebounceGive_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebounceGive_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ebounceGive(V v_ind_240, V v_f_241, V v_a_242) {
top: ;
  V v_x2_243 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str0)));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str2); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_a_242, 0)), ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str3));
  V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_f_241, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str4), v_t_247));
  V v_t_249 = heff_strAppend(heff_take_field(v_a_242, 0), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str5), v_t_248));
  V v_t_2410 = heff_strAppend(heff_take_field(v_f_241, 0), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str6), v_t_249));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str7), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str8), v_t_2410));
  V v_t_2412 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str9), v_t_2411));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  V v_t_2414 = (g_prelude_2e_2b_2b(heff_get_n(v_a_242, 1, 3), v_t_2413));
  return (g_prelude_2e_2b_2b(heff_get_n(v_f_241, 1, 3), v_t_2414));
}
V g_heff_2ecompile_2eemit_2ebounceGive_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebounceGive(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemit_2eloops_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eloops_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eloops(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_TSeq: {
    V v_t2_242 = heff_field(v_t_240, 1);
    V t_0 = v_t2_242;
    v_t_240 = t_0;
    goto top;
  }
  case TAG_TReturn: {
    return NTAG(TAG_False);
  }
  case TAG_TLoop: {
    return NTAG(TAG_True);
  }
  case TAG_TIf: {
    V v_t2_246 = heff_field(v_t_240, 1);
    V v_e_247 = heff_field(v_t_240, 2);
    V v_t_248 = (g_heff_2ecompile_2eemit_2eloops(v_t2_246));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_248);
      V t_0 = v_e_247;
      v_t_240 = t_0;
      goto top;
    }
  }
  case TAG_TCase: {
    V v_arms_2410 = heff_field(v_t_240, 1);
    HEFF_LAST return g_list_2eany_24s184951243x1948563855(v_arms_2410);
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2ecompile_2eemit_2eloops_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eloops(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str0, 4, "hole");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str1, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str2, 8, "setField");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str5, 4, "] = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str6, 3, ".a[");
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam2(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam3(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam4(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam5(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam6(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam7(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam8(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam9(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam10(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam11(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam12(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam13(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam14(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam15(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam16(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam17(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam18(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584(V v_env_240, V v_ind_241, V v_p_242, V v_as_243) {
top: ;
  if (heff_strEq_c_lent(v_p_242, ((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str0), 2)) {
    switch (heff_tag_of(v_as_243)) {
    case TAG_Nil: {
      heff_drop(v_env_240);
      heff_drop(v_ind_241);
      heff_drop(v_p_242);
      return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str1), MK_INT(3LL)});
    }
    case TAG_Cons: {
      V v_t_248 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam0, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
      return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_248));
    }
    default: return heff_nomatch(v_as_243);
    }
  } else {
    if (heff_strEq_c_lent(v_p_242, ((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str2), 2)) {
      switch (heff_tag_of(v_as_243)) {
      case TAG_Nil: {
        V v_t_2411 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam1, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
        return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2411));
      }
      case TAG_Cons: {
        V v_d_2412 = heff_dup(heff_field(v_as_243, 0));
        V v_as2_2413 = heff_dup(heff_field(v_as_243, 1));
        switch (heff_tag_of(v_as2_2413)) {
        case TAG_Nil: {
          heff_drop(v_d_2412);
          V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam2, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
          return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2415));
        }
        case TAG_Cons: {
          V v_as21_2416 = heff_field(v_as2_2413, 0);
          V v_as22_2417 = heff_field(v_as2_2413, 1);
          heff_take_n(v_as2_2413, 3ULL, 2);
          switch (heff_tag_of(v_as21_2416)) {
          case TAG_SVar: {
            heff_take_n(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2420 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam3, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2420));
          }
          case TAG_SGlobal: {
            heff_take_n(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2423 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam4, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2423));
          }
          case TAG_SInt: {
            V v_k_2424 = heff_field(v_as21_2416, 0);
            heff_take_n(v_as21_2416, 1ULL, 1);
            switch (heff_tag_of(v_as22_2417)) {
            case TAG_Nil: {
              heff_drop(v_d_2412);
              heff_drop(v_k_2424);
              V v_t_2426 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam5, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
              return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2426));
            }
            case TAG_Cons: {
              V v_v_2427 = heff_field(v_as22_2417, 0);
              V v_as222_2428 = heff_field(v_as22_2417, 1);
              heff_take_n(v_as22_2417, 3ULL, 2);
              switch (heff_tag_of(v_as222_2428)) {
              case TAG_Nil: {
                heff_drop(v_p_242);
                heff_drop_tag(v_as_243, 2);
                V v_c_2429 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_d_2412; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_d_2412); r_; });
                V v_t_2432;
                if (heff_intLt_c(heff_dup(heff_rfield(v_c_2429, 1)), MK_INT(3LL))) {
                  V v_t_2431 = heff_strAppend(heff_get_n(v_c_2429, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str3));
                  v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str4), v_t_2431);
                } else {
                  v_t_2432 = heff_get_n(v_c_2429, 0, 2);
                }
                V v_c_2433 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2427; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2427); r_; });
                V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str5), heff_get_n(v_c_2433, 0, 2));
                V v_t_2435 = heff_strAppend(heff_intShow(v_k_2424), v_t_2434);
                V v_t_2436 = heff_strAppend(v_t_2432, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str6), v_t_2435));
                return heff_rec_n(2, shape_code__prec, (V[]){v_t_2436, MK_INT(0LL)});
              }
              case TAG_Cons: {
                heff_take_n(v_as222_2428, 0ULL, 2);
                heff_drop(v_d_2412);
                heff_drop(v_k_2424);
                heff_drop(v_v_2427);
                V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam6, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
                return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2440));
              }
              default: return heff_nomatch(v_as222_2428);
              }
            }
            default: return heff_nomatch(v_as22_2417);
            }
          }
          case TAG_SFloat: {
            heff_take_na(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2443 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam7, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2443));
          }
          case TAG_SStr: {
            heff_take_n(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2446 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam8, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2446));
          }
          case TAG_SBytes: {
            heff_take_n(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2449 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam9, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2449));
          }
          case TAG_SFixed: {
            heff_take_n(v_as21_2416, 0ULL, 2);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2453 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam10, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2453));
          }
          case TAG_SFloat32: {
            heff_take_na(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2456 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam11, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2456));
          }
          case TAG_SPrimFn: {
            heff_take_n(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2459 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam12, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2459));
          }
          case TAG_SLam: {
            heff_take_n(v_as21_2416, 0ULL, 2);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2463 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam13, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2463));
          }
          case TAG_STag: {
            heff_take_n(v_as21_2416, 0ULL, 3);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2468 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam14, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2468));
          }
          case TAG_SRec: {
            heff_take_n(v_as21_2416, 0ULL, 2);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2472 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam15, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2472));
          }
          case TAG_SProj: {
            heff_take_n(v_as21_2416, 0ULL, 4);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2478 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam16, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2478));
          }
          case TAG_SPrim: {
            heff_take_n(v_as21_2416, 0ULL, 2);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2482 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam17, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2482));
          }
          default: return heff_nomatch(v_as21_2416);
          }
        }
        default: return heff_nomatch(v_as2_2413);
        }
      }
      default: return heff_nomatch(v_as_243);
      }
    } else {
      V v_t_2484 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam18, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
      return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2484));
    }
  }
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam0(V self, V *args) {
  V v_v_247 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_247; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_247); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam1(V self, V *args) {
  V v_v_2410 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2410; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2410); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam2(V self, V *args) {
  V v_v_2414 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2414; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2414); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam3(V self, V *args) {
  V v_v_2419 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2419; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2419); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam4(V self, V *args) {
  V v_v_2422 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2422; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2422); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam5(V self, V *args) {
  V v_v_2425 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2425; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2425); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam6(V self, V *args) {
  V v_v_2439 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2439; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2439); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam7(V self, V *args) {
  V v_v_2442 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2442; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2442); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam8(V self, V *args) {
  V v_v_2445 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2445; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2445); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam9(V self, V *args) {
  V v_v_2448 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2448; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2448); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam10(V self, V *args) {
  V v_v_2452 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2452; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2452); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam11(V self, V *args) {
  V v_v_2455 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2455; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2455); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam12(V self, V *args) {
  V v_v_2458 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2458; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2458); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam13(V self, V *args) {
  V v_v_2462 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2462; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2462); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam14(V self, V *args) {
  V v_v_2467 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2467; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2467); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam15(V self, V *args) {
  V v_v_2471 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2471; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2471); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam16(V self, V *args) {
  V v_v_2477 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2477; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2477); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam17(V self, V *args) {
  V v_v_2481 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2481; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2481); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam18(V self, V *args) {
  V v_v_2483 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2483; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2483); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_str3, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_str4, 4, "let ");
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_entry, 3, 0};

V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577(V v_env_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SLet: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_o_244 = heff_field(v_x4_242, 1);
    V v_st_245 = (g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(heff_dup(v_env_240), heff_dup(v_ind_241), v_o_244));
    V v_t_246 = (g_list_2efoldl_24s2118756600x1920057229(v_env_240, heff_rfield(v_st_245, 1)));
    V v_t_247 = (g_heff_2ecompile_2eemit_2ebindName(v_t_246, heff_dup(v_x_243)));
    HEFF_LAST return g_heff_2ecompile_2eemit_2eletBound(v_ind_241, v_st_245, v_t_247);
  }
  case TAG_SDecl: {
    V v_x_248 = heff_field(v_x4_242, 0);
    V v_nb_249 = (g_heff_2ecompile_2eemit_2ebindName(v_env_240, heff_dup(v_x_248)));
    V v_x2_2410 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_str0)));
    V v_t_2413;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_xs_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    V v_t_2414 = heff_strAppend(heff_take_field(v_nb_249, 0), ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_str3));
    V v_t_2415 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_str4), v_t_2414));
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
    return heff_rec_n(2, shape_lines__env, (V[]){v_t_2416, heff_get_n(v_nb_249, 1, 2)});
  }
  case TAG_SSet: {
    V v_x_2417 = heff_field(v_x4_242, 0);
    V v_o_2418 = heff_field(v_x4_242, 1);
    V v_t_2419 = (g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(heff_dup(v_env_240), heff_dup(v_ind_241), v_o_2418));
    return (g_heff_2ecompile_2eemit_2esetStmt(v_ind_241, v_t_2419, heff_dup(v_x_2417), v_env_240));
  }
  case TAG_SIf: {
    V v_c_2420 = heff_field(v_x4_242, 0);
    V v_ts_2421 = heff_field(v_x4_242, 1);
    V v_fs_2422 = heff_field(v_x4_242, 2);
    V v_t_2423 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), heff_dup(v_ind_241), heff_dup(v_c_2420)));
    V v_t_2428 = heff_tr(g_heff_2ecompile_2eemit_2eifLines(heff_dup(v_ind_241), v_t_2423, heff_clo_n(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_lam0, 1, 2, (V[]){heff_dup(v_env_240), heff_dup(v_ts_2421)}), heff_clo_n(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_lam1, 1, 2, (V[]){heff_dup(v_env_240), heff_dup(v_fs_2422)})));
    V v_t_2429 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), v_ind_241, heff_dup(v_c_2420)));
    V v_t_2430 = ({ V a_0 = v_t_2429; V r_ = (g_heff_2ecompile_2eemit_2eseqsOf(a_0)); heff_drop(v_t_2429); r_; });
    V v_t_2431 = ({ V a_0 = v_env_240; V a_1 = v_t_2430; V r_ = (g_list_2efoldl_24s2118756600x1920057229(a_0, a_1)); heff_drop(v_t_2430); r_; });
    return heff_rec_n(2, shape_lines__env, (V[]){v_t_2428, v_t_2431});
  }
  case TAG_SCase: {
    V v_v_2432 = heff_field(v_x4_242, 0);
    V v_arms_2433 = heff_field(v_x4_242, 1);
    V v_t_2434 = (g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(v_env_240, heff_dup(v_ind_241), heff_dup(v_v_2432)));
    HEFF_LAST return g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707(v_ind_241, heff_dup(v_arms_2433), v_t_2434);
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_lam0(V self, V *args) {
  V v_i_2424 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ts_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = ({ V a_0 = v_env_240; V a_1 = v_i_2424; V a_2 = v_ts_2421; V b_3 = NTAG(TAG_Nothing); V r_ = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  return heff_get_n(v_t_2425, 0, 2);
}
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_lam1(V self, V *args) {
  V v_i_2426 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_fs_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = ({ V a_0 = v_env_240; V a_1 = v_i_2426; V a_2 = v_fs_2422; V b_3 = NTAG(TAG_Nothing); V r_ = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  return heff_get_n(v_t_2427, 0, 2);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str3, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str4, 16, "return $nomatch(");
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519(V v_ind_240, V v_arms_241, V v_sc_242) {
top: ;
  V v_t_2410 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam0, 1, 2, (V[]){heff_dup(v_sc_242), heff_dup(v_ind_240)}), v_arms_241));
  V v_x2_2411 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str0)));
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str2); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2415 = heff_strAppend(heff_dup(heff_rfield(v_sc_242, 0)), ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str3));
  V v_t_2416 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str4), v_t_2415));
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  return (g_heff_2ecompile_2eemit_2eswitchLines(v_sc_242, v_ind_240, v_t_2410, NTAG(TAG_Nil), v_t_2417));
}
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam1(V self, V *args) {
  V v_e_248 = args[0];
  V v_i_249 = args[1];
  V v_t_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_248; V a_1 = v_i_249; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
}
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam0(V self, V *args) {
  V v_arm_243 = args[0];
  V v_sc_242 = heff_env(self)[0];
  V v_ind_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_243)) {
  case TAG_MkArm: {
    V v_tag_244 = heff_field(v_arm_243, 0);
    V v_vs_245 = heff_field(v_arm_243, 1);
    V v_t_246 = heff_field(v_arm_243, 2);
    heff_take_n(v_arm_243, 7ULL, 3);
    V v_t_247 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_246, NTAG(TAG_Nil)));
    return ({ V a_0 = v_sc_242; V a_1 = v_ind_240; V a_2 = v_tag_244; V a_3 = v_vs_245; V a_4 = v_t_247; V a_5 = heff_clo_n(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam1, 2, 1, (V[]){v_t_246}); V r_ = (g_heff_2ecompile_2eemit_2earmJs(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_arm_243);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str2, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str5, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str6, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str7, 2, "{\012");
Clo g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(V v_env_240, V v_ind_241, V v_t_242) {
top: ;
  V v_x2_243 = heff_tr(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(v_env_240, heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_x2_247 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str2)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str5), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str6)));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str7), heff_strAppend(v_t_246, v_t_2411));
}
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eextStr_str0, 247, "const $ext = (v) => typeof v === \"function\" \? (x) => $ext($tr(v(x))) : v !== null && typeof v === \"object\" && !Array.isArray(v) && !(v instanceof Uint8Array) && !(\"$\" in v) \? Object.fromEntries(Object.entries(v).map(([l, x]) => [l, $ext(x)])) : v;");

static V g_heff_2ecompile_2eemit_2eextStr_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2eextStr_st;
static V g_heff_2ecompile_2eemit_2eextStr_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2eextStr_str0);
}
V g_heff_2ecompile_2eemit_2eextStr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2eextStr_st)) return g_heff_2ecompile_2eemit_2eextStr_val;
  return heff_global(&g_heff_2ecompile_2eemit_2eextStr_val, &g_heff_2ecompile_2eemit_2eextStr_st, g_heff_2ecompile_2eemit_2eextStr_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str0, 5, "$lazy");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str1, 4, "$Bnc");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str2, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str3, 4, "$tr(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str4, 2, "$T");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str5, 60, "const $T = { $: \"True\", a: [] }, $F = { $: \"False\", a: [] };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str6, 2, "$F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str7, 60, "const $T = { $: \"True\", a: [] }, $F = { $: \"False\", a: [] };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str8, 8, "$abandon");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str9, 60, "const $abandon = () => { throw new Error(\"heff:abandon\"); };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str10, 8, "$nomatch");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str11, 87, "const $nomatch = (s) => { throw new Error(\"heff: no case for '\" + (s && s.$) + \"'\"); };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str12, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str13, 125, "const $force = (f) => { if (f.$m !== undefined) return f.$m; const v = $tr(f({ $: \"MkUnit\", a: [] })); f.$m = v; return v; };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str14, 5, "$lazy");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str15, 243, "const $lazy = (f) => { let state = 0, v; return () => { if (state === 2) return v; if (state === 1) throw new Error(\"heff: defined by itself\"); state = 1; try { v = $tr(f()); state = 2; return v; } finally { if (state === 1) state = 0; } }; };");
V g_heff_2ecompile_2eemit_2eruntime_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2eruntime_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eruntime_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eruntime_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eruntime(V v_code_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str0), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str2), v_t_241})});
  V v_t_245 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eruntime_lam0, 1, 1, (V[]){heff_dup(v_code_240)}); V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str3), v_t_242}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get())});
  } else {
    heff_drop(v_t_245);
    v_t_246 = NTAG(TAG_Nothing);
  }
  V v_x_247 = (g_prelude_2estrFind(((V)&g_heff_2ecompile_2eemit_2eruntime_str4), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2411;
  if (heff_intLe_c(MK_INT(0LL), v_x_247)) {
    v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str5)});
  } else {
    V v_x_249 = (g_prelude_2estrFind(((V)&g_heff_2ecompile_2eemit_2eruntime_str6), heff_dup(v_code_240), MK_INT(0LL)));
    if (heff_intLe_c(MK_INT(0LL), v_x_249)) {
      v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str7)});
    } else {
      v_t_2411 = NTAG(TAG_Nothing);
    }
  }
  V v_x_2412 = (g_prelude_2estrFind(((V)&g_heff_2ecompile_2eemit_2eruntime_str8), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2414;
  if (heff_intLe_c(MK_INT(0LL), v_x_2412)) {
    v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str9)});
  } else {
    v_t_2414 = NTAG(TAG_Nothing);
  }
  V v_x_2415 = (g_prelude_2estrFind(((V)&g_heff_2ecompile_2eemit_2eruntime_str10), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2417;
  if (heff_intLe_c(MK_INT(0LL), v_x_2415)) {
    v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str11)});
  } else {
    v_t_2417 = NTAG(TAG_Nothing);
  }
  V v_x_2418 = (g_prelude_2estrFind(((V)&g_heff_2ecompile_2eemit_2eruntime_str12), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2420;
  if (heff_intLe_c(MK_INT(0LL), v_x_2418)) {
    v_t_2420 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str13)});
  } else {
    v_t_2420 = NTAG(TAG_Nothing);
  }
  V v_x_2421 = (g_prelude_2estrFind(((V)&g_heff_2ecompile_2eemit_2eruntime_str14), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2423;
  if (heff_intLe_c(MK_INT(0LL), v_x_2421)) {
    v_t_2423 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str15)});
  } else {
    v_t_2423 = NTAG(TAG_Nothing);
  }
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2425})});
  V v_t_2427 = (g_heff_2ecompile_2eemit_2ecatMaybesL(heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2426})));
  V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eruntime_lam1, 1, 1, (V[]){v_code_240}), heff_dup(g_heff_2ecompile_2eemit_2estrHelpers_get())));
  V v_t_2434 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2433));
  return (g_prelude_2e_2b_2b(v_t_2427, v_t_2434));
}
V g_heff_2ecompile_2eemit_2eruntime_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eruntime(a[0]);
}
V g_heff_2ecompile_2eemit_2eruntime_lam0(V self, V *args) {
  V v_k_243 = args[0];
  V v_code_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_244 = (g_prelude_2estrFind(v_k_243, v_code_240, MK_INT(0LL)));
  return heff_intLe(MK_INT(0LL), v_x_244);
}
V g_heff_2ecompile_2eemit_2eruntime_lam1(V self, V *args) {
  V v_h_2428 = args[0];
  V v_code_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_h_2428)) {
  case TAG_MkPair: {
    V v_k_2429 = heff_field(v_h_2428, 0);
    V v_line_2430 = heff_field(v_h_2428, 1);
    heff_take_n(v_h_2428, 3ULL, 2);
    V v_x_2431 = (g_prelude_2estrFind(v_k_2429, v_code_240, MK_INT(0LL)));
    if (heff_intLe_c(MK_INT(0LL), v_x_2431)) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_line_2430});
    } else {
      heff_drop(v_line_2430);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_h_2428);
  }
}
Clo g_heff_2ecompile_2eemit_2einfoOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2einfoOne_entry, 4, 0};

V g_heff_2ecompile_2eemit_2einfoOne(V v_shorts_240, V v_facts_241, V v_acc_242, V v_key_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2eemit_2ejsNameOf(v_shorts_240, heff_dup(v_key_243)));
  V v_x2_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_key_243), heff_rfield(v_facts_241, 0)));
  V v_t_247;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nothing: {
    v_t_247 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_246 = heff_field(v_x2_245, 0);
    heff_take_n(v_x2_245, 1ULL, 1);
    v_t_247 = v_x_246;
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_x3_248 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_key_243), heff_rfield(v_facts_241, 2)));
  V v_t_2410;
  switch (heff_tag_of(v_x3_248)) {
  case TAG_Nothing: {
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_248, 0ULL, 1);
    v_t_2410 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_248);
  }
  V v_x3_2411 = ({ V a_0 = heff_dup(v_key_243); V b_1 = heff_get_n(v_facts_241, 1, 7); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2413;
  switch (heff_tag_of(v_x3_2411)) {
  case TAG_Nothing: {
    v_t_2413 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2411, 0ULL, 1);
    v_t_2413 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2411);
  }
  return (g_map_2einsert_24s1341440536x470972936(v_key_243, heff_rec_n(4, shape_js__arity__lazy__bounce, (V[]){v_t_244, v_t_247, v_t_2410, v_t_2413}), v_acc_242));
}
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2einfoOne(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eemit_2eemitKeptIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eemitKeptIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eemitKeptIn_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eemitKeptIn(V v_p_240, V v_defs_241, V v_roots_242, V v_kept_243) {
top: ;
  V v_t_244 = heff_rec_n(2, shape_entries__fresh, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_acc_2412 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemit_2eemitKeptIn_lam0, 2, 2, (V[]){heff_dup(v_p_240), heff_dup(v_kept_243)}), v_t_244, v_defs_241));
  V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_acc_2412, 0))));
  V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_2412, 0)));
  V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s963266017x1719814548(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_xs_2416 = (g_prelude_2e_2b_2b(v_t_2415, v_roots_242));
  V v_t_2417 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2416; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2416); r_; });
  V v_t_2418 = ({ V a_0 = v_p_240; V a_1 = v_t_2413; V a_2 = v_t_2417; V r_ = (g_heff_2ecompile_2eemit_2eassembled(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
  return heff_rec_n(2, shape_emitted__fresh, (V[]){v_t_2418, heff_get_n(v_acc_2412, 1, 2)});
}
V g_heff_2ecompile_2eemit_2eemitKeptIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2eemitKeptIn(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eemit_2eemitKeptIn_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_d_246 = args[1];
  V v_p_240 = heff_env(self)[0];
  V v_kept_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_own_247 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_map_2eempty_get()), MK_INT(0LL), heff_dup(heff_rfield(v_d_246, 2))));
  V v_t_2410;
  switch (heff_tag_of(v_own_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_dup(heff_field(v_own_247, 0));
    v_t_2410 = v_x_248;
    break;
  }
  default: heff_nomatch(v_own_247);
  }
  V v_t_2411 = (g_heff_2ecompile_2eemit_2ejsVer(heff_dup(v_p_240), heff_dup(heff_rfield(v_d_246, 0)), v_t_2410));
  return ({ V a_0 = v_p_240; V a_1 = v_kept_243; V a_2 = v_acc_245; V a_3 = v_d_246; V a_4 = v_own_247; V a_5 = v_t_2411; V r_ = (g_heff_2ecompile_2eemit_2ejsAt(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_kept_243); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntimeFor_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntimeFor_str1, 1, "\012");
Clo g_heff_2ecompile_2eemit_2eruntimeFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eruntimeFor_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eruntimeFor(V v_hasTr_240, V v_have_241, V v_provs_242, V v_eff_243) {
top: ;
  V v_t_244;
  if ((heff_dup(v_hasTr_240) == NTAG(TAG_True))) {
    v_t_244 = NTAG(TAG_Nil);
  } else {
    v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()), NTAG(TAG_Nil)});
  }
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2eworldStr_get()), NTAG(TAG_Nil)});
  V v_t_246 = (g_prelude_2e_2b_2b(v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2erunStr_get()), v_t_245})));
  V v_t_2410;
  switch (heff_tag_of(v_eff_243)) {
  case TAG_Leaf: {
    heff_take_n(v_eff_243, 0ULL, 1);
    v_t_2410 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Plus: {
    V v_ru_24eff_243_24Plus = heff_take_reuse_n(v_eff_243, 0ULL, 2);
    v_t_2410 = heff_tag_at_n(v_ru_24eff_243_24Plus, TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2esumStr_get()), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_eff_243);
  }
  V v_t_2411 = (g_heff_2ecompile_2eemit_2eprovStrHelpers(v_have_241, heff_dup(v_provs_242)));
  V v_t_2412 = (g_heff_2ecompile_2eemit_2ebundleAll(MK_INT(0LL), v_provs_242));
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2412));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2413));
  V v_x2_2415 = (g_prelude_2e_2b_2b(v_t_246, v_t_2414));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2eemit_2eruntimeFor_str0);
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eruntimeFor_str1); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eemit_2eruntimeFor_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2eruntimeFor(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str3, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str4, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str5, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str6, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str7, 8, "($world)");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str8, 2, "$p");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str9, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str10, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str11, 5, "$sum(");
Clo g_heff_2ecompile_2eemit_2ehandlerOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ehandlerOf_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ehandlerOf(V v_provs_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_t_243 = (g_prelude_2estrFind(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str0), heff_dup(v_k_242), MK_INT(0LL)));
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str1), heff_dup(v_k_242), MK_INT(0LL), v_t_243, NTAG(TAG_Nil)));
    V v_x2_245 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str3); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = (g_heff_2ecompile_2eemit_2eprovIndexGo(MK_INT(0LL), v_t_248, v_provs_240));
    V v_t_2410 = (g_prelude_2estrFind(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str4), heff_dup(v_k_242), MK_INT(0LL)));
    V v_t_2411 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str5), heff_dup(v_k_242), MK_INT(0LL), v_t_2410, NTAG(TAG_Nil)));
    V v_t_2412 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2411); r_; });
    V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str6), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str7)));
    V v_t_2414 = heff_strAppend(heff_intShow(v_t_249), v_t_2413);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str8), v_t_2414);
  }
  case TAG_Plus: {
    V v_a_2415 = heff_field(v_x2_241, 0);
    V v_b_2416 = heff_field(v_x2_241, 1);
    V v_t_2417 = (g_heff_2ecompile_2eemit_2ehandlerOf(v_provs_240, v_a_2415));
    V v_t_2418 = (g_heff_2ecompile_2eemit_2ehandlerOf(v_provs_240, v_b_2416));
    V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str9), heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str10)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str11), heff_strAppend(v_t_2417, v_t_2419));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2ehandlerOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ehandlerOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eimportLinesOf_str0, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eimportLinesOf_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eimportLinesOf_str2, 7, "import ");
Clo g_heff_2ecompile_2eemit_2eimportLinesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eimportLinesOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eimportLinesOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_s_243 = heff_dup(heff_rfield(v_p_241, 1));
    V v_t_244 = (g_prelude_2estrFind(((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str0), heff_dup(v_s_243), MK_INT(0LL)));
    V v_t_245 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str1), v_s_243, MK_INT(0LL), v_t_244, NTAG(TAG_Nil)));
    V v_t_246 = (g_list_2efilter_24s1820448628x561773228(MK_INT(0LL), MK_INT(7LL), ((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str2), v_t_245));
    V v_t_247 = (g_heff_2ecompile_2eemit_2eimportLinesOf(v_rest_242));
    return (g_prelude_2e_2b_2b(v_t_246, v_t_247));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2eimportLinesOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eimportLinesOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2ecompileJsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecompileJsWith_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecompileJsWith(V v_g_240, V v_exports_241) {
top: ;
  V v_roots_242 = (g_list_2emap_24s152505078x225062837(heff_dup(v_exports_241)));
  V v_t_243 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_g_240));
  V v_l_244 = (g_heff_2ecompile_2elower_2elowerErased(v_roots_242, v_t_243));
  V v_roots_245 = (g_list_2emap_24s152505078x225062837(heff_dup(v_exports_241)));
  V v_t_246 = ({ V a_0 = heff_take_field(v_l_244, 1); V a_1 = heff_take_field(v_l_244, 0); V a_2 = v_roots_245; V b_3 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2ecompile_2eemit_2eemitKept(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  V v_t_247 = (g_heff_2ecompile_2eemit_2ejsSource(v_exports_241, heff_get_n(v_t_246, 0, 2)));
  return heff_rec_n(2, shape_source__errors, (V[]){v_t_247, heff_get_n(v_l_244, 2, 3)});
}
V g_heff_2ecompile_2eemit_2ecompileJsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecompileJsWith(a[0], a[1]);
}