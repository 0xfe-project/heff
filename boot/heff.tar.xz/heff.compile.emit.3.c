// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Leaf 13717
#define TAG_MkArm 55352
#define TAG_MkArmJs 44527
#define TAG_Plus 9189
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_arity 294440695
#define LBL_bounce 563936691
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_emitted 749050271
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_js 10160
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_pre 320797
#define LBL_prec 9944807
#define LBL_source 1050636102
#define LBL_text 10052084
static uint32_t shape_code__prec[] = {LBL_code, LBL_prec};
static uint32_t shape_js__arity__lazy__bounce[] = {LBL_js, LBL_arity, LBL_lazy, LBL_bounce};
static uint32_t shape_js__env[] = {LBL_js, LBL_env};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eemit_2earmBound(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmBound_clo;
V g_heff_2ecompile_2eemit_2earmJs(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmJs_clo;
V g_heff_2ecompile_2eemit_2earmJs_24tok3(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmJs_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmJs_24tok3_clo;
V g_heff_2ecompile_2eemit_2ebindFrom(V, V, V, V);
V g_heff_2ecompile_2eemit_2ebindFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindFrom_clo;
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(V, V, V);
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_clo;
V g_heff_2ecompile_2eemit_2ebounceGive(V, V, V);
V g_heff_2ecompile_2eemit_2ebounceGive_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebounceGive_clo;
V g_heff_2ecompile_2eemit_2ebundleAll(V, V);
V g_heff_2ecompile_2eemit_2ebundleAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleAll_clo;
V g_heff_2ecompile_2eemit_2ecallsHelper(V, V);
V g_heff_2ecompile_2eemit_2ecallsHelper_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallsHelper_clo;
HeffT2 g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519(V, V, V);
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_clo;
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2(V, V, V, V);
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(V, V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_clo;
V g_heff_2ecompile_2eemit_2ecellPrim(V, V);
V g_heff_2ecompile_2eemit_2ecellPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecellPrim_clo;
V g_heff_2ecompile_2eemit_2ecompileJsWith(V, V);
V g_heff_2ecompile_2eemit_2ecompileJsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJsWith_clo;
V g_heff_2ecompile_2eemit_2eemitKept(V, V, V, V);
V g_heff_2ecompile_2eemit_2eemitKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eemitKept_clo;
V g_heff_2ecompile_2eemit_2eextStr_get(void);
V g_heff_2ecompile_2eemit_2ehandlerOf(V, V);
V g_heff_2ecompile_2eemit_2ehandlerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehandlerOf_clo;
V g_heff_2ecompile_2eemit_2eimportLinesOf(V);
V g_heff_2ecompile_2eemit_2eimportLinesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eimportLinesOf_clo;
V g_heff_2ecompile_2eemit_2einfoOne(V, V, V, V);
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2einfoOne_clo;
V g_heff_2ecompile_2eemit_2ejsNameOf(V, V);
V g_heff_2ecompile_2eemit_2ejsNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsNameOf_clo;
V g_heff_2ecompile_2eemit_2ejsSource(V, V);
V g_heff_2ecompile_2eemit_2ejsSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsSource_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
HeffT2 g_heff_2ecompile_2eemit_2eletBound_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eemit_2eletStmt_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2eloops(V);
V g_heff_2ecompile_2eemit_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eloops_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2enubGo_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2enubGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_24dps_clo;
HeffT2 g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2eprimCall(V, V);
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimCall_clo;
HeffT2 g_heff_2ecompile_2eemit_2eprimOp_24cpr(V);
V g_heff_2ecompile_2eemit_2eprimTest(V, V, V);
V g_heff_2ecompile_2eemit_2eprimTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimTest_clo;
HeffT2 g_heff_2ecompile_2eemit_2eprimUnary_24cpr(V);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584(V, V, V, V);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_clo;
V g_heff_2ecompile_2eemit_2eprovIndexGo(V, V, V);
V g_heff_2ecompile_2eemit_2eprovIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovIndexGo_clo;
V g_heff_2ecompile_2eemit_2eprovStrHelpers(V, V);
V g_heff_2ecompile_2eemit_2eprovStrHelpers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovStrHelpers_clo;
V g_heff_2ecompile_2eemit_2erunStr_get(void);
V g_heff_2ecompile_2eemit_2eruntime(V);
V g_heff_2ecompile_2eemit_2eruntime_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntime_clo;
V g_heff_2ecompile_2eemit_2eruntimeFor(V, V, V, V);
V g_heff_2ecompile_2eemit_2eruntimeFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntimeFor_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeFrom(V);
V g_heff_2ecompile_2eemit_2esafeFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeFrom_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(V, V, V, V);
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_clo;
V g_heff_2ecompile_2eemit_2estrHelpers_get(void);
V g_heff_2ecompile_2eemit_2esumStr_get(void);
V g_heff_2ecompile_2eemit_2eswitchLines(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2eswitchLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eswitchLines_clo;
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(V, V, V);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V, V, V);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo;
HeffT2 g_heff_2ecompile_2eemit_2ewordOf_24cpr(V);
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
HeffT3 g_heff_2ecompile_2elower_2elowerErased_24cpr(V, V);
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1027174601x1571638094(V, V, V, V);
V g_list_2eany_24s1027174601x1571638094_entry(V self, V *a);
extern Clo g_list_2eany_24s1027174601x1571638094_clo;
V g_list_2eany_24s184951243x1948563855(V);
V g_list_2eany_24s184951243x1948563855_entry(V self, V *a);
extern Clo g_list_2eany_24s184951243x1948563855_clo;
V g_list_2eany_24s1877524499x1789047582(V, V);
V g_list_2eany_24s1877524499x1789047582_entry(V self, V *a);
extern Clo g_list_2eany_24s1877524499x1789047582_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s2018454372x1607369768(V, V, V, V, V, V, V);
V g_list_2efoldl_24s2018454372x1607369768_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2018454372x1607369768_clo;
V g_list_2efoldl_24s2118756600x1920057229(V, V);
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_clo;
V g_list_2ekeepIf_24s185327080x101197346(V, V, V, V);
V g_list_2ekeepIf_24s185327080x101197346_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s185327080x101197346_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s319754340x1392149466(V, V, V, V);
V g_list_2emap_24s319754340x1392149466_entry(V self, V *a);
extern Clo g_list_2emap_24s319754340x1392149466_clo;
V g_list_2emap_24s357242026x384251201(V);
V g_list_2emap_24s357242026x384251201_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecatMaybesL_entry, 1, 0};

V g_heff_2ecompile_2eemit_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecatMaybesL(a[0]);
}
Clo g_heff_2ecompile_2eemit_2enubGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enubGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2enubGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_list_2eany(v_t_244, v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_xs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2eemit_2enubGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_xs_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enubGo(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(V v_x_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) <= v_i_241)) {
    V v_f_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ecompile_2eemit_2ewordOf_24cpr(heff_strByteAt_lent(v_x_240, heff_box_word(v_i_241), 2)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_w_247 = v_field_246;
        V t_0 = v_x_240;
        int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_w_247, v_acc_242});
        v_x_240 = t_0;
        v_i_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      } else {
        heff_drop(v_acc_242);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str5, 10, " \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str6, 1, " ");
Clo g_heff_2ecompile_2eemit_2eprimTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimTest_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprimTest(V v_op_240, V v_a_241, V v_b_242) {
top: ;
  V v_prec_243 = heff_take_field(v_b_242, 1);
  V v_code_244 = heff_get_n(v_b_242, 0, 2);
  V v_prec_245 = heff_take_field(v_a_241, 1);
  V v_code_246 = heff_get_n(v_a_241, 0, 2);
  V v_t_247;
  if (heff_intLt_c(v_prec_245, MK_INT(2LL))) {
    v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str0), heff_strAppend(v_code_246, ((V)&g_heff_2ecompile_2eemit_2eprimTest_str1)));
  } else {
    v_t_247 = v_code_246;
  }
  V v_t_248;
  if (heff_intLt_c(v_prec_243, MK_INT(2LL))) {
    v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str2), heff_strAppend(v_code_244, ((V)&g_heff_2ecompile_2eemit_2eprimTest_str3)));
  } else {
    v_t_248 = v_code_244;
  }
  V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str4), heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemit_2eprimTest_str5)));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str6), heff_strAppend(v_op_240, v_t_249));
  return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_247, v_t_2410), MK_INT(0LL)});
}
V g_heff_2ecompile_2eemit_2eprimTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimTest(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str4, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str8, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str9, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str11, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str14, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str16, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str17, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str18, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str19, 1, "$");
Clo g_heff_2ecompile_2eemit_2eprimCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimCall_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprimCall(V v_p_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_args_241)) {
  case TAG_Nil: {
    V v_x2_242 = (g_list_2emap_24s357242026x384251201(v_args_241));
    V v_t_245;
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str2), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str3)));
    V v_code_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str4), heff_strAppend(v_p_240, v_t_246));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_247, MK_INT(3LL)});
  }
  case TAG_Cons: {
    V v_a_248 = heff_dup(heff_field(v_args_241, 0));
    V v_args2_249 = heff_dup(heff_field(v_args_241, 1));
    switch (heff_tag_of(v_args2_249)) {
    case TAG_Nil: {
      HeffT2 v_t_2410 = (g_heff_2ecompile_2eemit_2eprimUnary_24cpr(v_p_240));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop(v_p_240);
          heff_drop_tag(v_args_241, 2);
          V v_f_2413 = v_field_2412;
          return heff_tail(v_f_2413, 1, (V[]){v_a_248});
        } else {
          heff_drop(v_a_248);
          heff_drop(v_field_2412);
          V v_x2_2414 = (g_list_2emap_24s357242026x384251201(v_args_241));
          V v_t_2417;
          switch (heff_tag_of(v_x2_2414)) {
          case TAG_Nil: {
            v_t_2417 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str5);
            break;
          }
          case TAG_Cons: {
            V v_x_2415 = heff_field(v_x2_2414, 0);
            V v_xs_2416 = heff_field(v_x2_2414, 1);
            heff_take_n(v_x2_2414, 3ULL, 2);
            v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str6); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2414);
          }
          V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str7), heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str8)));
          V v_code_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str9), heff_strAppend(v_p_240, v_t_2418));
          return heff_rec_n(2, shape_code__prec, (V[]){v_code_2419, MK_INT(3LL)});
        }
      }
    }
    case TAG_Cons: {
      V v_b_2420 = heff_field(v_args2_249, 0);
      V v_args22_2421 = heff_field(v_args2_249, 1);
      heff_take_n(v_args2_249, 3ULL, 2);
      switch (heff_tag_of(v_args22_2421)) {
      case TAG_Nil: {
        HeffT2 v_t_2422 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
        {
          V v_field_2424 = v_t_2422.f[1];
          int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
          if ((v_tag_2423 == ((int64_t)0ULL))) {
            heff_drop(v_p_240);
            heff_drop_tag(v_args_241, 2);
            V v_f_2425 = v_field_2424;
            return heff_tail(v_f_2425, 2, (V[]){v_a_248, v_b_2420});
          } else {
            heff_drop(v_a_248);
            heff_drop(v_b_2420);
            heff_drop(v_field_2424);
            V v_x2_2426 = (g_list_2emap_24s357242026x384251201(v_args_241));
            V v_t_2429;
            switch (heff_tag_of(v_x2_2426)) {
            case TAG_Nil: {
              v_t_2429 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str10);
              break;
            }
            case TAG_Cons: {
              V v_x_2427 = heff_field(v_x2_2426, 0);
              V v_xs_2428 = heff_field(v_x2_2426, 1);
              heff_take_n(v_x2_2426, 3ULL, 2);
              v_t_2429 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str11); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2426);
            }
            V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str12), heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str13)));
            V v_code_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str14), heff_strAppend(v_p_240, v_t_2430));
            return heff_rec_n(2, shape_code__prec, (V[]){v_code_2431, MK_INT(3LL)});
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_args22_2421, 0ULL, 2);
        heff_drop(v_a_248);
        heff_drop(v_b_2420);
        V v_x2_2434 = (g_list_2emap_24s357242026x384251201(v_args_241));
        V v_t_2437;
        switch (heff_tag_of(v_x2_2434)) {
        case TAG_Nil: {
          v_t_2437 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str15);
          break;
        }
        case TAG_Cons: {
          V v_x_2435 = heff_field(v_x2_2434, 0);
          V v_xs_2436 = heff_field(v_x2_2434, 1);
          heff_take_n(v_x2_2434, 3ULL, 2);
          v_t_2437 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str16); V a_1 = v_x_2435; V a_2 = v_xs_2436; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2436); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2434);
        }
        V v_t_2438 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str17), heff_strAppend(v_t_2437, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str18)));
        V v_code_2439 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str19), heff_strAppend(v_p_240, v_t_2438));
        return heff_rec_n(2, shape_code__prec, (V[]){v_code_2439, MK_INT(3LL)});
      }
      default: return heff_nomatch(v_args22_2421);
      }
    }
    default: return heff_nomatch(v_args2_249);
    }
  }
  default: return heff_nomatch(v_args_241);
  }
}
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimCall(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2ecallsHelper_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecallsHelper_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecallsHelper(V v_p_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_args_241)) {
  case TAG_Nil: {
    V v_x1_242 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_242) == NTAG(TAG_True)));
    heff_drop(v_x1_242);
    return v_ret_24bool;
  }
  case TAG_Cons: {
    V v_args2_244 = heff_field(v_args_241, 1);
    switch (heff_tag_of(v_args2_244)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_args_241)) {
      case TAG_Cons: {
        HeffT2 v_t_247 = (g_heff_2ecompile_2eemit_2eprimUnary_24cpr(v_p_240));
        {
          V v_field_249 = v_t_247.f[1];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          V v_ret_24bool = heff_bool(((v_tag_248 == ((int64_t)0ULL)) ? ({ V v_x_2410 = heff_dup(v_field_249); int c_ = 0; heff_drop(v_x_2410); c_; }) : 1));
          heff_drop(v_field_249);
          return v_ret_24bool;
        }
      }
      default: return heff_nomatch(v_args_241);
      }
    }
    case TAG_Cons: {
      V v_args21_2411 = heff_field(v_args2_244, 0);
      V v_args22_2412 = heff_field(v_args2_244, 1);
      switch (heff_tag_of(v_args21_2411)) {
      case TAG_SVar: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_2414 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2416 = v_t_2414.f[1];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2415 == ((int64_t)0ULL)) ? ({ V v_x_2417 = heff_dup(v_field_2416); int c_ = 0; heff_drop(v_x_2417); c_; }) : 1));
            heff_drop(v_field_2416);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2420 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2420) == NTAG(TAG_True)));
          heff_drop(v_x1_2420);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      case TAG_SGlobal: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_2422 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2424 = v_t_2422.f[1];
            int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2423 == ((int64_t)0ULL)) ? ({ V v_x_2425 = heff_dup(v_field_2424); int c_ = 0; heff_drop(v_x_2425); c_; }) : 1));
            heff_drop(v_field_2424);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2428 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2428) == NTAG(TAG_True)));
          heff_drop(v_x1_2428);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      case TAG_SInt: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_2430 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2432 = v_t_2430.f[1];
            int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2431 == ((int64_t)0ULL)) ? ({ V v_x_2433 = heff_dup(v_field_2432); int c_ = 0; heff_drop(v_x_2433); c_; }) : 1));
            heff_drop(v_field_2432);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_args222_2435 = heff_field(v_args22_2412, 1);
          switch (heff_tag_of(v_args222_2435)) {
          case TAG_Nil: {
            V v_x1_2436 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
            V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2436) == NTAG(TAG_True)));
            heff_drop(v_x1_2436);
            return v_ret_24bool;
          }
          case TAG_Cons: {
            V v_x1_2439 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
            V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2439) == NTAG(TAG_True)));
            heff_drop(v_x1_2439);
            return v_ret_24bool;
          }
          default: return heff_nomatch(v_args222_2435);
          }
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      case TAG_SFloat: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_2441 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2443 = v_t_2441.f[1];
            int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2442 == ((int64_t)0ULL)) ? ({ V v_x_2444 = heff_dup(v_field_2443); int c_ = 0; heff_drop(v_x_2444); c_; }) : 1));
            heff_drop(v_field_2443);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2447 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2447) == NTAG(TAG_True)));
          heff_drop(v_x1_2447);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      case TAG_SStr: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_2449 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2451 = v_t_2449.f[1];
            int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2450 == ((int64_t)0ULL)) ? ({ V v_x_2452 = heff_dup(v_field_2451); int c_ = 0; heff_drop(v_x_2452); c_; }) : 1));
            heff_drop(v_field_2451);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2455 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2455) == NTAG(TAG_True)));
          heff_drop(v_x1_2455);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      case TAG_SBytes: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_2457 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2459 = v_t_2457.f[1];
            int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2458 == ((int64_t)0ULL)) ? ({ V v_x_2460 = heff_dup(v_field_2459); int c_ = 0; heff_drop(v_x_2460); c_; }) : 1));
            heff_drop(v_field_2459);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2463 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2463) == NTAG(TAG_True)));
          heff_drop(v_x1_2463);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      case TAG_SFixed: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_2466 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2468 = v_t_2466.f[1];
            int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2467 == ((int64_t)0ULL)) ? ({ V v_x_2469 = heff_dup(v_field_2468); int c_ = 0; heff_drop(v_x_2469); c_; }) : 1));
            heff_drop(v_field_2468);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2472 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2472) == NTAG(TAG_True)));
          heff_drop(v_x1_2472);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      case TAG_SFloat32: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_2474 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2476 = v_t_2474.f[1];
            int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2475 == ((int64_t)0ULL)) ? ({ V v_x_2477 = heff_dup(v_field_2476); int c_ = 0; heff_drop(v_x_2477); c_; }) : 1));
            heff_drop(v_field_2476);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2480 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2480) == NTAG(TAG_True)));
          heff_drop(v_x1_2480);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      case TAG_SPrimFn: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_2482 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2484 = v_t_2482.f[1];
            int64_t v_tag_2483 = ((int64_t)v_t_2482.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2483 == ((int64_t)0ULL)) ? ({ V v_x_2485 = heff_dup(v_field_2484); int c_ = 0; heff_drop(v_x_2485); c_; }) : 1));
            heff_drop(v_field_2484);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2488 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2488) == NTAG(TAG_True)));
          heff_drop(v_x1_2488);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      case TAG_SLam: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_2491 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2493 = v_t_2491.f[1];
            int64_t v_tag_2492 = ((int64_t)v_t_2491.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2492 == ((int64_t)0ULL)) ? ({ V v_x_2494 = heff_dup(v_field_2493); int c_ = 0; heff_drop(v_x_2494); c_; }) : 1));
            heff_drop(v_field_2493);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2497 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2497) == NTAG(TAG_True)));
          heff_drop(v_x1_2497);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      case TAG_STag: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_24101 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_24103 = v_t_24101.f[1];
            int64_t v_tag_24102 = ((int64_t)v_t_24101.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_24102 == ((int64_t)0ULL)) ? ({ V v_x_24104 = heff_dup(v_field_24103); int c_ = 0; heff_drop(v_x_24104); c_; }) : 1));
            heff_drop(v_field_24103);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_24107 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24107) == NTAG(TAG_True)));
          heff_drop(v_x1_24107);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      case TAG_SRec: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_24110 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_24112 = v_t_24110.f[1];
            int64_t v_tag_24111 = ((int64_t)v_t_24110.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_24111 == ((int64_t)0ULL)) ? ({ V v_x_24113 = heff_dup(v_field_24112); int c_ = 0; heff_drop(v_x_24113); c_; }) : 1));
            heff_drop(v_field_24112);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_24116 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24116) == NTAG(TAG_True)));
          heff_drop(v_x1_24116);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      case TAG_SProj: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_24121 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_24123 = v_t_24121.f[1];
            int64_t v_tag_24122 = ((int64_t)v_t_24121.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_24122 == ((int64_t)0ULL)) ? ({ V v_x_24124 = heff_dup(v_field_24123); int c_ = 0; heff_drop(v_x_24124); c_; }) : 1));
            heff_drop(v_field_24123);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_24127 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24127) == NTAG(TAG_True)));
          heff_drop(v_x1_24127);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      case TAG_SPrim: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_24130 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_24132 = v_t_24130.f[1];
            int64_t v_tag_24131 = ((int64_t)v_t_24130.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_24131 == ((int64_t)0ULL)) ? ({ V v_x_24133 = heff_dup(v_field_24132); int c_ = 0; heff_drop(v_x_24133); c_; }) : 1));
            heff_drop(v_field_24132);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_24136 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24136) == NTAG(TAG_True)));
          heff_drop(v_x1_24136);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      default: return heff_nomatch(v_args21_2411);
      }
    }
    default: return heff_nomatch(v_args2_244);
    }
  }
  default: return heff_nomatch(v_args_241);
  }
}
V g_heff_2ecompile_2eemit_2ecallsHelper_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ecallsHelper(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eletStmt_24cpr_str0, 0, "");

HeffT2 g_heff_2ecompile_2eemit_2eletStmt_24cpr(V v_ind_240, V v_st_241, V v_x_242, V v_env_243) {
top: ;
  V v_env_244 = (g_list_2efoldl_24s2118756600x1920057229(v_env_243, heff_rfield(v_st_241, 1)));
  V v_x0_245 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_242), MK_INT(0LL)));
  int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_x0_245, 0)) - ((int64_t)1ULL));
  V v_t_247 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_245, heff_box_word(v_t_246)));
  V v_t_248 = ({ V a_0 = v_x0_245; V a_1 = v_t_247; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_t_249 = ({ V a_0 = v_t_248; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2eletStmt_24cpr_str0); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_t_2410 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_249));
  V v_t_2411 = (g_heff_2ecompile_2eemit_2ebindFrom(v_env_244, v_x_242, v_t_2410, MK_INT(0LL)));
  return (g_heff_2ecompile_2eemit_2eletBound_24cpr(v_ind_240, v_st_241, v_t_2411));
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str4, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str5, 4, ") : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str7, 12, " \? new $Bnc(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str8, 16, "return ++$dep > ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str9, 3, "500");
Clo g_heff_2ecompile_2eemit_2ebounceGive_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebounceGive_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ebounceGive(V v_ind_240, V v_f_241, V v_a_242) {
top: ;
  V v_pre_243 = heff_take_field(v_a_242, 1);
  V v_js_244 = heff_get_n(v_a_242, 0, 3);
  V v_pre_245 = heff_take_field(v_f_241, 1);
  V v_js_246 = heff_get_n(v_f_241, 0, 3);
  V v_x2_247 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str0)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str3), heff_strAppend(heff_dup(v_js_244), ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str4)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str5), heff_strAppend(heff_dup(v_js_246), v_t_2411));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str6), heff_strAppend(v_js_244, v_t_2412));
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str7), heff_strAppend(v_js_246, v_t_2413));
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str8), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str9), v_t_2414));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2410, v_t_2415), NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_pre_243, v_t_2416));
  return (g_prelude_2e_2b_2b(v_pre_245, v_t_2417));
}
V g_heff_2ecompile_2eemit_2ebounceGive_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebounceGive(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemit_2eloops_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eloops_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eloops(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TSeq: {
    V v_t_242 = heff_field(v_x1_240, 1);
    V t_0 = v_t_242;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_TReturn: {
    return NTAG(TAG_False);
  }
  case TAG_TLoop: {
    return NTAG(TAG_True);
  }
  case TAG_TIf: {
    V v_t_246 = heff_field(v_x1_240, 1);
    V v_e_247 = heff_field(v_x1_240, 2);
    V v_t_248 = (g_heff_2ecompile_2eemit_2eloops(v_t_246));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_248);
      V t_0 = v_e_247;
      v_x1_240 = t_0;
      goto top;
    }
  }
  case TAG_TCase: {
    V v_arms_2410 = heff_field(v_x1_240, 1);
    HEFF_LAST return g_list_2eany_24s184951243x1948563855(v_arms_2410);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2eloops_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eloops(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str0, 4, "hole");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str1, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str2, 8, "setField");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str5, 4, "] = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str6, 3, ".a[");
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam2(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam3(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam4(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam5(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam6(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam7(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam8(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam9(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam10(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam11(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam12(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam13(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam14(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam15(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam16(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam17(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam18(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584(V v_env_240, V v_ind_241, V v_p_242, V v_args_243) {
top: ;
  if (heff_strEq_c_lent(v_p_242, ((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str0), 2)) {
    switch (heff_tag_of(v_args_243)) {
    case TAG_Nil: {
      heff_drop(v_env_240);
      heff_drop(v_ind_241);
      heff_drop(v_p_242);
      return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str1), MK_INT(3LL)});
    }
    case TAG_Cons: {
      V v_t_247 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam0, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
      return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_247));
    }
    default: return heff_nomatch(v_args_243);
    }
  } else {
    if (heff_strEq_c_lent(v_p_242, ((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str2), 2)) {
      switch (heff_tag_of(v_args_243)) {
      case TAG_Nil: {
        V v_t_249 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam1, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
        return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_249));
      }
      case TAG_Cons: {
        V v_d_2410 = heff_dup(heff_field(v_args_243, 0));
        V v_args2_2411 = heff_dup(heff_field(v_args_243, 1));
        switch (heff_tag_of(v_args2_2411)) {
        case TAG_Nil: {
          heff_drop(v_d_2410);
          V v_t_2413 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam2, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
          return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2413));
        }
        case TAG_Cons: {
          V v_args21_2414 = heff_field(v_args2_2411, 0);
          V v_args22_2415 = heff_field(v_args2_2411, 1);
          V v_ru_24args2_2411_24Cons = heff_take_reuse_n(v_args2_2411, 3ULL, 2);
          switch (heff_tag_of(v_args21_2414)) {
          case TAG_SVar: {
            heff_take_n(v_args21_2414, 0ULL, 1);
            heff_drop(v_d_2410);
            heff_drop(v_args22_2415);
            V v_t_2418 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam3, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2418));
          }
          case TAG_SGlobal: {
            heff_take_n(v_args21_2414, 0ULL, 1);
            heff_drop(v_d_2410);
            heff_drop(v_args22_2415);
            V v_t_2421 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam4, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2421));
          }
          case TAG_SInt: {
            V v_k_2422 = heff_field(v_args21_2414, 0);
            heff_take_n(v_args21_2414, 1ULL, 1);
            switch (heff_tag_of(v_args22_2415)) {
            case TAG_Nil: {
              heff_drop(v_d_2410);
              heff_drop(v_k_2422);
              V v_t_2424 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam5, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
              return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2424));
            }
            case TAG_Cons: {
              V v_v_2425 = heff_field(v_args22_2415, 0);
              V v_args222_2426 = heff_field(v_args22_2415, 1);
              heff_take_n(v_args22_2415, 3ULL, 2);
              switch (heff_tag_of(v_args222_2426)) {
              case TAG_Nil: {
                heff_drop(v_p_242);
                heff_drop_tag(v_args_243, 2);
                heff_drop_cell(v_ru_24args2_2411_24Cons, 2);
                V v_c_2427 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_d_2410; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_d_2410); r_; });
                V v_prec_2428 = heff_take_field(v_c_2427, 1);
                V v_code_2429 = heff_get_n(v_c_2427, 0, 2);
                V v_t_2430;
                if (heff_intLt_c(v_prec_2428, MK_INT(3LL))) {
                  v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str3), heff_strAppend(v_code_2429, ((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str4)));
                } else {
                  v_t_2430 = v_code_2429;
                }
                V v_c_2431 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2425; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2425); r_; });
                V v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str5), heff_get_n(v_c_2431, 0, 2));
                V v_t_2433 = heff_strAppend(heff_intShow(v_k_2422), v_t_2432);
                V v_t_2434 = heff_strAppend(v_t_2430, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str6), v_t_2433));
                return heff_rec_n(2, shape_code__prec, (V[]){v_t_2434, MK_INT(0LL)});
              }
              case TAG_Cons: {
                heff_take_n(v_args222_2426, 0ULL, 2);
                heff_drop(v_d_2410);
                heff_drop(v_k_2422);
                heff_drop(v_v_2425);
                V v_t_2438 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam6, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
                return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2438));
              }
              default: return heff_nomatch(v_args222_2426);
              }
            }
            default: return heff_nomatch(v_args22_2415);
            }
          }
          case TAG_SFloat: {
            heff_take_na(v_args21_2414, 0ULL, 1);
            heff_drop(v_d_2410);
            heff_drop(v_args22_2415);
            V v_t_2441 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam7, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2441));
          }
          case TAG_SStr: {
            heff_take_n(v_args21_2414, 0ULL, 1);
            heff_drop(v_d_2410);
            heff_drop(v_args22_2415);
            V v_t_2444 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam8, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2444));
          }
          case TAG_SBytes: {
            heff_take_n(v_args21_2414, 0ULL, 1);
            heff_drop(v_d_2410);
            heff_drop(v_args22_2415);
            V v_t_2447 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam9, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2447));
          }
          case TAG_SFixed: {
            heff_take_n(v_args21_2414, 0ULL, 2);
            heff_drop(v_d_2410);
            heff_drop(v_args22_2415);
            V v_t_2451 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam10, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2451));
          }
          case TAG_SFloat32: {
            heff_take_na(v_args21_2414, 0ULL, 1);
            heff_drop(v_d_2410);
            heff_drop(v_args22_2415);
            V v_t_2454 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam11, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2454));
          }
          case TAG_SPrimFn: {
            heff_take_n(v_args21_2414, 0ULL, 1);
            heff_drop(v_d_2410);
            heff_drop(v_args22_2415);
            V v_t_2457 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam12, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2457));
          }
          case TAG_SLam: {
            heff_take_n(v_args21_2414, 0ULL, 2);
            heff_drop(v_d_2410);
            heff_drop(v_args22_2415);
            V v_t_2461 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam13, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2461));
          }
          case TAG_STag: {
            heff_take_n(v_args21_2414, 0ULL, 3);
            heff_drop(v_d_2410);
            heff_drop(v_args22_2415);
            V v_t_2466 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam14, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2466));
          }
          case TAG_SRec: {
            heff_take_n(v_args21_2414, 0ULL, 2);
            heff_drop(v_d_2410);
            heff_drop(v_args22_2415);
            V v_t_2470 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam15, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2470));
          }
          case TAG_SProj: {
            heff_take_n(v_args21_2414, 0ULL, 4);
            heff_drop(v_d_2410);
            heff_drop(v_args22_2415);
            V v_t_2476 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam16, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2476));
          }
          case TAG_SPrim: {
            heff_take_n(v_args21_2414, 0ULL, 2);
            heff_drop(v_d_2410);
            heff_drop(v_args22_2415);
            V v_t_2480 = (g_list_2emap_24tok2(v_ru_24args2_2411_24Cons, heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam17, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2480));
          }
          default: return heff_nomatch(v_args21_2414);
          }
        }
        default: return heff_nomatch(v_args2_2411);
        }
      }
      default: return heff_nomatch(v_args_243);
      }
    } else {
      V v_t_2482 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam18, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
      return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2482));
    }
  }
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_246; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_246); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam1(V self, V *args) {
  V v_v_248 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_248; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_248); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam2(V self, V *args) {
  V v_v_2412 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2412; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2412); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam3(V self, V *args) {
  V v_v_2417 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2417; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2417); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam4(V self, V *args) {
  V v_v_2420 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2420; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2420); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam5(V self, V *args) {
  V v_v_2423 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2423; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2423); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam6(V self, V *args) {
  V v_v_2437 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2437; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2437); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam7(V self, V *args) {
  V v_v_2440 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2440; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2440); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam8(V self, V *args) {
  V v_v_2443 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2443; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2443); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam9(V self, V *args) {
  V v_v_2446 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2446; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2446); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam10(V self, V *args) {
  V v_v_2450 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2450; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2450); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam11(V self, V *args) {
  V v_v_2453 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2453; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2453); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam12(V self, V *args) {
  V v_v_2456 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2456; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2456); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam13(V self, V *args) {
  V v_v_2460 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2460; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2460); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam14(V self, V *args) {
  V v_v_2465 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2465; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2465); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam15(V self, V *args) {
  V v_v_2469 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2469; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2469); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam16(V self, V *args) {
  V v_v_2475 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2475; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2475); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam17(V self, V *args) {
  V v_v_2479 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2479; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2479); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam18(V self, V *args) {
  V v_v_2481 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2481; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2481); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str3, 6, "break;");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str7, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str8, 18, "default: $nomatch(");
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr(V v_ind_240, V v_arms_241, V v_sc_242) {
top: ;
  V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam0, 1, 2, (V[]){heff_dup(v_sc_242), heff_dup(v_ind_240)}), v_arms_241));
  V v_x2_2418 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str4)));
  V v_t_2421;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    v_t_2421 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str6); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2422 = heff_strAppend(heff_dup(heff_rfield(v_sc_242, 0)), ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str7));
  V v_t_2423 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str8), v_t_2422));
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
  V v_f_2425 = (g_heff_2ecompile_2eemit_2eswitchLines(heff_dup(v_sc_242), v_ind_240, v_t_2417, v_t_2424, NTAG(TAG_Nil)));
  V v_f_2426 = heff_get_n(v_sc_242, 1, 3);
  return ((HeffT2){{v_f_2425, v_f_2426}});
}
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam1(V self, V *args) {
  V v_e_249 = args[0];
  V v_i_2410 = args[1];
  V v_ss_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = ({ V a_0 = v_e_249; V a_1 = heff_dup(v_i_2410); V a_2 = v_ss_246; V b_3 = NTAG(TAG_Nothing); V r_ = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  V v_x2_2412 = (g_list_2ereplicate(v_i_2410, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str0)));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str2); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str3)), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(heff_get_n(v_t_2411, 0, 2), v_t_2416));
}
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam0(V self, V *args) {
  V v_arm_243 = args[0];
  V v_sc_242 = heff_env(self)[0];
  V v_ind_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_243)) {
  case TAG_MkArm: {
    V v_tag_244 = heff_field(v_arm_243, 0);
    V v_vs_245 = heff_field(v_arm_243, 1);
    V v_ss_246 = heff_field(v_arm_243, 2);
    V v_ru_24arm_243_24MkArm = heff_take_reuse_n(v_arm_243, 7ULL, 3);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_246)));
    V v_t_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_247); r_; });
    return ({ V a_0 = v_ru_24arm_243_24MkArm; V a_1 = v_sc_242; V a_2 = v_ind_240; V a_3 = v_tag_244; V a_4 = v_vs_245; V a_5 = v_t_248; V a_6 = heff_clo_n(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam1, 2, 1, (V[]){v_ss_246}); V r_ = (g_heff_2ecompile_2eemit_2earmJs_24tok3(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_248); r_; });
  }
  default: return heff_nomatch(v_arm_243);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str3, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str4, 16, "return $nomatch(");
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519(V v_ind_240, V v_arms_241, V v_sc_242) {
top: ;
  V v_t_2410 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam0, 1, 2, (V[]){heff_dup(v_sc_242), heff_dup(v_ind_240)}), v_arms_241));
  V v_x2_2411 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str0)));
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str2); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2415 = heff_strAppend(heff_dup(heff_rfield(v_sc_242, 0)), ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str3));
  V v_t_2416 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str4), v_t_2415));
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  return (g_heff_2ecompile_2eemit_2eswitchLines(v_sc_242, v_ind_240, v_t_2410, NTAG(TAG_Nil), v_t_2417));
}
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam1(V self, V *args) {
  V v_e_248 = args[0];
  V v_i_249 = args[1];
  V v_t_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_248; V a_1 = v_i_249; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
}
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam0(V self, V *args) {
  V v_arm_243 = args[0];
  V v_sc_242 = heff_env(self)[0];
  V v_ind_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_243)) {
  case TAG_MkArm: {
    V v_tag_244 = heff_field(v_arm_243, 0);
    V v_vs_245 = heff_field(v_arm_243, 1);
    V v_t_246 = heff_field(v_arm_243, 2);
    V v_ru_24arm_243_24MkArm = heff_take_reuse_n(v_arm_243, 7ULL, 3);
    V v_t_247 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_246, NTAG(TAG_Nil)));
    return ({ V a_0 = v_ru_24arm_243_24MkArm; V a_1 = v_sc_242; V a_2 = v_ind_240; V a_3 = v_tag_244; V a_4 = v_vs_245; V a_5 = v_t_247; V a_6 = heff_clo_n(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam1, 2, 1, (V[]){v_t_246}); V r_ = (g_heff_2ecompile_2eemit_2earmJs_24tok3(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_arm_243);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str2, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str5, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str6, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str7, 2, "{\012");
Clo g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(V v_env_240, V v_ind_241, V v_t_242) {
top: ;
  V v_x2_243 = heff_tr(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(v_env_240, heff_box_word((heff_peek_word(v_ind_241) + ((int64_t)1ULL))), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_x2_247 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str2)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str5), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str6)));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str7), heff_strAppend(v_t_246, v_t_2411));
}
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eextStr_str0, 243, "const $ext = (v) => typeof v === \"function\" \? (x) => $ext($tr(v(x))) : v !== null && typeof v === \"object\" && !Array.isArray(v) && !ArrayBuffer.isView(v) && !(\"$\" in v) \? Object.fromEntries(Object.entries(v).map(([l, x]) => [l, $ext(x)])) : v;");

static V g_heff_2ecompile_2eemit_2eextStr_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2eextStr_st;
static V g_heff_2ecompile_2eemit_2eextStr_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2eextStr_str0);
}
V g_heff_2ecompile_2eemit_2eextStr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2eextStr_st)) return g_heff_2ecompile_2eemit_2eextStr_val;
  return heff_global(&g_heff_2ecompile_2eemit_2eextStr_val, &g_heff_2ecompile_2eemit_2eextStr_st, g_heff_2ecompile_2eemit_2eextStr_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str0, 5, "$lazy");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str1, 4, "$Bnc");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str2, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str3, 4, "$tr(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str4, 2, "$T");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str5, 2, "$F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str6, 60, "const $T = { $: \"True\", a: [] }, $F = { $: \"False\", a: [] };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str7, 8, "$abandon");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str8, 60, "const $abandon = () => { throw new Error(\"heff:abandon\"); };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str9, 8, "$nomatch");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str10, 87, "const $nomatch = (s) => { throw new Error(\"heff: no case for '\" + (s && s.$) + \"'\"); };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str11, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str12, 125, "const $force = (f) => { if (f.$m !== undefined) return f.$m; const v = $tr(f({ $: \"MkUnit\", a: [] })); f.$m = v; return v; };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str13, 5, "$lazy");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str14, 243, "const $lazy = (f) => { let state = 0, v; return () => { if (state === 2) return v; if (state === 1) throw new Error(\"heff: defined by itself\"); state = 1; try { v = $tr(f()); state = 2; return v; } finally { if (state === 1) state = 0; } }; };");
Clo g_heff_2ecompile_2eemit_2eruntime_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eruntime_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eruntime(V v_code_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str0), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str2), v_t_241})});
  V v_t_243 = ({ V a_0 = MK_INT(0LL); V a_1 = v_code_240; V b_2 = MK_INT(0LL); V b_3 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str3), v_t_242}); V r_ = (g_list_2eany_24s1027174601x1571638094(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
  V v_t_244;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    v_t_244 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get())});
  } else {
    heff_drop(v_t_243);
    v_t_244 = NTAG(TAG_Nothing);
  }
  V v_t_245;
  if ((heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str4), v_code_240, MK_INT(0LL), 5)) || heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str5), v_code_240, MK_INT(0LL), 5)))) {
    v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str6)});
  } else {
    v_t_245 = NTAG(TAG_Nothing);
  }
  V v_t_246;
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str7), v_code_240, MK_INT(0LL), 5))) {
    v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str8)});
  } else {
    v_t_246 = NTAG(TAG_Nothing);
  }
  V v_t_247;
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str9), v_code_240, MK_INT(0LL), 5))) {
    v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str10)});
  } else {
    v_t_247 = NTAG(TAG_Nothing);
  }
  V v_t_248;
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str11), v_code_240, MK_INT(0LL), 5))) {
    v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str12)});
  } else {
    v_t_248 = NTAG(TAG_Nothing);
  }
  V v_t_249;
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str13), v_code_240, MK_INT(0LL), 5))) {
    v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str14)});
  } else {
    v_t_249 = NTAG(TAG_Nothing);
  }
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2411})});
  V v_t_2413 = (g_heff_2ecompile_2eemit_2ecatMaybesL(heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2412})));
  V v_t_2414 = ({ V a_0 = MK_INT(0LL); V a_1 = v_code_240; V b_2 = MK_INT(0LL); V a_3 = heff_dup(g_heff_2ecompile_2eemit_2estrHelpers_get()); V r_ = (g_list_2emap_24s319754340x1392149466(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
  V v_t_2415 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2414));
  return (g_prelude_2e_2b_2b(v_t_2413, v_t_2415));
}
V g_heff_2ecompile_2eemit_2eruntime_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eruntime(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2einfoOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2einfoOne_entry, 4, 0};

V g_heff_2ecompile_2eemit_2einfoOne(V v_shorts_240, V v_facts_241, V v_acc_242, V v_key_243) {
top: ;
  V v_arity_244 = heff_take_field(v_facts_241, 0);
  V v_lazy_245 = heff_take_field(v_facts_241, 2);
  V v_bounce_246 = heff_get_n(v_facts_241, 1, 11);
  V v_t_247 = (g_heff_2ecompile_2eemit_2ejsNameOf(v_shorts_240, heff_dup(v_key_243)));
  HeffT2 v_t_248 = ({ V a_0 = v_arity_244; V a_1 = v_key_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_arity_244); r_; });
  V v_t_2412;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_2410;
      v_t_2412 = v_x_2411;
    } else {
      heff_drop(v_field_2410);
      v_t_2412 = MK_INT(0LL);
    }
  }
  HeffT2 v_t_2413 = ({ V a_0 = v_lazy_245; V a_1 = v_key_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_lazy_245); r_; });
  V v_t_2417;
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    v_t_2417 = heff_bool(((v_tag_2414 == ((int64_t)0ULL)) && ({ V v_x_2416 = heff_dup(v_field_2415); int c_ = 1; heff_drop(v_x_2416); c_; })));
    heff_drop(v_field_2415);
  }
  HeffT2 v_t_2418 = ({ V a_0 = v_bounce_246; V a_1 = v_key_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_bounce_246); r_; });
  V v_t_2422;
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    v_t_2422 = heff_bool(((v_tag_2419 == ((int64_t)0ULL)) && ({ V v_x_2421 = heff_dup(v_field_2420); int c_ = 1; heff_drop(v_x_2421); c_; })));
    heff_drop(v_field_2420);
  }
  return (g_std_2emap_2einsert_24s93785294x875597928(v_acc_242, v_key_243, heff_rec_n(4, shape_js__arity__lazy__bounce, (V[]){v_t_247, v_t_2412, v_t_2417, v_t_2422})));
}
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2einfoOne(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntimeFor_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntimeFor_str1, 1, "\012");
Clo g_heff_2ecompile_2eemit_2eruntimeFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eruntimeFor_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eruntimeFor(V v_hasTr_240, V v_have_241, V v_provs_242, V v_eff_243) {
top: ;
  V v_t_244;
  if ((heff_dup(v_hasTr_240) == NTAG(TAG_True))) {
    v_t_244 = NTAG(TAG_Nil);
  } else {
    v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()), NTAG(TAG_Nil)});
  }
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2erunStr_get()), NTAG(TAG_Nil)});
  V v_t_246 = (g_prelude_2e_2b_2b(v_t_244, v_t_245));
  V v_t_2410;
  switch (heff_tag_of(v_eff_243)) {
  case TAG_Leaf: {
    heff_take_n(v_eff_243, 0ULL, 1);
    v_t_2410 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Plus: {
    V v_ru_24eff_243_24Plus = heff_take_reuse_n(v_eff_243, 0ULL, 2);
    v_t_2410 = heff_tag_at_n(v_ru_24eff_243_24Plus, TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2esumStr_get()), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_eff_243);
  }
  V v_t_2411 = (g_heff_2ecompile_2eemit_2eprovStrHelpers(v_have_241, heff_dup(v_provs_242)));
  V v_t_2412 = (g_heff_2ecompile_2eemit_2ebundleAll(MK_INT(0LL), v_provs_242));
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2412));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2413));
  V v_x2_2415 = (g_prelude_2e_2b_2b(v_t_246, v_t_2414));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2eemit_2eruntimeFor_str0);
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eruntimeFor_str1); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eemit_2eruntimeFor_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2eruntimeFor(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str3, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str4, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str5, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str6, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str7, 2, "()");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str8, 2, "$p");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str9, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str10, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str11, 5, "$sum(");
Clo g_heff_2ecompile_2eemit_2ehandlerOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ehandlerOf_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ehandlerOf(V v_provs_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_t_243 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str0); V a_1 = v_k_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str1), v_k_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_244 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_243));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_247; V a_2 = v_provs_240; V r_ = (g_heff_2ecompile_2eemit_2eprovIndexGo(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
    V v_t_249 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str4); V a_1 = v_k_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str5), v_k_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_t_2410 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_t_249; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str6), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str7)));
    V v_t_2412 = heff_strAppend(heff_intShow(v_t_248), v_t_2411);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str8), v_t_2412);
  }
  case TAG_Plus: {
    V v_a_2413 = heff_field(v_x2_241, 0);
    V v_b_2414 = heff_field(v_x2_241, 1);
    V v_t_2415 = (g_heff_2ecompile_2eemit_2ehandlerOf(v_provs_240, v_a_2413));
    V v_t_2416 = (g_heff_2ecompile_2eemit_2ehandlerOf(v_provs_240, v_b_2414));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str9), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str10)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str11), heff_strAppend(v_t_2415, v_t_2417));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2ehandlerOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ehandlerOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eimportLinesOf_str0, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eimportLinesOf_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eimportLinesOf_str2, 7, "import ");
Clo g_heff_2ecompile_2eemit_2eimportLinesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eimportLinesOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eimportLinesOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_s_243 = heff_dup(heff_rfield(v_p_241, 1));
    V v_t_244 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str0); V a_1 = v_s_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str1), v_s_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_243); r_; });
    V v_t_245 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(7LL); V b_2 = ((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str2); V a_3 = v_t_244; V r_ = (g_list_2ekeepIf_24s185327080x101197346(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
    V v_t_246 = (g_heff_2ecompile_2eemit_2eimportLinesOf(v_rest_242));
    return (g_prelude_2e_2b_2b(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2eimportLinesOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eimportLinesOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2ecompileJsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecompileJsWith_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecompileJsWith(V v_g_240, V v_exports_241) {
top: ;
  V v_roots_242 = (g_list_2emap_24s152505078x225062837(heff_dup(v_exports_241)));
  V v_t_243 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_g_240));
  HeffT3 v_t_244 = (g_heff_2ecompile_2elower_2elowerErased_24cpr(v_roots_242, v_t_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_field_247 = v_t_244.f[2];
    V v_roots_248 = (g_list_2emap_24s152505078x225062837(heff_dup(v_exports_241)));
    V v_t_249 = ({ V a_0 = v_field_246; V a_1 = v_field_245; V a_2 = v_roots_248; V b_3 = heff_dup(g_std_2emap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemit_2eemitKept(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    V v_t_2410 = (g_heff_2ecompile_2eemit_2ejsSource(v_exports_241, heff_get_n(v_t_249, 0, 2)));
    return heff_rec_n(2, shape_source__errors, (V[]){v_t_2410, v_field_247});
  }
}
V g_heff_2ecompile_2eemit_2ecompileJsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecompileJsWith(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2earmJs_24tok3_str0, 0, "");
V g_heff_2ecompile_2eemit_2earmJs_24tok3_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2earmJs_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2earmJs_24tok3_entry, 7, 0};

V g_heff_2ecompile_2eemit_2earmJs_24tok3(V v_tok_240, V v_sc_241, V v_ind_242, V v_tag_243, V v_vs_244, V v_parts_245, V v_lines_246) {
top: ;
  V v_t_249 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2eemit_2earmJs_24tok3_lam0, 1, 1, (V[]){heff_dup(v_parts_245)}), v_vs_244));
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_vs_244);
    heff_drop(v_t_249);
    V v_t_2410 = heff_tr(heff_call(v_lines_246, 2, (V[]){heff_get_n(v_sc_241, 1, 3), heff_intAdd(v_ind_242, MK_INT(2LL))}));
    return heff_tag_at_n(v_tok_240, TAG_MkArmJs, 3, (V[]){v_tag_243, NTAG(TAG_True), v_t_2410});
  } else {
    heff_drop_cell(v_tok_240, 3);
    heff_drop(v_t_249);
    V v_t_2411 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), heff_dup(heff_rfield(v_sc_241, 1))});
    V v_t_2412 = (g_list_2efoldl_24s2018454372x1607369768(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2earmJs_24tok3_str0), MK_INT(0LL), v_t_2411, v_vs_244));
    return (g_heff_2ecompile_2eemit_2earmBound(v_sc_241, v_ind_242, v_tag_243, v_lines_246, v_t_2412));
  }
}
V g_heff_2ecompile_2eemit_2earmJs_24tok3_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2eemit_2earmJs_24tok3(a[0], a[1], a[2], a[3], a[4], a5, a[6]); heff_drop(a5); return r;
}
V g_heff_2ecompile_2eemit_2earmJs_24tok3_lam0(V self, V *args) {
  V v_v_247 = args[0];
  V v_parts_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_248 = ({ V a_0 = v_v_247; V a_1 = v_parts_245; V r_ = (g_list_2eany_24s1877524499x1789047582(a_0, a_1)); heff_drop(v_v_247); heff_drop(v_parts_245); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_248) == NTAG(TAG_True)));
  heff_drop(v_x1_248);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_str3, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_str4, 16, "return $nomatch(");
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_entry, 4, 0};

V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2(V v_tok_240, V v_ind_241, V v_arms_242, V v_sc_243) {
top: ;
  V v_t_2411 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_lam0, 1, 2, (V[]){heff_dup(v_sc_243), heff_dup(v_ind_241)}), v_arms_242));
  V v_x2_2412 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_str0)));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_str2); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2416 = heff_strAppend(heff_dup(heff_rfield(v_sc_243, 0)), ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_str3));
  V v_t_2417 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_str4), v_t_2416));
  V v_t_2418 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
  return (g_heff_2ecompile_2eemit_2eswitchLines(v_sc_243, v_ind_241, v_t_2411, NTAG(TAG_Nil), v_t_2418));
}
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_lam1(V self, V *args) {
  V v_e_249 = args[0];
  V v_i_2410 = args[1];
  V v_t_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_249; V a_1 = v_i_2410; V a_2 = v_t_247; V r_ = (g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
}
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_lam0(V self, V *args) {
  V v_arm_244 = args[0];
  V v_sc_243 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_244)) {
  case TAG_MkArm: {
    V v_tag_245 = heff_field(v_arm_244, 0);
    V v_vs_246 = heff_field(v_arm_244, 1);
    V v_t_247 = heff_field(v_arm_244, 2);
    V v_ru_24arm_244_24MkArm = heff_take_reuse_n(v_arm_244, 7ULL, 3);
    V v_t_248 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_247, NTAG(TAG_Nil)));
    return ({ V a_0 = v_ru_24arm_244_24MkArm; V a_1 = v_sc_243; V a_2 = v_ind_241; V a_3 = v_tag_245; V a_4 = v_vs_246; V a_5 = v_t_248; V a_6 = heff_clo_n(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_lam1, 2, 1, (V[]){v_t_247}); V r_ = (g_heff_2ecompile_2eemit_2earmJs_24tok3(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_248); r_; });
  }
  default: return heff_nomatch(v_arm_244);
  }
}