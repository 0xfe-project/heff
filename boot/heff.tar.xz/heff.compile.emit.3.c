// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Leaf 13717
#define TAG_MkArm 55352
#define TAG_Plus 9189
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_arity 294440695
#define LBL_bounce 563936691
#define LBL_code 9554612
#define LBL_emitted 749050271
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_gs 10067
#define LBL_js 10160
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_pre 320797
#define LBL_prec 9944807
#define LBL_source 1050636102
#define LBL_text 10052084
static uint32_t shape_code__prec[] = {LBL_code, LBL_prec};
static uint32_t shape_js__arity__lazy__bounce[] = {LBL_js, LBL_arity, LBL_lazy, LBL_bounce};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eemit_2earmJs(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmJs_clo;
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(V, V, V);
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_clo;
V g_heff_2ecompile_2eemit_2ebounceGive(V, V, V);
V g_heff_2ecompile_2eemit_2ebounceGive_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebounceGive_clo;
V g_heff_2ecompile_2eemit_2ebundleAll(V, V);
V g_heff_2ecompile_2eemit_2ebundleAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleAll_clo;
V g_heff_2ecompile_2eemit_2ecallName(V, V);
V g_heff_2ecompile_2eemit_2ecallName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallName_clo;
V g_heff_2ecompile_2eemit_2ecallsHelper(V, V);
V g_heff_2ecompile_2eemit_2ecallsHelper_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallsHelper_clo;
HeffT2 g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519(V, V, V);
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(V, V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_clo;
V g_heff_2ecompile_2eemit_2ecellPrim(V, V);
V g_heff_2ecompile_2eemit_2ecellPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecellPrim_clo;
V g_heff_2ecompile_2eemit_2ecompileJsWith(V, V);
V g_heff_2ecompile_2eemit_2ecompileJsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJsWith_clo;
V g_heff_2ecompile_2eemit_2eemitKept(V, V, V, V);
V g_heff_2ecompile_2eemit_2eemitKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eemitKept_clo;
V g_heff_2ecompile_2eemit_2eextStr_get(void);
V g_heff_2ecompile_2eemit_2ehandlerOf(V, V);
V g_heff_2ecompile_2eemit_2ehandlerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehandlerOf_clo;
V g_heff_2ecompile_2eemit_2eimportLinesOf(V);
V g_heff_2ecompile_2eemit_2eimportLinesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eimportLinesOf_clo;
V g_heff_2ecompile_2eemit_2einfoOne(V, V, V, V);
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2einfoOne_clo;
V g_heff_2ecompile_2eemit_2ejsNameOf(V, V);
V g_heff_2ecompile_2eemit_2ejsNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsNameOf_clo;
V g_heff_2ecompile_2eemit_2ejsSource(V, V);
V g_heff_2ecompile_2eemit_2ejsSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsSource_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2eloops(V);
V g_heff_2ecompile_2eemit_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eloops_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2enubGo_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2enubGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_24dps_clo;
HeffT2 g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2eprimCall(V, V);
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimCall_clo;
HeffT2 g_heff_2ecompile_2eemit_2eprimOp_24cpr(V);
V g_heff_2ecompile_2eemit_2eprimTest(V, V, V);
V g_heff_2ecompile_2eemit_2eprimTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimTest_clo;
HeffT2 g_heff_2ecompile_2eemit_2eprimUnary_24cpr(V);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584(V, V, V, V);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_clo;
V g_heff_2ecompile_2eemit_2eprovIndexGo(V, V, V);
V g_heff_2ecompile_2eemit_2eprovIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovIndexGo_clo;
V g_heff_2ecompile_2eemit_2eprovStrHelpers(V, V);
V g_heff_2ecompile_2eemit_2eprovStrHelpers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovStrHelpers_clo;
V g_heff_2ecompile_2eemit_2erunStr_get(void);
V g_heff_2ecompile_2eemit_2eruntime(V);
V g_heff_2ecompile_2eemit_2eruntime_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntime_clo;
V g_heff_2ecompile_2eemit_2eruntimeFor(V, V, V, V);
V g_heff_2ecompile_2eemit_2eruntimeFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntimeFor_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeRes(V);
V g_heff_2ecompile_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeRes_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(V, V, V, V);
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_clo;
V g_heff_2ecompile_2eemit_2estrHelpers_get(void);
V g_heff_2ecompile_2eemit_2esumStr_get(void);
V g_heff_2ecompile_2eemit_2eswitchLines(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2eswitchLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eswitchLines_clo;
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(V, V, V);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V, V, V);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo;
HeffT2 g_heff_2ecompile_2eemit_2ewordOf_24cpr(V);
V g_heff_2ecompile_2eemit_2eworldStr_get(void);
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
HeffT3 g_heff_2ecompile_2elower_2elowerErased_24cpr(V, V);
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1073020508x1907354150(V, V, V, V);
V g_list_2eany_24s1073020508x1907354150_entry(V self, V *a);
extern Clo g_list_2eany_24s1073020508x1907354150_clo;
V g_list_2eany_24s184951243x1948563855(V);
V g_list_2eany_24s184951243x1948563855_entry(V self, V *a);
extern Clo g_list_2eany_24s184951243x1948563855_clo;
V g_list_2efilter_24s1820448628x561773228(V, V, V, V);
V g_list_2efilter_24s1820448628x561773228_entry(V self, V *a);
extern Clo g_list_2efilter_24s1820448628x561773228_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s357242026x384251201(V);
V g_list_2emap_24s357242026x384251201_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_clo;
V g_list_2emap_24s567711145x425963688(V, V, V, V);
V g_list_2emap_24s567711145x425963688_entry(V self, V *a);
extern Clo g_list_2emap_24s567711145x425963688_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
HeffT2 g_map_2elookup_24s1546226666x2146984184_24cpr(V, V);
HeffT2 g_map_2elookup_24s659669741x1036301430_24cpr(V, V);
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecatMaybesL_entry, 1, 0};

V g_heff_2ecompile_2eemit_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecatMaybesL(a[0]);
}
Clo g_heff_2ecompile_2eemit_2enubGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enubGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2enubGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_list_2eany(v_t_244, v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_xs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2eemit_2enubGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_xs_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enubGo(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(V v_x_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) <= v_i_241)) {
    heff_drop(v_x_240);
    V v_f_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_244}});
  } else {
    HeffT2 v_t_245 = (g_heff_2ecompile_2eemit_2ewordOf_24cpr(heff_strByteAt_lent(v_x_240, heff_box_word(v_i_241), 2)));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_w_249 = v_field_247;
        V t_0 = v_x_240;
        int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_w_249, v_acc_242});
        v_x_240 = t_0;
        v_i_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      } else {
        heff_drop(v_x_240);
        heff_drop(v_acc_242);
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str0, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str5, 10, " \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str6, 1, " ");
Clo g_heff_2ecompile_2eemit_2eprimTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimTest_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprimTest(V v_op_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_245;
  if (heff_intLt_c(heff_dup(heff_rfield(v_a_241, 1)), MK_INT(2LL))) {
    V v_t_244 = heff_strAppend(heff_get_n(v_a_241, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimTest_str0));
    v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str1), v_t_244);
  } else {
    v_t_245 = heff_get_n(v_a_241, 0, 2);
  }
  V v_t_248;
  if (heff_intLt_c(heff_dup(heff_rfield(v_b_242, 1)), MK_INT(2LL))) {
    V v_t_247 = heff_strAppend(heff_get_n(v_b_242, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimTest_str2));
    v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str3), v_t_247);
  } else {
    v_t_248 = heff_get_n(v_b_242, 0, 2);
  }
  V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str4), heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemit_2eprimTest_str5)));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str6), heff_strAppend(v_op_240, v_t_249));
  return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_245, v_t_2410), MK_INT(0LL)});
}
V g_heff_2ecompile_2eemit_2eprimTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimTest(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str4, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str8, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str9, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str11, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str14, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str16, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str17, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str18, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str19, 1, "$");
Clo g_heff_2ecompile_2eemit_2eprimCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimCall_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprimCall(V v_p_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_as_241)) {
  case TAG_Nil: {
    V v_x2_242 = (g_list_2emap_24s357242026x384251201(v_as_241));
    V v_t_245;
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str2), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str3)));
    V v_code_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str4), heff_strAppend(v_p_240, v_t_246));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_247, MK_INT(3LL)});
  }
  case TAG_Cons: {
    V v_a_248 = heff_dup(heff_field(v_as_241, 0));
    V v_as2_249 = heff_dup(heff_field(v_as_241, 1));
    switch (heff_tag_of(v_as2_249)) {
    case TAG_Nil: {
      HeffT2 v_t_2410 = (g_heff_2ecompile_2eemit_2eprimUnary_24cpr(heff_dup(v_p_240)));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop(v_p_240);
          heff_drop_tag(v_as_241, 2);
          V v_f_2414 = v_field_2412;
          return heff_tail(v_f_2414, 1, (V[]){v_a_248});
        } else {
          heff_drop(v_a_248);
          heff_drop(v_field_2412);
          V v_x2_2415 = (g_list_2emap_24s357242026x384251201(v_as_241));
          V v_t_2418;
          switch (heff_tag_of(v_x2_2415)) {
          case TAG_Nil: {
            v_t_2418 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str5);
            break;
          }
          case TAG_Cons: {
            V v_x_2416 = heff_field(v_x2_2415, 0);
            V v_xs_2417 = heff_field(v_x2_2415, 1);
            heff_take_n(v_x2_2415, 3ULL, 2);
            v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str6); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2415);
          }
          V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str7), heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str8)));
          V v_code_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str9), heff_strAppend(v_p_240, v_t_2419));
          return heff_rec_n(2, shape_code__prec, (V[]){v_code_2420, MK_INT(3LL)});
        }
      }
    }
    case TAG_Cons: {
      V v_b_2421 = heff_field(v_as2_249, 0);
      V v_as22_2422 = heff_field(v_as2_249, 1);
      heff_take_n(v_as2_249, 3ULL, 2);
      switch (heff_tag_of(v_as22_2422)) {
      case TAG_Nil: {
        HeffT2 v_t_2423 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(heff_dup(v_p_240)));
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            heff_drop(v_p_240);
            heff_drop_tag(v_as_241, 2);
            V v_f_2427 = v_field_2425;
            return heff_tail(v_f_2427, 2, (V[]){v_a_248, v_b_2421});
          } else {
            heff_drop(v_a_248);
            heff_drop(v_b_2421);
            heff_drop(v_field_2425);
            V v_x2_2428 = (g_list_2emap_24s357242026x384251201(v_as_241));
            V v_t_2431;
            switch (heff_tag_of(v_x2_2428)) {
            case TAG_Nil: {
              v_t_2431 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str10);
              break;
            }
            case TAG_Cons: {
              V v_x_2429 = heff_field(v_x2_2428, 0);
              V v_xs_2430 = heff_field(v_x2_2428, 1);
              heff_take_n(v_x2_2428, 3ULL, 2);
              v_t_2431 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str11); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2428);
            }
            V v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str12), heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str13)));
            V v_code_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str14), heff_strAppend(v_p_240, v_t_2432));
            return heff_rec_n(2, shape_code__prec, (V[]){v_code_2433, MK_INT(3LL)});
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_as22_2422, 0ULL, 2);
        heff_drop(v_a_248);
        heff_drop(v_b_2421);
        V v_x2_2436 = (g_list_2emap_24s357242026x384251201(v_as_241));
        V v_t_2439;
        switch (heff_tag_of(v_x2_2436)) {
        case TAG_Nil: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str15);
          break;
        }
        case TAG_Cons: {
          V v_x_2437 = heff_field(v_x2_2436, 0);
          V v_xs_2438 = heff_field(v_x2_2436, 1);
          heff_take_n(v_x2_2436, 3ULL, 2);
          v_t_2439 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str16); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2436);
        }
        V v_t_2440 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str17), heff_strAppend(v_t_2439, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str18)));
        V v_code_2441 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str19), heff_strAppend(v_p_240, v_t_2440));
        return heff_rec_n(2, shape_code__prec, (V[]){v_code_2441, MK_INT(3LL)});
      }
      default: return heff_nomatch(v_as22_2422);
      }
    }
    default: return heff_nomatch(v_as2_249);
    }
  }
  default: return heff_nomatch(v_as_241);
  }
}
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimCall(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2ecallsHelper_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecallsHelper_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecallsHelper(V v_p_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_as_241)) {
  case TAG_Nil: {
    V v_x1_242 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_242) == NTAG(TAG_True)));
    heff_drop(v_x1_242);
    return v_ret_24bool;
  }
  case TAG_Cons: {
    V v_as2_244 = heff_field(v_as_241, 1);
    switch (heff_tag_of(v_as2_244)) {
    case TAG_Nil: {
      HeffT2 v_t_245 = (g_heff_2ecompile_2eemit_2eprimUnary_24cpr(v_p_240));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        V v_ret_24bool = heff_bool(((v_tag_246 == ((int64_t)0ULL)) ? ({ V v_x_249 = heff_dup(v_field_247); int c_ = 0; heff_drop(v_x_249); c_; }) : 1));
        heff_drop(v_field_247);
        return v_ret_24bool;
      }
    }
    case TAG_Cons: {
      V v_as21_2410 = heff_field(v_as2_244, 0);
      V v_as22_2411 = heff_field(v_as2_244, 1);
      switch (heff_tag_of(v_as21_2410)) {
      case TAG_SVar: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_2413 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2415 = v_t_2413.f[1];
            int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2414 == ((int64_t)0ULL)) ? ({ V v_x_2417 = heff_dup(v_field_2415); int c_ = 0; heff_drop(v_x_2417); c_; }) : 1));
            heff_drop(v_field_2415);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2420 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2420) == NTAG(TAG_True)));
          heff_drop(v_x1_2420);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      case TAG_SGlobal: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_2422 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2424 = v_t_2422.f[1];
            int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2423 == ((int64_t)0ULL)) ? ({ V v_x_2426 = heff_dup(v_field_2424); int c_ = 0; heff_drop(v_x_2426); c_; }) : 1));
            heff_drop(v_field_2424);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2429 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2429) == NTAG(TAG_True)));
          heff_drop(v_x1_2429);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      case TAG_SInt: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_2431 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2433 = v_t_2431.f[1];
            int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2432 == ((int64_t)0ULL)) ? ({ V v_x_2435 = heff_dup(v_field_2433); int c_ = 0; heff_drop(v_x_2435); c_; }) : 1));
            heff_drop(v_field_2433);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_as222_2437 = heff_field(v_as22_2411, 1);
          switch (heff_tag_of(v_as222_2437)) {
          case TAG_Nil: {
            V v_x1_2438 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
            V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2438) == NTAG(TAG_True)));
            heff_drop(v_x1_2438);
            return v_ret_24bool;
          }
          case TAG_Cons: {
            V v_x1_2441 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
            V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2441) == NTAG(TAG_True)));
            heff_drop(v_x1_2441);
            return v_ret_24bool;
          }
          default: return heff_nomatch(v_as222_2437);
          }
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      case TAG_SFloat: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_2443 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2445 = v_t_2443.f[1];
            int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2444 == ((int64_t)0ULL)) ? ({ V v_x_2447 = heff_dup(v_field_2445); int c_ = 0; heff_drop(v_x_2447); c_; }) : 1));
            heff_drop(v_field_2445);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2450 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2450) == NTAG(TAG_True)));
          heff_drop(v_x1_2450);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      case TAG_SStr: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_2452 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2454 = v_t_2452.f[1];
            int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2453 == ((int64_t)0ULL)) ? ({ V v_x_2456 = heff_dup(v_field_2454); int c_ = 0; heff_drop(v_x_2456); c_; }) : 1));
            heff_drop(v_field_2454);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2459 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2459) == NTAG(TAG_True)));
          heff_drop(v_x1_2459);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      case TAG_SBytes: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_2461 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2463 = v_t_2461.f[1];
            int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2462 == ((int64_t)0ULL)) ? ({ V v_x_2465 = heff_dup(v_field_2463); int c_ = 0; heff_drop(v_x_2465); c_; }) : 1));
            heff_drop(v_field_2463);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2468 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2468) == NTAG(TAG_True)));
          heff_drop(v_x1_2468);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      case TAG_SFixed: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_2471 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2473 = v_t_2471.f[1];
            int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2472 == ((int64_t)0ULL)) ? ({ V v_x_2475 = heff_dup(v_field_2473); int c_ = 0; heff_drop(v_x_2475); c_; }) : 1));
            heff_drop(v_field_2473);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2478 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2478) == NTAG(TAG_True)));
          heff_drop(v_x1_2478);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      case TAG_SFloat32: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_2480 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2482 = v_t_2480.f[1];
            int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2481 == ((int64_t)0ULL)) ? ({ V v_x_2484 = heff_dup(v_field_2482); int c_ = 0; heff_drop(v_x_2484); c_; }) : 1));
            heff_drop(v_field_2482);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2487 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2487) == NTAG(TAG_True)));
          heff_drop(v_x1_2487);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      case TAG_SPrimFn: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_2489 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2491 = v_t_2489.f[1];
            int64_t v_tag_2490 = ((int64_t)v_t_2489.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2490 == ((int64_t)0ULL)) ? ({ V v_x_2493 = heff_dup(v_field_2491); int c_ = 0; heff_drop(v_x_2493); c_; }) : 1));
            heff_drop(v_field_2491);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_2496 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2496) == NTAG(TAG_True)));
          heff_drop(v_x1_2496);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      case TAG_SLam: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_2499 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_24101 = v_t_2499.f[1];
            int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_24100 == ((int64_t)0ULL)) ? ({ V v_x_24103 = heff_dup(v_field_24101); int c_ = 0; heff_drop(v_x_24103); c_; }) : 1));
            heff_drop(v_field_24101);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_24106 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24106) == NTAG(TAG_True)));
          heff_drop(v_x1_24106);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      case TAG_STag: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_24110 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_24112 = v_t_24110.f[1];
            int64_t v_tag_24111 = ((int64_t)v_t_24110.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_24111 == ((int64_t)0ULL)) ? ({ V v_x_24114 = heff_dup(v_field_24112); int c_ = 0; heff_drop(v_x_24114); c_; }) : 1));
            heff_drop(v_field_24112);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_24117 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24117) == NTAG(TAG_True)));
          heff_drop(v_x1_24117);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      case TAG_SRec: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_24120 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_24122 = v_t_24120.f[1];
            int64_t v_tag_24121 = ((int64_t)v_t_24120.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_24121 == ((int64_t)0ULL)) ? ({ V v_x_24124 = heff_dup(v_field_24122); int c_ = 0; heff_drop(v_x_24124); c_; }) : 1));
            heff_drop(v_field_24122);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_24127 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24127) == NTAG(TAG_True)));
          heff_drop(v_x1_24127);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      case TAG_SProj: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_24132 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_24134 = v_t_24132.f[1];
            int64_t v_tag_24133 = ((int64_t)v_t_24132.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_24133 == ((int64_t)0ULL)) ? ({ V v_x_24136 = heff_dup(v_field_24134); int c_ = 0; heff_drop(v_x_24136); c_; }) : 1));
            heff_drop(v_field_24134);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_24139 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24139) == NTAG(TAG_True)));
          heff_drop(v_x1_24139);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      case TAG_SPrim: {
        switch (heff_tag_of(v_as22_2411)) {
        case TAG_Nil: {
          HeffT2 v_t_24142 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_24144 = v_t_24142.f[1];
            int64_t v_tag_24143 = ((int64_t)v_t_24142.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_24143 == ((int64_t)0ULL)) ? ({ V v_x_24146 = heff_dup(v_field_24144); int c_ = 0; heff_drop(v_x_24146); c_; }) : 1));
            heff_drop(v_field_24144);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_x1_24149 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_as_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24149) == NTAG(TAG_True)));
          heff_drop(v_x1_24149);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_as22_2411);
        }
      }
      default: return heff_nomatch(v_as21_2410);
      }
    }
    default: return heff_nomatch(v_as2_244);
    }
  }
  default: return heff_nomatch(v_as_241);
  }
}
V g_heff_2ecompile_2eemit_2ecallsHelper_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ecallsHelper(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallName_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallName_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallName_str2, 1, "x");
Clo g_heff_2ecompile_2eemit_2ecallName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecallName_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecallName(V v_env_240, V v_g_241) {
top: ;
  HeffT2 v_t_242 = ({ V a_0 = heff_dup(v_g_241); V b_1 = heff_get_n(v_env_240, 0, 5); HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_g_241);
      V v_i_246 = v_field_244;
      return heff_get_n(v_i_246, 0, 4);
    } else {
      heff_drop(v_field_244);
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_g_241, 0)) - ((int64_t)1ULL));
      V v_t_248 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_g_241), heff_box_word(v_t_247)));
      V v_t_249 = ({ V a_0 = v_g_241; V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_s_2410 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_249, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2ecallName_str0)));
      V v_t_2412;
      if (heff_strEq_c_lent(v_s_2410, ((V)&g_heff_2ecompile_2eemit_2ecallName_str1), 2)) {
        heff_drop(v_s_2410);
        v_t_2412 = ((V)&g_heff_2ecompile_2eemit_2ecallName_str2);
      } else {
        v_t_2412 = v_s_2410;
      }
      return (g_heff_2ecompile_2eemit_2esafeRes(v_t_2412));
    }
  }
}
V g_heff_2ecompile_2eemit_2ecallName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecallName(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str3, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str5, 4, ") : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str7, 3, "500");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str8, 12, " \? new $Bnc(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str9, 16, "return ++$dep > ");
Clo g_heff_2ecompile_2eemit_2ebounceGive_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebounceGive_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ebounceGive(V v_ind_240, V v_f_241, V v_a_242) {
top: ;
  V v_x2_243 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str0)));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str2); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_a_242, 0)), ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str3));
  V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_f_241, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str4), v_t_247));
  V v_t_249 = heff_strAppend(heff_take_field(v_a_242, 0), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str5), v_t_248));
  V v_t_2410 = heff_strAppend(heff_take_field(v_f_241, 0), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str6), v_t_249));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str7), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str8), v_t_2410));
  V v_t_2412 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str9), v_t_2411));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  V v_t_2414 = (g_prelude_2e_2b_2b(heff_get_n(v_a_242, 1, 3), v_t_2413));
  return (g_prelude_2e_2b_2b(heff_get_n(v_f_241, 1, 3), v_t_2414));
}
V g_heff_2ecompile_2eemit_2ebounceGive_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebounceGive(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemit_2eloops_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eloops_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eloops(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TSeq: {
    V v_t_242 = heff_field(v_x1_240, 1);
    V t_0 = v_t_242;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_TReturn: {
    return NTAG(TAG_False);
  }
  case TAG_TLoop: {
    return NTAG(TAG_True);
  }
  case TAG_TIf: {
    V v_t_246 = heff_field(v_x1_240, 1);
    V v_e_247 = heff_field(v_x1_240, 2);
    V v_t_248 = (g_heff_2ecompile_2eemit_2eloops(v_t_246));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_248);
      V t_0 = v_e_247;
      v_x1_240 = t_0;
      goto top;
    }
  }
  case TAG_TCase: {
    V v_arms_2410 = heff_field(v_x1_240, 1);
    HEFF_LAST return g_list_2eany_24s184951243x1948563855(v_arms_2410);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2eloops_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eloops(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str0, 4, "hole");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str1, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str2, 8, "setField");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str5, 4, "] = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str6, 3, ".a[");
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam2(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam3(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam4(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam5(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam6(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam7(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam8(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam9(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam10(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam11(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam12(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam13(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam14(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam15(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam16(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam17(V self, V *args);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam18(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584(V v_env_240, V v_ind_241, V v_p_242, V v_as_243) {
top: ;
  if (heff_strEq_c_lent(v_p_242, ((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str0), 2)) {
    switch (heff_tag_of(v_as_243)) {
    case TAG_Nil: {
      heff_drop(v_env_240);
      heff_drop(v_ind_241);
      heff_drop(v_p_242);
      return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str1), MK_INT(3LL)});
    }
    case TAG_Cons: {
      V v_t_248 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam0, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
      return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_248));
    }
    default: return heff_nomatch(v_as_243);
    }
  } else {
    if (heff_strEq_c_lent(v_p_242, ((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str2), 2)) {
      switch (heff_tag_of(v_as_243)) {
      case TAG_Nil: {
        V v_t_2411 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam1, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
        return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2411));
      }
      case TAG_Cons: {
        V v_d_2412 = heff_dup(heff_field(v_as_243, 0));
        V v_as2_2413 = heff_dup(heff_field(v_as_243, 1));
        switch (heff_tag_of(v_as2_2413)) {
        case TAG_Nil: {
          heff_drop(v_d_2412);
          V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam2, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
          return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2415));
        }
        case TAG_Cons: {
          V v_as21_2416 = heff_field(v_as2_2413, 0);
          V v_as22_2417 = heff_field(v_as2_2413, 1);
          heff_take_n(v_as2_2413, 3ULL, 2);
          switch (heff_tag_of(v_as21_2416)) {
          case TAG_SVar: {
            heff_take_n(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2420 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam3, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2420));
          }
          case TAG_SGlobal: {
            heff_take_n(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2423 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam4, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2423));
          }
          case TAG_SInt: {
            V v_k_2424 = heff_field(v_as21_2416, 0);
            heff_take_n(v_as21_2416, 1ULL, 1);
            switch (heff_tag_of(v_as22_2417)) {
            case TAG_Nil: {
              heff_drop(v_d_2412);
              heff_drop(v_k_2424);
              V v_t_2426 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam5, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
              return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2426));
            }
            case TAG_Cons: {
              V v_v_2427 = heff_field(v_as22_2417, 0);
              V v_as222_2428 = heff_field(v_as22_2417, 1);
              heff_take_n(v_as22_2417, 3ULL, 2);
              switch (heff_tag_of(v_as222_2428)) {
              case TAG_Nil: {
                heff_drop(v_p_242);
                heff_drop_tag(v_as_243, 2);
                V v_c_2429 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_d_2412; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_d_2412); r_; });
                V v_t_2432;
                if (heff_intLt_c(heff_dup(heff_rfield(v_c_2429, 1)), MK_INT(3LL))) {
                  V v_t_2431 = heff_strAppend(heff_get_n(v_c_2429, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str3));
                  v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str4), v_t_2431);
                } else {
                  v_t_2432 = heff_get_n(v_c_2429, 0, 2);
                }
                V v_c_2433 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2427; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2427); r_; });
                V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str5), heff_get_n(v_c_2433, 0, 2));
                V v_t_2435 = heff_strAppend(heff_intShow(v_k_2424), v_t_2434);
                V v_t_2436 = heff_strAppend(v_t_2432, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_str6), v_t_2435));
                return heff_rec_n(2, shape_code__prec, (V[]){v_t_2436, MK_INT(0LL)});
              }
              case TAG_Cons: {
                heff_take_n(v_as222_2428, 0ULL, 2);
                heff_drop(v_d_2412);
                heff_drop(v_k_2424);
                heff_drop(v_v_2427);
                V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam6, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
                return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2440));
              }
              default: return heff_nomatch(v_as222_2428);
              }
            }
            default: return heff_nomatch(v_as22_2417);
            }
          }
          case TAG_SFloat: {
            heff_take_na(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2443 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam7, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2443));
          }
          case TAG_SStr: {
            heff_take_n(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2446 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam8, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2446));
          }
          case TAG_SBytes: {
            heff_take_n(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2449 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam9, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2449));
          }
          case TAG_SFixed: {
            heff_take_n(v_as21_2416, 0ULL, 2);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2453 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam10, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2453));
          }
          case TAG_SFloat32: {
            heff_take_na(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2456 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam11, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2456));
          }
          case TAG_SPrimFn: {
            heff_take_n(v_as21_2416, 0ULL, 1);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2459 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam12, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2459));
          }
          case TAG_SLam: {
            heff_take_n(v_as21_2416, 0ULL, 2);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2463 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam13, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2463));
          }
          case TAG_STag: {
            heff_take_n(v_as21_2416, 0ULL, 3);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2468 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam14, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2468));
          }
          case TAG_SRec: {
            heff_take_n(v_as21_2416, 0ULL, 2);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2472 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam15, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2472));
          }
          case TAG_SProj: {
            heff_take_n(v_as21_2416, 0ULL, 4);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2478 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam16, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2478));
          }
          case TAG_SPrim: {
            heff_take_n(v_as21_2416, 0ULL, 2);
            heff_drop(v_d_2412);
            heff_drop(v_as22_2417);
            V v_t_2482 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam17, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
            return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2482));
          }
          default: return heff_nomatch(v_as21_2416);
          }
        }
        default: return heff_nomatch(v_as2_2413);
        }
      }
      default: return heff_nomatch(v_as_243);
      }
    } else {
      V v_t_2484 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam18, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_243));
      return (g_heff_2ecompile_2eemit_2eprimCall(v_p_242, v_t_2484));
    }
  }
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam0(V self, V *args) {
  V v_v_247 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_247; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_247); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam1(V self, V *args) {
  V v_v_2410 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2410; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2410); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam2(V self, V *args) {
  V v_v_2414 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2414; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2414); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam3(V self, V *args) {
  V v_v_2419 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2419; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2419); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam4(V self, V *args) {
  V v_v_2422 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2422; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2422); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam5(V self, V *args) {
  V v_v_2425 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2425; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2425); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam6(V self, V *args) {
  V v_v_2439 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2439; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2439); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam7(V self, V *args) {
  V v_v_2442 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2442; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2442); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam8(V self, V *args) {
  V v_v_2445 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2445; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2445); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam9(V self, V *args) {
  V v_v_2448 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2448; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2448); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam10(V self, V *args) {
  V v_v_2452 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2452; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2452); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam11(V self, V *args) {
  V v_v_2455 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2455; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2455); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam12(V self, V *args) {
  V v_v_2458 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2458; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2458); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam13(V self, V *args) {
  V v_v_2462 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2462; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2462); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam14(V self, V *args) {
  V v_v_2467 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2467; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2467); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam15(V self, V *args) {
  V v_v_2471 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2471; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2471); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam16(V self, V *args) {
  V v_v_2477 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2477; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2477); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam17(V self, V *args) {
  V v_v_2481 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2481; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2481); r_; });
}
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_lam18(V self, V *args) {
  V v_v_2483 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2483; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2483); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str3, 6, "break;");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str7, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str8, 18, "default: $nomatch(");
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr(V v_ind_240, V v_arms_241, V v_sc_242) {
top: ;
  V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam0, 1, 2, (V[]){heff_dup(v_sc_242), heff_dup(v_ind_240)}), v_arms_241));
  V v_x2_2418 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str4)));
  V v_t_2421;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    v_t_2421 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str6); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2422 = heff_strAppend(heff_dup(heff_rfield(v_sc_242, 0)), ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str7));
  V v_t_2423 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str8), v_t_2422));
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
  V v_f_2425 = (g_heff_2ecompile_2eemit_2eswitchLines(heff_dup(v_sc_242), v_ind_240, v_t_2417, v_t_2424, NTAG(TAG_Nil)));
  V v_f_2426 = heff_get_n(v_sc_242, 1, 3);
  return ((HeffT2){{v_f_2425, v_f_2426}});
}
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam1(V self, V *args) {
  V v_e_249 = args[0];
  V v_i_2410 = args[1];
  V v_ss_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = ({ V a_0 = v_e_249; V a_1 = heff_dup(v_i_2410); V a_2 = v_ss_246; V b_3 = NTAG(TAG_Nothing); V r_ = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  V v_x2_2412 = (g_list_2ereplicate(v_i_2410, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str0)));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str2); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str3)), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(heff_get_n(v_t_2411, 0, 2), v_t_2416));
}
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam0(V self, V *args) {
  V v_arm_243 = args[0];
  V v_sc_242 = heff_env(self)[0];
  V v_ind_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_243)) {
  case TAG_MkArm: {
    V v_tag_244 = heff_field(v_arm_243, 0);
    V v_vs_245 = heff_field(v_arm_243, 1);
    V v_ss_246 = heff_field(v_arm_243, 2);
    heff_take_n(v_arm_243, 7ULL, 3);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_246)));
    V v_t_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_247); r_; });
    return ({ V a_0 = v_sc_242; V a_1 = v_ind_240; V a_2 = v_tag_244; V a_3 = v_vs_245; V a_4 = v_t_248; V a_5 = heff_clo_n(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam1, 2, 1, (V[]){v_ss_246}); V r_ = (g_heff_2ecompile_2eemit_2earmJs(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_248); r_; });
  }
  default: return heff_nomatch(v_arm_243);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str3, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str4, 16, "return $nomatch(");
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519(V v_ind_240, V v_arms_241, V v_sc_242) {
top: ;
  V v_t_2410 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam0, 1, 2, (V[]){heff_dup(v_sc_242), heff_dup(v_ind_240)}), v_arms_241));
  V v_x2_2411 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str0)));
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str2); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2415 = heff_strAppend(heff_dup(heff_rfield(v_sc_242, 0)), ((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str3));
  V v_t_2416 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_str4), v_t_2415));
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  return (g_heff_2ecompile_2eemit_2eswitchLines(v_sc_242, v_ind_240, v_t_2410, NTAG(TAG_Nil), v_t_2417));
}
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam1(V self, V *args) {
  V v_e_248 = args[0];
  V v_i_249 = args[1];
  V v_t_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_248; V a_1 = v_i_249; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
}
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam0(V self, V *args) {
  V v_arm_243 = args[0];
  V v_sc_242 = heff_env(self)[0];
  V v_ind_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_243)) {
  case TAG_MkArm: {
    V v_tag_244 = heff_field(v_arm_243, 0);
    V v_vs_245 = heff_field(v_arm_243, 1);
    V v_t_246 = heff_field(v_arm_243, 2);
    heff_take_n(v_arm_243, 7ULL, 3);
    V v_t_247 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_246, NTAG(TAG_Nil)));
    return ({ V a_0 = v_sc_242; V a_1 = v_ind_240; V a_2 = v_tag_244; V a_3 = v_vs_245; V a_4 = v_t_247; V a_5 = heff_clo_n(g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_lam1, 2, 1, (V[]){v_t_246}); V r_ = (g_heff_2ecompile_2eemit_2earmJs(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_arm_243);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str2, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str5, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str6, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str7, 2, "{\012");
Clo g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(V v_env_240, V v_ind_241, V v_t_242) {
top: ;
  V v_x2_243 = heff_tr(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(v_env_240, heff_box_word((heff_peek_word(v_ind_241) + ((int64_t)1ULL))), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_x2_247 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str2)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str5), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str6)));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str7), heff_strAppend(v_t_246, v_t_2411));
}
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eextStr_str0, 243, "const $ext = (v) => typeof v === \"function\" \? (x) => $ext($tr(v(x))) : v !== null && typeof v === \"object\" && !Array.isArray(v) && !ArrayBuffer.isView(v) && !(\"$\" in v) \? Object.fromEntries(Object.entries(v).map(([l, x]) => [l, $ext(x)])) : v;");

static V g_heff_2ecompile_2eemit_2eextStr_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2eextStr_st;
static V g_heff_2ecompile_2eemit_2eextStr_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2eextStr_str0);
}
V g_heff_2ecompile_2eemit_2eextStr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2eextStr_st)) return g_heff_2ecompile_2eemit_2eextStr_val;
  return heff_global(&g_heff_2ecompile_2eemit_2eextStr_val, &g_heff_2ecompile_2eemit_2eextStr_st, g_heff_2ecompile_2eemit_2eextStr_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str0, 5, "$lazy");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str1, 4, "$Bnc");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str2, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str3, 4, "$tr(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str4, 2, "$T");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str5, 60, "const $T = { $: \"True\", a: [] }, $F = { $: \"False\", a: [] };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str6, 2, "$F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str7, 60, "const $T = { $: \"True\", a: [] }, $F = { $: \"False\", a: [] };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str8, 8, "$abandon");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str9, 60, "const $abandon = () => { throw new Error(\"heff:abandon\"); };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str10, 8, "$nomatch");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str11, 87, "const $nomatch = (s) => { throw new Error(\"heff: no case for '\" + (s && s.$) + \"'\"); };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str12, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str13, 125, "const $force = (f) => { if (f.$m !== undefined) return f.$m; const v = $tr(f({ $: \"MkUnit\", a: [] })); f.$m = v; return v; };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str14, 5, "$lazy");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str15, 243, "const $lazy = (f) => { let state = 0, v; return () => { if (state === 2) return v; if (state === 1) throw new Error(\"heff: defined by itself\"); state = 1; try { v = $tr(f()); state = 2; return v; } finally { if (state === 1) state = 0; } }; };");
Clo g_heff_2ecompile_2eemit_2eruntime_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eruntime_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eruntime(V v_code_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str0), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str2), v_t_241})});
  V v_t_243 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_code_240); V a_2 = MK_INT(0LL); V b_3 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str3), v_t_242}); V r_ = (g_list_2eany_24s1073020508x1907354150(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  V v_t_244;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    v_t_244 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get())});
  } else {
    heff_drop(v_t_243);
    v_t_244 = NTAG(TAG_Nothing);
  }
  V v_t_247;
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str4), v_code_240, MK_INT(0LL), 5))) {
    v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str5)});
  } else {
    if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str6), v_code_240, MK_INT(0LL), 5))) {
      v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str7)});
    } else {
      v_t_247 = NTAG(TAG_Nothing);
    }
  }
  V v_t_249;
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str8), v_code_240, MK_INT(0LL), 5))) {
    v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str9)});
  } else {
    v_t_249 = NTAG(TAG_Nothing);
  }
  V v_t_2411;
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str10), v_code_240, MK_INT(0LL), 5))) {
    v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str11)});
  } else {
    v_t_2411 = NTAG(TAG_Nothing);
  }
  V v_t_2413;
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str12), v_code_240, MK_INT(0LL), 5))) {
    v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str13)});
  } else {
    v_t_2413 = NTAG(TAG_Nothing);
  }
  V v_t_2415;
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str14), v_code_240, MK_INT(0LL), 5))) {
    v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str15)});
  } else {
    v_t_2415 = NTAG(TAG_Nothing);
  }
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2417})});
  V v_t_2419 = (g_heff_2ecompile_2eemit_2ecatMaybesL(heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2418})));
  V v_t_2420 = (g_list_2emap_24s567711145x425963688(MK_INT(0LL), v_code_240, MK_INT(0LL), heff_dup(g_heff_2ecompile_2eemit_2estrHelpers_get())));
  V v_t_2421 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2420));
  return (g_prelude_2e_2b_2b(v_t_2419, v_t_2421));
}
V g_heff_2ecompile_2eemit_2eruntime_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eruntime(a[0]);
}
Clo g_heff_2ecompile_2eemit_2einfoOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2einfoOne_entry, 4, 0};

V g_heff_2ecompile_2eemit_2einfoOne(V v_shorts_240, V v_facts_241, V v_acc_242, V v_key_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2eemit_2ejsNameOf(v_shorts_240, heff_dup(v_key_243)));
  HeffT2 v_t_245 = (g_map_2elookup_24s1546226666x2146984184_24cpr(heff_dup(v_key_243), heff_rfield(v_facts_241, 0)));
  V v_t_2410;
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_247;
      v_t_2410 = v_x_249;
    } else {
      heff_drop(v_field_247);
      v_t_2410 = MK_INT(0LL);
    }
  }
  HeffT2 v_t_2411 = (g_map_2elookup_24s659669741x1036301430_24cpr(heff_dup(v_key_243), heff_rfield(v_facts_241, 2)));
  V v_t_2416;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    v_t_2416 = heff_bool(((v_tag_2412 == ((int64_t)0ULL)) && ({ V v_x_2415 = heff_dup(v_field_2413); int c_ = 1; heff_drop(v_x_2415); c_; })));
    heff_drop(v_field_2413);
  }
  HeffT2 v_t_2417 = ({ V a_0 = heff_dup(v_key_243); V b_1 = heff_get_n(v_facts_241, 1, 10); HeffT2 r_ = (g_map_2elookup_24s659669741x1036301430_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2422;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    v_t_2422 = heff_bool(((v_tag_2418 == ((int64_t)0ULL)) && ({ V v_x_2421 = heff_dup(v_field_2419); int c_ = 1; heff_drop(v_x_2421); c_; })));
    heff_drop(v_field_2419);
  }
  return (g_map_2einsert_24s1341440536x470972936(v_key_243, heff_rec_n(4, shape_js__arity__lazy__bounce, (V[]){v_t_244, v_t_2410, v_t_2416, v_t_2422}), v_acc_242));
}
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2einfoOne(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntimeFor_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntimeFor_str1, 1, "\012");
Clo g_heff_2ecompile_2eemit_2eruntimeFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eruntimeFor_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eruntimeFor(V v_hasTr_240, V v_have_241, V v_provs_242, V v_eff_243) {
top: ;
  V v_t_244;
  if ((heff_dup(v_hasTr_240) == NTAG(TAG_True))) {
    v_t_244 = NTAG(TAG_Nil);
  } else {
    v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()), NTAG(TAG_Nil)});
  }
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2eworldStr_get()), NTAG(TAG_Nil)});
  V v_t_246 = (g_prelude_2e_2b_2b(v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2erunStr_get()), v_t_245})));
  V v_t_2410;
  switch (heff_tag_of(v_eff_243)) {
  case TAG_Leaf: {
    heff_take_n(v_eff_243, 0ULL, 1);
    v_t_2410 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Plus: {
    V v_ru_24eff_243_24Plus = heff_take_reuse_n(v_eff_243, 0ULL, 2);
    v_t_2410 = heff_tag_at_n(v_ru_24eff_243_24Plus, TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2esumStr_get()), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_eff_243);
  }
  V v_t_2411 = (g_heff_2ecompile_2eemit_2eprovStrHelpers(v_have_241, heff_dup(v_provs_242)));
  V v_t_2412 = (g_heff_2ecompile_2eemit_2ebundleAll(MK_INT(0LL), v_provs_242));
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2412));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2413));
  V v_x2_2415 = (g_prelude_2e_2b_2b(v_t_246, v_t_2414));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2eemit_2eruntimeFor_str0);
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eruntimeFor_str1); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eemit_2eruntimeFor_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2eruntimeFor(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str3, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str4, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str5, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str6, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str7, 8, "($world)");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str8, 2, "$p");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str9, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str10, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str11, 5, "$sum(");
Clo g_heff_2ecompile_2eemit_2ehandlerOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ehandlerOf_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ehandlerOf(V v_provs_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_t_243 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str0), heff_dup(v_k_242), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str1), v_k_242, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_x2_244 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_243));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = (g_heff_2ecompile_2eemit_2eprovIndexGo(MK_INT(0LL), v_t_247, v_provs_240));
    V v_t_249 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str4), heff_dup(v_k_242), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str5), v_k_242, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_t_2410 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_t_249; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str6), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str7)));
    V v_t_2412 = heff_strAppend(heff_intShow(v_t_248), v_t_2411);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str8), v_t_2412);
  }
  case TAG_Plus: {
    V v_a_2413 = heff_field(v_x2_241, 0);
    V v_b_2414 = heff_field(v_x2_241, 1);
    V v_t_2415 = (g_heff_2ecompile_2eemit_2ehandlerOf(v_provs_240, v_a_2413));
    V v_t_2416 = (g_heff_2ecompile_2eemit_2ehandlerOf(v_provs_240, v_b_2414));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str9), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str10)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str11), heff_strAppend(v_t_2415, v_t_2417));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2ehandlerOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ehandlerOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eimportLinesOf_str0, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eimportLinesOf_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eimportLinesOf_str2, 7, "import ");
Clo g_heff_2ecompile_2eemit_2eimportLinesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eimportLinesOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eimportLinesOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_s_243 = heff_dup(heff_rfield(v_p_241, 1));
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str0), heff_dup(v_s_243), MK_INT(0LL), heff_strFind(((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str1), v_s_243, MK_INT(0LL)), NTAG(TAG_Nil)));
    V v_t_245 = (g_list_2efilter_24s1820448628x561773228(MK_INT(0LL), MK_INT(7LL), ((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str2), v_t_244));
    V v_t_246 = (g_heff_2ecompile_2eemit_2eimportLinesOf(v_rest_242));
    return (g_prelude_2e_2b_2b(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2eimportLinesOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eimportLinesOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2ecompileJsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecompileJsWith_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecompileJsWith(V v_g_240, V v_exports_241) {
top: ;
  V v_roots_242 = (g_list_2emap_24s152505078x225062837(heff_dup(v_exports_241)));
  V v_t_243 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_g_240));
  HeffT3 v_t_244 = (g_heff_2ecompile_2elower_2elowerErased_24cpr(v_roots_242, v_t_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_field_247 = v_t_244.f[2];
    V v_roots_248 = (g_list_2emap_24s152505078x225062837(heff_dup(v_exports_241)));
    V v_t_249 = ({ V a_0 = v_field_246; V a_1 = v_field_245; V a_2 = v_roots_248; V b_3 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2ecompile_2eemit_2eemitKept(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    V v_t_2410 = (g_heff_2ecompile_2eemit_2ejsSource(v_exports_241, heff_get_n(v_t_249, 0, 2)));
    return heff_rec_n(2, shape_source__errors, (V[]){v_t_2410, v_field_247});
  }
}
V g_heff_2ecompile_2eemit_2ecompileJsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecompileJsWith(a[0], a[1]);
}