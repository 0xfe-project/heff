// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_Leaf 13717
#define TAG_MkArm 55352
#define TAG_MkArmJs 44527
#define TAG_MkBlock 5679
#define TAG_Plus 9189
#define TAG_SInt 64711
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38305
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_env 310119
#define LBL_gs 10067
#define LBL_inl 313953
#define LBL_js 10160
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_names 305943394
#define LBL_pre 320797
#define LBL_prec 9944807
#define LBL_self 10021907
#define LBL_text 10052084
#define LBL_used 10094724
static uint32_t shape_code__prec[] = {LBL_code, LBL_prec};
static uint32_t shape_gs__names__used__self__inl[] = {LBL_gs, LBL_names, LBL_used, LBL_self, LBL_inl};
static uint32_t shape_js__env[] = {LBL_js, LBL_env};
static uint32_t shape_js__env__pre[] = {LBL_js, LBL_env, LBL_pre};
static uint32_t shape_lines__env[] = {LBL_lines, LBL_env};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eemit_2earmBound(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmBound_clo;
V g_heff_2ecompile_2eemit_2earmJs(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmJs_clo;
V g_heff_2ecompile_2eemit_2earmJs_24tok3(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmJs_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmJs_24tok3_clo;
V g_heff_2ecompile_2eemit_2ebindFrom(V, V, V, V);
V g_heff_2ecompile_2eemit_2ebindFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindFrom_clo;
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(V, V, V);
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_clo;
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(V, V, V);
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_clo;
V g_heff_2ecompile_2eemit_2ebounceGive(V, V, V);
V g_heff_2ecompile_2eemit_2ebounceGive_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebounceGive_clo;
V g_heff_2ecompile_2eemit_2ecallsHelper(V, V);
V g_heff_2ecompile_2eemit_2ecallsHelper_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallsHelper_clo;
HeffT2 g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(V, V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_clo;
V g_heff_2ecompile_2eemit_2ecellPrim(V, V);
V g_heff_2ecompile_2eemit_2ecellPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecellPrim_clo;
HeffT2 g_heff_2ecompile_2eemit_2edefCodeOf_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2eextStr_get(void);
V g_heff_2ecompile_2eemit_2ehandlerOf(V, V);
V g_heff_2ecompile_2eemit_2ehandlerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehandlerOf_clo;
V g_heff_2ecompile_2eemit_2eimportLinesOf(V);
V g_heff_2ecompile_2eemit_2eimportLinesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eimportLinesOf_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2eletDeclarations(V, V);
V g_heff_2ecompile_2eemit_2eletDeclarations_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eletDeclarations_clo;
HeffT2 g_heff_2ecompile_2eemit_2eletStmt_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2elooped(V, V, V, V);
V g_heff_2ecompile_2eemit_2elooped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elooped_clo;
V g_heff_2ecompile_2eemit_2eloops(V);
V g_heff_2ecompile_2eemit_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eloops_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2enubGo_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2enubGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_24dps_clo;
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(V, V, V);
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_clo;
HeffT2 g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2eprimCall(V, V);
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimCall_clo;
HeffT2 g_heff_2ecompile_2eemit_2eprimOp_24cpr(V);
V g_heff_2ecompile_2eemit_2eprimTest(V, V, V);
V g_heff_2ecompile_2eemit_2eprimTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimTest_clo;
HeffT2 g_heff_2ecompile_2eemit_2eprimUnary_24cpr(V);
V g_heff_2ecompile_2eemit_2eprovIndexGo(V, V, V);
V g_heff_2ecompile_2eemit_2eprovIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovIndexGo_clo;
V g_heff_2ecompile_2eemit_2eruntime(V);
V g_heff_2ecompile_2eemit_2eruntime_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntime_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeFrom(V);
V g_heff_2ecompile_2eemit_2esafeFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeFrom_clo;
V g_heff_2ecompile_2eemit_2escrutBound(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2escrutBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutBound_clo;
V g_heff_2ecompile_2eemit_2escrutOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2escrutOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutOf_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
HeffT2 g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2estrHelpers_get(void);
V g_heff_2ecompile_2eemit_2eswitchLines(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2eswitchLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eswitchLines_clo;
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(V, V, V);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
HeffT2 g_heff_2ecompile_2eemit_2ewordOf_24cpr(V);
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s184951243x1948563855(V);
V g_list_2eany_24s184951243x1948563855_entry(V self, V *a);
extern Clo g_list_2eany_24s184951243x1948563855_clo;
V g_list_2eany_24s1877524499x1789047582(V, V);
V g_list_2eany_24s1877524499x1789047582_entry(V self, V *a);
extern Clo g_list_2eany_24s1877524499x1789047582_clo;
V g_list_2eany_24s1931936847x1400497912(V);
V g_list_2eany_24s1931936847x1400497912_entry(V self, V *a);
extern Clo g_list_2eany_24s1931936847x1400497912_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s2018454372x1607369768(V, V, V, V, V, V, V);
V g_list_2efoldl_24s2018454372x1607369768_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2018454372x1607369768_clo;
V g_list_2efoldl_24s2118756600x1920057229(V, V);
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_clo;
V g_list_2ekeepIf_24s185327080x101197346(V, V, V, V);
V g_list_2ekeepIf_24s185327080x101197346_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s185327080x101197346_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s319754340x1392149466(V, V, V, V);
V g_list_2emap_24s319754340x1392149466_entry(V self, V *a);
extern Clo g_list_2emap_24s319754340x1392149466_clo;
V g_list_2emap_24s357242026x384251201(V);
V g_list_2emap_24s357242026x384251201_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecatMaybesL_entry, 1, 0};

V g_heff_2ecompile_2eemit_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecatMaybesL(a[0]);
}
Clo g_heff_2ecompile_2eemit_2enubGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enubGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2enubGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_list_2eany(v_t_244, v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_xs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2eemit_2enubGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_xs_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enubGo(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(V v_x_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) <= v_i_241)) {
    V v_f_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ecompile_2eemit_2ewordOf_24cpr(heff_strByteAt_lent(v_x_240, heff_box_word(v_i_241), 2)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_w_247 = v_field_246;
        V t_0 = v_x_240;
        int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_w_247, v_acc_242});
        v_x_240 = t_0;
        v_i_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      } else {
        heff_drop(v_acc_242);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str2, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str5, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimTest_str6, 10, " \? $T : $F");
Clo g_heff_2ecompile_2eemit_2eprimTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimTest_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprimTest(V v_op_240, V v_a_241, V v_b_242) {
top: ;
  V v_prec_243 = heff_take_field(v_b_242, 1);
  V v_code_244 = heff_get_n(v_b_242, 0, 2);
  V v_prec_245 = heff_take_field(v_a_241, 1);
  V v_code_246 = heff_get_n(v_a_241, 0, 2);
  V v_t_247;
  if (heff_intLt_c(v_prec_245, MK_INT(2LL))) {
    v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str0), v_code_246), ((V)&g_heff_2ecompile_2eemit_2eprimTest_str1));
  } else {
    v_t_247 = v_code_246;
  }
  V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemit_2eprimTest_str2)), v_op_240);
  V v_t_249;
  if (heff_intLt_c(v_prec_243, MK_INT(2LL))) {
    v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str3), v_code_244), ((V)&g_heff_2ecompile_2eemit_2eprimTest_str4));
  } else {
    v_t_249 = v_code_244;
  }
  V v_t_2410 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemit_2eprimTest_str5)), v_t_249);
  return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2eprimTest_str6)), MK_INT(0LL)});
}
V g_heff_2ecompile_2eemit_2eprimTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimTest(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str3, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str5, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str8, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str9, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str10, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str11, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str13, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str14, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str15, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str18, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimCall_str19, 1, ")");
Clo g_heff_2ecompile_2eemit_2eprimCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimCall_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprimCall(V v_p_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_args_241)) {
  case TAG_Nil: {
    V v_t_242 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_240));
    V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str0), v_t_242), ((V)&g_heff_2ecompile_2eemit_2eprimCall_str1));
    V v_x2_244 = (g_list_2emap_24s357242026x384251201(v_args_241));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_code_248 = heff_strAppend(heff_strAppend(v_t_243, v_t_247), ((V)&g_heff_2ecompile_2eemit_2eprimCall_str4));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_248, MK_INT(3LL)});
  }
  case TAG_Cons: {
    V v_a_249 = heff_dup(heff_field(v_args_241, 0));
    V v_args2_2410 = heff_dup(heff_field(v_args_241, 1));
    switch (heff_tag_of(v_args2_2410)) {
    case TAG_Nil: {
      HeffT2 v_t_2411 = (g_heff_2ecompile_2eemit_2eprimUnary_24cpr(v_p_240));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          heff_drop_tag(v_args_241, 2);
          V v_f_2414 = v_field_2413;
          return heff_tail(v_f_2414, 1, (V[]){v_a_249});
        } else {
          heff_drop(v_a_249);
          heff_drop(v_field_2413);
          V v_t_2415 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_240));
          V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str5), v_t_2415), ((V)&g_heff_2ecompile_2eemit_2eprimCall_str6));
          V v_x2_2417 = (g_list_2emap_24s357242026x384251201(v_args_241));
          V v_t_2420;
          switch (heff_tag_of(v_x2_2417)) {
          case TAG_Nil: {
            v_t_2420 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str7);
            break;
          }
          case TAG_Cons: {
            V v_x_2418 = heff_field(v_x2_2417, 0);
            V v_xs_2419 = heff_field(v_x2_2417, 1);
            heff_take_n(v_x2_2417, 3ULL, 2);
            v_t_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str8); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2417);
          }
          V v_code_2421 = heff_strAppend(heff_strAppend(v_t_2416, v_t_2420), ((V)&g_heff_2ecompile_2eemit_2eprimCall_str9));
          return heff_rec_n(2, shape_code__prec, (V[]){v_code_2421, MK_INT(3LL)});
        }
      }
    }
    case TAG_Cons: {
      V v_b_2422 = heff_field(v_args2_2410, 0);
      V v_args22_2423 = heff_field(v_args2_2410, 1);
      heff_take_n(v_args2_2410, 3ULL, 2);
      switch (heff_tag_of(v_args22_2423)) {
      case TAG_Nil: {
        HeffT2 v_t_2424 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
        {
          V v_field_2426 = v_t_2424.f[1];
          int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
          if ((v_tag_2425 == ((int64_t)0ULL))) {
            heff_drop_tag(v_args_241, 2);
            V v_f_2427 = v_field_2426;
            return heff_tail(v_f_2427, 2, (V[]){v_a_249, v_b_2422});
          } else {
            heff_drop(v_a_249);
            heff_drop(v_b_2422);
            heff_drop(v_field_2426);
            V v_t_2428 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_240));
            V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str10), v_t_2428), ((V)&g_heff_2ecompile_2eemit_2eprimCall_str11));
            V v_x2_2430 = (g_list_2emap_24s357242026x384251201(v_args_241));
            V v_t_2433;
            switch (heff_tag_of(v_x2_2430)) {
            case TAG_Nil: {
              v_t_2433 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str12);
              break;
            }
            case TAG_Cons: {
              V v_x_2431 = heff_field(v_x2_2430, 0);
              V v_xs_2432 = heff_field(v_x2_2430, 1);
              heff_take_n(v_x2_2430, 3ULL, 2);
              v_t_2433 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str13); V a_1 = v_x_2431; V a_2 = v_xs_2432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2432); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2430);
            }
            V v_code_2434 = heff_strAppend(heff_strAppend(v_t_2429, v_t_2433), ((V)&g_heff_2ecompile_2eemit_2eprimCall_str14));
            return heff_rec_n(2, shape_code__prec, (V[]){v_code_2434, MK_INT(3LL)});
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_args22_2423, 0ULL, 2);
        heff_drop(v_a_249);
        heff_drop(v_b_2422);
        V v_t_2437 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_240));
        V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str15), v_t_2437), ((V)&g_heff_2ecompile_2eemit_2eprimCall_str16));
        V v_x2_2439 = (g_list_2emap_24s357242026x384251201(v_args_241));
        V v_t_2442;
        switch (heff_tag_of(v_x2_2439)) {
        case TAG_Nil: {
          v_t_2442 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str17);
          break;
        }
        case TAG_Cons: {
          V v_x_2440 = heff_field(v_x2_2439, 0);
          V v_xs_2441 = heff_field(v_x2_2439, 1);
          heff_take_n(v_x2_2439, 3ULL, 2);
          v_t_2442 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str18); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2439);
        }
        V v_code_2443 = heff_strAppend(heff_strAppend(v_t_2438, v_t_2442), ((V)&g_heff_2ecompile_2eemit_2eprimCall_str19));
        return heff_rec_n(2, shape_code__prec, (V[]){v_code_2443, MK_INT(3LL)});
      }
      default: return heff_nomatch(v_args22_2423);
      }
    }
    default: return heff_nomatch(v_args2_2410);
    }
  }
  default: return heff_nomatch(v_args_241);
  }
}
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eprimCall(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2ecallsHelper_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecallsHelper_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecallsHelper(V v_p_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_args_241)) {
  case TAG_Nil: {
    V v_t_242 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
    V v_ret_24bool = heff_bool(!(heff_dup(v_t_242) == NTAG(TAG_True)));
    heff_drop(v_t_242);
    return v_ret_24bool;
  }
  case TAG_Cons: {
    V v_args2_244 = heff_field(v_args_241, 1);
    switch (heff_tag_of(v_args2_244)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_args_241)) {
      case TAG_Cons: {
        HeffT2 v_t_247 = (g_heff_2ecompile_2eemit_2eprimUnary_24cpr(v_p_240));
        {
          V v_field_249 = v_t_247.f[1];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          V v_ret_24bool = heff_bool(((v_tag_248 == ((int64_t)0ULL)) ? ({ V v_x_2410 = heff_dup(v_field_249); int c_ = 0; heff_drop(v_x_2410); c_; }) : 1));
          heff_drop(v_field_249);
          return v_ret_24bool;
        }
      }
      default: return heff_nomatch(v_args_241);
      }
    }
    case TAG_Cons: {
      V v_args21_2411 = heff_field(v_args2_244, 0);
      V v_args22_2412 = heff_field(v_args2_244, 1);
      switch (heff_tag_of(v_args21_2411)) {
      case TAG_SInt: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_2414 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2416 = v_t_2414.f[1];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2415 == ((int64_t)0ULL)) ? ({ V v_x_2417 = heff_dup(v_field_2416); int c_ = 0; heff_drop(v_x_2417); c_; }) : 1));
            heff_drop(v_field_2416);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_args222_2419 = heff_field(v_args22_2412, 1);
          switch (heff_tag_of(v_args222_2419)) {
          case TAG_Nil: {
            V v_t_2420 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
            V v_ret_24bool = heff_bool(!(heff_dup(v_t_2420) == NTAG(TAG_True)));
            heff_drop(v_t_2420);
            return v_ret_24bool;
          }
          case TAG_Cons: {
            V v_t_2423 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
            V v_ret_24bool = heff_bool(!(heff_dup(v_t_2423) == NTAG(TAG_True)));
            heff_drop(v_t_2423);
            return v_ret_24bool;
          }
          default: return heff_nomatch(v_args222_2419);
          }
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      default: {
        switch (heff_tag_of(v_args22_2412)) {
        case TAG_Nil: {
          HeffT2 v_t_2424 = (g_heff_2ecompile_2eemit_2eprimOp_24cpr(v_p_240));
          {
            V v_field_2426 = v_t_2424.f[1];
            int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2425 == ((int64_t)0ULL)) ? ({ V v_x_2427 = heff_dup(v_field_2426); int c_ = 0; heff_drop(v_x_2427); c_; }) : 1));
            heff_drop(v_field_2426);
            return v_ret_24bool;
          }
        }
        case TAG_Cons: {
          V v_t_2430 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_240, v_args_241));
          V v_ret_24bool = heff_bool(!(heff_dup(v_t_2430) == NTAG(TAG_True)));
          heff_drop(v_t_2430);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_args22_2412);
        }
      }
      }
    }
    default: return heff_nomatch(v_args2_244);
    }
  }
  default: return heff_nomatch(v_args_241);
  }
}
V g_heff_2ecompile_2eemit_2ecallsHelper_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ecallsHelper(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_str0, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_str2, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_str3, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_str5, 1, "s");
Clo g_heff_2ecompile_2eemit_2escrutOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2escrutOf_entry, 4, 0};

V g_heff_2ecompile_2eemit_2escrutOf(V v_r_240, V v_env_241, V v_ind_242, V v_v_243) {
top: ;
  switch (heff_tag_of(v_v_243)) {
  case TAG_SVar: {
    V v_x_244 = heff_field(v_v_243, 0);
    V v_ru_24v_243_24SVar = heff_take_reuse_n(v_v_243, 1ULL, 1);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_env_241, 1), v_x_244));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_r_240);
        heff_drop(v_ind_242);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24v_243_24SVar, 1);
        V v_js_248 = v_field_247;
        return heff_rec_n(3, shape_js__env__pre, (V[]){v_js_248, v_env_241, NTAG(TAG_Nil)});
      } else {
        heff_drop(v_field_247);
        V v_x0_249 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_str0), MK_INT(0LL)));
        int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_x0_249, 0)) - ((int64_t)1ULL));
        V v_t_2411 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_249, heff_box_word(v_t_2410)));
        V v_t_2412 = ({ V a_0 = v_x0_249; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2411); r_; });
        V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_str1); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
        V v_t_2414 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2413));
        V v_t_2415 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_241), ((V)&g_heff_2ecompile_2eemit_2escrutOf_str2), v_t_2414, MK_INT(0LL)));
        return (g_heff_2ecompile_2eemit_2escrutBound(v_r_240, v_env_241, v_ind_242, heff_tag_at_n(v_ru_24v_243_24SVar, TAG_SVar, 1, (V[]){v_x_244}), v_t_2415));
      }
    }
  }
  default: {
    V v_x0_2416 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_str3), MK_INT(0LL)));
    int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_x0_2416, 0)) - ((int64_t)1ULL));
    V v_t_2418 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_2416, heff_box_word(v_t_2417)));
    V v_t_2419 = ({ V a_0 = v_x0_2416; V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_str4); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
    V v_t_2421 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2420));
    V v_t_2422 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_241), ((V)&g_heff_2ecompile_2eemit_2escrutOf_str5), v_t_2421, MK_INT(0LL)));
    return (g_heff_2ecompile_2eemit_2escrutBound(v_r_240, v_env_241, v_ind_242, v_v_243, v_t_2422));
  }
  }
}
V g_heff_2ecompile_2eemit_2escrutOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2escrutOf(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eletStmt_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletStmt_24cpr_str1, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletStmt_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletStmt_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletStmt_24cpr_str4, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletStmt_24cpr_str5, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletStmt_24cpr_str6, 1, ";");

HeffT2 g_heff_2ecompile_2eemit_2eletStmt_24cpr(V v_ind_240, V v_st_241, V v_x_242, V v_env_243) {
top: ;
  V v_ind_244 = v_ind_240;
  V v_st_245 = heff_dup(v_st_241);
  V v_decls_246 = heff_take_field(v_st_245, 1);
  V v_code_247 = heff_get_n(v_st_245, 0, 2);
  V v_env_248 = ({ V a_0 = v_env_243; V b_1 = heff_get_n(v_st_241, 1, 2); V r_ = (g_list_2efoldl_24s2118756600x1920057229(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x0_249 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_242), MK_INT(0LL)));
  int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_x0_249, 0)) - ((int64_t)1ULL));
  V v_t_2411 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_249, heff_box_word(v_t_2410)));
  V v_t_2412 = ({ V a_0 = v_x0_249; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2eletStmt_24cpr_str0); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
  V v_t_2414 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2413));
  V v_nb_2415 = (g_heff_2ecompile_2eemit_2ebindFrom(v_env_248, v_x_242, v_t_2414, MK_INT(0LL)));
  V v_js_2416 = heff_take_field(v_nb_2415, 0);
  V v_env_2417 = heff_get_n(v_nb_2415, 1, 2);
  V v_t_2418 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_244), v_decls_246));
  V v_x2_2419 = (g_list_2ereplicate(v_ind_244, ((V)&g_heff_2ecompile_2eemit_2eletStmt_24cpr_str1)));
  V v_t_2422;
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nil: {
    v_t_2422 = ((V)&g_heff_2ecompile_2eemit_2eletStmt_24cpr_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_xs_2421 = heff_field(v_x2_2419, 1);
    heff_take_n(v_x2_2419, 3ULL, 2);
    v_t_2422 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eletStmt_24cpr_str3); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2419);
  }
  V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemit_2eletStmt_24cpr_str4)), v_js_2416);
  V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eemit_2eletStmt_24cpr_str5)), heff_get_n(v_code_247, 0, 2));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemit_2eletStmt_24cpr_str6)), NTAG(TAG_Nil)});
  V v_f_2426 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2425));
  V v_f_2427 = v_env_2417;
  return ((HeffT2){{v_f_2426, v_f_2427}});
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str3, 16, "return ++$dep > ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str4, 3, "500");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str5, 12, " \? new $Bnc(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str7, 4, ") : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_str9, 2, ");");
Clo g_heff_2ecompile_2eemit_2ebounceGive_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebounceGive_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ebounceGive(V v_ind_240, V v_f_241, V v_a_242) {
top: ;
  V v_pre_243 = heff_take_field(v_a_242, 1);
  V v_js_244 = heff_get_n(v_a_242, 0, 3);
  V v_pre_245 = heff_take_field(v_f_241, 1);
  V v_js_246 = heff_get_n(v_f_241, 0, 3);
  V v_x2_247 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str0)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str3)), ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str4));
  V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str5)), heff_dup(v_js_246));
  V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str6)), heff_dup(v_js_244));
  V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str7)), v_js_246);
  V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str8)), v_js_244);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str9)), NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_pre_243, v_t_2416));
  return (g_prelude_2e_2b_2b(v_pre_245, v_t_2417));
}
V g_heff_2ecompile_2eemit_2ebounceGive_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebounceGive(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemit_2eloops_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eloops_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eloops(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TSeq: {
    V v_t_242 = heff_field(v_x1_240, 1);
    V t_0 = v_t_242;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_TReturn: {
    return NTAG(TAG_False);
  }
  case TAG_TLoop: {
    return NTAG(TAG_True);
  }
  case TAG_TIf: {
    V v_t_246 = heff_field(v_x1_240, 1);
    V v_e_247 = heff_field(v_x1_240, 2);
    V v_t_248 = (g_heff_2ecompile_2eemit_2eloops(v_t_246));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_248);
      V t_0 = v_e_247;
      v_x1_240 = t_0;
      goto top;
    }
  }
  case TAG_TCase: {
    V v_arms_2410 = heff_field(v_x1_240, 1);
    HEFF_LAST return g_list_2eany_24s184951243x1948563855(v_arms_2410);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2eloops_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eloops(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str3, 6, "break;");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str7, 18, "default: $nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str8, 2, ");");
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr(V v_ind_240, V v_arms_241, V v_sc_242) {
top: ;
  V v_t_2426 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam0, 1, 2, (V[]){heff_dup(v_sc_242), heff_dup(v_ind_240)}), heff_dup(v_arms_241)));
  V v_t_2427 = ({ V a_0 = v_arms_241; V r_ = (g_list_2eany_24s1931936847x1400497912(a_0)); heff_drop(v_arms_241); r_; });
  V v_t_2433;
  if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
    heff_drop(v_t_2427);
    v_t_2433 = NTAG(TAG_Nil);
  } else {
    heff_drop(v_t_2427);
    V v_x2_2428 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str4)));
    V v_t_2431;
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_Nil: {
      v_t_2431 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_x2_2428, 0);
      V v_xs_2430 = heff_field(v_x2_2428, 1);
      heff_take_n(v_x2_2428, 3ULL, 2);
      v_t_2431 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str6); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2428);
    }
    V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str7)), heff_dup(heff_rfield(v_sc_242, 0)));
    v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str8)), NTAG(TAG_Nil)});
  }
  V v_f_2434 = (g_heff_2ecompile_2eemit_2eswitchLines(heff_dup(v_sc_242), v_ind_240, v_t_2426, v_t_2433, NTAG(TAG_Nil)));
  V v_f_2435 = heff_get_n(v_sc_242, 1, 3);
  return ((HeffT2){{v_f_2434, v_f_2435}});
}
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam1(V self, V *args) {
  V v_e_249 = args[0];
  V v_i_2410 = args[1];
  V v_ss_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420;
  switch (heff_tag_of(v_ss_246)) {
  case TAG_Nil: {
    v_t_2420 = heff_rec_n(2, shape_lines__env, (V[]){NTAG(TAG_Nil), v_e_249});
    break;
  }
  case TAG_Cons: {
    V v_st_2411 = heff_field(v_ss_246, 0);
    V v_rest_2412 = heff_field(v_ss_246, 1);
    V v_ru_24ss_246_24Cons = heff_take_reuse_n(v_ss_246, 3ULL, 2);
    HeffT2 v_t_2413 = ({ V a_0 = v_e_249; V a_1 = heff_dup(v_i_2410); V a_2 = v_st_2411; HeffT2 r_ = (g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(a_0, a_1, a_2)); heff_drop(v_st_2411); r_; });
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      HeffT2 v_t_2416 = ({ V a_0 = v_field_2415; V a_1 = heff_dup(v_i_2410); V a_2 = v_rest_2412; V b_3 = NTAG(TAG_Nothing); HeffT2 r_ = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(a_0, a_1, a_2, b_3)); heff_drop(v_rest_2412); heff_drop(b_3); r_; });
      {
        V v_field_2417 = v_t_2416.f[0];
        V v_field_2418 = v_t_2416.f[1];
        V v_t_2419 = (g_prelude_2e_2b_2b_24tok2(v_ru_24ss_246_24Cons, v_field_2414, v_field_2417));
        v_t_2420 = heff_rec_n(2, shape_lines__env, (V[]){v_t_2419, v_field_2418});
      }
    }
    break;
  }
  default: heff_nomatch(v_ss_246);
  }
  V v_x2_2421 = (g_list_2ereplicate(v_i_2410, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str0)));
  V v_t_2424;
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_Nil: {
    v_t_2424 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_xs_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str2); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2421);
  }
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_str3)), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(heff_get_n(v_t_2420, 0, 2), v_t_2425));
}
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam0(V self, V *args) {
  V v_arm_243 = args[0];
  V v_sc_242 = heff_env(self)[0];
  V v_ind_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_243)) {
  case TAG_MkArm: {
    V v_tag_244 = heff_field(v_arm_243, 0);
    V v_vs_245 = heff_field(v_arm_243, 1);
    V v_ss_246 = heff_field(v_arm_243, 2);
    V v_ru_24arm_243_24MkArm = heff_take_reuse_n(v_arm_243, 7ULL, 3);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_246)));
    V v_t_248 = (g_list_2efoldl_24s2003609603x1707519208(NTAG(TAG_Nil), v_t_247));
    return ({ V a_0 = v_ru_24arm_243_24MkArm; V a_1 = v_sc_242; V a_2 = v_ind_240; V a_3 = v_tag_244; V a_4 = v_vs_245; V a_5 = v_t_248; V a_6 = heff_clo_n(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr_lam1, 2, 1, (V[]){v_ss_246}); V r_ = (g_heff_2ecompile_2eemit_2earmJs_24tok3(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_248); r_; });
  }
  default: return heff_nomatch(v_arm_243);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str2, 2, "{\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str3, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str7, 1, "}");
Clo g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(V v_env_240, V v_ind_241, V v_t_242) {
top: ;
  V v_x2_243 = heff_tr(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(v_env_240, heff_box_word((heff_peek_word(v_ind_241) + ((int64_t)1ULL))), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str2), v_t_246), ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str3));
  V v_x2_248 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str4)));
  V v_t_2411;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    v_t_2411 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    heff_take_n(v_x2_248, 3ULL, 2);
    v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str6); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  return heff_strAppend(heff_strAppend(v_t_247, v_t_2411), ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_str7));
}
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str1, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str3, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str4, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str5, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str6, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str8, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str9, 15, " = $lazy(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str10, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str12, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str13, 7, "(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str14, 3, ")()");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str15, 7, "(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str16, 3, ")()");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str17, 7, "(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str18, 3, ")()");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str19, 7, "(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str20, 3, ")()");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str21, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str22, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str23, 0, "");

HeffT2 g_heff_2ecompile_2eemit_2edefCodeOf_24cpr(V v_gs_240, V v_met_241, V v_key_242, V v_x4_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_DefFun: {
    V v_xs_245 = heff_field(v_x4_243, 0);
    V v_x42_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24DefFun = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x42_246)) {
    case TAG_MkBlock: {
      V v_t_247 = heff_field(v_x42_246, 0);
      heff_take_n(v_x42_246, 1ULL, 1);
      V v_t_248 = heff_rec_n(5, shape_gs__names__used__self__inl, (V[]){v_gs_240, heff_dup(g_std_2eordmap_2eempty_get()), v_met_241, NTAG(TAG_Nothing), heff_dup(g_std_2eordmap_2eempty_get())});
      V v_t_249 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), v_t_248});
      V v_r_2410 = (g_list_2efoldl_24s2018454372x1607369768(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str0), MK_INT(0LL), v_t_249, v_xs_245));
      V v_key_2411 = v_key_242;
      V v_i_2412 = v_i_244;
      V v_t_2413 = v_t_247;
      V v_r_2414 = heff_dup(v_r_2410);
      V v_t_2415 = (g_heff_2ecompile_2eemit_2eloops(v_t_2413));
      V v_f_2425;
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x4_243_24DefFun, 2);
        heff_drop(v_t_2415);
        v_f_2425 = (g_heff_2ecompile_2eemit_2elooped(v_key_2411, v_i_2412, v_t_2413, v_r_2414));
      } else {
        heff_drop(v_key_2411);
        heff_drop(v_t_2415);
        V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str1), heff_get_n(v_i_2412, 0, 4));
        V v_t_2417 = heff_take_field(v_r_2414, 0);
        V v_t_2420;
        switch (heff_tag_of(v_t_2417)) {
        case TAG_Nil: {
          v_t_2420 = ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str2);
          break;
        }
        case TAG_Cons: {
          V v_x_2418 = heff_field(v_t_2417, 0);
          V v_xs_2419 = heff_field(v_t_2417, 1);
          heff_take_n(v_t_2417, 3ULL, 2);
          v_t_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str3); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
          break;
        }
        default: heff_nomatch(v_t_2417);
        }
        V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str4)), v_t_2420);
        V v_t_2422 = (g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(heff_get_n(v_r_2414, 1, 2), MK_INT(0LL), v_t_2413));
        V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str5)), v_t_2422);
        V v_t_2424 = heff_tag_at_n(v_ru_24x4_243_24DefFun, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str6)), NTAG(TAG_Nil)});
        v_f_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str7), v_t_2424});
      }
      V v_f_2426 = heff_get_n(v_r_2410, 0, 2);
      return ((HeffT2){{v_f_2425, v_f_2426}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x42_246)}});
    }
  }
  case TAG_DefVal: {
    V v_x41_2427 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    heff_drop(v_key_242);
    switch (heff_tag_of(v_x41_2427)) {
    case TAG_MkBlock: {
      V v_t_2428 = heff_field(v_x41_2427, 0);
      heff_take_n(v_x41_2427, 1ULL, 1);
      V v_t_2429 = heff_take_field(v_i_244, 2);
      V v_f_2455;
      if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
        heff_drop(v_t_2429);
        V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str8), heff_get_n(v_i_244, 0, 4));
        V v_t_2431 = heff_rec_n(5, shape_gs__names__used__self__inl, (V[]){v_gs_240, heff_dup(g_std_2eordmap_2eempty_get()), v_met_241, NTAG(TAG_Nothing), heff_dup(g_std_2eordmap_2eempty_get())});
        V v_t_2432 = (g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(v_t_2431, MK_INT(0LL), v_t_2428));
        V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str9)), v_t_2432);
        V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2433, ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str10)), NTAG(TAG_Nil)});
        v_f_2455 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str11), v_t_2434});
      } else {
        heff_drop(v_t_2429);
        V v_t_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str12), heff_get_n(v_i_244, 0, 4));
        V v_env_2436 = heff_rec_n(5, shape_gs__names__used__self__inl, (V[]){v_gs_240, heff_dup(g_std_2eordmap_2eempty_get()), v_met_241, NTAG(TAG_Nothing), heff_dup(g_std_2eordmap_2eempty_get())});
        V v_t_2437 = v_t_2428;
        V v_t_2452;
        switch (heff_tag_of(v_t_2437)) {
        case TAG_TSeq: {
          V v_t_2440 = (g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(v_env_2436, MK_INT(0LL), v_t_2437));
          v_t_2452 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str13), v_t_2440), ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str14));
          break;
        }
        case TAG_TReturn: {
          V v_o_2441 = heff_field(v_t_2437, 0);
          heff_take_n(v_t_2437, 1ULL, 1);
          V v_t_2442 = ({ V a_0 = v_env_2436; V a_1 = MK_INT(0LL); V a_2 = v_o_2441; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop(v_o_2441); r_; });
          v_t_2452 = heff_get_n(v_t_2442, 0, 2);
          break;
        }
        case TAG_TLoop: {
          V v_t_2444 = (g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(v_env_2436, MK_INT(0LL), v_t_2437));
          v_t_2452 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str15), v_t_2444), ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str16));
          break;
        }
        case TAG_TIf: {
          V v_t_2448 = (g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(v_env_2436, MK_INT(0LL), v_t_2437));
          v_t_2452 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str17), v_t_2448), ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str18));
          break;
        }
        case TAG_TCase: {
          V v_t_2451 = (g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(v_env_2436, MK_INT(0LL), v_t_2437));
          v_t_2452 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str19), v_t_2451), ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str20));
          break;
        }
        default: heff_nomatch(v_t_2437);
        }
        V v_t_2453 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str21)), v_t_2452);
        V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2453, ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str22)), NTAG(TAG_Nil)});
        v_f_2455 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefCodeOf_24cpr_str23), v_t_2454});
      }
      return ((HeffT2){{v_f_2455, NTAG(TAG_Nil)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x41_2427)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eextStr_str0, 243, "const $ext = (v) => typeof v === \"function\" \? (x) => $ext($tr(v(x))) : v !== null && typeof v === \"object\" && !Array.isArray(v) && !ArrayBuffer.isView(v) && !(\"$\" in v) \? Object.fromEntries(Object.entries(v).map(([l, x]) => [l, $ext(x)])) : v;");

static V g_heff_2ecompile_2eemit_2eextStr_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2eextStr_st;
static V g_heff_2ecompile_2eemit_2eextStr_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2eextStr_str0);
}
V g_heff_2ecompile_2eemit_2eextStr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2eextStr_st)) return g_heff_2ecompile_2eemit_2eextStr_val;
  return heff_global(&g_heff_2ecompile_2eemit_2eextStr_val, &g_heff_2ecompile_2eemit_2eextStr_st, g_heff_2ecompile_2eemit_2eextStr_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str0, 4, "$tr(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str1, 4, "$Bnc");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str2, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str3, 5, "$lazy");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str4, 2, "$T");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str5, 2, "$F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str6, 60, "const $T = { $: \"True\", a: [] }, $F = { $: \"False\", a: [] };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str7, 8, "$abandon");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str8, 60, "const $abandon = () => { throw new Error(\"heff:abandon\"); };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str9, 8, "$nomatch");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str10, 87, "const $nomatch = (s) => { throw new Error(\"heff: no case for '\" + (s && s.$) + \"'\"); };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str11, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str12, 125, "const $force = (f) => { if (f.$m !== undefined) return f.$m; const v = $tr(f({ $: \"MkUnit\", a: [] })); f.$m = v; return v; };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str13, 5, "$lazy");
HEFF_LIT(g_heff_2ecompile_2eemit_2eruntime_str14, 243, "const $lazy = (f) => { let state = 0, v; return () => { if (state === 2) return v; if (state === 1) throw new Error(\"heff: defined by itself\"); state = 1; try { v = $tr(f()); state = 2; return v; } finally { if (state === 1) state = 0; } }; };");
Clo g_heff_2ecompile_2eemit_2eruntime_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eruntime_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eruntime(V v_code_240) {
top: ;
  V v_t_241;
  if ((heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str0), v_code_240, MK_INT(0LL), 5)) || (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str1), v_code_240, MK_INT(0LL), 5)) || (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str2), v_code_240, MK_INT(0LL), 5)) || heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str3), v_code_240, MK_INT(0LL), 5)))))) {
    v_t_241 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get())});
  } else {
    v_t_241 = NTAG(TAG_Nothing);
  }
  V v_t_242;
  if ((heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str4), v_code_240, MK_INT(0LL), 5)) || heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str5), v_code_240, MK_INT(0LL), 5)))) {
    v_t_242 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str6)});
  } else {
    v_t_242 = NTAG(TAG_Nothing);
  }
  V v_t_243;
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str7), v_code_240, MK_INT(0LL), 5))) {
    v_t_243 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str8)});
  } else {
    v_t_243 = NTAG(TAG_Nothing);
  }
  V v_t_244;
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str9), v_code_240, MK_INT(0LL), 5))) {
    v_t_244 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str10)});
  } else {
    v_t_244 = NTAG(TAG_Nothing);
  }
  V v_t_245;
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str11), v_code_240, MK_INT(0LL), 5))) {
    v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str12)});
  } else {
    v_t_245 = NTAG(TAG_Nothing);
  }
  V v_t_246;
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eruntime_str13), v_code_240, MK_INT(0LL), 5))) {
    v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str14)});
  } else {
    v_t_246 = NTAG(TAG_Nothing);
  }
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_248})});
  V v_t_2410 = (g_heff_2ecompile_2eemit_2ecatMaybesL(heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_249})));
  V v_t_2411 = ({ V a_0 = MK_INT(0LL); V a_1 = v_code_240; V b_2 = MK_INT(0LL); V a_3 = heff_dup(g_heff_2ecompile_2eemit_2estrHelpers_get()); V r_ = (g_list_2emap_24s319754340x1392149466(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
  V v_t_2412 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2411));
  return (g_prelude_2e_2b_2b(v_t_2410, v_t_2412));
}
V g_heff_2ecompile_2eemit_2eruntime_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eruntime(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str3, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str4, 2, "$p");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str5, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str6, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str7, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str8, 2, "()");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str9, 5, "$sum(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str10, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehandlerOf_str11, 1, ")");
Clo g_heff_2ecompile_2eemit_2ehandlerOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ehandlerOf_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ehandlerOf(V v_provs_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_t_243 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str0); V a_1 = v_k_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str1), v_k_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_244 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_243));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_247; V a_2 = v_provs_240; V r_ = (g_heff_2ecompile_2eemit_2eprovIndexGo(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str4), heff_intShow(v_t_248));
    V v_t_2410 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str5); V a_1 = v_k_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str6), v_k_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_t_2411 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_t_2410; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str7)), v_t_2411);
    return heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str8));
  }
  case TAG_Plus: {
    V v_a_2413 = heff_field(v_x2_241, 0);
    V v_b_2414 = heff_field(v_x2_241, 1);
    V v_t_2415 = (g_heff_2ecompile_2eemit_2ehandlerOf(v_provs_240, v_a_2413));
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str9), v_t_2415), ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str10));
    V v_t_2417 = (g_heff_2ecompile_2eemit_2ehandlerOf(v_provs_240, v_b_2414));
    return heff_strAppend(heff_strAppend(v_t_2416, v_t_2417), ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str11));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2ehandlerOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ehandlerOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eimportLinesOf_str0, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eimportLinesOf_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eimportLinesOf_str2, 7, "import ");
Clo g_heff_2ecompile_2eemit_2eimportLinesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eimportLinesOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eimportLinesOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_s_243 = heff_dup(heff_rfield(v_p_241, 1));
    V v_t_244 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str0); V a_1 = v_s_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str1), v_s_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_243); r_; });
    V v_t_245 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(7LL); V b_2 = ((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str2); V a_3 = v_t_244; V r_ = (g_list_2ekeepIf_24s185327080x101197346(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
    V v_t_246 = (g_heff_2ecompile_2eemit_2eimportLinesOf(v_rest_242));
    return (g_prelude_2e_2b_2b(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2eimportLinesOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eimportLinesOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2earmJs_24tok3_str0, 0, "");
V g_heff_2ecompile_2eemit_2earmJs_24tok3_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2earmJs_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2earmJs_24tok3_entry, 7, 0};

V g_heff_2ecompile_2eemit_2earmJs_24tok3(V v_tok_240, V v_sc_241, V v_ind_242, V v_tag_243, V v_vs_244, V v_parts_245, V v_lines_246) {
top: ;
  V v_t_249 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2eemit_2earmJs_24tok3_lam0, 1, 1, (V[]){heff_dup(v_parts_245)}), v_vs_244));
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_vs_244);
    heff_drop(v_t_249);
    V v_t_2410 = heff_tr(heff_call(v_lines_246, 2, (V[]){heff_get_n(v_sc_241, 1, 3), heff_intAdd(v_ind_242, MK_INT(2LL))}));
    return heff_tag_at_n(v_tok_240, TAG_MkArmJs, 3, (V[]){v_tag_243, NTAG(TAG_True), v_t_2410});
  } else {
    heff_drop_cell(v_tok_240, 3);
    heff_drop(v_t_249);
    V v_t_2411 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), heff_dup(heff_rfield(v_sc_241, 1))});
    V v_t_2412 = (g_list_2efoldl_24s2018454372x1607369768(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2earmJs_24tok3_str0), MK_INT(0LL), v_t_2411, v_vs_244));
    return (g_heff_2ecompile_2eemit_2earmBound(v_sc_241, v_ind_242, v_tag_243, v_lines_246, v_t_2412));
  }
}
V g_heff_2ecompile_2eemit_2earmJs_24tok3_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2eemit_2earmJs_24tok3(a[0], a[1], a[2], a[3], a[4], a5, a[6]); heff_drop(a5); return r;
}
V g_heff_2ecompile_2eemit_2earmJs_24tok3_lam0(V self, V *args) {
  V v_v_247 = args[0];
  V v_parts_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_248 = ({ V a_0 = v_v_247; V a_1 = v_parts_245; V r_ = (g_list_2eany_24s1877524499x1789047582(a_0, a_1)); heff_drop(v_v_247); heff_drop(v_parts_245); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_248) == NTAG(TAG_True)));
  heff_drop(v_x1_248);
  return v_ret_24bool;
}