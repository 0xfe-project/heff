// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Accept 48933
#define TAG_Connect 42828
#define TAG_Left 13886
#define TAG_Listen 55096
#define TAG_Local 3927
#define TAG_MkWith 3751
#define TAG_Peer 1965
#define TAG_Read 61409
#define TAG_Release 43671
#define TAG_ReleaseListener 49395
#define TAG_Right 62770
#define TAG_Shutdown 48081
#define TAG_ThisSide 6714
#define TAG_Throw 56084
#define TAG_Write 36323
#define LBL_bind 9519364
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_host 9704047
#define LBL_malg 9839318
#define LBL_port 9942344
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_std_2enet_2enet_get(void);
V g_std_2enet_2ewithListener_24s515529705x1495267221(V, V, V, V, V);
V g_std_2enet_2ewithListener_24s515529705x1495267221_entry(V self, V *a);
extern Clo g_std_2enet_2ewithListener_24s515529705x1495267221_clo;
V g_std_2enet_2enet_lam1(V self, V *args);
V g_std_2enet_2enet_lam2(V self, V *args);
V g_std_2enet_2enet_lam3(V self, V *args);
V g_std_2enet_2enet_lam4(V self, V *args);
V g_std_2enet_2enet_lam5(V self, V *args);
V g_std_2enet_2enet_lam6(V self, V *args);
V g_std_2enet_2enet_lam7(V self, V *args);
V g_std_2enet_2enet_lam8(V self, V *args);
V g_std_2enet_2enet_lam9(V self, V *args);
V g_std_2enet_2enet_lam10(V self, V *args);
V g_std_2enet_2enet_lam11(V self, V *args);
V g_std_2enet_2enet_lam0(V self, V *args); static Clo g_std_2enet_2enet_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2enet_2enet_lam0, 3, 0};
V g_std_2enet_2enet_lam12(V self, V *args); static Clo g_std_2enet_2enet_lam12_clo = {{0x80000000u, K_CLO, 0}, g_std_2enet_2enet_lam12, 4, 0};

static V g_std_2enet_2enet_val;
static HEFF_ONCE g_std_2enet_2enet_st;
static V g_std_2enet_2enet_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2enet_2enet_lam0_clo), ((V)&g_std_2enet_2enet_lam12_clo)});
}
V g_std_2enet_2enet_get(void) {
  if (HEFF_DONE(g_std_2enet_2enet_st)) return g_std_2enet_2enet_val;
  return heff_global(&g_std_2enet_2enet_val, &g_std_2enet_2enet_st, g_std_2enet_2enet_init);
}
V g_std_2enet_2enet_lam1(V self, V *args) {
  V v_r_246 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tr(heff_call(v_k_245, 1, (V[]){v_r_246}));
  V f_ = v_g_241;
  args[0] = v_t_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam2(V self, V *args) {
  V v_r_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_k_2411, 1, (V[]){v_r_2412}));
  V f_ = v_g_241;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam3(V self, V *args) {
  V v_r_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_r_2416}));
  V f_ = v_g_241;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam4(V self, V *args) {
  V v_r_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tr(heff_call(v_k_2420, 1, (V[]){v_r_2421}));
  V f_ = v_g_241;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam5(V self, V *args) {
  V v_r_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_tr(heff_call(v_k_2425, 1, (V[]){v_r_2426}));
  V f_ = v_g_241;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam6(V self, V *args) {
  V v_r_2430 = args[0];
  V v_k_2429 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_tr(heff_call(v_k_2429, 1, (V[]){v_r_2430}));
  V f_ = v_g_241;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam7(V self, V *args) {
  V v_r_2434 = args[0];
  V v_k_2433 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2435 = heff_tr(heff_call(v_k_2433, 1, (V[]){v_r_2434}));
  V f_ = v_g_241;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam8(V self, V *args) {
  V v_r_2438 = args[0];
  V v_k_2437 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_tr(heff_call(v_k_2437, 1, (V[]){v_r_2438}));
  V f_ = v_g_241;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam9(V self, V *args) {
  V v_r_2442 = args[0];
  V v_k_2441 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2443 = heff_tr(heff_call(v_k_2441, 1, (V[]){v_r_2442}));
  V f_ = v_g_241;
  args[0] = v_t_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam10(V self, V *args) {
  V v_r_2446 = args[0];
  V v_k_2445 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2447 = heff_tr(heff_call(v_k_2445, 1, (V[]){v_r_2446}));
  V f_ = v_g_241;
  args[0] = v_t_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam11(V self, V *args) {
  V v_r_2450 = args[0];
  V v_k_2449 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_tr(heff_call(v_k_2449, 1, (V[]){v_r_2450}));
  V f_ = v_g_241;
  args[0] = v_t_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Connect: {
    V v_h_243 = heff_field(v_p_242, 0);
    V v_port_244 = heff_field(v_p_242, 1);
    V v_k_245 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Connect = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Connect, TAG_Connect, 3, (V[]){v_h_243, v_port_244, heff_clo_n(g_std_2enet_2enet_lam1, 1, 2, (V[]){v_k_245, v_g_241})});
  }
  case TAG_Listen: {
    V v_h_248 = heff_field(v_p_242, 0);
    V v_port_249 = heff_field(v_p_242, 1);
    V v_n_2410 = heff_field(v_p_242, 2);
    V v_k_2411 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Listen = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24Listen, TAG_Listen, 4, (V[]){v_h_248, v_port_249, v_n_2410, heff_clo_n(g_std_2enet_2enet_lam2, 1, 2, (V[]){v_k_2411, v_g_241})});
  }
  case TAG_Accept: {
    V v_l_2414 = heff_field(v_p_242, 0);
    V v_k_2415 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Accept = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Accept, TAG_Accept, 2, (V[]){v_l_2414, heff_clo_n(g_std_2enet_2enet_lam3, 1, 2, (V[]){v_k_2415, v_g_241})});
  }
  case TAG_Read: {
    V v_c_2418 = heff_field(v_p_242, 0);
    V v_n_2419 = heff_field(v_p_242, 1);
    V v_k_2420 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Read = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Read, TAG_Read, 3, (V[]){v_c_2418, v_n_2419, heff_clo_n(g_std_2enet_2enet_lam4, 1, 2, (V[]){v_k_2420, v_g_241})});
  }
  case TAG_Write: {
    V v_c_2423 = heff_field(v_p_242, 0);
    V v_b_2424 = heff_field(v_p_242, 1);
    V v_k_2425 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Write = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Write, TAG_Write, 3, (V[]){v_c_2423, v_b_2424, heff_clo_n(g_std_2enet_2enet_lam5, 1, 2, (V[]){v_k_2425, v_g_241})});
  }
  case TAG_Shutdown: {
    V v_c_2428 = heff_field(v_p_242, 0);
    V v_k_2429 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Shutdown = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Shutdown, TAG_Shutdown, 2, (V[]){v_c_2428, heff_clo_n(g_std_2enet_2enet_lam6, 1, 2, (V[]){v_k_2429, v_g_241})});
  }
  case TAG_Peer: {
    V v_c_2432 = heff_field(v_p_242, 0);
    V v_k_2433 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Peer = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Peer, TAG_Peer, 2, (V[]){v_c_2432, heff_clo_n(g_std_2enet_2enet_lam7, 1, 2, (V[]){v_k_2433, v_g_241})});
  }
  case TAG_ThisSide: {
    V v_c_2436 = heff_field(v_p_242, 0);
    V v_k_2437 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ThisSide = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ThisSide, TAG_ThisSide, 2, (V[]){v_c_2436, heff_clo_n(g_std_2enet_2enet_lam8, 1, 2, (V[]){v_k_2437, v_g_241})});
  }
  case TAG_Local: {
    V v_l_2440 = heff_field(v_p_242, 0);
    V v_k_2441 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Local = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Local, TAG_Local, 2, (V[]){v_l_2440, heff_clo_n(g_std_2enet_2enet_lam9, 1, 2, (V[]){v_k_2441, v_g_241})});
  }
  case TAG_Release: {
    V v_c_2444 = heff_field(v_p_242, 0);
    V v_k_2445 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Release = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Release, TAG_Release, 2, (V[]){v_c_2444, heff_clo_n(g_std_2enet_2enet_lam10, 1, 2, (V[]){v_k_2445, v_g_241})});
  }
  case TAG_ReleaseListener: {
    V v_l_2448 = heff_field(v_p_242, 0);
    V v_k_2449 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReleaseListener = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ReleaseListener, TAG_ReleaseListener, 2, (V[]){v_l_2448, heff_clo_n(g_std_2enet_2enet_lam11, 1, 2, (V[]){v_k_2449, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2enet_2enet_lam12(V self, V *args) {
  V v_m_2452 = args[0];
  V v_n_2453 = args[1];
  V v_nt_2454 = args[2];
  V v_p_2455 = args[3];
  heff_drop(v_m_2452);
  heff_drop(v_n_2453);
  heff_drop(v_nt_2454);
  return v_p_2455;
}
V g_std_2enet_2ewithListener_24s515529705x1495267221_lam0(V self, V *args); static Clo g_std_2enet_2ewithListener_24s515529705x1495267221_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2enet_2ewithListener_24s515529705x1495267221_lam0, 1, 0};
V g_std_2enet_2ewithListener_24s515529705x1495267221_lam3(V self, V *args); static Clo g_std_2enet_2ewithListener_24s515529705x1495267221_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2enet_2ewithListener_24s515529705x1495267221_lam3, 1, 0};
V g_std_2enet_2ewithListener_24s515529705x1495267221_lam4(V self, V *args);
V g_std_2enet_2ewithListener_24s515529705x1495267221_lam2(V self, V *args);
V g_std_2enet_2ewithListener_24s515529705x1495267221_lam1(V self, V *args);
Clo g_std_2enet_2ewithListener_24s515529705x1495267221_clo = {{0x80000000u, K_CLO, 0}, g_std_2enet_2ewithListener_24s515529705x1495267221_entry, 5, 0};

V g_std_2enet_2ewithListener_24s515529705x1495267221(V v_address_240, V v_backlog_241, V v_body_242, V v_p_243, V v_p_244) {
top: ;
  V v_port_245 = heff_take_field(v_address_240, 1);
  V v_host_246 = heff_get_n(v_address_240, 0, 2);
  V v_port_247 = v_port_245;
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Listen, 4, (V[]){v_host_246, v_port_247, v_backlog_241, ((V)&g_std_2enet_2ewithListener_24s515529705x1495267221_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})}));
  return heff_tail(heff_dup(heff_rfield(v_p_243, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_std_2enet_2ewithListener_24s515529705x1495267221_lam1, 1, 3, (V[]){v_p_243, v_p_244, v_body_242})});
}
V g_std_2enet_2ewithListener_24s515529705x1495267221_entry(V self, V *a) {
  (void)self;
  return g_std_2enet_2ewithListener_24s515529705x1495267221(a[0], a[1], a[2], a[3], a[4]);
}
V g_std_2enet_2ewithListener_24s515529705x1495267221_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_std_2enet_2ewithListener_24s515529705x1495267221_lam3(V self, V *args) {
  V v_r_2420 = args[0];
  return v_r_2420;
}
V g_std_2enet_2ewithListener_24s515529705x1495267221_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    V v_err_2426 = heff_field(v_x_2425, 0);
    V v_ru_24x_2425_24Left = heff_take_reuse_n(v_x_2425, 1ULL, 1);
    heff_drop(v_x_2419);
    V v_t_2427 = heff_tag_at_n(v_ru_24x_2425_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2426})});
    V v_t_2428 = heff_tr(heff_call(heff_take_field(v_p_243, 2), 1, (V[]){v_t_2427}));
    V f_ = heff_get_n(v_p_243, 1, 3);
    heff_room[0] = v_t_2428;
    heff_room[1] = v_p_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2425, 0ULL, 1);
    heff_drop_rec(v_p_243, 3);
    V f_ = v_p_244;
    args[0] = v_x_2419;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_std_2enet_2ewithListener_24s515529705x1495267221_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReleaseListener, 2, (V[]){v_x_2417, ((V)&g_std_2enet_2ewithListener_24s515529705x1495267221_lam3_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})}));
  V f_ = heff_dup(heff_rfield(v_p_243, 1));
  heff_room[0] = v_t_2424;
  heff_room[1] = heff_clo_n(g_std_2enet_2ewithListener_24s515529705x1495267221_lam4, 1, 3, (V[]){v_p_243, v_p_244, v_x_2419});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2enet_2ewithListener_24s515529705x1495267221_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    heff_drop(v_body_242);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2413_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2414})});
    V v_t_2416 = heff_tr(heff_call(heff_take_field(v_p_243, 2), 1, (V[]){v_t_2415}));
    V f_ = heff_get_n(v_p_243, 1, 3);
    heff_room[0] = v_t_2416;
    heff_room[1] = v_p_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    V v_c_2418 = heff_tr(heff_call(v_body_242, 1, (V[]){heff_tag_n(TAG_MkWith, 1, (V[]){heff_dup(v_x_2417)})}));
    V f_ = v_c_2418;
    heff_room[0] = heff_dup(v_p_243);
    heff_room[1] = heff_clo_n(g_std_2enet_2ewithListener_24s515529705x1495267221_lam2, 1, 3, (V[]){v_x_2417, v_p_243, v_p_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2413);
  }
}