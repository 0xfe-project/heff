// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Accept 48933
#define TAG_Close 2276
#define TAG_Connect 42828
#define TAG_Listen 55096
#define TAG_Local 3927
#define TAG_Peer 1965
#define TAG_Read 61409
#define TAG_Shutdown 48081
#define TAG_Write 36323
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_std_2enet_2enet_get(void);
V g_std_2enet_2enet_lam1(V self, V *args);
V g_std_2enet_2enet_lam2(V self, V *args);
V g_std_2enet_2enet_lam3(V self, V *args);
V g_std_2enet_2enet_lam4(V self, V *args);
V g_std_2enet_2enet_lam5(V self, V *args);
V g_std_2enet_2enet_lam6(V self, V *args);
V g_std_2enet_2enet_lam7(V self, V *args);
V g_std_2enet_2enet_lam8(V self, V *args);
V g_std_2enet_2enet_lam0(V self, V *args); static Clo g_std_2enet_2enet_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2enet_2enet_lam0, 3, 0};
V g_std_2enet_2enet_lam9(V self, V *args); static Clo g_std_2enet_2enet_lam9_clo = {{0x80000000u, K_CLO, 0}, g_std_2enet_2enet_lam9, 4, 0};

static V g_std_2enet_2enet_val;
static HEFF_ONCE g_std_2enet_2enet_st;
static V g_std_2enet_2enet_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2enet_2enet_lam0_clo), ((V)&g_std_2enet_2enet_lam9_clo)});
}
V g_std_2enet_2enet_get(void) {
  if (HEFF_DONE(g_std_2enet_2enet_st)) return g_std_2enet_2enet_val;
  return heff_global(&g_std_2enet_2enet_val, &g_std_2enet_2enet_st, g_std_2enet_2enet_init);
}
V g_std_2enet_2enet_lam1(V self, V *args) {
  V v_r_246 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tr(heff_call(v_k_245, 1, (V[]){v_r_246}));
  V f_ = v_g_241;
  args[0] = v_t_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam2(V self, V *args) {
  V v_r_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_k_2411, 1, (V[]){v_r_2412}));
  V f_ = v_g_241;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam3(V self, V *args) {
  V v_r_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_r_2416}));
  V f_ = v_g_241;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam4(V self, V *args) {
  V v_r_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tr(heff_call(v_k_2420, 1, (V[]){v_r_2421}));
  V f_ = v_g_241;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam5(V self, V *args) {
  V v_r_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_tr(heff_call(v_k_2425, 1, (V[]){v_r_2426}));
  V f_ = v_g_241;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam6(V self, V *args) {
  V v_r_2430 = args[0];
  V v_k_2429 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_tr(heff_call(v_k_2429, 1, (V[]){v_r_2430}));
  V f_ = v_g_241;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam7(V self, V *args) {
  V v_r_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438 = heff_tr(heff_call(v_k_2436, 1, (V[]){v_r_2437}));
  V f_ = v_g_241;
  args[0] = v_t_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam8(V self, V *args) {
  V v_r_2441 = args[0];
  V v_k_2440 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = heff_tr(heff_call(v_k_2440, 1, (V[]){v_r_2441}));
  V f_ = v_g_241;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Connect: {
    V v_h_243 = heff_field(v_p_242, 0);
    V v_port_244 = heff_field(v_p_242, 1);
    V v_k_245 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Connect = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Connect, TAG_Connect, 3, (V[]){v_h_243, v_port_244, heff_clo_n(g_std_2enet_2enet_lam1, 1, 2, (V[]){v_k_245, v_g_241})});
  }
  case TAG_Listen: {
    V v_h_248 = heff_field(v_p_242, 0);
    V v_port_249 = heff_field(v_p_242, 1);
    V v_n_2410 = heff_field(v_p_242, 2);
    V v_k_2411 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Listen = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24Listen, TAG_Listen, 4, (V[]){v_h_248, v_port_249, v_n_2410, heff_clo_n(g_std_2enet_2enet_lam2, 1, 2, (V[]){v_k_2411, v_g_241})});
  }
  case TAG_Accept: {
    V v_l_2414 = heff_field(v_p_242, 0);
    V v_k_2415 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Accept = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Accept, TAG_Accept, 2, (V[]){v_l_2414, heff_clo_n(g_std_2enet_2enet_lam3, 1, 2, (V[]){v_k_2415, v_g_241})});
  }
  case TAG_Read: {
    V v_c_2418 = heff_field(v_p_242, 0);
    V v_n_2419 = heff_field(v_p_242, 1);
    V v_k_2420 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Read = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Read, TAG_Read, 3, (V[]){v_c_2418, v_n_2419, heff_clo_n(g_std_2enet_2enet_lam4, 1, 2, (V[]){v_k_2420, v_g_241})});
  }
  case TAG_Write: {
    V v_c_2423 = heff_field(v_p_242, 0);
    V v_b_2424 = heff_field(v_p_242, 1);
    V v_k_2425 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Write = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Write, TAG_Write, 3, (V[]){v_c_2423, v_b_2424, heff_clo_n(g_std_2enet_2enet_lam5, 1, 2, (V[]){v_k_2425, v_g_241})});
  }
  case TAG_Shutdown: {
    V v_c_2428 = heff_field(v_p_242, 0);
    V v_k_2429 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Shutdown = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Shutdown, TAG_Shutdown, 2, (V[]){v_c_2428, heff_clo_n(g_std_2enet_2enet_lam6, 1, 2, (V[]){v_k_2429, v_g_241})});
  }
  case TAG_Close: {
    V v_i_2432 = heff_field(v_p_242, 0);
    V v_x_2433 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Close = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2434 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2433}));
    return heff_tag_at_n(v_ru_24p_242_24Close, TAG_Close, 2, (V[]){v_i_2432, v_t_2434});
  }
  case TAG_Peer: {
    V v_c_2435 = heff_field(v_p_242, 0);
    V v_k_2436 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Peer = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Peer, TAG_Peer, 2, (V[]){v_c_2435, heff_clo_n(g_std_2enet_2enet_lam7, 1, 2, (V[]){v_k_2436, v_g_241})});
  }
  case TAG_Local: {
    V v_i_2439 = heff_field(v_p_242, 0);
    V v_k_2440 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Local = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Local, TAG_Local, 2, (V[]){v_i_2439, heff_clo_n(g_std_2enet_2enet_lam8, 1, 2, (V[]){v_k_2440, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2enet_2enet_lam9(V self, V *args) {
  V v_m_2443 = args[0];
  V v_n_2444 = args[1];
  V v_nt_2445 = args[2];
  V v_p_2446 = args[3];
  heff_drop(v_m_2443);
  heff_drop(v_n_2444);
  heff_drop(v_nt_2445);
  switch (heff_tag_of(v_p_2446)) {
  case TAG_Connect: {
    V v_h_2447 = heff_field(v_p_2446, 0);
    V v_port_2448 = heff_field(v_p_2446, 1);
    V v_k_2449 = heff_field(v_p_2446, 2);
    V v_ru_24p_2446_24Connect = heff_take_reuse_n(v_p_2446, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_2446_24Connect, TAG_Connect, 3, (V[]){v_h_2447, v_port_2448, v_k_2449});
  }
  case TAG_Listen: {
    V v_h_2450 = heff_field(v_p_2446, 0);
    V v_port_2451 = heff_field(v_p_2446, 1);
    V v_b_2452 = heff_field(v_p_2446, 2);
    V v_k_2453 = heff_field(v_p_2446, 3);
    V v_ru_24p_2446_24Listen = heff_take_reuse_n(v_p_2446, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_2446_24Listen, TAG_Listen, 4, (V[]){v_h_2450, v_port_2451, v_b_2452, v_k_2453});
  }
  case TAG_Accept: {
    V v_l_2454 = heff_field(v_p_2446, 0);
    V v_k_2455 = heff_field(v_p_2446, 1);
    V v_ru_24p_2446_24Accept = heff_take_reuse_n(v_p_2446, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2446_24Accept, TAG_Accept, 2, (V[]){v_l_2454, v_k_2455});
  }
  case TAG_Read: {
    V v_c_2456 = heff_field(v_p_2446, 0);
    V v_b_2457 = heff_field(v_p_2446, 1);
    V v_k_2458 = heff_field(v_p_2446, 2);
    V v_ru_24p_2446_24Read = heff_take_reuse_n(v_p_2446, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_2446_24Read, TAG_Read, 3, (V[]){v_c_2456, v_b_2457, v_k_2458});
  }
  case TAG_Write: {
    V v_c_2459 = heff_field(v_p_2446, 0);
    V v_b_2460 = heff_field(v_p_2446, 1);
    V v_k_2461 = heff_field(v_p_2446, 2);
    V v_ru_24p_2446_24Write = heff_take_reuse_n(v_p_2446, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_2446_24Write, TAG_Write, 3, (V[]){v_c_2459, v_b_2460, v_k_2461});
  }
  case TAG_Shutdown: {
    V v_c_2462 = heff_field(v_p_2446, 0);
    V v_k_2463 = heff_field(v_p_2446, 1);
    V v_ru_24p_2446_24Shutdown = heff_take_reuse_n(v_p_2446, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2446_24Shutdown, TAG_Shutdown, 2, (V[]){v_c_2462, v_k_2463});
  }
  case TAG_Close: {
    V v_i_2464 = heff_field(v_p_2446, 0);
    V v_x_2465 = heff_field(v_p_2446, 1);
    V v_ru_24p_2446_24Close = heff_take_reuse_n(v_p_2446, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2446_24Close, TAG_Close, 2, (V[]){v_i_2464, v_x_2465});
  }
  case TAG_Peer: {
    V v_c_2466 = heff_field(v_p_2446, 0);
    V v_k_2467 = heff_field(v_p_2446, 1);
    V v_ru_24p_2446_24Peer = heff_take_reuse_n(v_p_2446, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2446_24Peer, TAG_Peer, 2, (V[]){v_c_2466, v_k_2467});
  }
  case TAG_Local: {
    V v_i_2468 = heff_field(v_p_2446, 0);
    V v_k_2469 = heff_field(v_p_2446, 1);
    V v_ru_24p_2446_24Local = heff_take_reuse_n(v_p_2446, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2446_24Local, TAG_Local, 2, (V[]){v_i_2468, v_k_2469});
  }
  default: return heff_nomatch(v_p_2446);
  }
}