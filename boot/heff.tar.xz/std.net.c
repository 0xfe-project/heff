// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Accept 48933
#define TAG_Connect 42828
#define TAG_Left 13886
#define TAG_Listen 55096
#define TAG_Local 3927
#define TAG_MkWith 3751
#define TAG_Peer 1965
#define TAG_Read 61409
#define TAG_Release 43671
#define TAG_ReleaseListener 49395
#define TAG_Right 62770
#define TAG_Shutdown 48081
#define TAG_ThisSide 6714
#define TAG_Throw 56084
#define TAG_Write 36323
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_std_2enet_2eaccept_24s1720705717x1901582490(V, V, V, V, V);
V g_std_2enet_2eaccept_24s1720705717x1901582490_entry(V self, V *a);
extern Clo g_std_2enet_2eaccept_24s1720705717x1901582490_clo;
V g_std_2enet_2enet_get(void);
V g_std_2enet_2enet_lam1(V self, V *args);
V g_std_2enet_2enet_lam2(V self, V *args);
V g_std_2enet_2enet_lam3(V self, V *args);
V g_std_2enet_2enet_lam4(V self, V *args);
V g_std_2enet_2enet_lam5(V self, V *args);
V g_std_2enet_2enet_lam6(V self, V *args);
V g_std_2enet_2enet_lam7(V self, V *args);
V g_std_2enet_2enet_lam8(V self, V *args);
V g_std_2enet_2enet_lam9(V self, V *args);
V g_std_2enet_2enet_lam10(V self, V *args);
V g_std_2enet_2enet_lam11(V self, V *args);
V g_std_2enet_2enet_lam0(V self, V *args); static Clo g_std_2enet_2enet_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2enet_2enet_lam0, 3, 0};
V g_std_2enet_2enet_lam12(V self, V *args); static Clo g_std_2enet_2enet_lam12_clo = {{0x80000000u, K_CLO, 0}, g_std_2enet_2enet_lam12, 4, 0};

static V g_std_2enet_2enet_val;
static HEFF_ONCE g_std_2enet_2enet_st;
static V g_std_2enet_2enet_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2enet_2enet_lam0_clo), ((V)&g_std_2enet_2enet_lam12_clo)});
}
V g_std_2enet_2enet_get(void) {
  if (HEFF_DONE(g_std_2enet_2enet_st)) return g_std_2enet_2enet_val;
  return heff_global(&g_std_2enet_2enet_val, &g_std_2enet_2enet_st, g_std_2enet_2enet_init);
}
V g_std_2enet_2enet_lam1(V self, V *args) {
  V v_r_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_r_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam2(V self, V *args) {
  V v_r_2413 = args[0];
  V v_k_2412 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_k_2412, 1, (V[]){v_r_2413}));
  V f_ = v_g_241;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam3(V self, V *args) {
  V v_r_2417 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tr(heff_call(v_k_2416, 1, (V[]){v_r_2417}));
  V f_ = v_g_241;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam4(V self, V *args) {
  V v_r_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_tr(heff_call(v_k_2422, 1, (V[]){v_r_2423}));
  V f_ = v_g_241;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam5(V self, V *args) {
  V v_r_2429 = args[0];
  V v_k_2428 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_tr(heff_call(v_k_2428, 1, (V[]){v_r_2429}));
  V f_ = v_g_241;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam6(V self, V *args) {
  V v_r_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_tr(heff_call(v_k_2432, 1, (V[]){v_r_2433}));
  V f_ = v_g_241;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam7(V self, V *args) {
  V v_r_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438 = heff_tr(heff_call(v_k_2436, 1, (V[]){v_r_2437}));
  V f_ = v_g_241;
  args[0] = v_t_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam8(V self, V *args) {
  V v_r_2441 = args[0];
  V v_k_2440 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = heff_tr(heff_call(v_k_2440, 1, (V[]){v_r_2441}));
  V f_ = v_g_241;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam9(V self, V *args) {
  V v_r_2445 = args[0];
  V v_k_2444 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tr(heff_call(v_k_2444, 1, (V[]){v_r_2445}));
  V f_ = v_g_241;
  args[0] = v_t_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam10(V self, V *args) {
  V v_r_2449 = args[0];
  V v_k_2448 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_tr(heff_call(v_k_2448, 1, (V[]){v_r_2449}));
  V f_ = v_g_241;
  args[0] = v_t_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam11(V self, V *args) {
  V v_r_2453 = args[0];
  V v_k_2452 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2454 = heff_tr(heff_call(v_k_2452, 1, (V[]){v_r_2453}));
  V f_ = v_g_241;
  args[0] = v_t_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2enet_2enet_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Connect: {
    V v_h_243 = heff_field(v_p_242, 0);
    V v_port_244 = heff_field(v_p_242, 1);
    V v_ms_245 = heff_field(v_p_242, 2);
    V v_k_246 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Connect = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24Connect, TAG_Connect, 4, (V[]){v_h_243, v_port_244, v_ms_245, heff_clo_n(g_std_2enet_2enet_lam1, 1, 2, (V[]){v_k_246, v_g_241})});
  }
  case TAG_Listen: {
    V v_h_249 = heff_field(v_p_242, 0);
    V v_port_2410 = heff_field(v_p_242, 1);
    V v_n_2411 = heff_field(v_p_242, 2);
    V v_k_2412 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Listen = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24Listen, TAG_Listen, 4, (V[]){v_h_249, v_port_2410, v_n_2411, heff_clo_n(g_std_2enet_2enet_lam2, 1, 2, (V[]){v_k_2412, v_g_241})});
  }
  case TAG_Accept: {
    V v_l_2415 = heff_field(v_p_242, 0);
    V v_k_2416 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Accept = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Accept, TAG_Accept, 2, (V[]){v_l_2415, heff_clo_n(g_std_2enet_2enet_lam3, 1, 2, (V[]){v_k_2416, v_g_241})});
  }
  case TAG_Read: {
    V v_c_2419 = heff_field(v_p_242, 0);
    V v_n_2420 = heff_field(v_p_242, 1);
    V v_ms_2421 = heff_field(v_p_242, 2);
    V v_k_2422 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Read = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24Read, TAG_Read, 4, (V[]){v_c_2419, v_n_2420, v_ms_2421, heff_clo_n(g_std_2enet_2enet_lam4, 1, 2, (V[]){v_k_2422, v_g_241})});
  }
  case TAG_Write: {
    V v_c_2425 = heff_field(v_p_242, 0);
    V v_b_2426 = heff_field(v_p_242, 1);
    V v_ms_2427 = heff_field(v_p_242, 2);
    V v_k_2428 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Write = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24Write, TAG_Write, 4, (V[]){v_c_2425, v_b_2426, v_ms_2427, heff_clo_n(g_std_2enet_2enet_lam5, 1, 2, (V[]){v_k_2428, v_g_241})});
  }
  case TAG_Shutdown: {
    V v_c_2431 = heff_field(v_p_242, 0);
    V v_k_2432 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Shutdown = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Shutdown, TAG_Shutdown, 2, (V[]){v_c_2431, heff_clo_n(g_std_2enet_2enet_lam6, 1, 2, (V[]){v_k_2432, v_g_241})});
  }
  case TAG_Peer: {
    V v_c_2435 = heff_field(v_p_242, 0);
    V v_k_2436 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Peer = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Peer, TAG_Peer, 2, (V[]){v_c_2435, heff_clo_n(g_std_2enet_2enet_lam7, 1, 2, (V[]){v_k_2436, v_g_241})});
  }
  case TAG_ThisSide: {
    V v_c_2439 = heff_field(v_p_242, 0);
    V v_k_2440 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ThisSide = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ThisSide, TAG_ThisSide, 2, (V[]){v_c_2439, heff_clo_n(g_std_2enet_2enet_lam8, 1, 2, (V[]){v_k_2440, v_g_241})});
  }
  case TAG_Local: {
    V v_l_2443 = heff_field(v_p_242, 0);
    V v_k_2444 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Local = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Local, TAG_Local, 2, (V[]){v_l_2443, heff_clo_n(g_std_2enet_2enet_lam9, 1, 2, (V[]){v_k_2444, v_g_241})});
  }
  case TAG_Release: {
    V v_c_2447 = heff_field(v_p_242, 0);
    V v_k_2448 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Release = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Release, TAG_Release, 2, (V[]){v_c_2447, heff_clo_n(g_std_2enet_2enet_lam10, 1, 2, (V[]){v_k_2448, v_g_241})});
  }
  case TAG_ReleaseListener: {
    V v_l_2451 = heff_field(v_p_242, 0);
    V v_k_2452 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReleaseListener = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ReleaseListener, TAG_ReleaseListener, 2, (V[]){v_l_2451, heff_clo_n(g_std_2enet_2enet_lam11, 1, 2, (V[]){v_k_2452, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2enet_2enet_lam12(V self, V *args) {
  V v_m_2455 = args[0];
  V v_n_2456 = args[1];
  V v_nt_2457 = args[2];
  V v_p_2458 = args[3];
  heff_drop(v_m_2455);
  heff_drop(v_n_2456);
  heff_drop(v_nt_2457);
  return v_p_2458;
}
V g_std_2enet_2eaccept_24s1720705717x1901582490_lam0(V self, V *args); static Clo g_std_2enet_2eaccept_24s1720705717x1901582490_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2enet_2eaccept_24s1720705717x1901582490_lam0, 1, 0};
V g_std_2enet_2eaccept_24s1720705717x1901582490_lam3(V self, V *args); static Clo g_std_2enet_2eaccept_24s1720705717x1901582490_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2enet_2eaccept_24s1720705717x1901582490_lam3, 1, 0};
V g_std_2enet_2eaccept_24s1720705717x1901582490_lam4(V self, V *args);
V g_std_2enet_2eaccept_24s1720705717x1901582490_lam2(V self, V *args);
V g_std_2enet_2eaccept_24s1720705717x1901582490_lam1(V self, V *args);
Clo g_std_2enet_2eaccept_24s1720705717x1901582490_clo = {{0x80000000u, K_CLO, 0}, g_std_2enet_2eaccept_24s1720705717x1901582490_entry, 5, 0};

V g_std_2enet_2eaccept_24s1720705717x1901582490(V v_e_240, V v_l_241, V v_body_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_l_241)) {
  case TAG_MkWith: {
    V v_x_245 = heff_field(v_l_241, 0);
    v_t_246 = heff_dup(v_x_245);
    break;
  }
  default: heff_nomatch(v_l_241);
  }
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Accept, 2, (V[]){v_t_246, ((V)&g_std_2enet_2eaccept_24s1720705717x1901582490_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_hd_243), heff_clo_n(g_std_2enet_2eaccept_24s1720705717x1901582490_lam1, 1, 4, (V[]){v_e_240, v_hd_243, v_k_244, v_body_242})));
}
V g_std_2enet_2eaccept_24s1720705717x1901582490_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2enet_2eaccept_24s1720705717x1901582490(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_std_2enet_2eaccept_24s1720705717x1901582490_lam0(V self, V *args) {
  V v_r_247 = args[0];
  return v_r_247;
}
V g_std_2enet_2eaccept_24s1720705717x1901582490_lam3(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_std_2enet_2eaccept_24s1720705717x1901582490_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    V v_err_2424 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Left = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    heff_drop(v_x_2417);
    V v_t_2425 = heff_tag_at_n(v_ru_24x_2423_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2424})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2425, v_hd_243, v_k_244));
  }
  case TAG_Right: {
    heff_take_n(v_x_2423, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_hd_243);
    V f_ = v_k_244;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_std_2enet_2eaccept_24s1720705717x1901582490_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Release, 2, (V[]){v_x_2415, ((V)&g_std_2enet_2eaccept_24s1720705717x1901582490_lam3_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_243), heff_clo_n(g_std_2enet_2eaccept_24s1720705717x1901582490_lam4, 1, 4, (V[]){v_e_240, v_hd_243, v_k_244, v_x_2417})));
}
V g_std_2enet_2eaccept_24s1720705717x1901582490_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    heff_drop(v_body_242);
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2413})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2414, v_hd_243, v_k_244));
  }
  case TAG_Right: {
    V v_x_2415 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    V v_c_2416 = heff_tr(heff_call(v_body_242, 1, (V[]){heff_tag_n(TAG_MkWith, 1, (V[]){heff_dup(v_x_2415)})}));
    V f_ = v_c_2416;
    heff_room[0] = heff_dup(v_hd_243);
    heff_room[1] = heff_clo_n(g_std_2enet_2eaccept_24s1720705717x1901582490_lam2, 1, 4, (V[]){v_x_2415, v_e_240, v_hd_243, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2412);
  }
}