// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Done 47505
#define TAG_Next 8500
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803(V, V, V, V, V);
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_clo;
V g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818(V, V, V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_clo;
V g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118(V, V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_clo;
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419(V, V, V, V, V);
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_clo;
V g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_lam2(V self, V *args);
V g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_lam1(V self, V *args);
V g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_lam0(V self, V *args);
Clo g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_entry, 8, 0};

V g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818(V v_e_240, V v_idle_241, V v_c_242, V v_peer_243, V v_handle_244, V v_buf_245, V v_z_246, V v_z_247) {
top: ;
  V v_c_248 = (g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419(heff_dup(v_e_240), heff_dup(v_idle_241), v_c_242, v_buf_245, MK_INT(0LL)));
  return heff_tail(v_c_248, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_lam0, 1, 7, (V[]){v_e_240, v_idle_241, heff_dup(v_c_242), v_peer_243, v_z_246, v_handle_244, v_z_247})});
}
V g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7]); heff_drop(a2); return r;
}
V g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_idle_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_peer_243 = heff_env(self)[3];
  V v_handle_244 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Next: {
    V v_rest_2413 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    return ({ V a_0 = v_e_240; V a_1 = v_idle_241; V a_2 = v_c_242; V a_3 = v_peer_243; V a_4 = v_handle_244; V a_5 = v_rest_2413; V a_6 = v_z_246; V a_7 = v_z_247; V r_ = (g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_242); r_; });
  }
  case TAG_Done: {
    V v_stop_2414 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_idle_241);
    heff_drop(v_c_242);
    heff_drop(v_peer_243);
    heff_drop(v_handle_244);
    heff_drop(v_z_246);
    V f_ = v_z_247;
    args[0] = v_stop_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_idle_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_handle_244 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_peer_243 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2411 = (g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803(heff_dup(v_e_240), heff_dup(v_idle_241), v_c_242, heff_dup(v_handle_244), v_x_2410));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_z_246);
  heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_lam2, 1, 7, (V[]){v_e_240, v_idle_241, v_c_242, v_peer_243, v_handle_244, v_z_246, v_z_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_idle_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_peer_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_handle_244 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_idle_241); V a_2 = v_c_242; V a_3 = heff_dup(v_peer_243); V a_4 = v_x_249; V a_5 = heff_dup(v_z_246); V a_6 = heff_clo_n(g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_lam1, 1, 7, (V[]){v_e_240, v_idle_241, heff_dup(v_c_242), v_handle_244, v_z_246, v_peer_243, v_z_247}); V r_ = (g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_c_242); heff_drop(v_x_249); r_; });
}