// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAssign 4102
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(V, V);
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s643934088x525125611_24cpr(V, V);
Clo g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(V v_e_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EAssign: {
      V v_x_244 = heff_field(v_e1_242, 0);
      V v_v_246 = heff_field(v_e1_242, 2);
      heff_take_n(v_e1_242, 5ULL, 3);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_ru_24e_240_24At = heff_take_reuse_n(v_e_240, 0ULL, 2);
        V t_0 = v_v_246;
        V t_1 = heff_tag_at_n(v_ru_24e_240_24At, TAG_Cons, 2, (V[]){v_x_244, v_acc_241});
        v_e_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    default: {
      heff_drop(v_e1_242);
      HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s643934088x525125611_24cpr(v_acc_241, v_e_240));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        V v_y_2413 = v_field_2411;
        heff_drop(v_y_2413);
        return v_x_2412;
      }
    }
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(a[0], a[1]);
}