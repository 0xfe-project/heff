// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_binds 295100400
#define LBL_defs 9574869
#define LBL_fuel 9649789
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
static uint32_t shape_binds__args[] = {LBL_binds, LBL_args};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo;
V g_heff_2ecompile_2esimplify_2eapplyLam(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_clo;
V g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_24tok2_clo;
V g_heff_2ecompile_2esimplify_2eapplyToF(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo;
V g_heff_2ecompile_2esimplify_2eattemptBy(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebuilds_24tok2(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ebuilds_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuilds_24tok2_clo;
V g_heff_2ecompile_2esimplify_2ebuiltApplied(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ebuiltApplied_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltApplied_clo;
V g_heff_2ecompile_2esimplify_2ebuiltBy(V, V);
V g_heff_2ecompile_2esimplify_2ebuiltBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltBy_clo;
V g_heff_2ecompile_2esimplify_2ecallOf(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallOf_clo;
V g_heff_2ecompile_2esimplify_2ecallsW(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecallsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallsW_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eglobalLiteral(V, V);
V g_heff_2ecompile_2esimplify_2eglobalLiteral_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eglobalLiteral_clo;
V g_heff_2ecompile_2esimplify_2egrew(V, V);
V g_heff_2ecompile_2esimplify_2egrew_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrew_clo;
V g_heff_2ecompile_2esimplify_2egrewIn(V, V, V);
V g_heff_2ecompile_2esimplify_2egrewIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrewIn_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eknownField_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ematchApplied(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ematchApplied_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchApplied_clo;
V g_heff_2ecompile_2esimplify_2ematchApplied_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ematchApplied_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchApplied_24tok2_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eprunedCopy(V, V);
V g_heff_2ecompile_2esimplify_2eprunedCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedCopy_clo;
V g_heff_2ecompile_2esimplify_2epureOrPartial(V, V);
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2esimplify_2esplitArgs(V, V);
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo;
V g_heff_2ecompile_2esimplify_2estillCall(V, V);
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estillCall_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2estripLams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2estripLams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_24dps_clo;
V g_heff_2ecompile_2esimplify_2etakeL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2etakeL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_24dps_clo;
V g_heff_2ecompile_2esimplify_2etrySpec(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etrySpec_clo;
V g_heff_2ecompile_2esimplify_2evarsAre(V, V);
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evarsAre_clo;
V g_heff_2ecompile_2esimplify_2ewordLiteral(V);
V g_heff_2ecompile_2esimplify_2ewordLiteral_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewordLiteral_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_list_2eany_24s1742233102x56855645(V, V);
V g_list_2eany_24s1742233102x56855645_entry(V self, V *a);
extern Clo g_list_2eany_24s1742233102x56855645_clo;
V g_list_2eany_24s415398368x1824706470(V);
V g_list_2eany_24s415398368x1824706470_entry(V self, V *a);
extern Clo g_list_2eany_24s415398368x1824706470_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2eany_24s756915015x218492736(V);
V g_list_2eany_24s756915015x218492736_entry(V self, V *a);
extern Clo g_list_2eany_24s756915015x218492736_clo;
V g_list_2efoldl_24s591739608x1065283968(V, V);
V g_list_2efoldl_24s591739608x1065283968_entry(V self, V *a);
extern Clo g_list_2efoldl_24s591739608x1065283968_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1492759219x1917596721(V, V);
V g_list_2emap_24s1492759219x1917596721_entry(V self, V *a);
extern Clo g_list_2emap_24s1492759219x1917596721_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s549405518x243689326(V);
V g_list_2emap_24s549405518x243689326_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2etraverse_24s672366786x467588702(V, V);
V g_prelude_2etraverse_24s672366786x467588702_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s672366786x467588702_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
Clo g_heff_2ecompile_2esimplify_2etakeL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakeL_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etakeL_24dps(V v_n_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etakeL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etakeL_24dps(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_241}});
  }
  case TAG_Just: {
    V v_b_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_p_241, 1)))) {
      V v_t_243 = heff_intSub(heff_take_field(v_p_241, 1), MK_INT(1LL));
      V v_t_244 = ({ V rv_1 = v_t_243; V rr_ = heff_rec_reuse_nf(v_p_241, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      HeffT2 v_t_245 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_t_244));
      {
        V v_field_246 = v_t_245.f[0];
        V v_field_247 = v_t_245.f[1];
        V v_x_248 = v_field_246;
        V v_s_249 = v_field_247;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_x_248}), v_s_249}});
      }
    } else {
      heff_drop(v_b_242);
      heff_drop_cell(v_ru_24x1_240_24Just, 1);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_241}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2ecallsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecallsW_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ecallsW(V v_x_240, V v_p_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return v_n_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EVar: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELam: {
      V v_b_249 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_b_249, v_rest_245});
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_x41_244, 0);
      V v_argv_2411 = heff_field(v_x41_244, 1);
      V v_ru_24x41_244_24EApp = heff_take_reuse_n(v_x41_244, 3ULL, 2);
      V v_t_2452;
      switch (heff_tag_of(v_f_2410)) {
      case TAG_EVar: {
        V v_y_2412 = heff_dup(heff_field(v_f_2410, 0));
        if (heff_strEq_c_lent(v_x_240, v_y_2412, 2)) {
          V v_t_2413 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_argv_2411)}));
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_t_2413);
            v_t_2452 = heff_intAdd(v_n_242, MK_INT(1LL));
          } else {
            heff_drop(v_t_2413);
            v_t_2452 = v_n_242;
          }
        } else {
          v_t_2452 = v_n_242;
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_ELam: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EApp: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_ELet: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_ERecord: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EProj: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_ETag: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EMatch: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EPrim: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_ECall: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EInt: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EFloat: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EStr: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EBytes: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EFixed: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EFloat32: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EAbandon: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EBool: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_ESet: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EValues: {
        v_t_2452 = v_n_242;
        break;
      }
      case TAG_EFix: {
        v_t_2452 = v_n_242;
        break;
      }
      default: heff_nomatch(v_f_2410);
      }
      V v_t_2453 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x41_244_24EApp, v_argv_2411, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_t_2452;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_f_2410, v_t_2453});
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2455 = heff_field(v_x41_244, 1);
      V v_b_2456 = heff_field(v_x41_244, 2);
      heff_take_n(v_x41_244, 6ULL, 3);
      V v_t_2457 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_a_2455, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2456, v_rest_245})});
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2457;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2458 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 2);
      V v_t_2460 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x4_243_24Cons, v_fs_2458, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2460;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2461 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 4);
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e_2461, v_rest_245});
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2466 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 3);
      V v_t_2468 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_243_24Cons, v_argv_2466, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2468;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EMatch: {
      V v_sc_2469 = heff_field(v_x41_244, 0);
      V v_arms_2470 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_2471 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2470, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_sc_2469, v_t_2471});
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2474 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      V v_t_2475 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_243_24Cons, v_argv_2474, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2475;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2477 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      V v_t_2478 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_243_24Cons, v_argv_2477, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2478;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2486 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2487 = ({ V a_0 = v_c_2486; V a_1 = v_rest_245; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2486); r_; });
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2487;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2489 = heff_field(v_x41_244, 1);
      V v_b_2490 = heff_field(v_x41_244, 2);
      heff_take_n(v_x41_244, 6ULL, 3);
      V v_t_2491 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_a_2489, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2490, v_rest_245})});
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2491;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2492 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      V v_t_2493 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_243_24Cons, v_es_2492, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2493;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2esimplify_2ecallsW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ecallsW(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2esplitArgs_str0, 1, "t");
V g_heff_2ecompile_2esimplify_2esplitArgs_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esplitArgs_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esplitArgs_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esplitArgs(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_rec_n(2, shape_binds__args, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_p_241});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_argv_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x_245 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_a_243));
    return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2esplitArgs_lam0, 1, 2, (V[]){v_x_245, v_a_243}), heff_clo_n(g_heff_2ecompile_2esimplify_2esplitArgs_lam1, 2, 1, (V[]){v_argv_244}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esplitArgs(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2esplitArgs_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
    heff_drop(v_x_245);
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_a_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_p_246});
  } else {
    heff_drop(v_x_245);
    HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2esplitArgs_str0), v_p_246));
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_x_2411 = v_field_249;
      V v_s_2412 = v_field_2410;
      V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2411), v_a_243})});
      V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2411})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_s_2412});
    }
  }
}
V g_heff_2ecompile_2esimplify_2esplitArgs_lam1(V self, V *args) {
  V v_one_2415 = args[0];
  V v_z_2416 = args[1];
  V v_argv_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esplitArgs_clo), 1, (V[]){v_argv_244}));
  V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_2416}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_binds_2421 = heff_take_field(v_x_2419, 0);
    V v_args_2422 = heff_get_n(v_x_2419, 1, 2);
    V v_a_2425;
    switch (heff_tag_of(v_one_2415)) {
    case TAG_MkPair: {
      V v_y_2424 = heff_dup(heff_field(v_one_2415, 1));
      v_a_2425 = v_y_2424;
      break;
    }
    default: heff_nomatch(v_one_2415);
    }
    V v_t_2428;
    switch (heff_tag_of(v_one_2415)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_field(v_one_2415, 0);
      heff_take_n(v_one_2415, 1ULL, 2);
      v_t_2428 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_one_2415);
    }
    V v_t_2430;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Nothing: {
      v_t_2430 = heff_rec_n(2, shape_binds__args, (V[]){v_binds_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_a_2425, v_args_2422})});
      break;
    }
    case TAG_Just: {
      V v_bd_2429 = heff_field(v_t_2428, 0);
      heff_take_n(v_t_2428, 1ULL, 1);
      v_t_2430 = heff_rec_n(2, shape_binds__args, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_bd_2429, v_binds_2421}), heff_tag_n(TAG_Cons, 2, (V[]){v_a_2425, v_args_2422})});
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
Clo g_heff_2ecompile_2esimplify_2eglobalLiteral_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eglobalLiteral_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eglobalLiteral(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_240});
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_t_244 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_244);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_244);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EGlobal: {
      V v_h_245 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop(v_g_240);
      return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_h_245});
    }
    case TAG_ELam: {
      V v_t_248 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_248);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_248);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EApp: {
      V v_t_2411 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2411);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2411);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_ELet: {
      V v_t_2415 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2415);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 3);
        heff_drop(v_t_2415);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_ERecord: {
      V v_t_2418 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2418);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2418);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EProj: {
      V v_t_2423 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2423);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 4);
        heff_drop(v_t_2423);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_ETag: {
      V v_t_2427 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2427);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 3);
        heff_drop(v_t_2427);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EMatch: {
      V v_t_2430 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2430);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2430);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EPrim: {
      V v_t_2432 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2432);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2432);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EPrimCall: {
      V v_t_2435 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2435);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2435);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_ECall: {
      V v_t_2438 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2438);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2438);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EInt: {
      V v_t_2440 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2440);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2440);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EFloat: {
      V v_t_2442 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2442);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2442);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EStr: {
      V v_t_2444 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2444);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2444);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EBytes: {
      V v_t_2446 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2446);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2446);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EFixed: {
      V v_t_2449 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2449);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2449);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EFloat32: {
      V v_t_2451 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2451);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2451);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EAbandon: {
      V v_t_2452 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2452);
        return v_x21_242;
      } else {
        heff_drop(v_t_2452);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EBool: {
      V v_t_2454 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2454);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2454);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_ESet: {
      V v_t_2458 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2458);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 3);
        heff_drop(v_t_2458);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EValues: {
      V v_t_2460 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2460);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2460);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EFix: {
      V v_t_2463 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2463);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2463);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eglobalLiteral_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eglobalLiteral(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2estripLams_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estripLams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2estripLams(V v_zs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_argv_246 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_zs_240)));
    V v_t_247 = (g_heff_2ecompile_2esimplify_2ezipL(heff_dup(v_ys_244), v_argv_246));
    V v_m_248 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s591739608x1065283968(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_x_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_244));
    V v_y_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
    V v_e_2413;
    if (heff_intLt_c(v_y_2410, v_x_249)) {
      V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_zs_240; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_zs_240); r_; });
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2411, v_ys_244));
      v_e_2413 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2412, v_b_245});
    } else {
      heff_drop(v_zs_240);
      heff_drop(v_ys_244);
      heff_drop_cell(v_ru_24e_241_24ELam, 2);
      v_e_2413 = v_b_245;
    }
    V v_t_2414 = (g_std_2emap_2esize(v_m_248));
    if (heff_intEq_c(v_t_2414, MK_INT(0LL))) {
      heff_drop(v_m_248);
      return v_e_2413;
    } else {
      return ({ V a_0 = v_m_248; V a_1 = v_e_2413; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_248); r_; });
    }
  }
  case TAG_EApp: {
    V v_e1_2415 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_2415)) {
    case TAG_EVar: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EGlobal: {
      V v_g_2418 = heff_field(v_e1_2415, 0);
      V v_ru_24e1_2415_24EGlobal = heff_take_reuse_n(v_e1_2415, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EApp: {
        V v_argv_2420 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_2421 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
        V v_t_2422 = (g_heff_2ecompile_2esimplify_2eappendL(v_argv_2420, v_t_2421));
        return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24e1_2415_24EGlobal, TAG_EGlobal, 1, (V[]){v_g_2418}), v_t_2422});
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2415, 0ULL, 3);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2415, 0ULL, 4);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2415, 0ULL, 3);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EAbandon: {
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EBool: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_ESet: {
      heff_take_n(v_e1_2415, 0ULL, 3);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EValues: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    default: return heff_nomatch(v_e1_2415);
    }
  }
  case TAG_ELet: {
    V v_x_2460 = heff_field(v_e_241, 0);
    V v_a_2461 = heff_field(v_e_241, 1);
    V v_b_2462 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2463 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2460, v_a_2461, heff_hole()});
    V v_u_2464 = (g_heff_2ecompile_2esimplify_2estripLams_24dps(v_zs_240, v_b_2462, heff_dup(v_cell_2463)));
    heff_drop(v_u_2464);
    return v_cell_2463;
  }
  case TAG_ERecord: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EProj: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ETag: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EMatch: {
    V v_sc_2474 = heff_field(v_e_241, 0);
    V v_arms_2475 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_go_2476 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2estripLams_clo), 1, (V[]){v_zs_240}));
    V v_t_2482 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2estripLams_lam0, 1, 1, (V[]){v_go_2476}), v_arms_2475));
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_sc_2474, v_t_2482});
  }
  case TAG_EPrim: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EPrimCall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ECall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EInt: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EStr: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EBytes: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFixed: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EBool: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ESet: {
    V v_xs_2496 = heff_field(v_e_241, 0);
    V v_a_2497 = heff_field(v_e_241, 1);
    V v_b_2498 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2499 = heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2496, v_a_2497, heff_hole()});
    V v_u_24100 = (g_heff_2ecompile_2esimplify_2estripLams_24dps(v_zs_240, v_b_2498, heff_dup(v_cell_2499)));
    heff_drop(v_u_24100);
    return v_cell_2499;
  }
  case TAG_EValues: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFix: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2estripLams(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2estripLams_lam0(V self, V *args) {
  V v_x2_2477 = args[0];
  V v_go_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2477)) {
  case TAG_MkArm: {
    V v_t_2478 = heff_field(v_x2_2477, 0);
    V v_vs_2479 = heff_field(v_x2_2477, 1);
    V v_b_2480 = heff_field(v_x2_2477, 2);
    V v_ru_24x2_2477_24MkArm = heff_take_reuse_n(v_x2_2477, 7ULL, 3);
    V v_t_2481 = heff_tr(heff_call(v_go_2476, 1, (V[]){v_b_2480}));
    return heff_tag_at_n(v_ru_24x2_2477_24MkArm, TAG_MkArm, 3, (V[]){v_t_2478, v_vs_2479, v_t_2481});
  }
  default: return heff_nomatch(v_x2_2477);
  }
}
Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(V v_s_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_s_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x2_241, 0);
    V v_argv_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_list_2eany_24s1742233102x56855645(heff_dup(v_s_240), v_argv_244));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_s_240;
      V t_1 = v_argv_244;
      V t_2 = v_cell_246;
      v_s_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_s_240);
      heff_drop(v_a_243);
      heff_drop(v_argv_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2epushable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epushable_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2epushable(V v_a_240) {
top: ;
  V v_t_2440;
  switch (heff_tag_of(v_a_240)) {
  case TAG_EVar: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EGlobal: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_ELam: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EStr: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EBytes: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EFixed: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat32: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EAbandon: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
    heff_drop(v_a_240);
    heff_drop(v_t_2440);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2440);
    V v_t_2441 = (g_heff_2ecompile_2eir_2eisValue(v_a_240));
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop(v_t_2441);
      V v_t_2442 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_a_240)));
      if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
        heff_drop(v_a_240);
        heff_drop(v_t_2442);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2442);
        HEFF_LAST return g_heff_2ecompile_2esimplify_2ehandlerLike(v_a_240);
      }
    } else {
      heff_drop(v_a_240);
      heff_drop(v_t_2441);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epushable(a[0]);
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam42(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam43(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam44(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam45(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam46(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam47(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam48(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam49(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam50(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam51(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam52(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam53(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam54(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam56(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam57(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam55(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam58(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam59(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam60(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam61(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam62(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam63(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam64(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam65(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam66(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam67(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam68(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam69(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam70(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam71(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyToF_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eapplyToF(V v_r_240, V v_f_241, V v_argv_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
  if (heff_intEq_c(v_t_243, MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_argv_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam0, 1, 1, (V[]){v_f_241});
  } else {
    switch (heff_tag_of(v_f_241)) {
    case TAG_EVar: {
      heff_drop_rec(v_r_240, 4);
      V v_x_246 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam1, 1, 1, (V[]){v_x_246});
    }
    case TAG_EGlobal: {
      V v_g_248 = heff_dup(heff_field(v_f_241, 0));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam2, 1, 4, (V[]){v_argv_242, v_g_248, v_r_240, v_f_241});
    }
    case TAG_ELam: {
      V v_xs_2425 = heff_field(v_f_241, 0);
      V v_it2_2426 = heff_field(v_f_241, 1);
      V v_ru_24f_241_24ELam = heff_take_reuse_n(v_f_241, 3ULL, 2);
      switch (heff_tag_of(v_it2_2426)) {
      case TAG_EVar: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EGlobal: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_ELam: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EApp: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_ELet: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_ERecord: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EProj: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_ETag: {
        V v_t_2442 = heff_field(v_it2_2426, 0);
        V v_es_2443 = heff_field(v_it2_2426, 1);
        V v_ts_2444 = heff_field(v_it2_2426, 2);
        V v_ru_24it2_2426_24ETag = heff_take_reuse_n(v_it2_2426, 7ULL, 3);
        V v_t_2445 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2425));
        V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
        if (heff_intEq_c(v_t_2445, v_t_2446)) {
          V v_t_2447 = (g_heff_2ecompile_2esimplify_2evarsAre(v_xs_2425, v_es_2443));
          if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
            heff_drop_rec(v_r_240, 4);
            heff_drop(v_xs_2425);
            heff_drop_cell(v_ru_24f_241_24ELam, 2);
            heff_drop(v_es_2443);
            heff_drop_cell(v_ru_24it2_2426_24ETag, 3);
            heff_drop(v_t_2447);
            return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam5, 1, 3, (V[]){v_t_2442, v_argv_242, v_ts_2444});
          } else {
            heff_drop(v_t_2447);
            return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, heff_tag_at_n(v_ru_24it2_2426_24ETag, TAG_ETag, 3, (V[]){v_t_2442, v_es_2443, v_ts_2444}), v_argv_242));
          }
        } else {
          return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, heff_tag_at_n(v_ru_24it2_2426_24ETag, TAG_ETag, 3, (V[]){v_t_2442, v_es_2443, v_ts_2444}), v_argv_242));
        }
      }
      case TAG_EMatch: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EPrim: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EPrimCall: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_ECall: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EInt: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EFloat: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EStr: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EBytes: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EFixed: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EFloat32: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EAbandon: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EBool: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_ESet: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EValues: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      case TAG_EFix: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(v_ru_24f_241_24ELam, v_r_240, v_xs_2425, v_it2_2426, v_argv_242));
      }
      default: return heff_nomatch(v_it2_2426);
      }
    }
    case TAG_EApp: {
      V v_g_2470 = heff_field(v_f_241, 0);
      V v_bs_2471 = heff_field(v_f_241, 1);
      V v_ru_24f_241_24EApp = heff_take_reuse_n(v_f_241, 3ULL, 2);
      V v_t_2472 = (g_heff_2ecompile_2esimplify_2eappendL_24tok2(v_ru_24f_241_24EApp, v_bs_2471, v_argv_242));
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_g_2470, v_t_2472});
    }
    case TAG_ELet: {
      V v_x_2473 = heff_field(v_f_241, 0);
      V v_a_2474 = heff_field(v_f_241, 1);
      V v_b_2475 = heff_field(v_f_241, 2);
      heff_take_n(v_f_241, 7ULL, 3);
      V v_m_2476 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2475, v_argv_242}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam6, 1, 3, (V[]){v_m_2476, v_x_2473, v_a_2474});
    }
    case TAG_ERecord: {
      heff_drop_rec(v_r_240, 4);
      V v_x_2483 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam7, 1, 1, (V[]){v_x_2483});
    }
    case TAG_EProj: {
      V v_it1_2485 = heff_dup(heff_field(v_f_241, 0));
      V v_l_2486 = heff_dup(heff_field(v_f_241, 1));
      V v_sh_2487 = heff_dup(heff_field(v_f_241, 2));
      V v_t_2488 = heff_dup(heff_field(v_f_241, 3));
      switch (heff_tag_of(v_it1_2485)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2485, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_2490 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam8, 1, 1, (V[]){v_x_2490});
      }
      case TAG_EGlobal: {
        V v_g_2492 = heff_field(v_it1_2485, 0);
        heff_take_n(v_it1_2485, 1ULL, 1);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam9, 1, 7, (V[]){v_g_2492, v_l_2486, v_f_241, v_argv_242, v_r_240, v_sh_2487, v_t_2488});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_2485, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24123 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam11, 1, 1, (V[]){v_x_24123});
      }
      case TAG_EApp: {
        V v_it11_24125 = heff_field(v_it1_2485, 0);
        V v_bs_24126 = heff_field(v_it1_2485, 1);
        heff_take_n(v_it1_2485, 3ULL, 2);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        switch (heff_tag_of(v_it11_24125)) {
        case TAG_EVar: {
          heff_take_n(v_it11_24125, 0ULL, 1);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24128 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam12, 1, 1, (V[]){v_x_24128});
        }
        case TAG_EGlobal: {
          V v_g_24130 = heff_field(v_it11_24125, 0);
          heff_take_n(v_it11_24125, 1ULL, 1);
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam13, 1, 6, (V[]){v_g_24130, v_bs_24126, v_argv_242, v_f_241, v_r_240, v_l_2486});
        }
        case TAG_ELam: {
          heff_take_n(v_it11_24125, 0ULL, 2);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24143 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam14, 1, 1, (V[]){v_x_24143});
        }
        case TAG_EApp: {
          heff_take_n(v_it11_24125, 0ULL, 2);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24147 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam15, 1, 1, (V[]){v_x_24147});
        }
        case TAG_ELet: {
          heff_take_n(v_it11_24125, 0ULL, 3);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24152 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam16, 1, 1, (V[]){v_x_24152});
        }
        case TAG_ERecord: {
          heff_take_n(v_it11_24125, 0ULL, 2);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24156 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam17, 1, 1, (V[]){v_x_24156});
        }
        case TAG_EProj: {
          heff_take_n(v_it11_24125, 0ULL, 4);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24162 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam18, 1, 1, (V[]){v_x_24162});
        }
        case TAG_ETag: {
          heff_take_n(v_it11_24125, 0ULL, 3);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24167 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam19, 1, 1, (V[]){v_x_24167});
        }
        case TAG_EMatch: {
          heff_take_n(v_it11_24125, 0ULL, 2);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24171 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam20, 1, 1, (V[]){v_x_24171});
        }
        case TAG_EPrim: {
          heff_take_n(v_it11_24125, 0ULL, 1);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24174 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam21, 1, 1, (V[]){v_x_24174});
        }
        case TAG_EPrimCall: {
          heff_take_n(v_it11_24125, 0ULL, 2);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24178 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam22, 1, 1, (V[]){v_x_24178});
        }
        case TAG_ECall: {
          heff_take_n(v_it11_24125, 0ULL, 2);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24182 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam23, 1, 1, (V[]){v_x_24182});
        }
        case TAG_EInt: {
          heff_take_n(v_it11_24125, 0ULL, 1);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24185 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam24, 1, 1, (V[]){v_x_24185});
        }
        case TAG_EFloat: {
          heff_take_na(v_it11_24125, 0ULL, 1);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24188 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam25, 1, 1, (V[]){v_x_24188});
        }
        case TAG_EStr: {
          heff_take_n(v_it11_24125, 0ULL, 1);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24191 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam26, 1, 1, (V[]){v_x_24191});
        }
        case TAG_EBytes: {
          heff_take_n(v_it11_24125, 0ULL, 1);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24194 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam27, 1, 1, (V[]){v_x_24194});
        }
        case TAG_EFixed: {
          heff_take_n(v_it11_24125, 0ULL, 2);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24198 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam28, 1, 1, (V[]){v_x_24198});
        }
        case TAG_EFloat32: {
          heff_take_na(v_it11_24125, 0ULL, 1);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24201 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam29, 1, 1, (V[]){v_x_24201});
        }
        case TAG_EAbandon: {
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24203 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam30, 1, 1, (V[]){v_x_24203});
        }
        case TAG_EBool: {
          heff_take_n(v_it11_24125, 0ULL, 1);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24206 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam31, 1, 1, (V[]){v_x_24206});
        }
        case TAG_ESet: {
          heff_take_n(v_it11_24125, 0ULL, 3);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24211 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam32, 1, 1, (V[]){v_x_24211});
        }
        case TAG_EValues: {
          heff_take_n(v_it11_24125, 0ULL, 1);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24214 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam33, 1, 1, (V[]){v_x_24214});
        }
        case TAG_EFix: {
          heff_take_n(v_it11_24125, 0ULL, 2);
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_l_2486);
          heff_drop(v_bs_24126);
          V v_x_24218 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam34, 1, 1, (V[]){v_x_24218});
        }
        default: return heff_nomatch(v_it11_24125);
        }
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2485, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24223 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam35, 1, 1, (V[]){v_x_24223});
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_2485, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24227 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam36, 1, 1, (V[]){v_x_24227});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2485, 0ULL, 4);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24233 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam37, 1, 1, (V[]){v_x_24233});
      }
      case TAG_ETag: {
        heff_take_n(v_it1_2485, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24238 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam38, 1, 1, (V[]){v_x_24238});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_2485, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24242 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam39, 1, 1, (V[]){v_x_24242});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2485, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24245 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam40, 1, 1, (V[]){v_x_24245});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_2485, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24249 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam41, 1, 1, (V[]){v_x_24249});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_2485, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24253 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam42, 1, 1, (V[]){v_x_24253});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2485, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24256 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam43, 1, 1, (V[]){v_x_24256});
      }
      case TAG_EFloat: {
        heff_take_na(v_it1_2485, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24259 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam44, 1, 1, (V[]){v_x_24259});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2485, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24262 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam45, 1, 1, (V[]){v_x_24262});
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_2485, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24265 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam46, 1, 1, (V[]){v_x_24265});
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_2485, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24269 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam47, 1, 1, (V[]){v_x_24269});
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_2485, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24272 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam48, 1, 1, (V[]){v_x_24272});
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24274 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam49, 1, 1, (V[]){v_x_24274});
      }
      case TAG_EBool: {
        heff_take_n(v_it1_2485, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24277 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam50, 1, 1, (V[]){v_x_24277});
      }
      case TAG_ESet: {
        heff_take_n(v_it1_2485, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24282 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam51, 1, 1, (V[]){v_x_24282});
      }
      case TAG_EValues: {
        heff_take_n(v_it1_2485, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24285 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam52, 1, 1, (V[]){v_x_24285});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_2485, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2486);
        heff_drop(v_sh_2487);
        heff_drop(v_t_2488);
        V v_x_24289 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam53, 1, 1, (V[]){v_x_24289});
      }
      default: return heff_nomatch(v_it1_2485);
      }
    }
    case TAG_ETag: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24294 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam54, 1, 1, (V[]){v_x_24294});
    }
    case TAG_EMatch: {
      V v_s_24296 = heff_field(v_f_241, 0);
      V v_arms_24297 = heff_field(v_f_241, 1);
      heff_take_n(v_f_241, 3ULL, 2);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam55, 1, 4, (V[]){v_argv_242, v_r_240, v_s_24296, v_arms_24297});
    }
    case TAG_EPrim: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24309 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam58, 1, 1, (V[]){v_x_24309});
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24313 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam59, 1, 1, (V[]){v_x_24313});
    }
    case TAG_ECall: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24317 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam60, 1, 1, (V[]){v_x_24317});
    }
    case TAG_EInt: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24320 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam61, 1, 1, (V[]){v_x_24320});
    }
    case TAG_EFloat: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24323 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam62, 1, 1, (V[]){v_x_24323});
    }
    case TAG_EStr: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24326 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam63, 1, 1, (V[]){v_x_24326});
    }
    case TAG_EBytes: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24329 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam64, 1, 1, (V[]){v_x_24329});
    }
    case TAG_EFixed: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24333 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam65, 1, 1, (V[]){v_x_24333});
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24336 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam66, 1, 1, (V[]){v_x_24336});
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24338 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam67, 1, 1, (V[]){v_x_24338});
    }
    case TAG_EBool: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24341 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam68, 1, 1, (V[]){v_x_24341});
    }
    case TAG_ESet: {
      V v_xs_24343 = heff_field(v_f_241, 0);
      V v_a_24344 = heff_field(v_f_241, 1);
      V v_b_24345 = heff_field(v_f_241, 2);
      heff_take_n(v_f_241, 7ULL, 3);
      V v_m_24346 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_24345, v_argv_242}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam69, 1, 3, (V[]){v_m_24346, v_xs_24343, v_a_24344});
    }
    case TAG_EValues: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24352 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam70, 1, 1, (V[]){v_x_24352});
    }
    case TAG_EFix: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24356 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam71, 1, 1, (V[]){v_x_24356});
    }
    default: return heff_nomatch(v_f_241);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyToF(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_f_241, v_s_244});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_s_247});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam3(V self, V *args) {
  V v_s_2413 = args[0];
  V v_argv_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_argv_242, v_s_2413});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam4(V self, V *args) {
  V v_s_2414 = args[0];
  V v_argv_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_argv_242, v_s_2414});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_argv_242 = heff_env(self)[0];
  V v_g_248 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = (g_list_2eany_24s756915015x218492736(v_argv_242));
  V v_m_2415;
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_s_249, 7)), 1, 7);
    V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = v_argv_242; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2411); r_; });
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      v_m_2415 = (g_prelude_2etraverse_24s672366786x467588702(heff_dup(v_s_249), v_argv_242));
    } else {
      heff_drop(v_t_2412);
      v_m_2415 = heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam3, 1, 1, (V[]){v_argv_242});
    }
  } else {
    heff_drop(v_t_2410);
    v_m_2415 = heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam4, 1, 1, (V[]){v_argv_242});
  }
  V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){heff_dup(v_s_249)}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_s_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_t_2419 = ({ V b_0 = heff_get_n(v_s_249, 2, 9); V a_1 = v_g_248; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(b_0, a_1)); heff_drop(b_0); r_; });
    V v_m_2420 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_f_241; V a_2 = heff_dup(v_g_248); V a_3 = heff_dup(v_x_2417); V a_4 = v_t_2419; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2ecallOf(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2419); r_; });
    V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_s_2418}));
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_s_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      V v_t_2424 = (g_heff_2ecompile_2esimplify_2estillCall(v_g_248, v_x_2422));
      if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_2416_24MkPair, 2);
        heff_drop(v_x_2422);
        heff_drop(v_t_2424);
        return (g_heff_2ecompile_2esimplify_2etrySpec(v_r_240, v_g_248, v_x_2417, v_s_2423));
      } else {
        heff_drop(v_g_248);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_x_2417);
        heff_drop(v_t_2424);
        return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){v_x_2422, v_s_2423});
      }
    }
    default: return heff_nomatch(v_x2_2421);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam5(V self, V *args) {
  V v_s_2448 = args[0];
  V v_t_2442 = heff_env(self)[0];
  V v_argv_242 = heff_env(self)[1];
  V v_ts_2444 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2442, v_argv_242, v_ts_2444}), v_s_2448});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam6(V self, V *args) {
  V v_s_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  V v_x_2473 = heff_env(self)[1];
  V v_a_2474 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_s_2477}));
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkPair: {
    V v_x_2479 = heff_field(v_x2_2478, 0);
    V v_s_2480 = heff_field(v_x2_2478, 1);
    V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2473, v_a_2474, v_x_2479}), v_s_2480});
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam7(V self, V *args) {
  V v_s_2484 = args[0];
  V v_x_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2483, v_s_2484});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam8(V self, V *args) {
  V v_s_2491 = args[0];
  V v_x_2490 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2490, v_s_2491});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam10(V self, V *args) {
  V v_s_24116 = args[0];
  V v_m_24115 = heff_env(self)[0];
  V v_argv_242 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24117 = heff_tr(heff_call(v_m_24115, 1, (V[]){v_s_24116}));
  switch (heff_tag_of(v_x2_24117)) {
  case TAG_MkPair: {
    V v_x_24118 = heff_field(v_x2_24117, 0);
    V v_s_24119 = heff_field(v_x2_24117, 1);
    heff_take_n(v_x2_24117, 3ULL, 2);
    V v_t_24120 = (g_heff_2ecompile_2esimplify_2eprunedCopy(v_x_24118, v_argv_242));
    V f_ = heff_get_n(v_r_240, 1, 4);
    heff_room[0] = v_t_24120;
    heff_room[1] = v_argv_242;
    heff_room[2] = v_s_24119;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_24117);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam9(V self, V *args) {
  V v_s_2493 = args[0];
  V v_g_2492 = heff_env(self)[0];
  V v_l_2486 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_argv_242 = heff_env(self)[3];
  V v_r_240 = heff_env(self)[4];
  V v_sh_2487 = heff_env(self)[5];
  V v_t_2488 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2494 = (g_std_2emap_2elookup_24s1930949324x2078207031(heff_rfield(v_s_2493, 2), v_g_2492));
  HeffT2 v_t_2495 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2494, v_s_2493));
  {
    V v_field_2496 = v_t_2495.f[0];
    V v_field_2497 = v_t_2495.f[1];
    V v_x_2498 = v_field_2496;
    V v_s_2499 = v_field_2497;
    switch (heff_tag_of(v_x_2498)) {
    case TAG_Nothing: {
      heff_drop(v_sh_2487);
      heff_drop(v_t_2488);
      HeffT2 v_t_24100 = ({ V a_0 = v_g_2492; V a_1 = v_l_2486; V a_2 = v_s_2499; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2eknownField_24cpr(a_0, a_1, a_2)); heff_drop(v_g_2492); heff_drop(v_l_2486); r_; });
      {
        V v_field_24101 = v_t_24100.f[0];
        V v_field_24102 = v_t_24100.f[1];
        V v_x_24103 = v_field_24101;
        V v_s_24104 = v_field_24102;
        switch (heff_tag_of(v_x_24103)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 4);
          V v_x_24105 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24105, v_s_24104});
        }
        case TAG_Just: {
          V v_v_24106 = heff_field(v_x_24103, 0);
          heff_take_n(v_x_24103, 1ULL, 1);
          V v_t_24107 = (g_list_2eany_24s415398368x1824706470(v_argv_242));
          V v_t_24108;
          if ((heff_dup(v_t_24107) == NTAG(TAG_True))) {
            heff_drop(v_t_24107);
            v_t_24108 = MK_INT(160LL);
          } else {
            heff_drop(v_t_24107);
            v_t_24108 = MK_INT(24LL);
          }
          V v_t_24109 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_argv_242)));
          V v_t_24110 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_v_24106, v_argv_242}));
          return (g_heff_2ecompile_2esimplify_2eattemptBy(v_t_24108, v_t_24109, v_t_24110, v_s_24104));
        }
        default: return heff_nomatch(v_x_24103);
        }
      }
    }
    case TAG_Just: {
      V v_b_24111 = heff_field(v_x_2498, 0);
      heff_take_n(v_x_2498, 1ULL, 1);
      heff_drop(v_g_2492);
      V v_t_24112 = (g_list_2eany_24s415398368x1824706470(v_argv_242));
      V v_t_24113;
      if ((heff_dup(v_t_24112) == NTAG(TAG_True))) {
        heff_drop(v_t_24112);
        v_t_24113 = MK_INT(160LL);
      } else {
        heff_drop(v_t_24112);
        v_t_24113 = MK_INT(24LL);
      }
      V v_t_24114 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_argv_242)));
      V v_m_24115 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 4, (V[]){v_l_2486, v_sh_2487, v_t_2488, v_b_24111}));
      return (g_heff_2ecompile_2esimplify_2eattemptBy(v_t_24113, v_t_24114, heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam10, 1, 3, (V[]){v_m_24115, v_argv_242, v_r_240}), v_s_2499));
    }
    default: return heff_nomatch(v_x_2498);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam11(V self, V *args) {
  V v_s_24124 = args[0];
  V v_x_24123 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24123, v_s_24124});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam12(V self, V *args) {
  V v_s_24129 = args[0];
  V v_x_24128 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24128, v_s_24129});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam13(V self, V *args) {
  V v_s_24131 = args[0];
  V v_g_24130 = heff_env(self)[0];
  V v_bs_24126 = heff_env(self)[1];
  V v_argv_242 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_r_240 = heff_env(self)[4];
  V v_l_2486 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24132 = heff_get_n(heff_dup(heff_rfield(v_s_24131, 7)), 0, 7);
  V v_t_24133 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){heff_dup(v_g_24130)}), heff_dup(v_bs_24126)});
  V v_t_24134 = ({ V a_0 = v_t_24132; V a_1 = v_t_24133; V r_ = (g_heff_2ecompile_2esimplify_2ebuiltBy(a_0, a_1)); heff_drop(v_t_24132); heff_drop_tag(v_t_24133, 2); r_; });
  if ((heff_dup(v_t_24134) == NTAG(TAG_True))) {
    heff_drop(v_t_24134);
    V v_t_24135 = (g_list_2eany_24s415398368x1824706470(v_argv_242));
    V v_t_24136;
    if ((heff_dup(v_t_24135) == NTAG(TAG_True))) {
      heff_drop(v_t_24135);
      v_t_24136 = MK_INT(160LL);
    } else {
      heff_drop(v_t_24135);
      v_t_24136 = MK_INT(24LL);
    }
    V v_t_24137 = (g_heff_2ecompile_2esimplify_2emkApp(heff_dup(v_f_241), heff_dup(v_argv_242)));
    V v_t_24138 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_24130}), v_bs_24126});
    V v_t_24139 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2ebuiltApplied_clo), 5, (V[]){v_r_240, v_f_241, v_l_2486, v_t_24138, v_argv_242}));
    return (g_heff_2ecompile_2esimplify_2eattemptBy(v_t_24136, v_t_24137, v_t_24139, v_s_24131));
  } else {
    heff_drop(v_g_24130);
    heff_drop(v_bs_24126);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_l_2486);
    heff_drop(v_t_24134);
    V v_x_24140 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_242));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24140, v_s_24131});
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam14(V self, V *args) {
  V v_s_24144 = args[0];
  V v_x_24143 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24143, v_s_24144});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam15(V self, V *args) {
  V v_s_24148 = args[0];
  V v_x_24147 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24147, v_s_24148});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam16(V self, V *args) {
  V v_s_24153 = args[0];
  V v_x_24152 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24152, v_s_24153});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam17(V self, V *args) {
  V v_s_24157 = args[0];
  V v_x_24156 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24156, v_s_24157});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam18(V self, V *args) {
  V v_s_24163 = args[0];
  V v_x_24162 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24162, v_s_24163});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam19(V self, V *args) {
  V v_s_24168 = args[0];
  V v_x_24167 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24167, v_s_24168});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam20(V self, V *args) {
  V v_s_24172 = args[0];
  V v_x_24171 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24171, v_s_24172});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam21(V self, V *args) {
  V v_s_24175 = args[0];
  V v_x_24174 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24174, v_s_24175});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam22(V self, V *args) {
  V v_s_24179 = args[0];
  V v_x_24178 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24178, v_s_24179});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam23(V self, V *args) {
  V v_s_24183 = args[0];
  V v_x_24182 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24182, v_s_24183});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam24(V self, V *args) {
  V v_s_24186 = args[0];
  V v_x_24185 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24185, v_s_24186});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam25(V self, V *args) {
  V v_s_24189 = args[0];
  V v_x_24188 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24188, v_s_24189});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam26(V self, V *args) {
  V v_s_24192 = args[0];
  V v_x_24191 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24191, v_s_24192});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam27(V self, V *args) {
  V v_s_24195 = args[0];
  V v_x_24194 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24194, v_s_24195});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam28(V self, V *args) {
  V v_s_24199 = args[0];
  V v_x_24198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24198, v_s_24199});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam29(V self, V *args) {
  V v_s_24202 = args[0];
  V v_x_24201 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24201, v_s_24202});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam30(V self, V *args) {
  V v_s_24204 = args[0];
  V v_x_24203 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24203, v_s_24204});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam31(V self, V *args) {
  V v_s_24207 = args[0];
  V v_x_24206 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24206, v_s_24207});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam32(V self, V *args) {
  V v_s_24212 = args[0];
  V v_x_24211 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24211, v_s_24212});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam33(V self, V *args) {
  V v_s_24215 = args[0];
  V v_x_24214 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24214, v_s_24215});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam34(V self, V *args) {
  V v_s_24219 = args[0];
  V v_x_24218 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24218, v_s_24219});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam35(V self, V *args) {
  V v_s_24224 = args[0];
  V v_x_24223 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24223, v_s_24224});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam36(V self, V *args) {
  V v_s_24228 = args[0];
  V v_x_24227 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24227, v_s_24228});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam37(V self, V *args) {
  V v_s_24234 = args[0];
  V v_x_24233 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24233, v_s_24234});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam38(V self, V *args) {
  V v_s_24239 = args[0];
  V v_x_24238 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24238, v_s_24239});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam39(V self, V *args) {
  V v_s_24243 = args[0];
  V v_x_24242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24242, v_s_24243});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam40(V self, V *args) {
  V v_s_24246 = args[0];
  V v_x_24245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24245, v_s_24246});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam41(V self, V *args) {
  V v_s_24250 = args[0];
  V v_x_24249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24249, v_s_24250});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam42(V self, V *args) {
  V v_s_24254 = args[0];
  V v_x_24253 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24253, v_s_24254});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam43(V self, V *args) {
  V v_s_24257 = args[0];
  V v_x_24256 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24256, v_s_24257});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam44(V self, V *args) {
  V v_s_24260 = args[0];
  V v_x_24259 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24259, v_s_24260});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam45(V self, V *args) {
  V v_s_24263 = args[0];
  V v_x_24262 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24262, v_s_24263});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam46(V self, V *args) {
  V v_s_24266 = args[0];
  V v_x_24265 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24265, v_s_24266});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam47(V self, V *args) {
  V v_s_24270 = args[0];
  V v_x_24269 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24269, v_s_24270});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam48(V self, V *args) {
  V v_s_24273 = args[0];
  V v_x_24272 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24272, v_s_24273});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam49(V self, V *args) {
  V v_s_24275 = args[0];
  V v_x_24274 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24274, v_s_24275});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam50(V self, V *args) {
  V v_s_24278 = args[0];
  V v_x_24277 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24277, v_s_24278});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam51(V self, V *args) {
  V v_s_24283 = args[0];
  V v_x_24282 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24282, v_s_24283});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam52(V self, V *args) {
  V v_s_24286 = args[0];
  V v_x_24285 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24285, v_s_24286});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam53(V self, V *args) {
  V v_s_24290 = args[0];
  V v_x_24289 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24289, v_s_24290});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam54(V self, V *args) {
  V v_s_24295 = args[0];
  V v_x_24294 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24294, v_s_24295});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam56(V self, V *args) {
  V v_s_24302 = args[0];
  V v_argv_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_argv_242, v_s_24302});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam57(V self, V *args) {
  V v_s_24303 = args[0];
  V v_argv_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_argv_242, v_s_24303});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam55(V self, V *args) {
  V v_s_24298 = args[0];
  V v_argv_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_s_24296 = heff_env(self)[2];
  V v_arms_24297 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24299 = (g_list_2eany_24s756915015x218492736(v_argv_242));
  V v_m_24304;
  if ((heff_dup(v_t_24299) == NTAG(TAG_True))) {
    heff_drop(v_t_24299);
    V v_t_24300 = heff_get_n(heff_dup(heff_rfield(v_s_24298, 7)), 1, 7);
    V v_t_24301 = ({ V a_0 = v_t_24300; V a_1 = v_argv_242; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_24300); r_; });
    if ((heff_dup(v_t_24301) == NTAG(TAG_True))) {
      heff_drop(v_t_24301);
      v_m_24304 = (g_prelude_2etraverse_24s672366786x467588702(heff_dup(v_s_24298), v_argv_242));
    } else {
      heff_drop(v_t_24301);
      v_m_24304 = heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam56, 1, 1, (V[]){v_argv_242});
    }
  } else {
    heff_drop(v_t_24299);
    v_m_24304 = heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam57, 1, 1, (V[]){v_argv_242});
  }
  V v_x2_24305 = heff_tr(heff_call(v_m_24304, 1, (V[]){v_s_24298}));
  switch (heff_tag_of(v_x2_24305)) {
  case TAG_MkPair: {
    V v_x_24306 = heff_field(v_x2_24305, 0);
    V v_s_24307 = heff_field(v_x2_24305, 1);
    V v_ru_24x2_24305_24MkPair = heff_take_reuse_n(v_x2_24305, 3ULL, 2);
    return (g_heff_2ecompile_2esimplify_2ematchApplied_24tok2(v_ru_24x2_24305_24MkPair, v_r_240, v_s_24296, v_arms_24297, v_x_24306, v_s_24307));
  }
  default: return heff_nomatch(v_x2_24305);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam58(V self, V *args) {
  V v_s_24310 = args[0];
  V v_x_24309 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24309, v_s_24310});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam59(V self, V *args) {
  V v_s_24314 = args[0];
  V v_x_24313 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24313, v_s_24314});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam60(V self, V *args) {
  V v_s_24318 = args[0];
  V v_x_24317 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24317, v_s_24318});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam61(V self, V *args) {
  V v_s_24321 = args[0];
  V v_x_24320 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24320, v_s_24321});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam62(V self, V *args) {
  V v_s_24324 = args[0];
  V v_x_24323 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24323, v_s_24324});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam63(V self, V *args) {
  V v_s_24327 = args[0];
  V v_x_24326 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24326, v_s_24327});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam64(V self, V *args) {
  V v_s_24330 = args[0];
  V v_x_24329 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24329, v_s_24330});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam65(V self, V *args) {
  V v_s_24334 = args[0];
  V v_x_24333 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24333, v_s_24334});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam66(V self, V *args) {
  V v_s_24337 = args[0];
  V v_x_24336 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24336, v_s_24337});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam67(V self, V *args) {
  V v_s_24339 = args[0];
  V v_x_24338 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24338, v_s_24339});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam68(V self, V *args) {
  V v_s_24342 = args[0];
  V v_x_24341 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24341, v_s_24342});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam69(V self, V *args) {
  V v_s_24347 = args[0];
  V v_m_24346 = heff_env(self)[0];
  V v_xs_24343 = heff_env(self)[1];
  V v_a_24344 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24348 = heff_tr(heff_call(v_m_24346, 1, (V[]){v_s_24347}));
  switch (heff_tag_of(v_x2_24348)) {
  case TAG_MkPair: {
    V v_x_24349 = heff_field(v_x2_24348, 0);
    V v_s_24350 = heff_field(v_x2_24348, 1);
    V v_ru_24x2_24348_24MkPair = heff_take_reuse_n(v_x2_24348, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24348_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24343, v_a_24344, v_x_24349}), v_s_24350});
  }
  default: return heff_nomatch(v_x2_24348);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam70(V self, V *args) {
  V v_s_24353 = args[0];
  V v_x_24352 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24352, v_s_24353});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam71(V self, V *args) {
  V v_s_24357 = args[0];
  V v_x_24356 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24356, v_s_24357});
}
Clo g_heff_2ecompile_2esimplify_2egrewIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2egrewIn_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2egrewIn(V v_s0_240, V v_s1_241, V v_b_242) {
top: ;
  V v_supply_243 = heff_take_field(v_s1_241, 0);
  V v_sp_244 = heff_get_n(v_s1_241, 7, 9);
  V v_supply_245 = heff_take_field(v_s0_240, 0);
  V v_sp_246 = heff_get_n(v_s0_240, 7, 9);
  if (!heff_intEq_c_lent(v_supply_243, v_supply_245, 0)) {
    heff_drop(v_supply_243);
    heff_drop(v_supply_245);
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_242)));
    V v_hs_248 = (g_heff_2ecompile_2eir_2enubI(v_t_247));
    V v_t_249 = ({ V b_0 = heff_get_n(v_sp_246, 0, 7); V a_1 = v_hs_248; V r_ = (g_list_2emap_24s1492759219x1917596721(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2410 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_242));
    V v_hs_2411 = (g_heff_2ecompile_2eir_2enubI(v_t_2410));
    V v_t_2412 = ({ V b_0 = heff_get_n(v_sp_244, 0, 7); V a_1 = v_hs_2411; V r_ = (g_list_2emap_24s1492759219x1917596721(b_0, a_1)); heff_drop(b_0); r_; });
    return ({ V a_0 = v_t_249; V a_1 = v_t_2412; V r_ = (g_heff_2ecompile_2esimplify_2egrew(a_0, a_1)); heff_drop(v_t_249); heff_drop(v_t_2412); r_; });
  } else {
    heff_drop(v_b_242);
    heff_drop(v_supply_243);
    heff_drop_rec(v_sp_244, 7);
    heff_drop(v_supply_245);
    heff_drop_rec(v_sp_246, 7);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2esimplify_2egrewIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2egrewIn(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ebuilds_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebuilds_24tok2_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ebuilds_24tok2(V v_tok_240, V v_g_241, V v_n_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_n_242);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_EVar: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_x31_244, 0);
      V v_x312_248 = heff_field(v_x31_244, 1);
      switch (heff_tag_of(v_x312_248)) {
      case TAG_EVar: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        V v_fs_2418 = heff_field(v_x312_248, 0);
        V v_ts_2419 = heff_field(v_x312_248, 1);
        V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_247));
        if (heff_intEq_c(v_t_2420, v_n_242)) {
          switch (heff_tag_of(v_fs_2418)) {
          case TAG_Nil: {
            heff_drop_cell(v_tok_240, 2);
            return NTAG(TAG_False);
          }
          case TAG_Cons: {
            V v_t_2423 = (g_list_2emap_24s549405518x243689326(heff_dup(v_fs_2418)));
            V v_t_2424 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2423); r_; });
            if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
              heff_drop(v_t_2424);
              V v_t_2425 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_tag_at_n(v_tok_240, TAG_ERecord, 2, (V[]){heff_dup(v_fs_2418), heff_dup(v_ts_2419)})));
              V v_t_2426 = (g_heff_2ecompile_2eir_2enubI(v_t_2425));
              V v_x1_2427 = ({ V a_0 = v_g_241; V a_1 = v_t_2426; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2426); r_; });
              V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2427) == NTAG(TAG_True)));
              heff_drop(v_x1_2427);
              return v_ret_24bool;
            } else {
              heff_drop_cell(v_tok_240, 2);
              heff_drop(v_t_2424);
              return NTAG(TAG_False);
            }
          }
          default: return heff_nomatch(v_fs_2418);
          }
        } else {
          heff_drop_cell(v_tok_240, 2);
          return NTAG(TAG_False);
        }
      }
      case TAG_EProj: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_242);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x312_248);
      }
    }
    case TAG_EApp: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2esimplify_2ebuilds_24tok2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2esimplify_2ebuilds_24tok2(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}