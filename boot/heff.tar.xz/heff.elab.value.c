// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_F32 16337
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IntoCons 46138
#define TAG_LChunkSnoc 25233
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotApplicable 40298
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_keys 9783995
#define LBL_sol 323594
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522(V, V);
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2edecodeN(V);
V g_heff_2eelab_2evalue_2edecodeN_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeN_clo;
V g_heff_2eelab_2evalue_2edefaultsOf(V);
V g_heff_2eelab_2evalue_2edefaultsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edefaultsOf_clo;
V g_heff_2eelab_2evalue_2eemap_24s196957333x715530534(V);
V g_heff_2eelab_2evalue_2eemap_24s196957333x715530534_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s196957333x715530534_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_clo;
V g_heff_2eelab_2evalue_2eimplicitDefault(V);
V g_heff_2eelab_2evalue_2eimplicitDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eimplicitDefault_clo;
V g_heff_2eelab_2evalue_2eisError(V);
V g_heff_2eelab_2evalue_2eisError_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisError_clo;
V g_heff_2eelab_2evalue_2eisFixed(V, V);
V g_heff_2eelab_2evalue_2eisFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisFixed_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2elocalsAt(V, V);
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elocalsAt_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eneuAppTy(V, V, V);
V g_heff_2eelab_2evalue_2eneuAppTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eneuAppTy_clo;
V g_heff_2eelab_2evalue_2eproj(V, V);
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eproj_clo;
V g_heff_2eelab_2evalue_2eprojAt(V, V, V);
V g_heff_2eelab_2evalue_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojAt_clo;
V g_heff_2eelab_2evalue_2eprojTyWith(V, V, V);
V g_heff_2eelab_2evalue_2eprojTyWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojTyWith_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_heff_2eelab_2evalue_2especialize(V, V, V);
V g_heff_2eelab_2evalue_2especialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_clo;
V g_heff_2eelab_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_clo;
V g_heff_2eutil_2edict_2eempty_get(void);
V g_heff_2eutil_2edict_2eupdate(V, V, V);
V g_heff_2eutil_2edict_2eupdate_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eupdate_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
Clo g_heff_2eelab_2evalue_2elocalsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2elocalsAt_entry, 2, 0};

V g_heff_2eelab_2evalue_2elocalsAt(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_LNil: {
    heff_drop(v_i_241);
    return heff_abandon();
  }
  case TAG_LSnoc: {
    V v_e_242 = heff_field(v_x1_240, 0);
    V v_v_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tail(heff_dup(v_v_243), 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      V t_0 = v_e_242;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
  case TAG_LChunkSnoc: {
    V v_e_245 = heff_field(v_x1_240, 0);
    V v_vs_246 = heff_field(v_x1_240, 1);
    V v_t_247 = heff_intSub(heff_arrayLength_lent(v_vs_246, 0), heff_dup(v_i_241));
    V v_i_248 = heff_intSub(v_t_247, MK_INT(1LL));
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_248))) {
      if (heff_intLt_c(heff_dup(v_i_248), heff_arrayLength_lent(v_vs_246, 0))) {
        heff_drop(v_i_241);
        V v_v_2411 = heff_arrayIndex_lent(v_vs_246, v_i_248, 2);
        return v_v_2411;
      } else {
        heff_drop(v_i_248);
        V v_t_2412 = heff_intSub(v_i_241, heff_arrayLength_lent(v_vs_246, 0));
        V t_0 = v_e_245;
        V t_1 = v_t_2412;
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    } else {
      heff_drop(v_i_248);
      V v_t_2413 = heff_intSub(v_i_241, heff_arrayLength_lent(v_vs_246, 0));
      V t_0 = v_e_245;
      V t_1 = v_t_2413;
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2elocalsAt(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2evalue_2ebehavior_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ebehavior_entry, 1, 0};

V g_heff_2eelab_2evalue_2ebehavior(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VU: {
    V v_u_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VU = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24VU, TAG_LikeU, 1, (V[]){v_u_241});
  }
  case TAG_VDecode: {
    V v_described_245 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 5);
    V v_t_247 = heff_tr(heff_call(v_described_245, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      return NTAG(TAG_NoRules);
    }
    case TAG_Just: {
      V v_t_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V t_0 = v_t_248;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_VFunction: {
    V v_level_249 = heff_field(v_x1_240, 0);
    V v_dom_2410 = heff_field(v_x1_240, 1);
    V v_cod_2411 = heff_field(v_x1_240, 2);
    V v_implicit_2412 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 5);
    return heff_tag_n(TAG_LikeFunction, 4, (V[]){v_level_249, v_dom_2410, v_cod_2411, v_implicit_2412});
  }
  case TAG_VRecord: {
    V v_level_2414 = heff_field(v_x1_240, 0);
    V v_capture_2415 = heff_field(v_x1_240, 1);
    V v_fieldTypes_2416 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 4);
    return heff_tag_n(TAG_LikeRecord, 3, (V[]){v_level_2414, v_capture_2415, v_fieldTypes_2416});
  }
  case TAG_VSum: {
    V v_st_2418 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VSum = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24VSum, TAG_LikeSum, 1, (V[]){v_st_2418});
  }
  case TAG_VPrimInt: {
    return NTAG(TAG_LikeInt);
  }
  case TAG_VPrimFloat: {
    return NTAG(TAG_LikeFloat);
  }
  case TAG_VPrimString: {
    return NTAG(TAG_LikeString);
  }
  case TAG_VPrimRune: {
    return NTAG(TAG_LikeRune);
  }
  case TAG_VPrimArray: {
    V v_a_2419 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VPrimArray = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24VPrimArray, TAG_LikeArray, 1, (V[]){v_a_2419});
  }
  case TAG_VFixed: {
    V v_w_2420 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VFixed = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24VFixed, TAG_LikeFixed, 1, (V[]){v_w_2420});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2ebehavior(a[0]);
}
Clo g_heff_2eelab_2evalue_2elevelOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2elevelOf_entry, 1, 0};

V g_heff_2eelab_2evalue_2elevelOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VU: {
    V v_u_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_u_241)) {
    case TAG_SmallU: {
      return NTAG(TAG_Large);
    }
    case TAG_LargeU: {
      return NTAG(TAG_TopL);
    }
    default: return heff_nomatch(v_u_241);
    }
  }
  case TAG_VDecode: {
    V v_u_244 = heff_field(v_x1_240, 2);
    switch (heff_tag_of(v_u_244)) {
    case TAG_SmallU: {
      return NTAG(TAG_Small);
    }
    case TAG_LargeU: {
      return NTAG(TAG_Large);
    }
    default: return heff_nomatch(v_u_244);
    }
  }
  case TAG_VFunction: {
    V v_level_247 = heff_field(v_x1_240, 0);
    return heff_dup(v_level_247);
  }
  case TAG_VRecord: {
    V v_level_2412 = heff_field(v_x1_240, 0);
    return heff_dup(v_level_2412);
  }
  case TAG_VSum: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimInt: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimFloat: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimString: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimRune: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimArray: {
    V v_a_2417 = heff_field(v_x1_240, 0);
    V t_0 = v_a_2417;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_VFixed: {
    return NTAG(TAG_Small);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2elevelOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str0, 4, "Int8");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str1, 5, "Int16");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str2, 5, "Int32");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str3, 5, "Int64");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str4, 5, "UInt8");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str5, 6, "UInt16");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str6, 6, "UInt32");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str7, 6, "UInt64");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str8, 7, "Float32");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str9, 4, "Int8");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str10, 5, "Int16");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str11, 5, "Int32");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str12, 5, "Int64");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str13, 5, "UInt8");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str14, 6, "UInt16");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str15, 6, "UInt32");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str16, 6, "UInt64");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str17, 7, "Float32");
Clo g_heff_2eelab_2evalue_2eisFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eisFixed_entry, 2, 0};

V g_heff_2eelab_2evalue_2eisFixed(V v_w_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_VU: {
    return NTAG(TAG_False);
  }
  case TAG_VDecode: {
    return NTAG(TAG_False);
  }
  case TAG_VFunction: {
    return NTAG(TAG_False);
  }
  case TAG_VRecord: {
    return NTAG(TAG_False);
  }
  case TAG_VSum: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimInt: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimFloat: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimString: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimRune: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimArray: {
    return NTAG(TAG_False);
  }
  case TAG_VFixed: {
    V v_w_27_2419 = heff_field(v_x2_241, 0);
    V v_t_2420;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2420 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str0);
      break;
    }
    case TAG_I16: {
      v_t_2420 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str1);
      break;
    }
    case TAG_I32: {
      v_t_2420 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str2);
      break;
    }
    case TAG_I64: {
      v_t_2420 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str3);
      break;
    }
    case TAG_U8: {
      v_t_2420 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str4);
      break;
    }
    case TAG_U16: {
      v_t_2420 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str5);
      break;
    }
    case TAG_U32: {
      v_t_2420 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str6);
      break;
    }
    case TAG_U64: {
      v_t_2420 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str7);
      break;
    }
    case TAG_F32: {
      v_t_2420 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str8);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2421;
    switch (heff_tag_of(v_w_27_2419)) {
    case TAG_I8: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str9);
      break;
    }
    case TAG_I16: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str10);
      break;
    }
    case TAG_I32: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str11);
      break;
    }
    case TAG_I64: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str12);
      break;
    }
    case TAG_U8: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str13);
      break;
    }
    case TAG_U16: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str14);
      break;
    }
    case TAG_U32: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str15);
      break;
    }
    case TAG_U64: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str16);
      break;
    }
    case TAG_F32: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str17);
      break;
    }
    default: heff_nomatch(v_w_27_2419);
    }
    return heff_strEq(v_t_2420, v_t_2421);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2evalue_2eisFixed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2evalue_2eisFixed(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_lam0(V self, V *args);
Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry, 1, 0};

V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V v_v_240) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VNeu: {
    V v_expansion_244 = heff_field(v_v_240, 3);
    heff_take_n(v_v_240, 8ULL, 5);
    V v_t_246 = heff_tr(heff_call(v_expansion_244, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_t_246)) {
    case TAG_IntoCons: {
      V v_fields_247 = heff_field(v_t_246, 0);
      V v_ru_24t_246_24IntoCons = heff_take_reuse_n(v_t_246, 1ULL, 1);
      V v_xs_248 = heff_take_field(v_fields_247, 2);
      V v_t_2411 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_248, 0), heff_clo_n(g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_lam0, 1, 1, (V[]){v_xs_248}));
      V v_t_2412 = ({ V rv_2 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_fields_247, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return heff_tag_at_n(v_ru_24t_246_24IntoCons, TAG_Just, 1, (V[]){v_t_2412});
    }
    case TAG_NotApplicable: {
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_VCode: {
    heff_take_n(v_v_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_VLam: {
    heff_take_n(v_v_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_VCons: {
    V v_fields_2416 = heff_field(v_v_240, 0);
    V v_ru_24v_240_24VCons = heff_take_reuse_n(v_v_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24v_240_24VCons, TAG_Just, 1, (V[]){v_fields_2416});
  }
  case TAG_VOpaque: {
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a[0]);
}
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_lam0(V self, V *args) {
  V v_i_249 = args[0];
  V v_xs_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_arrayIndex(v_xs_248, v_i_249);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2410});
}
Clo g_heff_2eelab_2evalue_2eproj_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eproj_entry, 2, 0};

V g_heff_2eelab_2evalue_2eproj(V v_v_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VNeu: {
    V v_t_247 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_240));
    V v_d_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_d_249 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_fields_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_d_249 = v_fields_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = (g_map_2elookup_24s1546226666x2146984184(v_x_241, heff_rfield(v_d_249, 1)));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_d_249, 3);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_i_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      V v_xs_2412 = heff_get_n(v_d_249, 2, 3);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2411))) {
        if (heff_intLt_c(heff_dup(v_i_2411), heff_arrayLength_lent(v_xs_2412, 0))) {
          V v_v_2415 = heff_arrayIndex(v_xs_2412, v_i_2411);
          return v_v_2415;
        } else {
          heff_drop(v_i_2411);
          heff_drop(v_xs_2412);
          return heff_abandon();
        }
      } else {
        heff_drop(v_i_2411);
        heff_drop(v_xs_2412);
        return heff_abandon();
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  case TAG_VCode: {
    V v_t_2417 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_240));
    V v_d_2419;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nothing: {
      v_d_2419 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_fields_2418 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      v_d_2419 = v_fields_2418;
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2420 = (g_map_2elookup_24s1546226666x2146984184(v_x_241, heff_rfield(v_d_2419, 1)));
    switch (heff_tag_of(v_t_2420)) {
    case TAG_Nothing: {
      heff_drop_rec(v_d_2419, 3);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_i_2421 = heff_field(v_t_2420, 0);
      heff_take_n(v_t_2420, 1ULL, 1);
      V v_xs_2422 = heff_get_n(v_d_2419, 2, 3);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2421))) {
        if (heff_intLt_c(heff_dup(v_i_2421), heff_arrayLength_lent(v_xs_2422, 0))) {
          V v_v_2425 = heff_arrayIndex(v_xs_2422, v_i_2421);
          return v_v_2425;
        } else {
          heff_drop(v_i_2421);
          heff_drop(v_xs_2422);
          return heff_abandon();
        }
      } else {
        heff_drop(v_i_2421);
        heff_drop(v_xs_2422);
        return heff_abandon();
      }
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  case TAG_VLam: {
    V v_t_2428 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_240));
    V v_d_2430;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Nothing: {
      v_d_2430 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_fields_2429 = heff_field(v_t_2428, 0);
      heff_take_n(v_t_2428, 1ULL, 1);
      v_d_2430 = v_fields_2429;
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    V v_t_2431 = (g_map_2elookup_24s1546226666x2146984184(v_x_241, heff_rfield(v_d_2430, 1)));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_Nothing: {
      heff_drop_rec(v_d_2430, 3);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_i_2432 = heff_field(v_t_2431, 0);
      heff_take_n(v_t_2431, 1ULL, 1);
      V v_xs_2433 = heff_get_n(v_d_2430, 2, 3);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2432))) {
        if (heff_intLt_c(heff_dup(v_i_2432), heff_arrayLength_lent(v_xs_2433, 0))) {
          V v_v_2436 = heff_arrayIndex(v_xs_2433, v_i_2432);
          return v_v_2436;
        } else {
          heff_drop(v_i_2432);
          heff_drop(v_xs_2433);
          return heff_abandon();
        }
      } else {
        heff_drop(v_i_2432);
        heff_drop(v_xs_2433);
        return heff_abandon();
      }
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  case TAG_VCons: {
    V v_t_2438 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_240));
    V v_d_2440;
    switch (heff_tag_of(v_t_2438)) {
    case TAG_Nothing: {
      v_d_2440 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_fields_2439 = heff_field(v_t_2438, 0);
      heff_take_n(v_t_2438, 1ULL, 1);
      v_d_2440 = v_fields_2439;
      break;
    }
    default: heff_nomatch(v_t_2438);
    }
    V v_t_2441 = (g_map_2elookup_24s1546226666x2146984184(v_x_241, heff_rfield(v_d_2440, 1)));
    switch (heff_tag_of(v_t_2441)) {
    case TAG_Nothing: {
      heff_drop_rec(v_d_2440, 3);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_i_2442 = heff_field(v_t_2441, 0);
      heff_take_n(v_t_2441, 1ULL, 1);
      V v_xs_2443 = heff_get_n(v_d_2440, 2, 3);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2442))) {
        if (heff_intLt_c(heff_dup(v_i_2442), heff_arrayLength_lent(v_xs_2443, 0))) {
          V v_v_2446 = heff_arrayIndex(v_xs_2443, v_i_2442);
          return v_v_2446;
        } else {
          heff_drop(v_i_2442);
          heff_drop(v_xs_2443);
          return heff_abandon();
        }
      } else {
        heff_drop(v_i_2442);
        heff_drop(v_xs_2443);
        return heff_abandon();
      }
    }
    default: return heff_nomatch(v_t_2441);
    }
  }
  case TAG_VOpaque: {
    heff_drop(v_x_241);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eproj(a[0], a[1]);
}
V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_lam0(V self, V *args);
V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_lam1(V self, V *args);
V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_lam2(V self, V *args);
Clo g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_entry, 6, 0};

V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905(V v_vs_240, V v_h_241, V v_sp_242, V v_desc_243, V v_x6_244, V v_acc_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_vs_240);
    heff_drop(v_h_241);
    heff_drop(v_sp_242);
    heff_drop(v_desc_243);
    return v_acc_245;
  }
  case TAG_Cons: {
    V v_x61_246 = heff_field(v_x6_244, 0);
    V v_rest_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x61_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x61_246, 0);
      V v_f_249 = heff_field(v_x61_246, 1);
      V v_ru_24x61_246_24MkPair = heff_take_reuse_n(v_x61_246, 3ULL, 2);
      V v_x6_2410 = heff_tr(heff_call(v_f_249, 1, (V[]){heff_dup(v_vs_240)}));
      V v_v_2421;
      switch (heff_tag_of(v_x6_2410)) {
      case TAG_MkField: {
        V v_fty_2411 = heff_field(v_x6_2410, 0);
        V v_x62_2412 = heff_field(v_x6_2410, 1);
        heff_take_n(v_x6_2410, 3ULL, 2);
        switch (heff_tag_of(v_x62_2412)) {
        case TAG_Nothing: {
          switch (heff_tag_of(v_desc_243)) {
          case TAG_Nothing: {
            v_v_2421 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_dup(v_h_241), heff_tag_at_n(v_ru_24x61_246_24MkPair, TAG_SpProj, 2, (V[]){heff_dup(v_sp_242), v_x_248}), heff_clo_n(g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_lam0, 1, 1, (V[]){v_fty_2411}), NTAG(TAG_Nothing)));
            break;
          }
          case TAG_Just: {
            V v_x_2414 = heff_dup(heff_field(v_desc_243, 0));
            V v_t_2415 = (g_heff_2eelab_2evalue_2eproj(v_x_2414, heff_dup(v_x_248)));
            switch (heff_tag_of(v_t_2415)) {
            case TAG_Nom: {
              V v_a_2416 = heff_field(v_t_2415, 0);
              heff_take_n(v_t_2415, 1ULL, 1);
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x61_246_24MkPair, 2);
              heff_drop(v_fty_2411);
              v_v_2421 = v_a_2416;
              break;
            }
            case TAG_Describe: {
              V v_a_2417 = heff_field(v_t_2415, 0);
              V v_ru_24t_2415_24Describe = heff_take_reuse_n(v_t_2415, 1ULL, 1);
              v_v_2421 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_dup(v_h_241), heff_tag_at_n(v_ru_24x61_246_24MkPair, TAG_SpProj, 2, (V[]){heff_dup(v_sp_242), v_x_248}), heff_clo_n(g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_lam1, 1, 1, (V[]){v_fty_2411}), heff_tag_at_n(v_ru_24t_2415_24Describe, TAG_Just, 1, (V[]){v_a_2417})));
              break;
            }
            case TAG_Become: {
              V v_a_2419 = heff_field(v_t_2415, 0);
              heff_take_n(v_t_2415, 1ULL, 1);
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x61_246_24MkPair, 2);
              heff_drop(v_fty_2411);
              v_v_2421 = v_a_2419;
              break;
            }
            default: heff_nomatch(v_t_2415);
            }
            break;
          }
          default: heff_nomatch(v_desc_243);
          }
          break;
        }
        case TAG_Just: {
          V v_v_2420 = heff_field(v_x62_2412, 0);
          heff_take_n(v_x62_2412, 1ULL, 1);
          heff_drop(v_x_248);
          heff_drop_cell(v_ru_24x61_246_24MkPair, 2);
          heff_drop(v_fty_2411);
          v_v_2421 = v_v_2420;
          break;
        }
        default: heff_nomatch(v_x62_2412);
        }
        break;
      }
      default: heff_nomatch(v_x6_2410);
      }
      V t_0 = heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_240, heff_clo_n(g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_lam2, 1, 1, (V[]){heff_dup(v_v_2421)})});
      V t_1 = v_h_241;
      V t_2 = v_sp_242;
      V t_3 = v_desc_243;
      V t_4 = v_rest_247;
      V t_5 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_v_2421, v_acc_245});
      v_vs_240 = t_0;
      v_h_241 = t_1;
      v_sp_242 = t_2;
      v_desc_243 = t_3;
      v_x6_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x61_246);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2egoER_24s12178679x44040905(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_fty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_fty_2411;
}
V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_lam1(V self, V *args) {
  V v_u_2418 = args[0];
  V v_fty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2418);
  return v_fty_2411;
}
V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_lam2(V self, V *args) {
  V v_u_2422 = args[0];
  V v_v_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2422);
  return v_v_2421;
}
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_lam0(V self, V *args);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_lam1(V self, V *args);
Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry, 4, 0};

V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V v_h_240, V v_spine_241, V v_ty_242, V v_desc_243) {
top: ;
  return heff_tag_n(TAG_VNeu, 5, (V[]){heff_dup(v_h_240), heff_dup(v_spine_241), heff_dup(v_ty_242), heff_clo_n(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_lam0, 1, 4, (V[]){v_ty_242, v_h_240, v_spine_241, heff_dup(v_desc_243)}), heff_clo_n(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_lam1, 1, 1, (V[]){v_desc_243})});
}
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_ty_242 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_spine_241 = heff_env(self)[2];
  V v_desc_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_244);
  V v_t_245 = heff_tr(heff_call(v_ty_242, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_246 = (g_heff_2eelab_2evalue_2ebehavior(v_t_245));
  switch (heff_tag_of(v_t_246)) {
  case TAG_LikeU: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_246, 0ULL, 4);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeRecord: {
    V v_capture_2413 = heff_field(v_t_246, 1);
    V v_fieldTypes_2414 = heff_field(v_t_246, 2);
    heff_take_n(v_t_246, 6ULL, 3);
    V v_t_2415 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2414, 0)));
    V v_t_2416 = heff_arrayToList(heff_take_field(v_fieldTypes_2414, 2));
    V v_t_2417 = (g_heff_2eutil_2edict_2ezipKV(v_t_2415, v_t_2416));
    V v_xs_2418 = (g_heff_2eelab_2evalue_2egoER_24s12178679x44040905(v_capture_2413, v_h_240, v_spine_241, v_desc_243, v_t_2417, NTAG(TAG_Nil)));
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
    V v_t_2420 = ({ V rv_2 = heff_arrayFromList(v_t_2419); V rr_ = heff_rec_reuse_nf(v_fieldTypes_2414, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_IntoCons, 1, (V[]){v_t_2420});
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeInt: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeFloat: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeString: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeRune: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_NoRules: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_desc_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2424);
  return v_desc_243;
}
V g_heff_2eelab_2evalue_2eprojAt_lam0(V self, V *args);
Clo g_heff_2eelab_2evalue_2eprojAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eprojAt_entry, 3, 0};

V g_heff_2eelab_2evalue_2eprojAt(V v_v_240, V v_x_241, V v_a_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(heff_dup(v_v_240)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_v_240)) {
    case TAG_VNeu: {
      V v_h_244 = heff_field(v_v_240, 0);
      V v_sp_245 = heff_field(v_v_240, 1);
      heff_take_n(v_v_240, 3ULL, 5);
      V v_t_2410 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_244, heff_tag_n(TAG_SpProj, 2, (V[]){v_sp_245, v_x_241}), heff_clo_n(g_heff_2eelab_2evalue_2eprojAt_lam0, 1, 1, (V[]){v_a_242}), NTAG(TAG_Nothing)));
      return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2410});
    }
    case TAG_VCode: {
      heff_drop(v_a_242);
      return (g_heff_2eelab_2evalue_2eproj(v_v_240, v_x_241));
    }
    case TAG_VLam: {
      heff_drop(v_a_242);
      return (g_heff_2eelab_2evalue_2eproj(v_v_240, v_x_241));
    }
    case TAG_VCons: {
      heff_drop(v_a_242);
      return (g_heff_2eelab_2evalue_2eproj(v_v_240, v_x_241));
    }
    case TAG_VOpaque: {
      heff_drop(v_a_242);
      return (g_heff_2eelab_2evalue_2eproj(v_v_240, v_x_241));
    }
    default: return heff_nomatch(v_v_240);
    }
  }
  case TAG_Just: {
    V v_fields_2415 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop(v_a_242);
    V v_t_2416 = (g_map_2elookup_24s1546226666x2146984184(v_x_241, heff_rfield(v_fields_2415, 1)));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      heff_drop_rec(v_fields_2415, 3);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_i_2417 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      V v_xs_2418 = heff_get_n(v_fields_2415, 2, 3);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2417))) {
        if (heff_intLt_c(heff_dup(v_i_2417), heff_arrayLength_lent(v_xs_2418, 0))) {
          V v_v_2421 = heff_arrayIndex(v_xs_2418, v_i_2417);
          return v_v_2421;
        } else {
          heff_drop(v_i_2417);
          heff_drop(v_xs_2418);
          return heff_abandon();
        }
      } else {
        heff_drop(v_i_2417);
        heff_drop(v_xs_2418);
        return heff_abandon();
      }
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2evalue_2eprojAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eprojAt(a[0], a[1], a[2]);
}
V g_heff_2eelab_2evalue_2eprojAt_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_a_242;
}
Clo g_heff_2eelab_2evalue_2eisError_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eisError_entry, 1, 0};

V g_heff_2eelab_2evalue_2eisError(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VNeu: {
    V v_h_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      return NTAG(TAG_False);
    }
    case TAG_HGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_HMeta: {
      return NTAG(TAG_False);
    }
    case TAG_HError: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_h_241);
    }
  }
  case TAG_VCode: {
    V v_x11_249 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_VU: {
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_h_2411 = heff_field(v_x11_249, 0);
      switch (heff_tag_of(v_h_2411)) {
      case TAG_HLocal: {
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_HMeta: {
        return NTAG(TAG_False);
      }
      case TAG_HError: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_h_2411);
      }
    }
    case TAG_VFunction: {
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  case TAG_VLam: {
    return NTAG(TAG_False);
  }
  case TAG_VCons: {
    return NTAG(TAG_False);
  }
  case TAG_VOpaque: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2eisError_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2eisError(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2evalue_2edecodeN_lam0(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeN_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeN_lam0, 1, 0};
V g_heff_2eelab_2evalue_2edecodeN_lam1(V self, V *args);
V g_heff_2eelab_2evalue_2edecodeN_lam2(V self, V *args);
V g_heff_2eelab_2evalue_2edecodeN_lam3(V self, V *args);
Clo g_heff_2eelab_2evalue_2edecodeN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeN_entry, 1, 0};

V g_heff_2eelab_2evalue_2edecodeN(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VNeu: {
    V v_h_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ty_243 = heff_field(v_x1_240, 2);
    V v_expansion_244 = heff_field(v_x1_240, 3);
    V v_desc_245 = heff_field(v_x1_240, 4);
    V v_ru_24x1_240_24VNeu = heff_take_reuse_n(v_x1_240, 31ULL, 5);
    V v_x1_246 = heff_tr(heff_call(heff_dup(v_ty_243), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_u_2425;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_VU: {
      V v_u_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      v_u_2425 = v_u_247;
      break;
    }
    case TAG_VDecode: {
      heff_take_n(v_x1_246, 0ULL, 5);
      v_u_2425 = heff_abandon();
      break;
    }
    case TAG_VFunction: {
      heff_take_n(v_x1_246, 0ULL, 5);
      v_u_2425 = heff_abandon();
      break;
    }
    case TAG_VRecord: {
      heff_take_n(v_x1_246, 0ULL, 4);
      v_u_2425 = heff_abandon();
      break;
    }
    case TAG_VSum: {
      heff_take_n(v_x1_246, 0ULL, 1);
      v_u_2425 = heff_abandon();
      break;
    }
    case TAG_VPrimInt: {
      v_u_2425 = heff_abandon();
      break;
    }
    case TAG_VPrimFloat: {
      v_u_2425 = heff_abandon();
      break;
    }
    case TAG_VPrimString: {
      v_u_2425 = heff_abandon();
      break;
    }
    case TAG_VPrimRune: {
      v_u_2425 = heff_abandon();
      break;
    }
    case TAG_VPrimArray: {
      heff_take_n(v_x1_246, 0ULL, 1);
      v_u_2425 = heff_abandon();
      break;
    }
    case TAG_VFixed: {
      heff_take_n(v_x1_246, 0ULL, 1);
      v_u_2425 = heff_abandon();
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_x2_2426 = heff_tr(heff_call(heff_dup(v_desc_245), 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_Nothing: {
      return heff_tag_at_n(v_ru_24x1_240_24VNeu, TAG_VDecode, 5, (V[]){heff_dup(v_h_241), heff_dup(v_sp_242), v_u_2425, ((V)&g_heff_2eelab_2evalue_2edecodeN_lam0_clo), heff_clo_n(g_heff_2eelab_2evalue_2edecodeN_lam1, 1, 5, (V[]){v_h_241, v_sp_242, v_ty_243, v_expansion_244, v_desc_245})});
    }
    case TAG_Just: {
      V v_x_2429 = heff_field(v_x2_2426, 0);
      V v_ru_24x2_2426_24Just = heff_take_reuse_n(v_x2_2426, 1ULL, 1);
      V v_t_2439;
      switch (heff_tag_of(v_x_2429)) {
      case TAG_VNeu: {
        heff_take_n(v_x_2429, 0ULL, 5);
        heff_drop_cell(v_ru_24x2_2426_24Just, 1);
        v_t_2439 = heff_abandon();
        break;
      }
      case TAG_VCode: {
        V v_a_2435 = heff_field(v_x_2429, 0);
        heff_take_n(v_x_2429, 1ULL, 1);
        v_t_2439 = heff_tag_at_n(v_ru_24x2_2426_24Just, TAG_Describe, 1, (V[]){v_a_2435});
        break;
      }
      case TAG_VLam: {
        heff_take_n(v_x_2429, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_2426_24Just, 1);
        v_t_2439 = heff_abandon();
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_x_2429, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2426_24Just, 1);
        v_t_2439 = heff_abandon();
        break;
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_ru_24x2_2426_24Just, 1);
        v_t_2439 = heff_abandon();
        break;
      }
      default: heff_nomatch(v_x_2429);
      }
      switch (heff_tag_of(v_t_2439)) {
      case TAG_Nom: {
        V v_dty_2440 = heff_field(v_t_2439, 0);
        heff_take_n(v_t_2439, 1ULL, 1);
        heff_drop(v_h_241);
        heff_drop(v_sp_242);
        heff_drop(v_ty_243);
        heff_drop(v_expansion_244);
        heff_drop(v_desc_245);
        heff_drop_cell(v_ru_24x1_240_24VNeu, 5);
        heff_drop(v_u_2425);
        return v_dty_2440;
      }
      case TAG_Describe: {
        V v_dty_2441 = heff_field(v_t_2439, 0);
        heff_take_n(v_t_2439, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_240_24VNeu, TAG_VDecode, 5, (V[]){heff_dup(v_h_241), heff_dup(v_sp_242), v_u_2425, heff_clo_n(g_heff_2eelab_2evalue_2edecodeN_lam2, 1, 1, (V[]){v_dty_2441}), heff_clo_n(g_heff_2eelab_2evalue_2edecodeN_lam3, 1, 5, (V[]){v_h_241, v_sp_242, v_ty_243, v_expansion_244, v_desc_245})});
      }
      case TAG_Become: {
        V v_dty_2444 = heff_field(v_t_2439, 0);
        heff_take_n(v_t_2439, 1ULL, 1);
        heff_drop(v_h_241);
        heff_drop(v_sp_242);
        heff_drop(v_ty_243);
        heff_drop(v_expansion_244);
        heff_drop(v_desc_245);
        heff_drop_cell(v_ru_24x1_240_24VNeu, 5);
        heff_drop(v_u_2425);
        return v_dty_2444;
      }
      default: return heff_nomatch(v_t_2439);
      }
    }
    default: return heff_nomatch(v_x2_2426);
    }
  }
  case TAG_VCode: {
    V v_a_2445 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_a_2445;
  }
  case TAG_VLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return heff_abandon();
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_VOpaque: {
    return heff_abandon();
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2edecodeN_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2edecodeN(a[0]);
}
V g_heff_2eelab_2evalue_2edecodeN_lam0(V self, V *args) {
  V v_x_2427 = args[0];
  heff_drop(v_x_2427);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2evalue_2edecodeN_lam1(V self, V *args) {
  V v_x_2428 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_ty_243 = heff_env(self)[2];
  V v_expansion_244 = heff_env(self)[3];
  V v_desc_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2428);
  return heff_tag_n(TAG_VNeu, 5, (V[]){v_h_241, v_sp_242, v_ty_243, v_expansion_244, v_desc_245});
}
V g_heff_2eelab_2evalue_2edecodeN_lam2(V self, V *args) {
  V v_x_2442 = args[0];
  V v_dty_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2442);
  return heff_tag_n(TAG_Just, 1, (V[]){v_dty_2441});
}
V g_heff_2eelab_2evalue_2edecodeN_lam3(V self, V *args) {
  V v_x_2443 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_ty_243 = heff_env(self)[2];
  V v_expansion_244 = heff_env(self)[3];
  V v_desc_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2443);
  return heff_tag_n(TAG_VNeu, 5, (V[]){v_h_241, v_sp_242, v_ty_243, v_expansion_244, v_desc_245});
}
Clo g_heff_2eelab_2evalue_2eneuAppTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eneuAppTy_entry, 3, 0};

V g_heff_2eelab_2evalue_2eneuAppTy(V v_h_240, V v_t_241, V v_arg_242) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_HLocal: {
    V v_t_244 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
    switch (heff_tag_of(v_t_244)) {
    case TAG_LikeU: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFunction: {
      V v_cod_248 = heff_field(v_t_244, 2);
      heff_take_n(v_t_244, 4ULL, 4);
      V v_x1_2414;
      switch (heff_tag_of(v_cod_248)) {
      case TAG_MkClo: {
        V v_vs_2411 = heff_field(v_cod_248, 1);
        V v_body_2412 = heff_field(v_cod_248, 2);
        heff_take_n(v_cod_248, 6ULL, 3);
        v_x1_2414 = heff_tr(heff_call(v_body_2412, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2411, v_arg_242})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2413 = heff_field(v_cod_248, 0);
        heff_take_n(v_cod_248, 1ULL, 1);
        heff_drop(v_arg_242);
        v_x1_2414 = v_body_2413;
        break;
      }
      default: heff_nomatch(v_cod_248);
      }
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Nom: {
        V v_x_2415 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        return v_x_2415;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2414, 0ULL, 1);
        return heff_abandon();
      }
      case TAG_Become: {
        V v_x_2417 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        return v_x_2417;
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_244, 0ULL, 3);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeInt: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFloat: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeString: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeRune: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_NoRules: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_HGlobal: {
    V v_t_2425 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
    switch (heff_tag_of(v_t_2425)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2425, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFunction: {
      V v_cod_2429 = heff_field(v_t_2425, 2);
      heff_take_n(v_t_2425, 4ULL, 4);
      V v_x1_2435;
      switch (heff_tag_of(v_cod_2429)) {
      case TAG_MkClo: {
        V v_vs_2432 = heff_field(v_cod_2429, 1);
        V v_body_2433 = heff_field(v_cod_2429, 2);
        heff_take_n(v_cod_2429, 6ULL, 3);
        v_x1_2435 = heff_tr(heff_call(v_body_2433, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2432, v_arg_242})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2434 = heff_field(v_cod_2429, 0);
        heff_take_n(v_cod_2429, 1ULL, 1);
        heff_drop(v_arg_242);
        v_x1_2435 = v_body_2434;
        break;
      }
      default: heff_nomatch(v_cod_2429);
      }
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_Nom: {
        V v_x_2436 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        return v_x_2436;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2435, 0ULL, 1);
        return heff_abandon();
      }
      case TAG_Become: {
        V v_x_2438 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        return v_x_2438;
      }
      default: return heff_nomatch(v_x1_2435);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2425, 0ULL, 3);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2425, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeInt: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFloat: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeString: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeRune: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2425, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2425, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_NoRules: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  case TAG_HMeta: {
    V v_t_2446 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_241)));
    switch (heff_tag_of(v_t_2446)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2446, 0ULL, 1);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2446, 0ULL, 4);
      V v_t_2452 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
      switch (heff_tag_of(v_t_2452)) {
      case TAG_LikeU: {
        heff_take_n(v_t_2452, 0ULL, 1);
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeFunction: {
        V v_cod_2456 = heff_field(v_t_2452, 2);
        heff_take_n(v_t_2452, 4ULL, 4);
        V v_x1_2462;
        switch (heff_tag_of(v_cod_2456)) {
        case TAG_MkClo: {
          V v_vs_2459 = heff_field(v_cod_2456, 1);
          V v_body_2460 = heff_field(v_cod_2456, 2);
          heff_take_n(v_cod_2456, 6ULL, 3);
          v_x1_2462 = heff_tr(heff_call(v_body_2460, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2459, v_arg_242})}));
          break;
        }
        case TAG_CloConst: {
          V v_body_2461 = heff_field(v_cod_2456, 0);
          heff_take_n(v_cod_2456, 1ULL, 1);
          heff_drop(v_arg_242);
          v_x1_2462 = v_body_2461;
          break;
        }
        default: heff_nomatch(v_cod_2456);
        }
        switch (heff_tag_of(v_x1_2462)) {
        case TAG_Nom: {
          V v_x_2463 = heff_field(v_x1_2462, 0);
          heff_take_n(v_x1_2462, 1ULL, 1);
          return v_x_2463;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2462, 0ULL, 1);
          return heff_abandon();
        }
        case TAG_Become: {
          V v_x_2465 = heff_field(v_x1_2462, 0);
          heff_take_n(v_x1_2462, 1ULL, 1);
          return v_x_2465;
        }
        default: return heff_nomatch(v_x1_2462);
        }
      }
      case TAG_LikeRecord: {
        heff_take_n(v_t_2452, 0ULL, 3);
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_2452, 0ULL, 1);
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeInt: {
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeFloat: {
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeString: {
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeRune: {
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_2452, 0ULL, 1);
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_2452, 0ULL, 1);
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_NoRules: {
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      default: return heff_nomatch(v_t_2452);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2446, 0ULL, 3);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2446, 0ULL, 1);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeInt: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeFloat: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeString: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeRune: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2446, 0ULL, 1);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2446, 0ULL, 1);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_NoRules: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    default: return heff_nomatch(v_t_2446);
    }
  }
  case TAG_HError: {
    V v_t_2478 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
    switch (heff_tag_of(v_t_2478)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2478, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFunction: {
      V v_cod_2482 = heff_field(v_t_2478, 2);
      heff_take_n(v_t_2478, 4ULL, 4);
      V v_x1_2488;
      switch (heff_tag_of(v_cod_2482)) {
      case TAG_MkClo: {
        V v_vs_2485 = heff_field(v_cod_2482, 1);
        V v_body_2486 = heff_field(v_cod_2482, 2);
        heff_take_n(v_cod_2482, 6ULL, 3);
        v_x1_2488 = heff_tr(heff_call(v_body_2486, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2485, v_arg_242})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2487 = heff_field(v_cod_2482, 0);
        heff_take_n(v_cod_2482, 1ULL, 1);
        heff_drop(v_arg_242);
        v_x1_2488 = v_body_2487;
        break;
      }
      default: heff_nomatch(v_cod_2482);
      }
      switch (heff_tag_of(v_x1_2488)) {
      case TAG_Nom: {
        V v_x_2489 = heff_field(v_x1_2488, 0);
        heff_take_n(v_x1_2488, 1ULL, 1);
        return v_x_2489;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2488, 0ULL, 1);
        return heff_abandon();
      }
      case TAG_Become: {
        V v_x_2491 = heff_field(v_x1_2488, 0);
        heff_take_n(v_x1_2488, 1ULL, 1);
        return v_x_2491;
      }
      default: return heff_nomatch(v_x1_2488);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2478, 0ULL, 3);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2478, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeInt: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFloat: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeString: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeRune: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2478, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2478, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_NoRules: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_2478);
    }
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2eelab_2evalue_2eneuAppTy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2eneuAppTy(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2evalue_2eapp_lam0(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_lam1(V self, V *args);
Clo g_heff_2eelab_2evalue_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eapp_entry, 2, 0};

V g_heff_2eelab_2evalue_2eapp(V v_f_240, V v_arg_241) {
top: ;
  switch (heff_tag_of(v_f_240)) {
  case TAG_VNeu: {
    V v_h_242 = heff_field(v_f_240, 0);
    V v_sp_243 = heff_field(v_f_240, 1);
    V v_ty_244 = heff_field(v_f_240, 2);
    V v_desc_246 = heff_field(v_f_240, 4);
    heff_take_n(v_f_240, 23ULL, 5);
    V v_x2_247 = heff_tr(heff_call(v_desc_246, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2419;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      V v_t_248 = heff_tr(heff_call(heff_dup(v_arg_241), 1, (V[]){NTAG(TAG_MkUnit)}));
      v_t_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_dup(v_h_242), heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_243, v_t_248}), heff_clo_n(g_heff_2eelab_2evalue_2eapp_lam0, 1, 3, (V[]){v_ty_244, v_h_242, v_arg_241}), NTAG(TAG_Nothing)));
      break;
    }
    case TAG_Just: {
      V v_x_2411 = heff_field(v_x2_247, 0);
      V v_ru_24x2_247_24Just = heff_take_reuse_n(v_x2_247, 1ULL, 1);
      V v_t_2412 = heff_tr(g_heff_2eelab_2evalue_2eapp(v_x_2411, heff_dup(v_arg_241)));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nom: {
        V v_v_2413 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 1);
        heff_drop(v_arg_241);
        heff_drop(v_h_242);
        heff_drop(v_sp_243);
        heff_drop(v_ty_244);
        heff_drop_cell(v_ru_24x2_247_24Just, 1);
        v_t_2419 = v_v_2413;
        break;
      }
      case TAG_Describe: {
        V v_desc_2414 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 1);
        V v_t_2415 = heff_tr(heff_call(heff_dup(v_arg_241), 1, (V[]){NTAG(TAG_MkUnit)}));
        v_t_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_dup(v_h_242), heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_243, v_t_2415}), heff_clo_n(g_heff_2eelab_2evalue_2eapp_lam1, 1, 3, (V[]){v_ty_244, v_h_242, v_arg_241}), heff_tag_at_n(v_ru_24x2_247_24Just, TAG_Just, 1, (V[]){v_desc_2414})));
        break;
      }
      case TAG_Become: {
        V v_v_2418 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 1);
        heff_drop(v_arg_241);
        heff_drop(v_h_242);
        heff_drop(v_sp_243);
        heff_drop(v_ty_244);
        heff_drop_cell(v_ru_24x2_247_24Just, 1);
        v_t_2419 = v_v_2418;
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2419});
  }
  case TAG_VCode: {
    heff_take_n(v_f_240, 0ULL, 1);
    heff_drop(v_arg_241);
    return heff_abandon();
  }
  case TAG_VLam: {
    V v_clo_2422 = heff_field(v_f_240, 1);
    heff_take_n(v_f_240, 2ULL, 2);
    switch (heff_tag_of(v_clo_2422)) {
    case TAG_MkClo: {
      V v_vs_2424 = heff_field(v_clo_2422, 1);
      V v_body_2425 = heff_field(v_clo_2422, 2);
      heff_take_n(v_clo_2422, 6ULL, 3);
      return heff_tail(v_body_2425, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2424, v_arg_241})});
    }
    case TAG_CloConst: {
      V v_body_2426 = heff_field(v_clo_2422, 0);
      heff_take_n(v_clo_2422, 1ULL, 1);
      heff_drop(v_arg_241);
      return v_body_2426;
    }
    default: return heff_nomatch(v_clo_2422);
    }
  }
  case TAG_VCons: {
    heff_take_n(v_f_240, 0ULL, 1);
    heff_drop(v_arg_241);
    return heff_abandon();
  }
  case TAG_VOpaque: {
    heff_drop(v_arg_241);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_f_240);
  }
}
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eapp(a[0], a[1]);
}
V g_heff_2eelab_2evalue_2eapp_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_ty_244 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_arg_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_249);
  V v_t_2410 = heff_tr(heff_call(v_ty_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_h_242; V a_1 = v_t_2410; V a_2 = v_arg_241; V r_ = (g_heff_2eelab_2evalue_2eneuAppTy(a_0, a_1, a_2)); heff_drop(v_h_242); r_; });
}
V g_heff_2eelab_2evalue_2eapp_lam1(V self, V *args) {
  V v_u_2416 = args[0];
  V v_ty_244 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_arg_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2416);
  V v_t_2417 = heff_tr(heff_call(v_ty_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_h_242; V a_1 = v_t_2417; V a_2 = v_arg_241; V r_ = (g_heff_2eelab_2evalue_2eneuAppTy(a_0, a_1, a_2)); heff_drop(v_h_242); r_; });
}
V g_heff_2eelab_2evalue_2especialize_lam1(V self, V *args);
V g_heff_2eelab_2evalue_2especialize_lam0(V self, V *args);
Clo g_heff_2eelab_2evalue_2especialize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2especialize_entry, 3, 0};

V g_heff_2eelab_2evalue_2especialize(V v_v_240, V v_x_241, V v_f_242) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VNeu: {
    V v_h_243 = heff_field(v_v_240, 0);
    V v_sp_244 = heff_field(v_v_240, 1);
    V v_ty_245 = heff_field(v_v_240, 2);
    V v_expansion_246 = heff_field(v_v_240, 3);
    V v_desc_247 = heff_field(v_v_240, 4);
    V v_ru_24v_240_24VNeu = heff_take_reuse_n(v_v_240, 31ULL, 5);
    V v_it_248 = heff_tr(heff_call(v_desc_247, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_it_248)) {
    case TAG_Nothing: {
      heff_drop(v_x_241);
      heff_drop(v_f_242);
      heff_drop(v_h_243);
      heff_drop(v_sp_244);
      heff_drop(v_ty_245);
      heff_drop(v_expansion_246);
      heff_drop_cell(v_ru_24v_240_24VNeu, 5);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_it1_249 = heff_field(v_it_248, 0);
      heff_take_n(v_it_248, 1ULL, 1);
      switch (heff_tag_of(v_it1_249)) {
      case TAG_VNeu: {
        heff_take_n(v_it1_249, 0ULL, 5);
        heff_drop(v_x_241);
        heff_drop(v_f_242);
        heff_drop(v_h_243);
        heff_drop(v_sp_244);
        heff_drop(v_ty_245);
        heff_drop(v_expansion_246);
        heff_drop_cell(v_ru_24v_240_24VNeu, 5);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_it11_2415 = heff_field(v_it1_249, 0);
        heff_take_n(v_it1_249, 1ULL, 1);
        switch (heff_tag_of(v_it11_2415)) {
        case TAG_VU: {
          heff_take_n(v_it11_2415, 0ULL, 1);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VDecode: {
          heff_take_n(v_it11_2415, 0ULL, 5);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VFunction: {
          heff_take_n(v_it11_2415, 0ULL, 5);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VRecord: {
          V v_level_2427 = heff_field(v_it11_2415, 0);
          V v_capture_2428 = heff_field(v_it11_2415, 1);
          V v_fieldTypes_2429 = heff_field(v_it11_2415, 2);
          V v_defaults_2430 = heff_field(v_it11_2415, 3);
          heff_take_n(v_it11_2415, 15ULL, 4);
          return heff_tag_at_n(v_ru_24v_240_24VNeu, TAG_VNeu, 5, (V[]){v_h_243, heff_tag_n(TAG_SpSpec, 3, (V[]){v_sp_244, heff_dup(v_x_241), heff_dup(v_f_242)}), v_ty_245, v_expansion_246, heff_clo_n(g_heff_2eelab_2evalue_2especialize_lam0, 1, 6, (V[]){v_fieldTypes_2429, v_x_241, v_f_242, v_level_2427, v_capture_2428, v_defaults_2430})});
        }
        case TAG_VSum: {
          heff_take_n(v_it11_2415, 0ULL, 1);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimInt: {
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimFloat: {
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimString: {
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimRune: {
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimArray: {
          heff_take_n(v_it11_2415, 0ULL, 1);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VFixed: {
          heff_take_n(v_it11_2415, 0ULL, 1);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_it11_2415);
        }
      }
      case TAG_VLam: {
        heff_take_n(v_it1_249, 0ULL, 2);
        heff_drop(v_x_241);
        heff_drop(v_f_242);
        heff_drop(v_h_243);
        heff_drop(v_sp_244);
        heff_drop(v_ty_245);
        heff_drop(v_expansion_246);
        heff_drop_cell(v_ru_24v_240_24VNeu, 5);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_it1_249, 0ULL, 1);
        heff_drop(v_x_241);
        heff_drop(v_f_242);
        heff_drop(v_h_243);
        heff_drop(v_sp_244);
        heff_drop(v_ty_245);
        heff_drop(v_expansion_246);
        heff_drop_cell(v_ru_24v_240_24VNeu, 5);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop(v_x_241);
        heff_drop(v_f_242);
        heff_drop(v_h_243);
        heff_drop(v_sp_244);
        heff_drop(v_ty_245);
        heff_drop(v_expansion_246);
        heff_drop_cell(v_ru_24v_240_24VNeu, 5);
        return heff_abandon();
      }
      default: return heff_nomatch(v_it1_249);
      }
    }
    default: return heff_nomatch(v_it_248);
    }
  }
  case TAG_VCode: {
    heff_take_n(v_v_240, 0ULL, 1);
    heff_drop(v_x_241);
    heff_drop(v_f_242);
    return heff_abandon();
  }
  case TAG_VLam: {
    heff_take_n(v_v_240, 0ULL, 2);
    heff_drop(v_x_241);
    heff_drop(v_f_242);
    return heff_abandon();
  }
  case TAG_VCons: {
    heff_take_n(v_v_240, 0ULL, 1);
    heff_drop(v_x_241);
    heff_drop(v_f_242);
    return heff_abandon();
  }
  case TAG_VOpaque: {
    heff_drop(v_x_241);
    heff_drop(v_f_242);
    return heff_abandon();
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2eelab_2evalue_2especialize_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2especialize(a[0], a[1], a[2]);
}
V g_heff_2eelab_2evalue_2especialize_lam1(V self, V *args) {
  V v_field_2432 = args[0];
  V v_vs_2433 = args[1];
  V v_f_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_tr(heff_call(v_field_2432, 1, (V[]){v_vs_2433}));
  switch (heff_tag_of(v_t_2434)) {
  case TAG_MkField: {
    V v_ty_2435 = heff_field(v_t_2434, 0);
    V v_ru_24t_2434_24MkField = heff_take_reuse_n(v_t_2434, 1ULL, 2);
    return heff_tag_at_n(v_ru_24t_2434_24MkField, TAG_MkField, 2, (V[]){v_ty_2435, heff_tag_n(TAG_Just, 1, (V[]){v_f_242})});
  }
  default: return heff_nomatch(v_t_2434);
  }
}
V g_heff_2eelab_2evalue_2especialize_lam0(V self, V *args) {
  V v_u_2431 = args[0];
  V v_fieldTypes_2429 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_level_2427 = heff_env(self)[3];
  V v_capture_2428 = heff_env(self)[4];
  V v_defaults_2430 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_u_2431);
  V v_t_2437 = (g_heff_2eutil_2edict_2eupdate(v_fieldTypes_2429, v_x_241, heff_clo_n(g_heff_2eelab_2evalue_2especialize_lam1, 2, 1, (V[]){v_f_242})));
  V v_t_2438 = heff_tag_n(TAG_VCode, 1, (V[]){heff_tag_n(TAG_VRecord, 4, (V[]){v_level_2427, v_capture_2428, v_t_2437, v_defaults_2430})});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2438});
}
Clo g_heff_2eelab_2evalue_2eimplicitDefault_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eimplicitDefault_entry, 1, 0};

V g_heff_2eelab_2evalue_2eimplicitDefault(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VU: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_VDecode: {
    V v_described_245 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 5);
    V v_t_247 = heff_tr(heff_call(v_described_245, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_t_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V t_0 = v_t_248;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_VFunction: {
    V v_dflt_2413 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    return v_dflt_2413;
  }
  case TAG_VRecord: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_Nothing);
  }
  case TAG_VSum: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_VPrimInt: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VPrimFloat: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VPrimString: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VPrimRune: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VPrimArray: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_VFixed: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2eimplicitDefault_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eimplicitDefault(a[0]);
}
Clo g_heff_2eelab_2evalue_2edefaultsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edefaultsOf_entry, 1, 0};

V g_heff_2eelab_2evalue_2edefaultsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VU: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VDecode: {
    V v_described_245 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 5);
    V v_t_247 = heff_tr(heff_call(v_described_245, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      return heff_dup(g_heff_2eutil_2edict_2eempty_get());
    }
    case TAG_Just: {
      V v_t_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V t_0 = v_t_248;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_VFunction: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VRecord: {
    V v_defaults_2417 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_defaults_2417;
  }
  case TAG_VSum: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VPrimInt: {
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VPrimFloat: {
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VPrimString: {
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VPrimRune: {
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VPrimArray: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VFixed: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2edefaultsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2edefaultsOf(a[0]);
}
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam1(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam0(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam3(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam2(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam4(V self, V *args);
Clo g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_entry, 2, 0};

V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522(V v_lit_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_f_241)) {
  case TAG_VNeu: {
    V v_h_242 = heff_field(v_f_241, 0);
    V v_sp_243 = heff_field(v_f_241, 1);
    V v_ty_244 = heff_field(v_f_241, 2);
    V v_desc_246 = heff_field(v_f_241, 4);
    heff_take_n(v_f_241, 23ULL, 5);
    V v_x2_247 = heff_tr(heff_call(v_desc_246, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2419;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_t_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_dup(v_h_242), heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_243, heff_dup(v_lit_240)}), heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam0, 1, 3, (V[]){v_ty_244, v_h_242, v_lit_240}), NTAG(TAG_Nothing)));
      break;
    }
    case TAG_Just: {
      V v_x_2411 = heff_field(v_x2_247, 0);
      V v_ru_24x2_247_24Just = heff_take_reuse_n(v_x2_247, 1ULL, 1);
      V v_t_2412 = heff_tr(g_heff_2eelab_2evalue_2eapp_24s676305996x967270522(heff_dup(v_lit_240), v_x_2411));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nom: {
        V v_v_2413 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 1);
        heff_drop(v_lit_240);
        heff_drop(v_h_242);
        heff_drop(v_sp_243);
        heff_drop(v_ty_244);
        heff_drop_cell(v_ru_24x2_247_24Just, 1);
        v_t_2419 = v_v_2413;
        break;
      }
      case TAG_Describe: {
        V v_desc_2414 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 1);
        v_t_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_dup(v_h_242), heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_243, heff_dup(v_lit_240)}), heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam2, 1, 3, (V[]){v_ty_244, v_h_242, v_lit_240}), heff_tag_at_n(v_ru_24x2_247_24Just, TAG_Just, 1, (V[]){v_desc_2414})));
        break;
      }
      case TAG_Become: {
        V v_v_2418 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 1);
        heff_drop(v_lit_240);
        heff_drop(v_h_242);
        heff_drop(v_sp_243);
        heff_drop(v_ty_244);
        heff_drop_cell(v_ru_24x2_247_24Just, 1);
        v_t_2419 = v_v_2418;
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2419});
  }
  case TAG_VCode: {
    heff_take_n(v_f_241, 0ULL, 1);
    heff_drop(v_lit_240);
    return heff_abandon();
  }
  case TAG_VLam: {
    V v_clo_2422 = heff_field(v_f_241, 1);
    heff_take_n(v_f_241, 2ULL, 2);
    switch (heff_tag_of(v_clo_2422)) {
    case TAG_MkClo: {
      V v_vs_2424 = heff_field(v_clo_2422, 1);
      V v_body_2425 = heff_field(v_clo_2422, 2);
      heff_take_n(v_clo_2422, 6ULL, 3);
      return heff_tail(v_body_2425, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2424, heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam4, 1, 1, (V[]){v_lit_240})})});
    }
    case TAG_CloConst: {
      V v_body_2427 = heff_field(v_clo_2422, 0);
      heff_take_n(v_clo_2422, 1ULL, 1);
      heff_drop(v_lit_240);
      return v_body_2427;
    }
    default: return heff_nomatch(v_clo_2422);
    }
  }
  case TAG_VCons: {
    heff_take_n(v_f_241, 0ULL, 1);
    heff_drop(v_lit_240);
    return heff_abandon();
  }
  case TAG_VOpaque: {
    heff_drop(v_lit_240);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_f_241);
  }
}
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eapp_24s676305996x967270522(a[0], a[1]);
}
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam1(V self, V *args) {
  V v_a_2410 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2410);
  return v_lit_240;
}
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam0(V self, V *args) {
  V v_u_248 = args[0];
  V v_ty_244 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_248);
  V v_t_249 = heff_tr(heff_call(v_ty_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_h_242; V a_1 = v_t_249; V a_2 = heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam1, 1, 1, (V[]){v_lit_240}); V r_ = (g_heff_2eelab_2evalue_2eneuAppTy(a_0, a_1, a_2)); heff_drop(v_h_242); r_; });
}
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam3(V self, V *args) {
  V v_a_2417 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2417);
  return v_lit_240;
}
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam2(V self, V *args) {
  V v_u_2415 = args[0];
  V v_ty_244 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2415);
  V v_t_2416 = heff_tr(heff_call(v_ty_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_h_242; V a_1 = v_t_2416; V a_2 = heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam3, 1, 1, (V[]){v_lit_240}); V r_ = (g_heff_2eelab_2evalue_2eneuAppTy(a_0, a_1, a_2)); heff_drop(v_h_242); r_; });
}
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam4(V self, V *args) {
  V v_a_2426 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2426);
  return v_lit_240;
}
Clo g_heff_2eelab_2evalue_2ereplay_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ereplay_entry, 2, 0};

V g_heff_2eelab_2evalue_2ereplay(V v_v_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SpId: {
    return v_v_240;
  }
  case TAG_SpApp: {
    V v_sp_242 = heff_field(v_x2_241, 0);
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2eelab_2evalue_2ereplay(v_v_240, v_sp_242));
    V v_x1_245 = heff_tr(g_heff_2eelab_2evalue_2eapp_24s676305996x967270522(heff_dup(v_a_243), v_t_244));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nom: {
      V v_x_246 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      return v_x_246;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_245, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_Become: {
      V v_x_248 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      return v_x_248;
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  case TAG_SpProj: {
    V v_sp_249 = heff_field(v_x2_241, 0);
    V v_l_2410 = heff_field(v_x2_241, 1);
    V v_t_2411 = (g_heff_2eelab_2evalue_2ereplay(v_v_240, v_sp_249));
    V v_x1_2412 = (g_heff_2eelab_2evalue_2eproj(v_t_2411, heff_dup(v_l_2410)));
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nom: {
      V v_x_2413 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      return v_x_2413;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2412, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_Become: {
      V v_x_2415 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      return v_x_2415;
    }
    default: return heff_nomatch(v_x1_2412);
    }
  }
  case TAG_SpSpec: {
    V v_sp_2416 = heff_field(v_x2_241, 0);
    V v_l_2417 = heff_field(v_x2_241, 1);
    V v_f_2418 = heff_field(v_x2_241, 2);
    V v_t_2419 = (g_heff_2eelab_2evalue_2ereplay(v_v_240, v_sp_2416));
    return (g_heff_2eelab_2evalue_2especialize(v_t_2419, heff_dup(v_l_2417), heff_dup(v_f_2418)));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2evalue_2ereplay(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2evalue_2eforceEl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eforceEl_entry, 2, 0};

V g_heff_2eelab_2evalue_2eforceEl(V v_mc_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VNeu: {
    V v_v1_242 = heff_dup(heff_field(v_v_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_v_241, 1));
    switch (heff_tag_of(v_v1_242)) {
    case TAG_HLocal: {
      heff_take_n(v_v1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return v_v_241;
    }
    case TAG_HGlobal: {
      heff_take_n(v_v1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return v_v_241;
    }
    case TAG_HMeta: {
      V v_m_249 = heff_field(v_v1_242, 0);
      heff_take_n(v_v1_242, 1ULL, 1);
      V v_t_2410 = (g_map_2elookup_24s567992785x1569911877(v_m_249, v_mc_240));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nothing: {
        heff_drop(v_sp_243);
        return v_v_241;
      }
      case TAG_Just: {
        V v_e_2411 = heff_field(v_t_2410, 0);
        heff_take_n(v_t_2410, 1ULL, 1);
        V v_t_2412 = heff_get_n(v_e_2411, 1, 6);
        switch (heff_tag_of(v_t_2412)) {
        case TAG_Nothing: {
          heff_drop(v_sp_243);
          return v_v_241;
        }
        case TAG_Just: {
          V v_sol_2413 = heff_field(v_t_2412, 0);
          heff_take_n(v_t_2412, 1ULL, 1);
          heff_drop_tag(v_v_241, 5);
          V v_t_2414 = ({ V a_0 = v_sol_2413; V a_1 = v_sp_243; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_243); r_; });
          V t_0 = v_mc_240;
          V t_1 = v_t_2414;
          v_mc_240 = t_0;
          v_v_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_t_2412);
        }
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_HError: {
      heff_drop(v_sp_243);
      return v_v_241;
    }
    default: return heff_nomatch(v_v1_242);
    }
  }
  case TAG_VCode: {
    return v_v_241;
  }
  case TAG_VLam: {
    return v_v_241;
  }
  case TAG_VCons: {
    return v_v_241;
  }
  case TAG_VOpaque: {
    return v_v_241;
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2eforceEl(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2evalue_2eforceTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eforceTy_entry, 2, 0};

V g_heff_2eelab_2evalue_2eforceTy(V v_mc_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_VU: {
    return v_t_241;
  }
  case TAG_VDecode: {
    V v_t1_243 = heff_dup(heff_field(v_t_241, 0));
    V v_sp_244 = heff_dup(heff_field(v_t_241, 1));
    switch (heff_tag_of(v_t1_243)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_243, 0ULL, 1);
      heff_drop(v_sp_244);
      return v_t_241;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_243, 0ULL, 1);
      heff_drop(v_sp_244);
      return v_t_241;
    }
    case TAG_HMeta: {
      V v_m_2410 = heff_field(v_t1_243, 0);
      heff_take_n(v_t1_243, 1ULL, 1);
      V v_t_2411 = (g_map_2elookup_24s567992785x1569911877(v_m_2410, v_mc_240));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        heff_drop(v_sp_244);
        return v_t_241;
      }
      case TAG_Just: {
        V v_e_2412 = heff_field(v_t_2411, 0);
        heff_take_n(v_t_2411, 1ULL, 1);
        V v_t_2413 = heff_get_n(v_e_2412, 1, 6);
        switch (heff_tag_of(v_t_2413)) {
        case TAG_Nothing: {
          heff_drop(v_sp_244);
          return v_t_241;
        }
        case TAG_Just: {
          V v_sol_2414 = heff_field(v_t_2413, 0);
          heff_take_n(v_t_2413, 1ULL, 1);
          heff_drop_tag(v_t_241, 5);
          V v_t_2415 = ({ V a_0 = v_sol_2414; V a_1 = v_sp_244; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_244); r_; });
          V v_t_2416 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_240, v_t_2415));
          V v_t_2417 = (g_heff_2eelab_2evalue_2edecodeN(v_t_2416));
          V t_0 = v_mc_240;
          V t_1 = v_t_2417;
          v_mc_240 = t_0;
          v_t_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_t_2413);
        }
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_HError: {
      heff_drop(v_sp_244);
      return v_t_241;
    }
    default: return heff_nomatch(v_t1_243);
    }
  }
  case TAG_VFunction: {
    return v_t_241;
  }
  case TAG_VRecord: {
    return v_t_241;
  }
  case TAG_VSum: {
    return v_t_241;
  }
  case TAG_VPrimInt: {
    return v_t_241;
  }
  case TAG_VPrimFloat: {
    return v_t_241;
  }
  case TAG_VPrimString: {
    return v_t_241;
  }
  case TAG_VPrimRune: {
    return v_t_241;
  }
  case TAG_VPrimArray: {
    return v_t_241;
  }
  case TAG_VFixed: {
    return v_t_241;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2eforceTy(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2evalue_2etypeForProjection_lam0(V self, V *args);
Clo g_heff_2eelab_2evalue_2etypeForProjection_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2etypeForProjection_entry, 4, 0};

V g_heff_2eelab_2evalue_2etypeForProjection(V v_capture_240, V v_fieldTypes_241, V v_x_242, V v_fields_243) {
top: ;
  V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), heff_rfield(v_fieldTypes_241, 1)));
  V v_i_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_i_246 = heff_abandon();
    break;
  }
  case TAG_Just: {
    V v_i_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_i_246 = v_i_245;
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_xs_247 = heff_take_field(v_fieldTypes_241, 2);
  V v_t_2411;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_246))) {
    if (heff_intLt_c(heff_dup(v_i_246), heff_arrayLength_lent(v_xs_247, 0))) {
      V v_v_2410 = heff_arrayIndex(v_xs_247, v_i_246);
      v_t_2411 = v_v_2410;
    } else {
      heff_drop(v_i_246);
      heff_drop(v_xs_247);
      v_t_2411 = heff_abandon();
    }
  } else {
    heff_drop(v_i_246);
    heff_drop(v_xs_247);
    v_t_2411 = heff_abandon();
  }
  V v_t_2412 = ({ V a_0 = v_x_242; V b_1 = heff_get_n(v_fieldTypes_241, 1, 3); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2414;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    v_t_2414 = heff_abandon();
    break;
  }
  case TAG_Just: {
    V v_i_2413 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    v_t_2414 = v_i_2413;
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_t_2420 = heff_arrayGenerate(v_t_2414, heff_clo_n(g_heff_2eelab_2evalue_2etypeForProjection_lam0, 1, 1, (V[]){v_fields_243}));
  return heff_tail(v_t_2411, 1, (V[]){heff_tag_n(TAG_LChunkSnoc, 2, (V[]){v_capture_240, v_t_2420})});
}
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2etypeForProjection(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2evalue_2etypeForProjection_lam0(V self, V *args) {
  V v_j_2415 = args[0];
  V v_fields_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2416 = heff_get_n(v_fields_243, 2, 3);
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_j_2415))) {
    if (heff_intLt_c(heff_dup(v_j_2415), heff_arrayLength_lent(v_xs_2416, 0))) {
      V v_v_2419 = heff_arrayIndex(v_xs_2416, v_j_2415);
      return v_v_2419;
    } else {
      heff_drop(v_j_2415);
      heff_drop(v_xs_2416);
      return heff_abandon();
    }
  } else {
    heff_drop(v_j_2415);
    heff_drop(v_xs_2416);
    return heff_abandon();
  }
}
V g_heff_2eelab_2evalue_2eprojTyWith_lam0(V self, V *args);
Clo g_heff_2eelab_2evalue_2eprojTyWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eprojTyWith_entry, 3, 0};

V g_heff_2eelab_2evalue_2eprojTyWith(V v_t_240, V v_mf_241, V v_x_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2evalue_2ebehavior(v_t_240));
  switch (heff_tag_of(v_t_243)) {
  case TAG_LikeU: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_243, 0ULL, 4);
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeRecord: {
    V v_capture_2410 = heff_field(v_t_243, 1);
    V v_fieldTypes_2411 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 6ULL, 3);
    switch (heff_tag_of(v_mf_241)) {
    case TAG_Nothing: {
      heff_drop(v_x_242);
      heff_drop(v_capture_2410);
      heff_drop(v_fieldTypes_2411);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_fields_2412 = heff_field(v_mf_241, 0);
      V v_ru_24mf_241_24Just = heff_take_reuse_n(v_mf_241, 1ULL, 1);
      V v_xs_2413 = heff_take_field(v_fields_2412, 2);
      V v_t_2419 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2413, 0), heff_clo_n(g_heff_2eelab_2evalue_2eprojTyWith_lam0, 1, 1, (V[]){v_xs_2413}));
      V v_t_2420 = ({ V rv_2 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_fields_2412, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_x1_2421 = heff_tr(g_heff_2eelab_2evalue_2etypeForProjection(v_capture_2410, v_fieldTypes_2411, v_x_242, v_t_2420));
      V v_t_2424;
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_MkField: {
        V v_ty_2422 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 2);
        v_t_2424 = v_ty_2422;
        break;
      }
      default: heff_nomatch(v_x1_2421);
      }
      return heff_tag_at_n(v_ru_24mf_241_24Just, TAG_Just, 1, (V[]){v_t_2424});
    }
    default: return heff_nomatch(v_mf_241);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeInt: {
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeFloat: {
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeString: {
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeRune: {
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_NoRules: {
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2evalue_2eprojTyWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eprojTyWith(a[0], a[1], a[2]);
}
V g_heff_2eelab_2evalue_2eprojTyWith_lam0(V self, V *args) {
  V v_i_2414 = args[0];
  V v_xs_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_2415 = heff_arrayIndex(v_xs_2413, v_i_2414);
  switch (heff_tag_of(v_e_2415)) {
  case TAG_Nom: {
    V v_x_2416 = heff_field(v_e_2415, 0);
    heff_take_n(v_e_2415, 1ULL, 1);
    return v_x_2416;
  }
  case TAG_Describe: {
    heff_take_n(v_e_2415, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2418 = heff_field(v_e_2415, 0);
    heff_take_n(v_e_2415, 1ULL, 1);
    return v_x_2418;
  }
  default: return heff_nomatch(v_e_2415);
  }
}
Clo g_heff_2eelab_2evalue_2eemap_24s196957333x715530534_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eemap_24s196957333x715530534_entry, 1, 0};

V g_heff_2eelab_2evalue_2eemap_24s196957333x715530534(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nom: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24Nom = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2420;
    switch (heff_tag_of(v_x_241)) {
    case TAG_VU: {
      v_t_2420 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VDecode: {
      V v_a_247 = heff_field(v_x_241, 4);
      heff_take_n(v_x_241, 16ULL, 5);
      v_t_2420 = heff_tr(heff_call(v_a_247, 1, (V[]){NTAG(TAG_MkUnit)}));
      break;
    }
    case TAG_VFunction: {
      v_t_2420 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VRecord: {
      v_t_2420 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VSum: {
      v_t_2420 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VPrimInt: {
      v_t_2420 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2420 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VPrimString: {
      v_t_2420 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VPrimRune: {
      v_t_2420 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VPrimArray: {
      v_t_2420 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VFixed: {
      v_t_2420 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Nom, TAG_Nom, 1, (V[]){v_t_2420});
  }
  case TAG_Describe: {
    V v_x_2421 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24Describe = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2440;
    switch (heff_tag_of(v_x_2421)) {
    case TAG_VU: {
      v_t_2440 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2421});
      break;
    }
    case TAG_VDecode: {
      V v_a_2427 = heff_field(v_x_2421, 4);
      heff_take_n(v_x_2421, 16ULL, 5);
      v_t_2440 = heff_tr(heff_call(v_a_2427, 1, (V[]){NTAG(TAG_MkUnit)}));
      break;
    }
    case TAG_VFunction: {
      v_t_2440 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2421});
      break;
    }
    case TAG_VRecord: {
      v_t_2440 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2421});
      break;
    }
    case TAG_VSum: {
      v_t_2440 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2421});
      break;
    }
    case TAG_VPrimInt: {
      v_t_2440 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2421});
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2440 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2421});
      break;
    }
    case TAG_VPrimString: {
      v_t_2440 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2421});
      break;
    }
    case TAG_VPrimRune: {
      v_t_2440 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2421});
      break;
    }
    case TAG_VPrimArray: {
      v_t_2440 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2421});
      break;
    }
    case TAG_VFixed: {
      v_t_2440 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2421});
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Describe, TAG_Describe, 1, (V[]){v_t_2440});
  }
  case TAG_Become: {
    V v_x_2441 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24Become = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2460;
    switch (heff_tag_of(v_x_2441)) {
    case TAG_VU: {
      v_t_2460 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2441});
      break;
    }
    case TAG_VDecode: {
      V v_a_2447 = heff_field(v_x_2441, 4);
      heff_take_n(v_x_2441, 16ULL, 5);
      v_t_2460 = heff_tr(heff_call(v_a_2447, 1, (V[]){NTAG(TAG_MkUnit)}));
      break;
    }
    case TAG_VFunction: {
      v_t_2460 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2441});
      break;
    }
    case TAG_VRecord: {
      v_t_2460 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2441});
      break;
    }
    case TAG_VSum: {
      v_t_2460 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2441});
      break;
    }
    case TAG_VPrimInt: {
      v_t_2460 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2441});
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2460 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2441});
      break;
    }
    case TAG_VPrimString: {
      v_t_2460 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2441});
      break;
    }
    case TAG_VPrimRune: {
      v_t_2460 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2441});
      break;
    }
    case TAG_VPrimArray: {
      v_t_2460 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2441});
      break;
    }
    case TAG_VFixed: {
      v_t_2460 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2441});
      break;
    }
    default: heff_nomatch(v_x_2441);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Become, TAG_Become, 1, (V[]){v_t_2460});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2evalue_2eemap_24s196957333x715530534_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eemap_24s196957333x715530534(a[0]);
}
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam0(V self, V *args); static Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam0, 1, 0};
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam1(V self, V *args);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam2(V self, V *args);
Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry, 3, 0};

V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V v_h_240, V v_spine_241, V v_desc_242) {
top: ;
  return heff_tag_n(TAG_VNeu, 5, (V[]){heff_dup(v_h_240), heff_dup(v_spine_241), ((V)&g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam0_clo), heff_clo_n(g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam1, 1, 3, (V[]){v_h_240, v_spine_241, heff_dup(v_desc_242)}), heff_clo_n(g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam2, 1, 1, (V[]){v_desc_242})});
}
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(a[0], a[1], a[2]);
}
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam0(V self, V *args) {
  V v_a_243 = args[0];
  heff_drop(v_a_243);
  return heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
}
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam1(V self, V *args) {
  V v_u_244 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_spine_241 = heff_env(self)[1];
  V v_desc_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_244);
  V v_t_245 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
  V v_t_246 = (g_heff_2eelab_2evalue_2ebehavior(v_t_245));
  switch (heff_tag_of(v_t_246)) {
  case TAG_LikeU: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_246, 0ULL, 4);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeRecord: {
    V v_capture_2413 = heff_field(v_t_246, 1);
    V v_fieldTypes_2414 = heff_field(v_t_246, 2);
    heff_take_n(v_t_246, 6ULL, 3);
    V v_t_2415 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2414, 0)));
    V v_t_2416 = heff_arrayToList(heff_take_field(v_fieldTypes_2414, 2));
    V v_t_2417 = (g_heff_2eutil_2edict_2ezipKV(v_t_2415, v_t_2416));
    V v_xs_2418 = (g_heff_2eelab_2evalue_2egoER_24s12178679x44040905(v_capture_2413, v_h_240, v_spine_241, v_desc_242, v_t_2417, NTAG(TAG_Nil)));
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
    V v_t_2420 = ({ V rv_2 = heff_arrayFromList(v_t_2419); V rr_ = heff_rec_reuse_nf(v_fieldTypes_2414, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_IntoCons, 1, (V[]){v_t_2420});
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeInt: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeFloat: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeString: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeRune: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_NoRules: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam2(V self, V *args) {
  V v_u_2424 = args[0];
  V v_desc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2424);
  return v_desc_242;
}