// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_target 1066236092
V g_co_2e_3c_2b_3e_24s1404263853x1546533042(V);
V g_co_2e_3c_2b_3e_24s1404263853x1546533042_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1404263853x1546533042_clo;
V g_heff_2ebuild_2edev_2eanswer(V, V, V, V);
V g_heff_2ebuild_2edev_2eanswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eanswer_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657_clo;
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str0, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str3, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str6, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str7, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str9, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str10, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str11, 1, "/");
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_lam1, 1, 0};
Clo g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_entry, 7, 0};

V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0(V v_lit_240, V v_st_241, V v_req_242, V v_hd_243, V v_k_244, V v_to_245, V v_x_246) {
top: ;
  if ((heff_dup(v_x_246) == NTAG(TAG_True))) {
    heff_drop(v_to_245);
    V v_t_247 = (g_co_2e_3c_2b_3e_24s1404263853x1546533042(v_lit_240));
    V v_target_248 = heff_get_n(v_req_242, 1, 6);
    V v_j_249 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str0), v_target_248, MK_INT(0LL), 5);
    V v_path_2410;
    if (heff_intLt_c_lent(v_j_249, MK_INT(0LL), 2)) {
      heff_drop(v_j_249);
      v_path_2410 = v_target_248;
    } else {
      v_path_2410 = heff_strSlice(v_target_248, MK_INT(0LL), v_j_249);
    }
    V v_s_2411 = heff_strSlice(heff_dup(v_path_2410), MK_INT(1LL), heff_strLength(v_path_2410));
    V v_t_2412 = ({ V a_0 = v_s_2411; V b_1 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str2), v_s_2411, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_2411); heff_drop(b_1); r_; });
    V v_t_2420 = (g_heff_2ebuild_2edev_2eanswer(v_t_247, ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_lam0_clo), v_st_241, v_t_2412));
    return heff_tail(v_t_2420, 2, (V[]){v_hd_243, v_k_244});
  } else {
    V v_target_2421 = heff_dup(heff_rfield(v_req_242, 1));
    V v_j_2422 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str3), v_target_2421, MK_INT(0LL), 5);
    V v_path_2423;
    if (heff_intLt_c_lent(v_j_2422, MK_INT(0LL), 2)) {
      heff_drop(v_j_2422);
      v_path_2423 = v_target_2421;
    } else {
      v_path_2423 = heff_strSlice(v_target_2421, MK_INT(0LL), v_j_2422);
    }
    V v_s_2424 = heff_strSlice(heff_dup(v_path_2423), MK_INT(1LL), heff_strLength(v_path_2423));
    V v_ps_2425 = ({ V a_0 = v_s_2424; V b_1 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str4); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str5), v_s_2424, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_2424); heff_drop(b_1); r_; });
    V v_t_2434;
    switch (heff_tag_of(v_ps_2425)) {
    case TAG_Nil: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_ps1_2426 = heff_field(v_ps_2425, 0);
      V v_ps2_2427 = heff_field(v_ps_2425, 1);
      heff_take_n(v_ps_2425, 3ULL, 2);
      if (heff_strEq_c_lent(v_ps1_2426, ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str6), 2)) {
        heff_drop(v_ps1_2426);
        switch (heff_tag_of(v_ps2_2427)) {
        case TAG_Nil: {
          v_t_2434 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          V v_ps21_2428 = heff_field(v_ps2_2427, 0);
          V v_ps22_2429 = heff_field(v_ps2_2427, 1);
          heff_take_n(v_ps2_2427, 3ULL, 2);
          if (heff_strEq_c(v_ps21_2428, ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str7))) {
            switch (heff_tag_of(v_ps22_2429)) {
            case TAG_Nil: {
              v_t_2434 = NTAG(TAG_True);
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_ps22_2429, 0ULL, 2);
              v_t_2434 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_ps22_2429);
            }
          } else {
            heff_drop(v_ps22_2429);
            v_t_2434 = NTAG(TAG_False);
          }
          break;
        }
        default: heff_nomatch(v_ps2_2427);
        }
      } else {
        if (heff_strEq_c(v_ps1_2426, ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str8))) {
          switch (heff_tag_of(v_ps2_2427)) {
          case TAG_Nil: {
            v_t_2434 = NTAG(TAG_True);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_ps2_2427, 0ULL, 2);
            v_t_2434 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_ps2_2427);
          }
        } else {
          heff_drop(v_ps2_2427);
          v_t_2434 = NTAG(TAG_False);
        }
      }
      break;
    }
    default: heff_nomatch(v_ps_2425);
    }
    if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
      heff_drop(v_to_245);
      heff_drop(v_t_2434);
      V v_t_2435 = (g_co_2e_3c_2b_3e_24s1404263853x1546533042(v_lit_240));
      V v_target_2436 = heff_get_n(v_req_242, 1, 6);
      V v_j_2437 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str9), v_target_2436, MK_INT(0LL), 5);
      V v_path_2438;
      if (heff_intLt_c_lent(v_j_2437, MK_INT(0LL), 2)) {
        heff_drop(v_j_2437);
        v_path_2438 = v_target_2436;
      } else {
        v_path_2438 = heff_strSlice(v_target_2436, MK_INT(0LL), v_j_2437);
      }
      V v_s_2439 = heff_strSlice(heff_dup(v_path_2438), MK_INT(1LL), heff_strLength(v_path_2438));
      V v_t_2440 = ({ V a_0 = v_s_2439; V b_1 = ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str10); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_str11), v_s_2439, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_2439); heff_drop(b_1); r_; });
      V v_t_2448 = (g_heff_2ebuild_2edev_2eanswer(v_t_2435, ((V)&g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_lam1_clo), v_st_241, v_t_2440));
      return heff_tail(v_t_2448, 2, (V[]){v_hd_243, v_k_244});
    } else {
      heff_drop(v_st_241);
      heff_drop(v_t_2434);
      return (g_heff_2ebuild_2edev_2eforwarded_24s669203711x681599657(v_lit_240, v_to_245, v_req_242, v_hd_243, v_k_244));
    }
  }
}
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a6); return r;
}
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_lam0(V self, V *args) {
  V v_a_2413 = args[0];
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2419});
}
V g_heff_2ebuild_2edev_2eserved_24s1804180430x884165056_2ek_24l0_lam1(V self, V *args) {
  V v_a_2441 = args[0];
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2447});
}