// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AnyByte 31114
#define TAG_Byte 63245
#define TAG_Class 54362
#define TAG_Left 13886
#define TAG_Many 40086
#define TAG_MkRegex 19093
#define TAG_Once 46274
#define TAG_Optional 11609
#define TAG_Right 62770
#define TAG_Some 35657
#define LBL_end 310101
#define LBL_pieces 958716528
#define LBL_start 311115900
static uint32_t shape_start__pieces__end[] = {LBL_start, LBL_pieces, LBL_end};
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s2020157007x2085425027(V, V);
V g_list_2eany_24s2020157007x2085425027_entry(V self, V *a);
extern Clo g_list_2eany_24s2020157007x2085425027_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
HeffT2 g_regex_2eatomAt_24cpr(V, V);
V g_regex_2ebranchOf(V);
V g_regex_2ebranchOf_entry(V self, V *a);
extern Clo g_regex_2ebranchOf_clo;
HeffT2 g_regex_2eclassAt_24cpr(V, V);
HeffT2 g_regex_2eclassByte_24cpr(V, V);
HeffT2 g_regex_2eclassFrom_24cpr(V, V, V);
V g_regex_2ematchAt(V, V, V, V);
V g_regex_2ematchAt_entry(V self, V *a);
extern Clo g_regex_2ematchAt_clo;
V g_regex_2ematches(V, V);
V g_regex_2ematches_entry(V self, V *a);
extern Clo g_regex_2ematches_clo;
HeffT2 g_regex_2epiecesFrom_24cpr(V, V, V);
HeffT2 g_regex_2erepeated_24cpr(V, V, V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
Clo g_regex_2esplitGo_clo = {{0x80000000u, K_CLO, 0}, g_regex_2esplitGo_entry, 6, 0};

V g_regex_2esplitGo(V v_box_24sep_240, V v_s_241, V v_from_242, V v_i_243, V v_inClass_244, V v_acc_245) {
  int64_t v_sep_240 = heff_unbox_word(v_box_24sep_240);
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_241, 0), heff_dup(v_i_243))) {
    heff_drop(v_inClass_244);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_241, v_from_242, v_i_243, 6), v_acc_245});
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_246));
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_241, v_i_243, 0)) == ((int64_t)92ULL))) {
      int64_t t_0 = v_sep_240;
      V t_1 = v_s_241;
      V t_2 = v_from_242;
      V t_3 = heff_intAdd(v_i_243, MK_INT(2LL));
      V t_4 = v_inClass_244;
      V t_5 = v_acc_245;
      v_sep_240 = t_0;
      v_s_241 = t_1;
      v_from_242 = t_2;
      v_i_243 = t_3;
      v_inClass_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    } else {
      if ((heff_dup(v_inClass_244) == NTAG(TAG_True))) {
        heff_drop(v_inClass_244);
        V v_t_247 = heff_bool(!(heff_unbox_word(heff_strByteAt_lent(v_s_241, v_i_243, 0)) == ((int64_t)93ULL)));
        int64_t t_0 = v_sep_240;
        V t_1 = v_s_241;
        V t_2 = v_from_242;
        V t_3 = heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL)));
        V t_4 = v_t_247;
        V t_5 = v_acc_245;
        v_sep_240 = t_0;
        v_s_241 = t_1;
        v_from_242 = t_2;
        v_i_243 = t_3;
        v_inClass_244 = t_4;
        v_acc_245 = t_5;
        goto top;
      } else {
        heff_drop(v_inClass_244);
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_241, v_i_243, 0)) == ((int64_t)91ULL))) {
          int64_t t_0 = v_sep_240;
          V t_1 = v_s_241;
          V t_2 = v_from_242;
          V t_3 = heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL)));
          V t_4 = NTAG(TAG_True);
          V t_5 = v_acc_245;
          v_sep_240 = t_0;
          v_s_241 = t_1;
          v_from_242 = t_2;
          v_i_243 = t_3;
          v_inClass_244 = t_4;
          v_acc_245 = t_5;
          goto top;
        } else {
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_241, v_i_243, 0)) == v_sep_240)) {
            V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_241, v_from_242, v_i_243, 2), v_acc_245});
            int64_t t_0 = v_sep_240;
            V t_1 = v_s_241;
            V t_2 = heff_box_word((heff_peek_word(v_i_243) + ((int64_t)1ULL)));
            V t_3 = heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL)));
            V t_4 = NTAG(TAG_False);
            V t_5 = v_t_248;
            v_sep_240 = t_0;
            v_s_241 = t_1;
            v_from_242 = t_2;
            v_i_243 = t_3;
            v_inClass_244 = t_4;
            v_acc_245 = t_5;
            goto top;
          } else {
            int64_t t_0 = v_sep_240;
            V t_1 = v_s_241;
            V t_2 = v_from_242;
            V t_3 = heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL)));
            V t_4 = NTAG(TAG_False);
            V t_5 = v_acc_245;
            v_sep_240 = t_0;
            v_s_241 = t_1;
            v_from_242 = t_2;
            v_i_243 = t_3;
            v_inClass_244 = t_4;
            v_acc_245 = t_5;
            goto top;
          }
        }
      }
    }
  }
}
V g_regex_2esplitGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_regex_2esplitGo(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
HEFF_LIT(g_regex_2eclassByte_24cpr_str0, 17, "a `[` with no `]`");
HEFF_LIT(g_regex_2eclassByte_24cpr_str1, 16, "a `\\` at the end");
HEFF_LIT(g_regex_2eclassByte_24cpr_str2, 2, "`\\");
HEFF_LIT(g_regex_2eclassByte_24cpr_str3, 58, "` is not read: escape only what is not a letter or a digit");

HeffT2 g_regex_2eclassByte_24cpr(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassByte_24cpr_str0)}});
  } else {
    if (!(heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)92ULL))) {
      V v_f_242 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strByteAt_lent(v_s_240, v_i_241, 0), heff_intAdd(v_i_241, MK_INT(1LL))});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_242}});
    } else {
      if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) {
        heff_drop(v_i_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassByte_24cpr_str1)}});
      } else {
        V v_c_243 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
        if ((((((int64_t)48ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)57ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)90ULL))) || ((((int64_t)97ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)122ULL)))))) {
          heff_drop(v_c_243);
          V v_i_244 = heff_intAdd(v_i_241, MK_INT(1LL));
          V v_t_245 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_244), heff_intAdd(v_i_244, MK_INT(1LL)));
          V v_f_246 = heff_strAppend(((V)&g_regex_2eclassByte_24cpr_str2), heff_strAppend(v_t_245, ((V)&g_regex_2eclassByte_24cpr_str3)));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
        } else {
          heff_drop(v_c_243);
          V v_t_247 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
          V v_f_248 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, heff_intAdd(v_i_241, MK_INT(2LL))});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_248}});
        }
      }
    }
  }
}
HEFF_LIT(g_regex_2eclassFrom_24cpr_str0, 17, "a `[` with no `]`");
HEFF_LIT(g_regex_2eclassFrom_24cpr_str1, 20, "an empty class, `[]`");
HEFF_LIT(g_regex_2eclassFrom_24cpr_str2, 28, "a range of a class backwards");

HeffT2 g_regex_2eclassFrom_24cpr(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    heff_drop(v_acc_242);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassFrom_24cpr_str0)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)93ULL))) {
      switch (heff_tag_of(v_acc_242)) {
      case TAG_Nil: {
        heff_drop(v_i_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassFrom_24cpr_str1)}});
      }
      case TAG_Cons: {
        V v_f_245 = heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_242, heff_intAdd(v_i_241, MK_INT(1LL))});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_245}});
      }
      default: return ((HeffT2){{heff_nomatch(v_acc_242)}});
      }
    } else {
      HeffT2 v_t_246 = (g_regex_2eclassByte_24cpr(v_s_240, v_i_241));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          heff_drop(v_acc_242);
          V v_why_249 = v_field_248;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_249}});
        } else {
          V v_it1_2410 = v_field_248;
          switch (heff_tag_of(v_it1_2410)) {
          case TAG_MkPair: {
            V v_lo_2411 = heff_field(v_it1_2410, 0);
            V v_j_2412 = heff_field(v_it1_2410, 1);
            V v_ru_24it1_2410_24MkPair = heff_take_reuse_n(v_it1_2410, 3ULL, 2);
            if ((heff_intLt_c(heff_intAdd(heff_dup(v_j_2412), MK_INT(1LL)), heff_strLength_lent(v_s_240, 0)) && ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_2412, 0)) == ((int64_t)45ULL)) && !(heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_2412), MK_INT(1LL)))) == ((int64_t)93ULL))))) {
              HeffT2 v_t_2413 = (g_regex_2eclassByte_24cpr(v_s_240, heff_intAdd(v_j_2412, MK_INT(1LL))));
              {
                V v_field_2415 = v_t_2413.f[1];
                int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
                if ((v_tag_2414 == ((int64_t)0ULL))) {
                  heff_drop(v_acc_242);
                  heff_drop(v_lo_2411);
                  heff_drop_cell(v_ru_24it1_2410_24MkPair, 2);
                  V v_why_2416 = v_field_2415;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2416}});
                } else {
                  V v_it1_2417 = v_field_2415;
                  switch (heff_tag_of(v_it1_2417)) {
                  case TAG_MkPair: {
                    V v_hi_2418 = heff_field(v_it1_2417, 0);
                    V v_k_2419 = heff_field(v_it1_2417, 1);
                    V v_ru_24it1_2417_24MkPair = heff_take_reuse_n(v_it1_2417, 3ULL, 2);
                    if (heff_intLt_c_lent(v_hi_2418, v_lo_2411, 0)) {
                      heff_drop(v_acc_242);
                      heff_drop(v_lo_2411);
                      heff_drop_cell(v_ru_24it1_2410_24MkPair, 2);
                      heff_drop(v_hi_2418);
                      heff_drop(v_k_2419);
                      heff_drop_cell(v_ru_24it1_2417_24MkPair, 2);
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassFrom_24cpr_str2)}});
                    } else {
                      V v_t_2420 = heff_tag_at_n(v_ru_24it1_2417_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24it1_2410_24MkPair, TAG_MkPair, 2, (V[]){v_lo_2411, v_hi_2418}), v_acc_242});
                      V t_0 = v_s_240;
                      V t_1 = v_k_2419;
                      V t_2 = v_t_2420;
                      v_s_240 = t_0;
                      v_i_241 = t_1;
                      v_acc_242 = t_2;
                      goto top;
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_it1_2417)}});
                  }
                }
              }
            } else {
              V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24it1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_dup(v_lo_2411), v_lo_2411}), v_acc_242});
              V t_0 = v_s_240;
              V t_1 = v_j_2412;
              V t_2 = v_t_2421;
              v_s_240 = t_0;
              v_i_241 = t_1;
              v_acc_242 = t_2;
              goto top;
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2410)}});
          }
        }
      }
    }
  }
}

HeffT2 g_regex_2eclassAt_24cpr(V v_s_240, V v_i_241) {
top: ;
  if ((heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_s_240, 0)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)94ULL)))) {
    HeffT2 v_t_242 = (g_regex_2eclassFrom_24cpr(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_Nil)));
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_why_245 = v_field_244;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_245}});
      } else {
        V v_it1_246 = v_field_244;
        switch (heff_tag_of(v_it1_246)) {
        case TAG_MkPair: {
          V v_rs_247 = heff_field(v_it1_246, 0);
          V v_j_248 = heff_field(v_it1_246, 1);
          V v_ru_24it1_246_24MkPair = heff_take_reuse_n(v_it1_246, 3ULL, 2);
          V v_t_249 = heff_tag_n(TAG_Class, 2, (V[]){NTAG(TAG_True), v_rs_247});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24it1_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_249, v_j_248})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it1_246)}});
        }
      }
    }
  } else {
    HeffT2 v_t_2410 = (g_regex_2eclassFrom_24cpr(v_s_240, v_i_241, NTAG(TAG_Nil)));
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_why_2413 = v_field_2412;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2413}});
      } else {
        V v_it1_2414 = v_field_2412;
        switch (heff_tag_of(v_it1_2414)) {
        case TAG_MkPair: {
          V v_rs_2415 = heff_field(v_it1_2414, 0);
          V v_j_2416 = heff_field(v_it1_2414, 1);
          V v_ru_24it1_2414_24MkPair = heff_take_reuse_n(v_it1_2414, 3ULL, 2);
          V v_t_2417 = heff_tag_n(TAG_Class, 2, (V[]){NTAG(TAG_False), v_rs_2415});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24it1_2414_24MkPair, TAG_MkPair, 2, (V[]){v_t_2417, v_j_2416})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it1_2414)}});
        }
      }
    }
  }
}
HEFF_LIT(g_regex_2eatomAt_24cpr_str0, 29, "groups, `(...)`, are not read");
HEFF_LIT(g_regex_2eatomAt_24cpr_str1, 27, "counts, `{n}`, are not read");
HEFF_LIT(g_regex_2eatomAt_24cpr_str2, 3, "a `");
HEFF_LIT(g_regex_2eatomAt_24cpr_str3, 34, "` with nothing before it to repeat");
HEFF_LIT(g_regex_2eatomAt_24cpr_str4, 22, "a `^` not at the start");
HEFF_LIT(g_regex_2eatomAt_24cpr_str5, 20, "a `$` not at the end");

HeffT2 g_regex_2eatomAt_24cpr(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)46ULL))) {
    V v_f_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_AnyByte), heff_intAdd(v_i_241, MK_INT(1LL))});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_242}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)91ULL))) {
      HEFF_LAST return g_regex_2eclassAt_24cpr(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)));
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)92ULL))) {
        HeffT2 v_t_243 = (g_regex_2eclassByte_24cpr(v_s_240, v_i_241));
        {
          V v_field_245 = v_t_243.f[1];
          int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
          if ((v_tag_244 == ((int64_t)0ULL))) {
            V v_why_246 = v_field_245;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_246}});
          } else {
            V v_it1_247 = v_field_245;
            switch (heff_tag_of(v_it1_247)) {
            case TAG_MkPair: {
              V v_b_248 = heff_field(v_it1_247, 0);
              V v_j_249 = heff_field(v_it1_247, 1);
              V v_ru_24it1_247_24MkPair = heff_take_reuse_n(v_it1_247, 3ULL, 2);
              V v_t_2410 = heff_tag_at_n(v_ru_24it1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Byte, 1, (V[]){v_b_248}), v_j_249});
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2410}});
            }
            default: return ((HeffT2){{heff_nomatch(v_it1_247)}});
            }
          }
        }
      } else {
        if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)40ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)41ULL)))) {
          heff_drop(v_i_241);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eatomAt_24cpr_str0)}});
        } else {
          if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)123ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)125ULL)))) {
            heff_drop(v_i_241);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eatomAt_24cpr_str1)}});
          } else {
            if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)42ULL)) || ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)43ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)63ULL))))) {
              V v_t_2411 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
              V v_f_2412 = heff_strAppend(((V)&g_regex_2eatomAt_24cpr_str2), heff_strAppend(v_t_2411, ((V)&g_regex_2eatomAt_24cpr_str3)));
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
            } else {
              if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)94ULL))) {
                heff_drop(v_i_241);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eatomAt_24cpr_str4)}});
              } else {
                if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)36ULL))) {
                  heff_drop(v_i_241);
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eatomAt_24cpr_str5)}});
                } else {
                  V v_t_2413 = heff_tag_n(TAG_Byte, 1, (V[]){heff_strByteAt_lent(v_s_240, v_i_241, 0)});
                  V v_f_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, heff_intAdd(v_i_241, MK_INT(1LL))});
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2414}});
                }
              }
            }
          }
        }
      }
    }
  }
}

HeffT2 g_regex_2erepeated_24cpr(V v_s_240, V v_a_241, V v_i_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_242))) {
    return ((HeffT2){{heff_tag_n(TAG_Once, 1, (V[]){v_a_241}), v_i_242}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)42ULL))) {
      V v_f_243 = heff_intAdd(v_i_242, MK_INT(1LL));
      return ((HeffT2){{heff_tag_n(TAG_Many, 1, (V[]){v_a_241}), v_f_243}});
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)43ULL))) {
        V v_f_244 = heff_intAdd(v_i_242, MK_INT(1LL));
        return ((HeffT2){{heff_tag_n(TAG_Some, 1, (V[]){v_a_241}), v_f_244}});
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)63ULL))) {
          V v_f_245 = heff_intAdd(v_i_242, MK_INT(1LL));
          return ((HeffT2){{heff_tag_n(TAG_Optional, 1, (V[]){v_a_241}), v_f_245}});
        } else {
          return ((HeffT2){{heff_tag_n(TAG_Once, 1, (V[]){v_a_241}), v_i_242}});
        }
      }
    }
  }
}

HeffT2 g_regex_2epiecesFrom_24cpr(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_242, NTAG(TAG_False)});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_243}});
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)36ULL)) && heff_intEq_c(heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_strLength_lent(v_s_240, 0)))) {
      heff_drop(v_i_241);
      V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_242, NTAG(TAG_True)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_244}});
    } else {
      HeffT2 v_t_245 = (g_regex_2eatomAt_24cpr(v_s_240, v_i_241));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          heff_drop(v_acc_242);
          V v_why_248 = v_field_247;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_248}});
        } else {
          V v_it1_249 = v_field_247;
          switch (heff_tag_of(v_it1_249)) {
          case TAG_MkPair: {
            V v_a_2410 = heff_field(v_it1_249, 0);
            V v_j_2411 = heff_field(v_it1_249, 1);
            V v_ru_24it1_249_24MkPair = heff_take_reuse_n(v_it1_249, 3ULL, 2);
            HeffT2 v_t_2412 = (g_regex_2erepeated_24cpr(v_s_240, v_a_2410, v_j_2411));
            {
              V v_field_2413 = v_t_2412.f[0];
              V v_field_2414 = v_t_2412.f[1];
              V v_p_2415 = v_field_2413;
              V v_k_2416 = v_field_2414;
              V t_0 = v_s_240;
              V t_1 = v_k_2416;
              V t_2 = heff_tag_at_n(v_ru_24it1_249_24MkPair, TAG_Cons, 2, (V[]){v_p_2415, v_acc_242});
              v_s_240 = t_0;
              v_i_241 = t_1;
              v_acc_242 = t_2;
              goto top;
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_249)}});
          }
        }
      }
    }
  }
}
HEFF_LIT(g_regex_2ebranchOf_str0, 1, "^");
Clo g_regex_2ebranchOf_clo = {{0x80000000u, K_CLO, 0}, g_regex_2ebranchOf_entry, 1, 0};

V g_regex_2ebranchOf(V v_b_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_b_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_regex_2ebranchOf_str0))) {
    HeffT2 v_t_241 = (g_regex_2epiecesFrom_24cpr(v_b_240, MK_INT(1LL), NTAG(TAG_Nil)));
    {
      V v_field_243 = v_t_241.f[1];
      int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
      if ((v_tag_242 == ((int64_t)0ULL))) {
        V v_why_244 = v_field_243;
        return heff_tag_n(TAG_Left, 1, (V[]){v_why_244});
      } else {
        V v_it1_245 = v_field_243;
        switch (heff_tag_of(v_it1_245)) {
        case TAG_MkPair: {
          V v_ps_246 = heff_field(v_it1_245, 0);
          V v_end_247 = heff_field(v_it1_245, 1);
          heff_take_n(v_it1_245, 3ULL, 2);
          V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_246));
          V v_t_249 = heff_rec_n(3, shape_start__pieces__end, (V[]){NTAG(TAG_True), v_t_248, v_end_247});
          return heff_tag_n(TAG_Right, 1, (V[]){v_t_249});
        }
        default: return heff_nomatch(v_it1_245);
        }
      }
    }
  } else {
    HeffT2 v_t_2410 = (g_regex_2epiecesFrom_24cpr(v_b_240, MK_INT(0LL), NTAG(TAG_Nil)));
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_why_2413 = v_field_2412;
        return heff_tag_n(TAG_Left, 1, (V[]){v_why_2413});
      } else {
        V v_it1_2414 = v_field_2412;
        switch (heff_tag_of(v_it1_2414)) {
        case TAG_MkPair: {
          V v_ps_2415 = heff_field(v_it1_2414, 0);
          V v_end_2416 = heff_field(v_it1_2414, 1);
          heff_take_n(v_it1_2414, 3ULL, 2);
          V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2415));
          V v_t_2418 = heff_rec_n(3, shape_start__pieces__end, (V[]){NTAG(TAG_False), v_t_2417, v_end_2416});
          return heff_tag_n(TAG_Right, 1, (V[]){v_t_2418});
        }
        default: return heff_nomatch(v_it1_2414);
        }
      }
    }
  }
}
V g_regex_2ebranchOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_regex_2ebranchOf(a0); heff_drop(a0); return r;
}

HeffT2 g_regex_2eallRead_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Left: {
      V v_why_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_243}});
    }
    case TAG_Right: {
      V v_x_244 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      HeffT2 v_t_245 = (g_regex_2eallRead_24cpr(v_rest_242));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_244);
          V v_why_248 = v_field_247;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_248}});
        } else {
          V v_xs_249 = v_field_247;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_xs_249})}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_regex_2ematchAt_clo = {{0x80000000u, K_CLO, 0}, g_regex_2ematchAt_entry, 4, 0};

V g_regex_2ematchAt(V v_s_240, V v_end_241, V v_x3_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    V v_ret_24bool = heff_bool(((heff_dup(v_end_241) == NTAG(TAG_True)) ? heff_intEq_c(heff_dup(v_i_243), heff_strLength_lent(v_s_240, 0)) : 1));
    heff_drop(v_i_243);
    return v_ret_24bool;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_Once: {
      V v_a_246 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      if (heff_intLt_c(heff_dup(v_i_243), heff_strLength_lent(v_s_240, 0))) {
        V v_c_247 = heff_strByteAt_lent(v_s_240, v_i_243, 0);
        switch (heff_tag_of(v_a_246)) {
        case TAG_AnyByte: {
          heff_drop(v_c_247);
          V t_0 = v_s_240;
          V t_1 = v_end_241;
          V t_2 = v_rest_245;
          V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
          v_s_240 = t_0;
          v_end_241 = t_1;
          v_x3_242 = t_2;
          v_i_243 = t_3;
          goto top;
        }
        case TAG_Byte: {
          V v_b_248 = heff_field(v_a_246, 0);
          heff_take_n(v_a_246, 1ULL, 1);
          if (heff_intEq_c(v_b_248, v_c_247)) {
            V t_0 = v_s_240;
            V t_1 = v_end_241;
            V t_2 = v_rest_245;
            V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
            v_s_240 = t_0;
            v_end_241 = t_1;
            v_x3_242 = t_2;
            v_i_243 = t_3;
            goto top;
          } else {
            heff_drop(v_i_243);
            heff_drop(v_rest_245);
            return NTAG(TAG_False);
          }
        }
        case TAG_Class: {
          V v_x11_249 = heff_field(v_a_246, 0);
          V v_rs_2410 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_2412;
          if ((heff_dup(v_x11_249) == NTAG(TAG_True))) {
            heff_drop(v_x11_249);
            V v_x1_2411 = ({ V a_0 = v_c_247; V a_1 = v_rs_2410; V r_ = (g_list_2eany_24s2020157007x2085425027(a_0, a_1)); heff_drop(v_rs_2410); r_; });
            v_t_2412 = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
            heff_drop(v_x1_2411);
          } else {
            heff_drop(v_x11_249);
            v_t_2412 = ({ V a_0 = v_c_247; V a_1 = v_rs_2410; V r_ = (g_list_2eany_24s2020157007x2085425027(a_0, a_1)); heff_drop(v_rs_2410); r_; });
          }
          if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
            heff_drop(v_t_2412);
            V t_0 = v_s_240;
            V t_1 = v_end_241;
            V t_2 = v_rest_245;
            V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
            v_s_240 = t_0;
            v_end_241 = t_1;
            v_x3_242 = t_2;
            v_i_243 = t_3;
            goto top;
          } else {
            heff_drop(v_i_243);
            heff_drop(v_rest_245);
            heff_drop(v_t_2412);
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_a_246);
        }
      } else {
        heff_drop(v_i_243);
        heff_drop(v_rest_245);
        heff_drop(v_a_246);
        return NTAG(TAG_False);
      }
    }
    case TAG_Optional: {
      V v_a_2413 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      if (heff_intLt_c(heff_dup(v_i_243), heff_strLength_lent(v_s_240, 0))) {
        V v_c_2414 = heff_strByteAt_lent(v_s_240, v_i_243, 0);
        switch (heff_tag_of(v_a_2413)) {
        case TAG_AnyByte: {
          heff_drop(v_c_2414);
          V v_t_2415 = (g_regex_2ematchAt(v_s_240, v_end_241, heff_dup(v_rest_245), heff_intAdd(heff_dup(v_i_243), MK_INT(1LL))));
          if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
            heff_drop(v_i_243);
            heff_drop(v_rest_245);
            heff_drop(v_t_2415);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_2415);
            V t_0 = v_s_240;
            V t_1 = v_end_241;
            V t_2 = v_rest_245;
            V t_3 = v_i_243;
            v_s_240 = t_0;
            v_end_241 = t_1;
            v_x3_242 = t_2;
            v_i_243 = t_3;
            goto top;
          }
        }
        case TAG_Byte: {
          V v_b_2416 = heff_field(v_a_2413, 0);
          heff_take_n(v_a_2413, 1ULL, 1);
          if (heff_intEq_c(v_b_2416, v_c_2414)) {
            V v_t_2417 = (g_regex_2ematchAt(v_s_240, v_end_241, heff_dup(v_rest_245), heff_intAdd(heff_dup(v_i_243), MK_INT(1LL))));
            if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
              heff_drop(v_i_243);
              heff_drop(v_rest_245);
              heff_drop(v_t_2417);
              return NTAG(TAG_True);
            } else {
              heff_drop(v_t_2417);
              V t_0 = v_s_240;
              V t_1 = v_end_241;
              V t_2 = v_rest_245;
              V t_3 = v_i_243;
              v_s_240 = t_0;
              v_end_241 = t_1;
              v_x3_242 = t_2;
              v_i_243 = t_3;
              goto top;
            }
          } else {
            V t_0 = v_s_240;
            V t_1 = v_end_241;
            V t_2 = v_rest_245;
            V t_3 = v_i_243;
            v_s_240 = t_0;
            v_end_241 = t_1;
            v_x3_242 = t_2;
            v_i_243 = t_3;
            goto top;
          }
        }
        case TAG_Class: {
          V v_x11_2418 = heff_field(v_a_2413, 0);
          V v_rs_2419 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          V v_t_2421;
          if ((heff_dup(v_x11_2418) == NTAG(TAG_True))) {
            heff_drop(v_x11_2418);
            V v_x1_2420 = ({ V a_0 = v_c_2414; V a_1 = v_rs_2419; V r_ = (g_list_2eany_24s2020157007x2085425027(a_0, a_1)); heff_drop(v_rs_2419); r_; });
            v_t_2421 = heff_bool(!(heff_dup(v_x1_2420) == NTAG(TAG_True)));
            heff_drop(v_x1_2420);
          } else {
            heff_drop(v_x11_2418);
            v_t_2421 = ({ V a_0 = v_c_2414; V a_1 = v_rs_2419; V r_ = (g_list_2eany_24s2020157007x2085425027(a_0, a_1)); heff_drop(v_rs_2419); r_; });
          }
          if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
            heff_drop(v_t_2421);
            V v_t_2422 = (g_regex_2ematchAt(v_s_240, v_end_241, heff_dup(v_rest_245), heff_intAdd(heff_dup(v_i_243), MK_INT(1LL))));
            if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
              heff_drop(v_i_243);
              heff_drop(v_rest_245);
              heff_drop(v_t_2422);
              return NTAG(TAG_True);
            } else {
              heff_drop(v_t_2422);
              V t_0 = v_s_240;
              V t_1 = v_end_241;
              V t_2 = v_rest_245;
              V t_3 = v_i_243;
              v_s_240 = t_0;
              v_end_241 = t_1;
              v_x3_242 = t_2;
              v_i_243 = t_3;
              goto top;
            }
          } else {
            heff_drop(v_t_2421);
            V t_0 = v_s_240;
            V t_1 = v_end_241;
            V t_2 = v_rest_245;
            V t_3 = v_i_243;
            v_s_240 = t_0;
            v_end_241 = t_1;
            v_x3_242 = t_2;
            v_i_243 = t_3;
            goto top;
          }
        }
        default: return heff_nomatch(v_a_2413);
        }
      } else {
        heff_drop(v_a_2413);
        V t_0 = v_s_240;
        V t_1 = v_end_241;
        V t_2 = v_rest_245;
        V t_3 = v_i_243;
        v_s_240 = t_0;
        v_end_241 = t_1;
        v_x3_242 = t_2;
        v_i_243 = t_3;
        goto top;
      }
    }
    case TAG_Many: {
      V v_a_2423 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      V v_t_2424 = (g_regex_2ematchAt(v_s_240, v_end_241, heff_dup(v_rest_245), heff_dup(v_i_243)));
      if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
        heff_drop(v_i_243);
        heff_drop(v_rest_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_a_2423);
        heff_drop(v_t_2424);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2424);
        if (heff_intLt_c(heff_dup(v_i_243), heff_strLength_lent(v_s_240, 0))) {
          V v_c_2425 = heff_strByteAt_lent(v_s_240, v_i_243, 0);
          switch (heff_tag_of(v_a_2423)) {
          case TAG_AnyByte: {
            heff_drop(v_c_2425);
            V v_t_2426 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Many, 1, (V[]){v_a_2423}), v_rest_245});
            V t_0 = v_s_240;
            V t_1 = v_end_241;
            V t_2 = v_t_2426;
            V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
            v_s_240 = t_0;
            v_end_241 = t_1;
            v_x3_242 = t_2;
            v_i_243 = t_3;
            goto top;
          }
          case TAG_Byte: {
            V v_b_2427 = heff_dup(heff_field(v_a_2423, 0));
            if (heff_intEq_c(v_b_2427, v_c_2425)) {
              V v_t_2428 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Many, 1, (V[]){v_a_2423}), v_rest_245});
              V t_0 = v_s_240;
              V t_1 = v_end_241;
              V t_2 = v_t_2428;
              V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
              v_s_240 = t_0;
              v_end_241 = t_1;
              v_x3_242 = t_2;
              v_i_243 = t_3;
              goto top;
            } else {
              heff_drop(v_i_243);
              heff_drop(v_rest_245);
              heff_drop_cell(v_ru_24x3_242_24Cons, 2);
              heff_drop_tag(v_a_2423, 1);
              return NTAG(TAG_False);
            }
          }
          case TAG_Class: {
            V v_x11_2429 = heff_dup(heff_field(v_a_2423, 0));
            V v_rs_2430 = heff_dup(heff_field(v_a_2423, 1));
            V v_t_2432;
            if ((heff_dup(v_x11_2429) == NTAG(TAG_True))) {
              heff_drop(v_x11_2429);
              V v_x1_2431 = ({ V a_0 = v_c_2425; V a_1 = v_rs_2430; V r_ = (g_list_2eany_24s2020157007x2085425027(a_0, a_1)); heff_drop(v_rs_2430); r_; });
              v_t_2432 = heff_bool(!(heff_dup(v_x1_2431) == NTAG(TAG_True)));
              heff_drop(v_x1_2431);
            } else {
              heff_drop(v_x11_2429);
              v_t_2432 = ({ V a_0 = v_c_2425; V a_1 = v_rs_2430; V r_ = (g_list_2eany_24s2020157007x2085425027(a_0, a_1)); heff_drop(v_rs_2430); r_; });
            }
            if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
              heff_drop(v_t_2432);
              V v_t_2433 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Many, 1, (V[]){v_a_2423}), v_rest_245});
              V t_0 = v_s_240;
              V t_1 = v_end_241;
              V t_2 = v_t_2433;
              V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
              v_s_240 = t_0;
              v_end_241 = t_1;
              v_x3_242 = t_2;
              v_i_243 = t_3;
              goto top;
            } else {
              heff_drop(v_i_243);
              heff_drop(v_rest_245);
              heff_drop_cell(v_ru_24x3_242_24Cons, 2);
              heff_drop_tag(v_a_2423, 2);
              heff_drop(v_t_2432);
              return NTAG(TAG_False);
            }
          }
          default: return heff_nomatch(v_a_2423);
          }
        } else {
          heff_drop(v_i_243);
          heff_drop(v_rest_245);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop(v_a_2423);
          return NTAG(TAG_False);
        }
      }
    }
    case TAG_Some: {
      V v_a_2434 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      if (heff_intLt_c(heff_dup(v_i_243), heff_strLength_lent(v_s_240, 0))) {
        V v_c_2435 = heff_strByteAt_lent(v_s_240, v_i_243, 0);
        switch (heff_tag_of(v_a_2434)) {
        case TAG_AnyByte: {
          heff_drop(v_c_2435);
          V v_t_2436 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Many, 1, (V[]){v_a_2434}), v_rest_245});
          V t_0 = v_s_240;
          V t_1 = v_end_241;
          V t_2 = v_t_2436;
          V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
          v_s_240 = t_0;
          v_end_241 = t_1;
          v_x3_242 = t_2;
          v_i_243 = t_3;
          goto top;
        }
        case TAG_Byte: {
          V v_b_2437 = heff_dup(heff_field(v_a_2434, 0));
          if (heff_intEq_c(v_b_2437, v_c_2435)) {
            V v_t_2438 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Many, 1, (V[]){v_a_2434}), v_rest_245});
            V t_0 = v_s_240;
            V t_1 = v_end_241;
            V t_2 = v_t_2438;
            V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
            v_s_240 = t_0;
            v_end_241 = t_1;
            v_x3_242 = t_2;
            v_i_243 = t_3;
            goto top;
          } else {
            heff_drop(v_i_243);
            heff_drop(v_rest_245);
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            heff_drop_tag(v_a_2434, 1);
            return NTAG(TAG_False);
          }
        }
        case TAG_Class: {
          V v_x11_2439 = heff_dup(heff_field(v_a_2434, 0));
          V v_rs_2440 = heff_dup(heff_field(v_a_2434, 1));
          V v_t_2442;
          if ((heff_dup(v_x11_2439) == NTAG(TAG_True))) {
            heff_drop(v_x11_2439);
            V v_x1_2441 = ({ V a_0 = v_c_2435; V a_1 = v_rs_2440; V r_ = (g_list_2eany_24s2020157007x2085425027(a_0, a_1)); heff_drop(v_rs_2440); r_; });
            v_t_2442 = heff_bool(!(heff_dup(v_x1_2441) == NTAG(TAG_True)));
            heff_drop(v_x1_2441);
          } else {
            heff_drop(v_x11_2439);
            v_t_2442 = ({ V a_0 = v_c_2435; V a_1 = v_rs_2440; V r_ = (g_list_2eany_24s2020157007x2085425027(a_0, a_1)); heff_drop(v_rs_2440); r_; });
          }
          if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
            heff_drop(v_t_2442);
            V v_t_2443 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Many, 1, (V[]){v_a_2434}), v_rest_245});
            V t_0 = v_s_240;
            V t_1 = v_end_241;
            V t_2 = v_t_2443;
            V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
            v_s_240 = t_0;
            v_end_241 = t_1;
            v_x3_242 = t_2;
            v_i_243 = t_3;
            goto top;
          } else {
            heff_drop(v_i_243);
            heff_drop(v_rest_245);
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            heff_drop_tag(v_a_2434, 2);
            heff_drop(v_t_2442);
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_a_2434);
        }
      } else {
        heff_drop(v_i_243);
        heff_drop(v_rest_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_a_2434);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_regex_2ematchAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_regex_2ematchAt(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_regex_2ematches_lam1(V self, V *args);
V g_regex_2ematches_lam0(V self, V *args);
Clo g_regex_2ematches_clo = {{0x80000000u, K_CLO, 0}, g_regex_2ematches_entry, 2, 0};

V g_regex_2ematches(V v_x1_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkRegex: {
    V v_bs_242 = heff_field(v_x1_240, 0);
    HEFF_LAST return g_list_2eany(heff_clo_n(g_regex_2ematches_lam0, 1, 1, (V[]){heff_dup(v_s_241)}), v_bs_242);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_regex_2ematches_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_regex_2ematches(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_regex_2ematches_lam1(V self, V *args) {
  V v_i_248 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_end_245 = heff_env(self)[1];
  V v_pieces_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_s_241; V a_1 = v_end_245; V a_2 = v_pieces_246; V a_3 = v_i_248; V r_ = (g_regex_2ematchAt(a_0, a_1, a_2, a_3)); heff_drop(v_s_241); heff_drop(v_end_245); r_; });
}
V g_regex_2ematches_lam0(V self, V *args) {
  V v_b_243 = args[0];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_start_244 = heff_take_field(v_b_243, 0);
  V v_end_245 = heff_take_field(v_b_243, 2);
  V v_pieces_246 = heff_get_n(v_b_243, 1, 3);
  if ((heff_dup(v_start_244) == NTAG(TAG_True))) {
    heff_drop(v_start_244);
    return ({ V a_0 = v_s_241; V a_1 = v_end_245; V a_2 = v_pieces_246; V a_3 = MK_INT(0LL); V r_ = (g_regex_2ematchAt(a_0, a_1, a_2, a_3)); heff_drop(v_s_241); heff_drop(v_end_245); r_; });
  } else {
    heff_drop(v_start_244);
    V v_t_247 = (g_list_2erange(MK_INT(0LL), heff_strLength_lent(v_s_241, 0)));
    return ({ V a_0 = heff_clo_n(g_regex_2ematches_lam1, 1, 3, (V[]){v_s_241, v_end_245, v_pieces_246}); V a_1 = v_t_247; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_247); r_; });
  }
}