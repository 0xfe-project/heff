// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AnyByte 31114
#define TAG_Byte 63245
#define TAG_Class 54362
#define TAG_Left 13886
#define TAG_Many 40086
#define TAG_MkRegex 19093
#define TAG_Once 46274
#define TAG_Optional 11609
#define TAG_Right 62770
#define TAG_Some 35657
#define LBL_end 310101
#define LBL_pieces 958716528
#define LBL_start 311115900
static uint32_t shape_start__pieces__end[] = {LBL_start, LBL_pieces, LBL_end};
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s699755384x414427986(V, V);
V g_list_2eany_24s699755384x414427986_entry(V self, V *a);
extern Clo g_list_2eany_24s699755384x414427986_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
HeffT2 g_regex_2eatomAt_24cpr(V, V);
V g_regex_2eatomOn(V, V, V);
V g_regex_2eatomOn_entry(V self, V *a);
extern Clo g_regex_2eatomOn_clo;
V g_regex_2ebranchOf(V);
V g_regex_2ebranchOf_entry(V self, V *a);
extern Clo g_regex_2ebranchOf_clo;
HeffT2 g_regex_2eclassAt_24cpr(V, V);
HeffT2 g_regex_2eclassByte_24cpr(V, V);
HeffT2 g_regex_2eclassFrom_24cpr(V, V, V);
V g_regex_2eisLetterOrDigit(V);
V g_regex_2eisLetterOrDigit_entry(V self, V *a);
extern Clo g_regex_2eisLetterOrDigit_clo;
V g_regex_2ematchAt(V, V, V, V);
V g_regex_2ematchAt_entry(V self, V *a);
extern Clo g_regex_2ematchAt_clo;
V g_regex_2ematches(V, V);
V g_regex_2ematches_entry(V self, V *a);
extern Clo g_regex_2ematches_clo;
HeffT2 g_regex_2epiecesFrom_24cpr(V, V, V);
HeffT2 g_regex_2erepeated_24cpr(V, V, V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
Clo g_regex_2eisLetterOrDigit_clo = {{0x80000000u, K_CLO, 0}, g_regex_2eisLetterOrDigit_entry, 1, 0};

V g_regex_2eisLetterOrDigit(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_ret_24bool = heff_bool(((((int64_t)48ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)57ULL)) || ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)97ULL) <= v_c_240) && (v_c_240 <= ((int64_t)122ULL)))) : ((((int64_t)97ULL) <= v_c_240) && heff_intLe_c(heff_box_word(v_c_240), MK_INT(122LL))))) : ((((int64_t)65ULL) <= v_c_240) ? (heff_intLe_c(heff_box_word(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(97LL), heff_box_word(v_c_240)) && heff_intLe_c(heff_box_word(v_c_240), MK_INT(122LL)))) : ((((int64_t)97ULL) <= v_c_240) && heff_intLe_c(heff_box_word(v_c_240), MK_INT(122LL))))));
  return v_ret_24bool;
}
V g_regex_2eisLetterOrDigit_entry(V self, V *a) {
  (void)self;
  return g_regex_2eisLetterOrDigit(a[0]);
}
Clo g_regex_2esplitGo_clo = {{0x80000000u, K_CLO, 0}, g_regex_2esplitGo_entry, 6, 0};

V g_regex_2esplitGo(V v_box_24sep_240, V v_s_241, V v_from_242, V v_i_243, V v_inClass_244, V v_acc_245) {
  int64_t v_sep_240 = heff_unbox_word(v_box_24sep_240);
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_241, 0), heff_dup(v_i_243))) {
    heff_drop(v_inClass_244);
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_241, v_from_242, v_i_243, 6), v_acc_245});
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_247));
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_241, v_i_243, 0)) == ((int64_t)92ULL))) {
      int64_t t_0 = v_sep_240;
      V t_1 = v_s_241;
      V t_2 = v_from_242;
      V t_3 = heff_intAdd(v_i_243, MK_INT(2LL));
      V t_4 = v_inClass_244;
      V t_5 = v_acc_245;
      v_sep_240 = t_0;
      v_s_241 = t_1;
      v_from_242 = t_2;
      v_i_243 = t_3;
      v_inClass_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    } else {
      if ((heff_dup(v_inClass_244) == NTAG(TAG_True))) {
        heff_drop(v_inClass_244);
        V v_t_2410 = heff_bool(!(heff_unbox_word(heff_strByteAt_lent(v_s_241, v_i_243, 0)) == ((int64_t)93ULL)));
        int64_t t_0 = v_sep_240;
        V t_1 = v_s_241;
        V t_2 = v_from_242;
        V t_3 = heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL)));
        V t_4 = v_t_2410;
        V t_5 = v_acc_245;
        v_sep_240 = t_0;
        v_s_241 = t_1;
        v_from_242 = t_2;
        v_i_243 = t_3;
        v_inClass_244 = t_4;
        v_acc_245 = t_5;
        goto top;
      } else {
        heff_drop(v_inClass_244);
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_241, v_i_243, 0)) == ((int64_t)91ULL))) {
          int64_t t_0 = v_sep_240;
          V t_1 = v_s_241;
          V t_2 = v_from_242;
          V t_3 = heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL)));
          V t_4 = NTAG(TAG_True);
          V t_5 = v_acc_245;
          v_sep_240 = t_0;
          v_s_241 = t_1;
          v_from_242 = t_2;
          v_i_243 = t_3;
          v_inClass_244 = t_4;
          v_acc_245 = t_5;
          goto top;
        } else {
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_241, v_i_243, 0)) == v_sep_240)) {
            V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_241, v_from_242, v_i_243, 2), v_acc_245});
            int64_t t_0 = v_sep_240;
            V t_1 = v_s_241;
            V t_2 = heff_box_word((heff_peek_word(v_i_243) + ((int64_t)1ULL)));
            V t_3 = heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL)));
            V t_4 = NTAG(TAG_False);
            V t_5 = v_t_2413;
            v_sep_240 = t_0;
            v_s_241 = t_1;
            v_from_242 = t_2;
            v_i_243 = t_3;
            v_inClass_244 = t_4;
            v_acc_245 = t_5;
            goto top;
          } else {
            int64_t t_0 = v_sep_240;
            V t_1 = v_s_241;
            V t_2 = v_from_242;
            V t_3 = heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL)));
            V t_4 = NTAG(TAG_False);
            V t_5 = v_acc_245;
            v_sep_240 = t_0;
            v_s_241 = t_1;
            v_from_242 = t_2;
            v_i_243 = t_3;
            v_inClass_244 = t_4;
            v_acc_245 = t_5;
            goto top;
          }
        }
      }
    }
  }
}
V g_regex_2esplitGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_regex_2esplitGo(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
HEFF_LIT(g_regex_2eclassByte_24cpr_str0, 17, "a `[` with no `]`");
HEFF_LIT(g_regex_2eclassByte_24cpr_str1, 16, "a `\\` at the end");
HEFF_LIT(g_regex_2eclassByte_24cpr_str2, 2, "`\\");
HEFF_LIT(g_regex_2eclassByte_24cpr_str3, 58, "` is not read: escape only what is not a letter or a digit");

HeffT2 g_regex_2eclassByte_24cpr(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassByte_24cpr_str0)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)92ULL))) {
      if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) {
        heff_drop(v_i_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassByte_24cpr_str1)}});
      } else {
        V v_t_245 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
        V v_t_246 = (g_regex_2eisLetterOrDigit(v_t_245));
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          V v_i_247 = heff_intAdd(v_i_241, MK_INT(1LL));
          V v_t_248 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_247), heff_intAdd(v_i_247, MK_INT(1LL)));
          V v_f_249 = heff_strAppend(((V)&g_regex_2eclassByte_24cpr_str2), heff_strAppend(v_t_248, ((V)&g_regex_2eclassByte_24cpr_str3)));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
        } else {
          heff_drop(v_t_246);
          V v_t_2410 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
          V v_f_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, heff_intAdd(v_i_241, MK_INT(2LL))});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2411}});
        }
      }
    } else {
      V v_f_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strByteAt_lent(v_s_240, v_i_241, 0), heff_intAdd(v_i_241, MK_INT(1LL))});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2412}});
    }
  }
}
HEFF_LIT(g_regex_2eclassFrom_24cpr_str0, 17, "a `[` with no `]`");
HEFF_LIT(g_regex_2eclassFrom_24cpr_str1, 20, "an empty class, `[]`");
HEFF_LIT(g_regex_2eclassFrom_24cpr_str2, 28, "a range of a class backwards");

HeffT2 g_regex_2eclassFrom_24cpr(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    heff_drop(v_acc_242);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassFrom_24cpr_str0)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)93ULL))) {
      switch (heff_tag_of(v_acc_242)) {
      case TAG_Nil: {
        heff_drop(v_i_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassFrom_24cpr_str1)}});
      }
      case TAG_Cons: {
        V v_f_247 = heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_242, heff_intAdd(v_i_241, MK_INT(1LL))});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_247}});
      }
      default: return ((HeffT2){{heff_nomatch(v_acc_242)}});
      }
    } else {
      HeffT2 v_t_248 = (g_regex_2eclassByte_24cpr(v_s_240, v_i_241));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          heff_drop(v_acc_242);
          V v_why_2412 = v_field_2410;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2412}});
        } else {
          V v_it1_2413 = v_field_2410;
          switch (heff_tag_of(v_it1_2413)) {
          case TAG_MkPair: {
            V v_lo_2414 = heff_field(v_it1_2413, 0);
            V v_j_2415 = heff_field(v_it1_2413, 1);
            V v_ru_24it1_2413_24MkPair = heff_take_reuse_n(v_it1_2413, 3ULL, 2);
            if (heff_intLt_c(heff_intAdd(heff_dup(v_j_2415), MK_INT(1LL)), heff_strLength_lent(v_s_240, 0))) {
              if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_2415, 0)) == ((int64_t)45ULL))) {
                V v_t_2418 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_2415), MK_INT(1LL)));
                if ((heff_unbox_word(v_t_2418) == ((int64_t)93ULL))) {
                  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24it1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_dup(v_lo_2414), v_lo_2414}), v_acc_242});
                  V t_0 = v_s_240;
                  V t_1 = v_j_2415;
                  V t_2 = v_t_2420;
                  v_s_240 = t_0;
                  v_i_241 = t_1;
                  v_acc_242 = t_2;
                  goto top;
                } else {
                  HeffT2 v_t_2421 = (g_regex_2eclassByte_24cpr(v_s_240, heff_intAdd(v_j_2415, MK_INT(1LL))));
                  {
                    V v_field_2423 = v_t_2421.f[1];
                    int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
                    if ((v_tag_2422 == ((int64_t)0ULL))) {
                      heff_drop(v_acc_242);
                      heff_drop(v_lo_2414);
                      heff_drop_cell(v_ru_24it1_2413_24MkPair, 2);
                      V v_why_2425 = v_field_2423;
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2425}});
                    } else {
                      V v_it1_2426 = v_field_2423;
                      switch (heff_tag_of(v_it1_2426)) {
                      case TAG_MkPair: {
                        V v_hi_2427 = heff_field(v_it1_2426, 0);
                        V v_k_2428 = heff_field(v_it1_2426, 1);
                        V v_ru_24it1_2426_24MkPair = heff_take_reuse_n(v_it1_2426, 3ULL, 2);
                        if (heff_intLt_c_lent(v_hi_2427, v_lo_2414, 0)) {
                          heff_drop(v_acc_242);
                          heff_drop(v_lo_2414);
                          heff_drop_cell(v_ru_24it1_2413_24MkPair, 2);
                          heff_drop(v_hi_2427);
                          heff_drop(v_k_2428);
                          heff_drop_cell(v_ru_24it1_2426_24MkPair, 2);
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassFrom_24cpr_str2)}});
                        } else {
                          V v_t_2430 = heff_tag_at_n(v_ru_24it1_2426_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24it1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_lo_2414, v_hi_2427}), v_acc_242});
                          V t_0 = v_s_240;
                          V t_1 = v_k_2428;
                          V t_2 = v_t_2430;
                          v_s_240 = t_0;
                          v_i_241 = t_1;
                          v_acc_242 = t_2;
                          goto top;
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_it1_2426)}});
                      }
                    }
                  }
                }
              } else {
                V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24it1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_dup(v_lo_2414), v_lo_2414}), v_acc_242});
                V t_0 = v_s_240;
                V t_1 = v_j_2415;
                V t_2 = v_t_2431;
                v_s_240 = t_0;
                v_i_241 = t_1;
                v_acc_242 = t_2;
                goto top;
              }
            } else {
              V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24it1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_dup(v_lo_2414), v_lo_2414}), v_acc_242});
              V t_0 = v_s_240;
              V t_1 = v_j_2415;
              V t_2 = v_t_2432;
              v_s_240 = t_0;
              v_i_241 = t_1;
              v_acc_242 = t_2;
              goto top;
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2413)}});
          }
        }
      }
    }
  }
}

HeffT2 g_regex_2eclassAt_24cpr(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_s_240, 0))) {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)94ULL))) {
      HeffT2 v_t_244 = (g_regex_2eclassFrom_24cpr(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_Nil)));
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          V v_why_248 = v_field_246;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_248}});
        } else {
          V v_it1_249 = v_field_246;
          switch (heff_tag_of(v_it1_249)) {
          case TAG_MkPair: {
            V v_rs_2410 = heff_field(v_it1_249, 0);
            V v_j_2411 = heff_field(v_it1_249, 1);
            V v_ru_24it1_249_24MkPair = heff_take_reuse_n(v_it1_249, 3ULL, 2);
            V v_t_2412 = heff_tag_n(TAG_Class, 2, (V[]){NTAG(TAG_True), v_rs_2410});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24it1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2412, v_j_2411})}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_249)}});
          }
        }
      }
    } else {
      HeffT2 v_t_2413 = (g_regex_2eclassFrom_24cpr(v_s_240, v_i_241, NTAG(TAG_Nil)));
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          V v_why_2417 = v_field_2415;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2417}});
        } else {
          V v_it1_2418 = v_field_2415;
          switch (heff_tag_of(v_it1_2418)) {
          case TAG_MkPair: {
            V v_rs_2419 = heff_field(v_it1_2418, 0);
            V v_j_2420 = heff_field(v_it1_2418, 1);
            V v_ru_24it1_2418_24MkPair = heff_take_reuse_n(v_it1_2418, 3ULL, 2);
            V v_t_2421 = heff_tag_n(TAG_Class, 2, (V[]){NTAG(TAG_False), v_rs_2419});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24it1_2418_24MkPair, TAG_MkPair, 2, (V[]){v_t_2421, v_j_2420})}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2418)}});
          }
        }
      }
    }
  } else {
    HeffT2 v_t_2422 = (g_regex_2eclassFrom_24cpr(v_s_240, v_i_241, NTAG(TAG_Nil)));
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        V v_why_2426 = v_field_2424;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2426}});
      } else {
        V v_it1_2427 = v_field_2424;
        switch (heff_tag_of(v_it1_2427)) {
        case TAG_MkPair: {
          V v_rs_2428 = heff_field(v_it1_2427, 0);
          V v_j_2429 = heff_field(v_it1_2427, 1);
          V v_ru_24it1_2427_24MkPair = heff_take_reuse_n(v_it1_2427, 3ULL, 2);
          V v_t_2430 = heff_tag_n(TAG_Class, 2, (V[]){NTAG(TAG_False), v_rs_2428});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24it1_2427_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_j_2429})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it1_2427)}});
        }
      }
    }
  }
}
HEFF_LIT(g_regex_2eatomAt_24cpr_str0, 29, "groups, `(...)`, are not read");
HEFF_LIT(g_regex_2eatomAt_24cpr_str1, 29, "groups, `(...)`, are not read");
HEFF_LIT(g_regex_2eatomAt_24cpr_str2, 27, "counts, `{n}`, are not read");
HEFF_LIT(g_regex_2eatomAt_24cpr_str3, 27, "counts, `{n}`, are not read");
HEFF_LIT(g_regex_2eatomAt_24cpr_str4, 3, "a `");
HEFF_LIT(g_regex_2eatomAt_24cpr_str5, 34, "` with nothing before it to repeat");
HEFF_LIT(g_regex_2eatomAt_24cpr_str6, 3, "a `");
HEFF_LIT(g_regex_2eatomAt_24cpr_str7, 34, "` with nothing before it to repeat");
HEFF_LIT(g_regex_2eatomAt_24cpr_str8, 3, "a `");
HEFF_LIT(g_regex_2eatomAt_24cpr_str9, 34, "` with nothing before it to repeat");
HEFF_LIT(g_regex_2eatomAt_24cpr_str10, 22, "a `^` not at the start");
HEFF_LIT(g_regex_2eatomAt_24cpr_str11, 20, "a `$` not at the end");

HeffT2 g_regex_2eatomAt_24cpr(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)46ULL))) {
    V v_f_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_AnyByte), heff_intAdd(v_i_241, MK_INT(1LL))});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_243}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)91ULL))) {
      HEFF_LAST return g_regex_2eclassAt_24cpr(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)));
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)92ULL))) {
        HeffT2 v_t_246 = (g_regex_2eclassByte_24cpr(v_s_240, v_i_241));
        {
          V v_field_248 = v_t_246.f[1];
          int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
          if ((v_tag_247 == ((int64_t)0ULL))) {
            V v_why_2410 = v_field_248;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2410}});
          } else {
            V v_it1_2411 = v_field_248;
            switch (heff_tag_of(v_it1_2411)) {
            case TAG_MkPair: {
              V v_b_2412 = heff_field(v_it1_2411, 0);
              V v_j_2413 = heff_field(v_it1_2411, 1);
              V v_ru_24it1_2411_24MkPair = heff_take_reuse_n(v_it1_2411, 3ULL, 2);
              V v_t_2414 = heff_tag_at_n(v_ru_24it1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Byte, 1, (V[]){v_b_2412}), v_j_2413});
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2414}});
            }
            default: return ((HeffT2){{heff_nomatch(v_it1_2411)}});
            }
          }
        }
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)40ULL))) {
          heff_drop(v_i_241);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eatomAt_24cpr_str0)}});
        } else {
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)41ULL))) {
            heff_drop(v_i_241);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eatomAt_24cpr_str1)}});
          } else {
            if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)123ULL))) {
              heff_drop(v_i_241);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eatomAt_24cpr_str2)}});
            } else {
              if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)125ULL))) {
                heff_drop(v_i_241);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eatomAt_24cpr_str3)}});
              } else {
                if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)42ULL))) {
                  V v_t_2420 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
                  V v_f_2421 = heff_strAppend(((V)&g_regex_2eatomAt_24cpr_str4), heff_strAppend(v_t_2420, ((V)&g_regex_2eatomAt_24cpr_str5)));
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
                } else {
                  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)43ULL))) {
                    V v_t_2423 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
                    V v_f_2424 = heff_strAppend(((V)&g_regex_2eatomAt_24cpr_str6), heff_strAppend(v_t_2423, ((V)&g_regex_2eatomAt_24cpr_str7)));
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
                  } else {
                    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)63ULL))) {
                      V v_t_2426 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
                      V v_f_2427 = heff_strAppend(((V)&g_regex_2eatomAt_24cpr_str8), heff_strAppend(v_t_2426, ((V)&g_regex_2eatomAt_24cpr_str9)));
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2427}});
                    } else {
                      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)94ULL))) {
                        heff_drop(v_i_241);
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eatomAt_24cpr_str10)}});
                      } else {
                        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)36ULL))) {
                          heff_drop(v_i_241);
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eatomAt_24cpr_str11)}});
                        } else {
                          V v_t_2430 = heff_tag_n(TAG_Byte, 1, (V[]){heff_strByteAt_lent(v_s_240, v_i_241, 0)});
                          V v_f_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, heff_intAdd(v_i_241, MK_INT(1LL))});
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2431}});
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

HeffT2 g_regex_2erepeated_24cpr(V v_s_240, V v_a_241, V v_i_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_242))) {
    return ((HeffT2){{heff_tag_n(TAG_Once, 1, (V[]){v_a_241}), v_i_242}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)42ULL))) {
      V v_f_245 = heff_intAdd(v_i_242, MK_INT(1LL));
      return ((HeffT2){{heff_tag_n(TAG_Many, 1, (V[]){v_a_241}), v_f_245}});
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)43ULL))) {
        V v_f_247 = heff_intAdd(v_i_242, MK_INT(1LL));
        return ((HeffT2){{heff_tag_n(TAG_Some, 1, (V[]){v_a_241}), v_f_247}});
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)63ULL))) {
          V v_f_249 = heff_intAdd(v_i_242, MK_INT(1LL));
          return ((HeffT2){{heff_tag_n(TAG_Optional, 1, (V[]){v_a_241}), v_f_249}});
        } else {
          return ((HeffT2){{heff_tag_n(TAG_Once, 1, (V[]){v_a_241}), v_i_242}});
        }
      }
    }
  }
}

HeffT2 g_regex_2epiecesFrom_24cpr(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_242, NTAG(TAG_False)});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_244}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)36ULL))) {
      if (heff_intEq_c(heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_strLength_lent(v_s_240, 0))) {
        heff_drop(v_i_241);
        V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_242, NTAG(TAG_True)});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_247}});
      } else {
        HeffT2 v_t_248 = (g_regex_2eatomAt_24cpr(v_s_240, v_i_241));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            heff_drop(v_acc_242);
            V v_why_2412 = v_field_2410;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2412}});
          } else {
            V v_it1_2413 = v_field_2410;
            switch (heff_tag_of(v_it1_2413)) {
            case TAG_MkPair: {
              V v_a_2414 = heff_field(v_it1_2413, 0);
              V v_j_2415 = heff_field(v_it1_2413, 1);
              V v_ru_24it1_2413_24MkPair = heff_take_reuse_n(v_it1_2413, 3ULL, 2);
              HeffT2 v_t_2416 = (g_regex_2erepeated_24cpr(v_s_240, v_a_2414, v_j_2415));
              {
                V v_field_2417 = v_t_2416.f[0];
                V v_field_2418 = v_t_2416.f[1];
                V v_p_2419 = v_field_2417;
                V v_k_2420 = v_field_2418;
                V t_0 = v_s_240;
                V t_1 = v_k_2420;
                V t_2 = heff_tag_at_n(v_ru_24it1_2413_24MkPair, TAG_Cons, 2, (V[]){v_p_2419, v_acc_242});
                v_s_240 = t_0;
                v_i_241 = t_1;
                v_acc_242 = t_2;
                goto top;
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_it1_2413)}});
            }
          }
        }
      }
    } else {
      HeffT2 v_t_2421 = (g_regex_2eatomAt_24cpr(v_s_240, v_i_241));
      {
        V v_field_2423 = v_t_2421.f[1];
        int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
        if ((v_tag_2422 == ((int64_t)0ULL))) {
          heff_drop(v_acc_242);
          V v_why_2425 = v_field_2423;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2425}});
        } else {
          V v_it1_2426 = v_field_2423;
          switch (heff_tag_of(v_it1_2426)) {
          case TAG_MkPair: {
            V v_a_2427 = heff_field(v_it1_2426, 0);
            V v_j_2428 = heff_field(v_it1_2426, 1);
            V v_ru_24it1_2426_24MkPair = heff_take_reuse_n(v_it1_2426, 3ULL, 2);
            HeffT2 v_t_2429 = (g_regex_2erepeated_24cpr(v_s_240, v_a_2427, v_j_2428));
            {
              V v_field_2430 = v_t_2429.f[0];
              V v_field_2431 = v_t_2429.f[1];
              V v_p_2432 = v_field_2430;
              V v_k_2433 = v_field_2431;
              V t_0 = v_s_240;
              V t_1 = v_k_2433;
              V t_2 = heff_tag_at_n(v_ru_24it1_2426_24MkPair, TAG_Cons, 2, (V[]){v_p_2432, v_acc_242});
              v_s_240 = t_0;
              v_i_241 = t_1;
              v_acc_242 = t_2;
              goto top;
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2426)}});
          }
        }
      }
    }
  }
}
HEFF_LIT(g_regex_2ebranchOf_str0, 1, "^");
Clo g_regex_2ebranchOf_clo = {{0x80000000u, K_CLO, 0}, g_regex_2ebranchOf_entry, 1, 0};

V g_regex_2ebranchOf(V v_b_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_b_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_regex_2ebranchOf_str0))) {
    HeffT2 v_t_242 = (g_regex_2epiecesFrom_24cpr(v_b_240, MK_INT(1LL), NTAG(TAG_Nil)));
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_why_246 = v_field_244;
        return heff_tag_n(TAG_Left, 1, (V[]){v_why_246});
      } else {
        V v_it1_247 = v_field_244;
        switch (heff_tag_of(v_it1_247)) {
        case TAG_MkPair: {
          V v_ps_248 = heff_field(v_it1_247, 0);
          V v_end_249 = heff_field(v_it1_247, 1);
          heff_take_n(v_it1_247, 3ULL, 2);
          V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
          V v_t_2411 = heff_rec_n(3, shape_start__pieces__end, (V[]){NTAG(TAG_True), v_t_2410, v_end_249});
          return heff_tag_n(TAG_Right, 1, (V[]){v_t_2411});
        }
        default: return heff_nomatch(v_it1_247);
        }
      }
    }
  } else {
    HeffT2 v_t_2412 = (g_regex_2epiecesFrom_24cpr(v_b_240, MK_INT(0LL), NTAG(TAG_Nil)));
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        V v_why_2416 = v_field_2414;
        return heff_tag_n(TAG_Left, 1, (V[]){v_why_2416});
      } else {
        V v_it1_2417 = v_field_2414;
        switch (heff_tag_of(v_it1_2417)) {
        case TAG_MkPair: {
          V v_ps_2418 = heff_field(v_it1_2417, 0);
          V v_end_2419 = heff_field(v_it1_2417, 1);
          heff_take_n(v_it1_2417, 3ULL, 2);
          V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2418));
          V v_t_2421 = heff_rec_n(3, shape_start__pieces__end, (V[]){NTAG(TAG_False), v_t_2420, v_end_2419});
          return heff_tag_n(TAG_Right, 1, (V[]){v_t_2421});
        }
        default: return heff_nomatch(v_it1_2417);
        }
      }
    }
  }
}
V g_regex_2ebranchOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_regex_2ebranchOf(a0); heff_drop(a0); return r;
}

HeffT2 g_regex_2eallRead_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Left: {
      V v_why_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_243}});
    }
    case TAG_Right: {
      V v_x_244 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      HeffT2 v_t_245 = (g_regex_2eallRead_24cpr(v_rest_242));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_244);
          V v_why_249 = v_field_247;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_249}});
        } else {
          V v_xs_2410 = v_field_247;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_xs_2410})}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_regex_2eatomOn_clo = {{0x80000000u, K_CLO, 0}, g_regex_2eatomOn_entry, 3, 0};

V g_regex_2eatomOn(V v_a_240, V v_s_241, V v_i_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_242), heff_strLength_lent(v_s_241, 0))) {
    V v_c_244 = heff_strByteAt_lent(v_s_241, v_i_242, 2);
    switch (heff_tag_of(v_a_240)) {
    case TAG_AnyByte: {
      heff_drop(v_c_244);
      return NTAG(TAG_True);
    }
    case TAG_Byte: {
      V v_b_245 = heff_field(v_a_240, 0);
      return heff_intEq_lent(v_b_245, v_c_244, 2);
    }
    case TAG_Class: {
      V v_x11_246 = heff_field(v_a_240, 0);
      V v_rs_247 = heff_field(v_a_240, 1);
      if ((heff_dup(v_x11_246) == NTAG(TAG_True))) {
        V v_x1_248 = (g_list_2eany_24s699755384x414427986(v_c_244, v_rs_247));
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_248) == NTAG(TAG_True)));
        heff_drop(v_x1_248);
        return v_ret_24bool;
      } else {
        return (g_list_2eany_24s699755384x414427986(v_c_244, v_rs_247));
      }
    }
    default: return heff_nomatch(v_a_240);
    }
  } else {
    heff_drop(v_i_242);
    return NTAG(TAG_False);
  }
}
V g_regex_2eatomOn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_regex_2eatomOn(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_regex_2ematchAt_clo = {{0x80000000u, K_CLO, 0}, g_regex_2ematchAt_entry, 4, 0};

V g_regex_2ematchAt(V v_s_240, V v_end_241, V v_x3_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    if ((heff_dup(v_end_241) == NTAG(TAG_True))) {
      return heff_intEq(v_i_243, heff_strLength_lent(v_s_240, 0));
    } else {
      heff_drop(v_i_243);
      return NTAG(TAG_True);
    }
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_Once: {
      V v_a_246 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_247 = ({ V a_0 = v_a_246; V a_1 = v_s_240; V a_2 = heff_dup(v_i_243); V r_ = (g_regex_2eatomOn(a_0, a_1, a_2)); heff_drop(v_a_246); r_; });
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V t_0 = v_s_240;
        V t_1 = v_end_241;
        V t_2 = v_rest_245;
        V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
        v_s_240 = t_0;
        v_end_241 = t_1;
        v_x3_242 = t_2;
        v_i_243 = t_3;
        goto top;
      } else {
        heff_drop(v_i_243);
        heff_drop(v_rest_245);
        heff_drop(v_t_247);
        return NTAG(TAG_False);
      }
    }
    case TAG_Optional: {
      V v_a_248 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_249 = ({ V a_0 = v_a_248; V a_1 = v_s_240; V a_2 = heff_dup(v_i_243); V r_ = (g_regex_2eatomOn(a_0, a_1, a_2)); heff_drop(v_a_248); r_; });
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        V v_t_2410 = (g_regex_2ematchAt(v_s_240, v_end_241, heff_dup(v_rest_245), heff_intAdd(heff_dup(v_i_243), MK_INT(1LL))));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_i_243);
          heff_drop(v_rest_245);
          heff_drop(v_t_2410);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2410);
          V t_0 = v_s_240;
          V t_1 = v_end_241;
          V t_2 = v_rest_245;
          V t_3 = v_i_243;
          v_s_240 = t_0;
          v_end_241 = t_1;
          v_x3_242 = t_2;
          v_i_243 = t_3;
          goto top;
        }
      } else {
        heff_drop(v_t_249);
        V t_0 = v_s_240;
        V t_1 = v_end_241;
        V t_2 = v_rest_245;
        V t_3 = v_i_243;
        v_s_240 = t_0;
        v_end_241 = t_1;
        v_x3_242 = t_2;
        v_i_243 = t_3;
        goto top;
      }
    }
    case TAG_Many: {
      V v_a_2411 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      V v_t_2412 = (g_regex_2ematchAt(v_s_240, v_end_241, heff_dup(v_rest_245), heff_dup(v_i_243)));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_i_243);
        heff_drop(v_rest_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_a_2411);
        heff_drop(v_t_2412);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2412);
        V v_t_2413 = (g_regex_2eatomOn(v_a_2411, v_s_240, heff_dup(v_i_243)));
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_t_2413);
          V v_t_2414 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Many, 1, (V[]){v_a_2411}), v_rest_245});
          V t_0 = v_s_240;
          V t_1 = v_end_241;
          V t_2 = v_t_2414;
          V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
          v_s_240 = t_0;
          v_end_241 = t_1;
          v_x3_242 = t_2;
          v_i_243 = t_3;
          goto top;
        } else {
          heff_drop(v_i_243);
          heff_drop(v_rest_245);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop(v_a_2411);
          heff_drop(v_t_2413);
          return NTAG(TAG_False);
        }
      }
    }
    case TAG_Some: {
      V v_a_2415 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      V v_t_2416 = (g_regex_2eatomOn(v_a_2415, v_s_240, heff_dup(v_i_243)));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        V v_t_2417 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Many, 1, (V[]){v_a_2415}), v_rest_245});
        V t_0 = v_s_240;
        V t_1 = v_end_241;
        V t_2 = v_t_2417;
        V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
        v_s_240 = t_0;
        v_end_241 = t_1;
        v_x3_242 = t_2;
        v_i_243 = t_3;
        goto top;
      } else {
        heff_drop(v_i_243);
        heff_drop(v_rest_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_a_2415);
        heff_drop(v_t_2416);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_regex_2ematchAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_regex_2ematchAt(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_regex_2ematches_lam1(V self, V *args);
V g_regex_2ematches_lam0(V self, V *args);
Clo g_regex_2ematches_clo = {{0x80000000u, K_CLO, 0}, g_regex_2ematches_entry, 2, 0};

V g_regex_2ematches(V v_x1_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkRegex: {
    V v_bs_242 = heff_field(v_x1_240, 0);
    HEFF_LAST return g_list_2eany(heff_clo_n(g_regex_2ematches_lam0, 1, 1, (V[]){heff_dup(v_s_241)}), v_bs_242);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_regex_2ematches_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_regex_2ematches(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_regex_2ematches_lam1(V self, V *args) {
  V v_i_246 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_b_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_s_241; V b_1 = heff_dup(heff_rfield(v_b_243, 2)); V a_2 = heff_get_n(v_b_243, 1, 3); V a_3 = v_i_246; V r_ = (g_regex_2ematchAt(a_0, b_1, a_2, a_3)); heff_drop(v_s_241); heff_drop(b_1); r_; });
}
V g_regex_2ematches_lam0(V self, V *args) {
  V v_b_243 = args[0];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_dup(heff_rfield(v_b_243, 0));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    return ({ V a_0 = v_s_241; V b_1 = heff_dup(heff_rfield(v_b_243, 2)); V a_2 = heff_get_n(v_b_243, 1, 3); V a_3 = MK_INT(0LL); V r_ = (g_regex_2ematchAt(a_0, b_1, a_2, a_3)); heff_drop(v_s_241); heff_drop(b_1); r_; });
  } else {
    heff_drop(v_t_244);
    V v_t_245 = (g_list_2erange(MK_INT(0LL), heff_strLength_lent(v_s_241, 0)));
    return ({ V a_0 = heff_clo_n(g_regex_2ematches_lam1, 1, 2, (V[]){v_s_241, v_b_243}); V a_1 = v_t_245; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_245); r_; });
  }
}