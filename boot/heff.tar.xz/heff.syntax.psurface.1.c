// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define LBL_args 9498020
#define LBL_binders 123633223
#define LBL_body 9524841
#define LBL_head 9693863
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_keys 9783995
#define LBL_names 305943394
#define LBL_values 1123329101
static uint32_t shape_im__indent[] = {LBL_im, LBL_indent};
static uint32_t shape_names__binders__body[] = {LBL_names, LBL_binders, LBL_body};
V g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439(V, V, V);
V g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_clo;
V g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_clo;
V g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_clo;
V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365(V, V, V, V, V);
V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_clo;
V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_clo;
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_clo;
V g_heff_2esyntax_2epsurface_2eformerOf(V, V, V);
V g_heff_2esyntax_2epsurface_2eformerOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eformerOf_clo;
V g_heff_2esyntax_2epsurface_2eisOperator(V);
V g_heff_2esyntax_2epsurface_2eisOperator_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eisOperator_clo;
V g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399(V, V, V, V);
V g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_clo;
V g_heff_2esyntax_2epsurface_2elambdas(V, V, V);
V g_heff_2esyntax_2epsurface_2elambdas_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2elambdas_clo;
V g_heff_2esyntax_2epsurface_2elistItems(V);
V g_heff_2esyntax_2epsurface_2elistItems_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2elistItems_clo;
V g_heff_2esyntax_2epsurface_2elocalName(V, V);
V g_heff_2esyntax_2epsurface_2elocalName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2elocalName_clo;
V g_heff_2esyntax_2epsurface_2eplainImplicits_get(void);
V g_heff_2esyntax_2epsurface_2eprimitiveOf(V);
V g_heff_2esyntax_2epsurface_2eprimitiveOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eprimitiveOf_clo;
V g_heff_2esyntax_2epsurface_2eprintSig(V, V, V, V, V);
V g_heff_2esyntax_2epsurface_2eprintSig_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eprintSig_clo;
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_clo;
V g_heff_2esyntax_2epsurface_2etypeFormer(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etypeFormer_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etypeFormer_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_heff_2eutil_2erune_2equoteBytesGo(V, V, V);
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteBytesGo_clo;
V g_heff_2eutil_2erune_2equoteGo(V, V, V);
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteGo_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str4, 1, "}");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str5, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str6, 1, "{");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str7, 1, "}");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str8, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str9, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str10, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str11, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str12, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str13, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str14, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str15, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str16, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str17, 1, "_");
Clo g_heff_2esyntax_2epsurface_2elambdas_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2elambdas_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2elambdas(V v_ys_240, V v_bs_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SLocal: {
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_244, v_e_242});
  }
  case TAG_SGlobal: {
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_246, v_e_242});
  }
  case TAG_SCode: {
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_248, v_e_242});
  }
  case TAG_SApp: {
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2411, v_e_242});
  }
  case TAG_SLam: {
    V v_e1_2412 = heff_field(v_e_242, 0);
    V v_e2_2413 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SLam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_e1_2412)) {
    case TAG_SU: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2415 = heff_field(v_e2_2413, 0);
        V v_b_2416 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2415), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2415, v_bs_241});
        V t_2 = v_b_2416;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2417 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str0), v_bs_241});
        V t_2 = v_b_2417;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SDecode: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2419 = heff_field(v_e2_2413, 0);
        V v_b_2420 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2419), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2419, v_bs_241});
        V t_2 = v_b_2420;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2421 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str1), v_bs_241});
        V t_2 = v_b_2421;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SFunction: {
      V v_e14_2425 = heff_field(v_e1_2412, 3);
      heff_take_n(v_e1_2412, 8ULL, 5);
      switch (heff_tag_of(v_e14_2425)) {
      case TAG_Expl: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2427 = heff_field(v_e2_2413, 0);
          V v_b_2428 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2427), v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2427, v_bs_241});
          V t_2 = v_b_2428;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2429 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str2), v_bs_241});
          V t_2 = v_b_2429;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      case TAG_Impl: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2430 = heff_field(v_e2_2413, 0);
          V v_b_2431 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V v_t_2432 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2elambdas_str3), heff_strAppend(heff_dup(v_x_2430), ((V)&g_heff_2esyntax_2epsurface_2elambdas_str4)));
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){v_x_2430, v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_t_2432, v_bs_241});
          V t_2 = v_b_2431;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2433 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str5), v_bs_241});
          V t_2 = v_b_2433;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      case TAG_Inst: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2434 = heff_field(v_e2_2413, 0);
          V v_b_2435 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V v_t_2436 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2elambdas_str6), heff_strAppend(heff_dup(v_x_2434), ((V)&g_heff_2esyntax_2epsurface_2elambdas_str7)));
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){v_x_2434, v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_t_2436, v_bs_241});
          V t_2 = v_b_2435;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2437 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str8), v_bs_241});
          V t_2 = v_b_2437;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      default: return heff_nomatch(v_e14_2425);
      }
    }
    case TAG_SRecord: {
      heff_take_n(v_e1_2412, 0ULL, 3);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2441 = heff_field(v_e2_2413, 0);
        V v_b_2442 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2441), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2441, v_bs_241});
        V t_2 = v_b_2442;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2443 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str9), v_bs_241});
        V t_2 = v_b_2443;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SSum: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2445 = heff_field(v_e2_2413, 0);
        V v_b_2446 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2445), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2445, v_bs_241});
        V t_2 = v_b_2446;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2447 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str10), v_bs_241});
        V t_2 = v_b_2447;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SIsTy: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2449 = heff_field(v_e2_2413, 0);
        V v_b_2450 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2449), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2449, v_bs_241});
        V t_2 = v_b_2450;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2451 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str11), v_bs_241});
        V t_2 = v_b_2451;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimInt: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2452 = heff_field(v_e2_2413, 0);
        V v_b_2453 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2452), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2452, v_bs_241});
        V t_2 = v_b_2453;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2454 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str12), v_bs_241});
        V t_2 = v_b_2454;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimFloat: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2455 = heff_field(v_e2_2413, 0);
        V v_b_2456 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2455), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2455, v_bs_241});
        V t_2 = v_b_2456;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2457 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str13), v_bs_241});
        V t_2 = v_b_2457;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimString: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2458 = heff_field(v_e2_2413, 0);
        V v_b_2459 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2458), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2458, v_bs_241});
        V t_2 = v_b_2459;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2460 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str14), v_bs_241});
        V t_2 = v_b_2460;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimRune: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2461 = heff_field(v_e2_2413, 0);
        V v_b_2462 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2461), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2461, v_bs_241});
        V t_2 = v_b_2462;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2463 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str15), v_bs_241});
        V t_2 = v_b_2463;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimArray: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2465 = heff_field(v_e2_2413, 0);
        V v_b_2466 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2465), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2465, v_bs_241});
        V t_2 = v_b_2466;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2467 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str16), v_bs_241});
        V t_2 = v_b_2467;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SFixed: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2469 = heff_field(v_e2_2413, 0);
        V v_b_2470 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2469), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2469, v_bs_241});
        V t_2 = v_b_2470;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2471 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str17), v_bs_241});
        V t_2 = v_b_2471;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    default: return heff_nomatch(v_e1_2412);
    }
  }
  case TAG_SCons: {
    V v_t_2473 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2473, v_e_242});
  }
  case TAG_SProj: {
    V v_t_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2476, v_e_242});
  }
  case TAG_STag: {
    V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2479, v_e_242});
  }
  case TAG_SMatch: {
    V v_t_2482 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2482, v_e_242});
  }
  case TAG_SSpecialize: {
    V v_t_2486 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2486, v_e_242});
  }
  case TAG_SIs: {
    V v_t_2488 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2488, v_e_242});
  }
  case TAG_SOpaque: {
    V v_t_2489 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2489, v_e_242});
  }
  case TAG_SAbandon: {
    V v_t_2490 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2490, v_e_242});
  }
  case TAG_SRec: {
    V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2492, v_e_242});
  }
  case TAG_SFix: {
    V v_t_2495 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2495, v_e_242});
  }
  case TAG_SImplicit: {
    V v_t_2498 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2498, v_e_242});
  }
  case TAG_SPrim: {
    V v_t_24100 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24100, v_e_242});
  }
  case TAG_SMetaApp: {
    V v_t_24104 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24104, v_e_242});
  }
  case TAG_SLitInt: {
    V v_t_24106 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24106, v_e_242});
  }
  case TAG_SLitFloat: {
    V v_t_24108 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24108, v_e_242});
  }
  case TAG_SLitString: {
    V v_t_24110 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24110, v_e_242});
  }
  case TAG_SLitBytes: {
    V v_t_24112 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24112, v_e_242});
  }
  case TAG_SLitRune: {
    V v_t_24114 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24114, v_e_242});
  }
  case TAG_SLitFixed: {
    V v_t_24117 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24117, v_e_242});
  }
  case TAG_SLitFloat32: {
    V v_t_24119 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24119, v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2esyntax_2epsurface_2elambdas_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2elambdas(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_str1, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_str2, 1, ")");
Clo g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146(V v_c_240, V v_p_241, V v_xs_242, V v_sp_243) {
top: ;
  V v_headArg_244 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_242), heff_dup(heff_rfield(v_sp_243, 0))));
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 0, 2);
  V v_t_246 = heff_tr(heff_call(v_t_245, 2, (V[]){heff_dup(v_xs_242), heff_dup(heff_rfield(v_sp_243, 0))}));
  V v_args_247 = (g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365(heff_dup(v_c_240), heff_dup(v_xs_242), v_t_246, MK_INT(0LL), heff_take_field(v_sp_243, 1)));
  V v_headAlone_248 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, heff_dup(v_p_241), v_xs_242, heff_get_n(v_sp_243, 0, 2)));
  switch (heff_tag_of(v_args_247)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    heff_drop(v_headArg_244);
    return v_headAlone_248;
  }
  case TAG_Cons: {
    heff_drop(v_headAlone_248);
    V v_s_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_str0); V a_1 = v_headArg_244; V a_2 = v_args_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_args_247, 2); r_; });
    if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_str1), heff_strAppend(v_s_2411, ((V)&g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_str2)));
    } else {
      return v_s_2411;
    }
  }
  default: return heff_nomatch(v_args_247);
  }
}
V g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str2, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str4, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str5, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str6, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str7, 1, ".");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str10, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str13, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str14, 1, "[");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str15, 1, "]");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str18, 3, " of");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str19, 5, "case ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str20, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str21, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str22, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str23, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str24, 5, " ~ { ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str25, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str26, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str27, 8, "<opaque>");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str28, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str29, 7, "<local>");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str30, 11, "<primitive ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str31, 1, ">");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str32, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str33, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str34, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str35, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str36, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str37, 2, "b\"");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str38, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str39, 1, "'");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str40, 1, "'");
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam0(V self, V *args);
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam1(V self, V *args);
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam2(V self, V *args);
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam3(V self, V *args);
Clo g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(V v_c_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    return ({ V a_0 = v_xs_242; V a_1 = v_i_244; V r_ = (g_heff_2esyntax_2epsurface_2elocalName(a_0, a_1)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_246 = (g_heff_2esyntax_2epsurface_2eisOperator(heff_dup(v_x_245)));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str0), heff_strAppend(v_x_245, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str1)));
    } else {
      heff_drop(v_t_246);
      return v_x_245;
    }
  }
  case TAG_SCode: {
    V v_t_247 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    return ({ V a_0 = v_c_240; V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_247; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  case TAG_SApp: {
    V v_f_248 = heff_field(v_e_243, 0);
    V v_a_249 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430(v_c_240, v_p_241, v_xs_242, heff_tag_at_n(v_ru_24e_243_24SApp, TAG_SApp, 2, (V[]){v_f_248, v_a_249}));
  }
  case TAG_SLam: {
    V v_t_2410 = heff_field(v_e_243, 0);
    V v_b_2411 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SLam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2412 = (g_heff_2esyntax_2epsurface_2elambdas(heff_dup(v_xs_242), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24e_243_24SLam, TAG_SLam, 2, (V[]){v_t_2410, v_b_2411})));
    return ({ V a_0 = v_c_240; V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2412; V r_ = (g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399(a_0, a_1, a_2, a_3)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SCons: {
    V v_d_2413 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_p_241);
    V v_t_2414 = heff_arrayToList(heff_take_field(v_d_2413, 0));
    V v_t_2415 = heff_arrayToList(heff_get_n(v_d_2413, 2, 3));
    V v_t_2416 = (g_heff_2eutil_2edict_2ezipKV(v_t_2414, v_t_2415));
    V v_x2_2421 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam0, 1, 2, (V[]){v_c_240, v_xs_242}), v_t_2416));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str4); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str5), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str6)));
  }
  case TAG_SProj: {
    V v_e2_2425 = heff_field(v_e_243, 0);
    V v_l_2426 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    heff_drop(v_p_241);
    V v_t_2427 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(2LL), v_xs_242, v_e2_2425));
    return heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str7), v_l_2426));
  }
  case TAG_STag: {
    V v_x_2428 = heff_dup(heff_field(v_e_243, 0));
    V v_ts_2429 = heff_dup(heff_field(v_e_243, 1));
    V v_t_2430 = (g_heff_2esyntax_2epsurface_2elistItems(v_e_243));
    switch (heff_tag_of(v_t_2430)) {
    case TAG_Nothing: {
      V v_t_2431 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_ts_2429)); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (heff_intEq_c(v_t_2431, MK_INT(0LL))) {
        heff_drop_rec(v_c_240, 2);
        heff_drop(v_p_241);
        heff_drop(v_xs_242);
        heff_drop(v_ts_2429);
        return v_x_2428;
      } else {
        V v_t_2434 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam1, 1, 2, (V[]){v_c_240, v_xs_242}), heff_arrayToList(v_ts_2429)));
        V v_x2_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2428, v_t_2434});
        V v_s_2438;
        switch (heff_tag_of(v_x2_2435)) {
        case TAG_Nil: {
          v_s_2438 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2436 = heff_field(v_x2_2435, 0);
          V v_xs_2437 = heff_field(v_x2_2435, 1);
          heff_take_n(v_x2_2435, 3ULL, 2);
          v_s_2438 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str9); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2435);
        }
        if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
          return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str10), heff_strAppend(v_s_2438, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str11)));
        } else {
          return v_s_2438;
        }
      }
    }
    case TAG_Just: {
      V v_items_2440 = heff_field(v_t_2430, 0);
      heff_take_n(v_t_2430, 1ULL, 1);
      heff_drop(v_p_241);
      heff_drop(v_x_2428);
      heff_drop(v_ts_2429);
      V v_x2_2442 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam2, 1, 2, (V[]){v_c_240, v_xs_242}), v_items_2440));
      V v_t_2445;
      switch (heff_tag_of(v_x2_2442)) {
      case TAG_Nil: {
        v_t_2445 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2443 = heff_field(v_x2_2442, 0);
        V v_xs_2444 = heff_field(v_x2_2442, 1);
        heff_take_n(v_x2_2442, 3ULL, 2);
        v_t_2445 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str13); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2442);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str14), heff_strAppend(v_t_2445, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str15)));
    }
    default: return heff_nomatch(v_t_2430);
    }
  }
  case TAG_SMatch: {
    V v_s_2446 = heff_field(v_e_243, 0);
    V v_cases_2447 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2448 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_242), v_s_2446));
    V v_t_2449 = heff_arrayToList(heff_take_field(v_cases_2447, 0));
    V v_t_2450 = heff_arrayToList(heff_get_n(v_cases_2447, 2, 3));
    V v_t_2451 = (g_heff_2eutil_2edict_2ezipKV(v_t_2449, v_t_2450));
    V v_x2_2455 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam3, 1, 2, (V[]){v_c_240, v_xs_242}), v_t_2451));
    V v_t_2458;
    switch (heff_tag_of(v_x2_2455)) {
    case TAG_Nil: {
      v_t_2458 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2456 = heff_field(v_x2_2455, 0);
      V v_xs_2457 = heff_field(v_x2_2455, 1);
      heff_take_n(v_x2_2455, 3ULL, 2);
      v_t_2458 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str17); V a_1 = v_x_2456; V a_2 = v_xs_2457; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2457); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2455);
    }
    V v_t_2459 = heff_strAppend(v_t_2448, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str18), v_t_2458));
    V v_s_2460 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str19), v_t_2459);
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str20), heff_strAppend(v_s_2460, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str21)));
    } else {
      return v_s_2460;
    }
  }
  case TAG_SSpecialize: {
    V v_e2_2462 = heff_field(v_e_243, 0);
    V v_x_2463 = heff_field(v_e_243, 1);
    V v_v_2464 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_2465 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_242), v_e2_2462));
    V v_t_2466 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(0LL), v_xs_242, v_v_2464));
    V v_t_2467 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str22), heff_strAppend(v_t_2466, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str23)));
    V v_t_2468 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str24), heff_strAppend(v_x_2463, v_t_2467));
    V v_s_2469 = heff_strAppend(v_t_2465, v_t_2468);
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str25), heff_strAppend(v_s_2469, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str26)));
    } else {
      return v_s_2469;
    }
  }
  case TAG_SIs: {
    V v_e2_2471 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_e2_2471;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str27);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str28);
  }
  case TAG_SRec: {
    V v_e2_2472 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_e2_2472;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_SFix: {
    V v_e2_27_2474 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_e2_27_2474)) {
    case TAG_MkAbs: {
      V v_x_2475 = heff_field(v_e2_27_2474, 0);
      heff_take_n(v_e2_27_2474, 1ULL, 2);
      return v_x_2475;
    }
    case TAG_AbsConst: {
      heff_take_n(v_e2_27_2474, 0ULL, 1);
      return ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str29);
    }
    default: return heff_nomatch(v_e2_27_2474);
    }
  }
  case TAG_SImplicit: {
    V v_e2_2479 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_e2_2479;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_SPrim: {
    V v_x_2480 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str30), heff_strAppend(v_x_2480, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str31)));
  }
  case TAG_SMetaApp: {
    V v_m_2481 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 3);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str32), heff_intShow(v_m_2481));
  }
  case TAG_SLitInt: {
    V v_i_2484 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_i_2484);
  }
  case TAG_SLitFloat: {
    V v_x_2485 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2485);
  }
  case TAG_SLitString: {
    V v_s_2486 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2487 = (g_heff_2eutil_2erune_2equoteGo(v_s_2486, MK_INT(0LL), ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str33)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str34), heff_strAppend(v_t_2487, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str35)));
  }
  case TAG_SLitBytes: {
    V v_s_2488 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2489 = (g_heff_2eutil_2erune_2equoteBytesGo(v_s_2488, MK_INT(0LL), ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str36)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str37), heff_strAppend(v_t_2489, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str38)));
  }
  case TAG_SLitRune: {
    V v_ch_2490 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2491 = (g_heff_2eutil_2erune_2equoted(v_ch_2490));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str39), heff_strAppend(v_t_2491, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str40)));
  }
  case TAG_SLitFixed: {
    V v_n_2493 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_n_2493);
  }
  case TAG_SLitFloat32: {
    V v_x_2494 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2494);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam0(V self, V *args) {
  V v_f_2417 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_l_2418 = heff_field(v_f_2417, 0);
    V v_e_2419 = heff_field(v_f_2417, 1);
    heff_take_n(v_f_2417, 3ULL, 2);
    V v_t_2420 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(0LL), v_xs_242, v_e_2419));
    return heff_strAppend(v_l_2418, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str2), v_t_2420));
  }
  default: return heff_nomatch(v_f_2417);
  }
}
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam1(V self, V *args) {
  V v_a_2433 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(2LL), v_xs_242, v_a_2433));
}
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam2(V self, V *args) {
  V v_a_2441 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(0LL), v_xs_242, v_a_2441));
}
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam3(V self, V *args) {
  V v_alt_2452 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453 = heff_intAdd(heff_take_field(v_c_240, 1), MK_INT(2LL));
  V v_t_2454 = ({ V rv_1 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_c_240, 1ULL, 2, shape_im__indent, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  return ({ V a_0 = v_t_2454; V a_1 = v_xs_242; V a_2 = v_alt_2452; V r_ = (g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439(a_0, a_1, a_2)); heff_drop(v_alt_2452); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str0, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str3, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str4, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str5, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str6, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str7, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str8, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str9, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str10, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str11, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str12, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str13, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str14, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str15, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str16, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str17, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str18, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str19, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str20, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str21, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str22, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str23, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str24, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str25, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str26, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str27, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str28, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str29, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str30, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str31, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str32, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str33, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str34, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str35, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str36, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str37, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str38, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str39, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str40, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str41, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str42, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str43, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str44, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str45, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str46, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str47, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str48, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str49, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str50, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str51, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str52, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str53, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str54, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str55, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str56, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str57, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str58, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str59, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str60, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str61, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str62, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str63, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str64, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str65, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str66, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str67, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str68, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str69, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str70, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str71, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str72, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str73, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str74, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str75, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str76, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str77, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str78, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str79, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str80, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str81, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str82, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str83, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str84, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str85, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str86, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str87, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str88, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str89, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str90, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str91, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str92, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str93, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str94, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str95, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str96, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_str97, 1, "\012");
Clo g_heff_2esyntax_2epsurface_2eprintSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eprintSig_entry, 5, 0};

V g_heff_2esyntax_2epsurface_2eprintSig(V v_im_240, V v_name_241, V v_shown_242, V v_t_243, V v_body_244) {
top: ;
  switch (heff_tag_of(v_body_244)) {
  case TAG_SLocal: {
    V v_t_246 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      V v_t_247 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str0), heff_strAppend(v_t_247, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str1)));
      V v_d_249 = heff_strAppend(v_shown_242, v_t_248);
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2411 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_2410, NTAG(TAG_Nil)));
      V v_x2_2413;
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2412 = heff_field(v_t_2411, 0);
        heff_take_n(v_t_2411, 1ULL, 1);
        v_x2_2413 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2412));
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_Nothing: {
        return v_d_249;
      }
      case TAG_Just: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        heff_take_n(v_x2_2413, 1ULL, 1);
        heff_drop(v_d_249);
        return v_x_2414;
      }
      default: return heff_nomatch(v_x2_2413);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_2416 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str2), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str3)));
      return heff_strAppend(v_shown_242, v_t_2417);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_SGlobal: {
    V v_t_2419 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_2419)) {
    case TAG_Nothing: {
      V v_t_2420 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_2421 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str4), heff_strAppend(v_t_2420, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str5)));
      V v_d_2422 = heff_strAppend(v_shown_242, v_t_2421);
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2424 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_2423, NTAG(TAG_Nil)));
      V v_x2_2426;
      switch (heff_tag_of(v_t_2424)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2425 = heff_field(v_t_2424, 0);
        heff_take_n(v_t_2424, 1ULL, 1);
        v_x2_2426 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2425));
        break;
      }
      default: heff_nomatch(v_t_2424);
      }
      switch (heff_tag_of(v_x2_2426)) {
      case TAG_Nothing: {
        return v_d_2422;
      }
      case TAG_Just: {
        V v_x_2427 = heff_field(v_x2_2426, 0);
        heff_take_n(v_x2_2426, 1ULL, 1);
        heff_drop(v_d_2422);
        return v_x_2427;
      }
      default: return heff_nomatch(v_x2_2426);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2419, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_2429 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2430 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str6), heff_strAppend(v_t_2429, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str7)));
      return heff_strAppend(v_shown_242, v_t_2430);
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  case TAG_SCode: {
    V v_t_2432 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nothing: {
      V v_t_2433 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str8), heff_strAppend(v_t_2433, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str9)));
      V v_d_2435 = heff_strAppend(v_shown_242, v_t_2434);
      V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2437 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_2436, NTAG(TAG_Nil)));
      V v_x2_2439;
      switch (heff_tag_of(v_t_2437)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2439 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2438 = heff_field(v_t_2437, 0);
        heff_take_n(v_t_2437, 1ULL, 1);
        v_x2_2439 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2438));
        break;
      }
      default: heff_nomatch(v_t_2437);
      }
      switch (heff_tag_of(v_x2_2439)) {
      case TAG_Nothing: {
        return v_d_2435;
      }
      case TAG_Just: {
        V v_x_2440 = heff_field(v_x2_2439, 0);
        heff_take_n(v_x2_2439, 1ULL, 1);
        heff_drop(v_d_2435);
        return v_x_2440;
      }
      default: return heff_nomatch(v_x2_2439);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2432, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_2442 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2443 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str10), heff_strAppend(v_t_2442, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str11)));
      return heff_strAppend(v_shown_242, v_t_2443);
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  case TAG_SApp: {
    V v_t_2446 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_2446)) {
    case TAG_Nothing: {
      V v_t_2447 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_2448 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str12), heff_strAppend(v_t_2447, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str13)));
      V v_d_2449 = heff_strAppend(v_shown_242, v_t_2448);
      V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2451 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_2450, NTAG(TAG_Nil)));
      V v_x2_2453;
      switch (heff_tag_of(v_t_2451)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2453 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2452 = heff_field(v_t_2451, 0);
        heff_take_n(v_t_2451, 1ULL, 1);
        v_x2_2453 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2452));
        break;
      }
      default: heff_nomatch(v_t_2451);
      }
      switch (heff_tag_of(v_x2_2453)) {
      case TAG_Nothing: {
        return v_d_2449;
      }
      case TAG_Just: {
        V v_x_2454 = heff_field(v_x2_2453, 0);
        heff_take_n(v_x2_2453, 1ULL, 1);
        heff_drop(v_d_2449);
        return v_x_2454;
      }
      default: return heff_nomatch(v_x2_2453);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2446, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_2456 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2457 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str14), heff_strAppend(v_t_2456, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str15)));
      return heff_strAppend(v_shown_242, v_t_2457);
    }
    default: return heff_nomatch(v_t_2446);
    }
  }
  case TAG_SLam: {
    V v_t_2460 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_2460)) {
    case TAG_Nothing: {
      V v_t_2461 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_2462 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str16), heff_strAppend(v_t_2461, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str17)));
      V v_d_2463 = heff_strAppend(v_shown_242, v_t_2462);
      V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2465 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_2464, NTAG(TAG_Nil)));
      V v_x2_2467;
      switch (heff_tag_of(v_t_2465)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2467 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2466 = heff_field(v_t_2465, 0);
        heff_take_n(v_t_2465, 1ULL, 1);
        v_x2_2467 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2466));
        break;
      }
      default: heff_nomatch(v_t_2465);
      }
      switch (heff_tag_of(v_x2_2467)) {
      case TAG_Nothing: {
        return v_d_2463;
      }
      case TAG_Just: {
        V v_x_2468 = heff_field(v_x2_2467, 0);
        heff_take_n(v_x2_2467, 1ULL, 1);
        heff_drop(v_d_2463);
        return v_x_2468;
      }
      default: return heff_nomatch(v_x2_2467);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2460, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_2470 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2471 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str18), heff_strAppend(v_t_2470, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str19)));
      return heff_strAppend(v_shown_242, v_t_2471);
    }
    default: return heff_nomatch(v_t_2460);
    }
  }
  case TAG_SCons: {
    V v_t_2473 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_2473)) {
    case TAG_Nothing: {
      V v_t_2474 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_2475 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str20), heff_strAppend(v_t_2474, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str21)));
      V v_d_2476 = heff_strAppend(v_shown_242, v_t_2475);
      V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2478 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_2477, NTAG(TAG_Nil)));
      V v_x2_2480;
      switch (heff_tag_of(v_t_2478)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2480 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2479 = heff_field(v_t_2478, 0);
        heff_take_n(v_t_2478, 1ULL, 1);
        v_x2_2480 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2479));
        break;
      }
      default: heff_nomatch(v_t_2478);
      }
      switch (heff_tag_of(v_x2_2480)) {
      case TAG_Nothing: {
        return v_d_2476;
      }
      case TAG_Just: {
        V v_x_2481 = heff_field(v_x2_2480, 0);
        heff_take_n(v_x2_2480, 1ULL, 1);
        heff_drop(v_d_2476);
        return v_x_2481;
      }
      default: return heff_nomatch(v_x2_2480);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2473, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_2483 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2484 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str22), heff_strAppend(v_t_2483, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str23)));
      return heff_strAppend(v_shown_242, v_t_2484);
    }
    default: return heff_nomatch(v_t_2473);
    }
  }
  case TAG_SProj: {
    V v_t_2487 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_2487)) {
    case TAG_Nothing: {
      V v_t_2488 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_2489 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str24), heff_strAppend(v_t_2488, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str25)));
      V v_d_2490 = heff_strAppend(v_shown_242, v_t_2489);
      V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_2492 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_2491, NTAG(TAG_Nil)));
      V v_x2_2494;
      switch (heff_tag_of(v_t_2492)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_2494 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_2493 = heff_field(v_t_2492, 0);
        heff_take_n(v_t_2492, 1ULL, 1);
        v_x2_2494 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_2493));
        break;
      }
      default: heff_nomatch(v_t_2492);
      }
      switch (heff_tag_of(v_x2_2494)) {
      case TAG_Nothing: {
        return v_d_2490;
      }
      case TAG_Just: {
        V v_x_2495 = heff_field(v_x2_2494, 0);
        heff_take_n(v_x2_2494, 1ULL, 1);
        heff_drop(v_d_2490);
        return v_x_2495;
      }
      default: return heff_nomatch(v_x2_2494);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2487, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_2497 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2498 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str26), heff_strAppend(v_t_2497, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str27)));
      return heff_strAppend(v_shown_242, v_t_2498);
    }
    default: return heff_nomatch(v_t_2487);
    }
  }
  case TAG_STag: {
    V v_t_24101 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24101)) {
    case TAG_Nothing: {
      V v_t_24102 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24103 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str28), heff_strAppend(v_t_24102, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str29)));
      V v_d_24104 = heff_strAppend(v_shown_242, v_t_24103);
      V v_t_24105 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24106 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24105, NTAG(TAG_Nil)));
      V v_x2_24108;
      switch (heff_tag_of(v_t_24106)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24108 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24107 = heff_field(v_t_24106, 0);
        heff_take_n(v_t_24106, 1ULL, 1);
        v_x2_24108 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24107));
        break;
      }
      default: heff_nomatch(v_t_24106);
      }
      switch (heff_tag_of(v_x2_24108)) {
      case TAG_Nothing: {
        return v_d_24104;
      }
      case TAG_Just: {
        V v_x_24109 = heff_field(v_x2_24108, 0);
        heff_take_n(v_x2_24108, 1ULL, 1);
        heff_drop(v_d_24104);
        return v_x_24109;
      }
      default: return heff_nomatch(v_x2_24108);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24101, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_24111 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24112 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str30), heff_strAppend(v_t_24111, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str31)));
      return heff_strAppend(v_shown_242, v_t_24112);
    }
    default: return heff_nomatch(v_t_24101);
    }
  }
  case TAG_SMatch: {
    V v_t_24115 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24115)) {
    case TAG_Nothing: {
      V v_t_24116 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24117 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str32), heff_strAppend(v_t_24116, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str33)));
      V v_d_24118 = heff_strAppend(v_shown_242, v_t_24117);
      V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24120 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24119, NTAG(TAG_Nil)));
      V v_x2_24122;
      switch (heff_tag_of(v_t_24120)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24122 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24121 = heff_field(v_t_24120, 0);
        heff_take_n(v_t_24120, 1ULL, 1);
        v_x2_24122 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24121));
        break;
      }
      default: heff_nomatch(v_t_24120);
      }
      switch (heff_tag_of(v_x2_24122)) {
      case TAG_Nothing: {
        return v_d_24118;
      }
      case TAG_Just: {
        V v_x_24123 = heff_field(v_x2_24122, 0);
        heff_take_n(v_x2_24122, 1ULL, 1);
        heff_drop(v_d_24118);
        return v_x_24123;
      }
      default: return heff_nomatch(v_x2_24122);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24115, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_24125 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24126 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str34), heff_strAppend(v_t_24125, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str35)));
      return heff_strAppend(v_shown_242, v_t_24126);
    }
    default: return heff_nomatch(v_t_24115);
    }
  }
  case TAG_SSpecialize: {
    V v_t_24130 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24130)) {
    case TAG_Nothing: {
      V v_t_24131 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24132 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str36), heff_strAppend(v_t_24131, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str37)));
      V v_d_24133 = heff_strAppend(v_shown_242, v_t_24132);
      V v_t_24134 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24135 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24134, NTAG(TAG_Nil)));
      V v_x2_24137;
      switch (heff_tag_of(v_t_24135)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24137 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24136 = heff_field(v_t_24135, 0);
        heff_take_n(v_t_24135, 1ULL, 1);
        v_x2_24137 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24136));
        break;
      }
      default: heff_nomatch(v_t_24135);
      }
      switch (heff_tag_of(v_x2_24137)) {
      case TAG_Nothing: {
        return v_d_24133;
      }
      case TAG_Just: {
        V v_x_24138 = heff_field(v_x2_24137, 0);
        heff_take_n(v_x2_24137, 1ULL, 1);
        heff_drop(v_d_24133);
        return v_x_24138;
      }
      default: return heff_nomatch(v_x2_24137);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24130, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 3);
      V v_t_24140 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24141 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str38), heff_strAppend(v_t_24140, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str39)));
      return heff_strAppend(v_shown_242, v_t_24141);
    }
    default: return heff_nomatch(v_t_24130);
    }
  }
  case TAG_SIs: {
    V v_t_24143 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24143)) {
    case TAG_Nothing: {
      V v_t_24144 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24145 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str40), heff_strAppend(v_t_24144, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str41)));
      V v_d_24146 = heff_strAppend(v_shown_242, v_t_24145);
      V v_t_24147 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24148 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24147, NTAG(TAG_Nil)));
      V v_x2_24150;
      switch (heff_tag_of(v_t_24148)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24150 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24149 = heff_field(v_t_24148, 0);
        heff_take_n(v_t_24148, 1ULL, 1);
        v_x2_24150 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24149));
        break;
      }
      default: heff_nomatch(v_t_24148);
      }
      switch (heff_tag_of(v_x2_24150)) {
      case TAG_Nothing: {
        return v_d_24146;
      }
      case TAG_Just: {
        V v_x_24151 = heff_field(v_x2_24150, 0);
        heff_take_n(v_x2_24150, 1ULL, 1);
        heff_drop(v_d_24146);
        return v_x_24151;
      }
      default: return heff_nomatch(v_x2_24150);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24143, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24153 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24154 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str42), heff_strAppend(v_t_24153, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str43)));
      return heff_strAppend(v_shown_242, v_t_24154);
    }
    default: return heff_nomatch(v_t_24143);
    }
  }
  case TAG_SOpaque: {
    V v_t_24155 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24155)) {
    case TAG_Nothing: {
      V v_t_24156 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24157 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str44), heff_strAppend(v_t_24156, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str45)));
      V v_d_24158 = heff_strAppend(v_shown_242, v_t_24157);
      V v_t_24159 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24160 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24159, NTAG(TAG_Nil)));
      V v_x2_24162;
      switch (heff_tag_of(v_t_24160)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24162 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24161 = heff_field(v_t_24160, 0);
        heff_take_n(v_t_24160, 1ULL, 1);
        v_x2_24162 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24161));
        break;
      }
      default: heff_nomatch(v_t_24160);
      }
      switch (heff_tag_of(v_x2_24162)) {
      case TAG_Nothing: {
        return v_d_24158;
      }
      case TAG_Just: {
        V v_x_24163 = heff_field(v_x2_24162, 0);
        heff_take_n(v_x2_24162, 1ULL, 1);
        heff_drop(v_d_24158);
        return v_x_24163;
      }
      default: return heff_nomatch(v_x2_24162);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24155, 0ULL, 1);
      heff_drop(v_name_241);
      V v_t_24165 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24166 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str46), heff_strAppend(v_t_24165, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str47)));
      return heff_strAppend(v_shown_242, v_t_24166);
    }
    default: return heff_nomatch(v_t_24155);
    }
  }
  case TAG_SAbandon: {
    heff_drop(v_name_241);
    V v_t_24167 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
    V v_t_24168 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str48), heff_strAppend(v_t_24167, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str49)));
    return heff_strAppend(v_shown_242, v_t_24168);
  }
  case TAG_SRec: {
    V v_t_24170 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24170)) {
    case TAG_Nothing: {
      V v_t_24171 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24172 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str50), heff_strAppend(v_t_24171, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str51)));
      V v_d_24173 = heff_strAppend(v_shown_242, v_t_24172);
      V v_t_24174 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24175 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24174, NTAG(TAG_Nil)));
      V v_x2_24177;
      switch (heff_tag_of(v_t_24175)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24177 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24176 = heff_field(v_t_24175, 0);
        heff_take_n(v_t_24175, 1ULL, 1);
        v_x2_24177 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24176));
        break;
      }
      default: heff_nomatch(v_t_24175);
      }
      switch (heff_tag_of(v_x2_24177)) {
      case TAG_Nothing: {
        return v_d_24173;
      }
      case TAG_Just: {
        V v_x_24178 = heff_field(v_x2_24177, 0);
        heff_take_n(v_x2_24177, 1ULL, 1);
        heff_drop(v_d_24173);
        return v_x_24178;
      }
      default: return heff_nomatch(v_x2_24177);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24170, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24180 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24181 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str52), heff_strAppend(v_t_24180, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str53)));
      return heff_strAppend(v_shown_242, v_t_24181);
    }
    default: return heff_nomatch(v_t_24170);
    }
  }
  case TAG_SFix: {
    V v_t_24184 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24184)) {
    case TAG_Nothing: {
      V v_t_24185 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24186 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str54), heff_strAppend(v_t_24185, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str55)));
      V v_d_24187 = heff_strAppend(v_shown_242, v_t_24186);
      V v_t_24188 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24189 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24188, NTAG(TAG_Nil)));
      V v_x2_24191;
      switch (heff_tag_of(v_t_24189)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24191 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24190 = heff_field(v_t_24189, 0);
        heff_take_n(v_t_24189, 1ULL, 1);
        v_x2_24191 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24190));
        break;
      }
      default: heff_nomatch(v_t_24189);
      }
      switch (heff_tag_of(v_x2_24191)) {
      case TAG_Nothing: {
        return v_d_24187;
      }
      case TAG_Just: {
        V v_x_24192 = heff_field(v_x2_24191, 0);
        heff_take_n(v_x2_24191, 1ULL, 1);
        heff_drop(v_d_24187);
        return v_x_24192;
      }
      default: return heff_nomatch(v_x2_24191);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24184, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_24194 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24195 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str56), heff_strAppend(v_t_24194, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str57)));
      return heff_strAppend(v_shown_242, v_t_24195);
    }
    default: return heff_nomatch(v_t_24184);
    }
  }
  case TAG_SImplicit: {
    V v_t_24198 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24198)) {
    case TAG_Nothing: {
      V v_t_24199 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24200 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str58), heff_strAppend(v_t_24199, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str59)));
      V v_d_24201 = heff_strAppend(v_shown_242, v_t_24200);
      V v_t_24202 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24203 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24202, NTAG(TAG_Nil)));
      V v_x2_24205;
      switch (heff_tag_of(v_t_24203)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24205 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24204 = heff_field(v_t_24203, 0);
        heff_take_n(v_t_24203, 1ULL, 1);
        v_x2_24205 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24204));
        break;
      }
      default: heff_nomatch(v_t_24203);
      }
      switch (heff_tag_of(v_x2_24205)) {
      case TAG_Nothing: {
        return v_d_24201;
      }
      case TAG_Just: {
        V v_x_24206 = heff_field(v_x2_24205, 0);
        heff_take_n(v_x2_24205, 1ULL, 1);
        heff_drop(v_d_24201);
        return v_x_24206;
      }
      default: return heff_nomatch(v_x2_24205);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24198, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_24208 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24209 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str60), heff_strAppend(v_t_24208, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str61)));
      return heff_strAppend(v_shown_242, v_t_24209);
    }
    default: return heff_nomatch(v_t_24198);
    }
  }
  case TAG_SPrim: {
    V v_t_24211 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24211)) {
    case TAG_Nothing: {
      V v_t_24212 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24213 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str62), heff_strAppend(v_t_24212, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str63)));
      V v_d_24214 = heff_strAppend(v_shown_242, v_t_24213);
      V v_t_24215 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24216 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24215, NTAG(TAG_Nil)));
      V v_x2_24218;
      switch (heff_tag_of(v_t_24216)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24218 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24217 = heff_field(v_t_24216, 0);
        heff_take_n(v_t_24216, 1ULL, 1);
        v_x2_24218 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24217));
        break;
      }
      default: heff_nomatch(v_t_24216);
      }
      switch (heff_tag_of(v_x2_24218)) {
      case TAG_Nothing: {
        return v_d_24214;
      }
      case TAG_Just: {
        V v_x_24219 = heff_field(v_x2_24218, 0);
        heff_take_n(v_x2_24218, 1ULL, 1);
        heff_drop(v_d_24214);
        return v_x_24219;
      }
      default: return heff_nomatch(v_x2_24218);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24211, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24221 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24222 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str64), heff_strAppend(v_t_24221, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str65)));
      return heff_strAppend(v_shown_242, v_t_24222);
    }
    default: return heff_nomatch(v_t_24211);
    }
  }
  case TAG_SMetaApp: {
    V v_t_24226 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24226)) {
    case TAG_Nothing: {
      V v_t_24227 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24228 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str66), heff_strAppend(v_t_24227, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str67)));
      V v_d_24229 = heff_strAppend(v_shown_242, v_t_24228);
      V v_t_24230 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24231 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24230, NTAG(TAG_Nil)));
      V v_x2_24233;
      switch (heff_tag_of(v_t_24231)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24233 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24232 = heff_field(v_t_24231, 0);
        heff_take_n(v_t_24231, 1ULL, 1);
        v_x2_24233 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24232));
        break;
      }
      default: heff_nomatch(v_t_24231);
      }
      switch (heff_tag_of(v_x2_24233)) {
      case TAG_Nothing: {
        return v_d_24229;
      }
      case TAG_Just: {
        V v_x_24234 = heff_field(v_x2_24233, 0);
        heff_take_n(v_x2_24233, 1ULL, 1);
        heff_drop(v_d_24229);
        return v_x_24234;
      }
      default: return heff_nomatch(v_x2_24233);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24226, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 3);
      V v_t_24236 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24237 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str68), heff_strAppend(v_t_24236, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str69)));
      return heff_strAppend(v_shown_242, v_t_24237);
    }
    default: return heff_nomatch(v_t_24226);
    }
  }
  case TAG_SLitInt: {
    V v_t_24239 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24239)) {
    case TAG_Nothing: {
      V v_t_24240 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24241 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str70), heff_strAppend(v_t_24240, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str71)));
      V v_d_24242 = heff_strAppend(v_shown_242, v_t_24241);
      V v_t_24243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24244 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24243, NTAG(TAG_Nil)));
      V v_x2_24246;
      switch (heff_tag_of(v_t_24244)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24246 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24245 = heff_field(v_t_24244, 0);
        heff_take_n(v_t_24244, 1ULL, 1);
        v_x2_24246 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24245));
        break;
      }
      default: heff_nomatch(v_t_24244);
      }
      switch (heff_tag_of(v_x2_24246)) {
      case TAG_Nothing: {
        return v_d_24242;
      }
      case TAG_Just: {
        V v_x_24247 = heff_field(v_x2_24246, 0);
        heff_take_n(v_x2_24246, 1ULL, 1);
        heff_drop(v_d_24242);
        return v_x_24247;
      }
      default: return heff_nomatch(v_x2_24246);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24239, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24249 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24250 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str72), heff_strAppend(v_t_24249, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str73)));
      return heff_strAppend(v_shown_242, v_t_24250);
    }
    default: return heff_nomatch(v_t_24239);
    }
  }
  case TAG_SLitFloat: {
    V v_t_24252 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24252)) {
    case TAG_Nothing: {
      V v_t_24253 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24254 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str74), heff_strAppend(v_t_24253, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str75)));
      V v_d_24255 = heff_strAppend(v_shown_242, v_t_24254);
      V v_t_24256 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24257 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24256, NTAG(TAG_Nil)));
      V v_x2_24259;
      switch (heff_tag_of(v_t_24257)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24259 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24258 = heff_field(v_t_24257, 0);
        heff_take_n(v_t_24257, 1ULL, 1);
        v_x2_24259 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24258));
        break;
      }
      default: heff_nomatch(v_t_24257);
      }
      switch (heff_tag_of(v_x2_24259)) {
      case TAG_Nothing: {
        return v_d_24255;
      }
      case TAG_Just: {
        V v_x_24260 = heff_field(v_x2_24259, 0);
        heff_take_n(v_x2_24259, 1ULL, 1);
        heff_drop(v_d_24255);
        return v_x_24260;
      }
      default: return heff_nomatch(v_x2_24259);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24252, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24262 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24263 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str76), heff_strAppend(v_t_24262, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str77)));
      return heff_strAppend(v_shown_242, v_t_24263);
    }
    default: return heff_nomatch(v_t_24252);
    }
  }
  case TAG_SLitString: {
    V v_t_24265 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24265)) {
    case TAG_Nothing: {
      V v_t_24266 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24267 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str78), heff_strAppend(v_t_24266, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str79)));
      V v_d_24268 = heff_strAppend(v_shown_242, v_t_24267);
      V v_t_24269 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24270 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24269, NTAG(TAG_Nil)));
      V v_x2_24272;
      switch (heff_tag_of(v_t_24270)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24272 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24271 = heff_field(v_t_24270, 0);
        heff_take_n(v_t_24270, 1ULL, 1);
        v_x2_24272 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24271));
        break;
      }
      default: heff_nomatch(v_t_24270);
      }
      switch (heff_tag_of(v_x2_24272)) {
      case TAG_Nothing: {
        return v_d_24268;
      }
      case TAG_Just: {
        V v_x_24273 = heff_field(v_x2_24272, 0);
        heff_take_n(v_x2_24272, 1ULL, 1);
        heff_drop(v_d_24268);
        return v_x_24273;
      }
      default: return heff_nomatch(v_x2_24272);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24265, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24275 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24276 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str80), heff_strAppend(v_t_24275, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str81)));
      return heff_strAppend(v_shown_242, v_t_24276);
    }
    default: return heff_nomatch(v_t_24265);
    }
  }
  case TAG_SLitBytes: {
    V v_t_24278 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24278)) {
    case TAG_Nothing: {
      V v_t_24279 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24280 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str82), heff_strAppend(v_t_24279, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str83)));
      V v_d_24281 = heff_strAppend(v_shown_242, v_t_24280);
      V v_t_24282 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24283 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24282, NTAG(TAG_Nil)));
      V v_x2_24285;
      switch (heff_tag_of(v_t_24283)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24285 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24284 = heff_field(v_t_24283, 0);
        heff_take_n(v_t_24283, 1ULL, 1);
        v_x2_24285 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24284));
        break;
      }
      default: heff_nomatch(v_t_24283);
      }
      switch (heff_tag_of(v_x2_24285)) {
      case TAG_Nothing: {
        return v_d_24281;
      }
      case TAG_Just: {
        V v_x_24286 = heff_field(v_x2_24285, 0);
        heff_take_n(v_x2_24285, 1ULL, 1);
        heff_drop(v_d_24281);
        return v_x_24286;
      }
      default: return heff_nomatch(v_x2_24285);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24278, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24288 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24289 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str84), heff_strAppend(v_t_24288, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str85)));
      return heff_strAppend(v_shown_242, v_t_24289);
    }
    default: return heff_nomatch(v_t_24278);
    }
  }
  case TAG_SLitRune: {
    V v_t_24291 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24291)) {
    case TAG_Nothing: {
      V v_t_24292 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24293 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str86), heff_strAppend(v_t_24292, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str87)));
      V v_d_24294 = heff_strAppend(v_shown_242, v_t_24293);
      V v_t_24295 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24296 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24295, NTAG(TAG_Nil)));
      V v_x2_24298;
      switch (heff_tag_of(v_t_24296)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24298 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24297 = heff_field(v_t_24296, 0);
        heff_take_n(v_t_24296, 1ULL, 1);
        v_x2_24298 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24297));
        break;
      }
      default: heff_nomatch(v_t_24296);
      }
      switch (heff_tag_of(v_x2_24298)) {
      case TAG_Nothing: {
        return v_d_24294;
      }
      case TAG_Just: {
        V v_x_24299 = heff_field(v_x2_24298, 0);
        heff_take_n(v_x2_24298, 1ULL, 1);
        heff_drop(v_d_24294);
        return v_x_24299;
      }
      default: return heff_nomatch(v_x2_24298);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24291, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24301 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24302 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str88), heff_strAppend(v_t_24301, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str89)));
      return heff_strAppend(v_shown_242, v_t_24302);
    }
    default: return heff_nomatch(v_t_24291);
    }
  }
  case TAG_SLitFixed: {
    V v_t_24305 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24305)) {
    case TAG_Nothing: {
      V v_t_24306 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24307 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str90), heff_strAppend(v_t_24306, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str91)));
      V v_d_24308 = heff_strAppend(v_shown_242, v_t_24307);
      V v_t_24309 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24310 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24309, NTAG(TAG_Nil)));
      V v_x2_24312;
      switch (heff_tag_of(v_t_24310)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24312 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24311 = heff_field(v_t_24310, 0);
        heff_take_n(v_t_24310, 1ULL, 1);
        v_x2_24312 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24311));
        break;
      }
      default: heff_nomatch(v_t_24310);
      }
      switch (heff_tag_of(v_x2_24312)) {
      case TAG_Nothing: {
        return v_d_24308;
      }
      case TAG_Just: {
        V v_x_24313 = heff_field(v_x2_24312, 0);
        heff_take_n(v_x2_24312, 1ULL, 1);
        heff_drop(v_d_24308);
        return v_x_24313;
      }
      default: return heff_nomatch(v_x2_24312);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24305, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 2);
      V v_t_24315 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24316 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str92), heff_strAppend(v_t_24315, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str93)));
      return heff_strAppend(v_shown_242, v_t_24316);
    }
    default: return heff_nomatch(v_t_24305);
    }
  }
  case TAG_SLitFloat32: {
    V v_t_24318 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_244)));
    switch (heff_tag_of(v_t_24318)) {
    case TAG_Nothing: {
      V v_t_24319 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(v_im_240), MK_INT(0LL)}), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
      V v_t_24320 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str94), heff_strAppend(v_t_24319, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str95)));
      V v_d_24321 = heff_strAppend(v_shown_242, v_t_24320);
      V v_t_24322 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_241), NTAG(TAG_Nil)});
      V v_t_24323 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_243, v_body_244, v_t_24322, NTAG(TAG_Nil)));
      V v_x2_24325;
      switch (heff_tag_of(v_t_24323)) {
      case TAG_Nothing: {
        heff_drop(v_im_240);
        heff_drop(v_name_241);
        v_x2_24325 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_tf_24324 = heff_field(v_t_24323, 0);
        heff_take_n(v_t_24323, 1ULL, 1);
        v_x2_24325 = (g_heff_2esyntax_2epsurface_2eformerOf(heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}), v_name_241, v_tf_24324));
        break;
      }
      default: heff_nomatch(v_t_24323);
      }
      switch (heff_tag_of(v_x2_24325)) {
      case TAG_Nothing: {
        return v_d_24321;
      }
      case TAG_Just: {
        V v_x_24326 = heff_field(v_x2_24325, 0);
        heff_take_n(v_x2_24325, 1ULL, 1);
        heff_drop(v_d_24321);
        return v_x_24326;
      }
      default: return heff_nomatch(v_x2_24325);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_24318, 0ULL, 1);
      heff_drop(v_name_241);
      heff_drop_tag(v_body_244, 1);
      V v_t_24328 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_im_240, MK_INT(0LL)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_243; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_24329 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_str96), heff_strAppend(v_t_24328, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_str97)));
      return heff_strAppend(v_shown_242, v_t_24329);
    }
    default: return heff_nomatch(v_t_24318);
    }
  }
  default: return heff_nomatch(v_body_244);
  }
}
V g_heff_2esyntax_2epsurface_2eprintSig_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eprintSig(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str2, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str4, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str5, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str6, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str7, 1, ".");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str10, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str13, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str14, 1, "[");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str15, 1, "]");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str18, 3, " of");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str19, 5, "case ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str20, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str21, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str22, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str23, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str24, 5, " ~ { ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str25, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str26, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str27, 8, "<opaque>");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str28, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str29, 7, "<local>");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str30, 11, "<primitive ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str31, 1, ">");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str32, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str33, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str34, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str35, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str36, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str37, 2, "b\"");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str38, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str39, 1, "'");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str40, 1, "'");
V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_lam0(V self, V *args);
V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_lam1(V self, V *args);
V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_lam2(V self, V *args);
V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_lam3(V self, V *args);
Clo g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684(V v_lit_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return ({ V a_0 = v_xs_242; V a_1 = v_i_244; V r_ = (g_heff_2esyntax_2epsurface_2elocalName(a_0, a_1)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_246 = (g_heff_2esyntax_2epsurface_2eisOperator(heff_dup(v_x_245)));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str0), heff_strAppend(v_x_245, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str1)));
    } else {
      heff_drop(v_t_246);
      return v_x_245;
    }
  }
  case TAG_SCode: {
    V v_t_247 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_247; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  case TAG_SApp: {
    V v_f_248 = heff_field(v_e_243, 0);
    V v_a_249 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, heff_tag_at_n(v_ru_24e_243_24SApp, TAG_SApp, 2, (V[]){v_f_248, v_a_249}));
  }
  case TAG_SLam: {
    V v_t_2410 = heff_field(v_e_243, 0);
    V v_b_2411 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SLam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2412 = (g_heff_2esyntax_2epsurface_2elambdas(heff_dup(v_xs_242), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24e_243_24SLam, TAG_SLam, 2, (V[]){v_t_2410, v_b_2411})));
    return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2412; V r_ = (g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399(a_0, a_1, a_2, a_3)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SCons: {
    V v_d_2413 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_p_241);
    V v_t_2414 = heff_arrayToList(heff_take_field(v_d_2413, 0));
    V v_t_2415 = heff_arrayToList(heff_get_n(v_d_2413, 2, 3));
    V v_t_2416 = (g_heff_2eutil_2edict_2ezipKV(v_t_2414, v_t_2415));
    V v_x2_2421 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_lam0, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2416));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str4); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str5), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str6)));
  }
  case TAG_SProj: {
    V v_e2_2425 = heff_field(v_e_243, 0);
    V v_l_2426 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    heff_drop(v_p_241);
    V v_t_2427 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_e2_2425));
    return heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str7), v_l_2426));
  }
  case TAG_STag: {
    V v_x_2428 = heff_dup(heff_field(v_e_243, 0));
    V v_ts_2429 = heff_dup(heff_field(v_e_243, 1));
    V v_t_2430 = (g_heff_2esyntax_2epsurface_2elistItems(v_e_243));
    switch (heff_tag_of(v_t_2430)) {
    case TAG_Nothing: {
      V v_t_2431 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_ts_2429)); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (heff_intEq_c(v_t_2431, MK_INT(0LL))) {
        heff_drop(v_lit_240);
        heff_drop(v_p_241);
        heff_drop(v_xs_242);
        heff_drop(v_ts_2429);
        return v_x_2428;
      } else {
        V v_t_2434 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), heff_arrayToList(v_ts_2429)));
        V v_x2_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2428, v_t_2434});
        V v_s_2438;
        switch (heff_tag_of(v_x2_2435)) {
        case TAG_Nil: {
          v_s_2438 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2436 = heff_field(v_x2_2435, 0);
          V v_xs_2437 = heff_field(v_x2_2435, 1);
          heff_take_n(v_x2_2435, 3ULL, 2);
          v_s_2438 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str9); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2435);
        }
        if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
          return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str10), heff_strAppend(v_s_2438, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str11)));
        } else {
          return v_s_2438;
        }
      }
    }
    case TAG_Just: {
      V v_items_2440 = heff_field(v_t_2430, 0);
      heff_take_n(v_t_2430, 1ULL, 1);
      heff_drop(v_p_241);
      heff_drop(v_x_2428);
      heff_drop(v_ts_2429);
      V v_x2_2442 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}), v_items_2440));
      V v_t_2445;
      switch (heff_tag_of(v_x2_2442)) {
      case TAG_Nil: {
        v_t_2445 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2443 = heff_field(v_x2_2442, 0);
        V v_xs_2444 = heff_field(v_x2_2442, 1);
        heff_take_n(v_x2_2442, 3ULL, 2);
        v_t_2445 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str13); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2442);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str14), heff_strAppend(v_t_2445, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str15)));
    }
    default: return heff_nomatch(v_t_2430);
    }
  }
  case TAG_SMatch: {
    V v_s_2446 = heff_field(v_e_243, 0);
    V v_cases_2447 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2448 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), heff_dup(v_lit_240)}), MK_INT(0LL), heff_dup(v_xs_242), v_s_2446));
    V v_t_2449 = heff_arrayToList(heff_take_field(v_cases_2447, 0));
    V v_t_2450 = heff_arrayToList(heff_get_n(v_cases_2447, 2, 3));
    V v_t_2451 = (g_heff_2eutil_2edict_2ezipKV(v_t_2449, v_t_2450));
    V v_x2_2454 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_lam3, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2451));
    V v_t_2457;
    switch (heff_tag_of(v_x2_2454)) {
    case TAG_Nil: {
      v_t_2457 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2455 = heff_field(v_x2_2454, 0);
      V v_xs_2456 = heff_field(v_x2_2454, 1);
      heff_take_n(v_x2_2454, 3ULL, 2);
      v_t_2457 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str17); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2454);
    }
    V v_t_2458 = heff_strAppend(v_t_2448, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str18), v_t_2457));
    V v_s_2459 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str19), v_t_2458);
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str20), heff_strAppend(v_s_2459, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str21)));
    } else {
      return v_s_2459;
    }
  }
  case TAG_SSpecialize: {
    V v_e2_2461 = heff_field(v_e_243, 0);
    V v_x_2462 = heff_field(v_e_243, 1);
    V v_v_2463 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_2464 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), heff_dup(v_lit_240)}), MK_INT(2LL), heff_dup(v_xs_242), v_e2_2461));
    V v_t_2465 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_v_2463));
    V v_t_2466 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str22), heff_strAppend(v_t_2465, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str23)));
    V v_t_2467 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str24), heff_strAppend(v_x_2462, v_t_2466));
    V v_s_2468 = heff_strAppend(v_t_2464, v_t_2467);
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str25), heff_strAppend(v_s_2468, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str26)));
    } else {
      return v_s_2468;
    }
  }
  case TAG_SIs: {
    V v_e2_2470 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2470);
  }
  case TAG_SOpaque: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str27);
  }
  case TAG_SAbandon: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str28);
  }
  case TAG_SRec: {
    V v_e2_2471 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2471);
  }
  case TAG_SFix: {
    V v_e2_27_2473 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_e2_27_2473)) {
    case TAG_MkAbs: {
      V v_x_2474 = heff_field(v_e2_27_2473, 0);
      heff_take_n(v_e2_27_2473, 1ULL, 2);
      return v_x_2474;
    }
    case TAG_AbsConst: {
      heff_take_n(v_e2_27_2473, 0ULL, 1);
      return ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str29);
    }
    default: return heff_nomatch(v_e2_27_2473);
    }
  }
  case TAG_SImplicit: {
    V v_e2_2478 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2478);
  }
  case TAG_SPrim: {
    V v_x_2479 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str30), heff_strAppend(v_x_2479, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str31)));
  }
  case TAG_SMetaApp: {
    V v_m_2480 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 3);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str32), heff_intShow(v_m_2480));
  }
  case TAG_SLitInt: {
    V v_i_2483 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_i_2483);
  }
  case TAG_SLitFloat: {
    V v_x_2484 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2484);
  }
  case TAG_SLitString: {
    V v_s_2485 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2486 = (g_heff_2eutil_2erune_2equoteGo(v_s_2485, MK_INT(0LL), ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str33)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str34), heff_strAppend(v_t_2486, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str35)));
  }
  case TAG_SLitBytes: {
    V v_s_2487 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2488 = (g_heff_2eutil_2erune_2equoteBytesGo(v_s_2487, MK_INT(0LL), ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str36)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str37), heff_strAppend(v_t_2488, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str38)));
  }
  case TAG_SLitRune: {
    V v_ch_2489 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2490 = (g_heff_2eutil_2erune_2equoted(v_ch_2489));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str39), heff_strAppend(v_t_2490, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str40)));
  }
  case TAG_SLitFixed: {
    V v_n_2492 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_n_2492);
  }
  case TAG_SLitFloat32: {
    V v_x_2493 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2493);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_lam0(V self, V *args) {
  V v_f_2417 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_l_2418 = heff_field(v_f_2417, 0);
    V v_e_2419 = heff_field(v_f_2417, 1);
    heff_take_n(v_f_2417, 3ULL, 2);
    V v_t_2420 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_e_2419));
    return heff_strAppend(v_l_2418, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_str2), v_t_2420));
  }
  default: return heff_nomatch(v_f_2417);
  }
}
V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_lam1(V self, V *args) {
  V v_a_2433 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_a_2433));
}
V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_lam2(V self, V *args) {
  V v_a_2441 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_a_2441));
}
V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_lam3(V self, V *args) {
  V v_alt_2452 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), heff_intAdd(v_lit_240, MK_INT(2LL))});
  return ({ V a_0 = v_t_2453; V a_1 = v_xs_242; V a_2 = v_alt_2452; V r_ = (g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439(a_0, a_1, a_2)); heff_drop(v_alt_2452); r_; });
}