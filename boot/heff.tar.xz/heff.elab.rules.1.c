// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_BDelayedBy 11524
#define TAG_Become 65038
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CUndelay 45232
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Delayed2 38439
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_IntoCons 46138
#define TAG_LChunkSnoc 25233
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotApplicable 40298
#define TAG_NotInScope 14443
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIsTy 43896
#define TAG_SLocal 28569
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_applied 1586106042
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_conclusion 1382344475
#define LBL_defaults 1389419502
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_globals 352931696
#define LBL_goal 9673690
#define LBL_hole 9703815
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nameSpan 438211216
#define LBL_note 9882809
#define LBL_rest 9992347
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_subgoals 820279267
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_applied__conclusion__subgoals[] = {LBL_applied, LBL_conclusion, LBL_subgoals};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_el__span__dflt__rest[] = {LBL_el, LBL_span, LBL_dflt, LBL_rest};
static uint32_t shape_hole__goal[] = {LBL_hole, LBL_goal};
static uint32_t shape_name__ty__el__dflt__span[] = {LBL_name, LBL_ty, LBL_el, LBL_dflt, LBL_span};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2ememoed_2eabandonM_get(void);
V g_heff_2eelab_2ememoed_2eapp(V, V);
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eapp_clo;
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eabandonChk(V);
V g_heff_2eelab_2erules_2eabandonChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eabandonChk_clo;
V g_heff_2eelab_2erules_2eanyIdxGo(V, V, V);
V g_heff_2eelab_2erules_2eanyIdxGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyIdxGo_clo;
V g_heff_2eelab_2erules_2eanyP(V, V);
V g_heff_2eelab_2erules_2eanyP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyP_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2ecatMaybesR(V);
V g_heff_2eelab_2erules_2ecatMaybesR_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_clo;
V g_heff_2eelab_2erules_2ecatMaybesR_24dps(V, V);
V g_heff_2eelab_2erules_2ecatMaybesR_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_24dps_clo;
V g_heff_2eelab_2erules_2echeckFixed(V, V, V, V);
V g_heff_2eelab_2erules_2echeckFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckFixed_clo;
V g_heff_2eelab_2erules_2edefaultChk(V, V, V);
V g_heff_2eelab_2erules_2edefaultChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultChk_clo;
V g_heff_2eelab_2erules_2edefaultFor(V, V, V, V);
V g_heff_2eelab_2erules_2edefaultFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultFor_clo;
V g_heff_2eelab_2erules_2edefaulted(V, V, V, V, V);
V g_heff_2eelab_2erules_2edefaulted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaulted_clo;
V g_heff_2eelab_2erules_2eelimGo(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimGo_clo;
V g_heff_2eelab_2erules_2eelimPlain(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimPlain_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimPlain_clo;
V g_heff_2eelab_2erules_2eerrorOf_get(void);
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
V g_heff_2eelab_2erules_2efunctionIntroSyn(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroSyn_clo;
V g_heff_2eelab_2erules_2eimplicitArg(V, V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitArg_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einstantiateGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2einstantiateGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstantiateGo_clo;
V g_heff_2eelab_2erules_2eintroGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintroGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintroGo_clo;
V g_heff_2eelab_2erules_2eleftOver(V, V, V);
V g_heff_2eelab_2erules_2eleftOver_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eleftOver_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo;
V g_heff_2eelab_2erules_2ementionsTypeF(V, V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_clo;
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_clo;
V g_heff_2eelab_2erules_2emisfit(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2emisfit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emisfit_clo;
V g_heff_2eelab_2erules_2enotGiven(V, V, V);
V g_heff_2eelab_2erules_2enotGiven_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotGiven_clo;
V g_heff_2eelab_2erules_2eplacesGo_24dps(V, V, V);
V g_heff_2eelab_2erules_2eplacesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesGo_24dps_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
V g_heff_2eelab_2erules_2erigidFormer(V, V);
V g_heff_2eelab_2erules_2erigidFormer_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erigidFormer_clo;
V g_heff_2eelab_2erules_2eselfAdvance(V, V, V, V, V);
V g_heff_2eelab_2erules_2eselfAdvance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eselfAdvance_clo;
V g_heff_2eelab_2erules_2esumIntroNow(V, V, V, V);
V g_heff_2eelab_2erules_2esumIntroNow_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntroNow_clo;
V g_heff_2eelab_2erules_2etagArgsGo(V, V, V);
V g_heff_2eelab_2erules_2etagArgsGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagArgsGo_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2evarGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2evarGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evarGo_clo;
V g_heff_2eelab_2erules_2ewritten(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ewritten_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewritten_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2edecodeN(V);
V g_heff_2eelab_2evalue_2edecodeN_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeN_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_heff_2eelab_2erules_2ementionsTypeF_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTypeF_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTypeF_entry, 3, 0};

V g_heff_2eelab_2erules_2ementionsTypeF(V v_r_240, V v_d_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SDecode: {
    V v_e_244 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_e_244)});
  }
  case TAG_SFunction: {
    V v_dom_246 = heff_field(v_t_242, 1);
    V v_t3_247 = heff_field(v_t_242, 2);
    switch (heff_tag_of(v_t3_247)) {
    case TAG_MkAbs: {
      V v_b_2411 = heff_field(v_t3_247, 1);
      V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dom_246)}));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_d_241);
        heff_drop(v_t_2412);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2412);
        return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){heff_intAdd(v_d_241, MK_INT(1LL)), heff_dup(v_b_2411)});
      }
    }
    case TAG_AbsConst: {
      V v_b_2413 = heff_field(v_t3_247, 0);
      V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dom_246)}));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_d_241);
        heff_drop(v_t_2414);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2414);
        return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_d_241, heff_dup(v_b_2413)});
      }
    }
    default: return heff_nomatch(v_t3_247);
    }
  }
  case TAG_SRecord: {
    V v_ft_2416 = heff_field(v_t_242, 1);
    V v_t_2418 = heff_arrayToList(heff_dup(heff_rfield(v_ft_2416, 2)));
    return ({ V a_0 = MK_INT(0LL); V a_1 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_lam0, 2, 2, (V[]){v_r_240, v_d_241}); V a_2 = v_t_2418; V r_ = (g_heff_2eelab_2erules_2eanyIdxGo(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
  }
  case TAG_SSum: {
    V v_vs_2421 = heff_field(v_t_242, 0);
    V v_t_2422 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2421, 0)));
    V v_t_2423 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2421, 2)));
    V v_t_2424 = (g_heff_2eutil_2edict_2ezipKV(v_t_2422, v_t_2423));
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_lam1, 1, 2, (V[]){v_r_240, v_d_241}); V a_1 = v_t_2424; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2424); r_; });
  }
  case TAG_SIsTy: {
    V v_a_2429 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_d_241, heff_dup(v_a_2429)});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SPrimArray: {
    V v_a_2430 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_d_241, heff_dup(v_a_2430)});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2erules_2ementionsTypeF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2ementionsTypeF(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2ementionsTypeF_lam0(V self, V *args) {
  V v_i_2419 = args[0];
  V v_ty_2420 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_get_n(v_r_240, 1, 3);
  args[0] = heff_intAdd(v_d_241, v_i_2419);
  args[1] = v_ty_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ementionsTypeF_lam1(V self, V *args) {
  V v_x3_2425 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_2425)) {
  case TAG_MkPair: {
    V v_args_2427 = heff_field(v_x3_2425, 1);
    heff_take_n(v_x3_2425, 2ULL, 2);
    V v_t_2428 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){v_d_241}));
    return ({ V a_0 = v_t_2428; V b_1 = heff_arrayToList(v_args_2427); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_x3_2425);
  }
}
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry, 2, 0};

V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(V v_d_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SU: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SDecode: {
    V v_e_243 = heff_field(v_t_241, 0);
    HEFF_LAST return g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(v_d_240, v_e_243);
  }
  case TAG_SFunction: {
    V v_dom_245 = heff_field(v_t_241, 1);
    V v_t3_246 = heff_field(v_t_241, 2);
    switch (heff_tag_of(v_t3_246)) {
    case TAG_MkAbs: {
      V v_b_2410 = heff_field(v_t3_246, 1);
      V v_t_2411 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_240), v_dom_245));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_d_240);
        heff_drop(v_t_2411);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2411);
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_b_2410;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
    }
    case TAG_AbsConst: {
      V v_b_2412 = heff_field(v_t3_246, 0);
      V v_t_2413 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_240), v_dom_245));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_d_240);
        heff_drop(v_t_2413);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2413);
        V t_0 = v_d_240;
        V t_1 = v_b_2412;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_t3_246);
    }
  }
  case TAG_SRecord: {
    V v_ft_2415 = heff_field(v_t_241, 1);
    V v_t_2417 = heff_arrayToList(heff_dup(heff_rfield(v_ft_2415, 2)));
    return ({ V a_0 = MK_INT(0LL); V a_1 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam0, 2, 1, (V[]){v_d_240}); V a_2 = v_t_2417; V r_ = (g_heff_2eelab_2erules_2eanyIdxGo(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
  }
  case TAG_SSum: {
    V v_vs_2420 = heff_field(v_t_241, 0);
    V v_t_2421 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2420, 0)));
    V v_t_2422 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2420, 2)));
    V v_t_2423 = (g_heff_2eutil_2edict_2ezipKV(v_t_2421, v_t_2422));
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam1, 1, 1, (V[]){v_d_240}); V a_1 = v_t_2423; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2423); r_; });
  }
  case TAG_SIsTy: {
    V v_a_2428 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_a_2428;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SPrimInt: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SPrimString: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SPrimRune: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SPrimArray: {
    V v_a_2429 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_a_2429;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SFixed: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam0(V self, V *args) {
  V v_i_2418 = args[0];
  V v_ty_2419 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = heff_intAdd(v_d_240, v_i_2418); V a_1 = v_ty_2419; V r_ = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(a_0, a_1)); heff_drop(v_ty_2419); r_; });
}
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam2(V self, V *args) {
  V v_t_2427 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_d_240; V a_1 = v_t_2427; V r_ = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(a_0, a_1)); heff_drop(v_t_2427); r_; });
}
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam1(V self, V *args) {
  V v_x3_2424 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2424)) {
  case TAG_MkPair: {
    V v_args_2426 = heff_field(v_x3_2424, 1);
    heff_take_n(v_x3_2424, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_lam2, 1, 1, (V[]){v_d_240}); V b_1 = heff_arrayToList(v_args_2426); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_x3_2424);
  }
}
V g_heff_2eelab_2erules_2eerrorOf_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eerrorOf_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eerrorOf_lam2(V self, V *args);

static V g_heff_2eelab_2erules_2eerrorOf_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eerrorOf_st;
static V g_heff_2eelab_2erules_2eerrorOf_init(void) {
  V v_t_240 = (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  V v_a_241 = (g_heff_2eelab_2evalue_2edecodeN(v_t_240));
  V v_t_245 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eerrorOf_lam0, 1, 1, (V[]){v_a_241})});
  V v_t_246 = (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  V v_t_247 = (g_heff_2eelab_2evalue_2edecodeN(v_t_246));
  V v_x_248 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_247});
  return heff_clo_n(g_heff_2eelab_2erules_2eerrorOf_lam2, 2, 1, (V[]){v_x_248});
}
V g_heff_2eelab_2erules_2eerrorOf_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eerrorOf_st)) return g_heff_2eelab_2erules_2eerrorOf_val;
  return heff_global(&g_heff_2eelab_2erules_2eerrorOf_val, &g_heff_2eelab_2erules_2eerrorOf_st, g_heff_2eelab_2erules_2eerrorOf_init);
}
V g_heff_2eelab_2erules_2eerrorOf_lam1(V self, V *args) {
  V v_u_243 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_243);
  return v_a_241;
}
V g_heff_2eelab_2erules_2eerrorOf_lam0(V self, V *args) {
  V v_u_242 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_242);
  V v_t_244 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eerrorOf_lam1, 1, 1, (V[]){v_a_241}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_244});
}
V g_heff_2eelab_2erules_2eerrorOf_lam2(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2eelab_2erules_2ecatMaybesR_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecatMaybesR_entry, 1, 0};

V g_heff_2eelab_2erules_2ecatMaybesR(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2erules_2ecatMaybesR_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2ecatMaybesR_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecatMaybesR(a[0]);
}
HEFF_LIT(g_heff_2eelab_2erules_2einstantiateGo_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einstantiateGo_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einstantiateGo_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einstantiateGo_str3, 1, "_");
V g_heff_2eelab_2erules_2einstantiateGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam9(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam10(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam11(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam12(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam13(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam14(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam15(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam16(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam17(V self, V *args);
Clo g_heff_2eelab_2erules_2einstantiateGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstantiateGo_entry, 5, 0};

V g_heff_2eelab_2erules_2einstantiateGo(V v_e_240, V v_sp_241, V v_m_242, V v_ty_243, V v_subgoals_244) {
top: ;
  switch (heff_tag_of(v_ty_243)) {
  case TAG_VU: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_247 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_246});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam0, 2, 1, (V[]){v_x_247});
  }
  case TAG_VDecode: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_2416 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_2415});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam1, 2, 1, (V[]){v_x_2416});
  }
  case TAG_VFunction: {
    V v_dom_2420 = heff_dup(heff_field(v_ty_243, 1));
    V v_cod_2421 = heff_dup(heff_field(v_ty_243, 2));
    V v_it4_2422 = heff_dup(heff_field(v_ty_243, 3));
    switch (heff_tag_of(v_it4_2422)) {
    case TAG_Expl: {
      heff_drop_rec(v_e_240, 6);
      heff_drop(v_sp_241);
      heff_drop(v_dom_2420);
      heff_drop(v_cod_2421);
      V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
      V v_x_2425 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_2424});
      return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam2, 2, 1, (V[]){v_x_2425});
    }
    case TAG_Impl: {
      V v_t_2432;
      switch (heff_tag_of(v_cod_2421)) {
      case TAG_MkClo: {
        V v_n_2428 = heff_dup(heff_field(v_cod_2421, 0));
        v_t_2432 = v_n_2428;
        break;
      }
      case TAG_CloConst: {
        v_t_2432 = ((V)&g_heff_2eelab_2erules_2einstantiateGo_str0);
        break;
      }
      default: heff_nomatch(v_cod_2421);
      }
      V v_c_2433 = (g_heff_2eelab_2erules_2eimplicitArg(heff_dup(v_e_240), heff_dup(v_sp_241), v_ty_243, v_dom_2420, v_t_2432));
      return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam3, 2, 6, (V[]){v_c_2433, v_cod_2421, v_m_242, v_e_240, v_sp_241, v_subgoals_244});
    }
    case TAG_Inst: {
      heff_drop_tag(v_ty_243, 5);
      return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam6, 2, 6, (V[]){v_e_240, v_cod_2421, v_dom_2420, v_sp_241, v_m_242, v_subgoals_244});
    }
    default: return heff_nomatch(v_it4_2422);
    }
  }
  case TAG_VRecord: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_2493 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_2492});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam10, 2, 1, (V[]){v_x_2493});
  }
  case TAG_VSum: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_2497 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_2498 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_2497});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam11, 2, 1, (V[]){v_x_2498});
  }
  case TAG_VPrimInt: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24101 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24102 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24101});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam12, 2, 1, (V[]){v_x_24102});
  }
  case TAG_VPrimFloat: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24105 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24106 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24105});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam13, 2, 1, (V[]){v_x_24106});
  }
  case TAG_VPrimString: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24109 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24110 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24109});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam14, 2, 1, (V[]){v_x_24110});
  }
  case TAG_VPrimRune: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24113 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24114 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24113});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam15, 2, 1, (V[]){v_x_24114});
  }
  case TAG_VPrimArray: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24118 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24119 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24118});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam16, 2, 1, (V[]){v_x_24119});
  }
  case TAG_VFixed: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24123 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24124 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24123});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam17, 2, 1, (V[]){v_x_24124});
  }
  default: return heff_nomatch(v_ty_243);
  }
}
V g_heff_2eelab_2erules_2einstantiateGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einstantiateGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam2(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_x_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = v_x_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam5(V self, V *args) {
  V v_u_2446 = args[0];
  V v_x_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2446);
  V v_x1_2447 = heff_tr(heff_call(heff_get_n(v_x_2436, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2447)) {
  case TAG_Nom: {
    V v_x_2448 = heff_field(v_x1_2447, 0);
    heff_take_n(v_x1_2447, 1ULL, 1);
    return v_x_2448;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2447, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2450 = heff_field(v_x1_2447, 0);
    heff_take_n(v_x1_2447, 1ULL, 1);
    return v_x_2450;
  }
  default: return heff_nomatch(v_x1_2447);
  }
}
V g_heff_2eelab_2erules_2einstantiateGo_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_cod_2421 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_subgoals_244 = heff_env(self)[4];
  V v_hd_2434 = heff_env(self)[5];
  V v_k_2435 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2441;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_n_2437 = heff_dup(heff_field(v_cod_2421, 0));
    v_t_2441 = v_n_2437;
    break;
  }
  case TAG_CloConst: {
    v_t_2441 = ((V)&g_heff_2eelab_2erules_2einstantiateGo_str1);
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_t_2442 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2441, v_m_242, heff_dup(v_x_2436)));
  V v_x1_2452;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_vs_2444 = heff_field(v_cod_2421, 1);
    V v_body_2445 = heff_field(v_cod_2421, 2);
    heff_take_n(v_cod_2421, 6ULL, 3);
    v_x1_2452 = heff_tr(heff_call(v_body_2445, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2444, heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam5, 1, 1, (V[]){v_x_2436})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2451 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 1);
    heff_drop_rec(v_x_2436, 2);
    v_x1_2452 = v_body_2451;
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_t_2456;
  switch (heff_tag_of(v_x1_2452)) {
  case TAG_Nom: {
    V v_x_2453 = heff_field(v_x1_2452, 0);
    heff_take_n(v_x1_2452, 1ULL, 1);
    v_t_2456 = v_x_2453;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2452, 0ULL, 1);
    v_t_2456 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2455 = heff_field(v_x1_2452, 0);
    heff_take_n(v_x1_2452, 1ULL, 1);
    v_t_2456 = v_x_2455;
    break;
  }
  default: heff_nomatch(v_x1_2452);
  }
  V v_t_2457 = (g_heff_2eelab_2erules_2einstantiateGo(v_e_240, v_sp_241, v_t_2442, v_t_2456, v_subgoals_244));
  V f_ = v_t_2457;
  heff_room[0] = v_hd_2434;
  heff_room[1] = v_k_2435;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2einstantiateGo_lam3(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_cod_2421 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_subgoals_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2433;
  args[0] = heff_dup(v_hd_2434);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam4, 1, 7, (V[]){v_cod_2421, v_m_242, v_e_240, v_sp_241, v_subgoals_244, v_hd_2434, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam8(V self, V *args) {
  V v_u_2473 = args[0];
  V v_x_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2473);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_2467, 1, 2)});
}
V g_heff_2eelab_2erules_2einstantiateGo_lam9(V self, V *args) {
  V v_u_2479 = args[0];
  V v_x_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2479);
  return heff_get_n(v_x_2467, 1, 2);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam7(V self, V *args) {
  V v_x_2467 = args[0];
  V v_cod_2421 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_dom_2420 = heff_env(self)[2];
  V v_subgoals_244 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_hd_2458 = heff_env(self)[6];
  V v_k_2459 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2472;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_n_2468 = heff_dup(heff_field(v_cod_2421, 0));
    v_t_2472 = v_n_2468;
    break;
  }
  case TAG_CloConst: {
    v_t_2472 = ((V)&g_heff_2eelab_2erules_2einstantiateGo_str3);
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_t_2474 = heff_rec_n(2, shape_stx__val, (V[]){heff_dup(heff_rfield(v_x_2467, 0)), heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam8, 1, 1, (V[]){heff_dup(v_x_2467)})});
  V v_t_2475 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2472, v_m_242, v_t_2474));
  V v_x1_2481;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_vs_2477 = heff_field(v_cod_2421, 1);
    V v_body_2478 = heff_field(v_cod_2421, 2);
    heff_take_n(v_cod_2421, 6ULL, 3);
    v_x1_2481 = heff_tr(heff_call(v_body_2478, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2477, heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam9, 1, 1, (V[]){heff_dup(v_x_2467)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2480 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 1);
    v_x1_2481 = v_body_2480;
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_t_2485;
  switch (heff_tag_of(v_x1_2481)) {
  case TAG_Nom: {
    V v_x_2482 = heff_field(v_x1_2481, 0);
    heff_take_n(v_x1_2481, 1ULL, 1);
    v_t_2485 = v_x_2482;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2481, 0ULL, 1);
    v_t_2485 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2484 = heff_field(v_x1_2481, 0);
    heff_take_n(v_x1_2481, 1ULL, 1);
    v_t_2485 = v_x_2484;
    break;
  }
  default: heff_nomatch(v_x1_2481);
  }
  V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_hole__goal, (V[]){v_x_2467, v_dom_2420}), v_subgoals_244});
  V v_t_2487 = (g_heff_2eelab_2erules_2einstantiateGo(v_e_240, v_sp_241, v_t_2475, v_t_2485, v_t_2486));
  V f_ = v_t_2487;
  heff_room[0] = v_hd_2458;
  heff_room[1] = v_k_2459;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2einstantiateGo_lam6(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_cod_2421 = heff_env(self)[1];
  V v_dom_2420 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_m_242 = heff_env(self)[4];
  V v_subgoals_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2460 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_2461 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 4);
  V v_t_2466;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_n_2462 = heff_dup(heff_field(v_cod_2421, 0));
    v_t_2466 = v_n_2462;
    break;
  }
  case TAG_CloConst: {
    v_t_2466 = ((V)&g_heff_2eelab_2erules_2einstantiateGo_str2);
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  return ({ V a_0 = v_t_2460; V a_1 = v_t_2461; V a_2 = heff_dup(v_dom_2420); V a_3 = v_t_2466; V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_2458); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam7, 1, 8, (V[]){v_cod_2421, v_m_242, v_dom_2420, v_subgoals_244, v_e_240, v_sp_241, v_hd_2458, v_k_2459}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2461); r_; });
}
V g_heff_2eelab_2erules_2einstantiateGo_lam10(V self, V *args) {
  V v_hd_2494 = args[0];
  V v_k_2495 = args[1];
  V v_x_2493 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2494);
  V f_ = v_k_2495;
  args[0] = v_x_2493;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam11(V self, V *args) {
  V v_hd_2499 = args[0];
  V v_k_24100 = args[1];
  V v_x_2498 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2499);
  V f_ = v_k_24100;
  args[0] = v_x_2498;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam12(V self, V *args) {
  V v_hd_24103 = args[0];
  V v_k_24104 = args[1];
  V v_x_24102 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24103);
  V f_ = v_k_24104;
  args[0] = v_x_24102;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam13(V self, V *args) {
  V v_hd_24107 = args[0];
  V v_k_24108 = args[1];
  V v_x_24106 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24107);
  V f_ = v_k_24108;
  args[0] = v_x_24106;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam14(V self, V *args) {
  V v_hd_24111 = args[0];
  V v_k_24112 = args[1];
  V v_x_24110 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24111);
  V f_ = v_k_24112;
  args[0] = v_x_24110;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam15(V self, V *args) {
  V v_hd_24115 = args[0];
  V v_k_24116 = args[1];
  V v_x_24114 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24115);
  V f_ = v_k_24116;
  args[0] = v_x_24114;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam16(V self, V *args) {
  V v_hd_24120 = args[0];
  V v_k_24121 = args[1];
  V v_x_24119 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24120);
  V f_ = v_k_24121;
  args[0] = v_x_24119;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam17(V self, V *args) {
  V v_hd_24125 = args[0];
  V v_k_24126 = args[1];
  V v_x_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24125);
  V f_ = v_k_24126;
  args[0] = v_x_24124;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str0, 3, "Int");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str1, 7, "Float64");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str2, 6, "String");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str3, 4, "Rune");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str4, 5, "Array");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str5, 4, "Int8");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str6, 5, "Int16");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str7, 5, "Int32");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str8, 5, "Int64");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str9, 5, "UInt8");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str10, 6, "UInt16");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str11, 6, "UInt32");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str12, 6, "UInt64");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_str13, 7, "Float32");
Clo g_heff_2eelab_2erules_2erigidFormer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erigidFormer_entry, 2, 0};

V g_heff_2eelab_2erules_2erigidFormer(V v_mc_240, V v_v_241) {
top: ;
  V v_it_242 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_240, v_v_241));
  switch (heff_tag_of(v_it_242)) {
  case TAG_VNeu: {
    V v_it1_243 = heff_field(v_it_242, 0);
    V v_expansion_246 = heff_field(v_it_242, 3);
    heff_take_n(v_it_242, 9ULL, 5);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_expansion_246);
      return NTAG(TAG_Nothing);
    }
    case TAG_HGlobal: {
      V v_k_249 = heff_field(v_it1_243, 0);
      V v_ru_24it1_243_24HGlobal = heff_take_reuse_n(v_it1_243, 1ULL, 1);
      V v_t_2410 = heff_tr(heff_call(v_expansion_246, 1, (V[]){NTAG(TAG_MkUnit)}));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_IntoCons: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop(v_k_249);
        heff_drop_cell(v_ru_24it1_243_24HGlobal, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_NotApplicable: {
        return heff_tag_at_n(v_ru_24it1_243_24HGlobal, TAG_Just, 1, (V[]){v_k_249});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_expansion_246);
      return NTAG(TAG_Nothing);
    }
    case TAG_HError: {
      heff_drop(v_expansion_246);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  case TAG_VCode: {
    V v_t_2413 = heff_field(v_it_242, 0);
    V v_ru_24it_242_24VCode = heff_take_reuse_n(v_it_242, 1ULL, 1);
    V v_it_2414 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, v_t_2413));
    switch (heff_tag_of(v_it_2414)) {
    case TAG_VU: {
      heff_take_n(v_it_2414, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24VCode, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VDecode: {
      V v_it1_2416 = heff_field(v_it_2414, 0);
      heff_take_n(v_it_2414, 1ULL, 5);
      switch (heff_tag_of(v_it1_2416)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2416, 0ULL, 1);
        heff_drop_cell(v_ru_24it_242_24VCode, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_HGlobal: {
        V v_k_2422 = heff_field(v_it1_2416, 0);
        heff_take_n(v_it1_2416, 1ULL, 1);
        return heff_tag_at_n(v_ru_24it_242_24VCode, TAG_Just, 1, (V[]){v_k_2422});
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2416, 0ULL, 1);
        heff_drop_cell(v_ru_24it_242_24VCode, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_HError: {
        heff_drop_cell(v_ru_24it_242_24VCode, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_it1_2416);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_it_2414, 0ULL, 5);
      heff_drop_cell(v_ru_24it_242_24VCode, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VRecord: {
      heff_take_n(v_it_2414, 0ULL, 4);
      heff_drop_cell(v_ru_24it_242_24VCode, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VSum: {
      heff_take_n(v_it_2414, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24VCode, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VPrimInt: {
      return heff_tag_at_n(v_ru_24it_242_24VCode, TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2erigidFormer_str0)});
    }
    case TAG_VPrimFloat: {
      return heff_tag_at_n(v_ru_24it_242_24VCode, TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2erigidFormer_str1)});
    }
    case TAG_VPrimString: {
      return heff_tag_at_n(v_ru_24it_242_24VCode, TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2erigidFormer_str2)});
    }
    case TAG_VPrimRune: {
      return heff_tag_at_n(v_ru_24it_242_24VCode, TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2erigidFormer_str3)});
    }
    case TAG_VPrimArray: {
      heff_take_n(v_it_2414, 0ULL, 1);
      return heff_tag_at_n(v_ru_24it_242_24VCode, TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2erigidFormer_str4)});
    }
    case TAG_VFixed: {
      V v_w_2435 = heff_field(v_it_2414, 0);
      heff_take_n(v_it_2414, 1ULL, 1);
      V v_t_2436;
      switch (heff_tag_of(v_w_2435)) {
      case TAG_I8: {
        v_t_2436 = ((V)&g_heff_2eelab_2erules_2erigidFormer_str5);
        break;
      }
      case TAG_I16: {
        v_t_2436 = ((V)&g_heff_2eelab_2erules_2erigidFormer_str6);
        break;
      }
      case TAG_I32: {
        v_t_2436 = ((V)&g_heff_2eelab_2erules_2erigidFormer_str7);
        break;
      }
      case TAG_I64: {
        v_t_2436 = ((V)&g_heff_2eelab_2erules_2erigidFormer_str8);
        break;
      }
      case TAG_U8: {
        v_t_2436 = ((V)&g_heff_2eelab_2erules_2erigidFormer_str9);
        break;
      }
      case TAG_U16: {
        v_t_2436 = ((V)&g_heff_2eelab_2erules_2erigidFormer_str10);
        break;
      }
      case TAG_U32: {
        v_t_2436 = ((V)&g_heff_2eelab_2erules_2erigidFormer_str11);
        break;
      }
      case TAG_U64: {
        v_t_2436 = ((V)&g_heff_2eelab_2erules_2erigidFormer_str12);
        break;
      }
      case TAG_F32: {
        v_t_2436 = ((V)&g_heff_2eelab_2erules_2erigidFormer_str13);
        break;
      }
      default: heff_nomatch(v_w_2435);
      }
      return heff_tag_at_n(v_ru_24it_242_24VCode, TAG_Just, 1, (V[]){v_t_2436});
    }
    default: return heff_nomatch(v_it_2414);
    }
  }
  case TAG_VLam: {
    heff_take_n(v_it_242, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_VCons: {
    heff_take_n(v_it_242, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_VOpaque: {
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2eelab_2erules_2erigidFormer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2erigidFormer(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2emisfit_str0, 20, "the instance found, ");
HEFF_LIT(g_heff_2eelab_2erules_2emisfit_str1, 19, ", does not fit here");
Clo g_heff_2eelab_2erules_2emisfit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2emisfit_entry, 6, 0};

V g_heff_2eelab_2erules_2emisfit(V v_e_240, V v_sp_241, V v_w_242, V v_err_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_tr(heff_call(heff_get_n(v_w_242, 0, 6), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_msg_247 = heff_strAppend(((V)&g_heff_2eelab_2erules_2emisfit_str0), heff_strAppend(v_t_246, ((V)&g_heff_2eelab_2erules_2emisfit_str1)));
  V v_note_248 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_get_n(v_e_240, 1, 6), v_err_243));
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_msg_247, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2412, v_z_245});
}
V g_heff_2eelab_2erules_2emisfit_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2emisfit(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionIntroSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntroSyn_entry, 3, 0};

V g_heff_2eelab_2erules_2efunctionIntroSyn(V v_x_240, V v_dom_241, V v_body_242) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam0, 1, 3, (V[]){heff_dup(v_dom_241), v_x_240, heff_dup(v_body_242)})});
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2efunctionIntroSyn(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam3(V self, V *args) {
  V v_v_2414 = args[0];
  V v_scope_27_2415 = args[1];
  V v_body_242 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkSyn: {
    V v_f_2416 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    V v_t_2417 = heff_take_field(v_e_243, 2);
    V v_t_2420;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_ForNominative: {
      heff_drop(v_v_2414);
      v_t_2420 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2418 = heff_field(v_t_2417, 0);
      V v_sp_2419 = heff_field(v_t_2417, 1);
      V v_ru_24t_2417_24ForDescriptive = heff_take_reuse_n(v_t_2417, 3ULL, 2);
      v_t_2420 = heff_tag_at_n(v_ru_24t_2417_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2418, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2419, v_v_2414})});
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2421 = ({ V rv_0 = v_scope_27_2415; V rv_2 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_e_243, 58ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4044u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
    V f_ = v_f_2416;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam5(V self, V *args) {
  V v_u_2433 = args[0];
  V v_bty_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_bty_2425});
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam6(V self, V *args) {
  V v_u_2440 = args[0];
  V v_bty_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2440);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_bty_2425});
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_MkPair: {
    V v_ebody_2424 = heff_field(v_x_2423, 0);
    V v_bty_2425 = heff_field(v_x_2423, 1);
    V v_ru_24x_2423_24MkPair = heff_take_reuse_n(v_x_2423, 3ULL, 2);
    V v_t_2426 = heff_take_field(v_e_243, 2);
    V v_t_2429;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_ForNominative: {
      v_t_2429 = NTAG(TAG_N);
      break;
    }
    case TAG_ForDescriptive: {
      heff_take_n(v_t_2426, 0ULL, 2);
      v_t_2429 = NTAG(TAG_De);
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_t_2430 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
    V v_t_2431 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
    V v_t_2432 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2431, MK_INT(1LL)), heff_dup(v_bty_2425)));
    V v_cod_2434 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), heff_rec_n(2, shape_stx__val, (V[]){v_t_2432, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam5, 1, 1, (V[]){heff_dup(v_bty_2425)})})});
    V v_t_2435 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
    V v_t_2436 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(heff_rfield(v_e_243, 1)), v_t_2435, heff_dup(v_x_248), v_cod_2434));
    V v_t_2437 = (g_heff_2eelab_2ememoed_2elam(v_t_2429, heff_dup(heff_rfield(v_e_243, 1)), v_t_2430, v_t_2436, heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), v_ebody_2424})));
    V v_t_2438 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
    V v_t_2439 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2438, MK_INT(1LL)), heff_dup(v_bty_2425)));
    V v_cod_2441 = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_240, heff_rec_n(2, shape_stx__val, (V[]){v_t_2439, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam6, 1, 1, (V[]){v_bty_2425})})});
    V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
    V v_m_2443 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_get_n(v_e_243, 1, 6), v_t_2442, v_x_248, v_cod_2441));
    V v_x1_2444 = heff_tr(heff_call(heff_get_n(v_m_2443, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2448;
    switch (heff_tag_of(v_x1_2444)) {
    case TAG_Nom: {
      V v_x_2445 = heff_field(v_x1_2444, 0);
      heff_take_n(v_x1_2444, 1ULL, 1);
      v_t_2448 = v_x_2445;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2444, 0ULL, 1);
      v_t_2448 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2447 = heff_field(v_x1_2444, 0);
      heff_take_n(v_x1_2444, 1ULL, 1);
      v_t_2448 = v_x_2447;
      break;
    }
    default: heff_nomatch(v_x1_2444);
    }
    V v_x_2449 = heff_tag_at_n(v_ru_24x_2423_24MkPair, TAG_MkPair, 2, (V[]){v_t_2437, v_t_2448});
    V f_ = v_k_247;
    args[0] = v_x_2449;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_248, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_t_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_c_2422 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_240), v_t_2413, heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam3, 2, 2, (V[]){v_body_242, heff_dup(v_e_243)})));
  V f_ = v_c_2422;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam4, 1, 4, (V[]){v_e_243, v_x_240, v_x_248, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam2, 1, 5, (V[]){v_x_240, v_e_243, v_body_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroSyn_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_dom_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245;
  switch (heff_tag_of(v_dom_241)) {
  case TAG_MkTyp: {
    V v_f_244 = heff_field(v_dom_241, 0);
    heff_take_n(v_dom_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_dom_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroSyn_lam1, 2, 4, (V[]){v_c_245, v_x_240, v_e_243, v_body_242});
}
V g_heff_2eelab_2erules_2eelimPlain_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eelimPlain_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eelimPlain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimPlain_entry, 7, 0};

V g_heff_2eelab_2erules_2eelimPlain(V v_e_240, V v_ecallee_241, V v_dom_242, V v_cod_243, V v_arg_244, V v_z_245, V v_z_246) {
top: ;
  V v_c_248;
  switch (heff_tag_of(v_arg_244)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_arg_244, 0);
    v_c_248 = heff_tr(heff_call(heff_dup(v_f_247), 2, (V[]){v_e_240, v_dom_242}));
    break;
  }
  default: heff_nomatch(v_arg_244);
  }
  return heff_tail(v_c_248, 2, (V[]){v_z_245, heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam0, 1, 3, (V[]){v_ecallee_241, heff_dup(v_cod_243), v_z_246})});
}
V g_heff_2eelab_2erules_2eelimPlain_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2eelab_2erules_2eelimPlain(a[0], a[1], a[2], a3, a4, a[5], a[6]); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2eelab_2erules_2eelimPlain_lam1(V self, V *args) {
  V v_u_2414 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2414);
  V v_x1_2415 = heff_tr(heff_call(heff_get_n(v_x_249, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nom: {
    V v_x_2416 = heff_field(v_x1_2415, 0);
    heff_take_n(v_x1_2415, 1ULL, 1);
    return v_x_2416;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2415, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2418 = heff_field(v_x1_2415, 0);
    heff_take_n(v_x1_2415, 1ULL, 1);
    return v_x_2418;
  }
  default: return heff_nomatch(v_x1_2415);
  }
}
V g_heff_2eelab_2erules_2eelimPlain_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_ecallee_241 = heff_env(self)[0];
  V v_cod_243 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = (g_heff_2eelab_2ememoed_2eapp(v_ecallee_241, heff_dup(v_x_249)));
  V v_x1_2420;
  switch (heff_tag_of(v_cod_243)) {
  case TAG_MkClo: {
    V v_vs_2412 = heff_field(v_cod_243, 1);
    V v_body_2413 = heff_field(v_cod_243, 2);
    heff_take_n(v_cod_243, 6ULL, 3);
    v_x1_2420 = heff_tr(heff_call(v_body_2413, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2412, heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam1, 1, 1, (V[]){v_x_249})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2419 = heff_field(v_cod_243, 0);
    heff_take_n(v_cod_243, 1ULL, 1);
    heff_drop_rec(v_x_249, 2);
    v_x1_2420 = v_body_2419;
    break;
  }
  default: heff_nomatch(v_cod_243);
  }
  V v_t_2424;
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_Nom: {
    V v_x_2421 = heff_field(v_x1_2420, 0);
    heff_take_n(v_x1_2420, 1ULL, 1);
    v_t_2424 = v_x_2421;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2420, 0ULL, 1);
    v_t_2424 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2423 = heff_field(v_x1_2420, 0);
    heff_take_n(v_x1_2420, 1ULL, 1);
    v_t_2424 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_x1_2420);
  }
  V v_x_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_t_2424});
  V f_ = v_z_246;
  args[0] = v_x_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionElimC_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionElimC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionElimC_entry, 4, 0};

V g_heff_2eelab_2erules_2efunctionElimC(V v_checksOnly_240, V v_sp_241, V v_callee_242, V v_arg_243) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_lam0, 1, 4, (V[]){heff_dup(v_callee_242), v_sp_241, heff_dup(v_checksOnly_240), heff_dup(v_arg_243)})});
}
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2efunctionElimC(a0, a[1], a2, a3); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2efunctionElimC_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_checksOnly_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_arg_243 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_checksOnly_240; V a_1 = v_sp_241; V a_2 = v_arg_243; V a_3 = v_e_244; V a_4 = v_x_2412; V a_5 = v_hd_247; V a_6 = v_k_248; V r_ = (g_heff_2eelab_2erules_2eelimGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_checksOnly_240); heff_drop(v_arg_243); r_; });
}
V g_heff_2eelab_2erules_2efunctionElimC_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_arg_243 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_ecallee0_2410 = heff_field(v_x_249, 0);
    V v_a0_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_244), heff_dup(v_sp_241), v_ecallee0_2410, v_a0_2411, heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_lam3, 1, 6, (V[]){v_checksOnly_240, v_sp_241, v_arg_243, v_e_244, v_hd_247, v_k_248})));
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2erules_2efunctionElimC_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_arg_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_lam2, 1, 6, (V[]){v_e_244, v_sp_241, v_hd_247, v_checksOnly_240, v_arg_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionElimC_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_callee_242 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_checksOnly_240 = heff_env(self)[2];
  V v_arg_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246;
  switch (heff_tag_of(v_callee_242)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_callee_242, 0);
    heff_take_n(v_callee_242, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_callee_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_lam1, 2, 5, (V[]){v_c_246, v_e_244, v_sp_241, v_checksOnly_240, v_arg_243});
}
V g_heff_2eelab_2erules_2evarGo_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2evarGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2evarGo_entry, 6, 0};

V g_heff_2eelab_2erules_2evarGo(V v_x_240, V v_names_241, V v_x3_242, V v_locals_243, V v_n_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_CEmpty: {
    heff_drop(v_x_240);
    heff_drop(v_names_241);
    heff_drop(v_locals_243);
    heff_drop(v_n_244);
    heff_drop(v_i_245);
    return heff_tag_n(TAG_Left, 1, (V[]){NTAG(TAG_NotInScope)});
  }
  case TAG_CBind: {
    V v_c_27_246 = heff_field(v_x3_242, 0);
    V v_x32_247 = heff_field(v_x3_242, 1);
    V v_a_248 = heff_field(v_x3_242, 2);
    switch (heff_tag_of(v_x32_247)) {
    case TAG_BDelayedBy: {
      V v_k_249 = heff_field(v_x32_247, 0);
      switch (heff_tag_of(v_names_241)) {
      case TAG_Nil: {
        heff_drop(v_x_240);
        heff_drop(v_locals_243);
        heff_drop(v_n_244);
        heff_drop(v_i_245);
        return heff_tag_n(TAG_Left, 1, (V[]){NTAG(TAG_NotInScope)});
      }
      case TAG_Cons: {
        V v_x_27_2410 = heff_field(v_names_241, 0);
        V v_xs_2411 = heff_field(v_names_241, 1);
        V v_ru_24names_241_24Cons = heff_take_reuse_n(v_names_241, 3ULL, 2);
        switch (heff_tag_of(v_locals_243)) {
        case TAG_LNil: {
          heff_drop(v_x_240);
          heff_drop(v_n_244);
          heff_drop(v_i_245);
          heff_drop(v_x_27_2410);
          heff_drop(v_xs_2411);
          heff_drop_cell(v_ru_24names_241_24Cons, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){NTAG(TAG_NotInScope)});
        }
        case TAG_LSnoc: {
          V v_vs_2412 = heff_field(v_locals_243, 0);
          V v_v_2413 = heff_field(v_locals_243, 1);
          heff_take_n(v_locals_243, 3ULL, 2);
          if (heff_strEq_c_lent(v_x_240, v_x_27_2410, 2)) {
            heff_drop(v_x_240);
            heff_drop(v_xs_2411);
            heff_drop(v_vs_2412);
            if (heff_intLe_c(heff_dup(v_k_249), v_n_244)) {
              V v_t_2418 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_i_245}), heff_clo_n(g_heff_2eelab_2erules_2evarGo_lam0, 1, 1, (V[]){v_v_2413})});
              return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24names_241_24Cons, TAG_MkPair, 2, (V[]){v_t_2418, heff_dup(v_a_248)})});
            } else {
              heff_drop(v_i_245);
              heff_drop_cell(v_ru_24names_241_24Cons, 2);
              heff_drop(v_v_2413);
              return heff_tag_n(TAG_Left, 1, (V[]){NTAG(TAG_Delayed2)});
            }
          } else {
            heff_drop_cell(v_ru_24names_241_24Cons, 2);
            heff_drop(v_v_2413);
            V t_0 = v_x_240;
            V t_1 = v_xs_2411;
            V t_2 = v_c_27_246;
            V t_3 = v_vs_2412;
            V t_4 = v_n_244;
            V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
            v_x_240 = t_0;
            v_names_241 = t_1;
            v_x3_242 = t_2;
            v_locals_243 = t_3;
            v_n_244 = t_4;
            v_i_245 = t_5;
            goto top;
          }
        }
        case TAG_LChunkSnoc: {
          heff_take_n(v_locals_243, 0ULL, 2);
          heff_drop(v_x_240);
          heff_drop(v_n_244);
          heff_drop(v_i_245);
          heff_drop(v_x_27_2410);
          heff_drop(v_xs_2411);
          heff_drop_cell(v_ru_24names_241_24Cons, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){NTAG(TAG_NotInScope)});
        }
        default: return heff_nomatch(v_locals_243);
        }
      }
      default: return heff_nomatch(v_names_241);
      }
    }
    default: return heff_nomatch(v_x32_247);
    }
  }
  case TAG_CUndelay: {
    V v_c_27_2421 = heff_field(v_x3_242, 0);
    V t_0 = v_x_240;
    V t_1 = v_names_241;
    V t_2 = v_c_27_2421;
    V t_3 = v_locals_243;
    V t_4 = heff_intAdd(v_n_244, MK_INT(1LL));
    V t_5 = v_i_245;
    v_x_240 = t_0;
    v_names_241 = t_1;
    v_x3_242 = t_2;
    v_locals_243 = t_3;
    v_n_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2evarGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2evarGo(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2evarGo_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  V v_v_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tr(heff_call(v_v_2413, 1, (V[]){v_u_2416}));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2417});
}
HEFF_LIT(g_heff_2eelab_2erules_2eabandonChk_str0, 50, "can only use abandon when checking at a small type");
V g_heff_2eelab_2erules_2eabandonChk_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2eabandonChk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eabandonChk_lam1, 2, 0};
V g_heff_2eelab_2erules_2eabandonChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eabandonChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eabandonChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eabandonChk_entry, 1, 0};

V g_heff_2eelab_2erules_2eabandonChk(V v_sp_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eabandonChk_lam0, 2, 1, (V[]){v_sp_240})});
}
V g_heff_2eelab_2erules_2eabandonChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eabandonChk(a[0]);
}
V g_heff_2eelab_2erules_2eabandonChk_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eabandonM_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eabandonChk_lam2(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(321LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eabandonChk_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2411}));
  V f_ = heff_get_n(v_hd_247, 1, 3);
  args[0] = v_t_2412;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eabandonChk_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_241);
  V v_x1_243 = ({ V a_0 = v_a_242; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_a_242); r_; });
  V v_t_244;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Small: {
    v_t_244 = NTAG(TAG_True);
    break;
  }
  case TAG_Large: {
    v_t_244 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_t_244 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_sp_240);
    heff_drop(v_t_244);
    return ((V)&g_heff_2eelab_2erules_2eabandonChk_lam1_clo);
  } else {
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2eelab_2erules_2eabandonChk_lam2, 2, 1, (V[]){v_sp_240});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2edefaultChk_str0, 87, "a field's default names the fields before it and definitions, not the type's parameters");
V g_heff_2eelab_2erules_2edefaultChk_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2edefaultChk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultChk_lam3, 1, 0};
V g_heff_2eelab_2erules_2edefaultChk_lam4(V self, V *args);
V g_heff_2eelab_2erules_2edefaultChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edefaultChk_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edefaultChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaultChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultChk_entry, 3, 0};

V g_heff_2eelab_2erules_2edefaultChk(V v_sp_240, V v_i_241, V v_c_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2edefaultChk_lam0, 2, 3, (V[]){heff_dup(v_c_242), v_i_241, v_sp_240})});
}
V g_heff_2eelab_2erules_2edefaultChk_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2edefaultChk(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2edefaultChk_lam3(V self, V *args) {
  V v_c0_2410 = args[0];
  return heff_get_n(v_c0_2410, 3, 8);
}
V g_heff_2eelab_2erules_2edefaultChk_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = ({ V a_0 = v_x_2414; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_2414); r_; });
  V v_stx_2416 = heff_tr(heff_call(heff_get_n(v_t_2415, 0, 2), 1, (V[]){heff_take_field(v_x_249, 0)}));
  V v_t_2417 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(v_i_241, v_stx_2416));
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_249, 2);
    heff_drop(v_stx_2416);
    heff_drop(v_t_2417);
    V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(343LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2edefaultChk_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2420}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2421;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    heff_drop(v_t_2417);
    V v_t_2422 = ({ V rv_0 = v_stx_2416; V rr_ = heff_rec_reuse_nf(v_x_249, 2ULL, 2, shape_stx__val, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_248;
    args[0] = v_t_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2eelab_2erules_2edefaultChk_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2edefaultChk_lam3_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2edefaultChk_lam4, 1, 5, (V[]){v_x_249, v_i_241, v_sp_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2edefaultChk_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2edefaultChk_lam2, 1, 4, (V[]){v_hd_247, v_i_241, v_sp_240, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2edefaultChk_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246;
  switch (heff_tag_of(v_c_242)) {
  case TAG_MkChk: {
    V v_f_245 = heff_field(v_c_242, 0);
    heff_take_n(v_c_242, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 2, (V[]){v_e_243, v_a_244}));
    break;
  }
  default: heff_nomatch(v_c_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2edefaultChk_lam1, 2, 3, (V[]){v_c_246, v_i_241, v_sp_240});
}
V g_heff_2eelab_2erules_2edefaulted_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaulted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaulted_entry, 5, 0};

V g_heff_2eelab_2erules_2edefaulted(V v_e_240, V v_it_241, V v_x_242, V v_vs_243, V v_settings_244) {
top: ;
  V v_d_245 = heff_dup(heff_rfield(v_it_241, 3));
  V v_t_246 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), heff_rfield(v_d_245, 1)));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_vs_243);
    heff_drop_rec(v_d_245, 3);
    return ({ V a_0 = v_it_241; V a_1 = v_x_242; V a_2 = v_settings_244; V r_ = (g_heff_2eelab_2erules_2enotGiven(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
  }
  case TAG_Just: {
    V v_i_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_xs_248 = heff_get_n(v_d_245, 2, 3);
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_247))) {
      if (heff_intLt_c(heff_dup(v_i_247), heff_arrayLength_lent(v_xs_248, 0))) {
        V v_d_2411 = heff_arrayIndex(v_xs_248, v_i_247);
        return heff_clo_n(g_heff_2eelab_2erules_2edefaulted_lam0, 2, 6, (V[]){v_e_240, v_x_242, v_vs_243, v_d_2411, v_it_241, v_settings_244});
      } else {
        heff_drop_rec(v_e_240, 6);
        heff_drop(v_vs_243);
        heff_drop(v_i_247);
        heff_drop(v_xs_248);
        return ({ V a_0 = v_it_241; V a_1 = v_x_242; V a_2 = v_settings_244; V r_ = (g_heff_2eelab_2erules_2enotGiven(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
      }
    } else {
      heff_drop_rec(v_e_240, 6);
      heff_drop(v_vs_243);
      heff_drop(v_i_247);
      heff_drop(v_xs_248);
      return ({ V a_0 = v_it_241; V a_1 = v_x_242; V a_2 = v_settings_244; V r_ = (g_heff_2eelab_2erules_2enotGiven(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2erules_2edefaulted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edefaulted(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2edefaulted_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  V v_d_2411 = heff_env(self)[3];
  V v_it_241 = heff_env(self)[4];
  V v_settings_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_hd_2412);
  V v_t_2414 = heff_take_field(v_e_240, 2);
  V v_t_2417;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_ForNominative: {
    heff_drop(v_x_242);
    v_t_2417 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2415 = heff_field(v_t_2414, 0);
    V v_sp_2416 = heff_field(v_t_2414, 1);
    V v_ru_24t_2414_24ForDescriptive = heff_take_reuse_n(v_t_2414, 3ULL, 2);
    v_t_2417 = heff_tag_at_n(v_ru_24t_2414_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2415, heff_tag_n(TAG_SpProj, 2, (V[]){v_sp_2416, v_x_242})});
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = heff_get_n(v_e_240, 1, 6); V a_2 = v_vs_243; V a_3 = v_d_2411; V r_ = (g_heff_2eelab_2erules_2edefaultFor(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = heff_rec_n(4, shape_el__span__dflt__rest, (V[]){v_t_2418, heff_get_n(v_it_241, 0, 5), NTAG(TAG_True), v_settings_244});
  V f_ = v_k_2413;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ewritten_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ewritten_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ewritten_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ewritten_entry, 8, 0};

V g_heff_2eelab_2erules_2ewritten(V v_e_240, V v_it_241, V v_x_242, V v_fty_243, V v_fs_244, V v_rest_245, V v_hd_246, V v_k_247) {
top: ;
  return ({ V a_0 = heff_dup(v_e_240); V b_1 = heff_get_n(v_it_241, 1, 5); V a_2 = heff_dup(heff_rfield(v_fs_244, 0)); V a_3 = heff_dup(heff_rfield(v_fs_244, 3)); V a_4 = heff_dup(v_fty_243); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2ewritten_lam0, 1, 7, (V[]){v_fs_244, v_e_240, v_x_242, v_fty_243, v_hd_246, v_rest_245, v_k_247}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, b_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(b_1); r_; });
}
V g_heff_2eelab_2erules_2ewritten_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ewritten(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2ewritten_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_fs_244 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_rec_n(4, shape_el__span__dflt__rest, (V[]){v_x_2417, heff_get_n(v_fs_244, 2, 4), NTAG(TAG_False), v_rest_245});
  V f_ = v_k_247;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ewritten_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_fs_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_fty_243 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_248);
  V v_t_249 = heff_dup(heff_rfield(v_fs_244, 1));
  V v_c_2416;
  switch (heff_tag_of(v_t_249)) {
  case TAG_MkChk: {
    V v_f_2410 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    V v_t_2411 = heff_take_field(v_e_240, 2);
    V v_t_2414;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_ForNominative: {
      heff_drop(v_x_242);
      v_t_2414 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2412 = heff_field(v_t_2411, 0);
      V v_sp_2413 = heff_field(v_t_2411, 1);
      V v_ru_24t_2411_24ForDescriptive = heff_take_reuse_n(v_t_2411, 3ULL, 2);
      v_t_2414 = heff_tag_at_n(v_ru_24t_2411_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2412, heff_tag_n(TAG_SpProj, 2, (V[]){v_sp_2413, v_x_242})});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    V v_t_2415 = ({ V rv_2 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_e_240, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_2416 = heff_tr(heff_call(v_f_2410, 2, (V[]){v_t_2415, v_fty_243}));
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V f_ = v_c_2416;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ewritten_lam1, 1, 3, (V[]){v_fs_244, v_rest_245, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eintroGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eintroGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintroGo_entry, 6, 0};

V g_heff_2eelab_2erules_2eintroGo(V v_e_240, V v_it_241, V v_done_242, V v_vs_243, V v_settings_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_done_242);
    heff_drop(v_vs_243);
    return ({ V a_0 = v_e_240; V a_1 = v_it_241; V a_2 = v_settings_244; V r_ = (g_heff_2eelab_2erules_2eleftOver(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
  }
  case TAG_Cons: {
    V v_x61_246 = heff_field(v_x6_245, 0);
    V v_rest_247 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    switch (heff_tag_of(v_x61_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x61_246, 0);
      V v_fieldC_249 = heff_field(v_x61_246, 1);
      heff_take_n(v_x61_246, 3ULL, 2);
      V v_t_2410 = heff_tr(heff_call(v_fieldC_249, 1, (V[]){heff_dup(v_vs_243)}));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_MkField: {
        V v_fty_2411 = heff_field(v_t_2410, 0);
        V v_fvalue_2412 = heff_field(v_t_2410, 1);
        heff_take_n(v_t_2410, 3ULL, 2);
        V v_c_2416;
        switch (heff_tag_of(v_settings_244)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x6_245_24Cons, 2);
          v_c_2416 = (g_heff_2eelab_2erules_2edefaulted(heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_248), heff_dup(v_vs_243), NTAG(TAG_Nil)));
          break;
        }
        case TAG_Cons: {
          V v_fs_2413 = heff_field(v_settings_244, 0);
          V v_rest_2414 = heff_field(v_settings_244, 1);
          heff_take_n(v_settings_244, 3ULL, 2);
          if (heff_strEq_c(heff_dup(heff_rfield(v_fs_2413, 0)), heff_dup(v_x_248))) {
            heff_drop_cell(v_ru_24x6_245_24Cons, 2);
            v_c_2416 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ewritten_clo), 6, (V[]){heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_248), heff_dup(v_fty_2411), v_fs_2413, v_rest_2414}));
          } else {
            v_c_2416 = (g_heff_2eelab_2erules_2edefaulted(heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_248), heff_dup(v_vs_243), heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){v_fs_2413, v_rest_2414})));
          }
          break;
        }
        default: heff_nomatch(v_settings_244);
        }
        return heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam0, 2, 9, (V[]){v_c_2416, v_e_240, v_x_248, v_fty_2411, v_fvalue_2412, v_done_242, v_it_241, v_vs_243, v_rest_247});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_x61_246);
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eelab_2erules_2eintroGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eintroGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2eintroGo_lam2(V self, V *args) {
  V v_u_2432 = args[0];
  V v_fty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2432);
  return v_fty_2411;
}
V g_heff_2eelab_2erules_2eintroGo_lam5(V self, V *args) {
  V v_u_2442 = args[0];
  V v_v_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2442);
  return v_v_2434;
}
V g_heff_2eelab_2erules_2eintroGo_lam6(V self, V *args) {
  V v_x_2444 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_fty_2411 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_k_2418 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2445 = heff_rec_n(5, shape_name__ty__el__dflt__span, (V[]){v_x_248, v_fty_2411, heff_take_field(v_x_2419, 0), heff_take_field(v_x_2419, 2), heff_get_n(v_x_2419, 1, 4)});
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_x_2444});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eintroGo_lam4(V self, V *args) {
  V v_x_2439 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_v_2434 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_it_241 = heff_env(self)[3];
  V v_vs_243 = heff_env(self)[4];
  V v_x_2419 = heff_env(self)[5];
  V v_rest_247 = heff_env(self)[6];
  V v_hd_2417 = heff_env(self)[7];
  V v_fty_2411 = heff_env(self)[8];
  V v_k_2418 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_248), heff_dup(v_v_2434)}), NTAG(TAG_Nil)});
  V v_t_2441 = (g_heff_2eelab_2erules_2eappendP(v_done_242, v_t_2440));
  V v_c_2443 = (g_heff_2eelab_2erules_2eintroGo(v_x_2439, v_it_241, v_t_2441, heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_243, heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam5, 1, 1, (V[]){v_v_2434})}), heff_dup(heff_rfield(v_x_2419, 3)), v_rest_247));
  V f_ = v_c_2443;
  heff_room[0] = v_hd_2417;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam6, 1, 4, (V[]){v_x_248, v_fty_2411, v_x_2419, v_k_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eintroGo_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_v_2434 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_it_241 = heff_env(self)[4];
  V v_hd_2417 = heff_env(self)[5];
  V v_vs_243 = heff_env(self)[6];
  V v_x_2419 = heff_env(self)[7];
  V v_rest_247 = heff_env(self)[8];
  V v_fty_2411 = heff_env(self)[9];
  V v_k_2418 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_248), heff_dup(v_v_2434)}), NTAG(TAG_Nil)});
  V v_t_2438 = (g_heff_2eelab_2erules_2eappendP(heff_dup(v_done_242), v_t_2437));
  return ({ V a_0 = v_e_240; V a_1 = heff_dup(heff_rfield(v_it_241, 1)); V a_2 = v_t_2438; V a_3 = heff_dup(v_hd_2417); V a_4 = heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam4, 1, 10, (V[]){v_x_248, v_v_2434, v_done_242, v_it_241, v_vs_243, v_x_2419, v_rest_247, v_hd_2417, v_fty_2411, v_k_2418}); V r_ = (g_heff_2eelab_2erules_2eselfAdvance(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2438); r_; });
}
V g_heff_2eelab_2erules_2eintroGo_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_fty_2411 = heff_env(self)[2];
  V v_fvalue_2412 = heff_env(self)[3];
  V v_hd_2417 = heff_env(self)[4];
  V v_done_242 = heff_env(self)[5];
  V v_it_241 = heff_env(self)[6];
  V v_vs_243 = heff_env(self)[7];
  V v_rest_247 = heff_env(self)[8];
  V v_k_2418 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2420 = heff_dup(heff_rfield(v_e_240, 2));
  V v_v_2434;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_ForNominative: {
    V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_x_2419, 0)), 1, 2);
    V v_x2_2422 = heff_tr(heff_call(v_t_2421, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nom: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      heff_take_n(v_x2_2422, 1ULL, 1);
      v_v_2434 = v_x_2423;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x2_2422, 0ULL, 1);
      v_v_2434 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2425 = heff_field(v_x2_2422, 0);
      heff_take_n(v_x2_2422, 1ULL, 1);
      v_v_2434 = v_x_2425;
      break;
    }
    default: heff_nomatch(v_x2_2422);
    }
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2426 = heff_field(v_t_2420, 0);
    V v_sp_2427 = heff_field(v_t_2420, 1);
    V v_ru_24t_2420_24ForDescriptive = heff_take_reuse_n(v_t_2420, 3ULL, 2);
    V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_x_2419, 0)), 1, 2);
    V v_x2_2429 = heff_tr(heff_call(v_t_2428, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_Nom: {
      V v_v_2430 = heff_field(v_x2_2429, 0);
      heff_take_n(v_x2_2429, 1ULL, 1);
      heff_drop(v_h_2426);
      heff_drop(v_sp_2427);
      heff_drop_cell(v_ru_24t_2420_24ForDescriptive, 2);
      v_v_2434 = v_v_2430;
      break;
    }
    case TAG_Describe: {
      V v_desc_2431 = heff_field(v_x2_2429, 0);
      V v_ru_24x2_2429_24Describe = heff_take_reuse_n(v_x2_2429, 1ULL, 1);
      v_v_2434 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_2426, heff_tag_at_n(v_ru_24t_2420_24ForDescriptive, TAG_SpProj, 2, (V[]){v_sp_2427, heff_dup(v_x_248)}), heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam2, 1, 1, (V[]){heff_dup(v_fty_2411)}), heff_tag_at_n(v_ru_24x2_2429_24Describe, TAG_Just, 1, (V[]){v_desc_2431})));
      break;
    }
    case TAG_Become: {
      V v_v_2433 = heff_field(v_x2_2429, 0);
      heff_take_n(v_x2_2429, 1ULL, 1);
      heff_drop(v_h_2426);
      heff_drop(v_sp_2427);
      heff_drop_cell(v_ru_24t_2420_24ForDescriptive, 2);
      v_v_2434 = v_v_2433;
      break;
    }
    default: heff_nomatch(v_x2_2429);
    }
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  V v_c_2435 = (g_heff_2eelab_2erules_2echeckFixed(heff_dup(v_e_240), heff_dup(heff_rfield(v_x_2419, 1)), heff_dup(v_v_2434), v_fvalue_2412));
  V f_ = v_c_2435;
  heff_room[0] = heff_dup(v_hd_2417);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam3, 1, 11, (V[]){v_x_248, v_v_2434, v_done_242, v_e_240, v_it_241, v_hd_2417, v_vs_243, v_x_2419, v_rest_247, v_fty_2411, v_k_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eintroGo_lam0(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_fty_2411 = heff_env(self)[3];
  V v_fvalue_2412 = heff_env(self)[4];
  V v_done_242 = heff_env(self)[5];
  V v_it_241 = heff_env(self)[6];
  V v_vs_243 = heff_env(self)[7];
  V v_rest_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam1, 1, 10, (V[]){v_e_240, v_x_248, v_fty_2411, v_fvalue_2412, v_hd_2417, v_done_242, v_it_241, v_vs_243, v_rest_247, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2eplacesGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eplacesGo_24dps_entry, 3, 0};

V g_heff_2eelab_2erules_2eplacesGo_24dps(V v_x1_240, V v_k_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_b_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if ((heff_dup(v_b_243) == NTAG(TAG_True))) {
      heff_drop(v_b_243);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_241)}), heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_244;
      V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
      V t_2 = v_cell_245;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_b_243);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_rest_244;
      V t_1 = v_k_241;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eplacesGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eplacesGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str0, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str1, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str2, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str3, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str4, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str5, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str6, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str7, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str8, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str9, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str10, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str11, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str12, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str13, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str14, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str15, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str16, 12, "no such tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str17, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str18, 34, "wrong number of arguments for tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str19, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str20, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str21, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str22, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str23, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str24, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str25, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str26, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str27, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str28, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str29, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str30, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str31, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str32, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str33, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str34, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str35, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str36, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str37, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str38, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str39, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str40, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str41, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str42, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str43, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str44, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str45, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str46, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str47, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str48, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str49, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str50, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str51, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str52, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_str53, 63, " names no definition or binder in scope, so it is read as a tag");
V g_heff_2eelab_2erules_2esumIntroNow_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_lam6(V self, V *args); static Clo g_heff_2eelab_2erules_2esumIntroNow_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_lam6, 1, 0};
V g_heff_2eelab_2erules_2esumIntroNow_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumIntroNow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_entry, 4, 0};

V g_heff_2eelab_2erules_2esumIntroNow(V v_sp_240, V v_tsp_241, V v_x_242, V v_cs_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_lam0, 4, 4, (V[]){v_x_242, v_sp_240, v_tsp_241, v_cs_243})});
}
V g_heff_2eelab_2erules_2esumIntroNow_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumIntroNow(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2esumIntroNow_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2esumIntroNow_lam5(V self, V *args) {
  V v_i_24149 = args[0];
  V v_gs_24148 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_24150 = heff_arrayIndex(v_gs_24148, v_i_24149);
  return heff_get_n(v_m_24150, 0, 2);
}
V g_heff_2eelab_2erules_2esumIntroNow_lam6(V self, V *args) {
  V v_u_24152 = args[0];
  heff_drop(v_u_24152);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2esumIntroNow_lam4(V self, V *args) {
  V v_x_24147 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_gs_24148 = heff_arrayFromList(v_x_24147);
  V v_t_24151 = heff_arrayGenerate(heff_arrayLength_lent(v_gs_24148, 0), heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_lam5, 1, 1, (V[]){v_gs_24148}));
  V v_x_24153 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_STag, 2, (V[]){v_x_242, v_t_24151}), ((V)&g_heff_2eelab_2erules_2esumIntroNow_lam6_clo)});
  V f_ = v_k_247;
  args[0] = v_x_24153;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumIntroNow_lam3(V self, V *args) {
  V v_x_24145 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_cs_243 = heff_env(self)[1];
  V v_ts_24142 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24145);
  V v_c_24146 = (g_heff_2eelab_2erules_2etagArgsGo(v_e_244, v_cs_243, heff_arrayToList(v_ts_24142)));
  V f_ = v_c_24146;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_lam4, 1, 2, (V[]){v_x_242, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esumIntroNow_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_tsp_241 = heff_env(self)[5];
  V v_cs_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    V v_ru_24t_2413_24LikeU = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_2436;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2416 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_2416)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2416, 0ULL, 1);
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2416, 0ULL, 1);
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2416, 0ULL, 1);
        v_t_2436 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2416);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_2436);
      V v_t_2437 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str0), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str1)));
      V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_2437, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2439 = heff_tag_at_n(v_ru_24t_2413_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2440}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2441;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_2436);
      V v_t_2442 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_2443 = heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str2), heff_dup(v_x_242)));
      V v_msg_2444 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str3), v_t_2443);
      V v_t_2445 = heff_tag_at_n(v_ru_24t_2413_24LikeU, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str4))});
      V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_2444, v_tsp_241, v_t_2445});
      V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
      V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2448}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2449;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2413, 0ULL, 4);
    heff_drop(v_cs_243);
    V v_t_2475;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2455 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_2455)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2455, 0ULL, 1);
        v_t_2475 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2455, 0ULL, 1);
        v_t_2475 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2455, 0ULL, 1);
        v_t_2475 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2475 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2455);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_2475) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_2475);
      V v_t_2476 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str5), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str6)));
      V v_t_2477 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_2476, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2477})});
      V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
      V v_t_2480 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2479}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2480;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_2475);
      V v_t_2481 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_2482 = heff_strAppend(v_t_2481, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str7), heff_dup(v_x_242)));
      V v_msg_2483 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str8), v_t_2482);
      V v_t_2484 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str9))});
      V v_t_2485 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_2483, v_tsp_241, v_t_2484});
      V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2485})});
      V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
      V v_t_2488 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2487}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2488;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_cs_243);
    V v_t_24113;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2493 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_2493)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2493, 0ULL, 1);
        v_t_24113 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2493, 0ULL, 1);
        v_t_24113 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2493, 0ULL, 1);
        v_t_24113 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24113 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2493);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24113);
      V v_t_24114 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str10), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str11)));
      V v_t_24115 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24114, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24116 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24115})});
      V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
      V v_t_24118 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24117}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24118;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24113);
      V v_t_24119 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24120 = heff_strAppend(v_t_24119, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str12), heff_dup(v_x_242)));
      V v_msg_24121 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str13), v_t_24120);
      V v_t_24122 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str14))});
      V v_t_24123 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24121, v_tsp_241, v_t_24122});
      V v_t_24124 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24123})});
      V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
      V v_t_24126 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24125}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24126;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeSum: {
    V v_vs_24127 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24LikeSum = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    V v_t_24128 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), heff_rfield(v_vs_24127, 1)));
    V v_t_24134;
    switch (heff_tag_of(v_t_24128)) {
    case TAG_Nothing: {
      heff_drop_rec(v_vs_24127, 3);
      heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
      v_t_24134 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_i_24129 = heff_field(v_t_24128, 0);
      heff_take_n(v_t_24128, 1ULL, 1);
      V v_xs_24130 = heff_get_n(v_vs_24127, 2, 3);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_24129))) {
        if (heff_intLt_c(heff_dup(v_i_24129), heff_arrayLength_lent(v_xs_24130, 0))) {
          V v_t_24133 = heff_arrayIndex(v_xs_24130, v_i_24129);
          v_t_24134 = heff_tag_at_n(v_ru_24t_2413_24LikeSum, TAG_Just, 1, (V[]){v_t_24133});
        } else {
          heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
          heff_drop(v_i_24129);
          heff_drop(v_xs_24130);
          v_t_24134 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
        heff_drop(v_i_24129);
        heff_drop(v_xs_24130);
        v_t_24134 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_t_24128);
    }
    switch (heff_tag_of(v_t_24134)) {
    case TAG_Nothing: {
      heff_drop(v_tsp_241);
      heff_drop(v_cs_243);
      V v_t_24135 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24136 = heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str15), v_t_24135));
      V v_msg_24137 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str16), v_t_24136);
      V v_t_24138 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(315LL), NTAG(TAG_SError), v_msg_24137, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24139 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24138})});
      V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
      V v_t_24141 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24140}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24141;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Just: {
      V v_ts_24142 = heff_field(v_t_24134, 0);
      V v_ru_24t_24134_24Just = heff_take_reuse_n(v_t_24134, 1ULL, 1);
      V v_t_24143 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_cs_243));
      if (heff_intEq_c(heff_arrayLength_lent(v_ts_24142, 0), v_t_24143)) {
        heff_drop(v_sp_240);
        heff_drop_cell(v_ru_24t_24134_24Just, 1);
        return ({ V a_0 = heff_dup(v_e_244); V a_1 = v_x_2412; V a_2 = heff_dup(v_x_242); V a_3 = v_tsp_241; V a_4 = heff_dup(v_x_2412); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_lam3, 1, 6, (V[]){v_e_244, v_cs_243, v_ts_24142, v_hd_246, v_x_242, v_k_247}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2412); r_; });
      } else {
        heff_drop(v_tsp_241);
        heff_drop(v_cs_243);
        heff_drop(v_ts_24142);
        V v_t_24154 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
        V v_t_24155 = heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str17), v_t_24154));
        V v_msg_24156 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str18), v_t_24155);
        V v_t_24157 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(316LL), NTAG(TAG_SError), v_msg_24156, v_sp_240, NTAG(TAG_Nothing)});
        V v_t_24158 = heff_tag_at_n(v_ru_24t_24134_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24157})});
        V v_t_24159 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24158})});
        V v_t_24160 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24159}));
        V f_ = heff_get_n(v_hd_246, 1, 3);
        heff_room[0] = v_t_24160;
        heff_room[1] = v_k_247;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
    default: return heff_nomatch(v_t_24134);
    }
  }
  case TAG_LikeInt: {
    heff_drop(v_cs_243);
    V v_t_24182;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24182 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24162 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24162)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24162, 0ULL, 1);
        v_t_24182 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24162, 0ULL, 1);
        v_t_24182 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24162, 0ULL, 1);
        v_t_24182 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24182 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24162);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24182 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24182 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24182 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24182 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24182 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24182 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24182 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24182 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24182 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24182) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24182);
      V v_t_24183 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str19), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str20)));
      V v_t_24184 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24183, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24185 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24184})});
      V v_t_24186 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24185})});
      V v_t_24187 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24186}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24187;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24182);
      V v_t_24188 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24189 = heff_strAppend(v_t_24188, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str21), heff_dup(v_x_242)));
      V v_msg_24190 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str22), v_t_24189);
      V v_t_24191 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str23))});
      V v_t_24192 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24190, v_tsp_241, v_t_24191});
      V v_t_24193 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24192})});
      V v_t_24194 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24193})});
      V v_t_24195 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24194}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24195;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeFloat: {
    heff_drop(v_cs_243);
    V v_t_24217;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24217 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24197 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24197)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24197, 0ULL, 1);
        v_t_24217 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24197, 0ULL, 1);
        v_t_24217 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24197, 0ULL, 1);
        v_t_24217 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24217 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24197);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24217 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24217 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24217 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24217 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24217 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24217 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24217 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24217 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24217 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24217) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24217);
      V v_t_24218 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str24), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str25)));
      V v_t_24219 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24218, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24220 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24219})});
      V v_t_24221 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24220})});
      V v_t_24222 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24221}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24222;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24217);
      V v_t_24223 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24224 = heff_strAppend(v_t_24223, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str26), heff_dup(v_x_242)));
      V v_msg_24225 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str27), v_t_24224);
      V v_t_24226 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str28))});
      V v_t_24227 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24225, v_tsp_241, v_t_24226});
      V v_t_24228 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24227})});
      V v_t_24229 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24228})});
      V v_t_24230 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24229}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24230;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeString: {
    heff_drop(v_cs_243);
    V v_t_24252;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24252 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24232 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24232)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24232, 0ULL, 1);
        v_t_24252 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24232, 0ULL, 1);
        v_t_24252 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24232, 0ULL, 1);
        v_t_24252 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24252 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24232);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24252 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24252 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24252 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24252 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24252 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24252 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24252 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24252 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24252 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24252) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24252);
      V v_t_24253 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str29), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str30)));
      V v_t_24254 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24253, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24255 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24254})});
      V v_t_24256 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24255})});
      V v_t_24257 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24256}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24257;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24252);
      V v_t_24258 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24259 = heff_strAppend(v_t_24258, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str31), heff_dup(v_x_242)));
      V v_msg_24260 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str32), v_t_24259);
      V v_t_24261 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str33))});
      V v_t_24262 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24260, v_tsp_241, v_t_24261});
      V v_t_24263 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24262})});
      V v_t_24264 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24263})});
      V v_t_24265 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24264}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24265;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRune: {
    heff_drop(v_cs_243);
    V v_t_24287;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24287 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24267 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24267)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24267, 0ULL, 1);
        v_t_24287 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24267, 0ULL, 1);
        v_t_24287 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24267, 0ULL, 1);
        v_t_24287 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24287 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24267);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24287 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24287 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24287 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24287 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24287 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24287 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24287 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24287 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24287 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24287) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24287);
      V v_t_24288 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str34), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str35)));
      V v_t_24289 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24288, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24290 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24289})});
      V v_t_24291 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24290})});
      V v_t_24292 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24291}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24292;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24287);
      V v_t_24293 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24294 = heff_strAppend(v_t_24293, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str36), heff_dup(v_x_242)));
      V v_msg_24295 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str37), v_t_24294);
      V v_t_24296 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str38))});
      V v_t_24297 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24295, v_tsp_241, v_t_24296});
      V v_t_24298 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24297})});
      V v_t_24299 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24298})});
      V v_t_24300 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24299}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24300;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeArray: {
    V v_ru_24t_2413_24LikeArray = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_24323;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24323 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24303 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24303)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24303, 0ULL, 1);
        v_t_24323 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24303, 0ULL, 1);
        v_t_24323 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24303, 0ULL, 1);
        v_t_24323 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24323 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24303);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24323 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24323 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24323 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24323 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24323 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24323 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24323 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24323 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24323 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24323) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24323);
      V v_t_24324 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str39), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str40)));
      V v_t_24325 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24324, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24326 = heff_tag_at_n(v_ru_24t_2413_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24325})});
      V v_t_24327 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24326})});
      V v_t_24328 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24327}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24328;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24323);
      V v_t_24329 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24330 = heff_strAppend(v_t_24329, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str41), heff_dup(v_x_242)));
      V v_msg_24331 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str42), v_t_24330);
      V v_t_24332 = heff_tag_at_n(v_ru_24t_2413_24LikeArray, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str43))});
      V v_t_24333 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24331, v_tsp_241, v_t_24332});
      V v_t_24334 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24333})});
      V v_t_24335 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24334})});
      V v_t_24336 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24335}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24336;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2413_24LikeFixed = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_24359;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24359 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24339 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24339)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24339, 0ULL, 1);
        v_t_24359 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24339, 0ULL, 1);
        v_t_24359 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24339, 0ULL, 1);
        v_t_24359 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24359 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24339);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24359 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24359 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24359 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24359 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24359 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24359 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24359 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24359 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24359 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24359) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24359);
      V v_t_24360 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str44), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str45)));
      V v_t_24361 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24360, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24362 = heff_tag_at_n(v_ru_24t_2413_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24361})});
      V v_t_24363 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24362})});
      V v_t_24364 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24363}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24364;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24359);
      V v_t_24365 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24366 = heff_strAppend(v_t_24365, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str46), heff_dup(v_x_242)));
      V v_msg_24367 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str47), v_t_24366);
      V v_t_24368 = heff_tag_at_n(v_ru_24t_2413_24LikeFixed, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str48))});
      V v_t_24369 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24367, v_tsp_241, v_t_24368});
      V v_t_24370 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24369})});
      V v_t_24371 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24370})});
      V v_t_24372 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24371}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24372;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_NoRules: {
    heff_drop(v_cs_243);
    V v_t_24394;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24394 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24374 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24374)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24374, 0ULL, 1);
        v_t_24394 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24374, 0ULL, 1);
        v_t_24394 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24374, 0ULL, 1);
        v_t_24394 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24394 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24374);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24394 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24394 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24394 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24394 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24394 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24394 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24394 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24394 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24394 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24394) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24394);
      V v_t_24395 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str49), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str50)));
      V v_t_24396 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24395, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24397 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24396})});
      V v_t_24398 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24397})});
      V v_t_24399 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24398}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24399;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24394);
      V v_t_24400 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24401 = heff_strAppend(v_t_24400, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str51), heff_dup(v_x_242)));
      V v_msg_24402 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_str52), v_t_24401);
      V v_t_24403 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_str53))});
      V v_t_24404 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24402, v_tsp_241, v_t_24403});
      V v_t_24405 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24404})});
      V v_t_24406 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24405})});
      V v_t_24407 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24406}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24407;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2esumIntroNow_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_x_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_tsp_241 = heff_env(self)[2];
  V v_cs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_lam2, 1, 7, (V[]){v_x_242, v_sp_240, v_hd_246, v_k_247, v_e_244, v_tsp_241, v_cs_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}