// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_MkFolded 17353
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9006
#define TAG_SU 9427
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_applied 1586106042
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_conclusion 1382344475
#define LBL_defaults 1389419502
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_globals 352931696
#define LBL_goal 9673690
#define LBL_hole 9703815
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_name 9869138
#define LBL_rest 9992347
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_subgoals 820279267
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_applied__conclusion__subgoals[] = {LBL_applied, LBL_conclusion, LBL_subgoals};
static uint32_t shape_el__span__dflt__rest[] = {LBL_el, LBL_span, LBL_dflt, LBL_rest};
static uint32_t shape_hole__goal[] = {LBL_hole, LBL_goal};
static uint32_t shape_name__ty__el__dflt__span[] = {LBL_name, LBL_ty, LBL_el, LBL_dflt, LBL_span};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_clo;
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
HeffT1 g_heff_2eelab_2erules_2eannot_24cpr(V, V);
V g_heff_2eelab_2erules_2eanyIdxGo(V, V, V);
V g_heff_2eelab_2erules_2eanyIdxGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyIdxGo_clo;
V g_heff_2eelab_2erules_2eanyP(V, V);
V g_heff_2eelab_2erules_2eanyP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyP_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eappendP_24tok2(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24tok2_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2eapplyGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eapplyGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyGo_clo;
V g_heff_2eelab_2erules_2ecatMaybesR(V);
V g_heff_2eelab_2erules_2ecatMaybesR_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_clo;
V g_heff_2eelab_2erules_2ecatMaybesR_24dps(V, V);
V g_heff_2eelab_2erules_2ecatMaybesR_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_24dps_clo;
V g_heff_2eelab_2erules_2echeckFixed(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckFixed_clo;
V g_heff_2eelab_2erules_2echeckingCandidates(V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckingCandidates_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckingCandidates_clo;
V g_heff_2eelab_2erules_2edefaulted(V, V, V, V, V);
V g_heff_2eelab_2erules_2edefaulted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaulted_clo;
V g_heff_2eelab_2erules_2eelimPlain(V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimPlain_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimPlain_clo;
V g_heff_2eelab_2erules_2eerrorOf(V, V);
V g_heff_2eelab_2erules_2eerrorOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eerrorOf_clo;
V g_heff_2eelab_2erules_2eerrorOf_24tok2(V, V, V);
V g_heff_2eelab_2erules_2eerrorOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eerrorOf_24tok2_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2eimplicitArg(V, V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitArg_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einstantiateGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2einstantiateGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstantiateGo_clo;
V g_heff_2eelab_2erules_2eintroGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintroGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintroGo_clo;
V g_heff_2eelab_2erules_2eleftOver(V, V, V);
V g_heff_2eelab_2erules_2eleftOver_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eleftOver_clo;
V g_heff_2eelab_2erules_2ementionsTypeF(V, V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_clo;
V g_heff_2eelab_2erules_2enotGiven(V, V, V);
V g_heff_2eelab_2erules_2enotGiven_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotGiven_clo;
V g_heff_2eelab_2erules_2eplacesGo_24dps(V, V, V);
V g_heff_2eelab_2erules_2eplacesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesGo_24dps_clo;
HeffT2 g_heff_2eelab_2erules_2esealedOf_24cpr(V, V);
V g_heff_2eelab_2erules_2eselfAdvance(V, V, V, V, V);
V g_heff_2eelab_2erules_2eselfAdvance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eselfAdvance_clo;
V g_heff_2eelab_2erules_2esumIntroNow_24map0(V, V);
V g_heff_2eelab_2erules_2esumIntroNow_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntroNow_24map0_clo;
V g_heff_2eelab_2erules_2etagHidden(V, V, V, V, V);
V g_heff_2eelab_2erules_2etagHidden_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagHidden_clo;
V g_heff_2eelab_2erules_2etagsExposed(V, V, V, V);
V g_heff_2eelab_2erules_2etagsExposed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagsExposed_clo;
V g_heff_2eelab_2erules_2etriedCandidate(V, V, V, V, V);
V g_heff_2eelab_2erules_2etriedCandidate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etriedCandidate_clo;
V g_heff_2eelab_2erules_2ewritten(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ewritten_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewritten_clo;
V g_heff_2eelab_2erules_2ewrittenAt(V, V);
V g_heff_2eelab_2erules_2ewrittenAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewrittenAt_clo;
HeffT2 g_heff_2eelab_2erules_2ewrittenAt_24cpr(V, V);
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784(V, V);
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eebind(V, V);
V g_heff_2eelab_2evalue_2eebind_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_clo;
V g_heff_2eelab_2evalue_2eebind_24tok1(V, V, V);
V g_heff_2eelab_2evalue_2eebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_24tok1_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTypeF_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTypeF_entry, 3, 0};

V g_heff_2eelab_2erules_2ementionsTypeF(V v_r_240, V v_d_241, V v_t_242) {
top: ;
  V v_el_243 = heff_take_field(v_r_240, 0);
  V v_ty_244 = heff_get_n(v_r_240, 1, 3);
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop(v_d_241);
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return NTAG(TAG_False);
  }
  case TAG_SDecode: {
    V v_e_246 = heff_field(v_t_242, 0);
    heff_drop(v_ty_244);
    return heff_tail(v_el_243, 2, (V[]){v_d_241, heff_dup(v_e_246)});
  }
  case TAG_SFunction: {
    V v_dom_248 = heff_field(v_t_242, 1);
    V v_t3_249 = heff_field(v_t_242, 2);
    heff_drop(v_el_243);
    switch (heff_tag_of(v_t3_249)) {
    case TAG_MkAbs: {
      V v_b_2413 = heff_field(v_t3_249, 1);
      V v_t_2414 = heff_tr(heff_call(heff_dup(v_ty_244), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dom_248)}));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop(v_ty_244);
        heff_drop(v_t_2414);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2414);
        return heff_tail(v_ty_244, 2, (V[]){heff_intAdd(v_d_241, MK_INT(1LL)), heff_dup(v_b_2413)});
      }
    }
    case TAG_AbsConst: {
      V v_b_2415 = heff_field(v_t3_249, 0);
      V v_t_2416 = heff_tr(heff_call(heff_dup(v_ty_244), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dom_248)}));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop(v_ty_244);
        heff_drop(v_t_2416);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2416);
        return heff_tail(v_ty_244, 2, (V[]){v_d_241, heff_dup(v_b_2415)});
      }
    }
    default: return heff_nomatch(v_t3_249);
    }
  }
  case TAG_SRecord: {
    V v_ft_2418 = heff_field(v_t_242, 1);
    heff_drop(v_el_243);
    V v_t_2420 = heff_arrayToList(heff_dup(heff_rfield(v_ft_2418, 2)));
    return ({ V a_0 = MK_INT(0LL); V a_1 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_lam0, 2, 2, (V[]){v_ty_244, v_d_241}); V a_2 = v_t_2420; V r_ = (g_heff_2eelab_2erules_2eanyIdxGo(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
  }
  case TAG_SSum: {
    V v_vs_2423 = heff_field(v_t_242, 0);
    heff_drop(v_el_243);
    V v_keys_2424 = heff_dup(heff_rfield(v_vs_2423, 0));
    V v_values_2425 = heff_dup(heff_rfield(v_vs_2423, 2));
    V v_t_2426 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2424), heff_arrayToList(v_values_2425)));
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_lam1, 1, 2, (V[]){v_ty_244, v_d_241}); V a_1 = v_t_2426; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2426); r_; });
  }
  case TAG_SIsTy: {
    V v_a_2431 = heff_field(v_t_242, 0);
    heff_drop(v_el_243);
    return heff_tail(v_ty_244, 2, (V[]){v_d_241, heff_dup(v_a_2431)});
  }
  case TAG_SPrimInt: {
    heff_drop(v_d_241);
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return NTAG(TAG_False);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_d_241);
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return NTAG(TAG_False);
  }
  case TAG_SPrimString: {
    heff_drop(v_d_241);
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return NTAG(TAG_False);
  }
  case TAG_SPrimRune: {
    heff_drop(v_d_241);
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return NTAG(TAG_False);
  }
  case TAG_SPrimArray: {
    V v_a_2432 = heff_field(v_t_242, 0);
    heff_drop(v_el_243);
    return heff_tail(v_ty_244, 2, (V[]){v_d_241, heff_dup(v_a_2432)});
  }
  case TAG_SFixed: {
    heff_drop(v_d_241);
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2erules_2ementionsTypeF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2ementionsTypeF(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2ementionsTypeF_lam0(V self, V *args) {
  V v_i_2421 = args[0];
  V v_ty_2422 = args[1];
  V v_ty_244 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_ty_244;
  args[0] = heff_intAdd(v_d_241, v_i_2421);
  args[1] = v_ty_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ementionsTypeF_lam1(V self, V *args) {
  V v_x3_2427 = args[0];
  V v_ty_244 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_2427)) {
  case TAG_MkPair: {
    V v_args_2429 = heff_field(v_x3_2427, 1);
    heff_take_n(v_x3_2427, 2ULL, 2);
    V v_t_2430 = heff_tr(heff_call(v_ty_244, 1, (V[]){v_d_241}));
    return ({ V a_0 = v_t_2430; V b_1 = heff_arrayToList(v_args_2429); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_x3_2427);
  }
}
V g_heff_2eelab_2erules_2eerrorOf_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eerrorOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_lam0, 1, 0};
V g_heff_2eelab_2erules_2eerrorOf_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2eerrorOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_lam1, 1, 0};
V g_heff_2eelab_2erules_2eerrorOf_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2eerrorOf_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_lam2, 1, 0};
Clo g_heff_2eelab_2erules_2eerrorOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_entry, 2, 0};

V g_heff_2eelab_2erules_2eerrorOf(V v_hd_240, V v_k_241) {
top: ;
  V v_t_244 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2eerrorOf_lam0_clo)});
  V v_t_247 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2eerrorOf_lam1_clo), ((V)&g_heff_2eelab_2erules_2eerrorOf_lam2_clo)});
  return heff_tail(v_k_241, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_t_247})});
}
V g_heff_2eelab_2erules_2eerrorOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eerrorOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2eerrorOf_lam0(V self, V *args) {
  V v_u_242 = args[0];
  heff_drop(v_u_242);
  V v_t_243 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_243});
}
V g_heff_2eelab_2erules_2eerrorOf_lam1(V self, V *args) {
  V v_x_245 = args[0];
  heff_drop(v_x_245);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2eerrorOf_lam2(V self, V *args) {
  V v_x_246 = args[0];
  heff_drop(v_x_246);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
Clo g_heff_2eelab_2erules_2ecatMaybesR_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecatMaybesR_entry, 1, 0};

V g_heff_2eelab_2erules_2ecatMaybesR(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2erules_2ecatMaybesR_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2ecatMaybesR_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecatMaybesR(a[0]);
}
HEFF_LIT(g_heff_2eelab_2erules_2einstantiateGo_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einstantiateGo_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einstantiateGo_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einstantiateGo_str3, 1, "_");
V g_heff_2eelab_2erules_2einstantiateGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam9(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam10(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam11(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam12(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam13(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam14(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam15(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam16(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam17(V self, V *args);
Clo g_heff_2eelab_2erules_2einstantiateGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstantiateGo_entry, 5, 0};

V g_heff_2eelab_2erules_2einstantiateGo(V v_e_240, V v_sp_241, V v_m_242, V v_ty_243, V v_subgoals_244) {
top: ;
  switch (heff_tag_of(v_ty_243)) {
  case TAG_VU: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_247 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_246});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam0, 2, 1, (V[]){v_x_247});
  }
  case TAG_VDecode: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_2416 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_2415});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam1, 2, 1, (V[]){v_x_2416});
  }
  case TAG_VFunction: {
    V v_it4_2422 = heff_dup(heff_field(v_ty_243, 3));
    switch (heff_tag_of(v_it4_2422)) {
    case TAG_Expl: {
      heff_drop_rec(v_e_240, 6);
      heff_drop(v_sp_241);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
      V v_x_2426 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_2425});
      return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam2, 2, 1, (V[]){v_x_2426});
    }
    case TAG_Impl: {
      switch (heff_tag_of(v_ty_243)) {
      case TAG_VFunction: {
        V v_dom_2430 = heff_dup(heff_field(v_ty_243, 1));
        V v_cod_2431 = heff_dup(heff_field(v_ty_243, 2));
        V v_t_2439;
        switch (heff_tag_of(v_cod_2431)) {
        case TAG_MkClo: {
          V v_n_2435 = heff_dup(heff_field(v_cod_2431, 0));
          v_t_2439 = v_n_2435;
          break;
        }
        case TAG_CloConst: {
          v_t_2439 = ((V)&g_heff_2eelab_2erules_2einstantiateGo_str0);
          break;
        }
        default: heff_nomatch(v_cod_2431);
        }
        V v_c_2440 = (g_heff_2eelab_2erules_2eimplicitArg(heff_dup(v_e_240), heff_dup(v_sp_241), v_ty_243, v_dom_2430, v_t_2439));
        return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam3, 2, 6, (V[]){v_c_2440, v_cod_2431, v_m_242, v_e_240, v_sp_241, v_subgoals_244});
      }
      default: return heff_nomatch(v_ty_243);
      }
    }
    case TAG_Inst: {
      switch (heff_tag_of(v_ty_243)) {
      case TAG_VFunction: {
        V v_dom_2466 = heff_field(v_ty_243, 1);
        V v_cod_2467 = heff_field(v_ty_243, 2);
        heff_take_n(v_ty_243, 6ULL, 6);
        return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam6, 2, 6, (V[]){v_e_240, v_cod_2467, v_dom_2466, v_sp_241, v_m_242, v_subgoals_244});
      }
      default: return heff_nomatch(v_ty_243);
      }
    }
    default: return heff_nomatch(v_it4_2422);
    }
  }
  case TAG_VRecord: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24114 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24115 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24114});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam10, 2, 1, (V[]){v_x_24115});
  }
  case TAG_VSum: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24119 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24120 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24119});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam11, 2, 1, (V[]){v_x_24120});
  }
  case TAG_VPrimInt: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24123 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24124 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24123});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam12, 2, 1, (V[]){v_x_24124});
  }
  case TAG_VPrimFloat: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24127 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24128 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24127});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam13, 2, 1, (V[]){v_x_24128});
  }
  case TAG_VPrimString: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24131 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24132 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24131});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam14, 2, 1, (V[]){v_x_24132});
  }
  case TAG_VPrimRune: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24135 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24136 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24135});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam15, 2, 1, (V[]){v_x_24136});
  }
  case TAG_VPrimArray: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24140 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24141 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24140});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam16, 2, 1, (V[]){v_x_24141});
  }
  case TAG_VFixed: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    V v_t_24145 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_24146 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_24145});
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam17, 2, 1, (V[]){v_x_24146});
  }
  default: return heff_nomatch(v_ty_243);
  }
}
V g_heff_2eelab_2erules_2einstantiateGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einstantiateGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam2(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_x_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam5(V self, V *args) {
  V v_u_2453 = args[0];
  V v_x_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2453);
  V v_x1_2454 = heff_tr(heff_call(heff_get_n(v_x_2443, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2454)) {
  case TAG_Nom: {
    V v_x_2455 = heff_field(v_x1_2454, 0);
    heff_take_n(v_x1_2454, 1ULL, 1);
    return v_x_2455;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2454, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2457 = heff_field(v_x1_2454, 0);
    heff_take_n(v_x1_2454, 1ULL, 1);
    return v_x_2457;
  }
  default: return heff_nomatch(v_x1_2454);
  }
}
V g_heff_2eelab_2erules_2einstantiateGo_lam4(V self, V *args) {
  V v_x_2443 = args[0];
  V v_cod_2431 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_subgoals_244 = heff_env(self)[4];
  V v_hd_2441 = heff_env(self)[5];
  V v_k_2442 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2448;
  switch (heff_tag_of(v_cod_2431)) {
  case TAG_MkClo: {
    V v_n_2444 = heff_dup(heff_field(v_cod_2431, 0));
    v_t_2448 = v_n_2444;
    break;
  }
  case TAG_CloConst: {
    v_t_2448 = ((V)&g_heff_2eelab_2erules_2einstantiateGo_str1);
    break;
  }
  default: heff_nomatch(v_cod_2431);
  }
  V v_t_2449 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2448, v_m_242, heff_dup(v_x_2443)));
  V v_x1_2459;
  switch (heff_tag_of(v_cod_2431)) {
  case TAG_MkClo: {
    V v_vs_2451 = heff_field(v_cod_2431, 1);
    V v_body_2452 = heff_field(v_cod_2431, 2);
    heff_take_n(v_cod_2431, 6ULL, 3);
    v_x1_2459 = heff_tr(heff_call(v_body_2452, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2451, heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam5, 1, 1, (V[]){v_x_2443})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2458 = heff_field(v_cod_2431, 0);
    heff_take_n(v_cod_2431, 1ULL, 1);
    heff_drop_rec(v_x_2443, 2);
    v_x1_2459 = v_body_2458;
    break;
  }
  default: heff_nomatch(v_cod_2431);
  }
  V v_t_2463;
  switch (heff_tag_of(v_x1_2459)) {
  case TAG_Nom: {
    V v_x_2460 = heff_field(v_x1_2459, 0);
    heff_take_n(v_x1_2459, 1ULL, 1);
    v_t_2463 = v_x_2460;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2459, 0ULL, 1);
    v_t_2463 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2462 = heff_field(v_x1_2459, 0);
    heff_take_n(v_x1_2459, 1ULL, 1);
    v_t_2463 = v_x_2462;
    break;
  }
  default: heff_nomatch(v_x1_2459);
  }
  V v_t_2464 = (g_heff_2eelab_2erules_2einstantiateGo(v_e_240, v_sp_241, v_t_2449, v_t_2463, v_subgoals_244));
  V f_ = v_t_2464;
  heff_room[0] = v_hd_2441;
  heff_room[1] = v_k_2442;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2einstantiateGo_lam3(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_c_2440 = heff_env(self)[0];
  V v_cod_2431 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_subgoals_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2440;
  args[0] = heff_dup(v_hd_2441);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam4, 1, 7, (V[]){v_cod_2431, v_m_242, v_e_240, v_sp_241, v_subgoals_244, v_hd_2441, v_k_2442});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam8(V self, V *args) {
  V v_u_2491 = args[0];
  V v_x_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2491);
  return heff_get_n(v_x_2480, 1, 2);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam9(V self, V *args) {
  V v_u_2499 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_x_2480 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2499);
  V v_x2_24100 = heff_tr(heff_call(heff_get_n(v_m_242, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_24100)) {
  case TAG_Nom: {
    V v_x_24101 = heff_field(v_x2_24100, 0);
    heff_take_n(v_x2_24100, 1ULL, 1);
    return (g_heff_2eelab_2evalue_2eapp_24s435923339x187529784(v_x_2480, v_x_24101));
  }
  case TAG_Describe: {
    V v_x_24102 = heff_field(v_x2_24100, 0);
    heff_take_n(v_x2_24100, 1ULL, 1);
    return (g_heff_2eelab_2evalue_2eapp_24s435923339x187529784(v_x_2480, v_x_24102));
  }
  case TAG_Become: {
    V v_x_24103 = heff_field(v_x2_24100, 0);
    V v_ru_24x2_24100_24Become = heff_take_reuse_n(v_x2_24100, 1ULL, 1);
    V v_x1_24104 = heff_tr(g_heff_2eelab_2evalue_2eapp_24s435923339x187529784(v_x_2480, v_x_24103));
    V v_t_24108;
    switch (heff_tag_of(v_x1_24104)) {
    case TAG_Nom: {
      V v_x_24105 = heff_field(v_x1_24104, 0);
      heff_take_n(v_x1_24104, 1ULL, 1);
      v_t_24108 = v_x_24105;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24104, 0ULL, 1);
      v_t_24108 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24107 = heff_field(v_x1_24104, 0);
      heff_take_n(v_x1_24104, 1ULL, 1);
      v_t_24108 = v_x_24107;
      break;
    }
    default: heff_nomatch(v_x1_24104);
    }
    return heff_tag_at_n(v_ru_24x2_24100_24Become, TAG_Become, 1, (V[]){v_t_24108});
  }
  default: return heff_nomatch(v_x2_24100);
  }
}
V g_heff_2eelab_2erules_2einstantiateGo_lam7(V self, V *args) {
  V v_x_2480 = args[0];
  V v_cod_2467 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_dom_2466 = heff_env(self)[2];
  V v_subgoals_244 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_hd_2471 = heff_env(self)[6];
  V v_k_2472 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2485;
  switch (heff_tag_of(v_cod_2467)) {
  case TAG_MkClo: {
    V v_n_2481 = heff_dup(heff_field(v_cod_2467, 0));
    v_t_2485 = v_n_2481;
    break;
  }
  case TAG_CloConst: {
    v_t_2485 = ((V)&g_heff_2eelab_2erules_2einstantiateGo_str3);
    break;
  }
  default: heff_nomatch(v_cod_2467);
  }
  V v_t_2486 = heff_tag_n(TAG_SImplicit, 2, (V[]){v_t_2485, heff_dup(heff_rfield(v_x_2480, 0))});
  V v_t_2487 = heff_tag_n(TAG_SApp, 2, (V[]){heff_dup(heff_rfield(v_m_242, 0)), v_t_2486});
  V v_x1_2493;
  switch (heff_tag_of(v_cod_2467)) {
  case TAG_MkClo: {
    V v_vs_2489 = heff_field(v_cod_2467, 1);
    V v_body_2490 = heff_field(v_cod_2467, 2);
    heff_take_n(v_cod_2467, 6ULL, 3);
    v_x1_2493 = heff_tr(heff_call(v_body_2490, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2489, heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam8, 1, 1, (V[]){heff_dup(v_x_2480)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2492 = heff_field(v_cod_2467, 0);
    heff_take_n(v_cod_2467, 1ULL, 1);
    v_x1_2493 = v_body_2492;
    break;
  }
  default: heff_nomatch(v_cod_2467);
  }
  V v_t_2497;
  switch (heff_tag_of(v_x1_2493)) {
  case TAG_Nom: {
    V v_x_2494 = heff_field(v_x1_2493, 0);
    heff_take_n(v_x1_2493, 1ULL, 1);
    v_t_2497 = v_x_2494;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2493, 0ULL, 1);
    v_t_2497 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2496 = heff_field(v_x1_2493, 0);
    heff_take_n(v_x1_2493, 1ULL, 1);
    v_t_2497 = v_x_2496;
    break;
  }
  default: heff_nomatch(v_x1_2493);
  }
  V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_hole__goal, (V[]){heff_dup(v_x_2480), v_dom_2466}), v_subgoals_244});
  V v_t_24109 = (g_heff_2eelab_2erules_2einstantiateGo(v_e_240, v_sp_241, heff_rec_n(2, shape_stx__val, (V[]){v_t_2487, heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam9, 1, 2, (V[]){v_m_242, v_x_2480})}), v_t_2497, v_t_2498));
  V f_ = v_t_24109;
  heff_room[0] = v_hd_2471;
  heff_room[1] = v_k_2472;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2einstantiateGo_lam6(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_cod_2467 = heff_env(self)[1];
  V v_dom_2466 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_m_242 = heff_env(self)[4];
  V v_subgoals_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2473 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
  V v_t_2474 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 5);
  V v_t_2479;
  switch (heff_tag_of(v_cod_2467)) {
  case TAG_MkClo: {
    V v_n_2475 = heff_dup(heff_field(v_cod_2467, 0));
    v_t_2479 = v_n_2475;
    break;
  }
  case TAG_CloConst: {
    v_t_2479 = ((V)&g_heff_2eelab_2erules_2einstantiateGo_str2);
    break;
  }
  default: heff_nomatch(v_cod_2467);
  }
  return ({ V a_0 = v_t_2473; V a_1 = v_t_2474; V a_2 = heff_dup(v_dom_2466); V a_3 = v_t_2479; V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_2471); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam7, 1, 8, (V[]){v_cod_2467, v_m_242, v_dom_2466, v_subgoals_244, v_e_240, v_sp_241, v_hd_2471, v_k_2472}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2474); r_; });
}
V g_heff_2eelab_2erules_2einstantiateGo_lam10(V self, V *args) {
  V v_hd_24116 = args[0];
  V v_k_24117 = args[1];
  V v_x_24115 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24116);
  V f_ = v_k_24117;
  args[0] = v_x_24115;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam11(V self, V *args) {
  V v_hd_24121 = args[0];
  V v_k_24122 = args[1];
  V v_x_24120 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24121);
  V f_ = v_k_24122;
  args[0] = v_x_24120;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam12(V self, V *args) {
  V v_hd_24125 = args[0];
  V v_k_24126 = args[1];
  V v_x_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24125);
  V f_ = v_k_24126;
  args[0] = v_x_24124;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam13(V self, V *args) {
  V v_hd_24129 = args[0];
  V v_k_24130 = args[1];
  V v_x_24128 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24129);
  V f_ = v_k_24130;
  args[0] = v_x_24128;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam14(V self, V *args) {
  V v_hd_24133 = args[0];
  V v_k_24134 = args[1];
  V v_x_24132 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24133);
  V f_ = v_k_24134;
  args[0] = v_x_24132;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam15(V self, V *args) {
  V v_hd_24137 = args[0];
  V v_k_24138 = args[1];
  V v_x_24136 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24137);
  V f_ = v_k_24138;
  args[0] = v_x_24136;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam16(V self, V *args) {
  V v_hd_24142 = args[0];
  V v_k_24143 = args[1];
  V v_x_24141 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24142);
  V f_ = v_k_24143;
  args[0] = v_x_24141;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam17(V self, V *args) {
  V v_hd_24147 = args[0];
  V v_k_24148 = args[1];
  V v_x_24146 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24147);
  V f_ = v_k_24148;
  args[0] = v_x_24146;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2echeckingCandidates_lam1(V self, V *args);
V g_heff_2eelab_2erules_2echeckingCandidates_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2echeckingCandidates_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckingCandidates_entry, 5, 0};

V g_heff_2eelab_2erules_2echeckingCandidates(V v_e_240, V v_goal_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_goal_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_c_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_c_245)) {
    case TAG_MkPair: {
      V v_y_248 = heff_dup(heff_field(v_c_245, 1));
      v_t_249 = v_y_248;
      break;
    }
    default: heff_nomatch(v_c_245);
    }
    return ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_goal_241); V a_2 = v_t_249; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2eelab_2erules_2echeckingCandidates_lam0, 1, 6, (V[]){v_e_240, v_goal_241, v_rest_246, v_p_243, v_c_245, v_p_244}); V r_ = (g_heff_2eelab_2erules_2etriedCandidate(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_249); r_; });
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2echeckingCandidates_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2echeckingCandidates(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2echeckingCandidates_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413;
  if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_2410);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_245, v_x_2412});
  } else {
    heff_drop(v_x_2410);
    heff_drop(v_c_245);
    v_t_2413 = v_x_2412;
  }
  V f_ = v_p_244;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2echeckingCandidates_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_goal_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_c_245 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2411 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2echeckingCandidates_clo), 3, (V[]){v_e_240, v_goal_241, v_rest_246}));
  V f_ = v_c_2411;
  heff_room[0] = v_p_243;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2echeckingCandidates_lam1, 1, 3, (V[]){v_x_2410, v_c_245, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eelimPlain_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eelimPlain_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eelimPlain_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eelimPlain_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eelimPlain_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eelimPlain_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eelimPlain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimPlain_entry, 5, 0};

V g_heff_2eelab_2erules_2eelimPlain(V v_e_240, V v_ecallee_241, V v_dom_242, V v_cod_243, V v_arg_244) {
top: ;
  V v_stx_245 = heff_take_field(v_ecallee_241, 0);
  V v_val_246 = heff_get_n(v_ecallee_241, 1, 2);
  V v_c_248;
  switch (heff_tag_of(v_arg_244)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_arg_244, 0);
    v_c_248 = heff_tr(heff_call(heff_dup(v_f_247), 2, (V[]){v_e_240, v_dom_242}));
    break;
  }
  default: heff_nomatch(v_arg_244);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam0, 2, 4, (V[]){v_c_248, v_stx_245, v_val_246, heff_dup(v_cod_243)});
}
V g_heff_2eelab_2erules_2eelimPlain_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2eelab_2erules_2eelimPlain(a[0], a[1], a[2], a3, a4); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2eelab_2erules_2eelimPlain_lam4(V self, V *args) {
  V v_u2_2417 = args[0];
  V v_val_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2417);
  V v_x1_2418 = heff_tr(heff_call(v_val_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nom: {
    V v_x_2419 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    return v_x_2419;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2418, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2421 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    return v_x_2421;
  }
  default: return heff_nomatch(v_x1_2418);
  }
}
V g_heff_2eelab_2erules_2eelimPlain_lam3(V self, V *args) {
  V v_f_2416 = args[0];
  V v_val_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2416, heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam4, 1, 1, (V[]){v_val_2413})));
}
V g_heff_2eelab_2erules_2eelimPlain_lam2(V self, V *args) {
  V v_u_2414 = args[0];
  V v_val_246 = heff_env(self)[0];
  V v_val_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2414);
  V v_t_2415 = heff_tr(heff_call(v_val_246, 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2evalue_2eebind(heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam3, 1, 1, (V[]){v_val_2413}), v_t_2415));
}
V g_heff_2eelab_2erules_2eelimPlain_lam5(V self, V *args) {
  V v_u_2426 = args[0];
  V v_val_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2426);
  V v_x1_2427 = heff_tr(heff_call(v_val_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_Nom: {
    V v_x_2428 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 1);
    return v_x_2428;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2427, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2430 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 1);
    return v_x_2430;
  }
  default: return heff_nomatch(v_x1_2427);
  }
}
V g_heff_2eelab_2erules_2eelimPlain_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_stx_245 = heff_env(self)[0];
  V v_val_246 = heff_env(self)[1];
  V v_cod_243 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_stx_2412 = heff_take_field(v_x_2411, 0);
  V v_val_2413 = heff_get_n(v_x_2411, 1, 2);
  V v_t_2422 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_stx_245, v_stx_2412}), heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam2, 1, 2, (V[]){v_val_246, heff_dup(v_val_2413)})});
  V v_x1_2432;
  switch (heff_tag_of(v_cod_243)) {
  case TAG_MkClo: {
    V v_vs_2424 = heff_field(v_cod_243, 1);
    V v_body_2425 = heff_field(v_cod_243, 2);
    heff_take_n(v_cod_243, 6ULL, 3);
    v_x1_2432 = heff_tr(heff_call(v_body_2425, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2424, heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam5, 1, 1, (V[]){v_val_2413})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2431 = heff_field(v_cod_243, 0);
    heff_take_n(v_cod_243, 1ULL, 1);
    heff_drop(v_val_2413);
    v_x1_2432 = v_body_2431;
    break;
  }
  default: heff_nomatch(v_cod_243);
  }
  V v_t_2436;
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_Nom: {
    V v_x_2433 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    v_t_2436 = v_x_2433;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2432, 0ULL, 1);
    v_t_2436 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2435 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    v_t_2436 = v_x_2435;
    break;
  }
  default: heff_nomatch(v_x1_2432);
  }
  V v_x_2437 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_t_2436});
  V f_ = v_k_2410;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eelimPlain_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_stx_245 = heff_env(self)[1];
  V v_val_246 = heff_env(self)[2];
  V v_cod_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_248;
  args[0] = v_hd_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam1, 1, 4, (V[]){v_stx_245, v_val_246, v_cod_243, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eapply_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eapply_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eapply_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eapply_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eapply_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eapply_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V v_sp_240, V v_syn_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam0, 2, 2, (V[]){heff_dup(v_syn_241), v_sp_240})}});
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam3(V self, V *args) {
  V v_c_2411 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2411, 3, 9); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_m0_249 = heff_env(self)[0];
  V v_a1_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m0_249, v_a1_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2eapplyGo(v_sp_240, v_e_242, v_x_2415, v_x_2432, v_hd_246, v_k_247));
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_m0_249 = heff_env(self)[0];
  V v_a1_2410 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2415)));
  V v_t_2428;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFunction: {
    V v_implicit_2421 = heff_field(v_t_2416, 3);
    heff_take_n(v_t_2416, 8ULL, 4);
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_Impl: {
      v_t_2428 = NTAG(TAG_True);
      break;
    }
    case TAG_Inst: {
      v_t_2428 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2416, 0ULL, 3);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeInt: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFloat: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeString: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeRune: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_NoRules: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_c_2431;
  if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
    heff_drop(v_t_2428);
    v_c_2431 = heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam5, 2, 2, (V[]){v_m0_249, v_a1_2410});
  } else {
    heff_drop(v_t_2428);
    v_c_2431 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2einsertImplicits_clo), 4, (V[]){heff_dup(v_e_242), heff_dup(v_sp_240), v_m0_249, v_a1_2410}));
  }
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam6, 1, 5, (V[]){v_sp_240, v_e_242, v_x_2415, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_a0_243 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_m0_249 = heff_field(v_x_248, 0);
    V v_a1_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam3, 1, 1, (V[]){v_a0_243})})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2413}));
    V f_ = heff_dup(heff_rfield(v_hd_246, 1));
    heff_room[0] = v_t_2414;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam4, 1, 6, (V[]){v_m0_249, v_a1_2410, v_e_242, v_sp_240, v_hd_246, v_k_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_a0_243 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam2, 1, 5, (V[]){v_a0_243, v_hd_246, v_e_242, v_sp_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_syn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_syn_241)) {
  case TAG_MkSyn: {
    V v_f_244 = heff_field(v_syn_241, 0);
    heff_take_n(v_syn_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_e_242)}));
    break;
  }
  default: heff_nomatch(v_syn_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam1, 2, 4, (V[]){v_c_245, v_a0_243, v_e_242, v_sp_240});
}
V g_heff_2eelab_2erules_2eannot_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eannot_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eannot_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eannot_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2eannot_24cpr(V v_typ_240, V v_chk_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2eannot_24cpr_lam0, 1, 2, (V[]){heff_dup(v_typ_240), heff_dup(v_chk_241)})}});
}
V g_heff_2eelab_2erules_2eannot_24cpr_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2417 = heff_tr(heff_call(heff_get_n(v_x_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2421;
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nom: {
    V v_x_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2418;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2421 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2420 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x1_2417);
  }
  V v_x_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2416, v_t_2421});
  V f_ = v_k_247;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eannot_24cpr_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_chk_241 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_248, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_a_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_a_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_a_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_c_2415;
  switch (heff_tag_of(v_chk_241)) {
  case TAG_MkChk: {
    V v_f_2414 = heff_field(v_chk_241, 0);
    heff_take_n(v_chk_241, 1ULL, 1);
    v_c_2415 = heff_tr(heff_call(v_f_2414, 2, (V[]){v_e_242, v_a_2413}));
    break;
  }
  default: heff_nomatch(v_chk_241);
  }
  V f_ = v_c_2415;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eannot_24cpr_lam3, 1, 2, (V[]){v_x_248, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eannot_24cpr_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eannot_24cpr_lam2, 1, 4, (V[]){v_chk_241, v_e_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eannot_24cpr_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_typ_240 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_typ_240)) {
  case TAG_MkTyp: {
    V v_f_243 = heff_field(v_typ_240, 0);
    heff_take_n(v_typ_240, 1ULL, 1);
    V v_t_244 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(heff_rfield(v_e_242, 0)), heff_dup(heff_rfield(v_e_242, 1)), NTAG(TAG_ForNominative), heff_dup(heff_rfield(v_e_242, 3)), heff_dup(heff_rfield(v_e_242, 4)), heff_dup(heff_rfield(v_e_242, 5))});
    v_c_245 = heff_tr(heff_call(v_f_243, 1, (V[]){v_t_244}));
    break;
  }
  default: heff_nomatch(v_typ_240);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eannot_24cpr_lam1, 2, 3, (V[]){v_c_245, v_chk_241, v_e_242});
}
V g_heff_2eelab_2erules_2edefaulted_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edefaulted_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edefaulted_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaulted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaulted_entry, 5, 0};

V g_heff_2eelab_2erules_2edefaulted(V v_e_240, V v_it_241, V v_x_242, V v_vs_243, V v_settings_244) {
top: ;
  V v_elabFor_245 = heff_take_field(v_e_240, 2);
  V v_globals_246 = heff_get_n(v_e_240, 1, 6);
  V v_d_247 = heff_dup(heff_rfield(v_it_241, 3));
  V v_byName_248 = heff_take_field(v_d_247, 1);
  V v_values_249 = heff_get_n(v_d_247, 2, 3);
  HeffT2 v_t_2410 = ({ V a_0 = v_byName_248; V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_248); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_i_2413 = v_field_2412;
      V v_xs_2414 = v_values_249;
      if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2413, 1) && heff_intLt_c(heff_dup(v_i_2413), heff_arrayLength_lent(v_xs_2414, 0)))) {
        heff_drop(v_x_242);
        V v_d_2415 = heff_arrayIndex(v_xs_2414, v_i_2413);
        return heff_clo_n(g_heff_2eelab_2erules_2edefaulted_lam0, 2, 6, (V[]){v_elabFor_245, v_d_2415, v_globals_246, v_vs_243, v_it_241, v_settings_244});
      } else {
        heff_drop(v_vs_243);
        heff_drop(v_elabFor_245);
        heff_drop(v_globals_246);
        heff_drop(v_i_2413);
        heff_drop(v_xs_2414);
        return ({ V a_0 = v_it_241; V a_1 = v_x_242; V a_2 = v_settings_244; V r_ = (g_heff_2eelab_2erules_2enotGiven(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
      }
    } else {
      heff_drop(v_vs_243);
      heff_drop(v_elabFor_245);
      heff_drop(v_globals_246);
      heff_drop(v_values_249);
      heff_drop(v_field_2412);
      return ({ V a_0 = v_it_241; V a_1 = v_x_242; V a_2 = v_settings_244; V r_ = (g_heff_2eelab_2erules_2enotGiven(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
    }
  }
}
V g_heff_2eelab_2erules_2edefaulted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edefaulted(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2edefaulted_lam1(V self, V *args) {
  V v_u_2418 = args[0];
  V v_globals_246 = heff_env(self)[0];
  V v_d_2415 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2418);
  return (g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_globals_246, NTAG(TAG_N), v_d_2415, v_vs_243));
}
V g_heff_2eelab_2erules_2edefaulted_lam2(V self, V *args) {
  V v_u_2421 = args[0];
  V v_globals_246 = heff_env(self)[0];
  V v_d_2415 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2421);
  V v_x1_2422 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_globals_246, NTAG(TAG_N), v_d_2415, v_vs_243));
  V v_t_2426;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2423;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    v_t_2426 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2426});
}
V g_heff_2eelab_2erules_2edefaulted_lam0(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_elabFor_245 = heff_env(self)[0];
  V v_d_2415 = heff_env(self)[1];
  V v_globals_246 = heff_env(self)[2];
  V v_vs_243 = heff_env(self)[3];
  V v_it_241 = heff_env(self)[4];
  V v_settings_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_hd_2416);
  V v_t_2427;
  switch (heff_tag_of(v_elabFor_245)) {
  case TAG_ForNominative: {
    v_t_2427 = heff_rec_n(2, shape_stx__val, (V[]){heff_dup(v_d_2415), heff_clo_n(g_heff_2eelab_2erules_2edefaulted_lam1, 1, 3, (V[]){v_globals_246, v_d_2415, v_vs_243})});
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_elabFor_245, 0ULL, 2);
    v_t_2427 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(v_d_2415)}), heff_clo_n(g_heff_2eelab_2erules_2edefaulted_lam2, 1, 3, (V[]){v_globals_246, v_d_2415, v_vs_243})});
    break;
  }
  default: heff_nomatch(v_elabFor_245);
  }
  V v_t_2428 = heff_rec_n(4, shape_el__span__dflt__rest, (V[]){v_t_2427, heff_get_n(v_it_241, 0, 5), NTAG(TAG_True), v_settings_244});
  V f_ = v_k_2417;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eintroGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eintroGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintroGo_entry, 6, 0};

V g_heff_2eelab_2erules_2eintroGo(V v_e_240, V v_it_241, V v_done_242, V v_vs_243, V v_settings_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_done_242);
    heff_drop(v_vs_243);
    return ({ V a_0 = v_e_240; V a_1 = v_it_241; V a_2 = v_settings_244; V r_ = (g_heff_2eelab_2erules_2eleftOver(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
  }
  case TAG_Cons: {
    V v_x61_246 = heff_field(v_x6_245, 0);
    V v_rest_247 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    switch (heff_tag_of(v_x61_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x61_246, 0);
      V v_fieldC_249 = heff_field(v_x61_246, 1);
      heff_take_n(v_x61_246, 3ULL, 2);
      V v_t_2410 = heff_tr(heff_call(v_fieldC_249, 1, (V[]){heff_dup(v_vs_243)}));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_MkField: {
        V v_fty_2411 = heff_field(v_t_2410, 0);
        V v_fvalue_2412 = heff_field(v_t_2410, 1);
        heff_take_n(v_t_2410, 3ULL, 2);
        V v_c_2415;
        switch (heff_tag_of(v_settings_244)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x6_245_24Cons, 2);
          v_c_2415 = (g_heff_2eelab_2erules_2edefaulted(heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_248), heff_dup(v_vs_243), NTAG(TAG_Nil)));
          break;
        }
        case TAG_Cons: {
          V v_fs_2413 = heff_field(v_settings_244, 0);
          V v_rest_2414 = heff_field(v_settings_244, 1);
          heff_take_n(v_settings_244, 3ULL, 2);
          if (heff_strEq_c(heff_dup(heff_rfield(v_fs_2413, 0)), heff_dup(v_x_248))) {
            heff_drop_cell(v_ru_24x6_245_24Cons, 2);
            v_c_2415 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ewritten_clo), 6, (V[]){heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_248), heff_dup(v_fty_2411), v_fs_2413, v_rest_2414}));
          } else {
            v_c_2415 = (g_heff_2eelab_2erules_2edefaulted(heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_248), heff_dup(v_vs_243), heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){v_fs_2413, v_rest_2414})));
          }
          break;
        }
        default: heff_nomatch(v_settings_244);
        }
        return heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam0, 2, 9, (V[]){v_c_2415, v_e_240, v_x_248, v_fty_2411, v_fvalue_2412, v_done_242, v_it_241, v_vs_243, v_rest_247});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_x61_246);
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eelab_2erules_2eintroGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eintroGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2eintroGo_lam2(V self, V *args) {
  V v_u_2433 = args[0];
  V v_sp_2429 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2433);
  return heff_tag_n(TAG_SpProj, 2, (V[]){v_sp_2429, v_x_248});
}
V g_heff_2eelab_2erules_2eintroGo_lam3(V self, V *args) {
  V v_u_2435 = args[0];
  V v_fty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2435);
  return v_fty_2411;
}
V g_heff_2eelab_2erules_2eintroGo_lam6(V self, V *args) {
  V v_u_24108 = args[0];
  V v_v_24101 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24108);
  return v_v_24101;
}
V g_heff_2eelab_2erules_2eintroGo_lam7(V self, V *args) {
  V v_x_24110 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_fty_2411 = heff_env(self)[1];
  V v_el_2419 = heff_env(self)[2];
  V v_dflt_2422 = heff_env(self)[3];
  V v_span_2420 = heff_env(self)[4];
  V v_k_2417 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24111 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(5, shape_name__ty__el__dflt__span, (V[]){v_x_248, v_fty_2411, v_el_2419, v_dflt_2422, v_span_2420}), v_x_24110});
  V f_ = v_k_2417;
  args[0] = v_t_24111;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eintroGo_lam5(V self, V *args) {
  V v_x_24105 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_v_24101 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_it_241 = heff_env(self)[3];
  V v_vs_243 = heff_env(self)[4];
  V v_rest_2421 = heff_env(self)[5];
  V v_rest_247 = heff_env(self)[6];
  V v_hd_2416 = heff_env(self)[7];
  V v_fty_2411 = heff_env(self)[8];
  V v_el_2419 = heff_env(self)[9];
  V v_dflt_2422 = heff_env(self)[10];
  V v_span_2420 = heff_env(self)[11];
  V v_k_2417 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V v_t_24106 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_248), heff_dup(v_v_24101)}), NTAG(TAG_Nil)});
  V v_t_24107 = (g_heff_2eelab_2erules_2eappendP(v_done_242, v_t_24106));
  V v_c_24109 = (g_heff_2eelab_2erules_2eintroGo(v_x_24105, v_it_241, v_t_24107, heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_243, heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam6, 1, 1, (V[]){v_v_24101})}), v_rest_2421, v_rest_247));
  V f_ = v_c_24109;
  heff_room[0] = v_hd_2416;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam7, 1, 6, (V[]){v_x_248, v_fty_2411, v_el_2419, v_dflt_2422, v_span_2420, v_k_2417});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eintroGo_lam4(V self, V *args) {
  V v_x_24102 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_v_24101 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_it_241 = heff_env(self)[4];
  V v_hd_2416 = heff_env(self)[5];
  V v_vs_243 = heff_env(self)[6];
  V v_rest_2421 = heff_env(self)[7];
  V v_rest_247 = heff_env(self)[8];
  V v_fty_2411 = heff_env(self)[9];
  V v_el_2419 = heff_env(self)[10];
  V v_dflt_2422 = heff_env(self)[11];
  V v_span_2420 = heff_env(self)[12];
  V v_k_2417 = heff_env(self)[13];
  heff_clo_take(self, 14);
  heff_drop(v_x_24102);
  V v_t_24103 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_248), heff_dup(v_v_24101)}), NTAG(TAG_Nil)});
  V v_t_24104 = (g_heff_2eelab_2erules_2eappendP(heff_dup(v_done_242), v_t_24103));
  return (g_heff_2eelab_2erules_2eselfAdvance(v_e_240, heff_dup(heff_rfield(v_it_241, 1)), v_t_24104, heff_dup(v_hd_2416), heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam5, 1, 13, (V[]){v_x_248, v_v_24101, v_done_242, v_it_241, v_vs_243, v_rest_2421, v_rest_247, v_hd_2416, v_fty_2411, v_el_2419, v_dflt_2422, v_span_2420, v_k_2417})));
}
V g_heff_2eelab_2erules_2eintroGo_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_fty_2411 = heff_env(self)[2];
  V v_fvalue_2412 = heff_env(self)[3];
  V v_hd_2416 = heff_env(self)[4];
  V v_done_242 = heff_env(self)[5];
  V v_it_241 = heff_env(self)[6];
  V v_vs_243 = heff_env(self)[7];
  V v_rest_247 = heff_env(self)[8];
  V v_k_2417 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_el_2419 = heff_take_field(v_x_2418, 0);
  V v_span_2420 = heff_take_field(v_x_2418, 1);
  V v_rest_2421 = heff_take_field(v_x_2418, 3);
  V v_dflt_2422 = heff_get_n(v_x_2418, 2, 4);
  V v_t_2423 = heff_dup(heff_rfield(v_e_240, 2));
  V v_v_24101;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_ForNominative: {
    V v_x2_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_el_2419, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nom: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      heff_take_n(v_x2_2424, 1ULL, 1);
      v_v_24101 = v_x_2425;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x2_2424, 0ULL, 1);
      v_v_24101 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2427 = heff_field(v_x2_2424, 0);
      heff_take_n(v_x2_2424, 1ULL, 1);
      v_v_24101 = v_x_2427;
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2428 = heff_field(v_t_2423, 0);
    V v_sp_2429 = heff_field(v_t_2423, 1);
    V v_ru_24t_2423_24ForDescriptive = heff_take_reuse_n(v_t_2423, 3ULL, 2);
    V v_x2_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_el_2419, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_lit_2431 = v_x2_2430;
    V v_h_2432 = v_h_2428;
    V v_spineTh_2434 = heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam2, 1, 2, (V[]){v_sp_2429, heff_dup(v_x_248)});
    V v_ty_2436 = heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam3, 1, 1, (V[]){heff_dup(v_fty_2411)});
    switch (heff_tag_of(v_lit_2431)) {
    case TAG_Nom: {
      V v_v_2437 = heff_field(v_lit_2431, 0);
      V v_ru_24lit_2431_24Nom = heff_take_reuse_n(v_lit_2431, 1ULL, 1);
      heff_drop_clo(v_ty_2436, 1);
      switch (heff_tag_of(v_v_2437)) {
      case TAG_VNeu: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
        v_v_24101 = v_v_2437;
        break;
      }
      case TAG_VCode: {
        V v_v1_2443 = heff_dup(heff_field(v_v_2437, 0));
        switch (heff_tag_of(v_v1_2443)) {
        case TAG_VU: {
          heff_take_n(v_v1_2443, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VDecode: {
          heff_take_n(v_v1_2443, 0ULL, 5);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VFunction: {
          V v_level_2450 = heff_field(v_v1_2443, 0);
          V v_dom_2451 = heff_field(v_v1_2443, 1);
          V v_cod_2452 = heff_field(v_v1_2443, 2);
          V v_implicit_2453 = heff_field(v_v1_2443, 3);
          V v_dflt_2454 = heff_field(v_v1_2443, 4);
          V v_ru_24v1_2443_24VFunction = heff_take_reuse_n(v_v1_2443, 31ULL, 6);
          switch (heff_tag_of(v_v_2437)) {
          case TAG_VCode: {
            V v_ru_24v_2437_24VCode = heff_take_reuse_n(v_v_2437, 0ULL, 1);
            V v_t_2457 = heff_tag_at_n(v_ru_24lit_2431_24Nom, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24t_2423_24ForDescriptive, TAG_MkFolded, 2, (V[]){v_h_2432, v_spineTh_2434})});
            v_v_24101 = heff_tag_at_n(v_ru_24v_2437_24VCode, TAG_VCode, 1, (V[]){heff_tag_at_n(v_ru_24v1_2443_24VFunction, TAG_VFunction, 6, (V[]){v_level_2450, v_dom_2451, v_cod_2452, v_implicit_2453, v_dflt_2454, v_t_2457})});
            break;
          }
          default: heff_nomatch(v_v_2437);
          }
          break;
        }
        case TAG_VRecord: {
          heff_take_n(v_v1_2443, 0ULL, 4);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VSum: {
          heff_take_n(v_v1_2443, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VPrimInt: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VPrimFloat: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VPrimString: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VPrimRune: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VPrimArray: {
          heff_take_n(v_v1_2443, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VFixed: {
          heff_take_n(v_v1_2443, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        default: heff_nomatch(v_v1_2443);
        }
        break;
      }
      case TAG_VLam: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
        v_v_24101 = v_v_2437;
        break;
      }
      case TAG_VCons: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
        v_v_24101 = v_v_2437;
        break;
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
        v_v_24101 = v_v_2437;
        break;
      }
      default: heff_nomatch(v_v_2437);
      }
      break;
    }
    case TAG_Describe: {
      V v_desc_2468 = heff_field(v_lit_2431, 0);
      V v_ru_24lit_2431_24Describe = heff_take_reuse_n(v_lit_2431, 1ULL, 1);
      heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
      V v_t_2469 = heff_tr(heff_call(v_spineTh_2434, 1, (V[]){NTAG(TAG_MkUnit)}));
      v_v_24101 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_2432, v_t_2469, v_ty_2436, heff_tag_at_n(v_ru_24lit_2431_24Describe, TAG_Just, 1, (V[]){v_desc_2468})));
      break;
    }
    case TAG_Become: {
      V v_v_2470 = heff_field(v_lit_2431, 0);
      V v_ru_24lit_2431_24Become = heff_take_reuse_n(v_lit_2431, 1ULL, 1);
      heff_drop_clo(v_ty_2436, 1);
      switch (heff_tag_of(v_v_2470)) {
      case TAG_VNeu: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Become, 1);
        v_v_24101 = v_v_2470;
        break;
      }
      case TAG_VCode: {
        V v_v1_2476 = heff_dup(heff_field(v_v_2470, 0));
        switch (heff_tag_of(v_v1_2476)) {
        case TAG_VU: {
          heff_take_n(v_v1_2476, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VDecode: {
          heff_take_n(v_v1_2476, 0ULL, 5);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VFunction: {
          V v_level_2483 = heff_field(v_v1_2476, 0);
          V v_dom_2484 = heff_field(v_v1_2476, 1);
          V v_cod_2485 = heff_field(v_v1_2476, 2);
          V v_implicit_2486 = heff_field(v_v1_2476, 3);
          V v_dflt_2487 = heff_field(v_v1_2476, 4);
          V v_ru_24v1_2476_24VFunction = heff_take_reuse_n(v_v1_2476, 31ULL, 6);
          switch (heff_tag_of(v_v_2470)) {
          case TAG_VCode: {
            V v_ru_24v_2470_24VCode = heff_take_reuse_n(v_v_2470, 0ULL, 1);
            V v_t_2490 = heff_tag_at_n(v_ru_24lit_2431_24Become, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24t_2423_24ForDescriptive, TAG_MkFolded, 2, (V[]){v_h_2432, v_spineTh_2434})});
            v_v_24101 = heff_tag_at_n(v_ru_24v_2470_24VCode, TAG_VCode, 1, (V[]){heff_tag_at_n(v_ru_24v1_2476_24VFunction, TAG_VFunction, 6, (V[]){v_level_2483, v_dom_2484, v_cod_2485, v_implicit_2486, v_dflt_2487, v_t_2490})});
            break;
          }
          default: heff_nomatch(v_v_2470);
          }
          break;
        }
        case TAG_VRecord: {
          heff_take_n(v_v1_2476, 0ULL, 4);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VSum: {
          heff_take_n(v_v1_2476, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VPrimInt: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VPrimFloat: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VPrimString: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VPrimRune: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VPrimArray: {
          heff_take_n(v_v1_2476, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VFixed: {
          heff_take_n(v_v1_2476, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        default: heff_nomatch(v_v1_2476);
        }
        break;
      }
      case TAG_VLam: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Become, 1);
        v_v_24101 = v_v_2470;
        break;
      }
      case TAG_VCons: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Become, 1);
        v_v_24101 = v_v_2470;
        break;
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Become, 1);
        v_v_24101 = v_v_2470;
        break;
      }
      default: heff_nomatch(v_v_2470);
      }
      break;
    }
    default: heff_nomatch(v_lit_2431);
    }
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  return (g_heff_2eelab_2erules_2echeckFixed(heff_dup(v_e_240), heff_dup(v_span_2420), heff_dup(v_v_24101), v_fvalue_2412, heff_dup(v_hd_2416), heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam4, 1, 14, (V[]){v_x_248, v_v_24101, v_done_242, v_e_240, v_it_241, v_hd_2416, v_vs_243, v_rest_2421, v_rest_247, v_fty_2411, v_el_2419, v_dflt_2422, v_span_2420, v_k_2417})));
}
V g_heff_2eelab_2erules_2eintroGo_lam0(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_fty_2411 = heff_env(self)[3];
  V v_fvalue_2412 = heff_env(self)[4];
  V v_done_242 = heff_env(self)[5];
  V v_it_241 = heff_env(self)[6];
  V v_vs_243 = heff_env(self)[7];
  V v_rest_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam1, 1, 10, (V[]){v_e_240, v_x_248, v_fty_2411, v_fvalue_2412, v_hd_2416, v_done_242, v_it_241, v_vs_243, v_rest_247, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2eplacesGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eplacesGo_24dps_entry, 3, 0};

V g_heff_2eelab_2erules_2eplacesGo_24dps(V v_x1_240, V v_k_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_b_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if ((heff_dup(v_b_243) == NTAG(TAG_True))) {
      heff_drop(v_b_243);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_241)}), heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_244;
      V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
      V t_2 = v_cell_245;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_b_243);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_rest_244;
      V t_1 = v_k_241;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eplacesGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eplacesGo_24dps(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2etagsExposed_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etagsExposed_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagsExposed_lam0, 2, 0};
V g_heff_2eelab_2erules_2etagsExposed_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2etagsExposed_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagsExposed_lam1, 2, 0};
V g_heff_2eelab_2erules_2etagsExposed_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2etagsExposed_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagsExposed_lam2, 2, 0};
V g_heff_2eelab_2erules_2etagsExposed_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2etagsExposed_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagsExposed_lam3, 2, 0};
V g_heff_2eelab_2erules_2etagsExposed_lam5(V self, V *args);
V g_heff_2eelab_2erules_2etagsExposed_lam4(V self, V *args);
Clo g_heff_2eelab_2erules_2etagsExposed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagsExposed_entry, 4, 0};

V g_heff_2eelab_2erules_2etagsExposed(V v_e_240, V v_a_241, V v_vs_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop_rec(v_vs_242, 3);
    return ((V)&g_heff_2eelab_2erules_2etagsExposed_lam0_clo);
  }
  case TAG_Cons: {
    V v_x41_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x41_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x41_246, 0);
      V v_tsp_249 = heff_field(v_x41_246, 1);
      HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_vs_242, 1), v_x_248));
      V v_c_2426;
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_i_2413 = v_field_2412;
          V v_xs_2414 = heff_dup(heff_rfield(v_vs_242, 2));
          if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2413, 1) && heff_intLt_c(heff_dup(v_i_2413), heff_arrayLength_lent(v_xs_2414, 0)))) {
            V v_x_2415 = heff_arrayIndex(v_xs_2414, v_i_2413);
            heff_drop(v_x_2415);
            HeffT2 v_t_2416 = (g_heff_2eelab_2erules_2esealedOf_24cpr(heff_dup(heff_rfield(v_e_240, 1)), heff_dup(v_a_241)));
            {
              V v_field_2418 = v_t_2416.f[1];
              int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
              if ((v_tag_2417 == ((int64_t)0ULL))) {
                V v_m_2419 = v_field_2418;
                v_c_2426 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2etagHidden_clo), 3, (V[]){heff_dup(v_tsp_249), heff_dup(v_x_248), v_m_2419}));
              } else {
                heff_drop(v_field_2418);
                v_c_2426 = ((V)&g_heff_2eelab_2erules_2etagsExposed_lam1_clo);
              }
            }
          } else {
            heff_drop(v_i_2413);
            heff_drop(v_xs_2414);
            v_c_2426 = ((V)&g_heff_2eelab_2erules_2etagsExposed_lam2_clo);
          }
        } else {
          heff_drop(v_field_2412);
          v_c_2426 = ((V)&g_heff_2eelab_2erules_2etagsExposed_lam3_clo);
        }
      }
      return heff_clo_n(g_heff_2eelab_2erules_2etagsExposed_lam4, 2, 5, (V[]){v_c_2426, v_e_240, v_a_241, v_vs_242, heff_dup(v_rest_247)});
    }
    default: return heff_nomatch(v_x41_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2etagsExposed_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2etagsExposed(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2etagsExposed_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagsExposed_lam1(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagsExposed_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagsExposed_lam3(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagsExposed_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2427 = heff_env(self)[4];
  V v_k_2428 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2429);
  V v_t_2430 = ({ V a_0 = v_e_240; V a_1 = v_a_241; V a_2 = v_vs_242; V a_3 = v_rest_247; V r_ = (g_heff_2eelab_2erules_2etagsExposed(a_0, a_1, a_2, a_3)); heff_drop(v_rest_247); r_; });
  V f_ = v_t_2430;
  heff_room[0] = v_hd_2427;
  heff_room[1] = v_k_2428;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etagsExposed_lam4(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_vs_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2426;
  args[0] = heff_dup(v_hd_2427);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2etagsExposed_lam5, 1, 6, (V[]){v_e_240, v_a_241, v_vs_242, v_rest_247, v_hd_2427, v_k_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2esumIntroNow_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_24map0_entry, 2, 0};

V g_heff_2eelab_2erules_2esumIntroNow_24map0(V v_box_24i_240, V v_a_241) {
  int64_t v_i_240 = heff_unbox_word(v_box_24i_240);
  v_a_241 = heff_arrayOwn(v_a_241);
  if ((((int64_t)0ULL) <= v_i_240)) {
    top_TAG_InRange: ;
    if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
      V v_m_242 = heff_arrayIndexIn_lent(v_a_241, heff_box_word(v_i_240), 2);
      V v_t_243 = heff_arraySetOwnedIn(v_a_241, heff_box_word(v_i_240), heff_get_n(v_m_242, 0, 2));
      int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
      V t_1 = v_t_243;
      v_i_240 = t_0;
      v_a_241 = t_1;
      goto top_TAG_InRange;
    } else {
      return v_a_241;
    }
  } else {
  }
top: ;
  if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
    V v_m_242 = heff_arrayIndex_lent(v_a_241, heff_box_word(v_i_240), 2);
    V v_t_243 = heff_arraySetOwned(v_a_241, heff_box_word(v_i_240), heff_get_n(v_m_242, 0, 2));
    int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
    V t_1 = v_t_243;
    v_i_240 = t_0;
    v_a_241 = t_1;
    goto top;
  } else {
    return v_a_241;
  }
}
V g_heff_2eelab_2erules_2esumIntroNow_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumIntroNow_24map0(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2ewrittenAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ewrittenAt_entry, 2, 0};

V g_heff_2eelab_2erules_2ewrittenAt(V v_x1_240, V v_x_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2eelab_2erules_2ewrittenAt_24cpr(v_x1_240, v_x_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2eelab_2erules_2ewrittenAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2ewrittenAt(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eerrorOf_24tok2_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eerrorOf_24tok2_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_24tok2_lam0, 1, 0};
V g_heff_2eelab_2erules_2eerrorOf_24tok2_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2eerrorOf_24tok2_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_24tok2_lam1, 1, 0};
V g_heff_2eelab_2erules_2eerrorOf_24tok2_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2eerrorOf_24tok2_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_24tok2_lam2, 1, 0};
Clo g_heff_2eelab_2erules_2eerrorOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_24tok2_entry, 3, 0};

V g_heff_2eelab_2erules_2eerrorOf_24tok2(V v_tok_240, V v_hd_241, V v_k_242) {
top: ;
  heff_drop_cell(v_tok_240, 2);
  V v_t_245 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2eerrorOf_24tok2_lam0_clo)});
  V v_t_248 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2eerrorOf_24tok2_lam1_clo), ((V)&g_heff_2eelab_2erules_2eerrorOf_24tok2_lam2_clo)});
  return heff_tail(v_k_242, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_248})});
}
V g_heff_2eelab_2erules_2eerrorOf_24tok2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eerrorOf_24tok2(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eerrorOf_24tok2_lam0(V self, V *args) {
  V v_u_243 = args[0];
  heff_drop(v_u_243);
  V v_t_244 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_244});
}
V g_heff_2eelab_2erules_2eerrorOf_24tok2_lam1(V self, V *args) {
  V v_x_246 = args[0];
  heff_drop(v_x_246);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2eerrorOf_24tok2_lam2(V self, V *args) {
  V v_x_247 = args[0];
  heff_drop(v_x_247);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}