// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_MkFolded 17353
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_SApp 57081
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9006
#define TAG_SU 9427
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_applied 1586106042
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_conclusion 1382344475
#define LBL_defaults 1389419502
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_evidence 1128105991
#define LBL_globals 352931696
#define LBL_goal 9673690
#define LBL_hole 9703815
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_names 305943394
#define LBL_rest 9992347
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_subgoals 820279267
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_applied__conclusion__subgoals[] = {LBL_applied, LBL_conclusion, LBL_subgoals};
static uint32_t shape_el__span__dflt__rest[] = {LBL_el, LBL_span, LBL_dflt, LBL_rest};
static uint32_t shape_hole__goal[] = {LBL_hole, LBL_goal};
static uint32_t shape_name__ty__el__dflt__span[] = {LBL_name, LBL_ty, LBL_el, LBL_dflt, LBL_span};
static uint32_t shape_scope__globals__elabFor__lams__self__insts__named__evidence[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts, LBL_named, LBL_evidence};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_clo;
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
HeffT1 g_heff_2eelab_2erules_2eannot_24cpr(V, V);
V g_heff_2eelab_2erules_2eanyIdxGo(V, V, V);
V g_heff_2eelab_2erules_2eanyIdxGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyIdxGo_clo;
V g_heff_2eelab_2erules_2eanyP(V, V);
V g_heff_2eelab_2erules_2eanyP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyP_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eappendP_24tok2(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24tok2_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2eapplyGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eapplyGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyGo_clo;
V g_heff_2eelab_2erules_2ecatMaybesR(V);
V g_heff_2eelab_2erules_2ecatMaybesR_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_clo;
V g_heff_2eelab_2erules_2ecatMaybesR_24dps(V, V);
V g_heff_2eelab_2erules_2ecatMaybesR_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_24dps_clo;
V g_heff_2eelab_2erules_2echeckFixed(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckFixed_clo;
V g_heff_2eelab_2erules_2echeckingCandidates(V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckingCandidates_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckingCandidates_clo;
V g_heff_2eelab_2erules_2edefaulted(V, V, V, V, V);
V g_heff_2eelab_2erules_2edefaulted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaulted_clo;
V g_heff_2eelab_2erules_2eelimPlain(V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimPlain_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimPlain_clo;
V g_heff_2eelab_2erules_2eerrorOf(V, V);
V g_heff_2eelab_2erules_2eerrorOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eerrorOf_clo;
V g_heff_2eelab_2erules_2eerrorOf_24rec0_get(void);
V g_heff_2eelab_2erules_2eerrorOf_24tok2(V, V, V);
V g_heff_2eelab_2erules_2eerrorOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eerrorOf_24tok2_clo;
V g_heff_2eelab_2erules_2eescapeAt_24s1361751160x784580002(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eescapeAt_24s1361751160x784580002_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eescapeAt_24s1361751160x784580002_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2eimplicitArg(V, V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitArg_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einstantiateGo(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einstantiateGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstantiateGo_clo;
V g_heff_2eelab_2erules_2eintroGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintroGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintroGo_clo;
V g_heff_2eelab_2erules_2eleftOver(V, V, V, V, V);
V g_heff_2eelab_2erules_2eleftOver_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eleftOver_clo;
V g_heff_2eelab_2erules_2ementionsTypeF(V, V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_clo;
V g_heff_2eelab_2erules_2enameAtGo(V, V);
V g_heff_2eelab_2erules_2enameAtGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enameAtGo_clo;
V g_heff_2eelab_2erules_2enotGiven(V, V, V);
V g_heff_2eelab_2erules_2enotGiven_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotGiven_clo;
V g_heff_2eelab_2erules_2eplacesGo_24dps(V, V, V);
V g_heff_2eelab_2erules_2eplacesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesGo_24dps_clo;
V g_heff_2eelab_2erules_2eresourceEscapes(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresourceEscapes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresourceEscapes_clo;
HeffT2 g_heff_2eelab_2erules_2esealedOf_24cpr(V, V);
V g_heff_2eelab_2erules_2eselfAdvance(V, V, V, V, V);
V g_heff_2eelab_2erules_2eselfAdvance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eselfAdvance_clo;
V g_heff_2eelab_2erules_2esumIntroNow_24map0(V, V);
V g_heff_2eelab_2erules_2esumIntroNow_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntroNow_24map0_clo;
V g_heff_2eelab_2erules_2etagHidden(V, V, V, V, V);
V g_heff_2eelab_2erules_2etagHidden_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagHidden_clo;
V g_heff_2eelab_2erules_2etagsExposed(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2etagsExposed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagsExposed_clo;
V g_heff_2eelab_2erules_2etriedCandidate(V, V, V, V, V);
V g_heff_2eelab_2erules_2etriedCandidate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etriedCandidate_clo;
V g_heff_2eelab_2erules_2ewritten(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ewritten_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewritten_clo;
V g_heff_2eelab_2erules_2ewrittenAt(V, V);
V g_heff_2eelab_2erules_2ewrittenAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewrittenAt_clo;
HeffT2 g_heff_2eelab_2erules_2ewrittenAt_24cpr(V, V);
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784(V, V);
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eebind(V, V);
V g_heff_2eelab_2evalue_2eebind_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_clo;
V g_heff_2eelab_2evalue_2eebind_24tok1(V, V, V);
V g_heff_2eelab_2evalue_2eebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_24tok1_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTypeF_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTypeF_entry, 3, 0};

V g_heff_2eelab_2erules_2ementionsTypeF(V v_r_240, V v_d_241, V v_t_242) {
top: ;
  V v_el_243 = heff_take_field(v_r_240, 0);
  V v_ty_244 = heff_get_n(v_r_240, 1, 3);
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop(v_d_241);
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return NTAG(TAG_False);
  }
  case TAG_SDecode: {
    V v_e_246 = heff_field(v_t_242, 0);
    heff_drop(v_ty_244);
    return heff_tail(v_el_243, 2, (V[]){v_d_241, heff_dup(v_e_246)});
  }
  case TAG_SFunction: {
    V v_dom_248 = heff_field(v_t_242, 1);
    V v_t3_249 = heff_field(v_t_242, 2);
    heff_drop(v_el_243);
    switch (heff_tag_of(v_t3_249)) {
    case TAG_MkAbs: {
      V v_b_2413 = heff_field(v_t3_249, 1);
      V v_t_2414 = heff_tr(heff_call(heff_dup(v_ty_244), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dom_248)}));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop(v_ty_244);
        heff_drop(v_t_2414);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2414);
        return heff_tail(v_ty_244, 2, (V[]){heff_intAdd(v_d_241, MK_INT(1LL)), heff_dup(v_b_2413)});
      }
    }
    case TAG_AbsConst: {
      V v_b_2415 = heff_field(v_t3_249, 0);
      V v_t_2416 = heff_tr(heff_call(heff_dup(v_ty_244), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dom_248)}));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop(v_ty_244);
        heff_drop(v_t_2416);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2416);
        return heff_tail(v_ty_244, 2, (V[]){v_d_241, heff_dup(v_b_2415)});
      }
    }
    default: return heff_nomatch(v_t3_249);
    }
  }
  case TAG_SRecord: {
    V v_ft_2418 = heff_field(v_t_242, 1);
    heff_drop(v_el_243);
    V v_t_2420 = heff_arrayToList(heff_dup(heff_rfield(v_ft_2418, 2)));
    return ({ V a_0 = MK_INT(0LL); V b_1 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_lam0, 2, 2, (V[]){v_ty_244, v_d_241}); V a_2 = v_t_2420; V r_ = (g_heff_2eelab_2erules_2eanyIdxGo(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_t_2420); r_; });
  }
  case TAG_SSum: {
    V v_vs_2423 = heff_field(v_t_242, 0);
    heff_drop(v_el_243);
    V v_keys_2424 = heff_dup(heff_rfield(v_vs_2423, 0));
    V v_values_2425 = heff_dup(heff_rfield(v_vs_2423, 2));
    V v_t_2426 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2424), heff_arrayToList(v_values_2425)));
    return ({ V b_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTypeF_lam1, 1, 2, (V[]){v_ty_244, v_d_241}); V a_1 = v_t_2426; V r_ = (g_heff_2eelab_2erules_2eanyP(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2426); r_; });
  }
  case TAG_SIsTy: {
    V v_a_2431 = heff_field(v_t_242, 0);
    heff_drop(v_el_243);
    return heff_tail(v_ty_244, 2, (V[]){v_d_241, heff_dup(v_a_2431)});
  }
  case TAG_SPrimInt: {
    heff_drop(v_d_241);
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return NTAG(TAG_False);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_d_241);
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return NTAG(TAG_False);
  }
  case TAG_SPrimString: {
    heff_drop(v_d_241);
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return NTAG(TAG_False);
  }
  case TAG_SPrimRune: {
    heff_drop(v_d_241);
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return NTAG(TAG_False);
  }
  case TAG_SPrimArray: {
    V v_a_2432 = heff_field(v_t_242, 0);
    heff_drop(v_el_243);
    return heff_tail(v_ty_244, 2, (V[]){v_d_241, heff_dup(v_a_2432)});
  }
  case TAG_SFixed: {
    heff_drop(v_d_241);
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2erules_2ementionsTypeF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2ementionsTypeF(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2ementionsTypeF_lam0(V self, V *args) {
  V v_i_2421 = args[0];
  V v_ty_2422 = args[1];
  V v_ty_244 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_ty_244;
  args[0] = heff_intAdd(v_d_241, v_i_2421);
  args[1] = v_ty_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ementionsTypeF_lam1(V self, V *args) {
  V v_x3_2427 = args[0];
  V v_ty_244 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  switch (heff_tag_of(v_x3_2427)) {
  case TAG_MkPair: {
    V v_args_2429 = heff_field(v_x3_2427, 1);
    heff_take_n(v_x3_2427, 2ULL, 2);
    heff_clo_take(self, 2);
    V v_t_2430 = heff_tr(heff_call(v_ty_244, 1, (V[]){v_d_241}));
    return ({ V a_0 = v_t_2430; V b_1 = heff_arrayToList(v_args_2429); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(v_t_2430); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_x3_2427);
  }
}
V g_heff_2eelab_2erules_2eerrorOf_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eerrorOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_lam0, 1, 0};
V g_heff_2eelab_2erules_2eerrorOf_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2eerrorOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_lam1, 1, 0};
Clo g_heff_2eelab_2erules_2eerrorOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_entry, 2, 0};

V g_heff_2eelab_2erules_2eerrorOf(V v_hd_240, V v_k_241) {
top: ;
  V v_t_244 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2eerrorOf_lam0_clo), ((V)&g_heff_2eelab_2erules_2eerrorOf_lam1_clo)});
  return heff_tail(v_k_241, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2eelab_2erules_2eerrorOf_24rec0_get()), v_t_244})});
}
V g_heff_2eelab_2erules_2eerrorOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eerrorOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2eerrorOf_lam0(V self, V *args) {
  V v_x_242 = args[0];
  heff_drop(v_x_242);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2eerrorOf_lam1(V self, V *args) {
  V v_x_243 = args[0];
  heff_drop(v_x_243);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
Clo g_heff_2eelab_2erules_2ecatMaybesR_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecatMaybesR_entry, 1, 0};

V g_heff_2eelab_2erules_2ecatMaybesR(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2erules_2ecatMaybesR_24dps(v_xs_242, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2ecatMaybesR_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecatMaybesR(a[0]);
}
HEFF_LIT(g_heff_2eelab_2erules_2einstantiateGo_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einstantiateGo_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einstantiateGo_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einstantiateGo_str3, 1, "_");
V g_heff_2eelab_2erules_2einstantiateGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2einstantiateGo_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2einstantiateGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstantiateGo_entry, 7, 0};

V g_heff_2eelab_2erules_2einstantiateGo(V v_e_240, V v_sp_241, V v_m_242, V v_ty_243, V v_subgoals_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_ty_243)) {
  case TAG_VFunction: {
    V v_it4_2410 = heff_dup(heff_field(v_ty_243, 3));
    switch (heff_tag_of(v_it4_2410)) {
    case TAG_Expl: {
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_sp_241);
      heff_drop(v_z_245);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
      V v_x_2414 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_2413});
      return heff_tail(v_z_246, 1, (V[]){v_x_2414});
    }
    case TAG_Impl: {
      switch (heff_tag_of(v_ty_243)) {
      case TAG_VFunction: {
        V v_dom_2416 = heff_dup(heff_field(v_ty_243, 1));
        V v_cod_2417 = heff_dup(heff_field(v_ty_243, 2));
        V v_t_2425;
        switch (heff_tag_of(v_cod_2417)) {
        case TAG_MkClo: {
          V v_n_2421 = heff_dup(heff_field(v_cod_2417, 0));
          v_t_2425 = v_n_2421;
          break;
        }
        case TAG_CloConst: {
          v_t_2425 = ((V)&g_heff_2eelab_2erules_2einstantiateGo_str0);
          break;
        }
        default: heff_nomatch(v_cod_2417);
        }
        V v_c_2426 = (g_heff_2eelab_2erules_2eimplicitArg(heff_dup(v_e_240), heff_dup(v_sp_241), v_ty_243, v_dom_2416, v_t_2425));
        return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam0, 1, 7, (V[]){v_cod_2417, v_m_242, v_e_240, v_sp_241, v_subgoals_244, v_z_245, v_z_246})});
      }
      default: return heff_nomatch(v_ty_243);
      }
    }
    case TAG_Inst: {
      switch (heff_tag_of(v_ty_243)) {
      case TAG_VFunction: {
        V v_dom_2449 = heff_field(v_ty_243, 1);
        V v_cod_2450 = heff_field(v_ty_243, 2);
        heff_take_n(v_ty_243, 6ULL, 6);
        V v_t_2458;
        switch (heff_tag_of(v_cod_2450)) {
        case TAG_MkClo: {
          V v_n_2454 = heff_dup(heff_field(v_cod_2450, 0));
          v_t_2458 = v_n_2454;
          break;
        }
        case TAG_CloConst: {
          v_t_2458 = ((V)&g_heff_2eelab_2erules_2einstantiateGo_str2);
          break;
        }
        default: heff_nomatch(v_cod_2450);
        }
        V v_t_2459 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
        V v_t_2460 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 5);
        return ({ V a_0 = v_t_2459; V a_1 = v_t_2460; V a_2 = heff_dup(v_dom_2449); V a_3 = v_t_2458; V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_z_245); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam2, 1, 8, (V[]){v_cod_2450, v_m_242, v_dom_2449, v_subgoals_244, v_e_240, v_sp_241, v_z_245, v_z_246}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2460); r_; });
      }
      default: return heff_nomatch(v_ty_243);
      }
    }
    default: return heff_nomatch(v_it4_2410);
    }
  }
  default: {
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_sp_241);
    heff_drop(v_z_245);
    V v_t_2490 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_subgoals_244));
    V v_x_2491 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_m_242, v_ty_243, v_t_2490});
    return heff_tail(v_z_246, 1, (V[]){v_x_2491});
  }
  }
}
V g_heff_2eelab_2erules_2einstantiateGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einstantiateGo(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam1(V self, V *args) {
  V v_u_2437 = args[0];
  V v_x_2427 = heff_env(self)[0];
  heff_drop(v_u_2437);
  heff_clo_take(self, 1);
  V v_x1_2438 = heff_tr(heff_call(heff_get_n(v_x_2427, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2438)) {
  case TAG_Nom: {
    V v_x_2439 = heff_field(v_x1_2438, 0);
    heff_take_n(v_x1_2438, 1ULL, 1);
    return v_x_2439;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2438, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2441 = heff_field(v_x1_2438, 0);
    heff_take_n(v_x1_2438, 1ULL, 1);
    return v_x_2441;
  }
  default: return heff_nomatch(v_x1_2438);
  }
}
V g_heff_2eelab_2erules_2einstantiateGo_lam0(V self, V *args) {
  V v_x_2427 = args[0];
  V v_cod_2417 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_subgoals_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_t_2432;
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_n_2428 = heff_dup(heff_field(v_cod_2417, 0));
    v_t_2432 = v_n_2428;
    break;
  }
  case TAG_CloConst: {
    v_t_2432 = ((V)&g_heff_2eelab_2erules_2einstantiateGo_str1);
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2433 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2432, v_m_242, heff_dup(v_x_2427)));
  V v_x1_2443;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2435 = heff_field(v_cod_2417, 1);
    V v_body_2436 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2443 = heff_tr(heff_call(v_body_2436, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2435, heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam1, 1, 1, (V[]){v_x_2427})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2442 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2427, 2);
    v_x1_2443 = v_body_2442;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2447;
  switch (heff_tag_of(v_x1_2443)) {
  case TAG_Nom: {
    V v_x_2444 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    v_t_2447 = v_x_2444;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2443, 0ULL, 1);
    v_t_2447 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2446 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    v_t_2447 = v_x_2446;
    break;
  }
  default: heff_nomatch(v_x1_2443);
  }
  return (g_heff_2eelab_2erules_2einstantiateGo(v_e_240, v_sp_241, v_t_2433, v_t_2447, v_subgoals_244, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2einstantiateGo_lam3(V self, V *args) {
  V v_u_2470 = args[0];
  V v_x_2461 = heff_env(self)[0];
  heff_drop(v_u_2470);
  heff_clo_take(self, 1);
  return heff_get_n(v_x_2461, 1, 2);
}
V g_heff_2eelab_2erules_2einstantiateGo_lam4(V self, V *args) {
  V v_u_2480 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_x_2461 = heff_env(self)[1];
  heff_drop(v_u_2480);
  heff_clo_take(self, 2);
  V v_x2_2481 = heff_tr(heff_call(heff_get_n(v_m_242, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_2481)) {
  case TAG_Nom: {
    V v_x_2482 = heff_field(v_x2_2481, 0);
    heff_take_n(v_x2_2481, 1ULL, 1);
    return ({ V a_0 = v_x_2461; V a_1 = v_x_2482; V r_ = (g_heff_2eelab_2evalue_2eapp_24s435923339x187529784(a_0, a_1)); heff_drop_rec(v_x_2461, 2); r_; });
  }
  case TAG_Describe: {
    V v_x_2483 = heff_field(v_x2_2481, 0);
    heff_take_n(v_x2_2481, 1ULL, 1);
    return ({ V a_0 = v_x_2461; V a_1 = v_x_2483; V r_ = (g_heff_2eelab_2evalue_2eapp_24s435923339x187529784(a_0, a_1)); heff_drop_rec(v_x_2461, 2); r_; });
  }
  case TAG_Become: {
    V v_x_2484 = heff_field(v_x2_2481, 0);
    V v_ru_24x2_2481_24Become = heff_take_reuse_n(v_x2_2481, 1ULL, 1);
    V v_x1_2485 = ({ V a_0 = v_x_2461; V a_1 = v_x_2484; V r_ = heff_tr(g_heff_2eelab_2evalue_2eapp_24s435923339x187529784(a_0, a_1)); heff_drop_rec(v_x_2461, 2); r_; });
    V v_t_2489;
    switch (heff_tag_of(v_x1_2485)) {
    case TAG_Nom: {
      V v_x_2486 = heff_field(v_x1_2485, 0);
      heff_take_n(v_x1_2485, 1ULL, 1);
      v_t_2489 = v_x_2486;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2485, 0ULL, 1);
      v_t_2489 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2488 = heff_field(v_x1_2485, 0);
      heff_take_n(v_x1_2485, 1ULL, 1);
      v_t_2489 = v_x_2488;
      break;
    }
    default: heff_nomatch(v_x1_2485);
    }
    return heff_tag_at_n(v_ru_24x2_2481_24Become, TAG_Become, 1, (V[]){v_t_2489});
  }
  default: return heff_nomatch(v_x2_2481);
  }
}
V g_heff_2eelab_2erules_2einstantiateGo_lam2(V self, V *args) {
  V v_x_2461 = args[0];
  V v_cod_2450 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_dom_2449 = heff_env(self)[2];
  V v_subgoals_244 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  V v_t_2466;
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_cod_2450)) {
  case TAG_MkClo: {
    V v_n_2462 = heff_dup(heff_field(v_cod_2450, 0));
    v_t_2466 = v_n_2462;
    break;
  }
  case TAG_CloConst: {
    v_t_2466 = ((V)&g_heff_2eelab_2erules_2einstantiateGo_str3);
    break;
  }
  default: heff_nomatch(v_cod_2450);
  }
  V v_x1_2472;
  switch (heff_tag_of(v_cod_2450)) {
  case TAG_MkClo: {
    V v_vs_2468 = heff_field(v_cod_2450, 1);
    V v_body_2469 = heff_field(v_cod_2450, 2);
    heff_take_n(v_cod_2450, 6ULL, 3);
    v_x1_2472 = heff_tr(heff_call(v_body_2469, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2468, heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam3, 1, 1, (V[]){heff_dup(v_x_2461)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2471 = heff_field(v_cod_2450, 0);
    heff_take_n(v_cod_2450, 1ULL, 1);
    v_x1_2472 = v_body_2471;
    break;
  }
  default: heff_nomatch(v_cod_2450);
  }
  V v_t_2476;
  switch (heff_tag_of(v_x1_2472)) {
  case TAG_Nom: {
    V v_x_2473 = heff_field(v_x1_2472, 0);
    heff_take_n(v_x1_2472, 1ULL, 1);
    v_t_2476 = v_x_2473;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2472, 0ULL, 1);
    v_t_2476 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2475 = heff_field(v_x1_2472, 0);
    heff_take_n(v_x1_2472, 1ULL, 1);
    v_t_2476 = v_x_2475;
    break;
  }
  default: heff_nomatch(v_x1_2472);
  }
  V v_t_2477 = heff_tag_n(TAG_SImplicit, 2, (V[]){v_t_2466, heff_dup(heff_rfield(v_x_2461, 0))});
  V v_t_2478 = heff_tag_n(TAG_SApp, 2, (V[]){heff_dup(heff_rfield(v_m_242, 0)), v_t_2477});
  V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_hole__goal, (V[]){heff_dup(v_x_2461), v_dom_2449}), v_subgoals_244});
  return (g_heff_2eelab_2erules_2einstantiateGo(v_e_240, v_sp_241, ({ V rv_0 = v_t_2478; V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2einstantiateGo_lam4, 1, 2, (V[]){heff_dup(v_m_242), v_x_2461}); V rr_ = heff_rec_reuse_nf(v_m_242, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; }), v_t_2476, v_t_2479, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2echeckingCandidates_lam1(V self, V *args);
V g_heff_2eelab_2erules_2echeckingCandidates_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2echeckingCandidates_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckingCandidates_entry, 5, 0};

V g_heff_2eelab_2erules_2echeckingCandidates(V v_e_240, V v_goal_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_goal_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_c_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_c_245)) {
    case TAG_MkPair: {
      V v_y_248 = heff_dup(heff_field(v_c_245, 1));
      v_t_249 = v_y_248;
      break;
    }
    default: heff_nomatch(v_c_245);
    }
    return ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_goal_241); V a_2 = v_t_249; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2eelab_2erules_2echeckingCandidates_lam0, 1, 6, (V[]){v_e_240, v_goal_241, v_rest_246, v_p_243, v_c_245, v_p_244}); V r_ = (g_heff_2eelab_2erules_2etriedCandidate(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_249); r_; });
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2echeckingCandidates_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2echeckingCandidates(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2echeckingCandidates_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_t_2412;
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_2410);
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_245, v_x_2411});
  } else {
    heff_drop(v_x_2410);
    heff_drop(v_c_245);
    v_t_2412 = v_x_2411;
  }
  V f_ = v_p_244;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2echeckingCandidates_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_goal_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_c_245 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2erules_2echeckingCandidates(v_e_240, v_goal_241, v_rest_246, v_p_243, heff_clo_n(g_heff_2eelab_2erules_2echeckingCandidates_lam1, 1, 3, (V[]){v_x_2410, v_c_245, v_p_244})));
}
V g_heff_2eelab_2erules_2eelimPlain_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eelimPlain_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eelimPlain_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eelimPlain_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eelimPlain_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eelimPlain_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eelimPlain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimPlain_entry, 5, 0};

V g_heff_2eelab_2erules_2eelimPlain(V v_e_240, V v_ecallee_241, V v_dom_242, V v_cod_243, V v_arg_244) {
top: ;
  V v_stx_245 = heff_take_field(v_ecallee_241, 0);
  V v_val_246 = heff_get_n(v_ecallee_241, 1, 2);
  V v_c_248;
  switch (heff_tag_of(v_arg_244)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_arg_244, 0);
    v_c_248 = heff_tr(heff_call(heff_dup(v_f_247), 2, (V[]){v_e_240, v_dom_242}));
    break;
  }
  default: heff_nomatch(v_arg_244);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam0, 2, 4, (V[]){v_c_248, heff_dup(v_cod_243), v_stx_245, v_val_246});
}
V g_heff_2eelab_2erules_2eelimPlain_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2eelab_2erules_2eelimPlain(a[0], a[1], a[2], a3, a4); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2eelab_2erules_2eelimPlain_lam2(V self, V *args) {
  V v_u_2417 = args[0];
  V v_val_2412 = heff_env(self)[0];
  heff_drop(v_u_2417);
  heff_clo_take(self, 1);
  V v_x1_2418 = heff_tr(heff_call(v_val_2412, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nom: {
    V v_x_2419 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    return v_x_2419;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2418, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2421 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    return v_x_2421;
  }
  default: return heff_nomatch(v_x1_2418);
  }
}
V g_heff_2eelab_2erules_2eelimPlain_lam5(V self, V *args) {
  V v_u2_2431 = args[0];
  V v_val_2412 = heff_env(self)[0];
  heff_drop(v_u2_2431);
  heff_clo_take(self, 1);
  V v_x1_2432 = heff_tr(heff_call(v_val_2412, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_Nom: {
    V v_x_2433 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    return v_x_2433;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2432, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2435 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    return v_x_2435;
  }
  default: return heff_nomatch(v_x1_2432);
  }
}
V g_heff_2eelab_2erules_2eelimPlain_lam4(V self, V *args) {
  V v_f_2430 = args[0];
  V v_val_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_f_2430; V b_1 = heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam5, 1, 1, (V[]){v_val_2412}); V r_ = (g_heff_2eelab_2evalue_2eapp(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2eelab_2erules_2eelimPlain_lam3(V self, V *args) {
  V v_u_2428 = args[0];
  V v_val_246 = heff_env(self)[0];
  V v_val_2412 = heff_env(self)[1];
  heff_drop(v_u_2428);
  heff_clo_take(self, 2);
  V v_t_2429 = heff_tr(heff_call(v_val_246, 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2evalue_2eebind(heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam4, 1, 1, (V[]){v_val_2412}), v_t_2429));
}
V g_heff_2eelab_2erules_2eelimPlain_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_cod_243 = heff_env(self)[0];
  V v_stx_245 = heff_env(self)[1];
  V v_val_246 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_val_2412 = heff_take_field(v_x_2411, 1);
  V v_stx_2413 = heff_take_field(v_x_2411, 0);
  V v_x1_2423;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_cod_243)) {
  case TAG_MkClo: {
    V v_vs_2415 = heff_field(v_cod_243, 1);
    V v_body_2416 = heff_field(v_cod_243, 2);
    heff_take_n(v_cod_243, 6ULL, 3);
    v_x1_2423 = heff_tr(heff_call(v_body_2416, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2415, heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam2, 1, 1, (V[]){heff_dup(v_val_2412)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2422 = heff_field(v_cod_243, 0);
    heff_take_n(v_cod_243, 1ULL, 1);
    v_x1_2423 = v_body_2422;
    break;
  }
  default: heff_nomatch(v_cod_243);
  }
  V v_t_2427;
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_Nom: {
    V v_x_2424 = heff_field(v_x1_2423, 0);
    heff_take_n(v_x1_2423, 1ULL, 1);
    v_t_2427 = v_x_2424;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2423, 0ULL, 1);
    v_t_2427 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2426 = heff_field(v_x1_2423, 0);
    heff_take_n(v_x1_2423, 1ULL, 1);
    v_t_2427 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_x1_2423);
  }
  V v_t_2436 = ({ V rv_0 = heff_tag_n(TAG_SApp, 2, (V[]){v_stx_245, v_stx_2413}); V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam3, 1, 2, (V[]){v_val_246, v_val_2412}); V rr_ = heff_rec_reuse_nf(v_x_2411, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_x_2437 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2436, v_t_2427});
  V f_ = v_k_2410;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eelimPlain_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_cod_243 = heff_env(self)[1];
  V v_stx_245 = heff_env(self)[2];
  V v_val_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_248;
  args[0] = v_hd_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimPlain_lam1, 1, 4, (V[]){v_cod_243, v_stx_245, v_val_246, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2eescapeAt_24s1361751160x784580002_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eescapeAt_24s1361751160x784580002_entry, 9, 0};

V g_heff_2eelab_2erules_2eescapeAt_24s1361751160x784580002(V v_lit_240, V v_e_241, V v_sp_242, V v_a_243, V v_a_27_244, V v_err_245, V v_l_246, V v_z_247, V v_z_248) {
top: ;
  switch (heff_tag_of(v_lit_240)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_lit_240, 0);
    V v_t_2410 = heff_field(v_lit_240, 1);
    V v_sc_2411 = heff_dup(heff_rfield(v_e_241, 0));
    V v_names_2412 = heff_take_field(v_sc_2411, 1);
    V v_len_2413 = heff_get_n(v_sc_2411, 0, 5);
    V v_t_2414 = heff_intSub(heff_intSub(v_len_2413, MK_INT(1LL)), v_l_246);
    V v_t_2415 = ({ V a_0 = v_names_2412; V a_1 = v_t_2414; V r_ = (g_heff_2eelab_2erules_2enameAtGo(a_0, a_1)); heff_drop(v_names_2412); r_; });
    return (g_heff_2eelab_2erules_2eresourceEscapes(v_e_241, v_sp_242, v_t_2415, heff_dup(v_x_249), heff_dup(v_t_2410), v_z_247, v_z_248));
  }
  default: return heff_nomatch(v_lit_240);
  }
}
V g_heff_2eelab_2erules_2eescapeAt_24s1361751160x784580002_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2eelab_2erules_2eescapeAt_24s1361751160x784580002(a0, a[1], a[2], a3, a4, a5, a[6], a[7], a[8]); heff_drop(a0); heff_drop(a3); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eapply_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eapply_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eapply_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eapply_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eapply_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eapply_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V v_sp_240, V v_syn_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam0, 2, 2, (V[]){heff_dup(v_syn_241), v_sp_240})}});
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam3(V self, V *args) {
  V v_c_2411 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2411, 3, 9); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_m0_249 = heff_env(self)[0];
  V v_a1_2410 = heff_env(self)[1];
  heff_drop(v_hd_2429);
  heff_clo_take(self, 2);
  V f_ = v_k_2430;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m0_249, v_a1_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2eapplyGo(v_sp_240, v_e_242, v_x_2415, v_x_2432, v_hd_246, v_k_247));
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_m0_249 = heff_env(self)[0];
  V v_a1_2410 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_t_2416 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2415)));
  V v_t_2428;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFunction: {
    V v_implicit_2421 = heff_field(v_t_2416, 3);
    heff_take_n(v_t_2416, 8ULL, 4);
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_Impl: {
      v_t_2428 = NTAG(TAG_True);
      break;
    }
    case TAG_Inst: {
      v_t_2428 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2416, 0ULL, 3);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeInt: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFloat: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeString: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeRune: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_NoRules: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_c_2431;
  heff_clo_take(self, 6);
  if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
    heff_drop(v_t_2428);
    v_c_2431 = heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam5, 2, 2, (V[]){v_m0_249, v_a1_2410});
  } else {
    heff_drop(v_t_2428);
    v_c_2431 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2einsertImplicits_clo), 4, (V[]){heff_dup(v_e_242), heff_dup(v_sp_240), v_m0_249, v_a1_2410}));
  }
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam6, 1, 5, (V[]){v_sp_240, v_e_242, v_x_2415, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_a0_243 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_m0_249 = heff_field(v_x_248, 0);
    V v_a1_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    heff_clo_take(self, 5);
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam3, 1, 1, (V[]){v_a0_243})})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2413}));
    V f_ = heff_dup(heff_rfield(v_hd_246, 1));
    heff_room[0] = v_t_2414;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam4, 1, 6, (V[]){v_m0_249, v_a1_2410, v_e_242, v_sp_240, v_hd_246, v_k_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_a0_243 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam2, 1, 5, (V[]){v_a0_243, v_hd_246, v_e_242, v_sp_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eapply_24cpr_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_syn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_c_245;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_syn_241)) {
  case TAG_MkSyn: {
    V v_f_244 = heff_field(v_syn_241, 0);
    heff_take_n(v_syn_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_e_242)}));
    break;
  }
  default: heff_nomatch(v_syn_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eapply_24cpr_lam1, 2, 4, (V[]){v_c_245, v_a0_243, v_e_242, v_sp_240});
}
V g_heff_2eelab_2erules_2eannot_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eannot_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eannot_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eannot_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2eannot_24cpr(V v_typ_240, V v_chk_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2eannot_24cpr_lam0, 1, 2, (V[]){heff_dup(v_typ_240), heff_dup(v_chk_241)})}});
}
V g_heff_2eelab_2erules_2eannot_24cpr_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2417 = heff_tr(heff_call(heff_get_n(v_x_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2421;
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nom: {
    V v_x_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2418;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2421 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2420 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x1_2417);
  }
  V v_x_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2416, v_t_2421});
  V f_ = v_k_247;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eannot_24cpr_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_chk_241 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_x1_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_248, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_a_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_a_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_a_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_c_2415;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_chk_241)) {
  case TAG_MkChk: {
    V v_f_2414 = heff_field(v_chk_241, 0);
    heff_take_n(v_chk_241, 1ULL, 1);
    v_c_2415 = heff_tr(heff_call(v_f_2414, 2, (V[]){v_e_242, v_a_2413}));
    break;
  }
  default: heff_nomatch(v_chk_241);
  }
  V f_ = v_c_2415;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eannot_24cpr_lam3, 1, 2, (V[]){v_x_248, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eannot_24cpr_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eannot_24cpr_lam2, 1, 4, (V[]){v_chk_241, v_e_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eannot_24cpr_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_typ_240 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  V v_c_245;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_typ_240)) {
  case TAG_MkTyp: {
    V v_f_243 = heff_field(v_typ_240, 0);
    heff_take_n(v_typ_240, 1ULL, 1);
    V v_t_244 = heff_rec_n(8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, (V[]){heff_dup(heff_rfield(v_e_242, 0)), heff_dup(heff_rfield(v_e_242, 1)), NTAG(TAG_ForNominative), heff_dup(heff_rfield(v_e_242, 3)), heff_dup(heff_rfield(v_e_242, 4)), heff_dup(heff_rfield(v_e_242, 5)), heff_dup(heff_rfield(v_e_242, 6)), heff_dup(heff_rfield(v_e_242, 7))});
    v_c_245 = heff_tr(heff_call(v_f_243, 1, (V[]){v_t_244}));
    break;
  }
  default: heff_nomatch(v_typ_240);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eannot_24cpr_lam1, 2, 3, (V[]){v_c_245, v_chk_241, v_e_242});
}
V g_heff_2eelab_2erules_2edefaulted_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edefaulted_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edefaulted_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaulted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaulted_entry, 5, 0};

V g_heff_2eelab_2erules_2edefaulted(V v_e_240, V v_it_241, V v_x_242, V v_vs_243, V v_settings_244) {
top: ;
  V v_elabFor_245 = heff_take_field(v_e_240, 2);
  V v_globals_246 = heff_get_n(v_e_240, 1, 8);
  V v_d_247 = heff_dup(heff_rfield(v_it_241, 3));
  V v_byName_248 = heff_take_field(v_d_247, 1);
  V v_values_249 = heff_get_n(v_d_247, 2, 3);
  HeffT2 v_t_2410 = ({ V a_0 = v_byName_248; V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_248); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_i_2413 = v_field_2412;
      V v_xs_2414 = v_values_249;
      if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2413, 1) && heff_intLt_c_lent(v_i_2413, heff_arrayLength_lent(v_xs_2414, 0), 2))) {
        heff_drop(v_x_242);
        V v_d_2415 = heff_arrayIndex(v_xs_2414, v_i_2413);
        return heff_clo_n(g_heff_2eelab_2erules_2edefaulted_lam0, 2, 6, (V[]){v_elabFor_245, v_d_2415, v_globals_246, v_vs_243, v_it_241, v_settings_244});
      } else {
        heff_drop(v_vs_243);
        heff_drop(v_elabFor_245);
        heff_drop(v_globals_246);
        heff_drop(v_i_2413);
        heff_drop(v_xs_2414);
        return ({ V a_0 = v_it_241; V a_1 = v_x_242; V a_2 = v_settings_244; V r_ = (g_heff_2eelab_2erules_2enotGiven(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
      }
    } else {
      heff_drop(v_vs_243);
      heff_drop(v_elabFor_245);
      heff_drop(v_globals_246);
      heff_drop(v_values_249);
      heff_drop(v_field_2412);
      return ({ V a_0 = v_it_241; V a_1 = v_x_242; V a_2 = v_settings_244; V r_ = (g_heff_2eelab_2erules_2enotGiven(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
    }
  }
}
V g_heff_2eelab_2erules_2edefaulted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edefaulted(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2edefaulted_lam1(V self, V *args) {
  V v_u_2419 = args[0];
  V v_globals_246 = heff_env(self)[0];
  V v_d_2415 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_drop(v_u_2419);
  heff_clo_take(self, 3);
  return ({ V a_0 = v_globals_246; V a_1 = NTAG(TAG_N); V a_2 = v_d_2415; V a_3 = v_vs_243; V r_ = (g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(a_0, a_1, a_2, a_3)); heff_drop(v_globals_246); r_; });
}
V g_heff_2eelab_2erules_2edefaulted_lam2(V self, V *args) {
  V v_u_2422 = args[0];
  V v_globals_246 = heff_env(self)[0];
  V v_d_2415 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_drop(v_u_2422);
  heff_clo_take(self, 3);
  V v_x1_2423 = ({ V a_0 = v_globals_246; V a_1 = NTAG(TAG_N); V a_2 = v_d_2415; V a_3 = v_vs_243; V r_ = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(a_0, a_1, a_2, a_3)); heff_drop(v_globals_246); r_; });
  V v_t_2427;
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_Nom: {
    V v_x_2424 = heff_field(v_x1_2423, 0);
    heff_take_n(v_x1_2423, 1ULL, 1);
    v_t_2427 = v_x_2424;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2423, 0ULL, 1);
    v_t_2427 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2426 = heff_field(v_x1_2423, 0);
    heff_take_n(v_x1_2423, 1ULL, 1);
    v_t_2427 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_x1_2423);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2427});
}
V g_heff_2eelab_2erules_2edefaulted_lam0(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_elabFor_245 = heff_env(self)[0];
  V v_d_2415 = heff_env(self)[1];
  V v_globals_246 = heff_env(self)[2];
  V v_vs_243 = heff_env(self)[3];
  V v_it_241 = heff_env(self)[4];
  V v_settings_244 = heff_env(self)[5];
  heff_drop(v_hd_2416);
  heff_clo_take(self, 6);
  V v_t_2418 = v_elabFor_245;
  V v_t_2428;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_ForNominative: {
    v_t_2428 = heff_rec_n(2, shape_stx__val, (V[]){heff_dup(v_d_2415), heff_clo_n(g_heff_2eelab_2erules_2edefaulted_lam1, 1, 3, (V[]){v_globals_246, v_d_2415, v_vs_243})});
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2418, 0ULL, 2);
    v_t_2428 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(v_d_2415)}), heff_clo_n(g_heff_2eelab_2erules_2edefaulted_lam2, 1, 3, (V[]){v_globals_246, v_d_2415, v_vs_243})});
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_t_2429 = heff_rec_n(4, shape_el__span__dflt__rest, (V[]){v_t_2428, heff_get_n(v_it_241, 0, 5), NTAG(TAG_True), v_settings_244});
  V f_ = v_k_2417;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eintroGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eintroGo_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eintroGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintroGo_entry, 8, 0};

V g_heff_2eelab_2erules_2eintroGo(V v_e_240, V v_it_241, V v_done_242, V v_vs_243, V v_settings_244, V v_x6_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_done_242);
    heff_drop(v_vs_243);
    return ({ V a_0 = v_e_240; V a_1 = v_it_241; V a_2 = v_settings_244; V a_3 = v_z_246; V a_4 = v_z_247; V r_ = (g_heff_2eelab_2erules_2eleftOver(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_settings_244); r_; });
  }
  case TAG_Cons: {
    V v_x61_248 = heff_field(v_x6_245, 0);
    V v_rest_249 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    switch (heff_tag_of(v_x61_248)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x61_248, 0);
      V v_fieldC_2411 = heff_field(v_x61_248, 1);
      heff_take_n(v_x61_248, 3ULL, 2);
      V v_t_2412 = heff_tr(heff_call(v_fieldC_2411, 1, (V[]){heff_dup(v_vs_243)}));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_MkField: {
        V v_fty_2413 = heff_field(v_t_2412, 0);
        V v_fvalue_2414 = heff_field(v_t_2412, 1);
        heff_take_n(v_t_2412, 3ULL, 2);
        V v_c_2417;
        switch (heff_tag_of(v_settings_244)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x6_245_24Cons, 2);
          v_c_2417 = (g_heff_2eelab_2erules_2edefaulted(heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_2410), heff_dup(v_vs_243), NTAG(TAG_Nil)));
          break;
        }
        case TAG_Cons: {
          V v_fs_2415 = heff_field(v_settings_244, 0);
          V v_rest_2416 = heff_field(v_settings_244, 1);
          heff_take_n(v_settings_244, 3ULL, 2);
          if (heff_strEq_c(heff_dup(heff_rfield(v_fs_2415, 0)), heff_dup(v_x_2410))) {
            heff_drop_cell(v_ru_24x6_245_24Cons, 2);
            v_c_2417 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ewritten_clo), 6, (V[]){heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_2410), heff_dup(v_fty_2413), v_fs_2415, v_rest_2416}));
          } else {
            v_c_2417 = (g_heff_2eelab_2erules_2edefaulted(heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_2410), heff_dup(v_vs_243), heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){v_fs_2415, v_rest_2416})));
          }
          break;
        }
        default: heff_nomatch(v_settings_244);
        }
        return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam0, 1, 10, (V[]){v_e_240, v_x_2410, v_fty_2413, v_fvalue_2414, v_z_246, v_done_242, v_it_241, v_vs_243, v_rest_249, v_z_247})});
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_x61_248);
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eelab_2erules_2eintroGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eintroGo(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2eintroGo_lam1(V self, V *args) {
  V v_u_2433 = args[0];
  V v_sp_2429 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  heff_drop(v_u_2433);
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_SpProj, 2, (V[]){v_sp_2429, v_x_2410});
}
V g_heff_2eelab_2erules_2eintroGo_lam2(V self, V *args) {
  V v_u_2435 = args[0];
  V v_fty_2413 = heff_env(self)[0];
  heff_drop(v_u_2435);
  heff_clo_take(self, 1);
  return v_fty_2413;
}
V g_heff_2eelab_2erules_2eintroGo_lam5(V self, V *args) {
  V v_u_24108 = args[0];
  V v_v_24101 = heff_env(self)[0];
  heff_drop(v_u_24108);
  heff_clo_take(self, 1);
  return v_v_24101;
}
V g_heff_2eelab_2erules_2eintroGo_lam6(V self, V *args) {
  V v_x_24109 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_fty_2413 = heff_env(self)[1];
  V v_el_2419 = heff_env(self)[2];
  V v_dflt_2422 = heff_env(self)[3];
  V v_span_2420 = heff_env(self)[4];
  V v_z_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24110 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(5, shape_name__ty__el__dflt__span, (V[]){v_x_2410, v_fty_2413, v_el_2419, v_dflt_2422, v_span_2420}), v_x_24109});
  V f_ = v_z_247;
  args[0] = v_t_24110;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eintroGo_lam4(V self, V *args) {
  V v_x_24105 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_v_24101 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_it_241 = heff_env(self)[3];
  V v_vs_243 = heff_env(self)[4];
  V v_rest_2421 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  V v_fty_2413 = heff_env(self)[8];
  V v_el_2419 = heff_env(self)[9];
  V v_dflt_2422 = heff_env(self)[10];
  V v_span_2420 = heff_env(self)[11];
  V v_z_247 = heff_env(self)[12];
  V v_t_24106 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2410), heff_dup(v_v_24101)}), NTAG(TAG_Nil)});
  heff_clo_take(self, 13);
  V v_t_24107 = (g_heff_2eelab_2erules_2eappendP(v_done_242, v_t_24106));
  return (g_heff_2eelab_2erules_2eintroGo(v_x_24105, v_it_241, v_t_24107, heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_243, heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam5, 1, 1, (V[]){v_v_24101})}), v_rest_2421, v_rest_249, v_z_246, heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam6, 1, 6, (V[]){v_x_2410, v_fty_2413, v_el_2419, v_dflt_2422, v_span_2420, v_z_247})));
}
V g_heff_2eelab_2erules_2eintroGo_lam3(V self, V *args) {
  V v_x_24102 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_v_24101 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_it_241 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_vs_243 = heff_env(self)[6];
  V v_rest_2421 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  V v_fty_2413 = heff_env(self)[9];
  V v_el_2419 = heff_env(self)[10];
  V v_dflt_2422 = heff_env(self)[11];
  V v_span_2420 = heff_env(self)[12];
  V v_z_247 = heff_env(self)[13];
  heff_drop(v_x_24102);
  V v_t_24103 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2410), heff_dup(v_v_24101)}), NTAG(TAG_Nil)});
  V v_t_24104 = (g_heff_2eelab_2erules_2eappendP(heff_dup(v_done_242), v_t_24103));
  heff_clo_take(self, 14);
  return (g_heff_2eelab_2erules_2eselfAdvance(v_e_240, heff_dup(heff_rfield(v_it_241, 1)), v_t_24104, heff_dup(v_z_246), heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam4, 1, 13, (V[]){v_x_2410, v_v_24101, v_done_242, v_it_241, v_vs_243, v_rest_2421, v_rest_249, v_z_246, v_fty_2413, v_el_2419, v_dflt_2422, v_span_2420, v_z_247})));
}
V g_heff_2eelab_2erules_2eintroGo_lam0(V self, V *args) {
  V v_x_2418 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_fty_2413 = heff_env(self)[2];
  V v_fvalue_2414 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_done_242 = heff_env(self)[5];
  V v_it_241 = heff_env(self)[6];
  V v_vs_243 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  V v_z_247 = heff_env(self)[9];
  V v_el_2419 = heff_take_field(v_x_2418, 0);
  V v_span_2420 = heff_take_field(v_x_2418, 1);
  V v_rest_2421 = heff_take_field(v_x_2418, 3);
  V v_dflt_2422 = heff_get_n(v_x_2418, 2, 4);
  V v_t_2423 = heff_dup(heff_rfield(v_e_240, 2));
  V v_v_24101;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_ForNominative: {
    V v_x2_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_el_2419, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nom: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      heff_take_n(v_x2_2424, 1ULL, 1);
      v_v_24101 = v_x_2425;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x2_2424, 0ULL, 1);
      v_v_24101 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2427 = heff_field(v_x2_2424, 0);
      heff_take_n(v_x2_2424, 1ULL, 1);
      v_v_24101 = v_x_2427;
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2428 = heff_field(v_t_2423, 0);
    V v_sp_2429 = heff_field(v_t_2423, 1);
    V v_ru_24t_2423_24ForDescriptive = heff_take_reuse_n(v_t_2423, 3ULL, 2);
    V v_x2_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_el_2419, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_lit_2431 = v_x2_2430;
    V v_h_2432 = v_h_2428;
    V v_spineTh_2434 = heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam1, 1, 2, (V[]){v_sp_2429, heff_dup(v_x_2410)});
    V v_ty_2436 = heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam2, 1, 1, (V[]){heff_dup(v_fty_2413)});
    switch (heff_tag_of(v_lit_2431)) {
    case TAG_Nom: {
      V v_v_2437 = heff_field(v_lit_2431, 0);
      V v_ru_24lit_2431_24Nom = heff_take_reuse_n(v_lit_2431, 1ULL, 1);
      heff_drop_clo(v_ty_2436, 1);
      switch (heff_tag_of(v_v_2437)) {
      case TAG_VNeu: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
        v_v_24101 = v_v_2437;
        break;
      }
      case TAG_VCode: {
        V v_v1_2443 = heff_dup(heff_field(v_v_2437, 0));
        switch (heff_tag_of(v_v1_2443)) {
        case TAG_VU: {
          heff_take_n(v_v1_2443, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VDecode: {
          heff_take_n(v_v1_2443, 0ULL, 5);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VFunction: {
          V v_level_2450 = heff_field(v_v1_2443, 0);
          V v_dom_2451 = heff_field(v_v1_2443, 1);
          V v_cod_2452 = heff_field(v_v1_2443, 2);
          V v_implicit_2453 = heff_field(v_v1_2443, 3);
          V v_dflt_2454 = heff_field(v_v1_2443, 4);
          V v_ru_24v1_2443_24VFunction = heff_take_reuse_n(v_v1_2443, 31ULL, 6);
          switch (heff_tag_of(v_v_2437)) {
          case TAG_VCode: {
            V v_ru_24v_2437_24VCode = heff_take_reuse_n(v_v_2437, 0ULL, 1);
            V v_t_2457 = heff_tag_at_n(v_ru_24lit_2431_24Nom, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24t_2423_24ForDescriptive, TAG_MkFolded, 2, (V[]){v_h_2432, v_spineTh_2434})});
            v_v_24101 = heff_tag_at_n(v_ru_24v_2437_24VCode, TAG_VCode, 1, (V[]){heff_tag_re_n(v_ru_24v1_2443_24VFunction, TAG_VFunction, 6, 31ULL, (V[]){v_level_2450, v_dom_2451, v_cod_2452, v_implicit_2453, v_dflt_2454, v_t_2457})});
            break;
          }
          default: heff_nomatch(v_v_2437);
          }
          break;
        }
        case TAG_VRecord: {
          heff_take_n(v_v1_2443, 0ULL, 4);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VSum: {
          heff_take_n(v_v1_2443, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VPrimInt: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VPrimFloat: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VPrimString: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VPrimRune: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VPrimArray: {
          heff_take_n(v_v1_2443, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        case TAG_VFixed: {
          heff_take_n(v_v1_2443, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
          v_v_24101 = v_v_2437;
          break;
        }
        default: heff_nomatch(v_v1_2443);
        }
        break;
      }
      case TAG_VLam: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
        v_v_24101 = v_v_2437;
        break;
      }
      case TAG_VCons: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
        v_v_24101 = v_v_2437;
        break;
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Nom, 1);
        v_v_24101 = v_v_2437;
        break;
      }
      default: heff_nomatch(v_v_2437);
      }
      break;
    }
    case TAG_Describe: {
      V v_desc_2468 = heff_field(v_lit_2431, 0);
      V v_ru_24lit_2431_24Describe = heff_take_reuse_n(v_lit_2431, 1ULL, 1);
      heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
      V v_t_2469 = heff_tr(heff_call(v_spineTh_2434, 1, (V[]){NTAG(TAG_MkUnit)}));
      v_v_24101 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_2432, v_t_2469, v_ty_2436, heff_tag_at_n(v_ru_24lit_2431_24Describe, TAG_Just, 1, (V[]){v_desc_2468})));
      break;
    }
    case TAG_Become: {
      V v_v_2470 = heff_field(v_lit_2431, 0);
      V v_ru_24lit_2431_24Become = heff_take_reuse_n(v_lit_2431, 1ULL, 1);
      heff_drop_clo(v_ty_2436, 1);
      switch (heff_tag_of(v_v_2470)) {
      case TAG_VNeu: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Become, 1);
        v_v_24101 = v_v_2470;
        break;
      }
      case TAG_VCode: {
        V v_v1_2476 = heff_dup(heff_field(v_v_2470, 0));
        switch (heff_tag_of(v_v1_2476)) {
        case TAG_VU: {
          heff_take_n(v_v1_2476, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VDecode: {
          heff_take_n(v_v1_2476, 0ULL, 5);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VFunction: {
          V v_level_2483 = heff_field(v_v1_2476, 0);
          V v_dom_2484 = heff_field(v_v1_2476, 1);
          V v_cod_2485 = heff_field(v_v1_2476, 2);
          V v_implicit_2486 = heff_field(v_v1_2476, 3);
          V v_dflt_2487 = heff_field(v_v1_2476, 4);
          V v_ru_24v1_2476_24VFunction = heff_take_reuse_n(v_v1_2476, 31ULL, 6);
          switch (heff_tag_of(v_v_2470)) {
          case TAG_VCode: {
            V v_ru_24v_2470_24VCode = heff_take_reuse_n(v_v_2470, 0ULL, 1);
            V v_t_2490 = heff_tag_at_n(v_ru_24lit_2431_24Become, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24t_2423_24ForDescriptive, TAG_MkFolded, 2, (V[]){v_h_2432, v_spineTh_2434})});
            v_v_24101 = heff_tag_at_n(v_ru_24v_2470_24VCode, TAG_VCode, 1, (V[]){heff_tag_re_n(v_ru_24v1_2476_24VFunction, TAG_VFunction, 6, 31ULL, (V[]){v_level_2483, v_dom_2484, v_cod_2485, v_implicit_2486, v_dflt_2487, v_t_2490})});
            break;
          }
          default: heff_nomatch(v_v_2470);
          }
          break;
        }
        case TAG_VRecord: {
          heff_take_n(v_v1_2476, 0ULL, 4);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VSum: {
          heff_take_n(v_v1_2476, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VPrimInt: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VPrimFloat: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VPrimString: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VPrimRune: {
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VPrimArray: {
          heff_take_n(v_v1_2476, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        case TAG_VFixed: {
          heff_take_n(v_v1_2476, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
          heff_drop(v_h_2432);
          heff_drop_clo(v_spineTh_2434, 2);
          heff_drop_cell(v_ru_24lit_2431_24Become, 1);
          v_v_24101 = v_v_2470;
          break;
        }
        default: heff_nomatch(v_v1_2476);
        }
        break;
      }
      case TAG_VLam: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Become, 1);
        v_v_24101 = v_v_2470;
        break;
      }
      case TAG_VCons: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Become, 1);
        v_v_24101 = v_v_2470;
        break;
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_ru_24t_2423_24ForDescriptive, 2);
        heff_drop(v_h_2432);
        heff_drop_clo(v_spineTh_2434, 2);
        heff_drop_cell(v_ru_24lit_2431_24Become, 1);
        v_v_24101 = v_v_2470;
        break;
      }
      default: heff_nomatch(v_v_2470);
      }
      break;
    }
    default: heff_nomatch(v_lit_2431);
    }
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  heff_clo_take(self, 10);
  return (g_heff_2eelab_2erules_2echeckFixed(heff_dup(v_e_240), heff_dup(v_span_2420), heff_dup(v_v_24101), v_fvalue_2414, heff_dup(v_z_246), heff_clo_n(g_heff_2eelab_2erules_2eintroGo_lam3, 1, 14, (V[]){v_x_2410, v_v_24101, v_done_242, v_e_240, v_it_241, v_z_246, v_vs_243, v_rest_2421, v_rest_249, v_fty_2413, v_el_2419, v_dflt_2422, v_span_2420, v_z_247})));
}
Clo g_heff_2eelab_2erules_2eplacesGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eplacesGo_24dps_entry, 3, 0};

V g_heff_2eelab_2erules_2eplacesGo_24dps(V v_x1_240, V v_k_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_b_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if ((heff_dup(v_b_243) == NTAG(TAG_True))) {
      heff_drop(v_b_243);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_241)}), heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
      V t_0 = v_rest_244;
      V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
      V t_2 = v_u_246;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_b_243);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
      V t_0 = v_rest_244;
      V t_1 = v_k_241;
      V t_2 = v_u_248;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eplacesGo_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eplacesGo_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2etagsExposed_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etagsExposed_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagsExposed_lam0, 2, 0};
V g_heff_2eelab_2erules_2etagsExposed_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2etagsExposed_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagsExposed_lam1, 2, 0};
V g_heff_2eelab_2erules_2etagsExposed_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2etagsExposed_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagsExposed_lam2, 2, 0};
V g_heff_2eelab_2erules_2etagsExposed_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2etagsExposed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagsExposed_entry, 6, 0};

V g_heff_2eelab_2erules_2etagsExposed(V v_e_240, V v_a_241, V v_vs_242, V v_x4_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_a_241);
    heff_drop_rec(v_vs_242, 3);
    heff_drop(v_z_244);
    return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_x41_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x41_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x41_246, 0);
      V v_tsp_249 = heff_field(v_x41_246, 1);
      HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_vs_242, 1), v_x_248));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        V v_c_2426;
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_i_2413 = v_field_2412;
          V v_xs_2414 = heff_dup(heff_rfield(v_vs_242, 2));
          if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2413, 1) && heff_intLt_c_lent(v_i_2413, heff_arrayLength_lent(v_xs_2414, 0), 2))) {
            V v_x_2415 = heff_arrayIndex(v_xs_2414, v_i_2413);
            heff_drop(v_x_2415);
            HeffT2 v_t_2416 = (g_heff_2eelab_2erules_2esealedOf_24cpr(heff_rfield(v_e_240, 1), heff_dup(v_a_241)));
            {
              V v_field_2418 = v_t_2416.f[1];
              int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
              if ((v_tag_2417 == ((int64_t)0ULL))) {
                V v_m_2419 = v_field_2418;
                v_c_2426 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2etagHidden_clo), 3, (V[]){heff_dup(v_tsp_249), heff_dup(v_x_248), v_m_2419}));
              } else {
                heff_drop(v_field_2418);
                v_c_2426 = ((V)&g_heff_2eelab_2erules_2etagsExposed_lam0_clo);
              }
            }
          } else {
            heff_drop(v_i_2413);
            heff_drop(v_xs_2414);
            v_c_2426 = ((V)&g_heff_2eelab_2erules_2etagsExposed_lam1_clo);
          }
        } else {
          heff_drop(v_field_2412);
          v_c_2426 = ((V)&g_heff_2eelab_2erules_2etagsExposed_lam2_clo);
        }
        return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2erules_2etagsExposed_lam3, 1, 6, (V[]){v_e_240, v_a_241, v_vs_242, heff_dup(v_rest_247), v_z_244, v_z_245})});
      }
    }
    default: return heff_nomatch(v_x41_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2etagsExposed_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2etagsExposed(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2etagsExposed_lam0(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagsExposed_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagsExposed_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagsExposed_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_drop(v_x_2427);
  heff_clo_take(self, 6);
  return ({ V a_0 = v_e_240; V a_1 = v_a_241; V a_2 = v_vs_242; V a_3 = v_rest_247; V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2etagsExposed(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_rest_247); r_; });
}
Clo g_heff_2eelab_2erules_2esumIntroNow_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_24map0_entry, 2, 0};

V g_heff_2eelab_2erules_2esumIntroNow_24map0(V v_box_24i_240, V v_a_241) {
  int64_t v_i_240 = heff_unbox_word(v_box_24i_240);
  v_a_241 = heff_arrayOwn(v_a_241);
  if ((((int64_t)0ULL) <= v_i_240)) {
    top_TAG_InRange: ;
    if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
      V v_m_242 = heff_arrayIndexIn_lent(v_a_241, heff_box_word(v_i_240), 2);
      V v_t_243 = heff_arraySetOwnedIn(v_a_241, heff_box_word(v_i_240), heff_get_n(v_m_242, 0, 2));
      int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
      V t_1 = v_t_243;
      v_i_240 = t_0;
      v_a_241 = t_1;
      goto top_TAG_InRange;
    } else {
      return v_a_241;
    }
  } else {
  }
top: ;
  if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
    V v_m_242 = heff_arrayIndex_lent(v_a_241, heff_box_word(v_i_240), 2);
    V v_t_243 = heff_arraySetOwned(v_a_241, heff_box_word(v_i_240), heff_get_n(v_m_242, 0, 2));
    int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
    V t_1 = v_t_243;
    v_i_240 = t_0;
    v_a_241 = t_1;
    goto top;
  } else {
    return v_a_241;
  }
}
V g_heff_2eelab_2erules_2esumIntroNow_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumIntroNow_24map0(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2ewrittenAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ewrittenAt_entry, 2, 0};

V g_heff_2eelab_2erules_2ewrittenAt(V v_x1_240, V v_x_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2eelab_2erules_2ewrittenAt_24cpr(v_x1_240, v_x_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2eelab_2erules_2ewrittenAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2ewrittenAt(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eerrorOf_24tok2_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eerrorOf_24tok2_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_24tok2_lam0, 1, 0};
V g_heff_2eelab_2erules_2eerrorOf_24tok2_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2eerrorOf_24tok2_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_24tok2_lam1, 1, 0};
Clo g_heff_2eelab_2erules_2eerrorOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eerrorOf_24tok2_entry, 3, 0};

V g_heff_2eelab_2erules_2eerrorOf_24tok2(V v_tok_240, V v_hd_241, V v_k_242) {
top: ;
  heff_drop_cell(v_tok_240, 2);
  V v_t_245 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2eerrorOf_24tok2_lam0_clo), ((V)&g_heff_2eelab_2erules_2eerrorOf_24tok2_lam1_clo)});
  return heff_tail(v_k_242, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2eelab_2erules_2eerrorOf_24rec0_get()), v_t_245})});
}
V g_heff_2eelab_2erules_2eerrorOf_24tok2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eerrorOf_24tok2(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eerrorOf_24tok2_lam0(V self, V *args) {
  V v_x_243 = args[0];
  heff_drop(v_x_243);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2eerrorOf_24tok2_lam1(V self, V *args) {
  V v_x_244 = args[0];
  heff_drop(v_x_244);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}